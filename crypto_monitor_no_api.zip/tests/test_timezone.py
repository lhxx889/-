"""
Gate.io加密货币异动监控系统 - 时区功能测试（修正版）
"""

import logging
import sys
import os
import time
from datetime import datetime
import pytz

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入时区工具
from src.timezone_utils import (
    format_time, get_current_time, localize_time, 
    parse_time, utc_to_local, local_to_utc,
    get_timezone_offset, get_timezone_name, timezone_manager
)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("timezone_test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("timezone_test")

def test_timezone_config():
    """测试时区配置"""
    logger.info("=== 测试时区配置 ===")
    
    # 获取当前时区
    timezone_name = get_timezone_name()
    timezone_offset = get_timezone_offset()
    
    logger.info(f"当前时区: {timezone_name}")
    logger.info(f"时区偏移: {timezone_offset}")
    
    # 确认是中国标准时间
    assert timezone_name == "Asia/Shanghai", f"时区应为Asia/Shanghai，实际为{timezone_name}"
    assert timezone_offset == "+08:00", f"时区偏移应为+08:00，实际为{timezone_offset}"
    
    logger.info("时区配置测试通过")

def test_current_time():
    """测试当前时间"""
    logger.info("=== 测试当前时间 ===")
    
    # 获取当前时间
    local_now = get_current_time()
    utc_now = datetime.now(pytz.UTC)
    
    logger.info(f"本地时间: {local_now}")
    logger.info(f"UTC时间: {utc_now}")
    
    # 检查时区信息
    assert local_now.tzinfo is not None, "本地时间应有时区信息"
    assert str(local_now.tzinfo) == "Asia/Shanghai", f"本地时间时区应为Asia/Shanghai，实际为{local_now.tzinfo}"
    
    # 检查时间格式
    local_time_str = format_time(local_now)
    logger.info(f"格式化后的本地时间: {local_time_str}")
    
    # 检查是否包含正确的小时数
    hour = local_now.hour
    assert 0 <= hour <= 23, f"小时数应在0-23范围内，实际为{hour}"
    
    logger.info("当前时间测试通过")

def test_time_formatting():
    """测试时间格式化"""
    logger.info("=== 测试时间格式化 ===")
    
    # 获取当前时间
    now = get_current_time()
    
    # 不同格式的时间字符串
    formats = {
        "默认格式": "%Y-%m-%d %H:%M:%S",
        "日期格式": "%Y年%m月%d日",
        "时间格式": "%H:%M:%S",
        "完整格式": "%Y-%m-%d %H:%M:%S %Z%z"
    }
    
    for name, fmt in formats.items():
        formatted = format_time(now, fmt)
        logger.info(f"{name}: {formatted}")
        
        # 检查完整格式是否包含正确的时区信息
        if name == "完整格式":
            assert "+0800" in formatted.replace(":", "") or "+08:00" in formatted, f"完整格式应包含+08:00时区信息，实际为{formatted}"
    
    # 测试无参数调用（使用当前时间）
    current_formatted = format_time()
    logger.info(f"当前时间（默认格式）: {current_formatted}")
    
    logger.info("时间格式化测试通过")

def test_time_conversion():
    """测试时间转换"""
    logger.info("=== 测试时间转换 ===")
    
    # 创建UTC时间
    utc_time = datetime.now(pytz.UTC)
    logger.info(f"原始UTC时间: {utc_time}")
    
    # 转换为本地时间
    local_time = utc_to_local(utc_time)
    logger.info(f"转换后的本地时间: {local_time}")
    
    # 检查时区
    assert str(local_time.tzinfo) == "Asia/Shanghai", f"转换后的时区应为Asia/Shanghai，实际为{local_time.tzinfo}"
    
    # 再转回UTC
    back_to_utc = local_to_utc(local_time)
    logger.info(f"转回UTC的时间: {back_to_utc}")
    
    # 检查转换是否正确
    time_diff = (back_to_utc - utc_time).total_seconds()
    logger.info(f"转换前后时差: {time_diff}秒")
    
    # 允许有少量误差（±1秒）
    assert abs(time_diff) < 1, f"转换前后时差应接近0，实际为{time_diff}秒"
    
    logger.info("时间转换测试通过")

def test_time_parsing():
    """测试时间解析"""
    logger.info("=== 测试时间解析 ===")
    
    # 测试时间字符串
    time_strings = [
        "2025-05-30 12:00:00",
        "2025-05-30 00:00:00",
        "2025-01-01 00:00:00"
    ]
    
    for time_str in time_strings:
        parsed_time = parse_time(time_str)
        logger.info(f"解析 '{time_str}' 为: {parsed_time}")
        
        # 检查解析结果是否有时区信息
        assert parsed_time.tzinfo is not None, f"解析结果应有时区信息: {parsed_time}"
        
        # 检查时区是否正确
        assert str(parsed_time.tzinfo) == "Asia/Shanghai", f"时区应为Asia/Shanghai，实际为{parsed_time.tzinfo}"
    
    logger.info("时间解析测试通过")

def test_integration_with_logging():
    """测试与日志系统的集成"""
    logger.info("=== 测试与日志系统的集成 ===")
    
    # 记录几条日志
    logger.info("这是一条信息日志")
    logger.warning("这是一条警告日志")
    logger.error("这是一条错误日志")
    
    # 检查日志文件
    with open("timezone_test.log", "r") as f:
        log_content = f.read()
    
    # 提取最后几行
    last_lines = log_content.strip().split("\n")[-3:]
    
    for line in last_lines:
        logger.info(f"日志行: {line}")
        
        # 检查日志时间戳格式
        # 格式应为: 2025-05-30 12:34:56,789 - timezone_test - INFO - ...
        timestamp = line.split(" - ")[0]
        logger.info(f"日志时间戳: {timestamp}")
        
        # 尝试解析时间戳
        try:
            # 日志时间戳格式通常为: 2025-05-30 12:34:56,789
            dt_parts = timestamp.split(",")
            dt_str = dt_parts[0]
            parsed_dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
            logger.info(f"解析后的时间: {parsed_dt}")
        except Exception as e:
            logger.error(f"解析日志时间戳失败: {str(e)}")
            assert False, f"解析日志时间戳失败: {str(e)}"
    
    logger.info("与日志系统的集成测试通过")

def main():
    """主函数"""
    logger.info("开始时区功能测试")
    
    # 确保时区设置为中国标准时间
    timezone_manager.save_config("Asia/Shanghai")
    
    # 运行测试
    test_timezone_config()
    test_current_time()
    test_time_formatting()
    test_time_conversion()
    test_time_parsing()
    test_integration_with_logging()
    
    logger.info("所有时区功能测试通过")

if __name__ == "__main__":
    main()
