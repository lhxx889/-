"""
Gate.io加密货币异动监控系统 - 系统封装类
提供与测试用例兼容的系统封装，支持无API配置模式
"""

import logging
import time
import json
import os
import threading
from datetime import datetime

# 导入自定义模块
from src.data_collector import DataCollector
from src.anomaly_detector import AnomalyDetector
from src.enhanced_telegram_alerter import EnhancedTelegramAlerter
from src.enhanced_coin_info import EnhancedCoinInfoFetcher
from src.enhanced_reason_analyzer import EnhancedReasonAnalyzer
from src.deep_analyzer import DeepAnalyzer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("crypto_monitor_system")

class CryptoMonitorSystem:
    """加密货币异动监控系统封装类，提供与测试用例兼容的接口"""
    
    def __init__(self, config_file="api_config.json"):
        """
        初始化系统
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.running = False
        
        # 初始化各模块
        self._init_modules()
        
        logger.info("加密货币异动监控系统初始化完成")
    
    def _load_config(self):
        """加载配置"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                logger.info(f"从 {self.config_file} 加载配置成功")
                return config
            except Exception as e:
                logger.error(f"加载配置失败: {str(e)}")
        
        # 使用默认配置
        logger.info("使用默认配置")
        return {
            "gate_io": {
                "api_key": "",
                "api_secret": "",
                "base_url": "https://api.gateio.ws/api/v4"
            },
            "db_path": "crypto_data.db",
            "price_change_threshold": 30.0,
            "volume_change_threshold": 300.0,
            "check_interval": 50,
            "top_coins_limit": 100
        }
    
    def _init_modules(self):
        """初始化各模块"""
        # 获取配置
        api_key = self.config.get('gate_io', {}).get('api_key', '')
        api_secret = self.config.get('gate_io', {}).get('api_secret', '')
        base_url = self.config.get('gate_io', {}).get('base_url', 'https://api.gateio.ws/api/v4')
        db_path = self.config.get('db_path', 'crypto_data.db')
        price_change_threshold = self.config.get('price_change_threshold', 30.0)
        volume_change_threshold = self.config.get('volume_change_threshold', 300.0)
        check_interval = self.config.get('check_interval', 50)
        
        # 初始化数据收集器
        self.data_collector = DataCollector(
            api_key=api_key,
            api_secret=api_secret,
            base_url=base_url,
            db_path=db_path
        )
        
        # 初始化数据监控器
        self.data_monitor = self._create_data_monitor()
        
        # 初始化异常检测器
        self.anomaly_detector = AnomalyDetector(
            price_change_threshold=price_change_threshold,
            volume_change_threshold=volume_change_threshold
        )
        
        # 初始化异常监控器
        self.anomaly_monitor = self._create_anomaly_monitor()
        
        # 初始化Telegram警报器
        self.telegram_alerter = EnhancedTelegramAlerter()
        
        # 初始化币种信息获取器
        self.coin_info_fetcher = EnhancedCoinInfoFetcher()
        
        # 初始化深度分析器
        self.deep_analyzer = DeepAnalyzer()
        
        # 初始化异动原因分析器
        self.reason_analyzer = EnhancedReasonAnalyzer()
    
    def _create_data_monitor(self):
        """创建数据监控器"""
        from src.data_collector import DataMonitor
        return DataMonitor(
            collector=self.data_collector,
            interval=self.config.get('check_interval', 50)
        )
    
    def _create_anomaly_monitor(self):
        """创建异常监控器"""
        # 创建一个简单的异常监控器类
        class AnomalyMonitor:
            def __init__(self, system, check_interval=50):
                self.system = system
                self.check_interval = check_interval
                self.running = False
            
            def start(self):
                self.running = True
                logger.info("异常监控启动")
                
                try:
                    while self.running:
                        logger.info("检查异常")
                        
                        # 获取所有币种的ticker数据
                        tickers = self.system.data_collector.get_all_tickers()
                        
                        # 检测异常
                        anomalies = self.system.anomaly_detector.detect_anomalies(tickers)
                        
                        # 处理异常
                        if anomalies:
                            logger.info(f"检测到 {len(anomalies)} 个异常")
                            self.system.handle_anomaly_alert(anomalies)
                        
                        # 等待下一次检查
                        logger.info(f"等待 {self.check_interval} 秒后进行下一次检查")
                        time.sleep(self.check_interval)
                except Exception as e:
                    logger.error(f"异常监控出错: {str(e)}")
                    self.stop()
            
            def stop(self):
                self.running = False
                logger.info("异常监控已停止")
        
        return AnomalyMonitor(
            system=self,
            check_interval=self.config.get('check_interval', 50)
        )
    
    def configure_telegram(self, token, chat_id):
        """配置Telegram"""
        return self.telegram_alerter.save_config(token, chat_id)
    
    def handle_anomaly_alert(self, anomalies):
        """处理异常警报"""
        if not anomalies:
            return
        
        for anomaly in anomalies:
            try:
                # 获取币种信息
                symbol = anomaly.get("symbol", "")
                coin_info = self.coin_info_fetcher.get_coin_info(symbol)
                
                # 分析异动原因
                reasons = self.reason_analyzer.analyze_anomaly(anomaly, coin_info)
                
                # 添加分析结果到异常数据
                anomaly["analysis"] = reasons
                
                # 添加币种信息到异常数据
                anomaly["coin_info"] = coin_info
                
                # 发送警报
                self.telegram_alerter.send_anomaly_alert(anomaly)
                
            except Exception as e:
                logger.error(f"处理异常失败: {str(e)}")
    
    def start(self):
        """启动系统"""
        if self.running:
            logger.warning("系统已经在运行")
            return
        
        self.running = True
        logger.info("启动加密货币异动监控系统")
        
        # 启动数据监控线程
        self.data_monitor_thread = threading.Thread(target=self.data_monitor.start)
        self.data_monitor_thread.daemon = True
        self.data_monitor_thread.start()
        
        # 启动异常监控线程
        self.anomaly_monitor_thread = threading.Thread(target=self.anomaly_monitor.start)
        self.anomaly_monitor_thread.daemon = True
        self.anomaly_monitor_thread.start()
        
        # 发送启动消息
        if self.telegram_alerter.is_configured():
            start_message = f"Gate.io加密货币异动监控系统已启动\n\n当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            self.telegram_alerter.send_message(start_message)
    
    def stop(self):
        """停止系统"""
        if not self.running:
            logger.warning("系统已经停止")
            return
        
        logger.info("停止加密货币异动监控系统")
        
        # 停止数据监控
        self.data_monitor.stop()
        
        # 停止异常监控
        self.anomaly_monitor.stop()
        
        # 发送停止消息
        if self.telegram_alerter.is_configured():
            stop_message = f"Gate.io加密货币异动监控系统已停止\n\n当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            self.telegram_alerter.send_message(stop_message)
        
        self.running = False
        
        # 等待线程结束
        if hasattr(self, 'data_monitor_thread') and self.data_monitor_thread.is_alive():
            self.data_monitor_thread.join(timeout=5)
        
        if hasattr(self, 'anomaly_monitor_thread') and self.anomaly_monitor_thread.is_alive():
            self.anomaly_monitor_thread.join(timeout=5)
        
        logger.info("系统已完全停止")

# 导出系统类，供主程序和测试用例使用
__all__ = ['CryptoMonitorSystem']
