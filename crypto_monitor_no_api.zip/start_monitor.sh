#!/bin/bash
# Gate.io加密货币异动监控系统 - 快捷启动脚本

# 定义颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# 配置文件
CONFIG_FILE="config.json"
TELEGRAM_CONFIG_FILE="telegram_config.json"
API_CONFIG_FILE="api_config.json"

# 日志文件
LOG_FILE="crypto_monitor.log"
PID_FILE="crypto_monitor.pid"

# 显示欢迎信息
echo -e "${BLUE}=======================================${NC}"
echo -e "${BLUE}  Gate.io加密货币异动监控系统启动工具  ${NC}"
echo -e "${BLUE}=======================================${NC}"
echo ""

# 检查Python环境
check_python() {
    echo -e "${YELLOW}检查Python环境...${NC}"
    if command -v python3 &>/dev/null; then
        PYTHON="python3"
    elif command -v python &>/dev/null; then
        PYTHON="python"
    else
        echo -e "${RED}错误: 未找到Python。请安装Python 3.8+${NC}"
        exit 1
    fi
    
    PY_VERSION=$($PYTHON --version 2>&1 | cut -d' ' -f2)
    echo -e "${GREEN}找到Python版本: $PY_VERSION${NC}"
    
    # 检查依赖
    echo -e "${YELLOW}检查依赖库...${NC}"
    $PYTHON -c "import requests, numpy, pandas, matplotlib" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo -e "${YELLOW}安装依赖库...${NC}"
        $PYTHON -m pip install -r requirements.txt
        if [ $? -ne 0 ]; then
            echo -e "${RED}错误: 依赖库安装失败${NC}"
            exit 1
        fi
    fi
    echo -e "${GREEN}依赖库检查完成${NC}"
}

# 检查配置文件
check_config() {
    echo -e "${YELLOW}检查配置文件...${NC}"
    
    # 检查主配置文件
    if [ ! -f "$CONFIG_FILE" ]; then
        echo -e "${YELLOW}未找到配置文件，创建默认配置...${NC}"
        cat > "$CONFIG_FILE" << EOF
{
    "db_path": "crypto_data.db",
    "check_interval": 50,
    "price_change_threshold": 30.0,
    "volume_change_threshold": 200.0,
    "enable_charts": true,
    "enable_enhanced_info": true,
    "max_alerts_per_batch": 5,
    "dedup_window": 3600
}
EOF
    fi
    
    # 检查Telegram配置文件
    if [ ! -f "$TELEGRAM_CONFIG_FILE" ]; then
        echo -e "${YELLOW}未找到Telegram配置文件${NC}"
        setup_telegram
    fi
    
    echo -e "${GREEN}配置文件检查完成${NC}"
}

# 设置Telegram配置
setup_telegram() {
    echo -e "${YELLOW}设置Telegram配置${NC}"
    echo "请按照以下步骤获取Telegram Bot Token和Chat ID:"
    echo "1. 在Telegram中搜索 @BotFather 并开始对话"
    echo "2. 发送 /newbot 命令创建新机器人"
    echo "3. 按照提示设置机器人名称和用户名"
    echo "4. 获取API Token"
    echo "5. 将机器人添加到目标聊天中"
    echo "6. 获取Chat ID (可以使用 @get_id_bot 或其他方法)"
    echo ""
    
    read -p "请输入Telegram Bot Token: " TOKEN
    read -p "请输入Chat ID: " CHAT_ID
    
    cat > "$TELEGRAM_CONFIG_FILE" << EOF
{
    "token": "$TOKEN",
    "chat_id": "$CHAT_ID"
}
EOF
    
    echo -e "${GREEN}Telegram配置已保存${NC}"
}

# 设置API配置
setup_api() {
    echo -e "${YELLOW}设置API配置${NC}"
    echo "以下API密钥是可选的，如果没有可以留空:"
    
    read -p "请输入CryptoCompare API密钥 (可选): " CRYPTOCOMPARE_KEY
    read -p "请输入CoinMarketCap API密钥 (可选): " CMC_KEY
    
    cat > "$API_CONFIG_FILE" << EOF
{
    "cryptocompare_api_key": "$CRYPTOCOMPARE_KEY",
    "cmc_api_key": "$CMC_KEY"
}
EOF
    
    echo -e "${GREEN}API配置已保存${NC}"
}

# 设置监控参数
setup_monitor_params() {
    echo -e "${YELLOW}设置监控参数${NC}"
    
    # 读取当前配置
    if [ -f "$CONFIG_FILE" ]; then
        INTERVAL=$(grep -o '"check_interval":[^,}]*' "$CONFIG_FILE" | cut -d':' -f2)
        PRICE_THRESHOLD=$(grep -o '"price_change_threshold":[^,}]*' "$CONFIG_FILE" | cut -d':' -f2)
        VOLUME_THRESHOLD=$(grep -o '"volume_change_threshold":[^,}]*' "$CONFIG_FILE" | cut -d':' -f2)
    else
        INTERVAL=50
        PRICE_THRESHOLD=30.0
        VOLUME_THRESHOLD=200.0
    fi
    
    read -p "请输入检查间隔(秒) [$INTERVAL]: " NEW_INTERVAL
    read -p "请输入价格变化阈值(%) [$PRICE_THRESHOLD]: " NEW_PRICE_THRESHOLD
    read -p "请输入交易量变化阈值(%) [$VOLUME_THRESHOLD]: " NEW_VOLUME_THRESHOLD
    
    # 使用默认值如果用户没有输入
    INTERVAL=${NEW_INTERVAL:-$INTERVAL}
    PRICE_THRESHOLD=${NEW_PRICE_THRESHOLD:-$PRICE_THRESHOLD}
    VOLUME_THRESHOLD=${NEW_VOLUME_THRESHOLD:-$VOLUME_THRESHOLD}
    
    # 更新配置文件
    if [ -f "$CONFIG_FILE" ]; then
        # 使用临时文件避免sed -i的兼容性问题
        TMP_FILE=$(mktemp)
        cat "$CONFIG_FILE" | sed "s/\"check_interval\":[^,}]*/\"check_interval\": $INTERVAL/" | \
                             sed "s/\"price_change_threshold\":[^,}]*/\"price_change_threshold\": $PRICE_THRESHOLD/" | \
                             sed "s/\"volume_change_threshold\":[^,}]*/\"volume_change_threshold\": $VOLUME_THRESHOLD/" > "$TMP_FILE"
        mv "$TMP_FILE" "$CONFIG_FILE"
    else
        # 创建新配置文件
        cat > "$CONFIG_FILE" << EOF
{
    "db_path": "crypto_data.db",
    "check_interval": $INTERVAL,
    "price_change_threshold": $PRICE_THRESHOLD,
    "volume_change_threshold": $VOLUME_THRESHOLD,
    "enable_charts": true,
    "enable_enhanced_info": true,
    "max_alerts_per_batch": 5,
    "dedup_window": 3600
}
EOF
    fi
    
    echo -e "${GREEN}监控参数已更新${NC}"
}

# 检查监控状态
check_status() {
    echo -e "${YELLOW}检查监控状态...${NC}"
    
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p "$PID" > /dev/null; then
            echo -e "${GREEN}监控系统正在运行 (PID: $PID)${NC}"
            
            # 显示运行时间
            if [ -f "/proc/$PID/stat" ]; then
                START_TIME=$(stat -c %Y "/proc/$PID/stat")
                CURRENT_TIME=$(date +%s)
                RUNTIME=$((CURRENT_TIME - START_TIME))
                
                DAYS=$((RUNTIME / 86400))
                HOURS=$(( (RUNTIME % 86400) / 3600 ))
                MINUTES=$(( (RUNTIME % 3600) / 60 ))
                SECONDS=$((RUNTIME % 60))
                
                echo -e "${BLUE}运行时间: ${DAYS}天 ${HOURS}小时 ${MINUTES}分钟 ${SECONDS}秒${NC}"
            fi
            
            # 显示最近日志
            echo -e "${BLUE}最近日志:${NC}"
            tail -n 5 "$LOG_FILE"
            return 0
        else
            echo -e "${RED}监控系统已崩溃或被意外终止${NC}"
            rm -f "$PID_FILE"
            return 1
        fi
    else
        echo -e "${YELLOW}监控系统未运行${NC}"
        return 1
    fi
}

# 启动监控
start_monitor() {
    echo -e "${YELLOW}启动监控系统...${NC}"
    
    # 检查是否已经运行
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p "$PID" > /dev/null; then
            echo -e "${RED}监控系统已经在运行 (PID: $PID)${NC}"
            return 1
        else
            rm -f "$PID_FILE"
        fi
    fi
    
    # 启动监控
    nohup $PYTHON main.py > /dev/null 2>&1 &
    NEW_PID=$!
    echo $NEW_PID > "$PID_FILE"
    
    # 检查是否成功启动
    sleep 2
    if ps -p "$NEW_PID" > /dev/null; then
        echo -e "${GREEN}监控系统已成功启动 (PID: $NEW_PID)${NC}"
        return 0
    else
        echo -e "${RED}监控系统启动失败${NC}"
        rm -f "$PID_FILE"
        return 1
    fi
}

# 停止监控
stop_monitor() {
    echo -e "${YELLOW}停止监控系统...${NC}"
    
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p "$PID" > /dev/null; then
            kill "$PID"
            sleep 2
            
            # 检查是否成功停止
            if ps -p "$PID" > /dev/null; then
                echo -e "${RED}无法正常停止，尝试强制终止...${NC}"
                kill -9 "$PID"
                sleep 1
            fi
            
            # 最终检查
            if ps -p "$PID" > /dev/null; then
                echo -e "${RED}无法停止监控系统 (PID: $PID)${NC}"
                return 1
            else
                echo -e "${GREEN}监控系统已停止${NC}"
                rm -f "$PID_FILE"
                return 0
            fi
        else
            echo -e "${YELLOW}监控系统未运行${NC}"
            rm -f "$PID_FILE"
            return 0
        fi
    else
        echo -e "${YELLOW}监控系统未运行${NC}"
        return 0
    fi
}

# 重启监控
restart_monitor() {
    echo -e "${YELLOW}重启监控系统...${NC}"
    
    stop_monitor
    sleep 2
    start_monitor
}

# 恢复监控
resume_monitor() {
    echo -e "${YELLOW}检查并恢复监控系统...${NC}"
    
    # 检查是否已经运行
    if check_status; then
        echo -e "${GREEN}监控系统正常运行，无需恢复${NC}"
        return 0
    fi
    
    # 尝试启动
    echo -e "${YELLOW}尝试启动监控系统...${NC}"
    start_monitor
}

# 查看日志
view_logs() {
    echo -e "${YELLOW}显示监控日志...${NC}"
    
    if [ -f "$LOG_FILE" ]; then
        less "$LOG_FILE"
    else
        echo -e "${RED}日志文件不存在${NC}"
    fi
}

# 清理日志
clean_logs() {
    echo -e "${YELLOW}清理旧日志...${NC}"
    
    if [ -f "$LOG_FILE" ]; then
        # 备份旧日志
        BACKUP_FILE="${LOG_FILE}.$(date +%Y%m%d%H%M%S).bak"
        cp "$LOG_FILE" "$BACKUP_FILE"
        
        # 清空当前日志
        echo "" > "$LOG_FILE"
        
        echo -e "${GREEN}日志已清理，旧日志备份为: $BACKUP_FILE${NC}"
    else
        echo -e "${YELLOW}日志文件不存在${NC}"
    fi
}

# 安装系统服务
install_service() {
    echo -e "${YELLOW}安装系统服务...${NC}"
    
    # 检查是否有root权限
    if [ "$EUID" -ne 0 ]; then
        echo -e "${RED}安装系统服务需要root权限${NC}"
        echo "请使用sudo运行此命令"
        return 1
    fi
    
    # 创建服务文件
    SERVICE_FILE="/etc/systemd/system/crypto_monitor.service"
    
    cat > "$SERVICE_FILE" << EOF
[Unit]
Description=Gate.io Crypto Currency Monitor
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$SCRIPT_DIR
ExecStart=$PYTHON $SCRIPT_DIR/main.py
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=crypto_monitor

[Install]
WantedBy=multi-user.target
EOF
    
    # 重新加载systemd
    systemctl daemon-reload
    
    # 启用服务
    systemctl enable crypto_monitor.service
    
    echo -e "${GREEN}系统服务已安装并启用${NC}"
    echo "可以使用以下命令管理服务:"
    echo "  sudo systemctl start crypto_monitor.service"
    echo "  sudo systemctl stop crypto_monitor.service"
    echo "  sudo systemctl status crypto_monitor.service"
}

# 主菜单
show_menu() {
    clear
    echo -e "${BLUE}=======================================${NC}"
    echo -e "${BLUE}  Gate.io加密货币异动监控系统控制面板  ${NC}"
    echo -e "${BLUE}=======================================${NC}"
    echo ""
    echo -e "${YELLOW}1. 启动监控${NC}"
    echo -e "${YELLOW}2. 停止监控${NC}"
    echo -e "${YELLOW}3. 重启监控${NC}"
    echo -e "${YELLOW}4. 检查状态${NC}"
    echo -e "${YELLOW}5. 恢复监控${NC}"
    echo -e "${YELLOW}6. 设置Telegram${NC}"
    echo -e "${YELLOW}7. 设置API密钥${NC}"
    echo -e "${YELLOW}8. 设置监控参数${NC}"
    echo -e "${YELLOW}9. 查看日志${NC}"
    echo -e "${YELLOW}10. 清理日志${NC}"
    echo -e "${YELLOW}11. 安装为系统服务${NC}"
    echo -e "${YELLOW}0. 退出${NC}"
    echo ""
    read -p "请选择操作 [0-11]: " choice
    
    case $choice in
        1) start_monitor ;;
        2) stop_monitor ;;
        3) restart_monitor ;;
        4) check_status ;;
        5) resume_monitor ;;
        6) setup_telegram ;;
        7) setup_api ;;
        8) setup_monitor_params ;;
        9) view_logs ;;
        10) clean_logs ;;
        11) install_service ;;
        0) exit 0 ;;
        *) echo -e "${RED}无效选择${NC}" ;;
    esac
    
    echo ""
    read -p "按Enter键继续..."
    show_menu
}

# 检查环境和配置
check_python
check_config

# 如果有命令行参数，直接执行对应操作
if [ $# -gt 0 ]; then
    case "$1" in
        start) start_monitor ;;
        stop) stop_monitor ;;
        restart) restart_monitor ;;
        status) check_status ;;
        resume) resume_monitor ;;
        *) echo -e "${RED}无效参数: $1${NC}" ;;
    esac
else
    # 显示菜单
    show_menu
fi
