"""
Gate.io加密货币异动监控系统 - 主程序入口
支持无API配置模式，自动使用公开数据源或模拟数据
"""

import logging
import time
import sys
import os
import argparse
import json
from datetime import datetime, timedelta
import signal
import threading

# 导入系统封装类
from crypto_monitor_system import CryptoMonitorSystem

# 导入时区工具
try:
    from src.timezone_utils import format_time, get_current_time, timezone_manager
    timezone_utils_available = True
except ImportError:
    timezone_utils_available = False

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("main")

# 全局变量
running = True
system = None

def setup_timezone():
    """设置时区"""
    if not timezone_utils_available:
        logger.warning("时区工具模块不可用，将使用系统默认时区")
        return False
    
    # 设置为中国标准时间
    timezone_manager.save_config("Asia/Shanghai")
    logger.info(f"时区已设置为: {timezone_manager.timezone_str}")
    return True

def setup_telegram():
    """设置Telegram"""
    global system
    
    if system.telegram_alerter.is_configured():
        logger.info("Telegram已配置")
        return True
    
    logger.info("Telegram未配置，开始设置...")
    
    token = input("请输入Telegram Bot Token: ")
    chat_id = input("请输入Chat ID: ")
    
    if not token or not chat_id:
        logger.error("Token或Chat ID不能为空")
        return False
    
    if system.configure_telegram(token, chat_id):
        logger.info("Telegram配置已保存")
        
        # 测试连接
        if system.telegram_alerter.test_connection():
            logger.info("Telegram连接测试成功")
            
            # 发送测试消息
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if timezone_utils_available:
                current_time = format_time()
            
            test_message = f"Gate.io加密货币异动监控系统已启动\n\n当前时间: {current_time}"
            if system.telegram_alerter.send_message(test_message):
                logger.info("测试消息已发送")
                return True
            else:
                logger.error("测试消息发送失败")
                return False
        else:
            logger.error("Telegram连接测试失败")
            return False
    else:
        logger.error("Telegram配置保存失败")
        return False

def setup_api_config():
    """设置API配置"""
    config_file = "api_config.json"
    
    if os.path.exists(config_file):
        logger.info("API配置文件已存在")
        return True
    
    logger.info("API配置文件不存在，创建默认配置...")
    
    default_config = {
        "gate_io": {
            "api_key": "",
            "api_secret": "",
            "base_url": "https://api.gateio.ws/api/v4"
        },
        "price_change_threshold": 30.0,  # 价格变化阈值（百分比）
        "volume_change_threshold": 300.0,  # 交易量变化阈值（百分比）
        "check_interval": 50,  # 检查间隔（秒）
        "top_coins_limit": 100  # 监控的前多少名币种
    }
    
    try:
        with open(config_file, 'w') as f:
            json.dump(default_config, f, indent=4)
        logger.info("默认API配置已创建")
        return True
    except Exception as e:
        logger.error(f"创建API配置文件失败: {str(e)}")
        return False

def load_api_config():
    """加载API配置"""
    config_file = "api_config.json"
    
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
        logger.info("API配置已加载")
        return config
    except Exception as e:
        logger.error(f"加载API配置失败: {str(e)}")
        return None

def update_api_config():
    """更新API配置"""
    config_file = "api_config.json"
    
    try:
        # 加载当前配置
        with open(config_file, 'r') as f:
            config = json.load(f)
        
        # 更新配置
        print("\n当前配置:")
        print(f"价格变化阈值: {config.get('price_change_threshold', 30.0)}%")
        print(f"交易量变化阈值: {config.get('volume_change_threshold', 300.0)}%")
        print(f"检查间隔: {config.get('check_interval', 50)}秒")
        print(f"监控的前多少名币种: {config.get('top_coins_limit', 100)}")
        
        print("\n请输入新的配置值（直接回车保持不变）:")
        
        # 价格变化阈值
        price_input = input(f"价格变化阈值 [{config.get('price_change_threshold', 30.0)}%]: ")
        if price_input:
            try:
                config['price_change_threshold'] = float(price_input)
            except:
                print("输入无效，保持原值")
        
        # 交易量变化阈值
        volume_input = input(f"交易量变化阈值 [{config.get('volume_change_threshold', 300.0)}%]: ")
        if volume_input:
            try:
                config['volume_change_threshold'] = float(volume_input)
            except:
                print("输入无效，保持原值")
        
        # 检查间隔
        interval_input = input(f"检查间隔 [{config.get('check_interval', 50)}秒]: ")
        if interval_input:
            try:
                config['check_interval'] = int(interval_input)
            except:
                print("输入无效，保持原值")
        
        # 监控的前多少名币种
        limit_input = input(f"监控的前多少名币种 [{config.get('top_coins_limit', 100)}]: ")
        if limit_input:
            try:
                config['top_coins_limit'] = int(limit_input)
            except:
                print("输入无效，保持原值")
        
        # 保存配置
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=4)
        
        logger.info("API配置已更新")
        print("\nAPI配置已更新")
        return True
    except Exception as e:
        logger.error(f"更新API配置失败: {str(e)}")
        print(f"\n更新API配置失败: {str(e)}")
        return False

def signal_handler(sig, frame):
    """信号处理函数"""
    global running, system
    logger.info("接收到停止信号，准备退出...")
    running = False
    if system:
        system.stop()

def setup_wizard():
    """设置向导"""
    global system
    
    print("\n===== Gate.io加密货币异动监控系统设置向导 =====\n")
    
    # 设置时区
    if timezone_utils_available:
        print("设置时区...")
        setup_timezone()
        print(f"时区已设置为: {timezone_manager.timezone_str}")
    
    # 设置API配置
    print("\n设置API配置...")
    if setup_api_config():
        update_api_config()
    
    # 初始化系统
    system = CryptoMonitorSystem()
    
    # 设置Telegram
    print("\n设置Telegram...")
    if setup_telegram():
        print("Telegram设置成功")
    else:
        print("Telegram设置失败，请检查Token和Chat ID")
    
    print("\n设置完成！")
    print("\n注意：Gate.io API配置为可选项，即使不配置API密钥，系统也能通过公开数据源或模拟数据正常运行。")

def main():
    """主函数"""
    global running, system
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Gate.io加密货币异动监控系统")
    parser.add_argument("--setup", action="store_true", help="运行设置向导")
    parser.add_argument("--config", action="store_true", help="更新API配置")
    parser.add_argument("--no-api", action="store_true", help="不使用API，强制使用公开数据源或模拟数据")
    args = parser.parse_args()
    
    # 设置时区
    if timezone_utils_available:
        setup_timezone()
    
    # 运行设置向导
    if args.setup:
        setup_wizard()
        return
    
    # 更新API配置
    if args.config:
        update_api_config()
        return
    
    # 设置API配置
    if not setup_api_config():
        logger.error("API配置设置失败")
        return
    
    # 如果指定了--no-api参数，修改配置文件
    if args.no_api:
        logger.info("已指定不使用API，将强制使用公开数据源或模拟数据")
        config = load_api_config()
        if config:
            config['gate_io']['api_key'] = ""
            config['gate_io']['api_secret'] = ""
            with open("api_config.json", 'w') as f:
                json.dump(config, f, indent=4)
    
    # 初始化系统
    system = CryptoMonitorSystem()
    
    # 检查Telegram是否已配置
    if not system.telegram_alerter.is_configured():
        logger.error("Telegram未配置，请先运行设置向导")
        print("Telegram未配置，请先运行设置向导：python main.py --setup")
        return
    
    # 设置信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 启动系统
    system.start()
    
    # 等待系统停止
    try:
        while running:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("接收到键盘中断，准备退出...")
        running = False
        system.stop()
    
    logger.info("系统已停止")

if __name__ == "__main__":
    main()
