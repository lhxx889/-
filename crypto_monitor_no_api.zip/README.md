# Gate.io加密货币异动监控系统

## 系统概述

Gate.io加密货币异动监控系统是一个实时监控加密货币价格和交易量变化的自动化工具。当检测到价格波动超过30%或交易量猛增时，系统会自动通过Telegram推送异动警报、异动原因分析和币种详细信息。

### 主要功能

1. **实时监控**：每50秒检查一次所有币种的价格和交易量变化
2. **智能检测**：自动识别异常波动情况
3. **即时推送**：通过Telegram机器人实时推送警报
4. **深度分析**：提供异动可能原因的智能分析
5. **详细信息**：自动查询并推送币种的市值、持币人数、简介和社交媒体链接

## 系统架构

系统由以下几个核心模块组成：

1. **数据采集模块**：负责从Gate.io API获取实时价格和交易量数据
2. **异常检测模块**：负责分析价格和交易量变化，识别异常波动
3. **Telegram推送模块**：负责将异常事件推送到Telegram
4. **深度分析模块**：负责分析异动可能的原因和获取币种详细信息

## 安装指南

### 系统要求

- Python 3.8+
- SQLite3
- 网络连接

### 一键安装（推荐）

我们提供了一键安装脚本，可以自动完成环境配置、依赖安装和初始设置：

1. 克隆或下载源代码到您的服务器

2. 进入项目目录并运行安装脚本
   ```bash
   cd crypto_monitor
   chmod +x install.sh
   ./install.sh
   ```

3. 按照提示配置Telegram机器人信息和监控参数

4. 安装完成后，使用以下命令启动系统
   ```bash
   ./start_monitor.sh
   ```

### 手动安装

如果您希望手动安装，请按照以下步骤操作：

1. 克隆或下载源代码到您的服务器

2. 安装依赖库
   ```bash
   pip install -r requirements.txt
   ```

3. 配置Telegram机器人
   - 在Telegram中搜索 @BotFather 并开始对话
   - 发送 /newbot 命令创建新机器人
   - 按照提示设置机器人名称和用户名
   - 获取API Token
   - 将机器人添加到目标聊天中
   - 获取Chat ID (可以使用 @get_id_bot 或其他方法)

4. 运行设置向导
   ```bash
   python main.py --setup
   ```
   按照提示输入Telegram Bot Token和Chat ID，以及其他监控参数

### 作为系统服务运行（Linux）

在Linux系统上，您可以将监控系统设置为系统服务，以便开机自启动：

1. 如果您使用了一键安装脚本，服务文件已经创建好，只需执行：
   ```bash
   sudo cp /path/to/crypto_monitor/crypto_monitor.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable crypto_monitor.service
   sudo systemctl start crypto_monitor.service
   ```

2. 检查服务状态：
   ```bash
   sudo systemctl status crypto_monitor.service
   ```

## 使用指南

### 启动系统

```bash
python main.py
```

### 配置参数

系统配置保存在`config.json`文件中，可以手动编辑或通过设置向导修改：

```json
{
    "db_path": "crypto_data.db",
    "check_interval": 50,
    "price_change_threshold": 30.0,
    "volume_change_threshold": 200.0,
    "telegram_token": "YOUR_TELEGRAM_BOT_TOKEN",
    "telegram_chat_id": "YOUR_CHAT_ID"
}
```

- `db_path`: SQLite数据库路径
- `check_interval`: 检查间隔（秒）
- `price_change_threshold`: 价格变化阈值（百分比）
- `volume_change_threshold`: 交易量变化阈值（百分比）
- `telegram_token`: Telegram Bot API令牌
- `telegram_chat_id`: 目标聊天ID

### 警报示例

当检测到异常时，系统会发送类似以下的警报：

```
🚨 价格异动警报 🚨
币种: BTC_USDT
价格: $50,000 (↑11.11%)
参考价格: $45,000
24小时交易量: $1,000,000,000
检测时间: 2025-05-29 14:30:45
```

随后会发送深度分析结果：

```
📊 BTC_USDT 异动分析 📊

可能原因:
1. 积极新闻推动价格上涨
2. 社交媒体上的积极讨论
3. 大型机构投资者增持

币种信息:
名称: Bitcoin
市值: $1,000,000,000,000
持币地址数: 1,000,000+
官网: https://bitcoin.org
Twitter: @bitcoin (1,000,000 关注者)
```

## 系统维护

### 日志

系统日志保存在`crypto_monitor.log`文件中，包含详细的运行信息和错误记录。

### 数据库

系统使用SQLite数据库存储价格历史和异常记录，数据库文件默认为`crypto_data.db`。

### 故障排除

1. **无法获取数据**
   - 检查网络连接
   - 确认Gate.io API是否可访问
   - 查看日志文件中的错误信息

2. **无法发送Telegram消息**
   - 确认Telegram Bot Token和Chat ID是否正确
   - 确认机器人是否已添加到目标聊天中
   - 检查网络连接

3. **系统占用资源过高**
   - 增加检查间隔时间
   - 减少监控的币种数量

## 开发者信息

### 项目结构

```
crypto_monitor/
├── main.py                 # 主程序
├── config.json             # 配置文件
├── requirements.txt        # 依赖库列表
├── src/
│   ├── __init__.py
│   ├── data_collector.py   # 数据采集模块
│   ├── anomaly_detector.py # 异常检测模块
│   ├── telegram_alerter.py # Telegram推送模块
│   └── deep_analyzer.py    # 深度分析模块
└── tests/
    ├── __init__.py
    ├── test_modules.py     # 单元测试
    └── test_integration.py # 集成测试
```

### 扩展开发

1. **添加新的数据源**
   - 在`data_collector.py`中添加新的API接口
   - 实现数据格式转换和存储

2. **自定义异常检测算法**
   - 在`anomaly_detector.py`中修改检测逻辑
   - 调整阈值和过滤条件

3. **增加其他通知渠道**
   - 参考`telegram_alerter.py`实现新的推送模块
   - 在主程序中注册新的推送渠道

## 许可证

本项目采用MIT许可证。详见LICENSE文件。

## 联系方式

如有任何问题或建议，请联系开发者。
