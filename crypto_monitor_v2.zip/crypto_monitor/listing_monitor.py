#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交易所新币上线公告监控模块
"""

import time
import json
import logging
import re
import requests
from typing import Dict, List, Any, Optional
from bs4 import BeautifulSoup
from datetime import datetime

from config import API_CONFIG, MONITOR_CONFIG
from utils import (
    make_api_request, save_new_listing, logger,
    format_timestamp
)

def monitor_binance_listings() -> List[Dict[str, Any]]:
    """
    监控币安新币上线公告
    
    Returns:
        新币上线信息列表
    """
    logger.info("开始监控币安新币上线公告...")
    new_listings = []
    
    try:
        # 获取币安公告列表
        params = {
            'catalogId': '48',  # 新币上线公告分类ID
            'pageNo': 1,
            'pageSize': 20,
            'rnd': int(time.time() * 1000)
        }
        
        response = make_api_request(
            exchange='binance',
            endpoint=API_CONFIG['binance']['announcement_url'],
            method='POST',
            data=params,
            use_base_url=True
        )
        
        if not response or 'data' not in response or 'catalogs' not in response['data']:
            logger.error("获取币安公告列表失败")
            return []
        
        articles = []
        for catalog in response['data']['catalogs']:
            if 'articles' in catalog:
                articles.extend(catalog['articles'])
        
        # 处理公告列表
        for article in articles:
            try:
                # 检查是否是新币上线公告
                title = article.get('title', '')
                if not ('上线' in title or '将上线' in title or 'Lists' in title or 'Will List' in title):
                    continue
                
                # 提取公告详情
                article_id = article.get('id', '')
                publish_time = article.get('releaseDate', 0) // 1000  # 转换为秒
                
                # 获取公告详情页URL
                article_url = f"https://www.binance.com/zh-CN/support/announcement/{article_id}"
                
                # 提取币种符号
                symbol_match = re.search(r'\(([A-Z0-9]+)\)', title)
                if not symbol_match:
                    continue
                
                symbol = symbol_match.group(1)
                
                # 保存新币上线信息
                is_new = save_new_listing(
                    exchange='binance',
                    symbol=symbol,
                    name=title.split('(')[0].strip(),
                    listing_time=publish_time,
                    initial_price=0,  # 初始价格暂时设为0，后续可以更新
                    announcement_url=article_url
                )
                
                if is_new:
                    new_listings.append({
                        'exchange': 'binance',
                        'symbol': symbol,
                        'name': title.split('(')[0].strip(),
                        'listing_time': publish_time,
                        'announcement_url': article_url
                    })
                    
                    logger.info(f"发现币安新币上线: {symbol}")
                
            except Exception as e:
                logger.error(f"处理币安公告失败: {str(e)}")
        
        logger.info(f"币安新币上线监控完成，发现 {len(new_listings)} 个新币")
        return new_listings
        
    except Exception as e:
        logger.error(f"监控币安新币上线失败: {str(e)}")
        return []

def monitor_gate_listings() -> List[Dict[str, Any]]:
    """
    监控Gate.io新币上线公告
    
    Returns:
        新币上线信息列表
    """
    logger.info("开始监控Gate.io新币上线公告...")
    new_listings = []
    
    try:
        # 获取Gate.io公告列表
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get(
            API_CONFIG['gate']['announcement_url'],
            headers=headers,
            timeout=30
        )
        
        response.raise_for_status()
        
        # 解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 查找公告列表
        announcement_list = soup.select('.article-list li')
        
        for item in announcement_list:
            try:
                # 获取公告标题和链接
                title_elem = item.select_one('.title a')
                if not title_elem:
                    continue
                
                title = title_elem.text.strip()
                
                # 检查是否是新币上线公告
                if not ('上线' in title or '将上线' in title or 'Lists' in title or 'Will List' in title):
                    continue
                
                # 获取公告链接
                article_url = 'https://www.gate.io' + title_elem.get('href', '')
                
                # 获取发布时间
                time_elem = item.select_one('.time')
                publish_time = int(time.time())  # 默认为当前时间
                if time_elem:
                    time_str = time_elem.text.strip()
                    try:
                        # 尝试解析时间字符串
                        dt = datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S')
                        publish_time = int(dt.timestamp())
                    except:
                        pass
                
                # 提取币种符号
                symbol_match = re.search(r'\(([A-Z0-9]+)\)', title)
                if not symbol_match:
                    continue
                
                symbol = symbol_match.group(1)
                
                # 保存新币上线信息
                is_new = save_new_listing(
                    exchange='gate',
                    symbol=symbol,
                    name=title.split('(')[0].strip(),
                    listing_time=publish_time,
                    initial_price=0,  # 初始价格暂时设为0，后续可以更新
                    announcement_url=article_url
                )
                
                if is_new:
                    new_listings.append({
                        'exchange': 'gate',
                        'symbol': symbol,
                        'name': title.split('(')[0].strip(),
                        'listing_time': publish_time,
                        'announcement_url': article_url
                    })
                    
                    logger.info(f"发现Gate.io新币上线: {symbol}")
                
            except Exception as e:
                logger.error(f"处理Gate.io公告失败: {str(e)}")
        
        logger.info(f"Gate.io新币上线监控完成，发现 {len(new_listings)} 个新币")
        return new_listings
        
    except Exception as e:
        logger.error(f"监控Gate.io新币上线失败: {str(e)}")
        return []

def fetch_binance_coin_details(symbol: str) -> Dict[str, Any]:
    """
    获取币安币种详细信息
    
    Args:
        symbol: 币种符号，如 'BTC'
        
    Returns:
        币种详细信息字典
    """
    try:
        # 获取币种详情
        params = {
            'assetCode': symbol
        }
        
        response = make_api_request(
            exchange='binance',
            endpoint=API_CONFIG['binance']['coin_info_url'],
            method='GET',
            params=params,
            use_base_url=True
        )
        
        if not response or 'data' not in response:
            logger.error(f"获取币安币种 {symbol} 详情失败")
            return {}
        
        coin_data = response['data']
        
        # 提取所需信息
        details = {
            'symbol': symbol,
            'name': coin_data.get('assetName', ''),
            'description': coin_data.get('description', ''),
            'website': '',
            'twitter': '',
            'telegram': '',
            'total_supply': coin_data.get('totalSupply', 0),
            'circulating_supply': coin_data.get('circulatingSupply', 0),
            'max_supply': coin_data.get('maxSupply', 0)
        }
        
        # 提取社交媒体链接
        for social in coin_data.get('socialMedia', []):
            if social.get('mediaType') == 'TWITTER':
                details['twitter'] = social.get('url', '')
            elif social.get('mediaType') == 'TELEGRAM':
                details['telegram'] = social.get('url', '')
            elif social.get('mediaType') == 'WEBSITE':
                details['website'] = social.get('url', '')
        
        return details
        
    except Exception as e:
        logger.error(f"获取币安币种 {symbol} 详情失败: {str(e)}")
        return {}

def fetch_gate_coin_details(symbol: str) -> Dict[str, Any]:
    """
    获取Gate.io币种详细信息
    
    Args:
        symbol: 币种符号，如 'BTC'
        
    Returns:
        币种详细信息字典
    """
    try:
        # 构建币种详情页URL
        coin_url = API_CONFIG['gate']['coin_info_url'].format(symbol=f"{symbol}_USDT")
        
        # 获取币种详情页
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get(
            coin_url,
            headers=headers,
            timeout=30
        )
        
        response.raise_for_status()
        
        # 解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 提取币种名称
        name = symbol
        name_elem = soup.select_one('.currency-title')
        if name_elem:
            name = name_elem.text.strip()
        
        # 提取币种描述
        description = ''
        desc_elem = soup.select_one('.currency-description')
        if desc_elem:
            description = desc_elem.text.strip()
        
        # 提取社交媒体链接
        website = ''
        twitter = ''
        telegram = ''
        
        social_links = soup.select('.social-link a')
        for link in social_links:
            href = link.get('href', '')
            if 'twitter.com' in href:
                twitter = href
            elif 't.me' in href or 'telegram.org' in href:
                telegram = href
            elif not href.startswith('https://www.gate.io'):
                website = href
        
        # 提取供应信息
        total_supply = 0
        circulating_supply = 0
        max_supply = 0
        
        supply_elems = soup.select('.currency-info-item')
        for elem in supply_elems:
            label = elem.select_one('.label')
            value = elem.select_one('.value')
            
            if not label or not value:
                continue
            
            label_text = label.text.strip()
            value_text = value.text.strip()
            
            if '总供应量' in label_text or 'Total Supply' in label_text:
                try:
                    total_supply = float(value_text.replace(',', ''))
                except:
                    pass
            elif '流通供应量' in label_text or 'Circulating Supply' in label_text:
                try:
                    circulating_supply = float(value_text.replace(',', ''))
                except:
                    pass
            elif '最大供应量' in label_text or 'Max Supply' in label_text:
                try:
                    max_supply = float(value_text.replace(',', ''))
                except:
                    pass
        
        return {
            'symbol': symbol,
            'name': name,
            'description': description,
            'website': website,
            'twitter': twitter,
            'telegram': telegram,
            'total_supply': total_supply,
            'circulating_supply': circulating_supply,
            'max_supply': max_supply
        }
        
    except Exception as e:
        logger.error(f"获取Gate.io币种 {symbol} 详情失败: {str(e)}")
        return {}

def monitor_new_listings() -> List[Dict[str, Any]]:
    """
    监控所有交易所的新币上线
    
    Returns:
        新币上线信息列表
    """
    all_new_listings = []
    
    # 监控币安新币上线
    binance_listings = monitor_binance_listings()
    all_new_listings.extend(binance_listings)
    
    # 监控Gate.io新币上线
    gate_listings = monitor_gate_listings()
    all_new_listings.extend(gate_listings)
    
    return all_new_listings

if __name__ == '__main__':
    # 测试代码
    new_listings = monitor_new_listings()
    print(f"发现 {len(new_listings)} 个新币上线")
    
    for listing in new_listings:
        print(f"{listing['exchange']} 上线 {listing['symbol']} ({listing['name']})")
        print(f"上线时间: {format_timestamp(listing['listing_time'])}")
        print(f"公告链接: {listing['announcement_url']}")
        print("-" * 50)
        
        # 获取币种详情
        if listing['exchange'] == 'binance':
            details = fetch_binance_coin_details(listing['symbol'])
        else:
            details = fetch_gate_coin_details(listing['symbol'])
        
        if details:
            print(f"币种名称: {details['name']}")
            print(f"币种描述: {details['description'][:100]}...")
            print(f"官网: {details['website']}")
            print(f"Twitter: {details['twitter']}")
            print(f"Telegram: {details['telegram']}")
            print("-" * 50)
