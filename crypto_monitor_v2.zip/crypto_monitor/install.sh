#!/bin/bash

# 加密货币监控脚本一键安装脚本
# 作者: Manus
# 日期: 2025-06-01

# 显示彩色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 显示欢迎信息
echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}    加密货币监控脚本一键安装程序    ${NC}"
echo -e "${GREEN}================================================${NC}"
echo ""

# 检查是否为root用户
check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo -e "${YELLOW}提示: 您当前不是以root用户运行此脚本。${NC}"
        echo -e "${YELLOW}某些操作可能需要sudo权限。${NC}"
        echo ""
    fi
}

# 检查系统环境
check_system() {
    echo -e "${GREEN}[1/7] 检查系统环境...${NC}"
    
    # 检查操作系统
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        echo -e "  - 操作系统: ${YELLOW}$OS $VER${NC}"
    else
        echo -e "  - 操作系统: ${YELLOW}未知${NC}"
    fi
    
    # 检查Python版本
    if command -v python3 &>/dev/null; then
        PYTHON_VER=$(python3 --version)
        echo -e "  - Python版本: ${YELLOW}$PYTHON_VER${NC}"
    else
        echo -e "  - ${RED}未检测到Python3，将尝试安装...${NC}"
        install_python
    fi
    
    # 检查pip
    if command -v pip3 &>/dev/null; then
        PIP_VER=$(pip3 --version | awk '{print $2}')
        echo -e "  - pip版本: ${YELLOW}$PIP_VER${NC}"
    else
        echo -e "  - ${RED}未检测到pip3，将尝试安装...${NC}"
        install_pip
    fi
    
    echo -e "${GREEN}系统环境检查完成!${NC}"
    echo ""
}

# 安装Python
install_python() {
    echo -e "${GREEN}[*] 正在安装Python3...${NC}"
    
    if [ -f /etc/debian_version ]; then
        # Debian/Ubuntu
        sudo apt-get update
        sudo apt-get install -y python3 python3-dev
    elif [ -f /etc/redhat-release ]; then
        # CentOS/RHEL
        sudo yum install -y python3 python3-devel
    elif [ -f /etc/arch-release ]; then
        # Arch Linux
        sudo pacman -S python
    elif [ -f /etc/SuSE-release ]; then
        # OpenSUSE
        sudo zypper install -y python3 python3-devel
    elif [ -f /etc/alpine-release ]; then
        # Alpine
        sudo apk add python3 python3-dev
    else
        echo -e "${RED}无法确定您的操作系统，请手动安装Python3后重试。${NC}"
        exit 1
    fi
    
    if command -v python3 &>/dev/null; then
        PYTHON_VER=$(python3 --version)
        echo -e "  - Python安装成功: ${YELLOW}$PYTHON_VER${NC}"
    else
        echo -e "${RED}Python3安装失败，请手动安装后重试。${NC}"
        exit 1
    fi
}

# 安装pip
install_pip() {
    echo -e "${GREEN}[*] 正在安装pip3...${NC}"
    
    if [ -f /etc/debian_version ]; then
        # Debian/Ubuntu
        sudo apt-get update
        sudo apt-get install -y python3-pip
    elif [ -f /etc/redhat-release ]; then
        # CentOS/RHEL
        sudo yum install -y python3-pip
    elif [ -f /etc/arch-release ]; then
        # Arch Linux
        sudo pacman -S python-pip
    elif [ -f /etc/SuSE-release ]; then
        # OpenSUSE
        sudo zypper install -y python3-pip
    elif [ -f /etc/alpine-release ]; then
        # Alpine
        sudo apk add py3-pip
    else
        # 通用方法
        curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
        python3 get-pip.py
        rm get-pip.py
    fi
    
    if command -v pip3 &>/dev/null; then
        PIP_VER=$(pip3 --version | awk '{print $2}')
        echo -e "  - pip安装成功: ${YELLOW}$PIP_VER${NC}"
    else
        echo -e "${RED}pip3安装失败，请手动安装后重试。${NC}"
        exit 1
    fi
}

# 创建虚拟环境
create_venv() {
    echo -e "${GREEN}[2/7] 创建Python虚拟环境...${NC}"
    
    # 检查venv模块
    if ! python3 -c "import venv" &>/dev/null; then
        echo -e "  - ${YELLOW}安装venv模块...${NC}"
        if [ -f /etc/debian_version ]; then
            sudo apt-get install -y python3-venv
        elif [ -f /etc/redhat-release ]; then
            sudo yum install -y python3-venv
        else
            pip3 install virtualenv
        fi
    fi
    
    # 创建虚拟环境
    if [ -d "venv" ]; then
        echo -e "  - ${YELLOW}检测到已存在的虚拟环境，将重新创建...${NC}"
        rm -rf venv
    fi
    
    python3 -m venv venv
    
    if [ -d "venv" ]; then
        echo -e "  - 虚拟环境创建成功: ${YELLOW}./venv${NC}"
    else
        echo -e "${RED}虚拟环境创建失败，将使用系统Python环境。${NC}"
    fi
    
    echo -e "${GREEN}虚拟环境创建完成!${NC}"
    echo ""
}

# 安装依赖
install_dependencies() {
    echo -e "${GREEN}[3/7] 安装依赖包...${NC}"
    
    # 激活虚拟环境
    if [ -d "venv" ]; then
        source venv/bin/activate
        echo -e "  - 已激活虚拟环境"
    fi
    
    # 升级pip
    echo -e "  - 升级pip..."
    pip3 install --upgrade pip
    
    # 安装依赖
    echo -e "  - 安装项目依赖..."
    if [ -f "requirements.txt" ]; then
        pip3 install -r requirements.txt
        
        if [ $? -eq 0 ]; then
            echo -e "  - ${GREEN}依赖安装成功!${NC}"
        else
            echo -e "  - ${RED}部分依赖安装失败，请查看上方错误信息。${NC}"
            echo -e "  - ${YELLOW}您可以稍后手动运行: pip3 install -r requirements.txt${NC}"
        fi
    else
        echo -e "  - ${RED}未找到requirements.txt文件，无法安装依赖。${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}依赖安装完成!${NC}"
    echo ""
}

# 配置脚本
configure_script() {
    echo -e "${GREEN}[4/7] 配置脚本...${NC}"
    
    # 检查配置文件
    if [ -f "config.py" ]; then
        echo -e "  - 检测到配置文件: ${YELLOW}config.py${NC}"
        echo -e "  - ${YELLOW}请在安装完成后手动编辑config.py文件，设置API密钥和Telegram配置。${NC}"
    else
        echo -e "  - ${RED}未找到config.py文件，脚本可能无法正常运行。${NC}"
    fi
    
    # 创建数据目录
    if [ ! -d "data" ]; then
        mkdir -p data
        echo -e "  - 已创建数据目录: ${YELLOW}./data${NC}"
    fi
    
    # 设置权限
    chmod +x main.py
    echo -e "  - 已设置执行权限"
    
    echo -e "${GREEN}脚本配置完成!${NC}"
    echo ""
}

# 创建启动脚本
create_startup_script() {
    echo -e "${GREEN}[5/7] 创建启动脚本...${NC}"
    
    # 创建启动脚本
    cat > start.sh << 'EOF'
#!/bin/bash
# 加密货币监控脚本启动程序

# 检查虚拟环境
if [ -d "venv" ]; then
    source venv/bin/activate
    echo "已激活虚拟环境"
fi

# 启动脚本
echo "正在启动加密货币监控脚本..."
python3 main.py "$@"
EOF
    
    # 创建后台运行脚本
    cat > start_daemon.sh << 'EOF'
#!/bin/bash
# 加密货币监控脚本后台启动程序

# 检查虚拟环境
if [ -d "venv" ]; then
    source venv/bin/activate
    echo "已激活虚拟环境"
fi

# 检查日志目录
if [ ! -d "logs" ]; then
    mkdir -p logs
    echo "已创建日志目录"
fi

# 启动脚本
echo "正在后台启动加密货币监控脚本..."
nohup python3 main.py > logs/crypto_monitor.log 2>&1 &

# 显示进程ID
PID=$!
echo "脚本已在后台启动，进程ID: $PID"
echo "可以通过以下命令查看日志:"
echo "  tail -f logs/crypto_monitor.log"
echo "可以通过以下命令停止脚本:"
echo "  kill $PID"

# 保存进程ID
echo $PID > .pid
EOF
    
    # 创建停止脚本
    cat > stop.sh << 'EOF'
#!/bin/bash
# 加密货币监控脚本停止程序

if [ -f .pid ]; then
    PID=$(cat .pid)
    if ps -p $PID > /dev/null; then
        echo "正在停止进程 $PID..."
        kill $PID
        rm .pid
        echo "已停止加密货币监控脚本"
    else
        echo "进程 $PID 不存在，可能已经停止"
        rm .pid
    fi
else
    echo "未找到进程ID文件，尝试查找并停止所有相关进程..."
    pkill -f "python3 main.py"
    echo "已尝试停止所有加密货币监控脚本进程"
fi
EOF
    
    # 设置执行权限
    chmod +x start.sh
    chmod +x start_daemon.sh
    chmod +x stop.sh
    
    echo -e "  - 已创建启动脚本: ${YELLOW}./start.sh${NC}"
    echo -e "  - 已创建后台启动脚本: ${YELLOW}./start_daemon.sh${NC}"
    echo -e "  - 已创建停止脚本: ${YELLOW}./stop.sh${NC}"
    
    echo -e "${GREEN}启动脚本创建完成!${NC}"
    echo ""
}

# 测试安装
test_installation() {
    echo -e "${GREEN}[6/7] 测试安装...${NC}"
    
    # 激活虚拟环境
    if [ -d "venv" ]; then
        source venv/bin/activate
    fi
    
    # 测试Python导入
    echo -e "  - 测试Python依赖导入..."
    python3 -c "
import sys
try:
    import requests
    import bs4
    import telegram
    import sqlite3
    print('  - 依赖导入测试通过')
except ImportError as e:
    print(f'  - 依赖导入测试失败: {e}')
    sys.exit(1)
"
    
    if [ $? -ne 0 ]; then
        echo -e "  - ${RED}依赖测试失败，请检查安装日志。${NC}"
    else
        echo -e "  - ${GREEN}依赖测试通过!${NC}"
    fi
    
    echo -e "${GREEN}安装测试完成!${NC}"
    echo ""
}

# 显示使用说明
show_instructions() {
    echo -e "${GREEN}[7/7] 安装完成!${NC}"
    echo ""
    echo -e "${YELLOW}使用说明:${NC}"
    echo -e "  1. 编辑 ${YELLOW}config.py${NC} 文件，配置您的API密钥和Telegram设置"
    echo -e "  2. 使用以下命令启动脚本:"
    echo -e "     ${YELLOW}./start.sh${NC} - 前台运行"
    echo -e "     ${YELLOW}./start_daemon.sh${NC} - 后台运行"
    echo -e "  3. 使用以下命令停止脚本:"
    echo -e "     ${YELLOW}./stop.sh${NC}"
    echo ""
    echo -e "  测试模式 (单次运行):"
    echo -e "     ${YELLOW}./start.sh --test${NC}"
    echo ""
    echo -e "  查看日志:"
    echo -e "     ${YELLOW}tail -f logs/crypto_monitor.log${NC}"
    echo ""
    echo -e "${GREEN}感谢使用加密货币监控脚本!${NC}"
    echo -e "${GREEN}================================================${NC}"
}

# 主函数
main() {
    check_root
    check_system
    create_venv
    install_dependencies
    configure_script
    create_startup_script
    test_installation
    show_instructions
}

# 执行主函数
main
