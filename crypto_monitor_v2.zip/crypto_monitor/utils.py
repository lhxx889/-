#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
工具函数模块，提供API请求、轮换策略和通用功能
"""

import time
import random
import logging
import requests
import json
import sqlite3
import hashlib
import hmac
from datetime import datetime
from typing import Dict, List, Tuple, Any, Optional, Union
from urllib.parse import urlencode
from requests.exceptions import RequestException, Timeout, ConnectionError

from config import (
    API_CONFIG, TELEGRAM_CONFIG, MONITOR_CONFIG, 
    USER_AGENTS, PROXY_CONFIG, LOG_CONFIG
)

# 设置日志
def setup_logger():
    """配置并返回日志记录器"""
    logger = logging.getLogger('crypto_monitor')
    logger.setLevel(getattr(logging, LOG_CONFIG['log_level']))
    
    # 文件处理器
    from logging.handlers import RotatingFileHandler
    file_handler = RotatingFileHandler(
        LOG_CONFIG['log_file'],
        maxBytes=LOG_CONFIG['max_log_size'],
        backupCount=LOG_CONFIG['backup_count']
    )
    file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_format)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_format = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_format)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

logger = setup_logger()

# API请求计数器
api_request_counters = {
    'binance': 0,
    'gate': 0
}

# Telegram消息计数器
telegram_message_counter = 0

# 当前使用的API密钥索引
current_api_key_indices = {
    'binance': 0,
    'gate': 0
}

# 当前使用的Telegram机器人索引
current_telegram_bot_index = 0

# 当前使用的代理索引
current_proxy_index = 0

# 当前使用的User-Agent索引
current_user_agent_index = 0

def get_current_api_key(exchange: str) -> Tuple[str, str]:
    """获取当前交易所的API密钥"""
    keys = API_CONFIG[exchange]['api_keys']
    if not keys:
        logger.warning(f"{exchange}没有配置API密钥")
        return ('', '')
    
    index = current_api_key_indices[exchange]
    return keys[index]

def rotate_api_key(exchange: str) -> None:
    """轮换交易所API密钥"""
    keys = API_CONFIG[exchange]['api_keys']
    if not keys:
        return
    
    current_api_key_indices[exchange] = (current_api_key_indices[exchange] + 1) % len(keys)
    logger.debug(f"已轮换{exchange} API密钥到索引 {current_api_key_indices[exchange]}")

def get_current_telegram_bot() -> Dict[str, Any]:
    """获取当前Telegram机器人配置"""
    bots = TELEGRAM_CONFIG['bots']
    if not bots:
        logger.warning("没有配置Telegram机器人")
        return {'token': '', 'chat_ids': []}
    
    return bots[current_telegram_bot_index]

def rotate_telegram_bot() -> None:
    """轮换Telegram机器人"""
    global telegram_message_counter, current_telegram_bot_index
    
    bots = TELEGRAM_CONFIG['bots']
    if not bots:
        return
    
    telegram_message_counter += 1
    
    if telegram_message_counter >= TELEGRAM_CONFIG['rotation_interval']:
        current_telegram_bot_index = (current_telegram_bot_index + 1) % len(bots)
        telegram_message_counter = 0
        logger.debug(f"已轮换Telegram机器人到索引 {current_telegram_bot_index}")

def get_current_proxy() -> Dict[str, str]:
    """获取当前代理服务器"""
    if not PROXY_CONFIG['enabled'] or not PROXY_CONFIG['proxies']:
        return {}
    
    return PROXY_CONFIG['proxies'][current_proxy_index]

def rotate_proxy() -> None:
    """轮换代理服务器"""
    global current_proxy_index
    
    if not PROXY_CONFIG['enabled'] or not PROXY_CONFIG['proxies']:
        return
    
    current_proxy_index = (current_proxy_index + 1) % len(PROXY_CONFIG['proxies'])
    logger.debug(f"已轮换代理服务器到索引 {current_proxy_index}")

def get_current_user_agent() -> str:
    """获取当前User-Agent"""
    return USER_AGENTS[current_user_agent_index]

def rotate_user_agent() -> None:
    """轮换User-Agent"""
    global current_user_agent_index
    
    current_user_agent_index = (current_user_agent_index + 1) % len(USER_AGENTS)
    logger.debug(f"已轮换User-Agent到索引 {current_user_agent_index}")

def make_api_request(
    exchange: str,
    endpoint: str,
    method: str = 'GET',
    params: Dict = None,
    data: Dict = None,
    headers: Dict = None,
    auth_required: bool = False,
    use_base_url: bool = True,
    timeout: int = 30
) -> Dict:
    """
    发送API请求并处理轮换逻辑
    
    Args:
        exchange: 交易所名称 ('binance' 或 'gate')
        endpoint: API端点
        method: 请求方法 ('GET', 'POST', 等)
        params: URL参数
        data: 请求体数据
        headers: 请求头
        auth_required: 是否需要认证
        use_base_url: 是否使用基础URL
        timeout: 请求超时时间(秒)
        
    Returns:
        API响应(字典)
    """
    global api_request_counters
    
    # 增加请求计数
    api_request_counters[exchange] += 1
    
    # 检查是否需要轮换API密钥
    if api_request_counters[exchange] >= MONITOR_CONFIG['rotation_strategy']['api_rotation_count']:
        rotate_api_key(exchange)
        api_request_counters[exchange] = 0
    
    # 准备请求URL
    if use_base_url:
        url = f"{API_CONFIG[exchange]['base_url']}{endpoint}"
    else:
        url = endpoint
    
    # 准备请求头
    if headers is None:
        headers = {}
    
    # 添加User-Agent
    if MONITOR_CONFIG['rotation_strategy']['user_agent_rotation']:
        headers['User-Agent'] = get_current_user_agent()
        rotate_user_agent()
    
    # 添加认证信息
    if auth_required:
        api_key, api_secret = get_current_api_key(exchange)
        
        if exchange == 'binance':
            # 币安API认证
            headers['X-MBX-APIKEY'] = api_key
            
            if params is None:
                params = {}
            
            # 添加时间戳
            params['timestamp'] = int(time.time() * 1000)
            
            # 生成签名
            query_string = urlencode(params)
            signature = hmac.new(
                api_secret.encode('utf-8'),
                query_string.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()
            
            params['signature'] = signature
            
        elif exchange == 'gate':
            # Gate.io API认证
            timestamp = int(time.time())
            
            if method == 'GET':
                sign_str = ''
                if params:
                    sign_str = urlencode(sorted(params.items()))
                signature_payload = f"{method}\n{endpoint}\n{sign_str}\n{timestamp}"
            else:
                body = ''
                if data:
                    body = json.dumps(data)
                signature_payload = f"{method}\n{endpoint}\n\n{body}\n{timestamp}"
            
            signature = hmac.new(
                api_secret.encode('utf-8'),
                signature_payload.encode('utf-8'),
                hashlib.sha512
            ).hexdigest()
            
            headers.update({
                'KEY': api_key,
                'SIGN': signature,
                'Timestamp': str(timestamp),
                'Content-Type': 'application/json'
            })
    
    # 获取代理
    proxies = get_current_proxy() if PROXY_CONFIG['enabled'] else None
    
    # 发送请求
    for attempt in range(MONITOR_CONFIG['max_retries']):
        try:
            response = requests.request(
                method=method,
                url=url,
                params=params,
                json=data,
                headers=headers,
                proxies=proxies,
                timeout=timeout
            )
            
            # 检查响应状态
            response.raise_for_status()
            
            # 解析JSON响应
            result = response.json()
            
            # 轮换代理(如果启用)
            if PROXY_CONFIG['enabled'] and api_request_counters[exchange] % PROXY_CONFIG['rotation_interval'] == 0:
                rotate_proxy()
            
            return result
            
        except (RequestException, Timeout, ConnectionError, ValueError) as e:
            logger.warning(f"{exchange} API请求失败(尝试 {attempt+1}/{MONITOR_CONFIG['max_retries']}): {str(e)}")
            
            # 如果不是最后一次尝试，则等待后重试
            if attempt < MONITOR_CONFIG['max_retries'] - 1:
                time.sleep(MONITOR_CONFIG['retry_delay'])
                
                # 轮换API密钥和代理
                rotate_api_key(exchange)
                if PROXY_CONFIG['enabled']:
                    rotate_proxy()
    
    # 所有尝试都失败
    logger.error(f"{exchange} API请求失败，已达到最大重试次数")
    return {}

def send_telegram_message(message: str) -> bool:
    """
    发送Telegram消息
    
    Args:
        message: 要发送的消息文本(支持Markdown格式)
        
    Returns:
        是否发送成功
    """
    bot = get_current_telegram_bot()
    
    if not bot['token'] or not bot['chat_ids']:
        logger.error("未配置Telegram机器人或聊天ID")
        return False
    
    success = True
    
    for chat_id in bot['chat_ids']:
        try:
            url = f"https://api.telegram.org/bot{bot['token']}/sendMessage"
            payload = {
                'chat_id': chat_id,
                'text': message,
                'parse_mode': 'Markdown',
                'disable_web_page_preview': True
            }
            
            response = requests.post(url, json=payload, timeout=30)
            response.raise_for_status()
            
            logger.info(f"已成功发送Telegram消息到聊天ID {chat_id}")
            
        except Exception as e:
            logger.error(f"发送Telegram消息失败: {str(e)}")
            success = False
    
    # 轮换Telegram机器人
    rotate_telegram_bot()
    
    return success

def init_database():
    """初始化SQLite数据库"""
    conn = sqlite3.connect(STORAGE_CONFIG['db_file'])
    cursor = conn.cursor()
    
    # 创建币种价格表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS coin_prices (
        symbol TEXT PRIMARY KEY,
        exchange TEXT,
        price REAL,
        price_change_24h REAL,
        volume_24h REAL,
        market_cap REAL,
        last_updated INTEGER
    )
    ''')
    
    # 创建新币上线表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS new_listings (
        id TEXT PRIMARY KEY,
        exchange TEXT,
        symbol TEXT,
        name TEXT,
        listing_time INTEGER,
        initial_price REAL,
        announcement_url TEXT,
        processed INTEGER DEFAULT 0,
        created_at INTEGER
    )
    ''')
    
    # 创建价格预警记录表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS price_alerts (
        id TEXT PRIMARY KEY,
        exchange TEXT,
        symbol TEXT,
        price REAL,
        price_change_24h REAL,
        alert_type TEXT,
        processed INTEGER DEFAULT 0,
        created_at INTEGER
    )
    ''')
    
    # 创建币种详情缓存表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS coin_details (
        symbol TEXT PRIMARY KEY,
        name TEXT,
        description TEXT,
        website TEXT,
        twitter TEXT,
        telegram TEXT,
        total_supply REAL,
        circulating_supply REAL,
        max_supply REAL,
        last_updated INTEGER
    )
    ''')
    
    conn.commit()
    conn.close()
    
    logger.info("数据库初始化完成")

def get_db_connection():
    """获取数据库连接"""
    return sqlite3.connect(STORAGE_CONFIG['db_file'])

def save_coin_price(
    exchange: str,
    symbol: str,
    price: float,
    price_change_24h: float,
    volume_24h: float,
    market_cap: float
):
    """保存币种价格信息到数据库"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    now = int(time.time())
    
    cursor.execute('''
    INSERT OR REPLACE INTO coin_prices
    (symbol, exchange, price, price_change_24h, volume_24h, market_cap, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (symbol, exchange, price, price_change_24h, volume_24h, market_cap, now))
    
    conn.commit()
    conn.close()

def save_new_listing(
    exchange: str,
    symbol: str,
    name: str,
    listing_time: int,
    initial_price: float,
    announcement_url: str
):
    """保存新币上线信息到数据库"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    now = int(time.time())
    listing_id = f"{exchange}_{symbol}_{listing_time}"
    
    cursor.execute('''
    INSERT OR IGNORE INTO new_listings
    (id, exchange, symbol, name, listing_time, initial_price, announcement_url, processed, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
    ''', (listing_id, exchange, symbol, name, listing_time, initial_price, announcement_url, now))
    
    conn.commit()
    conn.close()
    
    return cursor.rowcount > 0

def save_price_alert(
    exchange: str,
    symbol: str,
    price: float,
    price_change_24h: float,
    alert_type: str
):
    """保存价格预警信息到数据库"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    now = int(time.time())
    alert_id = f"{exchange}_{symbol}_{now}"
    
    cursor.execute('''
    INSERT INTO price_alerts
    (id, exchange, symbol, price, price_change_24h, alert_type, processed, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 0, ?)
    ''', (alert_id, exchange, symbol, price, price_change_24h, alert_type, now))
    
    conn.commit()
    conn.close()
    
    return alert_id

def save_coin_details(
    symbol: str,
    name: str,
    description: str,
    website: str,
    twitter: str,
    telegram: str,
    total_supply: float = None,
    circulating_supply: float = None,
    max_supply: float = None
):
    """保存币种详情到数据库"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    now = int(time.time())
    
    cursor.execute('''
    INSERT OR REPLACE INTO coin_details
    (symbol, name, description, website, twitter, telegram, 
     total_supply, circulating_supply, max_supply, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        symbol, name, description, website, twitter, telegram,
        total_supply, circulating_supply, max_supply, now
    ))
    
    conn.commit()
    conn.close()

def get_unprocessed_price_alerts(limit: int = 10):
    """获取未处理的价格预警"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT id, exchange, symbol, price, price_change_24h, alert_type, created_at
    FROM price_alerts
    WHERE processed = 0
    ORDER BY created_at ASC
    LIMIT ?
    ''', (limit,))
    
    alerts = cursor.fetchall()
    conn.close()
    
    return alerts

def get_unprocessed_new_listings(limit: int = 10):
    """获取未处理的新币上线信息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT id, exchange, symbol, name, listing_time, initial_price, announcement_url, created_at
    FROM new_listings
    WHERE processed = 0
    ORDER BY listing_time ASC
    LIMIT ?
    ''', (limit,))
    
    listings = cursor.fetchall()
    conn.close()
    
    return listings

def mark_price_alert_processed(alert_id: str):
    """标记价格预警为已处理"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
    UPDATE price_alerts
    SET processed = 1
    WHERE id = ?
    ''', (alert_id,))
    
    conn.commit()
    conn.close()

def mark_new_listing_processed(listing_id: str):
    """标记新币上线为已处理"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
    UPDATE new_listings
    SET processed = 1
    WHERE id = ?
    ''', (listing_id,))
    
    conn.commit()
    conn.close()

def get_coin_details(symbol: str):
    """从数据库获取币种详情"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT symbol, name, description, website, twitter, telegram,
           total_supply, circulating_supply, max_supply, last_updated
    FROM coin_details
    WHERE symbol = ?
    ''', (symbol,))
    
    details = cursor.fetchone()
    conn.close()
    
    if details:
        # 检查缓存是否过期
        now = int(time.time())
        if now - details[9] > STORAGE_CONFIG['cache_expire']:
            return None
        
        return {
            'symbol': details[0],
            'name': details[1],
            'description': details[2],
            'website': details[3],
            'twitter': details[4],
            'telegram': details[5],
            'total_supply': details[6],
            'circulating_supply': details[7],
            'max_supply': details[8],
            'last_updated': details[9]
        }
    
    return None

def format_number(num: float, precision: int = 2) -> str:
    """格式化数字，添加千位分隔符"""
    if num is None:
        return "N/A"
    
    if num >= 1_000_000_000:
        return f"{num / 1_000_000_000:.{precision}f}B"
    elif num >= 1_000_000:
        return f"{num / 1_000_000:.{precision}f}M"
    elif num >= 1_000:
        return f"{num / 1_000:.{precision}f}K"
    else:
        return f"{num:.{precision}f}"

def format_timestamp(timestamp: int, format_str: str = '%Y-%m-%d %H:%M:%S') -> str:
    """格式化时间戳为可读字符串"""
    return datetime.fromtimestamp(timestamp).strftime(format_str)
