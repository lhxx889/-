# Gate加密货币监控脚本使用说明

## 项目简介

Gate加密货币监控脚本是一个功能强大的工具，用于实时监控Gate交易所上的加密货币价格波动。当币种价格出现大幅波动（默认30%-50%）时，脚本会自动分析波动原因，并将分析结果推送到Telegram和邮箱。

### 主要功能

- 实时监控Gate交易所上所有币种的价格变化
- 自动分析价格波动原因，包括社交媒体信息抓取和分析
- 支持Telegram和邮箱推送
- 支持自定义监控间隔、涨跌幅阈值和监控币种
- 支持一键安装所有依赖
- 支持启动、停止和状态查看等控制功能

## 安装说明

### 系统要求

- Linux操作系统
- Python 3.6或更高版本
- 网络连接

### 安装步骤

1. 下载脚本包并解压
2. 进入脚本目录
3. 执行安装脚本

```bash
chmod +x install.sh
./install.sh
```

安装脚本会自动执行以下操作：
- 检查系统环境
- 安装系统依赖
- 创建Python虚拟环境
- 安装所有Python依赖
- 创建默认配置文件
- 创建启动脚本

## 配置说明

安装完成后，需要编辑`config.yaml`文件，配置Telegram和邮箱推送信息：

```yaml
# 监控设置
monitoring:
  interval: 60  # 监控间隔（秒）
  threshold:
    min: 30  # 最小涨跌幅阈值（%）
    max: 50  # 最大涨跌幅阈值（%）
  coins: []  # 空列表表示监控所有币种，否则只监控指定币种

# 推送设置
notification:
  telegram:
    enabled: true
    bot_token: "YOUR_BOT_TOKEN"  # Telegram Bot Token
    chat_id: "YOUR_CHAT_ID"      # Telegram Chat ID
  email:
    enabled: true
    smtp_server: "smtp.example.com"  # SMTP服务器
    smtp_port: 587                   # SMTP端口
    username: "your_email@example.com"  # 邮箱用户名
    password: "your_password"           # 邮箱密码
    recipients:                         # 接收邮件的邮箱列表
      - "recipient1@example.com"
      - "recipient2@example.com"

# 数据存储设置
storage:
  data_dir: "./data"  # 数据存储目录
  log_dir: "./logs"   # 日志存储目录
```

### Telegram配置说明

1. 在Telegram中搜索`@BotFather`并开始对话
2. 发送`/newbot`命令创建新机器人
3. 按照提示设置机器人名称和用户名
4. 获取Bot Token并填入配置文件
5. 在Telegram中搜索并启动你创建的机器人
6. 发送任意消息给机器人
7. 访问`https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`获取Chat ID
8. 将Chat ID填入配置文件

### 邮箱配置说明

1. 填写SMTP服务器地址和端口
   - Gmail: smtp.gmail.com, 端口587
   - Outlook: smtp.office365.com, 端口587
   - QQ邮箱: smtp.qq.com, 端口587
2. 填写邮箱用户名和密码（对于Gmail和QQ邮箱，需要使用应用专用密码）
3. 填写接收通知的邮箱地址列表

## 使用说明

### 基本命令

```bash
# 启动监控
./start.sh --start

# 停止监控
./start.sh --stop

# 查看监控状态
./start.sh --status

# 测试推送功能
./start.sh --test

# 执行一次监控
./start.sh --once
```

### 自定义设置

```bash
# 设置最小涨跌幅阈值（百分比）
./start.sh --min 30

# 设置最大涨跌幅阈值（百分比）
./start.sh --max 50

# 设置监控间隔（秒）
./start.sh --interval 60

# 设置监控币种（逗号分隔）
./start.sh --coins BTC,ETH,DOGE
```

### 组合使用

```bash
# 设置参数并启动监控
./start.sh --min 25 --max 45 --interval 120 --coins BTC,ETH --start

# 测试推送后启动监控
./start.sh --test --start
```

## 目录结构

```
gate_crypto_monitor/
├── install.sh                # 一键安装脚本
├── start.sh                  # 启动脚本
├── main.py                   # 主程序入口
├── config.yaml               # 配置文件
├── requirements.txt          # Python依赖列表
├── modules/                  # 功能模块目录
│   ├── __init__.py
│   ├── data_collector.py     # 数据采集模块
│   ├── info_scraper.py       # 信息抓取模块
│   ├── analyzer.py           # 分析模块
│   ├── notifier.py           # 推送模块
│   └── controller.py         # 控制模块
├── utils/                    # 工具包目录
│   ├── __init__.py
│   └── api.py                # API工具
├── data/                     # 数据存储目录
└── logs/                     # 日志存储目录
```

## 常见问题

1. **Q: 安装脚本执行失败怎么办？**
   A: 检查是否有执行权限，确保系统满足要求，尝试手动安装依赖。

2. **Q: 推送测试失败怎么办？**
   A: 检查配置文件中的Telegram Bot Token和Chat ID是否正确，邮箱配置是否正确。

3. **Q: 如何查看日志？**
   A: 日志文件保存在`logs`目录下，可以使用`cat`或`less`命令查看。

4. **Q: 如何添加更多币种？**
   A: 在配置文件中的`coins`列表中添加币种代码，或使用`--coins`参数指定。

5. **Q: 如何在后台运行？**
   A: 使用`nohup ./start.sh --start &`命令在后台运行。

## 注意事项

- 本脚本仅供参考，不构成投资建议
- 请勿频繁修改监控间隔，以免触发API限制
- 定期检查日志文件大小，避免占用过多磁盘空间
- 敏感信息（如邮箱密码）请妥善保管

## 更新日志

### 版本 1.0.0 (2025-05-27)
- 初始版本发布
- 支持实时监控Gate交易所币种价格
- 支持自动分析价格波动原因
- 支持Telegram和邮箱推送
- 支持自定义监控参数
- 提供一键安装脚本
