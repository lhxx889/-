"""
API工具模块，用于与Gate API交互
"""
import requests
import time
import logging
from typing import Dict, List, Any, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/api.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("gate_api")

class GateAPI:
    """Gate交易所API封装类"""
    
    BASE_URL = "https://api.gateio.ws/api/v4"
    
    def __init__(self):
        """初始化API客户端"""
        self.session = requests.Session()
        self.rate_limit_remaining = 100
        self.rate_limit_reset = 0
        
    def _handle_rate_limit(self):
        """处理API速率限制"""
        if self.rate_limit_remaining <= 5:
            sleep_time = max(0, self.rate_limit_reset - time.time())
            if sleep_time > 0:
                logger.info(f"API速率限制即将达到，等待 {sleep_time:.2f} 秒")
                time.sleep(sleep_time + 1)  # 额外等待1秒以确保安全
    
    def _update_rate_limit(self, headers: Dict):
        """从响应头更新速率限制信息"""
        if 'X-RateLimit-Remaining' in headers:
            self.rate_limit_remaining = int(headers['X-RateLimit-Remaining'])
        if 'X-RateLimit-Reset' in headers:
            self.rate_limit_reset = int(headers['X-RateLimit-Reset'])
    
    def _make_request(self, endpoint: str, params: Optional[Dict] = None) -> Dict:
        """
        发送API请求并处理响应
        
        Args:
            endpoint: API端点
            params: 请求参数
            
        Returns:
            API响应数据
        """
        url = f"{self.BASE_URL}{endpoint}"
        self._handle_rate_limit()
        
        try:
            response = self.session.get(url, params=params)
            self._update_rate_limit(response.headers)
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求失败: {e}")
            if hasattr(e.response, 'text'):
                logger.error(f"响应内容: {e.response.text}")
            raise
    
    def get_tickers(self) -> List[Dict[str, Any]]:
        """
        获取所有交易对的24小时行情数据
        
        Returns:
            所有交易对的行情数据列表
        """
        logger.info("获取所有交易对行情数据")
        return self._make_request("/spot/tickers")
    
    def get_currency_pairs(self) -> List[Dict[str, Any]]:
        """
        获取所有交易对信息
        
        Returns:
            所有交易对信息列表
        """
        logger.info("获取所有交易对信息")
        return self._make_request("/spot/currency_pairs")
    
    def get_currency_detail(self, currency: str) -> Dict[str, Any]:
        """
        获取特定币种的详细信息
        
        Args:
            currency: 币种代码，如BTC
            
        Returns:
            币种详细信息
        """
        logger.info(f"获取币种 {currency} 的详细信息")
        return self._make_request(f"/spot/currencies/{currency}")
    
    def get_market_info(self, currency_pair: str) -> Dict[str, Any]:
        """
        获取特定交易对的市场信息
        
        Args:
            currency_pair: 交易对，如BTC_USDT
            
        Returns:
            交易对市场信息
        """
        logger.info(f"获取交易对 {currency_pair} 的市场信息")
        return self._make_request(f"/spot/currency_pairs/{currency_pair}")
