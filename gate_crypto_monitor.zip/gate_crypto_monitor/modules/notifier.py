"""
推送模块，负责将分析结果推送到Telegram和邮箱
"""
import logging
import json
import os
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Any, Optional
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/notifier.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("notifier")

class Notifier:
    """通知推送类，负责将分析结果推送到Telegram和邮箱"""
    
    def __init__(self, config_file: str = "../config.yaml"):
        """
        初始化通知推送器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.data_dir = self.config.get('storage', {}).get('data_dir', '../data')
        self.notification_dir = os.path.join(self.data_dir, "notifications")
        
        # 确保数据目录存在
        os.makedirs(self.notification_dir, exist_ok=True)
        
        # 已推送的消息ID集合，用于去重
        self.sent_message_ids = set()
        self._load_sent_messages()
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        try:
            import yaml
            with open(self.config_file, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            # 返回默认配置
            return {
                'notification': {
                    'telegram': {
                        'enabled': False,
                        'bot_token': '',
                        'chat_id': ''
                    },
                    'email': {
                        'enabled': False,
                        'smtp_server': '',
                        'smtp_port': 587,
                        'username': '',
                        'password': '',
                        'recipients': []
                    }
                },
                'storage': {
                    'data_dir': '../data',
                    'log_dir': '../logs'
                }
            }
    
    def _load_sent_messages(self):
        """加载已发送的消息ID"""
        sent_file = os.path.join(self.notification_dir, "sent_messages.json")
        if os.path.exists(sent_file):
            try:
                with open(sent_file, 'r') as f:
                    self.sent_message_ids = set(json.load(f))
                logger.info(f"已加载 {len(self.sent_message_ids)} 个已发送消息ID")
            except Exception as e:
                logger.error(f"加载已发送消息ID失败: {e}")
    
    def _save_sent_messages(self):
        """保存已发送的消息ID"""
        sent_file = os.path.join(self.notification_dir, "sent_messages.json")
        try:
            with open(sent_file, 'w') as f:
                json.dump(list(self.sent_message_ids), f)
            logger.info(f"已保存 {len(self.sent_message_ids)} 个已发送消息ID")
        except Exception as e:
            logger.error(f"保存已发送消息ID失败: {e}")
    
    def _generate_message_id(self, analysis: Dict[str, Any]) -> str:
        """
        生成消息唯一ID，用于去重
        
        Args:
            analysis: 分析结果
            
        Returns:
            消息唯一ID
        """
        currency_pair = analysis.get('currency_pair', '')
        change_percentage = analysis.get('change_percentage', 0)
        # 取整数部分作为ID的一部分，避免浮点数精度问题
        change_int = int(change_percentage)
        timestamp = datetime.now().strftime("%Y%m%d")
        
        return f"{currency_pair}_{change_int}_{timestamp}"
    
    def format_message(self, analysis: Dict[str, Any], html: bool = False) -> str:
        """
        格式化消息内容
        
        Args:
            analysis: 分析结果
            html: 是否使用HTML格式
            
        Returns:
            格式化后的消息内容
        """
        currency_pair = analysis.get('currency_pair', '')
        change_percentage = analysis.get('change_percentage', 0)
        direction = analysis.get('direction', '')
        summary = analysis.get('summary', '')
        factors = analysis.get('factors', [])
        confidence = analysis.get('confidence', 'medium')
        
        # 转换置信度为中文
        confidence_text = {
            'high': '高',
            'medium': '中',
            'low': '低'
        }.get(confidence, '中')
        
        if html:
            # HTML格式
            message = f"""
            <h2>🚨 加密货币价格波动提醒</h2>
            <p><b>交易对:</b> {currency_pair}</p>
            <p><b>24小时{direction}幅度:</b> <span style="color:{'green' if change_percentage > 0 else 'red'}">{abs(change_percentage):.2f}%</span></p>
            <p><b>波动摘要:</b> {summary}</p>
            <p><b>可能原因:</b></p>
            <ul>
            """
            
            for factor in factors:
                message += f"<li>{factor}</li>"
            
            message += f"""
            </ul>
            <p><b>分析置信度:</b> {confidence_text}</p>
            <p><small>此消息由Gate加密货币监控脚本自动生成，仅供参考，不构成投资建议。</small></p>
            """
        else:
            # 纯文本格式
            message = f"""
🚨 加密货币价格波动提醒

交易对: {currency_pair}
24小时{direction}幅度: {abs(change_percentage):.2f}%

波动摘要: 
{summary}

可能原因:
"""
            
            for factor in factors:
                message += f"- {factor}\n"
            
            message += f"""
分析置信度: {confidence_text}

此消息由Gate加密货币监控脚本自动生成，仅供参考，不构成投资建议。
"""
        
        return message
    
    def send_telegram(self, analysis: Dict[str, Any]) -> bool:
        """
        发送Telegram消息
        
        Args:
            analysis: 分析结果
            
        Returns:
            是否发送成功
        """
        # 检查Telegram是否启用
        telegram_config = self.config.get('notification', {}).get('telegram', {})
        if not telegram_config.get('enabled', False):
            logger.info("Telegram推送未启用")
            return False
        
        # 获取配置
        bot_token = telegram_config.get('bot_token', '')
        chat_id = telegram_config.get('chat_id', '')
        
        if not bot_token or not chat_id:
            logger.error("Telegram配置不完整")
            return False
        
        # 生成消息ID并检查是否已发送
        message_id = self._generate_message_id(analysis)
        if message_id in self.sent_message_ids:
            logger.info(f"消息 {message_id} 已发送，跳过")
            return True
        
        # 格式化消息
        message = self.format_message(analysis, html=True)
        
        # 发送消息
        try:
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': chat_id,
                'text': message,
                'parse_mode': 'HTML'
            }
            
            response = requests.post(url, data=data)
            response.raise_for_status()
            
            # 记录已发送消息
            self.sent_message_ids.add(message_id)
            self._save_sent_messages()
            
            logger.info(f"Telegram消息发送成功: {message_id}")
            return True
        except Exception as e:
            logger.error(f"Telegram消息发送失败: {e}")
            return False
    
    def send_email(self, analysis: Dict[str, Any]) -> bool:
        """
        发送邮件
        
        Args:
            analysis: 分析结果
            
        Returns:
            是否发送成功
        """
        # 检查邮件是否启用
        email_config = self.config.get('notification', {}).get('email', {})
        if not email_config.get('enabled', False):
            logger.info("邮件推送未启用")
            return False
        
        # 获取配置
        smtp_server = email_config.get('smtp_server', '')
        smtp_port = email_config.get('smtp_port', 587)
        username = email_config.get('username', '')
        password = email_config.get('password', '')
        recipients = email_config.get('recipients', [])
        
        if not smtp_server or not username or not password or not recipients:
            logger.error("邮件配置不完整")
            return False
        
        # 生成消息ID并检查是否已发送
        message_id = self._generate_message_id(analysis)
        if message_id in self.sent_message_ids:
            logger.info(f"消息 {message_id} 已发送，跳过")
            return True
        
        # 格式化消息
        currency_pair = analysis.get('currency_pair', '')
        change_percentage = analysis.get('change_percentage', 0)
        direction = analysis.get('direction', '')
        
        subject = f"加密货币 {currency_pair} 价格{direction} {abs(change_percentage):.2f}% 提醒"
        body = self.format_message(analysis, html=True)
        
        # 创建邮件
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = username
        msg['To'] = ', '.join(recipients)
        
        # 添加HTML内容
        html_part = MIMEText(body, 'html')
        msg.attach(html_part)
        
        # 发送邮件
        try:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(username, password)
            server.sendmail(username, recipients, msg.as_string())
            server.quit()
            
            # 记录已发送消息
            self.sent_message_ids.add(message_id)
            self._save_sent_messages()
            
            logger.info(f"邮件发送成功: {message_id}")
            return True
        except Exception as e:
            logger.error(f"邮件发送失败: {e}")
            return False
    
    def send_notification(self, analysis: Dict[str, Any]) -> bool:
        """
        发送通知（Telegram和邮件）
        
        Args:
            analysis: 分析结果
            
        Returns:
            是否至少有一种方式发送成功
        """
        # 保存通知记录
        self._save_notification(analysis)
        
        # 发送Telegram
        telegram_success = self.send_telegram(analysis)
        
        # 发送邮件
        email_success = self.send_email(analysis)
        
        return telegram_success or email_success
    
    def _save_notification(self, analysis: Dict[str, Any]):
        """
        保存通知记录
        
        Args:
            analysis: 分析结果
        """
        try:
            # 生成文件名
            currency_pair = analysis.get('currency_pair', '').replace('_', '')
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = os.path.join(self.notification_dir, f"notification_{currency_pair}_{timestamp}.json")
            
            # 保存数据
            with open(filename, 'w') as f:
                json.dump(analysis, f, indent=2)
            
            logger.info(f"已保存通知记录到 {filename}")
        except Exception as e:
            logger.error(f"保存通知记录失败: {e}")
    
    def batch_send(self, analyses: List[Dict[str, Any]]) -> int:
        """
        批量发送通知
        
        Args:
            analyses: 分析结果列表
            
        Returns:
            成功发送的数量
        """
        success_count = 0
        
        for analysis in analyses:
            if self.send_notification(analysis):
                success_count += 1
        
        logger.info(f"批量发送通知完成，成功 {success_count}/{len(analyses)}")
        return success_count
