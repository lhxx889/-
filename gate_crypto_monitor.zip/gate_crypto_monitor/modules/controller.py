"""
控制模块，负责监控的启动、停止和自定义配置
"""
import logging
import json
import os
import time
import yaml
import threading
import signal
import sys
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/controller.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("controller")

class Controller:
    """控制类，负责监控的启动、停止和自定义配置"""
    
    def __init__(self, config_file: str = "../config.yaml"):
        """
        初始化控制器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.running = False
        self.monitor_thread = None
        self.stop_event = threading.Event()
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    return yaml.safe_load(f)
            else:
                # 创建默认配置
                default_config = {
                    'monitoring': {
                        'interval': 60,
                        'threshold': {
                            'min': 30,
                            'max': 50
                        },
                        'coins': []
                    },
                    'notification': {
                        'telegram': {
                            'enabled': True,
                            'bot_token': '',
                            'chat_id': ''
                        },
                        'email': {
                            'enabled': True,
                            'smtp_server': '',
                            'smtp_port': 587,
                            'username': '',
                            'password': '',
                            'recipients': []
                        }
                    },
                    'storage': {
                        'data_dir': './data',
                        'log_dir': './logs'
                    }
                }
                
                # 保存默认配置
                self._save_config(default_config)
                
                return default_config
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            return {}
    
    def _save_config(self, config: Dict[str, Any]) -> bool:
        """
        保存配置文件
        
        Args:
            config: 配置字典
            
        Returns:
            是否保存成功
        """
        try:
            with open(self.config_file, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
            logger.info(f"配置已保存到 {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
            return False
    
    def reload_config(self) -> Dict[str, Any]:
        """
        重新加载配置文件
        
        Returns:
            最新的配置字典
        """
        self.config = self._load_config()
        logger.info("配置已重新加载")
        return self.config
    
    def update_config(self, section: str, key: str, value: Any) -> bool:
        """
        更新配置项
        
        Args:
            section: 配置节
            key: 配置键
            value: 配置值
            
        Returns:
            是否更新成功
        """
        try:
            # 处理嵌套配置
            if '.' in key:
                parts = key.split('.')
                current = self.config.get(section, {})
                
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]
                
                current[parts[-1]] = value
            else:
                if section not in self.config:
                    self.config[section] = {}
                
                self.config[section][key] = value
            
            # 保存配置
            success = self._save_config(self.config)
            
            if success:
                logger.info(f"配置已更新: {section}.{key} = {value}")
            
            return success
        except Exception as e:
            logger.error(f"更新配置失败: {e}")
            return False
    
    def set_threshold(self, min_threshold: float, max_threshold: float) -> bool:
        """
        设置涨跌幅阈值
        
        Args:
            min_threshold: 最小涨跌幅阈值（百分比）
            max_threshold: 最大涨跌幅阈值（百分比）
            
        Returns:
            是否设置成功
        """
        if min_threshold < 0 or max_threshold < min_threshold:
            logger.error(f"无效的阈值范围: {min_threshold}% - {max_threshold}%")
            return False
        
        if 'monitoring' not in self.config:
            self.config['monitoring'] = {}
        
        if 'threshold' not in self.config['monitoring']:
            self.config['monitoring']['threshold'] = {}
        
        self.config['monitoring']['threshold']['min'] = min_threshold
        self.config['monitoring']['threshold']['max'] = max_threshold
        
        success = self._save_config(self.config)
        
        if success:
            logger.info(f"涨跌幅阈值已设置为 {min_threshold}% - {max_threshold}%")
        
        return success
    
    def set_interval(self, interval: int) -> bool:
        """
        设置监控间隔
        
        Args:
            interval: 监控间隔（秒）
            
        Returns:
            是否设置成功
        """
        if interval < 10:
            logger.error(f"监控间隔不能小于10秒: {interval}")
            return False
        
        if 'monitoring' not in self.config:
            self.config['monitoring'] = {}
        
        self.config['monitoring']['interval'] = interval
        
        success = self._save_config(self.config)
        
        if success:
            logger.info(f"监控间隔已设置为 {interval} 秒")
        
        return success
    
    def set_coins(self, coins: List[str]) -> bool:
        """
        设置监控币种列表
        
        Args:
            coins: 币种列表，空列表表示监控所有币种
            
        Returns:
            是否设置成功
        """
        if 'monitoring' not in self.config:
            self.config['monitoring'] = {}
        
        self.config['monitoring']['coins'] = coins
        
        success = self._save_config(self.config)
        
        if success:
            if coins:
                logger.info(f"监控币种已设置为 {', '.join(coins)}")
            else:
                logger.info("监控币种已设置为所有币种")
        
        return success
    
    def set_telegram_config(self, enabled: bool, bot_token: str = None, chat_id: str = None) -> bool:
        """
        设置Telegram配置
        
        Args:
            enabled: 是否启用Telegram推送
            bot_token: Telegram Bot Token
            chat_id: Telegram Chat ID
            
        Returns:
            是否设置成功
        """
        if 'notification' not in self.config:
            self.config['notification'] = {}
        
        if 'telegram' not in self.config['notification']:
            self.config['notification']['telegram'] = {}
        
        self.config['notification']['telegram']['enabled'] = enabled
        
        if bot_token is not None:
            self.config['notification']['telegram']['bot_token'] = bot_token
        
        if chat_id is not None:
            self.config['notification']['telegram']['chat_id'] = chat_id
        
        success = self._save_config(self.config)
        
        if success:
            logger.info(f"Telegram配置已{'启用' if enabled else '禁用'}")
        
        return success
    
    def set_email_config(self, enabled: bool, smtp_server: str = None, 
                        smtp_port: int = None, username: str = None, 
                        password: str = None, recipients: List[str] = None) -> bool:
        """
        设置邮件配置
        
        Args:
            enabled: 是否启用邮件推送
            smtp_server: SMTP服务器
            smtp_port: SMTP端口
            username: 邮箱用户名
            password: 邮箱密码
            recipients: 接收邮件的邮箱列表
            
        Returns:
            是否设置成功
        """
        if 'notification' not in self.config:
            self.config['notification'] = {}
        
        if 'email' not in self.config['notification']:
            self.config['notification']['email'] = {}
        
        self.config['notification']['email']['enabled'] = enabled
        
        if smtp_server is not None:
            self.config['notification']['email']['smtp_server'] = smtp_server
        
        if smtp_port is not None:
            self.config['notification']['email']['smtp_port'] = smtp_port
        
        if username is not None:
            self.config['notification']['email']['username'] = username
        
        if password is not None:
            self.config['notification']['email']['password'] = password
        
        if recipients is not None:
            self.config['notification']['email']['recipients'] = recipients
        
        success = self._save_config(self.config)
        
        if success:
            logger.info(f"邮件配置已{'启用' if enabled else '禁用'}")
        
        return success
    
    def start_monitoring(self, monitor_func: Callable) -> bool:
        """
        启动监控
        
        Args:
            monitor_func: 监控函数
            
        Returns:
            是否启动成功
        """
        if self.running:
            logger.warning("监控已在运行中")
            return False
        
        self.running = True
        self.stop_event.clear()
        
        # 创建并启动监控线程
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            args=(monitor_func,),
            daemon=True
        )
        self.monitor_thread.start()
        
        logger.info("监控已启动")
        return True
    
    def _monitoring_loop(self, monitor_func: Callable):
        """
        监控循环
        
        Args:
            monitor_func: 监控函数
        """
        while self.running and not self.stop_event.is_set():
            try:
                # 重新加载配置
                self.reload_config()
                
                # 获取监控参数
                interval = self.config.get('monitoring', {}).get('interval', 60)
                min_threshold = self.config.get('monitoring', {}).get('threshold', {}).get('min', 30)
                max_threshold = self.config.get('monitoring', {}).get('threshold', {}).get('max', 50)
                coins = self.config.get('monitoring', {}).get('coins', [])
                
                # 执行监控函数
                monitor_func(interval, min_threshold, max_threshold, coins)
                
                # 等待下一次监控
                for _ in range(interval):
                    if self.stop_event.is_set():
                        break
                    time.sleep(1)
            except Exception as e:
                logger.error(f"监控循环异常: {e}")
                time.sleep(10)  # 出错后等待10秒再重试
    
    def stop_monitoring(self) -> bool:
        """
        停止监控
        
        Returns:
            是否停止成功
        """
        if not self.running:
            logger.warning("监控未在运行")
            return False
        
        self.running = False
        self.stop_event.set()
        
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=5)
        
        logger.info("监控已停止")
        return True
    
    def is_monitoring(self) -> bool:
        """
        检查监控是否在运行
        
        Returns:
            是否在运行
        """
        return self.running and self.monitor_thread and self.monitor_thread.is_alive()
    
    def test_notification(self, message: str = "这是一条测试消息") -> Dict[str, bool]:
        """
        测试通知推送
        
        Args:
            message: 测试消息内容
            
        Returns:
            各推送渠道的测试结果
        """
        from modules.notifier import Notifier
        
        logger.info("开始测试通知推送")
        
        # 创建测试分析结果
        test_analysis = {
            'currency_pair': 'TEST_USDT',
            'change_percentage': 35.0,
            'direction': '上涨',
            'summary': message,
            'factors': ["这是一个测试因素，用于验证推送功能是否正常工作"],
            'confidence': 'high',
            'timestamp': datetime.now().isoformat()
        }
        
        # 创建通知器
        notifier = Notifier(self.config_file)
        
        # 测试结果
        results = {
            'telegram': False,
            'email': False
        }
        
        # 测试Telegram
        if self.config.get('notification', {}).get('telegram', {}).get('enabled', False):
            results['telegram'] = notifier.send_telegram(test_analysis)
        
        # 测试邮件
        if self.config.get('notification', {}).get('email', {}).get('enabled', False):
            results['email'] = notifier.send_email(test_analysis)
        
        logger.info(f"通知推送测试结果: {results}")
        return results
    
    def get_status(self) -> Dict[str, Any]:
        """
        获取监控状态
        
        Returns:
            状态信息字典
        """
        status = {
            'running': self.is_monitoring(),
            'config': self.config,
            'timestamp': datetime.now().isoformat()
        }
        
        return status
