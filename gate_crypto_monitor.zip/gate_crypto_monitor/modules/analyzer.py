"""
分析模块，负责分析币种价格波动原因
"""
import logging
import json
import os
import re
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import pandas as pd
from collections import Counter

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/analyzer.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("analyzer")

class PriceAnalyzer:
    """价格分析类，负责分析币种价格波动原因"""
    
    def __init__(self, data_dir: str = "../data"):
        """
        初始化价格分析器
        
        Args:
            data_dir: 数据存储目录
        """
        self.data_dir = data_dir
        self.analysis_dir = os.path.join(data_dir, "analysis")
        
        # 确保数据目录存在
        os.makedirs(self.analysis_dir, exist_ok=True)
        
        # 关键词词典，用于分析社交媒体内容
        self.positive_keywords = [
            "launch", "partnership", "listing", "release", "update", "upgrade",
            "announcement", "collaboration", "integration", "milestone", "achievement",
            "success", "growth", "development", "progress", "innovation",
            "breakthrough", "expansion", "adoption", "支持", "上线", "合作", "发布",
            "更新", "升级", "公告", "里程碑", "成功", "增长", "发展", "创新", "突破"
        ]
        
        self.negative_keywords = [
            "hack", "exploit", "vulnerability", "issue", "problem", "bug", "delay",
            "postpone", "cancel", "suspend", "halt", "stop", "fail", "breach",
            "attack", "scam", "fraud", "investigation", "regulation", "ban",
            "restriction", "warning", "concern", "risk", "黑客", "漏洞", "问题",
            "延迟", "取消", "暂停", "停止", "失败", "攻击", "欺诈", "调查", "监管",
            "禁止", "限制", "警告", "担忧", "风险"
        ]
        
        self.market_keywords = [
            "market", "trend", "bullish", "bearish", "rally", "correction",
            "recovery", "resistance", "support", "volume", "liquidity", "volatility",
            "momentum", "oversold", "overbought", "accumulation", "distribution",
            "市场", "趋势", "牛市", "熊市", "反弹", "调整", "恢复", "阻力", "支撑",
            "交易量", "流动性", "波动性", "动能", "超卖", "超买", "积累", "分配"
        ]
    
    def analyze_price_change(self, coin_data: Dict[str, Any], coin_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        分析币种价格变化原因
        
        Args:
            coin_data: 币种价格数据
            coin_info: 币种信息和社交媒体数据
            
        Returns:
            分析结果字典
        """
        logger.info(f"分析币种 {coin_data.get('currency_pair', '')} 的价格变化原因")
        
        # 提取基本信息
        currency_pair = coin_data.get('currency_pair', '')
        change_percentage = coin_data.get('change_percentage', 0)
        direction = '上涨' if change_percentage > 0 else '下跌'
        abs_change = abs(change_percentage)
        
        # 初始化分析结果
        analysis = {
            'currency_pair': currency_pair,
            'change_percentage': change_percentage,
            'direction': direction,
            'summary': '',
            'factors': [],
            'confidence': 'medium',  # 默认置信度
            'timestamp': datetime.now().isoformat()
        }
        
        # 分析因素列表
        factors = []
        
        # 1. 基于币种描述的分析
        description_factor = self._analyze_description(coin_info.get('description', ''), direction)
        if description_factor:
            factors.append(description_factor)
        
        # 2. 基于社交媒体的分析
        social_factors = self._analyze_social_media(
            coin_info.get('twitter_posts', []),
            coin_info.get('telegram_posts', []),
            direction
        )
        factors.extend(social_factors)
        
        # 3. 基于市场数据的分析
        market_factor = self._analyze_market_data(coin_data, direction)
        if market_factor:
            factors.append(market_factor)
        
        # 如果没有找到任何因素，添加默认因素
        if not factors:
            if direction == '上涨':
                factors.append("可能受整体市场情绪影响或存在未公开的利好消息")
            else:
                factors.append("可能受整体市场情绪影响或存在未公开的利空消息")
        
        # 更新分析结果
        analysis['factors'] = factors
        
        # 生成摘要
        if abs_change >= 40:
            intensity = "剧烈"
        elif abs_change >= 35:
            intensity = "显著"
        else:
            intensity = "明显"
        
        summary = f"{coin_info.get('name', currency_pair)}在过去24小时内{intensity}{direction}了{abs_change:.2f}%。"
        
        if len(factors) == 1:
            summary += f"主要原因可能是{factors[0]}。"
        else:
            summary += f"可能的原因包括：{', '.join(factors[:2])}等。"
        
        analysis['summary'] = summary
        
        # 确定置信度
        if len(factors) >= 3 or (len(factors) >= 2 and any("公告" in f or "宣布" in f or "官方" in f for f in factors)):
            analysis['confidence'] = 'high'
        elif len(factors) == 1 and "可能" in factors[0]:
            analysis['confidence'] = 'low'
        
        # 保存分析结果
        self._save_analysis(currency_pair, analysis)
        
        return analysis
    
    def _analyze_description(self, description: str, direction: str) -> Optional[str]:
        """
        基于币种描述分析价格变化原因
        
        Args:
            description: 币种描述
            direction: 价格变化方向
            
        Returns:
            分析结果
        """
        if not description:
            return None
        
        # 检查描述中是否包含关键词
        keywords = self.positive_keywords if direction == '上涨' else self.negative_keywords
        
        for keyword in keywords:
            if keyword in description.lower():
                context = self._extract_context(description, keyword)
                if context:
                    return f"币种介绍中提到的{context}"
        
        return None
    
    def _analyze_social_media(self, twitter_posts: List[Dict[str, str]], 
                             telegram_posts: List[Dict[str, str]], 
                             direction: str) -> List[str]:
        """
        基于社交媒体内容分析价格变化原因
        
        Args:
            twitter_posts: Twitter帖子列表
            telegram_posts: Telegram帖子列表
            direction: 价格变化方向
            
        Returns:
            分析结果列表
        """
        factors = []
        
        # 合并所有社交媒体内容
        all_posts = []
        for post in twitter_posts:
            all_posts.append({
                'content': post.get('content', ''),
                'time': post.get('time', ''),
                'source': 'Twitter'
            })
        
        for post in telegram_posts:
            all_posts.append({
                'content': post.get('content', ''),
                'time': post.get('time', ''),
                'source': 'Telegram'
            })
        
        # 按时间排序，最新的在前
        all_posts.sort(key=lambda x: x.get('time', ''), reverse=True)
        
        # 分析每个帖子
        keywords = self.positive_keywords if direction == '上涨' else self.negative_keywords
        market_factors = []
        
        for post in all_posts:
            content = post.get('content', '').lower()
            source = post.get('source', '')
            
            # 检查是否包含关键词
            for keyword in keywords:
                if keyword.lower() in content:
                    context = self._extract_context(content, keyword)
                    if context:
                        factor = f"{source}上发布的关于{context}的消息"
                        if factor not in factors:
                            factors.append(factor)
                            break
            
            # 检查市场相关关键词
            for keyword in self.market_keywords:
                if keyword.lower() in content:
                    context = self._extract_context(content, keyword)
                    if context:
                        factor = f"{source}上提到的{context}"
                        if factor not in market_factors:
                            market_factors.append(factor)
                            break
        
        # 如果没有找到主要因素，但有市场因素，添加市场因素
        if not factors and market_factors:
            factors.append(market_factors[0])
        
        return factors[:3]  # 最多返回3个因素
    
    def _analyze_market_data(self, coin_data: Dict[str, Any], direction: str) -> Optional[str]:
        """
        基于市场数据分析价格变化原因
        
        Args:
            coin_data: 币种价格数据
            direction: 价格变化方向
            
        Returns:
            分析结果
        """
        volume = float(coin_data.get('volume_24h', 0))
        
        if volume > 1000000:  # 交易量大于100万
            if direction == '上涨':
                return "交易量显著增加，可能有大量买盘涌入"
            else:
                return "交易量显著增加，可能有大量卖盘涌出"
        
        return None
    
    def _extract_context(self, text: str, keyword: str) -> str:
        """
        提取关键词上下文
        
        Args:
            text: 文本内容
            keyword: 关键词
            
        Returns:
            上下文
        """
        # 查找关键词位置
        keyword_pos = text.lower().find(keyword.lower())
        if keyword_pos == -1:
            return keyword
        
        # 提取前后各50个字符
        start = max(0, keyword_pos - 50)
        end = min(len(text), keyword_pos + len(keyword) + 50)
        
        context = text[start:end]
        
        # 如果上下文太长，截断并添加省略号
        if len(context) > 100:
            words = context.split()
            if len(words) > 10:
                context = ' '.join(words[:10]) + '...'
        
        return context
    
    def _save_analysis(self, currency_pair: str, analysis: Dict[str, Any]):
        """
        保存分析结果
        
        Args:
            currency_pair: 交易对
            analysis: 分析结果
        """
        try:
            # 生成文件名
            filename = os.path.join(
                self.analysis_dir, 
                f"{currency_pair.replace('_', '')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            )
            
            # 保存数据
            with open(filename, 'w') as f:
                json.dump(analysis, f, indent=2)
            
            logger.info(f"已保存分析结果到 {filename}")
        except Exception as e:
            logger.error(f"保存分析结果失败: {e}")
    
    def batch_analyze(self, alerts: List[Dict[str, Any]], coin_infos: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        批量分析多个币种的价格变化
        
        Args:
            alerts: 警报数据列表
            coin_infos: 币种信息字典，键为交易对
            
        Returns:
            分析结果列表
        """
        results = []
        
        for alert in alerts:
            currency_pair = alert.get('currency_pair', '')
            
            if currency_pair in coin_infos:
                analysis = self.analyze_price_change(alert, coin_infos[currency_pair])
                results.append(analysis)
            else:
                logger.warning(f"缺少币种 {currency_pair} 的信息数据")
        
        return results
