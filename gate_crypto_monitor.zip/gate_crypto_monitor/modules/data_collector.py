"""
数据采集模块，负责从Gate API获取加密货币价格数据
"""
import time
import logging
import json
import os
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Set, Tuple

from utils.api import GateAPI

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/data_collector.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("data_collector")

class DataCollector:
    """数据采集类，负责从Gate API获取价格数据并进行初步处理"""
    
    def __init__(self, data_dir: str = "../data"):
        """
        初始化数据采集器
        
        Args:
            data_dir: 数据存储目录
        """
        self.api = GateAPI()
        self.data_dir = data_dir
        self.history_file = os.path.join(data_dir, "price_history.json")
        self.last_data = {}
        self.currency_pairs = {}
        self.pushed_alerts: Set[str] = set()  # 已推送的警报集合，用于去重
        
        # 确保数据目录存在
        os.makedirs(data_dir, exist_ok=True)
        
        # 加载历史数据
        self._load_history()
        
        # 初始化获取所有交易对信息
        self._init_currency_pairs()
    
    def _load_history(self):
        """加载历史价格数据"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    self.last_data = json.load(f)
                logger.info(f"已加载历史价格数据，包含 {len(self.last_data)} 个交易对")
            except Exception as e:
                logger.error(f"加载历史价格数据失败: {e}")
                self.last_data = {}
    
    def _save_history(self, data: Dict[str, Any]):
        """
        保存价格数据到历史文件
        
        Args:
            data: 价格数据字典
        """
        try:
            with open(self.history_file, 'w') as f:
                json.dump(data, f)
            logger.info(f"已保存价格数据，包含 {len(data)} 个交易对")
        except Exception as e:
            logger.error(f"保存价格数据失败: {e}")
    
    def _init_currency_pairs(self):
        """初始化获取所有交易对信息"""
        try:
            pairs = self.api.get_currency_pairs()
            self.currency_pairs = {pair['id']: pair for pair in pairs}
            logger.info(f"已获取 {len(self.currency_pairs)} 个交易对信息")
        except Exception as e:
            logger.error(f"获取交易对信息失败: {e}")
    
    def collect_price_data(self) -> Dict[str, Any]:
        """
        收集所有交易对的价格数据
        
        Returns:
            处理后的价格数据字典
        """
        try:
            tickers = self.api.get_tickers()
            
            # 转换为以交易对为键的字典
            current_data = {ticker['currency_pair']: ticker for ticker in tickers}
            
            # 保存当前数据作为下次比较的基准
            self._save_history(current_data)
            
            return current_data
        except Exception as e:
            logger.error(f"收集价格数据失败: {e}")
            return {}
    
    def calculate_changes(self, current_data: Dict[str, Any], 
                          min_threshold: float = 30.0, 
                          max_threshold: float = 50.0) -> List[Dict[str, Any]]:
        """
        计算价格变化并筛选出符合条件的币种
        
        Args:
            current_data: 当前价格数据
            min_threshold: 最小涨跌幅阈值（百分比）
            max_threshold: 最大涨跌幅阈值（百分比）
            
        Returns:
            符合条件的币种列表
        """
        result = []
        
        for pair, data in current_data.items():
            try:
                # 提取24小时涨跌幅
                change_percentage = float(data.get('change_percentage', '0'))
                
                # 转换为百分比值
                change_percentage = change_percentage * 100
                
                # 检查是否在阈值范围内
                if abs(change_percentage) >= min_threshold and abs(change_percentage) <= max_threshold:
                    # 构建结果对象
                    result_item = {
                        'currency_pair': pair,
                        'last_price': data.get('last', '0'),
                        'change_percentage': change_percentage,
                        'volume_24h': data.get('volume', '0'),
                        'high_24h': data.get('high_24h', '0'),
                        'low_24h': data.get('low_24h', '0'),
                        'direction': 'up' if change_percentage > 0 else 'down',
                        'timestamp': datetime.now().isoformat()
                    }
                    
                    # 添加交易对基本信息
                    if pair in self.currency_pairs:
                        pair_info = self.currency_pairs[pair]
                        result_item['base'] = pair_info.get('base', '')
                        result_item['quote'] = pair_info.get('quote', '')
                    
                    # 生成唯一标识，用于去重
                    alert_id = f"{pair}_{int(change_percentage)}"
                    
                    # 检查是否已经推送过
                    if alert_id not in self.pushed_alerts:
                        result.append(result_item)
                        self.pushed_alerts.add(alert_id)
                        
                        # 控制已推送集合大小，避免内存泄漏
                        if len(self.pushed_alerts) > 1000:
                            self.pushed_alerts = set(list(self.pushed_alerts)[-500:])
            except Exception as e:
                logger.error(f"处理交易对 {pair} 数据失败: {e}")
        
        return result
    
    def monitor_price_changes(self, interval: int = 60, 
                             min_threshold: float = 30.0, 
                             max_threshold: float = 50.0) -> List[Dict[str, Any]]:
        """
        监控价格变化，返回符合条件的币种
        
        Args:
            interval: 监控间隔（秒）
            min_threshold: 最小涨跌幅阈值（百分比）
            max_threshold: 最大涨跌幅阈值（百分比）
            
        Returns:
            符合条件的币种列表
        """
        logger.info(f"开始监控价格变化，间隔 {interval} 秒，阈值 {min_threshold}%-{max_threshold}%")
        
        # 收集当前价格数据
        current_data = self.collect_price_data()
        
        # 计算变化并筛选
        alerts = self.calculate_changes(current_data, min_threshold, max_threshold)
        
        if alerts:
            logger.info(f"发现 {len(alerts)} 个符合条件的币种")
            # 保存警报数据
            self._save_alerts(alerts)
        else:
            logger.info("未发现符合条件的币种")
        
        return alerts
    
    def _save_alerts(self, alerts: List[Dict[str, Any]]):
        """
        保存警报数据到文件
        
        Args:
            alerts: 警报数据列表
        """
        try:
            # 确保目录存在
            alerts_dir = os.path.join(self.data_dir, "alerts")
            os.makedirs(alerts_dir, exist_ok=True)
            
            # 生成文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = os.path.join(alerts_dir, f"alerts_{timestamp}.json")
            
            # 保存数据
            with open(filename, 'w') as f:
                json.dump(alerts, f, indent=2)
            
            logger.info(f"已保存警报数据到 {filename}")
        except Exception as e:
            logger.error(f"保存警报数据失败: {e}")
