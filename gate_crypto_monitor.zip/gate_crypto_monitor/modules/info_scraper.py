"""
信息抓取模块，负责获取币种基本信息和社交媒体链接
"""
import logging
import requests
import json
import os
import re
from typing import Dict, List, Any, Optional
from bs4 import BeautifulSoup
from datetime import datetime

from utils.api import GateAPI

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/info_scraper.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("info_scraper")

class InfoScraper:
    """信息抓取类，负责获取币种基本信息和社交媒体链接"""
    
    def __init__(self, data_dir: str = "../data"):
        """
        初始化信息抓取器
        
        Args:
            data_dir: 数据存储目录
        """
        self.api = GateAPI()
        self.data_dir = data_dir
        self.coin_info_dir = os.path.join(data_dir, "coin_info")
        self.social_info_dir = os.path.join(data_dir, "social_info")
        
        # 确保数据目录存在
        os.makedirs(self.coin_info_dir, exist_ok=True)
        os.makedirs(self.social_info_dir, exist_ok=True)
        
        # 用户代理，避免被网站封锁
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
    
    def get_coin_info(self, currency: str) -> Dict[str, Any]:
        """
        获取币种基本信息
        
        Args:
            currency: 币种代码，如BTC
            
        Returns:
            币种基本信息字典
        """
        logger.info(f"获取币种 {currency} 的基本信息")
        
        # 检查缓存
        cache_file = os.path.join(self.coin_info_dir, f"{currency.lower()}.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
                
                # 检查缓存是否过期（24小时）
                cache_time = datetime.fromisoformat(cached_data.get('timestamp', '2000-01-01T00:00:00'))
                now = datetime.now()
                if (now - cache_time).total_seconds() < 86400:  # 24小时 = 86400秒
                    logger.info(f"使用缓存的币种 {currency} 信息")
                    return cached_data
            except Exception as e:
                logger.error(f"读取币种 {currency} 缓存信息失败: {e}")
        
        try:
            # 从Gate API获取币种信息
            coin_data = self.api.get_currency_detail(currency)
            
            # 补充信息
            result = {
                'currency': currency,
                'name': coin_data.get('name', ''),
                'description': self._get_coin_description(currency),
                'social_links': self._extract_social_links(currency),
                'timestamp': datetime.now().isoformat()
            }
            
            # 保存到缓存
            with open(cache_file, 'w') as f:
                json.dump(result, f, indent=2)
            
            return result
        except Exception as e:
            logger.error(f"获取币种 {currency} 信息失败: {e}")
            return {
                'currency': currency,
                'name': '',
                'description': '',
                'social_links': {},
                'timestamp': datetime.now().isoformat()
            }
    
    def _get_coin_description(self, currency: str) -> str:
        """
        获取币种描述信息
        
        Args:
            currency: 币种代码
            
        Returns:
            币种描述文本
        """
        try:
            # 尝试从CoinGecko获取信息
            url = f"https://www.coingecko.com/en/coins/{currency.lower()}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                description_div = soup.select_one('div[data-target="coins-information.description"]')
                if description_div:
                    return description_div.get_text(strip=True)
            
            # 尝试从CoinMarketCap获取信息
            url = f"https://coinmarketcap.com/currencies/{currency.lower()}/"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                description_div = soup.select_one('div.sc-aef7b723-0')
                if description_div:
                    return description_div.get_text(strip=True)
            
            return "暂无描述信息"
        except Exception as e:
            logger.error(f"获取币种 {currency} 描述信息失败: {e}")
            return "获取描述信息失败"
    
    def _extract_social_links(self, currency: str) -> Dict[str, str]:
        """
        提取币种社交媒体链接
        
        Args:
            currency: 币种代码
            
        Returns:
            社交媒体链接字典
        """
        social_links = {
            'website': '',
            'twitter': '',
            'telegram': '',
            'github': '',
            'reddit': '',
            'discord': ''
        }
        
        try:
            # 尝试从CoinGecko获取社交链接
            url = f"https://www.coingecko.com/en/coins/{currency.lower()}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 提取官网
                website_link = soup.select_one('a[data-site="website"]')
                if website_link and 'href' in website_link.attrs:
                    social_links['website'] = website_link['href']
                
                # 提取Twitter
                twitter_link = soup.select_one('a[data-site="twitter"]')
                if twitter_link and 'href' in twitter_link.attrs:
                    social_links['twitter'] = twitter_link['href']
                
                # 提取Telegram
                telegram_link = soup.select_one('a[data-site="telegram"]')
                if telegram_link and 'href' in telegram_link.attrs:
                    social_links['telegram'] = telegram_link['href']
                
                # 提取GitHub
                github_link = soup.select_one('a[data-site="github"]')
                if github_link and 'href' in github_link.attrs:
                    social_links['github'] = github_link['href']
                
                # 提取Reddit
                reddit_link = soup.select_one('a[data-site="reddit"]')
                if reddit_link and 'href' in reddit_link.attrs:
                    social_links['reddit'] = reddit_link['href']
                
                # 提取Discord
                discord_link = soup.select_one('a[data-site="discord"]')
                if discord_link and 'href' in discord_link.attrs:
                    social_links['discord'] = discord_link['href']
            
            # 如果没有找到足够的社交链接，尝试从CoinMarketCap获取
            if not all(social_links.values()):
                url = f"https://coinmarketcap.com/currencies/{currency.lower()}/"
                response = requests.get(url, headers=self.headers, timeout=10)
                
                if response.status_code == 200:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    
                    # 查找所有社交链接
                    social_divs = soup.select('div.sc-aef7b723-0 a')
                    for link in social_divs:
                        href = link.get('href', '')
                        
                        if 'twitter.com' in href and not social_links['twitter']:
                            social_links['twitter'] = href
                        elif 't.me' in href and not social_links['telegram']:
                            social_links['telegram'] = href
                        elif 'github.com' in href and not social_links['github']:
                            social_links['github'] = href
                        elif 'reddit.com' in href and not social_links['reddit']:
                            social_links['reddit'] = href
                        elif 'discord' in href and not social_links['discord']:
                            social_links['discord'] = href
                        elif not social_links['website'] and not any(domain in href for domain in ['twitter.com', 't.me', 'github.com', 'reddit.com', 'discord']):
                            social_links['website'] = href
            
            return social_links
        except Exception as e:
            logger.error(f"提取币种 {currency} 社交媒体链接失败: {e}")
            return social_links
    
    def get_social_media_content(self, currency: str) -> Dict[str, Any]:
        """
        获取币种社交媒体内容
        
        Args:
            currency: 币种代码
            
        Returns:
            社交媒体内容字典
        """
        logger.info(f"获取币种 {currency} 的社交媒体内容")
        
        # 获取币种信息和社交链接
        coin_info = self.get_coin_info(currency)
        social_links = coin_info.get('social_links', {})
        
        result = {
            'currency': currency,
            'twitter_posts': [],
            'telegram_posts': [],
            'timestamp': datetime.now().isoformat()
        }
        
        # 获取Twitter内容
        if social_links.get('twitter'):
            result['twitter_posts'] = self._get_twitter_content(social_links['twitter'])
        
        # 获取Telegram内容
        if social_links.get('telegram'):
            result['telegram_posts'] = self._get_telegram_content(social_links['telegram'])
        
        # 保存到缓存
        cache_file = os.path.join(self.social_info_dir, f"{currency.lower()}_social.json")
        try:
            with open(cache_file, 'w') as f:
                json.dump(result, f, indent=2)
        except Exception as e:
            logger.error(f"保存币种 {currency} 社交媒体内容失败: {e}")
        
        return result
    
    def _get_twitter_content(self, twitter_url: str) -> List[Dict[str, str]]:
        """
        获取Twitter内容
        
        Args:
            twitter_url: Twitter链接
            
        Returns:
            Twitter帖子列表
        """
        posts = []
        
        try:
            # 提取Twitter用户名
            username_match = re.search(r'twitter\.com/([^/]+)', twitter_url)
            if not username_match:
                return posts
            
            username = username_match.group(1)
            
            # 使用nitter.net作为Twitter替代服务（不需要API密钥）
            url = f"https://nitter.net/{username}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 获取最近的推文
                tweet_divs = soup.select('div.timeline-item')
                for i, div in enumerate(tweet_divs[:5]):  # 只获取最近5条推文
                    content_div = div.select_one('div.tweet-content')
                    time_a = div.select_one('a.tweet-date')
                    
                    if content_div and time_a:
                        content = content_div.get_text(strip=True)
                        time = time_a.get_text(strip=True)
                        
                        posts.append({
                            'content': content,
                            'time': time,
                            'url': f"https://twitter.com/{username}/status/{div.get('data-tweet-id', '')}"
                        })
            
            return posts
        except Exception as e:
            logger.error(f"获取Twitter内容失败: {e}")
            return posts
    
    def _get_telegram_content(self, telegram_url: str) -> List[Dict[str, str]]:
        """
        获取Telegram内容
        
        Args:
            telegram_url: Telegram链接
            
        Returns:
            Telegram帖子列表
        """
        posts = []
        
        try:
            # 提取Telegram频道名
            channel_match = re.search(r't\.me/([^/]+)', telegram_url)
            if not channel_match:
                return posts
            
            channel = channel_match.group(1)
            
            # 使用Telegram Web版获取内容
            url = f"https://t.me/s/{channel}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 获取最近的消息
                message_divs = soup.select('div.tgme_widget_message')
                for i, div in enumerate(message_divs[-5:]):  # 只获取最近5条消息
                    content_div = div.select_one('div.tgme_widget_message_text')
                    time_div = div.select_one('div.tgme_widget_message_date')
                    
                    if content_div and time_div:
                        content = content_div.get_text(strip=True)
                        time = time_div.get_text(strip=True)
                        
                        posts.append({
                            'content': content,
                            'time': time,
                            'url': time_div.get('href', '')
                        })
            
            return posts
        except Exception as e:
            logger.error(f"获取Telegram内容失败: {e}")
            return posts
    
    def get_coin_full_info(self, currency_pair: str) -> Dict[str, Any]:
        """
        获取币种完整信息，包括基本信息和社交媒体内容
        
        Args:
            currency_pair: 交易对，如BTC_USDT
            
        Returns:
            币种完整信息字典
        """
        # 提取基础币种
        base_currency = currency_pair.split('_')[0]
        
        # 获取币种基本信息
        coin_info = self.get_coin_info(base_currency)
        
        # 获取社交媒体内容
        social_info = self.get_social_media_content(base_currency)
        
        # 合并信息
        result = {
            'currency_pair': currency_pair,
            'base_currency': base_currency,
            'name': coin_info.get('name', ''),
            'description': coin_info.get('description', ''),
            'social_links': coin_info.get('social_links', {}),
            'twitter_posts': social_info.get('twitter_posts', []),
            'telegram_posts': social_info.get('telegram_posts', []),
            'timestamp': datetime.now().isoformat()
        }
        
        return result
