# Gate加密货币监控脚本设计文档

## 1. 整体架构

脚本将采用模块化设计，主要包含以下几个核心模块：

1. **数据采集模块**：负责从Gate API获取所有币种的价格数据
2. **数据处理模块**：计算涨跌幅，过滤重复数据
3. **信息抓取模块**：获取币种基本信息和社交媒体链接
4. **分析模块**：分析币种波动原因
5. **推送模块**：将分析结果推送到Telegram和邮箱
6. **控制模块**：提供启动、停止和自定义配置功能
7. **安装模块**：提供一键安装所有依赖的功能

## 2. 模块详细设计

### 2.1 数据采集模块
- 使用Gate API获取所有币种的实时价格数据
- 每60秒执行一次数据采集
- 保存历史数据用于计算涨跌幅和去重

### 2.2 数据处理模块
- 计算24小时涨跌幅
- 计算24小时交易量
- 筛选涨跌幅超过设定阈值（默认30%-50%）的币种
- 对比上次推送数据，过滤重复数据

### 2.3 信息抓取模块
- 获取币种基本信息（名称、简介、发行时间等）
- 从币种信息中提取社交媒体链接（Twitter、Telegram等）
- 抓取社交媒体上的最新动态

### 2.4 分析模块
- 基于币种基本信息进行初步分析
- 基于社交媒体内容进行深入分析
- 综合多方面信息，生成波动原因分析报告

### 2.5 推送模块
- 支持Telegram Bot推送
- 支持邮件推送
- 格式化推送内容，包含币种名称、价格、涨跌幅、交易量、波动原因等

### 2.6 控制模块
- 提供命令行接口，支持启动和停止监控
- 支持自定义涨跌幅阈值
- 支持自定义监控币种列表
- 支持自定义推送频率

### 2.7 安装模块
- 检测系统环境
- 安装所需的Python依赖
- 配置环境变量

## 3. 数据流设计

1. 数据采集模块从Gate API获取数据
2. 数据处理模块计算涨跌幅并筛选符合条件的币种
3. 对于符合条件的币种，信息抓取模块获取详细信息
4. 分析模块基于获取的信息进行分析
5. 推送模块将分析结果推送到指定渠道
6. 控制模块全程监控并可随时干预流程

## 4. 配置文件设计

配置文件采用YAML格式，主要包含以下配置项：

```yaml
# 监控设置
monitoring:
  interval: 60  # 监控间隔（秒）
  threshold:
    min: 30  # 最小涨跌幅阈值（%）
    max: 50  # 最大涨跌幅阈值（%）
  coins: []  # 空列表表示监控所有币种，否则只监控指定币种

# 推送设置
notification:
  telegram:
    enabled: true
    bot_token: ""  # Telegram Bot Token
    chat_id: ""    # Telegram Chat ID
  email:
    enabled: true
    smtp_server: ""  # SMTP服务器
    smtp_port: 587   # SMTP端口
    username: ""     # 邮箱用户名
    password: ""     # 邮箱密码
    recipients: []   # 接收邮件的邮箱列表

# 数据存储设置
storage:
  data_dir: "./data"  # 数据存储目录
  log_dir: "./logs"   # 日志存储目录
```

## 5. 文件结构设计

```
gate_crypto_monitor/
├── install.sh                # 一键安装脚本
├── requirements.txt          # Python依赖列表
├── config.yaml               # 配置文件
├── main.py                   # 主程序入口
├── modules/
│   ├── __init__.py
│   ├── data_collector.py     # 数据采集模块
│   ├── data_processor.py     # 数据处理模块
│   ├── info_scraper.py       # 信息抓取模块
│   ├── analyzer.py           # 分析模块
│   ├── notifier.py           # 推送模块
│   └── controller.py         # 控制模块
├── utils/
│   ├── __init__.py
│   ├── api.py                # API工具
│   ├── logger.py             # 日志工具
│   └── helpers.py            # 辅助函数
├── data/                     # 数据存储目录
└── logs/                     # 日志存储目录
```

## 6. 依赖列表

主要依赖包括：

- requests：用于API调用和网络请求
- pandas：用于数据处理和分析
- pyyaml：用于配置文件解析
- schedule：用于定时任务调度
- python-telegram-bot：用于Telegram推送
- beautifulsoup4：用于网页解析
- tweepy：用于Twitter API调用
- telethon：用于Telegram API调用
- smtplib（标准库）：用于邮件发送

## 7. 安装脚本设计

安装脚本将执行以下操作：

1. 检查Python版本
2. 安装pip（如果未安装）
3. 安装virtualenv（如果未安装）
4. 创建虚拟环境
5. 安装所有依赖
6. 创建必要的目录结构
7. 生成默认配置文件
8. 提示用户完成配置
