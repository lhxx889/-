"""
Gate.io加密货币异动监控系统 - 增强版异动原因分析模块
负责分析异动可能的原因并提供更详细的解释
"""

import logging
import time
import json
import requests
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import os
import re

# 导入币种信息模块
from src.enhanced_coin_info import EnhancedCoinInfo

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("enhanced_reason_analyzer")

class EnhancedReasonAnalyzer:
    """增强版异动原因分析类，负责分析异动可能的原因"""
    
    # CryptoCompare News API
    CRYPTOCOMPARE_API_URL = "https://min-api.cryptocompare.com/data/v2/news/"
    
    # CoinGecko Trending API
    COINGECKO_TRENDING_URL = "https://api.coingecko.com/api/v3/search/trending"
    
    def __init__(self, config_file: str = "api_config.json", cache_duration: int = 1800):
        """
        初始化增强版异动原因分析器
        
        Args:
            config_file: 配置文件路径
            cache_duration: 缓存有效期（秒）
        """
        self.config_file = config_file
        self.cache_duration = cache_duration
        self.api_key = None
        self.cache = {}
        self.cache_expiry = {}
        
        # 初始化币种信息查询器
        self.coin_info = EnhancedCoinInfo(config_file=config_file)
        
        # 尝试从配置文件加载API密钥
        self._load_config()
        
        logger.info("增强版异动原因分析模块初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载API配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.api_key = config.get("cryptocompare_api_key")
                    logger.info("从配置文件加载API配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def save_config(self, api_key: str = None) -> bool:
        """
        保存API配置到配置文件
        
        Args:
            api_key: CryptoCompare API密钥
            
        Returns:
            保存是否成功
        """
        try:
            # 读取现有配置（如果存在）
            config = {}
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            
            # 更新配置
            if api_key:
                self.api_key = api_key
                config["cryptocompare_api_key"] = api_key
            
            # 保存配置
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info("保存API配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def _make_request(self, url: str, params: Dict = None, headers: Dict = None) -> Optional[Dict]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API URL
            params: 请求参数
            headers: 请求头
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, headers=headers, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
    
    def get_coin_news(self, symbol: str, limit: int = 5) -> List[Dict]:
        """
        获取特定币种的新闻
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            limit: 返回的新闻数量
            
        Returns:
            新闻列表
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"coin_news_{coin_name}_{limit}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{coin_name}的新闻")
            return self.cache[cache_key]
        
        logger.info(f"获取{coin_name}的新闻，数量: {limit}")
        
        params = {"limit": 50}  # 获取更多新闻，然后过滤
        headers = {}
        
        if self.api_key:
            headers["authorization"] = f"Apikey {self.api_key}"
        
        data = self._make_request(self.CRYPTOCOMPARE_API_URL, params, headers)
        
        if data and data.get("Response") == "Success":
            all_news = data.get("Data", [])
            
            # 过滤与币种相关的新闻
            coin_news = []
            for news in all_news:
                title = news.get("title", "").lower()
                body = news.get("body", "").lower()
                categories = news.get("categories", "").lower()
                
                # 检查新闻标题、内容和类别是否包含币种名称
                if (
                    coin_name.lower() in title or
                    coin_name.lower() in body or
                    coin_name.lower() in categories
                ):
                    coin_news.append(news)
                    
                    # 如果已经找到足够的新闻，停止搜索
                    if len(coin_news) >= limit:
                        break
            
            logger.info(f"成功获取{len(coin_news)}条{coin_name}的新闻")
            
            # 更新缓存
            self.cache[cache_key] = coin_news
            self.cache_expiry[cache_key] = time.time()
            
            return coin_news
        
        logger.warning(f"获取{coin_name}的新闻失败")
        return []
    
    def get_trending_coins(self) -> List[str]:
        """
        获取当前热门币种
        
        Returns:
            热门币种符号列表
        """
        # 检查缓存
        cache_key = "trending_coins"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info("从缓存获取热门币种")
            return self.cache[cache_key]
        
        logger.info("获取热门币种")
        
        data = self._make_request(self.COINGECKO_TRENDING_URL)
        
        if data and "coins" in data:
            trending_coins = []
            for item in data["coins"]:
                coin = item.get("item", {})
                symbol = coin.get("symbol", "").upper()
                if symbol:
                    trending_coins.append(symbol)
            
            logger.info(f"成功获取{len(trending_coins)}个热门币种")
            
            # 更新缓存
            self.cache[cache_key] = trending_coins
            self.cache_expiry[cache_key] = time.time()
            
            return trending_coins
        
        logger.warning("获取热门币种失败")
        return []
    
    def analyze_news_sentiment(self, news: List[Dict]) -> Dict:
        """
        分析新闻情感
        
        Args:
            news: 新闻列表
            
        Returns:
            情感分析结果
        """
        if not news:
            return {
                "sentiment": "neutral",
                "score": 0,
                "positive_count": 0,
                "negative_count": 0,
                "neutral_count": 0
            }
        
        # 简单的情感分析，基于关键词
        positive_keywords = [
            "bullish", "surge", "soar", "rally", "gain", "rise", "up", "high", "positive",
            "good", "great", "excellent", "amazing", "fantastic", "wonderful", "success",
            "breakthrough", "innovation", "partnership", "collaboration", "adoption",
            "launch", "release", "update", "upgrade", "improvement", "enhance", "boost",
            "牛市", "上涨", "飙升", "增长", "上升", "高涨", "积极", "利好", "优秀", "成功",
            "突破", "创新", "合作", "采用", "发布", "更新", "升级", "改进", "提升"
        ]
        
        negative_keywords = [
            "bearish", "crash", "plunge", "drop", "fall", "down", "low", "negative",
            "bad", "poor", "terrible", "awful", "horrible", "disaster", "failure",
            "problem", "issue", "concern", "worry", "fear", "risk", "threat", "danger",
            "hack", "scam", "fraud", "investigation", "regulation", "ban", "restrict",
            "熊市", "崩溃", "暴跌", "下跌", "下降", "低迷", "消极", "利空", "糟糕", "失败",
            "问题", "担忧", "恐惧", "风险", "威胁", "危险", "黑客", "诈骗", "欺诈", "调查",
            "监管", "禁止", "限制"
        ]
        
        positive_count = 0
        negative_count = 0
        neutral_count = 0
        
        for item in news:
            title = item.get("title", "").lower()
            body = item.get("body", "").lower()
            
            # 计算正面和负面关键词出现次数
            positive_matches = sum(1 for keyword in positive_keywords if keyword in title or keyword in body)
            negative_matches = sum(1 for keyword in negative_keywords if keyword in title or keyword in body)
            
            # 确定情感
            if positive_matches > negative_matches:
                positive_count += 1
            elif negative_matches > positive_matches:
                negative_count += 1
            else:
                neutral_count += 1
        
        # 计算总体情感得分（-1到1之间）
        total = positive_count + negative_count + neutral_count
        if total > 0:
            score = (positive_count - negative_count) / total
        else:
            score = 0
        
        # 确定总体情感
        if score > 0.2:
            sentiment = "positive"
        elif score < -0.2:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return {
            "sentiment": sentiment,
            "score": score,
            "positive_count": positive_count,
            "negative_count": negative_count,
            "neutral_count": neutral_count
        }
    
    def analyze_price_pattern(self, price_data: List[Dict]) -> Dict:
        """
        分析价格模式
        
        Args:
            price_data: 价格数据列表
            
        Returns:
            价格模式分析结果
        """
        if not price_data or len(price_data) < 2:
            return {
                "pattern": "unknown",
                "confidence": 0,
                "description": "数据不足，无法分析价格模式"
            }
        
        # 按时间排序
        sorted_data = sorted(price_data, key=lambda x: x.get("timestamp", ""))
        
        # 提取价格
        prices = [item.get("price", 0) for item in sorted_data]
        
        # 计算价格变化
        changes = [prices[i] - prices[i-1] for i in range(1, len(prices))]
        
        # 计算上涨和下跌次数
        up_count = sum(1 for change in changes if change > 0)
        down_count = sum(1 for change in changes if change < 0)
        
        # 计算总体趋势
        if len(changes) > 0:
            overall_change = (prices[-1] - prices[0]) / prices[0] * 100
        else:
            overall_change = 0
        
        # 判断模式
        if overall_change > 10 and up_count > down_count * 2:
            pattern = "strong_uptrend"
            description = "强劲上涨趋势，价格持续走高"
            confidence = min(0.9, 0.5 + overall_change / 100)
        elif overall_change > 5 and up_count > down_count:
            pattern = "uptrend"
            description = "上涨趋势，价格总体走高"
            confidence = min(0.8, 0.4 + overall_change / 100)
        elif overall_change < -10 and down_count > up_count * 2:
            pattern = "strong_downtrend"
            description = "强劲下跌趋势，价格持续走低"
            confidence = min(0.9, 0.5 + abs(overall_change) / 100)
        elif overall_change < -5 and down_count > up_count:
            pattern = "downtrend"
            description = "下跌趋势，价格总体走低"
            confidence = min(0.8, 0.4 + abs(overall_change) / 100)
        elif abs(overall_change) < 3 and abs(up_count - down_count) < len(changes) / 4:
            pattern = "sideways"
            description = "横盘整理，价格波动较小"
            confidence = 0.7
        elif up_count > down_count and overall_change > 0:
            pattern = "volatile_uptrend"
            description = "波动上涨，价格震荡中走高"
            confidence = 0.6
        elif down_count > up_count and overall_change < 0:
            pattern = "volatile_downtrend"
            description = "波动下跌，价格震荡中走低"
            confidence = 0.6
        else:
            pattern = "volatile"
            description = "高波动性，价格走势不明确"
            confidence = 0.5
        
        return {
            "pattern": pattern,
            "confidence": confidence,
            "description": description,
            "overall_change_pct": overall_change,
            "up_periods": up_count,
            "down_periods": down_count
        }
    
    def analyze_volume_pattern(self, volume_data: List[Dict]) -> Dict:
        """
        分析交易量模式
        
        Args:
            volume_data: 交易量数据列表
            
        Returns:
            交易量模式分析结果
        """
        if not volume_data or len(volume_data) < 2:
            return {
                "pattern": "unknown",
                "confidence": 0,
                "description": "数据不足，无法分析交易量模式"
            }
        
        # 按时间排序
        sorted_data = sorted(volume_data, key=lambda x: x.get("timestamp", ""))
        
        # 提取交易量
        volumes = [item.get("volume_24h", 0) for item in sorted_data]
        
        # 计算平均交易量
        avg_volume = sum(volumes) / len(volumes)
        
        # 计算最新交易量与平均值的比例
        if avg_volume > 0:
            latest_ratio = volumes[-1] / avg_volume
        else:
            latest_ratio = 1
        
        # 计算交易量变化趋势
        volume_changes = [volumes[i] - volumes[i-1] for i in range(1, len(volumes))]
        increasing_count = sum(1 for change in volume_changes if change > 0)
        decreasing_count = sum(1 for change in volume_changes if change < 0)
        
        # 判断模式
        if latest_ratio > 3:
            pattern = "volume_explosion"
            description = "交易量爆发，远高于平均水平"
            confidence = min(0.9, 0.6 + latest_ratio / 10)
        elif latest_ratio > 2:
            pattern = "high_volume"
            description = "交易量明显高于平均水平"
            confidence = min(0.8, 0.5 + latest_ratio / 10)
        elif latest_ratio > 1.5:
            pattern = "increasing_volume"
            description = "交易量高于平均水平"
            confidence = 0.7
        elif latest_ratio < 0.5:
            pattern = "low_volume"
            description = "交易量明显低于平均水平"
            confidence = 0.7
        elif increasing_count > decreasing_count * 2:
            pattern = "volume_uptrend"
            description = "交易量持续增加"
            confidence = 0.6
        elif decreasing_count > increasing_count * 2:
            pattern = "volume_downtrend"
            description = "交易量持续减少"
            confidence = 0.6
        else:
            pattern = "normal_volume"
            description = "交易量处于正常水平"
            confidence = 0.5
        
        return {
            "pattern": pattern,
            "confidence": confidence,
            "description": description,
            "latest_volume": volumes[-1],
            "average_volume": avg_volume,
            "latest_to_average_ratio": latest_ratio
        }
    
    def analyze_anomaly_reasons(
        self, 
        anomaly: Dict, 
        price_data: List[Dict] = None,
        include_coin_info: bool = True
    ) -> Dict:
        """
        分析异动可能的原因
        
        Args:
            anomaly: 异常数据
            price_data: 价格历史数据
            include_coin_info: 是否包含币种信息
            
        Returns:
            异动原因分析结果
        """
        # 获取异常类型和币种
        anomaly_type = anomaly.get("type", "unknown")
        symbol = anomaly.get("symbol", "")
        
        # 初始化结果
        result = {
            "symbol": symbol,
            "anomaly_type": anomaly_type,
            "possible_reasons": [],
            "confidence_levels": {},
            "news_sentiment": {},
            "price_pattern": {},
            "volume_pattern": {},
            "is_trending": False
        }
        
        # 获取币种新闻
        news = self.get_coin_news(symbol)
        
        # 分析新闻情感
        sentiment = self.analyze_news_sentiment(news)
        result["news_sentiment"] = sentiment
        
        # 检查是否为热门币种
        trending_coins = self.get_trending_coins()
        coin_name = symbol.split('_')[0].upper()
        if coin_name in trending_coins:
            result["is_trending"] = True
        
        # 分析价格模式
        if price_data:
            price_pattern = self.analyze_price_pattern(price_data)
            result["price_pattern"] = price_pattern
            
            # 分析交易量模式
            volume_pattern = self.analyze_volume_pattern(price_data)
            result["volume_pattern"] = volume_pattern
        
        # 根据异常类型确定可能的原因
        if anomaly_type == "price":
            change_pct = anomaly.get("price_change_pct", 0)
            
            # 价格上涨
            if change_pct > 0:
                # 添加可能的原因
                reasons = []
                confidence = {}
                
                # 基于新闻情感
                if sentiment["sentiment"] == "positive":
                    reasons.append("积极新闻推动价格上涨")
                    confidence["积极新闻推动价格上涨"] = min(0.8, 0.5 + sentiment["score"])
                
                # 基于热门趋势
                if result["is_trending"]:
                    reasons.append("币种处于热门趋势")
                    confidence["币种处于热门趋势"] = 0.7
                
                # 基于交易量
                if "volume_pattern" in result:
                    volume_pattern = result["volume_pattern"]["pattern"]
                    if volume_pattern in ["volume_explosion", "high_volume"]:
                        reasons.append("大量买入推动价格上涨")
                        confidence["大量买入推动价格上涨"] = result["volume_pattern"]["confidence"]
                
                # 添加通用原因
                reasons.extend([
                    "可能有大型机构或鲸鱼增持",
                    "市场情绪积极",
                    "技术面突破关键阻力位"
                ])
                confidence["可能有大型机构或鲸鱼增持"] = 0.5
                confidence["市场情绪积极"] = 0.5
                confidence["技术面突破关键阻力位"] = 0.5
                
                result["possible_reasons"] = reasons
                result["confidence_levels"] = confidence
            
            # 价格下跌
            else:
                # 添加可能的原因
                reasons = []
                confidence = {}
                
                # 基于新闻情感
                if sentiment["sentiment"] == "negative":
                    reasons.append("负面新闻导致价格下跌")
                    confidence["负面新闻导致价格下跌"] = min(0.8, 0.5 + abs(sentiment["score"]))
                
                # 基于交易量
                if "volume_pattern" in result:
                    volume_pattern = result["volume_pattern"]["pattern"]
                    if volume_pattern in ["volume_explosion", "high_volume"]:
                        reasons.append("大量抛售导致价格下跌")
                        confidence["大量抛售导致价格下跌"] = result["volume_pattern"]["confidence"]
                
                # 添加通用原因
                reasons.extend([
                    "可能有大型持币者减持",
                    "市场情绪消极",
                    "技术面跌破关键支撑位"
                ])
                confidence["可能有大型持币者减持"] = 0.5
                confidence["市场情绪消极"] = 0.5
                confidence["技术面跌破关键支撑位"] = 0.5
                
                result["possible_reasons"] = reasons
                result["confidence_levels"] = confidence
        
        # 交易量异常
        elif anomaly_type == "volume":
            # 添加可能的原因
            reasons = []
            confidence = {}
            
            # 基于新闻
            if news:
                reasons.append("重要新闻引发交易热潮")
                confidence["重要新闻引发交易热潮"] = 0.7
            
            # 基于热门趋势
            if result["is_trending"]:
                reasons.append("币种处于热门趋势，吸引大量交易")
                confidence["币种处于热门趋势，吸引大量交易"] = 0.7
            
            # 基于价格模式
            if "price_pattern" in result:
                price_pattern = result["price_pattern"]["pattern"]
                if price_pattern in ["strong_uptrend", "uptrend"]:
                    reasons.append("价格上涨吸引更多交易者参与")
                    confidence["价格上涨吸引更多交易者参与"] = result["price_pattern"]["confidence"]
                elif price_pattern in ["strong_downtrend", "downtrend"]:
                    reasons.append("价格下跌引发恐慌性交易")
                    confidence["价格下跌引发恐慌性交易"] = result["price_pattern"]["confidence"]
            
            # 添加通用原因
            reasons.extend([
                "可能有大型交易或机构参与",
                "市场流动性突然增加",
                "交易所活动或促销"
            ])
            confidence["可能有大型交易或机构参与"] = 0.6
            confidence["市场流动性突然增加"] = 0.5
            confidence["交易所活动或促销"] = 0.4
            
            result["possible_reasons"] = reasons
            result["confidence_levels"] = confidence
        
        # 如果需要包含币种信息
        if include_coin_info:
            coin_info = self.coin_info.get_comprehensive_coin_info(symbol)
            result["coin_info"] = coin_info
        
        return result
    
    def format_analysis_message(self, analysis: Dict) -> str:
        """
        格式化分析消息
        
        Args:
            analysis: 分析结果
            
        Returns:
            格式化后的消息
        """
        # 提取信息
        symbol = analysis.get("symbol", "")
        anomaly_type = analysis.get("anomaly_type", "")
        possible_reasons = analysis.get("possible_reasons", [])
        news_sentiment = analysis.get("news_sentiment", {})
        price_pattern = analysis.get("price_pattern", {})
        volume_pattern = analysis.get("volume_pattern", {})
        is_trending = analysis.get("is_trending", False)
        coin_info = analysis.get("coin_info", {})
        
        # 构建消息标题
        if anomaly_type == "price":
            title = f"📊 {symbol} 价格异动分析"
        elif anomaly_type == "volume":
            title = f"📊 {symbol} 交易量异动分析"
        else:
            title = f"📊 {symbol} 异动分析"
        
        # 构建消息内容
        message_parts = [title, ""]
        
        # 添加可能原因
        message_parts.append("🔍 可能原因:")
        for i, reason in enumerate(possible_reasons[:5], 1):
            message_parts.append(f"{i}. {reason}")
        
        # 添加市场情绪
        if news_sentiment:
            message_parts.append("")
            message_parts.append("📰 市场情绪:")
            
            sentiment = news_sentiment.get("sentiment", "")
            if sentiment == "positive":
                message_parts.append("积极 (有利好消息)")
            elif sentiment == "negative":
                message_parts.append("消极 (有利空消息)")
            else:
                message_parts.append("中性 (无明显情绪)")
        
        # 添加价格模式
        if price_pattern:
            message_parts.append("")
            message_parts.append("📈 价格模式:")
            message_parts.append(price_pattern.get("description", "未知"))
        
        # 添加交易量模式
        if volume_pattern:
            message_parts.append("")
            message_parts.append("📊 交易量模式:")
            message_parts.append(volume_pattern.get("description", "未知"))
        
        # 添加热门趋势
        if is_trending:
            message_parts.append("")
            message_parts.append("🔥 该币种目前处于热门趋势")
        
        # 添加币种信息
        if coin_info:
            message_parts.append("")
            message_parts.append("💎 币种信息:")
            
            # 添加名称
            name = coin_info.get("name", symbol.split('_')[0])
            message_parts.append(f"名称: {name}")
            
            # 添加市场数据
            market_data = coin_info.get("market_data", {})
            if "market_cap" in market_data:
                market_cap = market_data["market_cap"]
                if market_cap >= 1_000_000_000:
                    market_cap_str = f"${market_cap / 1_000_000_000:.2f}B"
                elif market_cap >= 1_000_000:
                    market_cap_str = f"${market_cap / 1_000_000:.2f}M"
                else:
                    market_cap_str = f"${market_cap:.2f}"
                message_parts.append(f"市值: {market_cap_str}")
            
            # 添加社交媒体链接
            social_links = coin_info.get("social_links", {})
            if social_links:
                message_parts.append("")
                message_parts.append("🔗 社交媒体:")
                
                if "website" in social_links:
                    message_parts.append(f"官网: {social_links['website']}")
                
                if "twitter" in social_links:
                    message_parts.append(f"Twitter: {social_links['twitter']}")
                
                if "telegram" in social_links:
                    message_parts.append(f"Telegram: {social_links['telegram']}")
        
        # 合并消息
        return "\n".join(message_parts)


if __name__ == "__main__":
    # 测试代码
    
    # 创建增强版异动原因分析器
    analyzer = EnhancedReasonAnalyzer()
    
    # 测试异常数据
    test_anomaly = {
        "type": "price",
        "symbol": "BTC_USDT",
        "current_price": 50000,
        "reference_price": 45000,
        "price_change_pct": 11.11,
        "volume_24h": 1000000,
        "detected_at": datetime.now().isoformat()
    }
    
    # 生成测试价格数据
    now = datetime.now()
    test_data = []
    for i in range(24):
        timestamp = (now - timedelta(hours=24-i)).isoformat()
        price = 45000 + 5000 * (i / 24)
        volume = 1000000 + 500000 * (i / 24)
        test_data.append({
            "timestamp": timestamp,
            "price": price,
            "volume_24h": volume
        })
    
    # 测试分析异动原因
    print("分析异动原因...")
    analysis = analyzer.analyze_anomaly_reasons(test_anomaly, test_data)
    
    print(f"可能的原因: {analysis['possible_reasons']}")
    print(f"新闻情感: {analysis['news_sentiment']}")
    print(f"价格模式: {analysis['price_pattern']}")
    print(f"交易量模式: {analysis['volume_pattern']}")
    print(f"是否热门: {analysis['is_trending']}")
    
    # 测试格式化消息
    print("\n格式化后的消息:")
    formatted_message = analyzer.format_analysis_message(analysis)
    print(formatted_message)
    
    print("\n测试完成!")
