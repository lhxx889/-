#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
API管理器模块 - Gate.io加密货币异动监控系统
管理API地址，支持主地址、备用地址和自定义地址的切换
"""

import os
import sys
import json
import time
import logging
import requests
from typing import List, Dict, Any, Optional

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import PRIMARY_API_URL, BACKUP_API_URLS, API_RATE_LIMIT, API_RATE_WINDOW, DATA_DIR

logger = logging.getLogger("api_manager")

class APIManager:
    """API管理器类"""
    
    def __init__(self):
        self.primary_url = PRIMARY_API_URL
        self.backup_urls = BACKUP_API_URLS.copy()
        self.current_url = self.primary_url
        self.custom_urls = []
        self.request_times = []  # 用于速率限制
        self.rate_limit = API_RATE_LIMIT
        self.rate_window = API_RATE_WINDOW
        
        # 加载自定义API地址
        self.load_custom_urls()
        
        # 测试当前API地址，如果不可用则切换
        if not self.test_connection():
            self.switch_to_available()
        
        logger.info(f"API管理器初始化完成，当前API地址: {self.current_url}")
    
    def load_custom_urls(self):
        """加载自定义API地址"""
        try:
            file_path = os.path.join(DATA_DIR, "custom_api_urls.json")
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        self.custom_urls = data
                        logger.info(f"已加载{len(self.custom_urls)}个自定义API地址")
        except Exception as e:
            logger.error(f"加载自定义API地址失败: {e}")
    
    def save_custom_urls(self):
        """保存自定义API地址"""
        try:
            file_path = os.path.join(DATA_DIR, "custom_api_urls.json")
            with open(file_path, 'w') as f:
                json.dump(self.custom_urls, f)
            logger.info(f"已保存{len(self.custom_urls)}个自定义API地址")
        except Exception as e:
            logger.error(f"保存自定义API地址失败: {e}")
    
    def add_custom_url(self, url: str) -> bool:
        """添加自定义API地址"""
        url = url.strip()
        if not url:
            return False
        
        # 检查是否已存在
        if url in self.custom_urls or url == self.primary_url or url in self.backup_urls:
            return False
        
        # 测试URL是否可用
        if not self.test_url(url):
            logger.warning(f"添加的API地址不可用: {url}")
            return False
        
        self.custom_urls.append(url)
        self.save_custom_urls()
        logger.info(f"已添加自定义API地址: {url}")
        return True
    
    def remove_custom_url(self, url: str) -> bool:
        """删除自定义API地址"""
        if url in self.custom_urls:
            self.custom_urls.remove(url)
            self.save_custom_urls()
            
            # 如果删除的是当前使用的URL，则切换到可用地址
            if url == self.current_url:
                self.switch_to_available()
            
            logger.info(f"已删除自定义API地址: {url}")
            return True
        return False
    
    def get_custom_urls(self) -> List[str]:
        """获取自定义API地址列表"""
        return self.custom_urls.copy()
    
    def switch_to_primary(self) -> bool:
        """切换到主API地址"""
        if self.test_url(self.primary_url):
            self.current_url = self.primary_url
            logger.info(f"已切换到主API地址: {self.current_url}")
            return True
        else:
            logger.warning(f"主API地址不可用: {self.primary_url}")
            return False
    
    def switch_to_url(self, url: str) -> bool:
        """切换到指定API地址"""
        if self.test_url(url):
            self.current_url = url
            logger.info(f"已切换到API地址: {self.current_url}")
            return True
        else:
            logger.warning(f"API地址不可用: {url}")
            return False
    
    def switch_to_available(self) -> bool:
        """切换到可用的API地址"""
        # 先尝试主地址
        if self.test_url(self.primary_url):
            self.current_url = self.primary_url
            logger.info(f"已切换到主API地址: {self.current_url}")
            return True
        
        # 再尝试备用地址
        for url in self.backup_urls:
            if self.test_url(url):
                self.current_url = url
                logger.info(f"已切换到备用API地址: {self.current_url}")
                return True
        
        # 最后尝试自定义地址
        for url in self.custom_urls:
            if self.test_url(url):
                self.current_url = url
                logger.info(f"已切换到自定义API地址: {self.current_url}")
                return True
        
        logger.error("没有找到可用的API地址")
        return False
    
    def test_connection(self) -> bool:
        """测试当前API地址连接"""
        return self.test_url(self.current_url)
    
    def test_url(self, url: str) -> bool:
        """测试指定API地址是否可用"""
        try:
            response = requests.get(f"{url}/spot/currencies", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"测试API地址失败: {url}, 错误: {e}")
            return False
    
    def check_rate_limit(self):
        """检查并处理速率限制"""
        now = time.time()
        
        # 清理过期的请求时间
        self.request_times = [t for t in self.request_times if now - t < self.rate_window]
        
        # 检查是否超过速率限制
        if len(self.request_times) >= self.rate_limit:
            # 计算需要等待的时间
            wait_time = self.rate_window - (now - self.request_times[0])
            if wait_time > 0:
                logger.warning(f"达到速率限制，等待{wait_time:.2f}秒")
                time.sleep(wait_time)
                # 重新清理过期的请求时间
                now = time.time()
                self.request_times = [t for t in self.request_times if now - t < self.rate_window]
        
        # 记录本次请求时间
        self.request_times.append(now)
    
    def request(self, method: str, endpoint: str, params: Dict[str, Any] = None, data: Dict[str, Any] = None) -> Any:
        """发送API请求"""
        # 检查速率限制
        self.check_rate_limit()
        
        url = f"{self.current_url}{endpoint}"
        
        try:
            if method.upper() == "GET":
                response = requests.get(url, params=params, timeout=10)
            elif method.upper() == "POST":
                response = requests.post(url, json=data, timeout=10)
            else:
                logger.error(f"不支持的请求方法: {method}")
                return None
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"API请求失败: {url}, 状态码: {response.status_code}, 响应: {response.text}")
                return None
        except Exception as e:
            logger.error(f"API请求出错: {url}, 错误: {e}")
            
            # 如果当前API地址不可用，尝试切换到可用地址
            if not self.test_connection():
                logger.warning("当前API地址不可用，尝试切换到可用地址")
                self.switch_to_available()
            
            return None

# 单例模式
_api_manager = None

def get_api_manager() -> APIManager:
    """获取API管理器实例"""
    global _api_manager
    if _api_manager is None:
        _api_manager = APIManager()
    return _api_manager
