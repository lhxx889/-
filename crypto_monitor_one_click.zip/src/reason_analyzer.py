#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
异动原因分析模块 - Gate.io加密货币异动监控系统
"""

import os
import json
import logging
import requests
import time
import sys
from typing import Dict, List, Any, Optional
from datetime import datetime

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import (
    LOG_LEVEL, LOG_FILE, DATA_DIR
)

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("reason_analyzer")

class ReasonAnalyzer:
    """异动原因分析器"""
    
    def __init__(self):
        # 创建缓存目录
        self.cache_dir = os.path.join(DATA_DIR, "reason_cache")
        os.makedirs(self.cache_dir, exist_ok=True)
    
    def analyze_abnormal_movement(self, abnormal: Dict) -> Dict:
        """分析异常波动原因"""
        currency_pair = abnormal.get("currency_pair", "")
        price_change_pct = abnormal.get("price_change_pct", 0)
        volume_change_pct = abnormal.get("volume_change_pct", 0)
        
        # 获取币种
        currency = currency_pair.split("_")[0] if "_" in currency_pair else currency_pair
        
        # 分析结果
        analysis = {
            "currency": currency,
            "currency_pair": currency_pair,
            "timestamp": datetime.now().isoformat(),
            "possible_reasons": [],
            "confidence": 0,
            "market_sentiment": "neutral",
            "related_news": []
        }
        
        # 根据价格和交易量变化分析可能原因
        if price_change_pct >= 45 and volume_change_pct >= 200:
            # 价格大幅上涨且交易量猛增
            analysis["possible_reasons"].append("可能有重大利好消息或大额买入")
            analysis["confidence"] = 0.8
            analysis["market_sentiment"] = "极度看涨"
        elif price_change_pct >= 45 and volume_change_pct < 100:
            # 价格大幅上涨但交易量变化不大
            analysis["possible_reasons"].append("可能是市场投机行为或短期炒作")
            analysis["confidence"] = 0.6
            analysis["market_sentiment"] = "看涨"
        elif price_change_pct <= -45 and volume_change_pct >= 200:
            # 价格大幅下跌且交易量猛增
            analysis["possible_reasons"].append("可能有重大利空消息或大额抛售")
            analysis["confidence"] = 0.8
            analysis["market_sentiment"] = "极度看跌"
        elif price_change_pct <= -45 and volume_change_pct < 100:
            # 价格大幅下跌但交易量变化不大
            analysis["possible_reasons"].append("可能是市场恐慌情绪或技术性回调")
            analysis["confidence"] = 0.6
            analysis["market_sentiment"] = "看跌"
        elif volume_change_pct >= 300:
            # 交易量极度放大
            analysis["possible_reasons"].append("可能有大型机构或鲸鱼参与交易")
            analysis["confidence"] = 0.7
            analysis["market_sentiment"] = "波动加剧"
        
        # 搜索相关新闻
        news = self.search_related_news(currency)
        if news:
            analysis["related_news"] = news
            
            # 根据新闻调整分析结果
            if len(news) > 0:
                analysis["possible_reasons"].append("可能与最新新闻相关")
                analysis["confidence"] = min(analysis["confidence"] + 0.1, 1.0)
        
        # 保存分析结果
        self.save_analysis(currency_pair, analysis)
        
        return analysis
    
    def search_related_news(self, currency: str) -> List[Dict]:
        """搜索相关新闻"""
        # 这部分需要通过新闻API或网页爬取获取
        # 由于没有直接的新闻API，这里返回空结果
        return []
    
    def save_analysis(self, currency_pair: str, analysis: Dict):
        """保存分析结果"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            file_path = os.path.join(self.cache_dir, f"{currency_pair}_{timestamp}.json")
            with open(file_path, 'w') as f:
                json.dump(analysis, f)
            logger.info(f"已保存分析结果: {file_path}")
        except Exception as e:
            logger.error(f"保存分析结果失败: {e}")
    
    def format_reason_message(self, abnormal: Dict, analysis: Dict) -> str:
        """格式化原因分析消息"""
        currency_pair = abnormal.get("currency_pair", "")
        price_change_pct = abnormal.get("price_change_pct", 0)
        volume_change_pct = abnormal.get("volume_change_pct", 0)
        
        # 判断价格变化方向
        price_direction = "上涨" if abnormal.get("current_price", 0) > abnormal.get("previous_price", 0) else "下跌"
        
        # 判断市场情绪
        sentiment = analysis.get("market_sentiment", "neutral")
        sentiment_emoji = "🔥" if sentiment == "极度看涨" else "📈" if sentiment == "看涨" else "📉" if sentiment == "看跌" else "❄️" if sentiment == "极度看跌" else "⚖️"
        
        # 格式化消息
        message = f"""
<b>🔍 {currency_pair} 异动原因分析</b>

<b>市场情绪:</b> {sentiment_emoji} {sentiment}

<b>可能原因:</b>
"""
        
        for reason in analysis.get("possible_reasons", []):
            message += f"• {reason}\n"
        
        message += f"\n<b>分析置信度:</b> {analysis.get('confidence', 0) * 100:.0f}%"
        
        # 添加相关新闻
        if analysis.get("related_news"):
            message += "\n\n<b>相关新闻:</b>\n"
            for news in analysis.get("related_news")[:3]:  # 最多显示3条新闻
                message += f"• {news.get('title', '')}\n"
        
        # 添加技术分析
        message += f"""
<b>技术分析:</b>
• 价格变化: {price_direction} {price_change_pct:.2f}%
• 交易量变化: 增加 {volume_change_pct:.2f}%
• 波动强度: {"极高" if price_change_pct > 60 or volume_change_pct > 300 else "高" if price_change_pct > 45 or volume_change_pct > 200 else "中等"}
"""
        
        return message

def main():
    """主函数 - 用于测试"""
    logger.info("异动原因分析模块测试")
    
    analyzer = ReasonAnalyzer()
    
    # 测试分析异常波动
    abnormal = {
        "currency_pair": "BTC_USDT",
        "current_price": 50000,
        "previous_price": 30000,
        "price_change_pct": 66.67,
        "current_volume": 1000000,
        "previous_volume": 300000,
        "volume_change_pct": 233.33,
        "reasons": ["价格上涨66.67%", "交易量增加233.33%"],
        "timestamp": datetime.now().isoformat()
    }
    
    analysis = analyzer.analyze_abnormal_movement(abnormal)
    print("分析结果:")
    print(json.dumps(analysis, indent=2))
    
    # 测试格式化消息
    message = analyzer.format_reason_message(abnormal, analysis)
    print("\n格式化消息:")
    print(message)

if __name__ == "__main__":
    main()
