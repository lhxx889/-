#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
主程序 - Gate.io加密货币异动监控系统
"""

import os
import sys
import time
import json
import logging
import requests
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional

# 导入配置
from config import (
    API_BASE_URL, CHECK_INTERVAL, PRICE_CHANGE_THRESHOLD, 
    VOLUME_SURGE_THRESHOLD, CONTINUOUS_RUN, LOG_LEVEL, LOG_FILE,
    API_RATE_LIMIT, API_RATE_WINDOW, DATA_DIR
)

# 确保数据目录存在
os.makedirs(DATA_DIR, exist_ok=True)

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("crypto_monitor")

class RateLimiter:
    """API请求速率限制器"""
    
    def __init__(self, limit: int, window: int):
        self.limit = limit  # 窗口期内最大请求数
        self.window = window  # 窗口期（秒）
        self.timestamps = []  # 请求时间戳列表
    
    def can_request(self) -> bool:
        """检查是否可以发送请求"""
        now = time.time()
        # 移除窗口期外的时间戳
        self.timestamps = [ts for ts in self.timestamps if now - ts < self.window]
        # 检查是否达到限制
        return len(self.timestamps) < self.limit
    
    def add_request(self):
        """记录一次请求"""
        self.timestamps.append(time.time())
    
    def wait_if_needed(self):
        """如果达到限制，等待到可以请求为止"""
        while not self.can_request():
            time.sleep(0.1)
        self.add_request()

class GateioAPI:
    """Gate.io API接口封装"""
    
    def __init__(self):
        self.base_url = API_BASE_URL
        self.rate_limiter = RateLimiter(API_RATE_LIMIT, API_RATE_WINDOW)
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
    
    def _request(self, method: str, endpoint: str, params: Dict = None) -> Any:
        """发送API请求"""
        self.rate_limiter.wait_if_needed()
        url = f"{self.base_url}{endpoint}"
        try:
            response = self.session.request(method, url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求错误: {e}")
            return None
    
    def get_currencies(self) -> List[Dict]:
        """获取所有币种信息"""
        return self._request("GET", "/spot/currencies")
    
    def get_currency(self, currency: str) -> Dict:
        """获取单个币种信息"""
        return self._request("GET", f"/spot/currencies/{currency}")
    
    def get_tickers(self, currency_pair: str = None) -> List[Dict]:
        """获取交易对Ticker信息"""
        params = {}
        if currency_pair:
            params["currency_pair"] = currency_pair
        return self._request("GET", "/spot/tickers", params)
    
    def get_pairs(self) -> List[Dict]:
        """获取所有交易对"""
        return self._request("GET", "/spot/currency_pairs")

class DataManager:
    """数据管理器"""
    
    def __init__(self):
        self.api = GateioAPI()
        self.previous_data = {}  # 上一次的数据
        self.current_data = {}   # 当前数据
        self.alerts = []         # 异动警报
    
    def load_previous_data(self):
        """加载上一次的数据"""
        try:
            file_path = os.path.join(DATA_DIR, "previous_tickers.json")
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    self.previous_data = json.load(f)
                logger.info(f"已加载上一次数据，共{len(self.previous_data)}个交易对")
            else:
                logger.info("未找到上一次数据，将在本次运行后创建")
        except Exception as e:
            logger.error(f"加载上一次数据失败: {e}")
    
    def save_current_data(self):
        """保存当前数据作为下一次的上一次数据"""
        try:
            file_path = os.path.join(DATA_DIR, "previous_tickers.json")
            with open(file_path, 'w') as f:
                json.dump(self.current_data, f)
            logger.info(f"已保存当前数据，共{len(self.current_data)}个交易对")
        except Exception as e:
            logger.error(f"保存当前数据失败: {e}")
    
    def fetch_all_tickers(self):
        """获取所有交易对的Ticker信息"""
        tickers = self.api.get_tickers()
        if tickers:
            # 将列表转换为以currency_pair为键的字典
            self.current_data = {ticker["currency_pair"]: ticker for ticker in tickers}
            logger.info(f"已获取{len(self.current_data)}个交易对的Ticker信息")
            return True
        else:
            logger.error("获取Ticker信息失败")
            return False
    
    def detect_abnormal_movements(self):
        """检测异常波动"""
        if not self.previous_data:
            logger.info("没有上一次数据，无法检测异常波动")
            return []
        
        abnormal = []
        for pair, current in self.current_data.items():
            if pair not in self.previous_data:
                continue
            
            previous = self.previous_data[pair]
            
            # 计算价格变化百分比
            try:
                prev_price = float(previous.get("last", 0))
                curr_price = float(current.get("last", 0))
                if prev_price > 0:
                    price_change_pct = abs((curr_price - prev_price) / prev_price * 100)
                else:
                    price_change_pct = 0
                
                # 计算交易量变化百分比
                prev_volume = float(previous.get("base_volume", 0))
                curr_volume = float(current.get("base_volume", 0))
                if prev_volume > 0:
                    volume_change_pct = abs((curr_volume - prev_volume) / prev_volume * 100)
                else:
                    volume_change_pct = 0
                
                # 检测异常
                is_abnormal = False
                reasons = []
                
                if price_change_pct >= PRICE_CHANGE_THRESHOLD:
                    is_abnormal = True
                    direction = "上涨" if curr_price > prev_price else "下跌"
                    reasons.append(f"价格{direction}{price_change_pct:.2f}%")
                
                if volume_change_pct >= VOLUME_SURGE_THRESHOLD:
                    is_abnormal = True
                    direction = "增加" if curr_volume > prev_volume else "减少"
                    reasons.append(f"交易量{direction}{volume_change_pct:.2f}%")
                
                if is_abnormal:
                    abnormal.append({
                        "currency_pair": pair,
                        "current_price": curr_price,
                        "previous_price": prev_price,
                        "price_change_pct": price_change_pct,
                        "current_volume": curr_volume,
                        "previous_volume": prev_volume,
                        "volume_change_pct": volume_change_pct,
                        "reasons": reasons,
                        "timestamp": datetime.now().isoformat()
                    })
            except (ValueError, TypeError) as e:
                logger.error(f"处理交易对{pair}时出错: {e}")
        
        logger.info(f"检测到{len(abnormal)}个异常波动")
        return abnormal

def main():
    """主函数"""
    logger.info("Gate.io加密货币异动监控系统启动")
    
    # 创建数据管理器
    data_manager = DataManager()
    
    # 加载上一次数据
    data_manager.load_previous_data()
    
    try:
        while True:
            logger.info(f"开始新一轮检查，时间: {datetime.now().isoformat()}")
            
            # 获取所有交易对的Ticker信息
            if data_manager.fetch_all_tickers():
                # 检测异常波动
                abnormal = data_manager.detect_abnormal_movements()
                
                # 保存当前数据作为下一次的上一次数据
                data_manager.save_current_data()
                
                # 输出异常波动信息
                if abnormal:
                    for item in abnormal:
                        logger.info(f"异常波动: {item['currency_pair']}, 原因: {', '.join(item['reasons'])}")
                    
                    # 保存异常波动信息
                    try:
                        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                        file_path = os.path.join(DATA_DIR, f"abnormal_{timestamp}.json")
                        with open(file_path, 'w') as f:
                            json.dump(abnormal, f)
                        logger.info(f"已保存异常波动信息到{file_path}")
                    except Exception as e:
                        logger.error(f"保存异常波动信息失败: {e}")
            
            # 如果不是持续运行，则退出
            if not CONTINUOUS_RUN:
                break
            
            # 等待下一次检查
            logger.info(f"等待{CHECK_INTERVAL}秒后进行下一次检查")
            time.sleep(CHECK_INTERVAL)
    
    except KeyboardInterrupt:
        logger.info("收到中断信号，程序退出")
    except Exception as e:
        logger.error(f"程序运行出错: {e}")
    finally:
        logger.info("Gate.io加密货币异动监控系统关闭")

if __name__ == "__main__":
    main()
