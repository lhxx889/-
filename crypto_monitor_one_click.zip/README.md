# Gate.io加密货币异动监控系统

一个实时监控Gate.io交易所加密货币价格和交易量异动的自动化工具，支持动态切换监控网址和添加备用网址。

## 功能特点

1. **实时监控**：每50秒检查一次Gate.io所有加密货币的价格和交易量变化
2. **智能检测**：自动识别价格波动超过45%或交易量猛增的异常情况
3. **即时推送**：通过Telegram机器人实时推送异动警报
4. **深度分析**：提供异动可能原因的智能分析
5. **详细信息**：自动查询并推送币种的市值、持币人数、简介和社交媒体链接等信息
6. **交互式菜单**：运行时可通过交互式菜单动态切换监控网址和管理备用网址
7. **多地址容灾**：支持主API地址、备用API地址和自定义API地址，自动切换确保系统稳定性

## 系统要求

- Python 3.6或更高版本
- Linux操作系统
- 网络连接
- Telegram账号（用于接收推送消息）

## 快速安装

使用一键安装脚本（仅支持Linux系统）：

```bash
curl -sSL https://raw.githubusercontent.com/用户名/crypto_monitor/main/install.sh | bash
```

或者手动安装：

```bash
# 克隆仓库
git clone https://github.com/用户名/crypto_monitor.git
cd crypto_monitor

# 安装依赖
pip install -r requirements.txt

# 运行程序
python src/main.py
```

## 使用方法

1. 配置Telegram机器人：
   - 编辑 `src/config.py` 文件，填入您的Telegram Bot Token
   - 或在首次运行时按提示输入

2. 启动监控系统：
   ```
   python src/main.py
   ```

3. 首次运行时，系统会提示您：
   - 输入Telegram Bot Token（如果配置文件中未设置）
   - 输入Telegram Chat ID（群组ID或频道用户名）

4. 系统启动后，会自动：
   - 连接Gate.io API获取所有币种信息
   - 每50秒检查一次价格和交易量变化
   - 检测到异动时通过Telegram推送警报

5. 交互式菜单使用：
   - 系统运行后会显示交互式菜单
   - 可通过菜单查看、切换和管理API地址
   - 可暂停/恢复监控或安全退出程序

## 交互式菜单选项

- **查看所有可用API地址**：显示所有配置的API地址
- **切换到主API地址**：将当前使用的API地址切换为主地址
- **切换到备用API地址**：从备用地址列表中选择一个进行切换
- **添加自定义API地址**：添加新的自定义API地址
- **删除自定义API地址**：删除已添加的自定义API地址
- **测试当前API地址连接**：测试当前API地址的连接状态
- **暂停/恢复监控**：临时暂停或恢复监控功能
- **退出菜单**：退出菜单但继续监控
- **退出程序**：安全退出整个程序

## 配置说明

系统配置文件位于 `src/config.py`，主要配置项包括：

- `PRIMARY_API_URL`：主要API地址
- `BACKUP_API_URLS`：备用API地址列表
- `PRICE_CHANGE_THRESHOLD`：价格波动阈值（百分比），默认为45.0
- `VOLUME_SURGE_THRESHOLD`：交易量猛增阈值（百分比），默认为200.0
- `CHECK_INTERVAL`：检查间隔（秒），默认为50
- `CONTINUOUS_RUN`：是否持续运行，默认为True
- `TELEGRAM_BOT_TOKEN`：Telegram机器人Token
- `TELEGRAM_CHAT_ID`：Telegram聊天ID（群组ID或频道用户名）

## 目录结构

```
crypto_monitor/
├── data/                  # 数据存储目录
├── src/                   # 源代码目录
│   ├── api_manager.py     # API管理器模块
│   ├── config.py          # 配置文件
│   ├── interactive_menu.py # 交互式菜单模块
│   ├── main.py            # 主程序
│   ├── reason_analyzer.py # 异动原因分析模块
│   ├── telegram_notifier.py # Telegram推送模块
│   └── token_details.py   # 币种详情查询模块
├── tests/                 # 测试目录
│   └── test_system.py     # 系统测试脚本
├── install.sh             # 一键安装脚本
├── requirements.txt       # 依赖项列表
└── README.md              # 说明文档
```

## 常见问题

1. **问题**：系统无法连接Gate.io API
   **解决方案**：使用交互式菜单切换到备用API地址或添加自定义API地址

2. **问题**：Telegram消息推送失败
   **解决方案**：
   - 确认Bot Token是否正确
   - 确认Chat ID是否正确
   - 确保机器人已被添加到指定的群组或频道中
   - 如果是频道，确保机器人具有发送消息的权限

3. **问题**：未检测到异常波动
   **解决方案**：这可能是正常的，因为市场可能没有大幅波动。您可以临时降低配置文件中的阈值进行测试。

## 贡献

欢迎提交问题和拉取请求，共同改进这个项目。

## 许可证

MIT

## 联系与支持

如有任何问题或建议，请通过GitHub Issues联系我们。

---

最后更新：2025年5月24日
