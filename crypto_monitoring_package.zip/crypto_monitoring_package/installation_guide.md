# 加密货币监控系统一键安装指南

## 概述

本指南将帮助您快速部署完整的加密货币监控系统，包括API监控、网页爬虫和Telegram推送通知功能。通过一键安装脚本，您可以在几分钟内完成所有组件的安装和配置。

## 系统要求

- 操作系统：Ubuntu/Debian/CentOS/Fedora Linux
- Python 3.6+
- 至少1GB可用磁盘空间
- 互联网连接

## 安装步骤

### 1. 下载安装脚本

```bash
wget https://raw.githubusercontent.com/your-username/crypto-monitoring/main/install.sh
# 或者直接使用已下载的脚本
```

### 2. 设置执行权限

```bash
chmod +x install.sh
```

### 3. 运行安装脚本

```bash
sudo ./install.sh
```

> **注意**：安装过程中需要sudo权限来安装系统依赖和TA-Lib库。

### 4. 安装过程

安装脚本将自动执行以下操作：

1. 检查系统环境
2. 安装必要的系统依赖
3. 安装TA-Lib（技术分析库）
4. 创建项目目录结构
5. 复制所有必要的脚本文件
6. 安装Python依赖
7. 创建启动、停止和状态检查脚本

整个安装过程大约需要5-15分钟，具体时间取决于您的系统性能和网络速度。

## 安装后配置

### 获取Telegram Bot令牌

如果您计划使用Telegram推送通知功能，需要获取Telegram Bot API令牌：

1. 在Telegram中搜索 `@BotFather` 并开始对话
2. 发送 `/newbot` 命令创建新机器人
3. 按照提示设置机器人名称和用户名
4. 创建成功后，BotFather会提供一个API令牌

### 启动监控系统

```bash
cd ~/crypto_monitoring
./start_monitoring.sh -t <your_telegram_bot_token> -m full -b
```

参数说明：
- `-t, --telegram-token`：Telegram Bot API令牌
- `-m, --mode`：运行模式，可选值：api, web, telegram, full
- `-b, --background`：在后台运行

### 查看系统状态

```bash
./status_monitoring.sh
```

### 停止监控系统

```bash
./stop_monitoring.sh
```

## 常见问题

### 1. 安装过程中出现错误

如果安装过程中出现错误，请检查以下几点：

- 确保您有足够的磁盘空间
- 确保您的系统满足最低要求
- 检查网络连接是否正常
- 查看错误日志，通常位于安装目录下的`logs/`文件夹

### 2. 无法接收Telegram通知

如果您无法接收Telegram通知，请检查：

- 确保您已正确设置Telegram Bot令牌
- 确保您已在Telegram中与您的Bot进行了对话并发送了`/start`命令
- 检查`logs/telegram_notifier.log`文件中的错误信息

### 3. 如何自定义监控币种

编辑`notification/integrated_config.json`文件，修改`monitored_symbols`数组。

## 进阶使用

### 设置开机自启

您可以使用crontab设置开机自启：

```bash
crontab -e
```

添加以下行：

```
@reboot cd /path/to/crypto_monitoring && ./start_monitoring.sh -t <your_telegram_bot_token> -m full -b
```

### 自定义通知模板

如需自定义通知消息格式，可以修改`notification/telegram_notifier.py`文件中的相应方法。

## 支持与反馈

如有任何问题或需要进一步的帮助，请参考日志文件或联系系统管理员。
