#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
加密货币监控系统 v2.0
现代化的加密货币价格监控和公告扫描系统

主要改进:
- 模块化架构设计
- SQLite数据库存储
- Web界面管理
- 更好的错误处理
- 配置文件管理
- 异步处理支持
- VLESS 和 Hysteria2 代理支持
"""

import os
import sys
import logging
from pathlib import Path

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.core.config import Config
from app.core.database import Database
from app.core.monitor import CryptoMonitor
from app.core.proxy_manager import ProxyManager
from app.web.app import create_app

def setup_logging():
    """设置日志配置"""
    log_dir = PROJECT_ROOT / "logs"
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "crypto_monitor.log"),
            logging.StreamHandler()
        ]
    )

def main():
    """主函数"""
    setup_logging()
    logger = logging.getLogger(__name__)
    
    try:
        # 初始化配置
        config = Config()
        logger.info("配置加载完成")
        
        # 初始化数据库
        db = Database(config.database_path)
        db.init_database()
        db.init_proxy_tables()  # 初始化代理相关表
        logger.info("数据库初始化完成")
        
        # 初始化代理管理器
        proxy_manager = ProxyManager(config, db)
        logger.info("代理管理器初始化完成")
        
        # 创建监控器
        monitor = CryptoMonitor(config, db)
        monitor.set_proxy_manager(proxy_manager)  # 设置代理管理器
        
        # 启动Web应用
        app = create_app(config, monitor, proxy_manager)
        
        logger.info("启动Web服务器...")
        app.run(
            host='0.0.0.0',
            port=8080,  # 使用端口 8080 避免冲突
            debug=config.debug_mode
        )
        
    except KeyboardInterrupt:
        logger.info("程序被用户中断")
    except Exception as e:
        logger.error(f"程序启动失败: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

