
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Nekobox代理功能测试脚本
"""

import sys
import os
from pathlib import Path
import json

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

# Dummy classes for testing
class DummyConfig:
    def __init__(self):
        self._config = {}

    def get(self, key, default=None):
        keys = key.split(".")
        val = self._config
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val

    def set(self, key, value):
        keys = key.split(".")
        val = self._config
        for i, k in enumerate(keys):
            if i == len(keys) - 1:
                val[k] = value
            else:
                if k not in val or not isinstance(val[k], dict):
                    val[k] = {}
                val = val[k]

    def save(self):
        pass # Dummy save

    @property
    def database_path(self):
        return "dummy_db.sqlite"

    @property
    def nekobox_enabled(self):
        return self.get("proxy.nekobox.enabled", False)

    @property
    def nekobox_config(self):
        return self.get("proxy.nekobox", {})

class DummyDatabase:
    def __init__(self, db_path):
        self.db_path = db_path
        self.proxy_servers = []

    def add_proxy_server(self, protocol, server_id, name, config, priority, active):
        self.proxy_servers.append({
            "protocol": protocol,
            "server_id": server_id,
            "name": name,
            "config": config,
            "priority": priority,
            "active": active
        })

    def get_proxy_servers(self, protocol=None):
        if protocol:
            return [s for s in self.proxy_servers if s["protocol"] == protocol]
        return self.proxy_servers

def test_nekobox_detection():
    """测试Nekobox代理检测功能"""
    print("测试Nekobox代理检测功能...")
    try:
        from app.core.nekobox_proxy import NekoboxProxyManager
        
        nekobox_manager = NekoboxProxyManager(DummyConfig(), DummyDatabase("dummy.db"))
        
        # 测试端口检测
        print("  检测常见代理端口...")
        for port in nekobox_manager.COMMON_PORTS:
            is_open = nekobox_manager.is_port_open("127.0.0.1", port)
            print("    端口 " + str(port) + ": " + ("开放" if is_open else "关闭"))
        
        # 检测Nekobox代理
        print("  检测Nekobox代理...")
        proxies = nekobox_manager.detect_nekobox_proxies()
        
        if proxies:
            print("  ✅ 检测到 " + str(len(proxies)) + " 个代理:")
            for proxy in proxies:
                print("    - " + proxy["type"] + "://" + proxy["host"] + ":" + str(proxy["port"]) + " (" + proxy["status"] + ")")
        else:
            print("  ⚠️  未检测到Nekobox代理")
        
        return True
    except Exception as e:
        print("  ❌ 检测失败: " + str(e))
        return False

def test_nekobox_config():
    """测试Nekobox配置功能"""
    print("\n测试Nekobox配置功能...")
    try:
        from app.core.nekobox_proxy import NekoboxProxyManager
        
        nekobox_manager = NekoboxProxyManager(DummyConfig(), DummyDatabase("dummy.db"))
        
        # 测试自动检测配置
        print("  测试自动检测配置...")
        auto_config = nekobox_manager.get_proxy_config(auto_detect=True)
        if auto_config:
            print("  ✅ 自动配置成功: " + str(auto_config))
        else:
            print("  ⚠️  自动配置失败（可能没有运行Nekobox）")
        
        # 测试手动配置
        print("  测试手动配置...")
        manual_config = {
            "host": "127.0.0.1",
            "port": 7890,
            "protocol": "socks5"
        }
        
        manual_proxy_config = nekobox_manager.get_proxy_config(
            auto_detect=False, 
            manual_config=manual_config
        )
        
        if manual_proxy_config:
            print("  ✅ 手动配置成功: " + str(manual_proxy_config))
        else:
            print("  ⚠️  手动配置失败（端口可能未开放）")
        
        return True
    except Exception as e:
        print("  ❌ 配置测试失败: " + str(e))
        return False

def test_nekobox_integration():
    """测试Nekobox与系统集成"""
    print("\n测试Nekobox与系统集成...")
    try:
        from app.core.config import Config
        from app.core.api_client import ExchangeAPIManager
        
        # 创建配置并启用Nekobox
        config = DummyConfig()
        config.set("proxy.enabled", True)
        config.set("proxy.type", "nekobox")
        config.set("proxy.nekobox.enabled", True)
        config.set("proxy.nekobox.auto_detect", True)
        
        print("  测试API客户端Nekobox集成...")
        api_manager = ExchangeAPIManager(config)
        
        print("  ✅ API客户端创建成功")
        print("    支持的交易所: " + str(list(api_manager.clients.keys())))
        
        return True
    except Exception as e:
        print("  ❌ 集成测试失败: " + str(e))
        return False

def test_nekobox_api():
    """测试Nekobox Web API"""
    print("\n测试Nekobox Web API...")
    try:
        from app.core.config import Config
        from app.core.database import Database
        from app.core.monitor import CryptoMonitor
        from app.web.app import create_app
        
        config = DummyConfig()
        db = DummyDatabase("dummy.db")
        monitor = CryptoMonitor(config, db)
        app = create_app(config, monitor)
        
        with app.test_client() as client:
            # 测试Nekobox状态API
            print("  测试Nekobox状态API...")
            response = client.get("/api/nekobox/status")
            if response.status_code == 200:
                print("  ✅ 状态API正常")
            else:
                print("  ⚠️  状态API异常: " + str(response.status_code))
            
            # 测试Nekobox检测API
            print("  测试Nekobox检测API...")
            response = client.post("/api/nekobox/detect")
            if response.status_code == 200:
                print("  ✅ 检测API正常")
            else:
                print("  ⚠️  检测API异常: " + str(response.status_code))
        
        return True
    except Exception as e:
        print("  ❌ API测试失败: " + str(e))
        return False

def test_config_persistence():
    """测试配置持久化"""
    print("\n测试Nekobox配置持久化...")
    try:
        from app.core.config import Config
        
        # 创建配置实例
        config = DummyConfig()
        
        # 设置Nekobox配置
        config.set("proxy.nekobox.enabled", True)
        config.set("proxy.nekobox.auto_detect", False)
        config.set("proxy.nekobox.manual_config.host", "127.0.0.1")
        config.set("proxy.nekobox.manual_config.port", 7890)
        config.set("proxy.nekobox.manual_config.protocol", "socks5")
        
        # 保存配置
        config.save()
        print("  ✅ 配置保存成功")
        
        # 重新加载配置验证
        new_config = DummyConfig()
        nekobox_enabled = new_config.nekobox_enabled
        nekobox_config = new_config.nekobox_config
        
        print("  验证配置: enabled=" + str(nekobox_enabled))
        print("  验证配置: auto_detect=" + str(nekobox_config.get("auto_detect")))
        print("  验证配置: manual_config=" + str(nekobox_config.get("manual_config")))
        
        return True
    except Exception as e:
        print("  ❌ 配置持久化测试失败: " + str(e))
        return False

def main():
    """主测试函数"""
    print("🚀 开始Nekobox代理功能测试...")
    print("=" * 60)
    
    tests = [
        test_nekobox_detection,
        test_nekobox_config,
        test_nekobox_integration,
        test_nekobox_api,
        test_config_persistence
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print("\n" + "=" * 60)
    print("📊 Nekobox测试结果: " + str(passed) + "/" + str(total) + " 通过")
    
    if passed == total:
        print("🎉 所有Nekobox功能测试通过！")
        return 0
    else:
        print("⚠️  部分Nekobox功能测试失败")
        print("\n💡 提示:")
        print("- 如果检测失败，请确保Nekobox正在运行")
        print("- 检查Nekobox是否在常见端口(7890, 7891, 7892等)上监听")
        print("- 确认Nekobox配置了混合端口或SOCKS代理")
        return 1

if __name__ == "__main__":
    sys.exit(main())




