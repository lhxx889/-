#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io API轮询优化模块
功能：提供稳定的API轮询机制，包括错误重试、请求限流和负载均衡
"""

import time
import random
import logging
import requests
from datetime import datetime
from functools import wraps

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("api_client.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_api_client")

class GateApiClient:
    """Gate.io API客户端，提供稳定的API轮询机制"""
    
    def __init__(self, config=None):
        """初始化API客户端
        
        Args:
            config: 配置字典
        """
        self.config = {
            "base_urls": [
                "https://api.gateio.ws/api/v4",
                "https://api.gateio.ws/api/v4"  # 可添加备用API地址
            ],
            "max_retries": 3,       # 最大重试次数
            "retry_delay": 2,       # 重试延迟（秒）
            "request_timeout": 10,  # 请求超时（秒）
            "rate_limit": {
                "requests_per_second": 5,  # 每秒最大请求数
                "burst": 10               # 突发请求数
            }
        }
        
        # 更新配置
        if config:
            self.update_config(config)
        
        # 初始化请求计数器和时间戳
        self.request_count = 0
        self.last_request_time = 0
        self.token_bucket = self.config["rate_limit"]["burst"]
        self.last_token_refill = time.time()
    
    def update_config(self, config):
        """更新配置"""
        for key, value in config.items():
            if key in self.config and isinstance(self.config[key], dict) and isinstance(value, dict):
                self.config[key].update(value)
            else:
                self.config[key] = value
    
    def refill_token_bucket(self):
        """补充令牌桶"""
        now = time.time()
        elapsed = now - self.last_token_refill
        
        # 计算应该添加的令牌数
        new_tokens = elapsed * self.config["rate_limit"]["requests_per_second"]
        
        # 更新令牌桶
        self.token_bucket = min(
            self.token_bucket + new_tokens,
            self.config["rate_limit"]["burst"]
        )
        
        # 更新上次补充时间
        self.last_token_refill = now
    
    def consume_token(self):
        """消耗一个令牌，如果没有令牌则等待"""
        self.refill_token_bucket()
        
        if self.token_bucket < 1:
            # 计算需要等待的时间
            wait_time = (1 - self.token_bucket) / self.config["rate_limit"]["requests_per_second"]
            logger.debug(f"限流等待: {wait_time:.2f}秒")
            time.sleep(wait_time)
            self.refill_token_bucket()
        
        # 消耗一个令牌
        self.token_bucket -= 1
    
    def select_base_url(self):
        """选择一个基础URL"""
        return random.choice(self.config["base_urls"])
    
    def request(self, method, endpoint, params=None, data=None, headers=None):
        """发送API请求，带重试和限流机制
        
        Args:
            method: 请求方法（GET, POST等）
            endpoint: API端点
            params: URL参数
            data: 请求体数据
            headers: 请求头
            
        Returns:
            响应对象或None（如果请求失败）
        """
        # 消耗令牌（限流）
        self.consume_token()
        
        # 准备请求头
        if headers is None:
            headers = {}
        
        if 'User-Agent' not in headers:
            headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        
        # 重试机制
        retries = 0
        last_error = None
        
        while retries < self.config["max_retries"]:
            try:
                # 选择基础URL
                base_url = self.select_base_url()
                url = f"{base_url}{endpoint}"
                
                # 发送请求
                response = requests.request(
                    method=method,
                    url=url,
                    params=params,
                    json=data,
                    headers=headers,
                    timeout=self.config["request_timeout"]
                )
                
                # 检查响应状态
                response.raise_for_status()
                
                # 更新请求计数和时间
                self.request_count += 1
                self.last_request_time = time.time()
                
                # 返回响应
                return response
            
            except requests.exceptions.RequestException as e:
                retries += 1
                last_error = e
                logger.warning(f"API请求失败 ({retries}/{self.config['max_retries']}): {e}")
                
                if retries < self.config["max_retries"]:
                    # 指数退避策略
                    sleep_time = self.config["retry_delay"] * (2 ** (retries - 1)) * (0.5 + random.random())
                    logger.debug(f"等待 {sleep_time:.2f} 秒后重试")
                    time.sleep(sleep_time)
        
        logger.error(f"API请求最终失败: {endpoint}, 错误: {last_error}")
        return None
    
    def get(self, endpoint, params=None, headers=None):
        """发送GET请求"""
        return self.request("GET", endpoint, params=params, headers=headers)
    
    def post(self, endpoint, data=None, params=None, headers=None):
        """发送POST请求"""
        return self.request("POST", endpoint, params=params, data=data, headers=headers)
    
    def get_json(self, endpoint, params=None, headers=None):
        """发送GET请求并返回JSON响应"""
        response = self.get(endpoint, params=params, headers=headers)
        if response:
            try:
                return response.json()
            except ValueError as e:
                logger.error(f"解析JSON响应失败: {e}")
        return None

# 装饰器：API请求重试
def retry_on_failure(max_retries=3, delay=1):
    """装饰器：在失败时重试函数
    
    Args:
        max_retries: 最大重试次数
        delay: 重试延迟（秒）
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    retries += 1
                    if retries >= max_retries:
                        logger.error(f"函数 {func.__name__} 最终失败: {e}")
                        raise
                    
                    logger.warning(f"函数 {func.__name__} 失败 ({retries}/{max_retries}): {e}")
                    time.sleep(delay * (2 ** (retries - 1)))
        return wrapper
    return decorator

if __name__ == "__main__":
    # 创建API客户端实例
    api_client = GateApiClient()
    
    # 测试API请求
    response = api_client.get_json("/spot/currencies/BTC")
    if response:
        print(response)
    else:
        print("API请求失败")
