#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 智能分析与预警系统
功能：
1. 实现基于机器学习的异常价格波动预警
2. 添加交易量突增分析，及早发现潜在热点币种
3. 开发市场情绪分析，基于公告内容和价格反应
4. 实现自定义复合条件预警规则
"""

import os
import re
import json
import time
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from collections import defaultdict
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import joblib
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import warnings

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("smart_alerts.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_smart_alerts")

# 忽略警告
warnings.filterwarnings("ignore")

class SmartAlerts:
    """Gate.io智能分析与预警系统"""
    
    def __init__(self, config_file=None, config=None):
        """初始化智能分析与预警系统
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        # 默认配置
        self.config = {
            "anomaly_detection": {
                "enabled": True,
                "training_days": 30,  # 训练数据天数
                "contamination": 0.05,  # 异常比例
                "features": ["price_change", "volume_change", "volatility"],  # 使用的特征
                "model_path": "anomaly_model.pkl",  # 模型保存路径
                "retrain_interval": 86400,  # 模型重训练间隔（秒）
                "min_data_points": 20  # 最小数据点数量
            },
            "volume_surge": {
                "enabled": True,
                "threshold": 3.0,  # 交易量突增阈值（倍数）
                "window": 24,  # 时间窗口（小时）
                "min_volume": 100000  # 最小交易量（USDT）
            },
            "sentiment_analysis": {
                "enabled": True,
                "keywords": {
                    "positive": ["launch", "partnership", "breakthrough", "milestone", "success", "bullish", "growth"],
                    "negative": ["delay", "issue", "problem", "bug", "hack", "exploit", "bearish", "decline"]
                },
                "threshold": 0.2  # 情绪分数阈值
            },
            "custom_rules": {
                "enabled": True,
                "rules": [
                    {
                        "name": "价格突破30日高点",
                        "conditions": [
                            {"type": "price", "operator": ">", "value": "highest_price_30d", "buffer": 0.01}
                        ],
                        "enabled": True
                    },
                    {
                        "name": "价格跌破30日低点",
                        "conditions": [
                            {"type": "price", "operator": "<", "value": "lowest_price_30d", "buffer": 0.01}
                        ],
                        "enabled": True
                    },
                    {
                        "name": "超买RSI警报",
                        "conditions": [
                            {"type": "rsi", "operator": ">", "value": 70}
                        ],
                        "enabled": True
                    },
                    {
                        "name": "超卖RSI警报",
                        "conditions": [
                            {"type": "rsi", "operator": "<", "value": 30}
                        ],
                        "enabled": True
                    },
                    {
                        "name": "价格与交易量双增",
                        "conditions": [
                            {"type": "price_change_24h", "operator": ">", "value": 5},
                            {"type": "volume_trend", "operator": "==", "value": "大幅增加"}
                        ],
                        "enabled": True
                    }
                ]
            },
            "data_storage": {
                "enabled": True,
                "history_file": "price_history.json",
                "max_history_days": 60  # 最大历史数据保存天数
            }
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.update_config(self.config, config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(self.config, user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 初始化数据存储
        self.price_history = {}
        self.load_price_history()
        
        # 初始化异常检测模型
        self.anomaly_model = None
        self.scaler = None
        self.last_train_time = 0
        
        # 初始化情感分析器
        self.sentiment_analyzer = None
        if self.config["sentiment_analysis"]["enabled"]:
            self.initialize_sentiment_analyzer()
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def load_price_history(self):
        """加载价格历史数据"""
        history_file = self.config["data_storage"]["history_file"]
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    self.price_history = json.load(f)
                logger.info(f"已加载价格历史数据: {len(self.price_history)} 个币种")
            except Exception as e:
                logger.error(f"加载价格历史数据失败: {e}")
                self.price_history = {}
    
    def save_price_history(self):
        """保存价格历史数据"""
        if not self.config["data_storage"]["enabled"]:
            return
        
        try:
            history_file = self.config["data_storage"]["history_file"]
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(self.price_history, f, ensure_ascii=False, indent=2)
            logger.info(f"价格历史数据已保存: {len(self.price_history)} 个币种")
        except Exception as e:
            logger.error(f"保存价格历史数据失败: {e}")
    
    def update_price_history(self, symbol, price_data):
        """更新价格历史数据"""
        if not self.config["data_storage"]["enabled"]:
            return
        
        now = int(time.time())
        
        if symbol not in self.price_history:
            self.price_history[symbol] = []
        
        # 添加新数据点
        data_point = {
            "timestamp": now,
            "price": price_data.get("price", 0),
            "volume_24h": price_data.get("volume_24h", 0),
            "high_24h": price_data.get("high_24h", 0),
            "low_24h": price_data.get("low_24h", 0),
            "change_24h": price_data.get("change_24h", 0),
            "rsi": price_data.get("rsi", None),
            "volatility": price_data.get("volatility", None)
        }
        
        self.price_history[symbol].append(data_point)
        
        # 清理过旧的数据
        max_age = now - (self.config["data_storage"]["max_history_days"] * 86400)
        self.price_history[symbol] = [p for p in self.price_history[symbol] if p["timestamp"] > max_age]
        
        # 定期保存数据
        if now % 3600 < 60:  # 每小时保存一次
            self.save_price_history()
    
    def initialize_sentiment_analyzer(self):
        """初始化情感分析器"""
        try:
            # 下载NLTK资源（如果需要）
            try:
                nltk.data.find('vader_lexicon')
            except LookupError:
                nltk.download('vader_lexicon')
            
            # 初始化情感分析器
            self.sentiment_analyzer = SentimentIntensityAnalyzer()
            logger.info("情感分析器初始化成功")
        except Exception as e:
            logger.error(f"初始化情感分析器失败: {e}")
            self.sentiment_analyzer = None
    
    def analyze_sentiment(self, text):
        """分析文本情感"""
        if not self.sentiment_analyzer or not text:
            return 0
        
        try:
            # 获取情感分数
            sentiment_scores = self.sentiment_analyzer.polarity_scores(text)
            compound_score = sentiment_scores['compound']
            
            # 检查关键词
            text_lower = text.lower()
            positive_count = sum(1 for word in self.config["sentiment_analysis"]["keywords"]["positive"] if word.lower() in text_lower)
            negative_count = sum(1 for word in self.config["sentiment_analysis"]["keywords"]["negative"] if word.lower() in text_lower)
            
            # 调整分数
            keyword_factor = 0.1 * (positive_count - negative_count)
            adjusted_score = compound_score + keyword_factor
            
            # 限制在[-1, 1]范围内
            adjusted_score = max(-1, min(1, adjusted_score))
            
            return adjusted_score
        
        except Exception as e:
            logger.error(f"分析文本情感失败: {e}")
            return 0
    
    def prepare_anomaly_detection_data(self, symbol):
        """准备异常检测的数据"""
        if symbol not in self.price_history or len(self.price_history[symbol]) < self.config["anomaly_detection"]["min_data_points"]:
            return None
        
        try:
            # 获取历史数据
            history = self.price_history[symbol]
            
            # 转换为DataFrame
            df = pd.DataFrame(history)
            df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
            df = df.sort_values('datetime')
            
            # 计算特征
            df['price_change'] = df['price'].pct_change() * 100
            df['volume_change'] = df['volume_24h'].pct_change() * 100
            
            # 填充缺失值
            df = df.fillna(0)
            
            # 选择特征
            features = self.config["anomaly_detection"]["features"]
            feature_data = df[features].values
            
            return feature_data
        
        except Exception as e:
            logger.error(f"准备异常检测数据失败: {e}")
            return None
    
    def train_anomaly_model(self, data):
        """训练异常检测模型"""
        try:
            # 标准化数据
            self.scaler = StandardScaler()
            scaled_data = self.scaler.fit_transform(data)
            
            # 训练模型
            contamination = self.config["anomaly_detection"]["contamination"]
            self.anomaly_model = IsolationForest(
                contamination=contamination,
                random_state=42,
                n_estimators=100
            )
            self.anomaly_model.fit(scaled_data)
            
            # 保存模型
            model_path = self.config["anomaly_detection"]["model_path"]
            joblib.dump((self.anomaly_model, self.scaler), model_path)
            
            self.last_train_time = int(time.time())
            logger.info(f"异常检测模型训练完成，使用 {len(data)} 个数据点")
            
            return True
        
        except Exception as e:
            logger.error(f"训练异常检测模型失败: {e}")
            return False
    
    def load_anomaly_model(self):
        """加载异常检测模型"""
        model_path = self.config["anomaly_detection"]["model_path"]
        if os.path.exists(model_path):
            try:
                self.anomaly_model, self.scaler = joblib.load(model_path)
                logger.info("异常检测模型加载成功")
                return True
            except Exception as e:
                logger.error(f"加载异常检测模型失败: {e}")
        return False
    
    def detect_price_anomaly(self, symbol, current_data):
        """检测价格异常"""
        if not self.config["anomaly_detection"]["enabled"]:
            return False, 0
        
        try:
            # 检查是否需要训练或重新训练模型
            now = int(time.time())
            retrain_interval = self.config["anomaly_detection"]["retrain_interval"]
            
            if self.anomaly_model is None:
                # 尝试加载模型
                if not self.load_anomaly_model():
                    # 准备训练数据
                    all_data = []
                    for sym, history in self.price_history.items():
                        if len(history) >= self.config["anomaly_detection"]["min_data_points"]:
                            sym_data = self.prepare_anomaly_detection_data(sym)
                            if sym_data is not None:
                                all_data.extend(sym_data)
                    
                    if len(all_data) >= self.config["anomaly_detection"]["min_data_points"]:
                        self.train_anomaly_model(np.array(all_data))
                    else:
                        logger.warning("没有足够的数据来训练异常检测模型")
                        return False, 0
            
            elif now - self.last_train_time > retrain_interval:
                logger.info("重新训练异常检测模型")
                # 准备训练数据
                all_data = []
                for sym, history in self.price_history.items():
                    if len(history) >= self.config["anomaly_detection"]["min_data_points"]:
                        sym_data = self.prepare_anomaly_detection_data(sym)
                        if sym_data is not None:
                            all_data.extend(sym_data)
                
                if len(all_data) >= self.config["anomaly_detection"]["min_data_points"]:
                    self.train_anomaly_model(np.array(all_data))
            
            # 准备当前数据
            features = self.config["anomaly_detection"]["features"]
            current_features = []
            
            for feature in features:
                if feature == 'price_change':
                    current_features.append(current_data.get('change_24h', 0))
                elif feature == 'volume_change':
                    # 计算与前一天相比的交易量变化
                    if symbol in self.price_history and len(self.price_history[symbol]) > 0:
                        prev_volume = self.price_history[symbol][-1].get('volume_24h', 0)
                        curr_volume = current_data.get('volume_24h', 0)
                        if prev_volume > 0:
                            volume_change = (curr_volume - prev_volume) / prev_volume * 100
                        else:
                            volume_change = 0
                    else:
                        volume_change = 0
                    current_features.append(volume_change)
                else:
                    current_features.append(current_data.get(feature, 0))
            
            # 标准化数据
            if self.scaler is not None:
                current_features = self.scaler.transform([current_features])
                
                # 预测
                score = self.anomaly_model.decision_function(current_features)[0]
                prediction = self.anomaly_model.predict(current_features)[0]
                
                # 判断是否异常
                is_anomaly = prediction == -1
                
                if is_anomaly:
                    logger.info(f"检测到 {symbol} 的价格异常，异常分数: {score:.4f}")
                
                return is_anomaly, score
            
            return False, 0
        
        except Exception as e:
            logger.error(f"检测价格异常失败: {e}")
            return False, 0
    
    def detect_volume_surge(self, symbol, current_data):
        """检测交易量突增"""
        if not self.config["volume_surge"]["enabled"]:
            return False, 0
        
        try:
            current_volume = current_data.get('volume_24h', 0)
            
            # 检查最小交易量
            if current_volume < self.config["volume_surge"]["min_volume"]:
                return False, 0
            
            # 获取历史数据
            if symbol not in self.price_history or len(self.price_history[symbol]) < 2:
                return False, 0
            
            # 计算平均交易量
            window = self.config["volume_surge"]["window"]
            now = int(time.time())
            window_start = now - (window * 3600)
            
            historical_volumes = [p.get('volume_24h', 0) for p in self.price_history[symbol] 
                                if p['timestamp'] >= window_start and p['timestamp'] < now - 3600]
            
            if not historical_volumes:
                return False, 0
            
            avg_volume = sum(historical_volumes) / len(historical_volumes)
            
            if avg_volume > 0:
                surge_ratio = current_volume / avg_volume
                
                # 判断是否突增
                is_surge = surge_ratio >= self.config["volume_surge"]["threshold"]
                
                if is_surge:
                    logger.info(f"检测到 {symbol} 的交易量突增，比率: {surge_ratio:.2f}倍")
                
                return is_surge, surge_ratio
            
            return False, 0
        
        except Exception as e:
            logger.error(f"检测交易量突增失败: {e}")
            return False, 0
    
    def evaluate_custom_rule(self, rule, symbol, data):
        """评估自定义规则"""
        if not rule.get('enabled', True):
            return False
        
        try:
            # 检查所有条件
            for condition in rule.get('conditions', []):
                condition_type = condition.get('type')
                operator = condition.get('operator')
                value = condition.get('value')
                buffer = condition.get('buffer', 0)
                
                # 获取实际值
                if condition_type in data:
                    actual_value = data.get(condition_type)
                elif value in data:
                    # 支持引用其他字段作为比较值
                    compare_value = data.get(value)
                    actual_value = data.get(condition_type, 0)
                    
                    # 应用缓冲区
                    if operator == '>':
                        compare_value = compare_value * (1 + buffer)
                    elif operator == '<':
                        compare_value = compare_value * (1 - buffer)
                    
                    # 替换值为实际数值
                    value = compare_value
                else:
                    # 尝试转换为数值
                    try:
                        actual_value = data.get(condition_type, 0)
                        value = float(value)
                    except (ValueError, TypeError):
                        # 如果是字符串比较
                        actual_value = str(data.get(condition_type, ''))
                
                # 执行比较
                if operator == '>' and not (actual_value > value):
                    return False
                elif operator == '>=' and not (actual_value >= value):
                    return False
                elif operator == '<' and not (actual_value < value):
                    return False
                elif operator == '<=' and not (actual_value <= value):
                    return False
                elif operator == '==' and not (actual_value == value):
                    return False
                elif operator == '!=' and not (actual_value != value):
                    return False
                elif operator == 'contains' and not (value in actual_value):
                    return False
                elif operator == 'not_contains' and (value in actual_value):
                    return False
            
            # 所有条件都满足
            return True
        
        except Exception as e:
            logger.error(f"评估自定义规则失败: {e}")
            return False
    
    def check_custom_rules(self, symbol, data):
        """检查自定义规则"""
        if not self.config["custom_rules"]["enabled"]:
            return []
        
        triggered_rules = []
        
        try:
            for rule in self.config["custom_rules"]["rules"]:
                if self.evaluate_custom_rule(rule, symbol, data):
                    triggered_rules.append(rule.get('name', 'Unknown Rule'))
            
            if triggered_rules:
                logger.info(f"{symbol} 触发了自定义规则: {', '.join(triggered_rules)}")
            
            return triggered_rules
        
        except Exception as e:
            logger.error(f"检查自定义规则失败: {e}")
            return []
    
    def analyze_coin(self, symbol, coin_data):
        """分析币种数据，生成预警"""
        alerts = []
        
        try:
            # 更新价格历史
            self.update_price_history(symbol, coin_data)
            
            # 检测价格异常
            is_anomaly, anomaly_score = self.detect_price_anomaly(symbol, coin_data)
            if is_anomaly:
                alerts.append({
                    "type": "anomaly",
                    "title": "价格异常波动",
                    "description": f"检测到异常价格模式，异常分数: {anomaly_score:.4f}",
                    "severity": "high" if anomaly_score < -0.5 else "medium"
                })
            
            # 检测交易量突增
            is_surge, surge_ratio = self.detect_volume_surge(symbol, coin_data)
            if is_surge:
                alerts.append({
                    "type": "volume_surge",
                    "title": "交易量突增",
                    "description": f"交易量较前期增加 {surge_ratio:.2f} 倍",
                    "severity": "high" if surge_ratio > 5 else "medium"
                })
            
            # 分析市场情绪
            if self.config["sentiment_analysis"]["enabled"] and 'description' in coin_data:
                sentiment_score = self.analyze_sentiment(coin_data['description'])
                threshold = self.config["sentiment_analysis"]["threshold"]
                
                if abs(sentiment_score) >= threshold:
                    sentiment_type = "积极" if sentiment_score > 0 else "消极"
                    alerts.append({
                        "type": "sentiment",
                        "title": f"{sentiment_type}市场情绪",
                        "description": f"项目描述呈现{sentiment_type}情绪，分数: {sentiment_score:.2f}",
                        "severity": "medium"
                    })
            
            # 检查自定义规则
            triggered_rules = self.check_custom_rules(symbol, coin_data)
            for rule_name in triggered_rules:
                alerts.append({
                    "type": "custom_rule",
                    "title": f"触发规则: {rule_name}",
                    "description": f"满足自定义规则条件: {rule_name}",
                    "severity": "medium"
                })
            
            return alerts
        
        except Exception as e:
            logger.error(f"分析币种数据失败: {e}")
            return []
    
    def format_alerts_message(self, symbol, alerts, coin_data=None):
        """格式化预警消息"""
        if not alerts:
            return None
        
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = f"🚨 <b>Gate.io 智能预警 - {now}</b>\n\n"
            
            message += f"<b>币种: {symbol}</b>\n"
            
            if coin_data:
                price = coin_data.get('price', 0)
                change = coin_data.get('change_24h', 0)
                direction = "🔺" if change > 0 else "🔻"
                message += f"当前价格: {price:.8f} USDT ({direction} {change:.2f}%)\n"
                
                volume = coin_data.get('volume_24h', 0)
                message += f"24h成交量: {volume:.2f} USDT\n\n"
            else:
                message += "\n"
            
            message += "<b>预警信息:</b>\n"
            
            for alert in alerts:
                severity_icon = "🔴" if alert.get('severity') == "high" else "🟠"
                message += f"{severity_icon} <b>{alert.get('title', '未知预警')}</b>\n"
                message += f"   {alert.get('description', '')}\n\n"
            
            if coin_data and 'analysis_text' in coin_data:
                message += f"<b>市场分析:</b>\n{coin_data['analysis_text']}\n"
            
            return message
        
        except Exception as e:
            logger.error(f"格式化预警消息失败: {e}")
            return f"🚨 检测到 {symbol} 的预警，但格式化消息时出错"
    
    def generate_daily_summary(self, coins_data):
        """生成每日摘要"""
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = f"📊 <b>Gate.io 每日市场摘要 - {now}</b>\n\n"
            
            # 按涨跌幅排序
            sorted_coins = sorted(coins_data.items(), key=lambda x: x[1].get('change_24h', 0), reverse=True)
            
            # 涨幅最大的币种
            top_gainers = sorted_coins[:5]
            if top_gainers:
                message += "<b>🔝 涨幅最大:</b>\n"
                for symbol, data in top_gainers:
                    change = data.get('change_24h', 0)
                    price = data.get('price', 0)
                    message += f"• {symbol}: {change:.2f}%, 价格: {price:.8f} USDT\n"
                message += "\n"
            
            # 跌幅最大的币种
            top_losers = sorted_coins[-5:]
            top_losers.reverse()
            if top_losers:
                message += "<b>⬇️ 跌幅最大:</b>\n"
                for symbol, data in top_losers:
                    change = data.get('change_24h', 0)
                    price = data.get('price', 0)
                    message += f"• {symbol}: {change:.2f}%, 价格: {price:.8f} USDT\n"
                message += "\n"
            
            # 交易量最大的币种
            volume_sorted = sorted(coins_data.items(), key=lambda x: x[1].get('volume_24h', 0), reverse=True)
            top_volume = volume_sorted[:5]
            if top_volume:
                message += "<b>💰 交易量最大:</b>\n"
                for symbol, data in top_volume:
                    volume = data.get('volume_24h', 0)
                    price = data.get('price', 0)
                    message += f"• {symbol}: {volume:.2f} USDT, 价格: {price:.8f} USDT\n"
                message += "\n"
            
            # 今日预警统计
            alert_counts = defaultdict(int)
            for symbol, data in coins_data.items():
                if 'alerts' in data and data['alerts']:
                    for alert in data['alerts']:
                        alert_counts[alert.get('type', 'unknown')] += 1
            
            if alert_counts:
                message += "<b>⚠️ 今日预警统计:</b>\n"
                for alert_type, count in alert_counts.items():
                    alert_name = {
                        "anomaly": "价格异常波动",
                        "volume_surge": "交易量突增",
                        "sentiment": "市场情绪波动",
                        "custom_rule": "自定义规则触发"
                    }.get(alert_type, alert_type)
                    message += f"• {alert_name}: {count} 次\n"
                message += "\n"
            
            # 市场整体情况
            total_coins = len(coins_data)
            up_coins = sum(1 for _, data in coins_data.items() if data.get('change_24h', 0) > 0)
            down_coins = sum(1 for _, data in coins_data.items() if data.get('change_24h', 0) < 0)
            
            message += "<b>📈 市场整体情况:</b>\n"
            message += f"• 上涨币种: {up_coins} ({up_coins/total_coins*100:.1f}%)\n"
            message += f"• 下跌币种: {down_coins} ({down_coins/total_coins*100:.1f}%)\n"
            message += f"• 持平币种: {total_coins - up_coins - down_coins}\n"
            
            return message
        
        except Exception as e:
            logger.error(f"生成每日摘要失败: {e}")
            return "📊 无法生成每日市场摘要，处理数据时出错"

if __name__ == "__main__":
    # 创建智能预警系统实例
    smart_alerts = SmartAlerts()
    
    # 测试数据
    test_data = {
        "price": 50000,
        "change_24h": 5.2,
        "volume_24h": 1000000,
        "high_24h": 52000,
        "low_24h": 48000,
        "rsi": 65,
        "volatility": 0.05,
        "description": "This project is showing great progress with new partnerships and growth.",
        "analysis_text": "BTC当前处于上涨趋势，近期支撑位在48000，阻力位在52000。"
    }
    
    # 测试分析
    alerts = smart_alerts.analyze_coin("BTC", test_data)
    
    # 打印结果
    if alerts:
        message = smart_alerts.format_alerts_message("BTC", alerts, test_data)
        print(message)
    else:
        print("没有检测到预警")
