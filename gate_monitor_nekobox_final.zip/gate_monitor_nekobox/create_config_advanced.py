#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 监控系统配置文件生成器（高级版）
功能：生成高级监控系统所需的配置文件
"""

import os
import json
import argparse

def create_main_config():
    """创建主配置文件"""
    config = {
        "price_monitor": {
            "enabled": True,
            "change_threshold": 5.0,  # 价格变动阈值（百分比）
            "symbols": ["BTC_USDT", "ETH_USDT", "GT_USDT"],  # 固定监控的交易对
            "top_symbols_count": 20  # 监控交易量排名前N的币种
        },
        "announcement_monitor": {
            "enabled": True,
            "keywords": ["上线", "上架", "首发", "新增", "开放", "交易", "上市"],  # 关注的关键词
            "max_announcements": 20  # 每次检查的公告数量
        },
        "coin_info": {
            "enabled": True,
            "cache_expiry": 86400,  # 缓存过期时间（秒），默认1天
            "fetch_details_for_new_coins": True  # 为新上币获取详细信息
        },
        "telegram_push": {
            "enabled": True,
            "config_file": "telegram_config.json"  # Telegram配置文件路径
        },
        "api_client": {
            "max_retries": 3,
            "retry_delay": 2,
            "request_timeout": 10,
            "rate_limit": {
                "requests_per_second": 5,
                "burst": 10
            }
        },
        "run_interval": 3600  # 运行间隔，单位秒（默认1小时）
    }
    
    with open("config_advanced.json", "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    print(f"高级主配置文件已创建: config_advanced.json")

def create_telegram_config():
    """创建Telegram配置文件"""
    config = {
        "accounts": [
            {
                "bot_token": "YOUR_BOT_TOKEN_1_HERE",
                "chat_id": "YOUR_CHAT_ID_1_HERE",
                "message_thread_id": None,
                "enabled": True,
                "last_used": 0,
                "error_count": 0
            },
            {
                "bot_token": "YOUR_BOT_TOKEN_2_HERE",
                "chat_id": "YOUR_CHAT_ID_2_HERE",
                "message_thread_id": None,
                "enabled": True,
                "last_used": 0,
                "error_count": 0
            }
        ],
        "proxy": None,
        "rotation_strategy": "round_robin",
        "max_errors": 3,
        "error_reset_time": 86400,
        "note": "请替换上面的占位符为实际的Bot Token和Chat ID"
    }
    
    with open("telegram_config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    print(f"Telegram配置文件已创建: telegram_config.json")

def create_readme():
    """创建README文件"""
    readme_content = """# Gate.io 高级监控系统

## 功能介绍

Gate.io 高级监控系统是一个自动化工具，用于监控Gate.io交易所的价格变动、公告更新和币种信息，并通过Telegram推送通知。

### 主要功能

1. **价格监控**：
   - 监控指定交易对和交易量排名靠前的币种
   - 检测显著的价格变动
   - 推送价格预警消息，包含涨跌幅、成交量等信息

2. **公告监控**：
   - 监控Gate.io官方公告
   - 监控新上币公告
   - 根据关键词过滤重要公告
   - 推送公告更新通知

3. **币种详细信息**：
   - 获取币种简介、合约信息、市值数据
   - 收集社交媒体链接（官网、Twitter、Telegram等）
   - 分析市场动态和价格趋势
   - 为新上币自动获取详细信息

4. **Telegram多账号推送**：
   - 支持配置多个Telegram Bot账号
   - 账号轮换推送，降低单一账号风险
   - 自动检测账号状态并切换
   - 支持HTML格式消息和链接预览控制

5. **API轮询优化**：
   - 稳定的API请求机制
   - 错误重试和请求限流控制
   - 负载均衡和故障转移

## 安装与配置

### 依赖安装

```bash
pip install requests beautifulsoup4
```

### 配置文件

1. **主配置文件** (`config_advanced.json`):
   - 控制各模块的启用状态和参数
   - 设置价格变动阈值和监控的交易对
   - 设置公告关键词和监控数量
   - 设置币种信息缓存过期时间
   - 设置API客户端参数
   - 设置运行间隔

2. **Telegram配置文件** (`telegram_config.json`):
   - 设置多个Bot Token和Chat ID
   - 设置账号轮换策略
   - 设置代理（如需）
   - 设置消息主题ID（如需）

## 使用方法

### 单次运行

```bash
python gate_monitor_advanced.py --once
```

### 持续运行

```bash
python gate_monitor_advanced.py
```

### 使用自定义配置文件

```bash
python gate_monitor_advanced.py --config custom_config.json
```

## 定时任务设置

由于系统不支持内置的定时任务，建议使用外部定时服务（如crontab或云函数）触发监控脚本。

### Linux Crontab示例（每小时运行一次）

```bash
0 * * * * cd /path/to/gate_monitor && python gate_monitor_advanced.py --once
```

## 注意事项

- 首次运行时会记录当前状态作为基准，不会产生预警
- 价格监控的变动阈值可在配置文件中调整
- 公告监控的关键词可根据需要在配置文件中修改
- 币种信息会缓存一段时间，可在配置文件中调整缓存过期时间
- 请确保Telegram配置正确，否则无法接收通知
- 所有数据均直接从Gate.io官方API和网站获取，不使用第三方数据源
"""
    
    with open("README_advanced.md", "w", encoding="utf-8") as f:
        f.write(readme_content)
    
    print(f"高级版README文件已创建: README_advanced.md")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 高级监控系统配置文件生成器")
    parser.add_argument("--all", action="store_true", help="生成所有配置文件")
    parser.add_argument("--main", action="store_true", help="生成主配置文件")
    parser.add_argument("--telegram", action="store_true", help="生成Telegram配置文件")
    parser.add_argument("--readme", action="store_true", help="生成README文件")
    args = parser.parse_args()
    
    # 如果没有指定参数，默认生成所有文件
    if not (args.all or args.main or args.telegram or args.readme):
        args.all = True
    
    if args.all or args.main:
        create_main_config()
    
    if args.all or args.telegram:
        create_telegram_config()
    
    if args.all or args.readme:
        create_readme()
    
    print("配置文件生成完成！")

if __name__ == "__main__":
    main()
