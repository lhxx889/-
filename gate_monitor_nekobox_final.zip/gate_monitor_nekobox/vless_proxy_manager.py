#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io VLESS代理管理模块
功能：
1. 支持VLESS URI格式代理配置
2. 支持代理轮换和负载均衡
3. 集成本地nekobox客户端配置
4. 提供HTTP/SOCKS代理接口
"""

import os
import json
import time
import random
import logging
import requests
import subprocess
import threading
import re
import base64
import urllib.parse
from urllib.parse import urlparse, parse_qs
from requests.exceptions import RequestException, ProxyError, Timeout
from http.cookiejar import LWPCookieJar
from collections import defaultdict

try:
    from fake_useragent import UserAgent
    HAS_FAKE_UA = True
except ImportError:
    HAS_FAKE_UA = False

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("vless_proxy_manager.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_vless_proxy_manager")

class VLESSProxy:
    """VLESS代理配置类"""
    
    def __init__(self, uri=None):
        """初始化VLESS代理配置
        
        Args:
            uri: VLESS URI格式的代理配置
        """
        self.protocol = "vless"
        self.user_id = ""
        self.address = ""
        self.port = 443
        self.params = {}
        self.tag = ""
        self.local_port = None
        self.process = None
        
        if uri:
            self.parse_uri(uri)
    
    def parse_uri(self, uri):
        """解析VLESS URI
        
        Args:
            uri: VLESS URI格式的代理配置
            
        Example:
            vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态
        """
        try:
            # 检查URI格式
            if not uri.startswith("vless://"):
                raise ValueError("不是有效的VLESS URI")
            
            # 移除协议前缀
            uri = uri[8:]
            
            # 分离标签部分
            if "#" in uri:
                uri, tag = uri.split("#", 1)
                self.tag = urllib.parse.unquote(tag)
            
            # 分离用户ID和服务器地址
            if "@" in uri:
                user_id, server = uri.split("@", 1)
                self.user_id = user_id
            else:
                server = uri
            
            # 分离服务器地址和参数
            if "/?" in server:
                server, params_str = server.split("/?", 1)
                # 解析参数
                self.params = dict(urllib.parse.parse_qsl(params_str))
            
            # 分离地址和端口
            if ":" in server:
                address, port = server.split(":", 1)
                self.address = address
                self.port = int(port)
            else:
                self.address = server
            
            logger.info(f"成功解析VLESS URI: {self.address}:{self.port}, 标签: {self.tag}")
            return True
        
        except Exception as e:
            logger.error(f"解析VLESS URI失败: {e}")
            return False
    
    def to_nekobox_config(self, local_port=1080, local_address="127.0.0.1"):
        """转换为nekobox配置
        
        Args:
            local_port: 本地代理端口
            local_address: 本地代理地址
            
        Returns:
            dict: nekobox配置字典
        """
        config = {
            "log": {
                "loglevel": "warning"
            },
            "inbounds": [
                {
                    "port": local_port,
                    "listen": local_address,
                    "protocol": "socks",
                    "settings": {
                        "udp": True
                    }
                },
                {
                    "port": local_port + 1,
                    "listen": local_address,
                    "protocol": "http"
                }
            ],
            "outbounds": [
                {
                    "protocol": "vless",
                    "settings": {
                        "vnext": [
                            {
                                "address": self.address,
                                "port": self.port,
                                "users": [
                                    {
                                        "id": self.user_id,
                                        "encryption": self.params.get("encryption", "none"),
                                        "flow": self.params.get("flow", "")
                                    }
                                ]
                            }
                        ]
                    },
                    "streamSettings": {
                        "network": self.params.get("type", "tcp"),
                        "security": self.params.get("security", "none")
                    },
                    "tag": "proxy"
                },
                {
                    "protocol": "freedom",
                    "settings": {},
                    "tag": "direct"
                }
            ],
            "routing": {
                "rules": [
                    {
                        "type": "field",
                        "ip": ["geoip:private"],
                        "outboundTag": "direct"
                    },
                    {
                        "type": "field",
                        "outboundTag": "proxy"
                    }
                ]
            }
        }
        
        # 添加TLS配置
        if self.params.get("security") == "tls" or self.params.get("security") == "reality":
            config["outbounds"][0]["streamSettings"]["tlsSettings"] = {
                "serverName": self.params.get("sni", ""),
                "fingerprint": self.params.get("fp", "chrome")
            }
        
        # 添加Reality配置
        if self.params.get("security") == "reality":
            config["outbounds"][0]["streamSettings"]["realitySettings"] = {
                "show": False,
                "publicKey": self.params.get("pbk", ""),
                "shortId": self.params.get("sid", ""),
                "spiderX": self.params.get("spx", "")
            }
        
        # 添加传输配置
        network = self.params.get("type", "tcp")
        if network == "ws":
            config["outbounds"][0]["streamSettings"]["wsSettings"] = {
                "path": self.params.get("path", "/"),
                "headers": {
                    "Host": self.params.get("host", self.address)
                }
            }
        elif network == "grpc":
            config["outbounds"][0]["streamSettings"]["grpcSettings"] = {
                "serviceName": self.params.get("serviceName", "")
            }
        
        self.local_port = local_port
        return config
    
    def get_proxy_url(self, protocol="socks5"):
        """获取代理URL
        
        Args:
            protocol: 代理协议，socks5或http
            
        Returns:
            str: 代理URL
        """
        if not self.local_port:
            return None
        
        if protocol == "socks5":
            return f"socks5://127.0.0.1:{self.local_port}"
        elif protocol == "http":
            return f"http://127.0.0.1:{self.local_port + 1}"
        else:
            return None
    
    def __str__(self):
        """字符串表示"""
        return f"VLESS://{self.user_id}@{self.address}:{self.port} [{self.tag}]"

class VLESSProxyManager:
    """VLESS代理管理类"""
    
    def __init__(self, config_file=None, config=None):
        """初始化VLESS代理管理器
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        # 默认配置
        self.config = {
            "proxy": {
                "enabled": True,
                "type": "vless",  # 代理类型：vless, http, socks5
                "vless_uris": [
                    # VLESS URI格式的代理配置
                ],
                "http_proxies": [
                    # 格式: "http://user:pass@host:port"
                ],
                "socks5_proxies": [
                    # 格式: "socks5://user:pass@host:port"
                ],
                "nekobox_bin": "nekobox",  # nekobox可执行文件路径
                "use_local_nekobox": True,  # 是否使用本地nekobox客户端
                "local_port_start": 10800,  # 本地代理端口起始值
                "rotation_interval": 10,  # 代理轮换间隔（请求次数）
                "retry_times": 3,  # 代理失败重试次数
                "timeout": 10,  # 请求超时时间（秒）
                "test_url": "https://api.ipify.org?format=json",  # 代理测试URL
                "blacklist_time": 300  # 代理黑名单时间（秒）
            },
            "user_agent": {
                "enabled": True,
                "rotation": "random",  # random, pool
                "custom_agents": [
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
                ]
            },
            "cookie": {
                "enabled": True,
                "save_path": "cookies.txt",  # Cookie保存路径
                "domains": ["gate.io", "www.gate.io"],  # 需要管理Cookie的域名
                "expire_days": 7  # Cookie过期天数
            },
            "behavior": {
                "enabled": True,
                "random_delay": {
                    "min": 1,  # 最小延迟（秒）
                    "max": 3   # 最大延迟（秒）
                },
                "visit_patterns": {
                    "enabled": True,
                    "entry_pages": [
                        "https://www.gate.io/",
                        "https://www.gate.io/trade/BTC_USDT"
                    ],
                    "random_pages": [
                        "https://www.gate.io/trade/ETH_USDT",
                        "https://www.gate.io/marketlist"
                    ],
                    "probability": 0.3  # 随机访问概率
                }
            }
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.update_config(self.config, config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(self.config, user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 初始化状态
        self.current_proxy = None
        self.proxy_index = 0
        self.request_count = 0
        self.proxy_blacklist = {}  # 代理黑名单
        self.domain_cookies = defaultdict(dict)  # 按域名存储Cookie
        self.session = requests.Session()  # 会话对象
        self.lock = threading.Lock()  # 线程锁
        self.vless_proxies = []  # VLESS代理列表
        self.running_proxies = {}  # 运行中的代理进程
        
        # 初始化User-Agent生成器
        if HAS_FAKE_UA:
            try:
                self.ua = UserAgent()
                logger.info("User-Agent生成器初始化成功")
            except Exception as e:
                logger.warning(f"User-Agent生成器初始化失败: {e}，将使用自定义User-Agent")
                self.ua = None
        else:
            self.ua = None
            logger.warning("未安装fake-useragent库，将使用自定义User-Agent")
        
        # 加载Cookie
        self.load_cookies()
        
        # 初始化代理列表
        self.available_proxies = []
        self.init_proxies()
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def init_proxies(self):
        """初始化代理列表"""
        if not self.config["proxy"]["enabled"]:
            logger.info("代理功能未启用")
            return
        
        proxy_type = self.config["proxy"]["type"]
        
        if proxy_type == "vless":
            self.init_vless_proxies()
        elif proxy_type == "http":
            self.available_proxies = self.config["proxy"]["http_proxies"]
            logger.info(f"已加载 {len(self.available_proxies)} 个HTTP代理")
        elif proxy_type == "socks5":
            self.available_proxies = self.config["proxy"]["socks5_proxies"]
            logger.info(f"已加载 {len(self.available_proxies)} 个SOCKS5代理")
        else:
            logger.error(f"不支持的代理类型: {proxy_type}")
        
        # 测试代理可用性
        self.test_proxies()
    
    def init_vless_proxies(self):
        """初始化VLESS代理"""
        vless_uris = self.config["proxy"]["vless_uris"]
        
        if not vless_uris:
            logger.warning("未配置VLESS URI")
            return
        
        # 解析VLESS URI
        for uri in vless_uris:
            proxy = VLESSProxy(uri)
            if proxy.user_id and proxy.address:
                self.vless_proxies.append(proxy)
        
        logger.info(f"已加载 {len(self.vless_proxies)} 个VLESS代理")
        
        # 如果使用本地nekobox客户端，则启动代理
        if self.config["proxy"]["use_local_nekobox"]:
            self.start_local_proxies()
    
    def start_local_proxies(self):
        """启动本地代理"""
        if not self.vless_proxies:
            logger.warning("没有可用的VLESS代理")
            return
        
        nekobox_bin = self.config["proxy"]["nekobox_bin"]
        local_port_start = self.config["proxy"]["local_port_start"]
        
        # 检查nekobox是否可用
        try:
            subprocess.run([nekobox_bin, "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        except Exception as e:
            logger.error(f"nekobox不可用: {e}")
            return
        
        # 启动代理
        for i, proxy in enumerate(self.vless_proxies):
            local_port = local_port_start + i * 2
            config = proxy.to_nekobox_config(local_port)
            
            # 保存配置文件
            config_file = f"nekobox_config_{i}.json"
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            # 启动nekobox
            try:
                process = subprocess.Popen(
                    [nekobox_bin, "-c", config_file],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                
                # 等待启动
                time.sleep(2)
                
                # 检查进程是否存活
                if process.poll() is None:
                    self.running_proxies[proxy] = process
                    proxy_url = proxy.get_proxy_url("socks5")
                    self.available_proxies.append(proxy_url)
                    logger.info(f"启动本地代理成功: {proxy_url}")
                else:
                    stdout, stderr = process.communicate()
                    logger.error(f"启动本地代理失败: {stderr.decode('utf-8', errors='ignore')}")
            
            except Exception as e:
                logger.error(f"启动本地代理异常: {e}")
    
    def stop_local_proxies(self):
        """停止本地代理"""
        for proxy, process in self.running_proxies.items():
            try:
                process.terminate()
                process.wait(timeout=5)
                logger.info(f"停止本地代理: {proxy}")
            except Exception as e:
                logger.error(f"停止本地代理失败: {e}")
                try:
                    process.kill()
                except:
                    pass
        
        self.running_proxies = {}
    
    def test_proxies(self):
        """测试代理可用性"""
        working_proxies = []
        
        for proxy in self.available_proxies:
            if self.test_proxy(proxy):
                working_proxies.append(proxy)
        
        self.available_proxies = working_proxies
        logger.info(f"代理测试完成，{len(working_proxies)}/{len(self.available_proxies)} 个代理可用")
    
    def test_proxy(self, proxy):
        """测试单个代理的可用性"""
        try:
            test_url = self.config["proxy"]["test_url"]
            timeout = self.config["proxy"]["timeout"]
            
            # 构建代理配置
            proxies = self.build_proxy_config(proxy)
            
            # 发送测试请求
            response = requests.get(
                test_url,
                proxies=proxies,
                timeout=timeout
            )
            
            if response.status_code == 200:
                logger.debug(f"代理 {proxy} 测试成功")
                return True
            else:
                logger.warning(f"代理 {proxy} 测试失败，状态码: {response.status_code}")
                return False
        
        except Exception as e:
            logger.warning(f"代理 {proxy} 测试失败: {e}")
            return False
    
    def build_proxy_config(self, proxy):
        """构建代理配置"""
        proxy_type = self.config["proxy"]["type"]
        
        if proxy_type in ["vless", "http", "socks5"]:
            # 直接使用代理URL
            return {
                "http": proxy,
                "https": proxy
            }
        else:
            logger.error(f"不支持的代理类型: {proxy_type}")
            return {}
    
    def get_next_proxy(self):
        """获取下一个代理"""
        with self.lock:
            if not self.available_proxies:
                logger.warning("没有可用的代理")
                return None
            
            # 轮询选择代理
            for _ in range(len(self.available_proxies)):
                self.proxy_index = (self.proxy_index + 1) % len(self.available_proxies)
                proxy = self.available_proxies[self.proxy_index]
                
                # 检查代理是否在黑名单中
                if proxy in self.proxy_blacklist:
                    blacklist_time = self.proxy_blacklist[proxy]
                    if time.time() - blacklist_time > self.config["proxy"]["blacklist_time"]:
                        # 从黑名单中移除
                        del self.proxy_blacklist[proxy]
                    else:
                        # 跳过黑名单中的代理
                        continue
                
                return proxy
            
            return None
    
    def rotate_proxy(self, force=False):
        """轮换代理"""
        if not self.config["proxy"]["enabled"]:
            return None
        
        with self.lock:
            self.request_count += 1
            
            # 检查是否需要轮换代理
            if force or self.request_count >= self.config["proxy"]["rotation_interval"]:
                self.current_proxy = self.get_next_proxy()
                self.request_count = 0
                logger.info(f"轮换代理: {self.current_proxy}")
            elif not self.current_proxy:
                self.current_proxy = self.get_next_proxy()
            
            return self.current_proxy
    
    def blacklist_proxy(self, proxy):
        """将代理加入黑名单"""
        if proxy:
            self.proxy_blacklist[proxy] = time.time()
            logger.warning(f"代理 {proxy} 已加入黑名单")
    
    def get_user_agent(self):
        """获取User-Agent"""
        if not self.config["user_agent"]["enabled"]:
            return None
        
        rotation = self.config["user_agent"]["rotation"]
        
        if rotation == "random" and self.ua:
            # 使用fake_useragent生成随机UA
            return self.ua.random
        else:
            # 从自定义列表中随机选择
            return random.choice(self.config["user_agent"]["custom_agents"])
    
    def load_cookies(self):
        """加载Cookie"""
        if not self.config["cookie"]["enabled"]:
            return
        
        cookie_path = self.config["cookie"]["save_path"]
        
        if os.path.exists(cookie_path):
            try:
                cookie_jar = LWPCookieJar(cookie_path)
                cookie_jar.load(ignore_discard=True, ignore_expires=True)
                
                # 将Cookie加载到会话
                self.session.cookies = cookie_jar
                logger.info(f"已加载Cookie: {len(cookie_jar)} 个")
            except Exception as e:
                logger.error(f"加载Cookie失败: {e}")
        else:
            # 创建新的Cookie文件
            cookie_jar = LWPCookieJar(cookie_path)
            self.session.cookies = cookie_jar
            logger.info("创建新的Cookie文件")
    
    def save_cookies(self):
        """保存Cookie"""
        if not self.config["cookie"]["enabled"]:
            return
        
        try:
            self.session.cookies.save(ignore_discard=True, ignore_expires=True)
            logger.info(f"已保存 {len(self.session.cookies)} 个Cookie")
        except Exception as e:
            logger.error(f"保存Cookie失败: {e}")
    
    def should_visit_random_page(self):
        """判断是否应该访问随机页面"""
        if not self.config["behavior"]["enabled"] or not self.config["behavior"]["visit_patterns"]["enabled"]:
            return False
        
        return random.random() < self.config["behavior"]["visit_patterns"]["probability"]
    
    def visit_random_pages(self):
        """访问随机页面，模拟真实用户行为"""
        if not self.should_visit_random_page():
            return
        
        try:
            # 随机选择一个页面
            pages = self.config["behavior"]["visit_patterns"]["random_pages"]
            if not pages:
                return
            
            random_page = random.choice(pages)
            logger.info(f"访问随机页面: {random_page}")
            
            # 发送请求
            self.request(random_page, method="GET")
            
            # 随机延迟
            self.random_delay()
        
        except Exception as e:
            logger.error(f"访问随机页面失败: {e}")
    
    def random_delay(self):
        """随机延迟，模拟人类行为"""
        if not self.config["behavior"]["enabled"]:
            return
        
        min_delay = self.config["behavior"]["random_delay"]["min"]
        max_delay = self.config["behavior"]["random_delay"]["max"]
        
        delay = random.uniform(min_delay, max_delay)
        time.sleep(delay)
    
    def request(self, url, method="GET", **kwargs):
        """发送HTTP请求，带代理和反爬虫功能
        
        Args:
            url: 请求URL
            method: 请求方法，GET或POST
            **kwargs: 其他请求参数
        
        Returns:
            requests.Response对象或None
        """
        if not url:
            logger.error("URL不能为空")
            return None
        
        # 检查是否需要访问随机页面
        if self.should_visit_random_page():
            self.visit_random_pages()
        
        # 获取代理
        proxy = self.rotate_proxy()
        proxies = self.build_proxy_config(proxy) if proxy else None
        
        # 获取User-Agent
        user_agent = self.get_user_agent()
        
        # 准备请求头
        headers = kwargs.get("headers", {})
        if user_agent:
            headers["User-Agent"] = user_agent
        
        # 添加常见请求头，模拟浏览器
        if "Accept" not in headers:
            headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
        if "Accept-Language" not in headers:
            headers["Accept-Language"] = "zh-CN,zh;q=0.9,en;q=0.8"
        if "Accept-Encoding" not in headers:
            headers["Accept-Encoding"] = "gzip, deflate, br"
        if "Connection" not in headers:
            headers["Connection"] = "keep-alive"
        if "Upgrade-Insecure-Requests" not in headers:
            headers["Upgrade-Insecure-Requests"] = "1"
        
        # 更新请求参数
        kwargs["headers"] = headers
        if proxies:
            kwargs["proxies"] = proxies
        
        # 设置超时
        if "timeout" not in kwargs:
            kwargs["timeout"] = self.config["proxy"]["timeout"]
        
        # 重试机制
        retry_times = self.config["proxy"]["retry_times"]
        retry_count = 0
        
        while retry_count <= retry_times:
            try:
                # 随机延迟
                self.random_delay()
                
                # 发送请求
                if method.upper() == "GET":
                    response = self.session.get(url, **kwargs)
                elif method.upper() == "POST":
                    response = self.session.post(url, **kwargs)
                else:
                    logger.error(f"不支持的请求方法: {method}")
                    return None
                
                # 检查响应状态
                response.raise_for_status()
                
                # 保存Cookie
                self.save_cookies()
                
                return response
            
            except (ProxyError, Timeout) as e:
                # 代理错误，将当前代理加入黑名单
                logger.warning(f"代理错误: {e}")
                self.blacklist_proxy(proxy)
                
                # 获取新代理
                proxy = self.rotate_proxy(force=True)
                proxies = self.build_proxy_config(proxy) if proxy else None
                if proxies:
                    kwargs["proxies"] = proxies
                
                retry_count += 1
            
            except RequestException as e:
                # 其他请求错误
                logger.warning(f"请求错误: {e}")
                retry_count += 1
            
            except Exception as e:
                # 未知错误
                logger.error(f"未知错误: {e}")
                return None
        
        logger.error(f"请求失败，已重试 {retry_times} 次: {url}")
        return None
    
    def get(self, url, **kwargs):
        """发送GET请求"""
        return self.request(url, method="GET", **kwargs)
    
    def post(self, url, **kwargs):
        """发送POST请求"""
        return self.request(url, method="POST", **kwargs)
    
    def __del__(self):
        """析构函数，清理资源"""
        self.stop_local_proxies()

class AnnouncementCrawler:
    """Gate.io公告爬虫类"""
    
    def __init__(self, proxy_manager, config=None):
        """初始化公告爬虫
        
        Args:
            proxy_manager: 代理管理器实例
            config: 配置字典
        """
        self.proxy_manager = proxy_manager
        
        # 默认配置
        self.config = {
            "announcement": {
                "urls": {
                    "general": "https://www.gate.io/zh/announcements",
                    "newlisted": "https://www.gate.io/zh/announcements/newlisted"
                },
                "max_pages": 3,  # 最大爬取页数
                "cache_file": "announcement_cache.json",  # 缓存文件
                "cache_expiry": 3600  # 缓存过期时间（秒）
            }
        }
        
        # 更新配置
        if config:
            self.update_config(self.config, config)
        
        # 加载缓存
        self.announcement_cache = self.load_cache()
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def load_cache(self):
        """加载公告缓存"""
        cache_file = self.config["announcement"]["cache_file"]
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                logger.info(f"已加载公告缓存: {len(cache.get('general', []))} 条普通公告, {len(cache.get('newlisted', []))} 条新上币公告")
                return cache
            except Exception as e:
                logger.error(f"加载公告缓存失败: {e}")
        
        return {"general": [], "newlisted": [], "last_update": 0}
    
    def save_cache(self):
        """保存公告缓存"""
        cache_file = self.config["announcement"]["cache_file"]
        
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.announcement_cache, f, ensure_ascii=False, indent=2)
            logger.info(f"已保存公告缓存: {len(self.announcement_cache.get('general', []))} 条普通公告, {len(self.announcement_cache.get('newlisted', []))} 条新上币公告")
        except Exception as e:
            logger.error(f"保存公告缓存失败: {e}")
    
    def is_cache_valid(self):
        """检查缓存是否有效"""
        last_update = self.announcement_cache.get("last_update", 0)
        now = int(time.time())
        
        return now - last_update < self.config["announcement"]["cache_expiry"]
    
    def fetch_announcements(self, force_update=False):
        """获取公告列表
        
        Args:
            force_update: 是否强制更新缓存
        
        Returns:
            dict: 包含普通公告和新上币公告的字典
        """
        # 检查缓存是否有效
        if not force_update and self.is_cache_valid():
            logger.info("使用缓存的公告数据")
            return self.announcement_cache
        
        # 获取普通公告
        general_announcements = self.fetch_announcement_page(
            self.config["announcement"]["urls"]["general"],
            "general"
        )
        
        # 获取新上币公告
        newlisted_announcements = self.fetch_announcement_page(
            self.config["announcement"]["urls"]["newlisted"],
            "newlisted"
        )
        
        # 更新缓存
        self.announcement_cache = {
            "general": general_announcements,
            "newlisted": newlisted_announcements,
            "last_update": int(time.time())
        }
        
        # 保存缓存
        self.save_cache()
        
        return self.announcement_cache
    
    def fetch_announcement_page(self, url, announcement_type, max_pages=None):
        """获取公告页面内容
        
        Args:
            url: 公告页面URL
            announcement_type: 公告类型
            max_pages: 最大爬取页数
        
        Returns:
            list: 公告列表
        """
        if max_pages is None:
            max_pages = self.config["announcement"]["max_pages"]
        
        announcements = []
        current_page = 1
        
        while current_page <= max_pages:
            page_url = f"{url}?page={current_page}" if current_page > 1 else url
            logger.info(f"获取{announcement_type}公告页面: {page_url}")
            
            # 发送请求
            response = self.proxy_manager.get(page_url)
            
            if not response:
                logger.error(f"获取页面失败: {page_url}")
                break
            
            # 解析公告
            page_announcements = self.parse_announcement_page(response.text, announcement_type)
            
            if not page_announcements:
                logger.warning(f"页面没有公告或解析失败: {page_url}")
                break
            
            announcements.extend(page_announcements)
            
            # 检查是否有下一页
            if len(page_announcements) < 10:  # 假设每页10条公告
                break
            
            current_page += 1
        
        logger.info(f"共获取 {len(announcements)} 条{announcement_type}公告")
        return announcements
    
    def parse_announcement_page(self, html_content, announcement_type):
        """解析公告页面
        
        Args:
            html_content: 页面HTML内容
            announcement_type: 公告类型
        
        Returns:
            list: 公告列表
        """
        try:
            from bs4 import BeautifulSoup
            
            soup = BeautifulSoup(html_content, 'html.parser')
            announcements = []
            
            # 查找公告列表
            announcement_items = soup.select('div.article-list-item')
            
            for item in announcement_items:
                try:
                    # 提取标题和链接
                    title_elem = item.select_one('a.article-list-link')
                    if not title_elem:
                        continue
                    
                    title = title_elem.text.strip()
                    link = title_elem.get('href', '')
                    
                    # 提取日期
                    date_elem = item.select_one('div.article-date')
                    date = date_elem.text.strip() if date_elem else ''
                    
                    # 构建完整链接
                    if link and not link.startswith('http'):
                        link = f"https://www.gate.io{link}"
                    
                    # 提取ID
                    announcement_id = ''
                    if link:
                        try:
                            announcement_id = link.split('/')[-1]
                        except:
                            pass
                    
                    announcement = {
                        'id': announcement_id,
                        'title': title,
                        'link': link,
                        'date': date,
                        'type': announcement_type
                    }
                    
                    announcements.append(announcement)
                
                except Exception as e:
                    logger.error(f"解析公告项失败: {e}")
            
            return announcements
        
        except Exception as e:
            logger.error(f"解析公告页面失败: {e}")
            return []
    
    def get_announcement_detail(self, announcement):
        """获取公告详情
        
        Args:
            announcement: 公告信息字典
        
        Returns:
            dict: 包含详情的公告信息字典
        """
        if not announcement or 'link' not in announcement:
            logger.error("无效的公告信息")
            return announcement
        
        # 检查缓存中是否已有详情
        if 'content' in announcement and announcement['content']:
            return announcement
        
        link = announcement['link']
        logger.info(f"获取公告详情: {link}")
        
        # 发送请求
        response = self.proxy_manager.get(link)
        
        if not response:
            logger.error(f"获取公告详情失败: {link}")
            return announcement
        
        # 解析详情
        try:
            from bs4 import BeautifulSoup
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 提取内容
            content_elem = soup.select_one('div.article-content')
            content = content_elem.text.strip() if content_elem else ''
            
            # 提取HTML内容
            content_html = str(content_elem) if content_elem else ''
            
            # 更新公告信息
            announcement['content'] = content
            announcement['content_html'] = content_html
            
            return announcement
        
        except Exception as e:
            logger.error(f"解析公告详情失败: {e}")
            return announcement

if __name__ == "__main__":
    # 测试VLESS URI解析
    test_uri = "vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态"
    proxy = VLESSProxy(test_uri)
    print(f"解析结果: {proxy}")
    
    # 创建配置
    config = {
        "proxy": {
            "enabled": True,
            "type": "vless",
            "vless_uris": [test_uri],
            "use_local_v2ray": False  # 测试时不启动本地代理
        }
    }
    
    # 创建代理管理器
    proxy_manager = VLESSProxyManager(config=config)
    
    # 创建公告爬虫
    crawler = AnnouncementCrawler(proxy_manager)
    
    # 测试获取公告
    print("测试获取公告...")
    announcements = crawler.fetch_announcements(force_update=True)
    
    # 打印结果
    print(f"普通公告: {len(announcements.get('general', []))} 条")
    print(f"新上币公告: {len(announcements.get('newlisted', []))} 条")
