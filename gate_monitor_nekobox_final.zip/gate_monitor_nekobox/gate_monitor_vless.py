#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 高级监控系统 - VLESS代理集成版
功能：
1. 集成VLESS代理支持
2. 增强币种信息采集
3. 智能分析与预警
4. 多账号Telegram推送
"""

import os
import sys
import json
import time
import logging
import argparse
from datetime import datetime

# 导入各个模块
from enhanced_coin_info import EnhancedCoinInfo
from smart_alerts import SmartAlerts
from vless_proxy_manager import VLESSProxyManager, AnnouncementCrawler
from gate_telegram_push_enhanced import TelegramPush

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("gate_monitor_vless.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_monitor_vless")

class GateMonitorVLESS:
    """Gate.io高级监控系统 - VLESS代理集成版"""
    
    def __init__(self, config_file=None):
        """初始化监控系统
        
        Args:
            config_file: 配置文件路径
        """
        # 加载配置
        self.config = self.load_config(config_file)
        
        # 初始化代理管理器
        self.proxy_manager = VLESSProxyManager(config=self.config.get("proxy_config", {}))
        
        # 初始化币种信息采集器
        self.coin_info = EnhancedCoinInfo(config=self.config.get("coin_info_config", {}))
        
        # 初始化智能预警系统
        self.smart_alerts = SmartAlerts(config=self.config.get("alerts_config", {}))
        
        # 初始化公告爬虫
        self.announcement_crawler = AnnouncementCrawler(
            self.proxy_manager,
            config=self.config.get("announcement_config", {})
        )
        
        # 初始化Telegram推送
        self.telegram_push = TelegramPush(config=self.config.get("telegram_config", {}))
        
        # 初始化状态
        self.last_run = 0
        self.monitored_coins = self.config.get("monitored_coins", ["BTC", "ETH", "GT"])
        self.price_alerts = {}
        self.announcement_alerts = {}
    
    def load_config(self, config_file):
        """加载配置文件"""
        default_config = {
            "monitored_coins": ["BTC", "ETH", "GT", "DOGE", "SHIB"],
            "run_interval": 3600,  # 运行间隔（秒）
            "price_change_threshold": 5.0,  # 价格变动阈值（百分比）
            "volume_change_threshold": 50.0,  # 交易量变动阈值（百分比）
            "proxy_config": "config_vless.json",
            "coin_info_config": {},
            "alerts_config": {},
            "announcement_config": {},
            "telegram_config": {}
        }
        
        # 加载主配置文件
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(default_config, user_config)
                logger.info(f"已加载主配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载主配置文件失败: {e}")
        
        # 加载代理配置文件
        proxy_config_file = default_config.get("proxy_config")
        if proxy_config_file and os.path.exists(proxy_config_file):
            try:
                with open(proxy_config_file, 'r') as f:
                    proxy_config = json.load(f)
                    default_config["proxy_config"] = proxy_config
                logger.info(f"已加载代理配置文件: {proxy_config_file}")
            except Exception as e:
                logger.error(f"加载代理配置文件失败: {e}")
        
        return default_config
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def monitor_prices(self):
        """监控币种价格"""
        logger.info("开始监控币种价格...")
        
        alerts = []
        
        for symbol in self.monitored_coins:
            try:
                # 获取币种信息
                coin_info = self.coin_info.get_complete_coin_info(symbol)
                
                if not coin_info:
                    logger.warning(f"获取币种信息失败: {symbol}")
                    continue
                
                # 分析币种
                coin_alerts = self.smart_alerts.analyze_coin(symbol, coin_info)
                
                if coin_alerts:
                    alerts.append({
                        "symbol": symbol,
                        "alerts": coin_alerts,
                        "coin_info": coin_info
                    })
                    logger.info(f"发现币种预警: {symbol}, {len(coin_alerts)} 个预警")
            
            except Exception as e:
                logger.error(f"监控币种价格异常: {symbol}, {e}")
        
        return alerts
    
    def monitor_announcements(self):
        """监控公告"""
        logger.info("开始监控公告...")
        
        try:
            # 获取公告
            announcements = self.announcement_crawler.fetch_announcements()
            
            if not announcements:
                logger.warning("获取公告失败")
                return []
            
            # 处理新上币公告
            newlisted = announcements.get("newlisted", [])
            
            # 如果是首次运行，不触发预警
            if self.last_run == 0:
                logger.info(f"首次运行，记录 {len(newlisted)} 条新上币公告")
                self.announcement_alerts = {a.get("id"): a for a in newlisted}
                return []
            
            # 查找新公告
            new_alerts = []
            
            for announcement in newlisted:
                announcement_id = announcement.get("id")
                
                if announcement_id and announcement_id not in self.announcement_alerts:
                    # 获取公告详情
                    detail = self.announcement_crawler.get_announcement_detail(announcement)
                    
                    # 添加到预警
                    new_alerts.append(detail)
                    
                    # 更新缓存
                    self.announcement_alerts[announcement_id] = detail
            
            logger.info(f"发现 {len(new_alerts)} 条新上币公告")
            return new_alerts
        
        except Exception as e:
            logger.error(f"监控公告异常: {e}")
            return []
    
    def send_price_alerts(self, alerts):
        """发送价格预警"""
        if not alerts:
            return
        
        logger.info(f"发送 {len(alerts)} 个价格预警...")
        
        for alert in alerts:
            symbol = alert.get("symbol")
            coin_alerts = alert.get("alerts", [])
            coin_info = alert.get("coin_info", {})
            
            if not coin_alerts:
                continue
            
            # 格式化预警消息
            message = self.smart_alerts.format_alerts_message(symbol, coin_alerts, coin_info)
            
            # 发送消息
            self.telegram_push.send_message(
                message,
                title=f"{symbol} 价格预警"
            )
            
            # 添加到摘要
            self.telegram_push.add_to_summary(
                "价格预警",
                f"{symbol}: {len(coin_alerts)} 个预警"
            )
    
    def send_announcement_alerts(self, announcements):
        """发送公告预警"""
        if not announcements:
            return
        
        logger.info(f"发送 {len(announcements)} 个公告预警...")
        
        for announcement in announcements:
            title = announcement.get("title", "")
            link = announcement.get("link", "")
            date = announcement.get("date", "")
            
            # 提取币种符号
            symbols = self.coin_info.extract_symbols_from_title(title)
            symbols_str = ", ".join(symbols) if symbols else "未知币种"
            
            # 格式化消息
            if self.telegram_push.config.get("message_format") == "html":
                message = f"<b>发现新上币公告</b>\n\n"
                message += f"<b>标题:</b> {title}\n"
                message += f"<b>日期:</b> {date}\n"
                message += f"<b>币种:</b> {symbols_str}\n\n"
                
                if link:
                    message += f"<a href=\"{link}\">查看详情</a>"
            else:
                message = f"*发现新上币公告*\n\n"
                message += f"*标题:* {title}\n"
                message += f"*日期:* {date}\n"
                message += f"*币种:* {symbols_str}\n\n"
                
                if link:
                    message += f"[查看详情]({link})"
            
            # 发送消息
            self.telegram_push.send_message(
                message,
                title="新上币公告"
            )
            
            # 添加到摘要
            self.telegram_push.add_to_summary(
                "新上币公告",
                f"{title} ({symbols_str})"
            )
            
            # 如果提取到币种符号，获取币种详情
            for symbol in symbols:
                try:
                    # 获取币种信息
                    coin_info = self.coin_info.get_complete_coin_info(symbol)
                    
                    if coin_info:
                        # 格式化币种信息
                        coin_message = self.coin_info.format_coin_info_message(symbol, coin_info)
                        
                        # 发送消息
                        self.telegram_push.send_message(
                            coin_message,
                            title=f"{symbol} 币种信息"
                        )
                
                except Exception as e:
                    logger.error(f"获取币种信息异常: {symbol}, {e}")
    
    def run_once(self):
        """运行一次监控"""
        logger.info("开始运行监控...")
        
        # 监控币种价格
        price_alerts = self.monitor_prices()
        
        # 监控公告
        announcement_alerts = self.monitor_announcements()
        
        # 发送预警
        self.send_price_alerts(price_alerts)
        self.send_announcement_alerts(announcement_alerts)
        
        # 发送摘要
        self.telegram_push.send_summary()
        
        # 更新运行时间
        self.last_run = int(time.time())
        
        logger.info("监控运行完成")
    
    def run(self):
        """持续运行监控"""
        logger.info("启动持续监控...")
        
        try:
            while True:
                # 运行一次监控
                self.run_once()
                
                # 等待下一次运行
                interval = self.config.get("run_interval", 3600)
                logger.info(f"等待 {interval} 秒后再次运行...")
                time.sleep(interval)
        
        except KeyboardInterrupt:
            logger.info("监控被用户中断")
        
        except Exception as e:
            logger.error(f"监控异常: {e}")
        
        finally:
            # 清理资源
            logger.info("清理资源...")
            if hasattr(self.proxy_manager, "stop_local_proxies"):
                self.proxy_manager.stop_local_proxies()

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 高级监控系统 - VLESS代理集成版")
    parser.add_argument("--config", help="配置文件路径")
    parser.add_argument("--once", action="store_true", help="只运行一次")
    args = parser.parse_args()
    
    # 创建监控实例
    monitor = GateMonitorVLESS(args.config)
    
    # 运行监控
    if args.once:
        monitor.run_once()
    else:
        monitor.run()

if __name__ == "__main__":
    main()
