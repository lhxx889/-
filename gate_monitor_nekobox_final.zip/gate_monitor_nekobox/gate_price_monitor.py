#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 价格监控模块
功能：获取Gate.io交易所的币种价格信息，监控价格变动
"""

import os
import json
import time
import requests
import logging
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("price_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_price_monitor")

class GatePriceMonitor:
    """Gate.io价格监控类"""
    
    def __init__(self, config_file=None, config=None):
        """初始化价格监控器
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        self.base_url = "https://api.gateio.ws/api/v4"
        self.last_prices = {}  # 存储上次检查的价格
        self.price_changes = {}  # 存储价格变化百分比
        self.config = {
            "symbols": ["BTC_USDT", "ETH_USDT", "GT_USDT"],  # 默认监控的交易对
            "change_threshold": 5.0,  # 默认价格变动阈值（百分比）
            "volume_threshold": 1000000,  # 默认交易量阈值（USDT）
            "top_symbols_count": 20,  # 监控交易量排名前N的币种
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.config.update(config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.config.update(user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
    
    def get_tickers(self):
        """获取所有交易对的ticker信息"""
        try:
            response = requests.get(f"{self.base_url}/spot/tickers")
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"获取ticker失败: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            logger.error(f"请求ticker接口异常: {e}")
            return []
    
    def get_currency_pairs(self):
        """获取所有交易对信息"""
        try:
            response = requests.get(f"{self.base_url}/spot/currency_pairs")
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"获取交易对信息失败: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            logger.error(f"请求交易对接口异常: {e}")
            return []
    
    def get_top_volume_symbols(self, tickers, count=20):
        """获取交易量最大的前N个交易对"""
        # 过滤USDT计价的交易对并按交易量排序
        usdt_pairs = [t for t in tickers if t['currency_pair'].endswith('_USDT')]
        sorted_pairs = sorted(usdt_pairs, key=lambda x: float(x.get('quote_volume', 0)), reverse=True)
        return [pair['currency_pair'] for pair in sorted_pairs[:count]]
    
    def calculate_price_changes(self, current_tickers):
        """计算价格变动百分比"""
        changes = {}
        
        # 将当前ticker数据转换为字典格式，方便查询
        current_prices = {ticker['currency_pair']: ticker for ticker in current_tickers}
        
        # 对于每个监控的交易对，计算价格变动
        for symbol in self.symbols_to_monitor:
            if symbol in current_prices and symbol in self.last_prices:
                last_price = float(self.last_prices[symbol]['last'])
                current_price = float(current_prices[symbol]['last'])
                
                if last_price > 0:
                    change_percent = ((current_price - last_price) / last_price) * 100
                    changes[symbol] = {
                        'last_price': last_price,
                        'current_price': current_price,
                        'change_percent': change_percent,
                        'volume_24h': float(current_prices[symbol]['quote_volume']),
                        'high_24h': float(current_prices[symbol]['high_24h']),
                        'low_24h': float(current_prices[symbol]['low_24h']),
                    }
        
        return changes
    
    def detect_significant_changes(self, price_changes):
        """检测显著的价格变动"""
        significant_changes = {}
        threshold = self.config['change_threshold']
        
        for symbol, data in price_changes.items():
            change = data['change_percent']
            if abs(change) >= threshold:
                significant_changes[symbol] = data
        
        return significant_changes
    
    def update_monitored_symbols(self, tickers):
        """更新要监控的交易对列表"""
        # 合并配置中的固定交易对和交易量排名靠前的交易对
        top_symbols = self.get_top_volume_symbols(tickers, self.config['top_symbols_count'])
        all_symbols = set(self.config['symbols'] + top_symbols)
        self.symbols_to_monitor = list(all_symbols)
        logger.info(f"当前监控 {len(self.symbols_to_monitor)} 个交易对")
    
    def run_price_check(self):
        """执行价格检查"""
        logger.info("开始执行价格监控检查...")
        
        # 获取当前所有交易对的ticker数据
        current_tickers = self.get_tickers()
        if not current_tickers:
            logger.error("获取ticker数据失败，无法执行价格监控")
            return None
        
        # 更新监控的交易对列表
        self.update_monitored_symbols(current_tickers)
        
        # 如果是首次运行，仅记录当前价格
        if not self.last_prices:
            self.last_prices = {ticker['currency_pair']: ticker for ticker in current_tickers}
            logger.info("首次运行，已记录当前价格基准")
            return None
        
        # 计算价格变动
        self.price_changes = self.calculate_price_changes(current_tickers)
        
        # 检测显著变动
        significant_changes = self.detect_significant_changes(self.price_changes)
        
        # 更新最新价格记录
        self.last_prices = {ticker['currency_pair']: ticker for ticker in current_tickers}
        
        # 返回显著变动的结果
        return significant_changes
    
    def format_price_alert(self, significant_changes):
        """格式化价格预警消息"""
        if not significant_changes:
            return None
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"🔔 Gate.io 价格监控 - {now}\n\n"
        
        for symbol, data in significant_changes.items():
            change = data['change_percent']
            direction = "🔺" if change > 0 else "🔻"
            message += f"{direction} {symbol}: {data['current_price']:.8f} USDT\n"
            message += f"   变动: {change:.2f}% | 24h成交: {data['volume_24h']:.2f} USDT\n"
            message += f"   24h高/低: {data['high_24h']:.8f}/{data['low_24h']:.8f}\n\n"
        
        return message

if __name__ == "__main__":
    # 创建价格监控器实例
    monitor = GatePriceMonitor()
    
    # 执行价格检查
    significant_changes = monitor.run_price_check()
    
    # 如果有显著变动，打印警报消息
    if significant_changes:
        alert_message = monitor.format_price_alert(significant_changes)
        print(alert_message)
    else:
        print("没有检测到显著的价格变动")
