#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 监控系统主程序（高级版）
功能：集成价格监控、公告监控、币种信息采集和Telegram推送功能
"""

import os
import json
import time
import logging
import argparse
from datetime import datetime

# 导入各个模块
from gate_price_monitor import GatePriceMonitor
from gate_announcement_monitor import GateAnnouncementMonitor
from gate_telegram_push import GateTelegramPush
from gate_coin_info import GateCoinInfo
from gate_api_client import GateApiClient

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("gate_monitor_advanced.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_monitor_advanced")

class GateMonitorAdvanced:
    """Gate.io监控系统高级版主类"""
    
    def __init__(self, config_file="config_advanced.json"):
        """初始化监控系统"""
        self.config = {
            "price_monitor": {
                "enabled": True,
                "change_threshold": 5.0,
                "symbols": ["BTC_USDT", "ETH_USDT", "GT_USDT"],
                "top_symbols_count": 20
            },
            "announcement_monitor": {
                "enabled": True,
                "keywords": ["上线", "上架", "首发", "新增", "开放", "交易", "上市"],
                "max_announcements": 20
            },
            "coin_info": {
                "enabled": True,
                "cache_expiry": 86400,  # 缓存过期时间（秒），默认1天
                "fetch_details_for_new_coins": True  # 为新上币获取详细信息
            },
            "telegram_push": {
                "enabled": True,
                "config_file": "telegram_config.json"
            },
            "api_client": {
                "max_retries": 3,
                "retry_delay": 2,
                "request_timeout": 10
            },
            "run_interval": 3600  # 运行间隔，单位秒（默认1小时）
        }
        
        # 加载配置文件
        self.load_config(config_file)
        
        # 创建API客户端
        self.api_client = GateApiClient(config=self.config["api_client"])
        
        # 创建各模块实例
        self.price_monitor = GatePriceMonitor(config=self.config["price_monitor"]) if self.config["price_monitor"]["enabled"] else None
        self.announcement_monitor = GateAnnouncementMonitor(config=self.config["announcement_monitor"]) if self.config["announcement_monitor"]["enabled"] else None
        self.coin_info = GateCoinInfo(config=self.config["coin_info"]) if self.config["coin_info"]["enabled"] else None
        self.telegram_push = GateTelegramPush(config_file=self.config["telegram_push"]["config_file"]) if self.config["telegram_push"]["enabled"] else None
    
    def load_config(self, config_file):
        """加载配置文件"""
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    # 递归更新配置
                    self.update_config(self.config, user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        else:
            logger.warning(f"配置文件不存在: {config_file}，将使用默认配置")
            # 创建示例配置文件
            self.create_example_config(config_file)
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def create_example_config(self, config_file):
        """创建示例配置文件"""
        try:
            with open(config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info(f"已创建示例配置文件: {config_file}")
        except Exception as e:
            logger.error(f"创建示例配置文件失败: {e}")
    
    def extract_coin_symbol(self, currency_pair):
        """从交易对中提取币种符号"""
        if '_' in currency_pair:
            return currency_pair.split('_')[0]
        return currency_pair
    
    def run_once(self):
        """执行一次完整的监控检查"""
        logger.info("开始执行监控检查...")
        start_time = time.time()
        
        # 价格监控
        price_changes = None
        if self.price_monitor:
            try:
                logger.info("执行价格监控...")
                price_changes = self.price_monitor.run_price_check()
                if price_changes:
                    logger.info(f"检测到 {len(price_changes)} 个显著价格变动")
                else:
                    logger.info("没有检测到显著的价格变动")
            except Exception as e:
                logger.error(f"价格监控执行失败: {e}")
        
        # 公告监控
        new_announcements = None
        new_newlisted = None
        if self.announcement_monitor:
            try:
                logger.info("执行公告监控...")
                new_announcements, new_newlisted = self.announcement_monitor.run_announcement_check()
                if new_announcements:
                    logger.info(f"检测到 {len(new_announcements)} 条新的重要公告")
                if new_newlisted:
                    logger.info(f"检测到 {len(new_newlisted)} 条新的上币公告")
                if not new_announcements and not new_newlisted:
                    logger.info("没有检测到新的公告")
            except Exception as e:
                logger.error(f"公告监控执行失败: {e}")
        
        # 币种信息采集
        coin_info_results = {}
        if self.coin_info and new_newlisted and self.config["coin_info"]["fetch_details_for_new_coins"]:
            try:
                logger.info("为新上币获取详细信息...")
                for announcement_id, announcement in new_newlisted.items():
                    title = announcement['title']
                    # 尝试从标题中提取币种符号
                    # 这里使用简单的方法，实际应用中可能需要更复杂的解析
                    for keyword in ["将上线", "已上线", "上架"]:
                        if keyword in title:
                            parts = title.split(keyword)
                            if len(parts) > 1:
                                # 假设币种符号在关键词前面，并且用括号标注
                                import re
                                matches = re.findall(r'\(([A-Za-z0-9]+)\)', parts[0])
                                if matches:
                                    coin_symbol = matches[-1]  # 取最后一个匹配项
                                    logger.info(f"从公告中提取到币种符号: {coin_symbol}")
                                    
                                    # 获取币种详细信息
                                    coin_detail = self.coin_info.get_new_coin_info(coin_symbol)
                                    if coin_detail:
                                        coin_info_results[coin_symbol] = coin_detail
                                        logger.info(f"成功获取币种 {coin_symbol} 的详细信息")
                                    break
            except Exception as e:
                logger.error(f"币种信息采集失败: {e}")
        
        # Telegram推送
        if self.telegram_push:
            # 推送价格预警
            if price_changes:
                try:
                    logger.info("推送价格预警...")
                    self.telegram_push.send_price_alert(price_changes)
                except Exception as e:
                    logger.error(f"推送价格预警失败: {e}")
            
            # 推送公告预警
            if new_announcements or new_newlisted:
                try:
                    logger.info("推送公告预警...")
                    self.telegram_push.send_announcement_alert(new_announcements, new_newlisted)
                except Exception as e:
                    logger.error(f"推送公告预警失败: {e}")
            
            # 推送币种详细信息
            for symbol, info in coin_info_results.items():
                try:
                    logger.info(f"推送币种 {symbol} 详细信息...")
                    self.telegram_push.send_coin_info(info)
                except Exception as e:
                    logger.error(f"推送币种详细信息失败: {e}")
        
        # 计算执行时间
        execution_time = time.time() - start_time
        logger.info(f"监控检查完成，耗时 {execution_time:.2f} 秒")
        
        return {
            "price_changes": price_changes,
            "new_announcements": new_announcements,
            "new_newlisted": new_newlisted,
            "coin_info_results": coin_info_results,
            "execution_time": execution_time
        }
    
    def run_continuous(self):
        """持续运行监控系统"""
        logger.info(f"启动持续监控，间隔 {self.config['run_interval']} 秒")
        
        try:
            while True:
                self.run_once()
                logger.info(f"等待下一次检查，{self.config['run_interval']} 秒后执行...")
                time.sleep(self.config['run_interval'])
        except KeyboardInterrupt:
            logger.info("监控系统已手动停止")
        except Exception as e:
            logger.error(f"监控系统运行异常: {e}")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 监控系统（高级版）")
    parser.add_argument("-c", "--config", default="config_advanced.json", help="配置文件路径")
    parser.add_argument("-o", "--once", action="store_true", help="仅执行一次检查")
    args = parser.parse_args()
    
    # 创建监控系统实例
    monitor = GateMonitorAdvanced(config_file=args.config)
    
    # 根据参数决定运行模式
    if args.once:
        monitor.run_once()
    else:
        monitor.run_continuous()

if __name__ == "__main__":
    main()
