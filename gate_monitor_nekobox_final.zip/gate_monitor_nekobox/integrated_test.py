#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 监控系统集成测试
功能：测试币种信息采集、智能预警和公告抓取等模块的协同工作能力
"""

import os
import json
import time
import logging
import argparse
from datetime import datetime

# 导入各个模块
from enhanced_coin_info import EnhancedCoinInfo
from smart_alerts import SmartAlerts
from proxy_manager import ProxyManager, AnnouncementCrawler
from gate_telegram_push_enhanced import TelegramPush  # 修正导入路径

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("integrated_test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_integrated_test")

class IntegratedTest:
    """Gate.io监控系统集成测试类"""
    
    def __init__(self, config_file=None):
        """初始化集成测试
        
        Args:
            config_file: 配置文件路径
        """
        # 加载配置
        self.config = self.load_config(config_file)
        
        # 初始化代理管理器
        self.proxy_manager = ProxyManager(config=self.config.get("proxy_manager", {}))
        
        # 初始化币种信息采集器
        self.coin_info = EnhancedCoinInfo(config=self.config.get("enhanced_coin_info", {}))
        
        # 初始化智能预警系统
        self.smart_alerts = SmartAlerts(config=self.config.get("smart_alerts", {}))
        
        # 初始化公告爬虫
        self.announcement_crawler = AnnouncementCrawler(
            self.proxy_manager,
            config=self.config.get("announcement_crawler", {})
        )
        
        # 初始化Telegram推送
        self.telegram_push = TelegramPush(config=self.config.get("telegram_push", {}))
        
        # 测试结果
        self.test_results = {
            "coin_info": {"success": 0, "fail": 0, "details": []},
            "smart_alerts": {"success": 0, "fail": 0, "details": []},
            "announcement": {"success": 0, "fail": 0, "details": []},
            "telegram_push": {"success": 0, "fail": 0, "details": []}
        }
    
    def load_config(self, config_file):
        """加载配置文件"""
        default_config = {
            "test": {
                "symbols": ["BTC", "ETH", "GT", "DOGE", "SHIB"],
                "test_telegram": True,
                "test_proxy": True
            },
            "proxy_manager": {
                "proxy": {
                    "enabled": True,
                    "type": "v2box",
                    "v2box": {
                        "api_url": "http://127.0.0.1:8080/api/v1",
                        "auth_token": "",
                        "outbounds": []
                    },
                    "rotation_interval": 5
                }
            },
            "enhanced_coin_info": {
                "cache_expiry": 300  # 测试时使用较短的缓存过期时间
            },
            "smart_alerts": {
                "anomaly_detection": {
                    "enabled": True,
                    "contamination": 0.1  # 测试时使用较高的异常比例
                }
            },
            "telegram_push": {
                "test_mode": True  # 测试模式，不实际发送消息
            }
        }
        
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(default_config, user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        return default_config
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def test_proxy(self):
        """测试代理功能"""
        if not self.config["test"]["test_proxy"]:
            logger.info("跳过代理测试")
            return True
        
        logger.info("开始测试代理功能...")
        
        try:
            # 测试IP获取
            test_url = "https://api.ipify.org?format=json"
            response = self.proxy_manager.get(test_url)
            
            if response and response.status_code == 200:
                ip_data = response.json()
                logger.info(f"当前IP: {ip_data.get('ip', 'unknown')}")
                
                # 测试代理轮换
                logger.info("测试代理轮换...")
                for i in range(3):
                    self.proxy_manager.rotate_proxy(force=True)
                    response = self.proxy_manager.get(test_url)
                    if response and response.status_code == 200:
                        ip_data = response.json()
                        logger.info(f"轮换后IP: {ip_data.get('ip', 'unknown')}")
                    time.sleep(1)
                
                return True
            else:
                logger.error("代理测试失败，无法获取IP信息")
                return False
        
        except Exception as e:
            logger.error(f"代理测试失败: {e}")
            return False
    
    def test_coin_info(self, symbol):
        """测试币种信息采集"""
        logger.info(f"测试币种信息采集: {symbol}")
        
        try:
            # 获取币种信息
            start_time = time.time()
            coin_info = self.coin_info.get_complete_coin_info(symbol)
            end_time = time.time()
            
            if coin_info:
                # 记录成功
                self.test_results["coin_info"]["success"] += 1
                self.test_results["coin_info"]["details"].append({
                    "symbol": symbol,
                    "status": "success",
                    "time": end_time - start_time,
                    "fields": len(coin_info)
                })
                
                logger.info(f"币种信息采集成功: {symbol}, 字段数: {len(coin_info)}, 耗时: {end_time - start_time:.2f}秒")
                return coin_info
            else:
                # 记录失败
                self.test_results["coin_info"]["fail"] += 1
                self.test_results["coin_info"]["details"].append({
                    "symbol": symbol,
                    "status": "fail",
                    "error": "获取币种信息失败"
                })
                
                logger.error(f"币种信息采集失败: {symbol}")
                return None
        
        except Exception as e:
            # 记录异常
            self.test_results["coin_info"]["fail"] += 1
            self.test_results["coin_info"]["details"].append({
                "symbol": symbol,
                "status": "fail",
                "error": str(e)
            })
            
            logger.error(f"币种信息采集异常: {symbol}, {e}")
            return None
    
    def test_smart_alerts(self, symbol, coin_info):
        """测试智能预警系统"""
        if not coin_info:
            logger.warning(f"跳过智能预警测试: {symbol}, 缺少币种信息")
            return None
        
        logger.info(f"测试智能预警系统: {symbol}")
        
        try:
            # 生成预警
            start_time = time.time()
            alerts = self.smart_alerts.analyze_coin(symbol, coin_info)
            end_time = time.time()
            
            # 记录结果
            self.test_results["smart_alerts"]["success"] += 1
            self.test_results["smart_alerts"]["details"].append({
                "symbol": symbol,
                "status": "success",
                "time": end_time - start_time,
                "alerts_count": len(alerts)
            })
            
            logger.info(f"智能预警测试成功: {symbol}, 预警数: {len(alerts)}, 耗时: {end_time - start_time:.2f}秒")
            
            # 格式化预警消息
            if alerts:
                message = self.smart_alerts.format_alerts_message(symbol, alerts, coin_info)
                logger.info(f"预警消息: {message[:100]}...")
            
            return alerts
        
        except Exception as e:
            # 记录异常
            self.test_results["smart_alerts"]["fail"] += 1
            self.test_results["smart_alerts"]["details"].append({
                "symbol": symbol,
                "status": "fail",
                "error": str(e)
            })
            
            logger.error(f"智能预警测试异常: {symbol}, {e}")
            return None
    
    def test_announcement_crawler(self):
        """测试公告爬虫"""
        logger.info("测试公告爬虫...")
        
        try:
            # 获取公告
            start_time = time.time()
            announcements = self.announcement_crawler.fetch_announcements(force_update=True)
            end_time = time.time()
            
            general_count = len(announcements.get("general", []))
            newlisted_count = len(announcements.get("newlisted", []))
            
            if general_count > 0 or newlisted_count > 0:
                # 记录成功
                self.test_results["announcement"]["success"] += 1
                self.test_results["announcement"]["details"].append({
                    "status": "success",
                    "time": end_time - start_time,
                    "general_count": general_count,
                    "newlisted_count": newlisted_count
                })
                
                logger.info(f"公告爬虫测试成功: 普通公告 {general_count} 条, 新上币公告 {newlisted_count} 条, 耗时: {end_time - start_time:.2f}秒")
                
                # 测试获取公告详情
                if newlisted_count > 0:
                    announcement = announcements["newlisted"][0]
                    start_time = time.time()
                    detail = self.announcement_crawler.get_announcement_detail(announcement)
                    end_time = time.time()
                    
                    if "content" in detail and detail["content"]:
                        logger.info(f"公告详情获取成功: {detail['title']}, 内容长度: {len(detail['content'])}, 耗时: {end_time - start_time:.2f}秒")
                    else:
                        logger.warning(f"公告详情获取失败: {detail['title']}")
                
                return announcements
            else:
                # 记录失败
                self.test_results["announcement"]["fail"] += 1
                self.test_results["announcement"]["details"].append({
                    "status": "fail",
                    "error": "未获取到公告"
                })
                
                logger.error("公告爬虫测试失败: 未获取到公告")
                return None
        
        except Exception as e:
            # 记录异常
            self.test_results["announcement"]["fail"] += 1
            self.test_results["announcement"]["details"].append({
                "status": "fail",
                "error": str(e)
            })
            
            logger.error(f"公告爬虫测试异常: {e}")
            return None
    
    def test_telegram_push(self, content, title="测试消息"):
        """测试Telegram推送"""
        if not self.config["test"]["test_telegram"]:
            logger.info("跳过Telegram推送测试")
            return True
        
        logger.info("测试Telegram推送...")
        
        try:
            # 发送测试消息
            start_time = time.time()
            result = self.telegram_push.send_message(content, title=title)
            end_time = time.time()
            
            if result:
                # 记录成功
                self.test_results["telegram_push"]["success"] += 1
                self.test_results["telegram_push"]["details"].append({
                    "status": "success",
                    "time": end_time - start_time,
                    "title": title
                })
                
                logger.info(f"Telegram推送测试成功: {title}, 耗时: {end_time - start_time:.2f}秒")
                return True
            else:
                # 记录失败
                self.test_results["telegram_push"]["fail"] += 1
                self.test_results["telegram_push"]["details"].append({
                    "status": "fail",
                    "error": "推送失败"
                })
                
                logger.error(f"Telegram推送测试失败: {title}")
                return False
        
        except Exception as e:
            # 记录异常
            self.test_results["telegram_push"]["fail"] += 1
            self.test_results["telegram_push"]["details"].append({
                "status": "fail",
                "error": str(e)
            })
            
            logger.error(f"Telegram推送测试异常: {e}")
            return False
    
    def run_tests(self):
        """运行所有测试"""
        logger.info("开始运行集成测试...")
        
        # 测试代理
        if self.config["test"]["test_proxy"]:
            self.test_proxy()
        
        # 测试公告爬虫
        announcements = self.test_announcement_crawler()
        
        # 测试币种信息采集和智能预警
        symbols = self.config["test"]["symbols"]
        alerts_by_symbol = {}
        
        for symbol in symbols:
            # 测试币种信息采集
            coin_info = self.test_coin_info(symbol)
            
            if coin_info:
                # 测试智能预警
                alerts = self.test_smart_alerts(symbol, coin_info)
                if alerts:
                    alerts_by_symbol[symbol] = alerts
        
        # 测试Telegram推送
        if self.config["test"]["test_telegram"] and alerts_by_symbol:
            # 选择一个有预警的币种进行推送测试
            for symbol, alerts in alerts_by_symbol.items():
                if alerts:
                    coin_info = self.coin_info.get_complete_coin_info(symbol)
                    message = self.smart_alerts.format_alerts_message(symbol, alerts, coin_info)
                    self.test_telegram_push(message, f"{symbol} 预警测试")
                    break
        
        # 生成测试报告
        self.generate_report()
    
    def generate_report(self):
        """生成测试报告"""
        logger.info("生成测试报告...")
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report = f"Gate.io 监控系统集成测试报告 - {now}\n\n"
        
        # 总体统计
        total_success = sum(r["success"] for r in self.test_results.values())
        total_fail = sum(r["fail"] for r in self.test_results.values())
        total_tests = total_success + total_fail
        
        report += f"总测试数: {total_tests}, 成功: {total_success}, 失败: {total_fail}\n\n"
        
        # 模块统计
        for module, results in self.test_results.items():
            module_total = results["success"] + results["fail"]
            if module_total > 0:
                success_rate = results["success"] / module_total * 100
                report += f"{module} 模块: 测试数 {module_total}, 成功率 {success_rate:.1f}%\n"
        
        report += "\n详细结果:\n"
        
        # 币种信息采集详情
        report += "\n币种信息采集:\n"
        for detail in self.test_results["coin_info"]["details"]:
            status = "✅" if detail["status"] == "success" else "❌"
            if detail["status"] == "success":
                report += f"{status} {detail['symbol']}: {detail['fields']} 个字段, 耗时 {detail['time']:.2f}秒\n"
            else:
                report += f"{status} {detail['symbol']}: {detail.get('error', '未知错误')}\n"
        
        # 智能预警详情
        report += "\n智能预警系统:\n"
        for detail in self.test_results["smart_alerts"]["details"]:
            status = "✅" if detail["status"] == "success" else "❌"
            if detail["status"] == "success":
                report += f"{status} {detail['symbol']}: {detail['alerts_count']} 个预警, 耗时 {detail['time']:.2f}秒\n"
            else:
                report += f"{status} {detail['symbol']}: {detail.get('error', '未知错误')}\n"
        
        # 公告爬虫详情
        report += "\n公告爬虫:\n"
        for detail in self.test_results["announcement"]["details"]:
            status = "✅" if detail["status"] == "success" else "❌"
            if detail["status"] == "success":
                report += f"{status} 普通公告: {detail['general_count']} 条, 新上币公告: {detail['newlisted_count']} 条, 耗时 {detail['time']:.2f}秒\n"
            else:
                report += f"{status} {detail.get('error', '未知错误')}\n"
        
        # Telegram推送详情
        if self.config["test"]["test_telegram"]:
            report += "\nTelegram推送:\n"
            for detail in self.test_results["telegram_push"]["details"]:
                status = "✅" if detail["status"] == "success" else "❌"
                if detail["status"] == "success":
                    report += f"{status} {detail['title']}: 耗时 {detail['time']:.2f}秒\n"
                else:
                    report += f"{status} {detail.get('error', '未知错误')}\n"
        
        # 保存报告
        report_file = "integration_test_report.txt"
        with open(report_file, "w", encoding="utf-8") as f:
            f.write(report)
        
        logger.info(f"测试报告已保存到: {report_file}")
        print(report)

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 监控系统集成测试")
    parser.add_argument("--config", help="配置文件路径")
    args = parser.parse_args()
    
    # 创建测试实例
    test = IntegratedTest(args.config)
    
    # 运行测试
    test.run_tests()

if __name__ == "__main__":
    main()
