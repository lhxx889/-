# Gate.io 高级监控系统

## 功能介绍

Gate.io 高级监控系统是一个自动化工具，用于监控Gate.io交易所的价格变动、公告更新和币种信息，并通过Telegram推送通知。

### 主要功能

1. **价格监控**：
   - 监控指定交易对和交易量排名靠前的币种
   - 检测显著的价格变动
   - 推送价格预警消息，包含涨跌幅、成交量等信息

2. **公告监控**：
   - 监控Gate.io官方公告
   - 监控新上币公告
   - 根据关键词过滤重要公告
   - 推送公告更新通知

3. **币种详细信息**：
   - 获取币种简介、合约信息、市值数据
   - 收集社交媒体链接（官网、Twitter、Telegram等）
   - 分析市场动态和价格趋势
   - 为新上币自动获取详细信息

4. **Telegram多账号推送**：
   - 支持配置多个Telegram Bot账号
   - 账号轮换推送，降低单一账号风险
   - 自动检测账号状态并切换
   - 支持HTML格式消息和链接预览控制

5. **API轮询优化**：
   - 稳定的API请求机制
   - 错误重试和请求限流控制
   - 负载均衡和故障转移

## 安装与配置

### 依赖安装

```bash
pip install requests beautifulsoup4
```

### 配置文件

1. **主配置文件** (`config_advanced.json`):
   - 控制各模块的启用状态和参数
   - 设置价格变动阈值和监控的交易对
   - 设置公告关键词和监控数量
   - 设置币种信息缓存过期时间
   - 设置API客户端参数
   - 设置运行间隔

2. **Telegram配置文件** (`telegram_config.json`):
   - 设置多个Bot Token和Chat ID
   - 设置账号轮换策略
   - 设置代理（如需）
   - 设置消息主题ID（如需）

## 使用方法

### 单次运行

```bash
python gate_monitor_advanced.py --once
```

### 持续运行

```bash
python gate_monitor_advanced.py
```

### 使用自定义配置文件

```bash
python gate_monitor_advanced.py --config custom_config.json
```

## 定时任务设置

由于系统不支持内置的定时任务，建议使用外部定时服务（如crontab或云函数）触发监控脚本。

### Linux Crontab示例（每小时运行一次）

```bash
0 * * * * cd /path/to/gate_monitor && python gate_monitor_advanced.py --once
```

## 注意事项

- 首次运行时会记录当前状态作为基准，不会产生预警
- 价格监控的变动阈值可在配置文件中调整
- 公告监控的关键词可根据需要在配置文件中修改
- 币种信息会缓存一段时间，可在配置文件中调整缓存过期时间
- 请确保Telegram配置正确，否则无法接收通知
- 所有数据均直接从Gate.io官方API和网站获取，不使用第三方数据源
