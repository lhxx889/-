#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
不依赖pip的wheel文件安装脚本
用于在没有pip的环境中安装wheel文件
"""

import os
import sys
import zipfile
import shutil
import tempfile
import subprocess
import glob
import importlib.util
import json
from pathlib import Path

def print_header(title):
    """打印标题"""
    print("=" * 60)
    print(title)
    print("=" * 60)

def print_section(title):
    """打印分节标题"""
    print("-" * 60)
    print(title)
    print("-" * 60)

def check_module(module_name):
    """检查模块是否已安装"""
    try:
        importlib.util.find_spec(module_name)
        print(f"✅ 模块 {module_name} 已安装")
        return True
    except ImportError:
        print(f"❌ 模块 {module_name} 未安装")
        return False

def extract_wheel(wheel_path, target_dir):
    """解压wheel文件到目标目录"""
    try:
        with zipfile.ZipFile(wheel_path, 'r') as wheel_zip:
            wheel_zip.extractall(target_dir)
        print(f"✅ 成功解压 {os.path.basename(wheel_path)}")
        return True
    except Exception as e:
        print(f"❌ 解压 {os.path.basename(wheel_path)} 失败: {e}")
        return False

def copy_module_files(source_dir, target_dir):
    """复制模块文件到目标目录"""
    try:
        # 查找所有.py文件和.dist-info目录
        py_files = glob.glob(os.path.join(source_dir, "**", "*.py"), recursive=True)
        dist_info_dirs = glob.glob(os.path.join(source_dir, "*.dist-info"))
        
        # 复制.py文件
        for py_file in py_files:
            rel_path = os.path.relpath(py_file, source_dir)
            target_path = os.path.join(target_dir, rel_path)
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            shutil.copy2(py_file, target_path)
        
        # 复制.dist-info目录
        for dist_info_dir in dist_info_dirs:
            dist_info_name = os.path.basename(dist_info_dir)
            target_dist_info = os.path.join(target_dir, dist_info_name)
            if os.path.exists(target_dist_info):
                shutil.rmtree(target_dist_info)
            shutil.copytree(dist_info_dir, target_dist_info)
        
        print(f"✅ 成功复制模块文件")
        return True
    except Exception as e:
        print(f"❌ 复制模块文件失败: {e}")
        return False

def install_wheel_without_pip(wheel_path, site_packages_dir):
    """不使用pip安装wheel文件"""
    try:
        print(f"正在安装 {os.path.basename(wheel_path)}...")
        
        # 创建临时目录
        with tempfile.TemporaryDirectory() as temp_dir:
            # 解压wheel文件
            if not extract_wheel(wheel_path, temp_dir):
                return False
            
            # 复制模块文件到site-packages目录
            if not copy_module_files(temp_dir, site_packages_dir):
                return False
        
        print(f"✅ 成功安装 {os.path.basename(wheel_path)}")
        return True
    except Exception as e:
        print(f"❌ 安装 {os.path.basename(wheel_path)} 失败: {e}")
        return False

def get_site_packages_dir():
    """获取site-packages目录"""
    try:
        # 尝试使用sys.path
        for path in sys.path:
            if "site-packages" in path:
                return path
        
        # 如果sys.path中没有site-packages，尝试使用subprocess
        result = subprocess.run(
            [sys.executable, "-c", "import site; print(site.getsitepackages()[0])"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            return result.stdout.strip()
        
        # 如果以上方法都失败，使用默认路径
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
        return os.path.expanduser(f"~/.local/lib/python{python_version}/site-packages")
    except Exception as e:
        print(f"❌ 获取site-packages目录失败: {e}")
        # 使用默认路径
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
        return os.path.expanduser(f"~/.local/lib/python{python_version}/site-packages")

def create_user_site_packages():
    """创建用户的site-packages目录"""
    site_packages_dir = get_site_packages_dir()
    os.makedirs(site_packages_dir, exist_ok=True)
    return site_packages_dir

def install_all_wheels(vendor_dir, site_packages_dir):
    """安装vendor目录中的所有wheel文件"""
    # 获取所有wheel文件
    wheel_files = glob.glob(os.path.join(vendor_dir, "*.whl"))
    if not wheel_files:
        print("❌ 在vendor目录中未找到wheel文件")
        return False
    
    print(f"在vendor目录中找到 {len(wheel_files)} 个wheel文件")
    
    # 按照依赖顺序安装
    # 首先安装基础库
    base_wheels = [w for w in wheel_files if any(lib in w for lib in ["setuptools", "six", "pytz", "certifi", "cachetools", "tzlocal"])]
    for wheel in base_wheels:
        install_wheel_without_pip(wheel, site_packages_dir)
        wheel_files.remove(wheel)
    
    # 然后安装其他库
    for wheel in wheel_files:
        install_wheel_without_pip(wheel, site_packages_dir)
    
    return True

def check_telegram_module():
    """检查telegram模块是否已安装"""
    try:
        import telegram
        print(f"✅ python-telegram-bot 已安装 (版本: {telegram.__version__})")
        return True
    except ImportError:
        print("❌ python-telegram-bot 未安装")
        return False

def check_config_file(config_path):
    """检查配置文件"""
    if not os.path.exists(config_path):
        print(f"❌ 配置文件不存在: {config_path}")
        return False
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # 检查Telegram配置
        if config.get("telegram_enabled", False):
            if not config.get("telegram_bot_token") or not config.get("telegram_chat_id"):
                print("⚠️  警告: Telegram功能已启用，但未配置Bot Token或Chat ID")
                return False
            print("✅ Telegram配置正确")
        else:
            print("ℹ️  Telegram功能已禁用")
        
        return True
    except Exception as e:
        print(f"❌ 检查配置文件时出错: {e}")
        return False

def run_main_program(program_path):
    """运行主程序"""
    if not os.path.exists(program_path):
        print(f"❌ 主程序不存在: {program_path}")
        return False
    
    try:
        print(f"正在启动主程序: {program_path}")
        subprocess.Popen([sys.executable, program_path])
        print("✅ 主程序已启动")
        return True
    except Exception as e:
        print(f"❌ 启动主程序时出错: {e}")
        return False

def main():
    """主函数"""
    print_header("不依赖pip的python-telegram-bot安装工具")
    
    # 检查命令行参数
    if len(sys.argv) < 3:
        print("用法: python no_pip_install.py <vendor目录路径> <主程序路径> [配置文件路径]")
        print("例如: python no_pip_install.py /path/to/vendor /path/to/crypto_monitor_menu_enhanced.py /path/to/config.json")
        return
    
    vendor_dir = sys.argv[1]
    program_path = sys.argv[2]
    config_path = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(program_path), "config.json")
    
    print(f"vendor目录路径: {vendor_dir}")
    print(f"主程序路径: {program_path}")
    print(f"配置文件路径: {config_path}")
    
    # 检查vendor目录
    if not os.path.exists(vendor_dir):
        print(f"❌ vendor目录不存在: {vendor_dir}")
        return
    
    # 检查主程序
    if not os.path.exists(program_path):
        print(f"❌ 主程序不存在: {program_path}")
        return
    
    # 检查telegram模块
    print_section("检查telegram模块")
    if check_telegram_module():
        print("telegram模块已安装，无需重新安装")
    else:
        print("telegram模块未安装，将进行安装")
        
        # 创建用户的site-packages目录
        print_section("创建site-packages目录")
        site_packages_dir = create_user_site_packages()
        print(f"site-packages目录: {site_packages_dir}")
        
        # 安装所有wheel文件
        print_section("安装wheel文件")
        install_all_wheels(vendor_dir, site_packages_dir)
        
        # 再次检查telegram模块
        print_section("再次检查telegram模块")
        check_telegram_module()
    
    # 检查配置文件
    print_section("检查配置文件")
    check_config_file(config_path)
    
    # 询问是否运行主程序
    print_section("运行主程序")
    choice = input("是否运行主程序? (y/n): ")
    if choice.lower() == 'y':
        run_main_program(program_path)
    else:
        print("跳过运行主程序")
    
    print_header("安装完成")

if __name__ == "__main__":
    main()

