# 不依赖pip的python-telegram-bot安装解决方案

这个解决方案提供了一种在没有pip的环境中安装python-telegram-bot库的方法，适用于无法使用pip或遇到"externally-managed-environment"错误的系统。

## 解决方案原理

这个解决方案不使用pip，而是直接使用Python的内置模块解压wheel文件，并将其中的Python模块文件复制到Python的site-packages目录中。这种方法可以绕过pip的限制，直接安装Python库。

## 文件说明

- `no_pip_install.py`: 不依赖pip的安装脚本，可以直接安装wheel文件
- `run_no_pip_install.sh`: 启动脚本，用于运行安装脚本
- `vendor/`: 包含python-telegram-bot库及其依赖项的wheel文件
- `README_NO_PIP.md`: 本说明文件

## 使用方法

1. 确保您有Python 3环境（无需pip）

2. 设置执行权限：
   ```bash
   chmod +x run_no_pip_install.sh
   ```

3. 运行启动脚本，提供加密货币监控程序的目录路径：
   ```bash
   ./run_no_pip_install.sh /path/to/crypto_monitor_directory
   ```
   
   例如：
   ```bash
   ./run_no_pip_install.sh /root/crypto_monitor_fixed/crypto_monitor/crypto_monitor
   ```

## 脚本功能

安装脚本会自动：

1. 检查telegram模块是否已安装
2. 如果未安装，创建用户的site-packages目录
3. 解压vendor目录中的wheel文件，并将模块文件复制到site-packages目录
4. 检查配置文件是否正确
5. 询问是否运行主程序

## 手动使用

如果您想手动运行安装脚本，可以使用以下命令：

```bash
python3 no_pip_install.py /path/to/vendor /path/to/crypto_monitor_menu_enhanced.py [/path/to/config.json]
```

## 注意事项

- 这个解决方案不需要系统管理员权限，因为它将库安装到用户的site-packages目录中
- 如果您的系统使用了Debian/Ubuntu的Python环境管理策略，这个解决方案可以避免"externally-managed-environment"错误
- 如果您不需要Telegram功能，可以在程序中禁用它

