#!/bin/bash

# 不依赖pip的安装脚本启动器
# 用于在没有pip的环境中安装python-telegram-bot库

# 获取脚本所在目录的绝对路径
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# 检查命令行参数
if [ $# -lt 1 ]; then
  echo "用法: $0 <crypto_monitor目录路径>"
  echo "例如: $0 /root/crypto_monitor_fixed/crypto_monitor/crypto_monitor"
  exit 1
fi

CRYPTO_DIR="$1"
MAIN_PROGRAM="$CRYPTO_DIR/crypto_monitor_menu_enhanced.py"
CONFIG_FILE="$CRYPTO_DIR/config.json"
VENDOR_DIR="$SCRIPT_DIR/vendor"

# 检查目录和文件是否存在
if [ ! -d "$CRYPTO_DIR" ]; then
  echo "错误: 目录不存在: $CRYPTO_DIR"
  exit 1
fi

if [ ! -f "$MAIN_PROGRAM" ]; then
  echo "错误: 主程序不存在: $MAIN_PROGRAM"
  exit 1
fi

if [ ! -d "$VENDOR_DIR" ]; then
  echo "错误: vendor目录不存在: $VENDOR_DIR"
  exit 1
fi

# 运行不依赖pip的安装脚本
echo "正在运行不依赖pip的安装脚本..."
python3 "$SCRIPT_DIR/no_pip_install.py" "$VENDOR_DIR" "$MAIN_PROGRAM" "$CONFIG_FILE"

# 脚本结束
echo "脚本执行完毕"

