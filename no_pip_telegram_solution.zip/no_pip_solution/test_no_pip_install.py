#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试不依赖pip的安装脚本
用于验证不依赖pip的安装脚本是否正常工作
"""

import os
import sys
import importlib.util
import subprocess
import glob

def print_header(title):
    """打印标题"""
    print("=" * 60)
    print(title)
    print("=" * 60)

def print_section(title):
    """打印分节标题"""
    print("-" * 60)
    print(title)
    print("-" * 60)

def check_wheel_files(vendor_dir):
    """检查vendor目录中的wheel文件"""
    print_section("检查wheel文件")
    
    if not os.path.exists(vendor_dir):
        print(f"❌ vendor目录不存在: {vendor_dir}")
        return False
    
    wheel_files = glob.glob(os.path.join(vendor_dir, "*.whl"))
    if not wheel_files:
        print("❌ 在vendor目录中未找到wheel文件")
        return False
    
    print(f"✅ 在vendor目录中找到 {len(wheel_files)} 个wheel文件:")
    for wheel in wheel_files:
        print(f"  - {os.path.basename(wheel)}")
    
    # 检查是否包含python-telegram-bot库
    telegram_wheels = [w for w in wheel_files if "python_telegram_bot" in w]
    if not telegram_wheels:
        print("❌ 未找到python-telegram-bot库文件")
        return False
    
    print(f"✅ 找到python-telegram-bot库文件: {os.path.basename(telegram_wheels[0])}")
    return True

def check_installation_script(script_path):
    """检查安装脚本"""
    print_section("检查安装脚本")
    
    if not os.path.exists(script_path):
        print(f"❌ 安装脚本不存在: {script_path}")
        return False
    
    # 检查脚本是否可执行
    if not os.access(script_path, os.X_OK):
        print(f"❌ 安装脚本没有执行权限: {script_path}")
        try:
            os.chmod(script_path, 0o755)
            print(f"✅ 已添加执行权限: {script_path}")
        except Exception as e:
            print(f"❌ 添加执行权限失败: {e}")
            return False
    
    print(f"✅ 安装脚本检查通过: {script_path}")
    return True

def test_import_modules():
    """测试导入模块"""
    print_section("测试导入模块")
    
    modules_to_test = [
        "telegram",
        "tornado",
        "pytz",
        "certifi",
        "apscheduler",
        "tzlocal"
    ]
    
    success = True
    for module in modules_to_test:
        try:
            spec = importlib.util.find_spec(module)
            if spec is not None:
                print(f"✅ 模块 {module} 可以导入")
            else:
                print(f"❌ 模块 {module} 无法导入")
                success = False
        except ImportError:
            print(f"❌ 模块 {module} 导入失败")
            success = False
    
    return success

def test_site_packages_dir():
    """测试site-packages目录"""
    print_section("测试site-packages目录")
    
    # 尝试使用sys.path
    site_packages_dirs = [path for path in sys.path if "site-packages" in path]
    if site_packages_dirs:
        print(f"✅ 在sys.path中找到site-packages目录:")
        for path in site_packages_dirs:
            print(f"  - {path}")
        return True
    
    # 尝试使用subprocess
    try:
        result = subprocess.run(
            [sys.executable, "-c", "import site; print(site.getsitepackages())"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print(f"✅ 使用site.getsitepackages()找到site-packages目录:")
            print(f"  - {result.stdout.strip()}")
            return True
    except Exception:
        pass
    
    # 检查默认路径
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
    default_path = os.path.expanduser(f"~/.local/lib/python{python_version}/site-packages")
    if os.path.exists(default_path):
        print(f"✅ 默认site-packages目录存在: {default_path}")
        return True
    
    print("❌ 无法找到site-packages目录")
    return False

def main():
    """主函数"""
    print_header("测试不依赖pip的安装脚本")
    
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 检查vendor目录
    vendor_dir = os.path.join(script_dir, "vendor")
    check_wheel_files(vendor_dir)
    
    # 检查安装脚本
    install_script = os.path.join(script_dir, "no_pip_install.py")
    check_installation_script(install_script)
    
    # 检查启动脚本
    run_script = os.path.join(script_dir, "run_no_pip_install.sh")
    check_installation_script(run_script)
    
    # 测试site-packages目录
    test_site_packages_dir()
    
    # 测试导入模块
    test_import_modules()
    
    print_header("测试完成")

if __name__ == "__main__":
    main()

