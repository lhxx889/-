#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
配置模块 - Gate.io加密货币异动监控系统
"""

import os
import logging
from typing import List

# API配置
PRIMARY_API_URL = "https://api.gateio.ws/api/v4"
BACKUP_API_URLS = [
    "https://api.gateio.io/api/v4",
    "https://api.gate.io/api/v4"
]
API_BASE_URL = PRIMARY_API_URL
API_RATE_LIMIT = 100  # 每分钟最大请求数
API_RATE_WINDOW = 60  # 速率限制窗口期（秒）

# 监控配置
CHECK_INTERVAL = 50  # 检查间隔（秒）
PRICE_CHANGE_THRESHOLD = 45.0  # 价格波动阈值（百分比）
VOLUME_SURGE_THRESHOLD = 200.0  # 交易量猛增阈值（百分比）
CONTINUOUS_RUN = True  # 是否持续运行

# Telegram配置
TELEGRAM_API_URL = "https://api.telegram.org/bot"
TELEGRAM_BOT_TOKEN = ""  # 在首次运行时填写或从环境变量获取
TELEGRAM_CHAT_ID = ""    # 在首次运行时填写或从环境变量获取

# 日志配置
LOG_LEVEL = "INFO"
LOG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "crypto_monitor.log")

# 数据目录
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# 确保数据目录存在
os.makedirs(DATA_DIR, exist_ok=True)

# 从环境变量加载配置（如果有）
if os.environ.get("TELEGRAM_BOT_TOKEN"):
    TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")

if os.environ.get("TELEGRAM_CHAT_ID"):
    TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID")

if os.environ.get("CHECK_INTERVAL"):
    try:
        CHECK_INTERVAL = int(os.environ.get("CHECK_INTERVAL"))
    except ValueError:
        pass

if os.environ.get("PRICE_CHANGE_THRESHOLD"):
    try:
        PRICE_CHANGE_THRESHOLD = float(os.environ.get("PRICE_CHANGE_THRESHOLD"))
    except ValueError:
        pass

if os.environ.get("VOLUME_SURGE_THRESHOLD"):
    try:
        VOLUME_SURGE_THRESHOLD = float(os.environ.get("VOLUME_SURGE_THRESHOLD"))
    except ValueError:
        pass

# 加载自定义配置文件（如果存在）
custom_config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "custom_config.py")
if os.path.exists(custom_config_path):
    try:
        exec(open(custom_config_path).read())
    except Exception as e:
        print(f"加载自定义配置失败: {e}")
