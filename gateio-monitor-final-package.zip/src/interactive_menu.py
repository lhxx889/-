#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交互式菜单模块 - Gate.io加密货币异动监控系统
提供用户友好的交互式菜单，支持API地址切换、监控控制等功能
"""

import os
import sys
import time
import json
import threading
import logging
from typing import Dict, List, Any, Optional

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入API管理器
from src.api_manager import get_api_manager

logger = logging.getLogger("interactive_menu")

class InteractiveMenu:
    """交互式菜单类"""
    
    def __init__(self, monitor):
        self.monitor = monitor
        self.running = False
        self.menu_thread = None
        self.api_manager = get_api_manager()
    
    def display_menu(self):
        """显示菜单"""
        print("\n" + "=" * 50)
        print("Gate.io加密货币异动监控系统 - 交互式菜单")
        print("=" * 50)
        print("1. 查看所有可用API地址")
        print("2. 切换到主API地址")
        print("3. 切换到备用API地址")
        print("4. 添加自定义API地址")
        print("5. 删除自定义API地址")
        print("6. 测试当前API地址连接")
        print("7. 暂停/恢复监控")
        print("8. 发送状态报告到Telegram")
        print("9. 退出菜单")
        print("0. 退出程序")
        print("=" * 50)
        print("快捷键: jm=暂停/恢复监控, db=发送状态报告")
        print("=" * 50)
        print("请输入选项编号:")
    
    def handle_menu_choice(self, choice):
        """处理菜单选择"""
        try:
            choice = choice.strip()
            
            # 处理快捷键
            if choice.lower() == 'jm':
                self.monitor.toggle_monitoring()
                return True
            elif choice.lower() == 'db':
                self.monitor.send_status_report()
                return True
            
            # 处理数字选项
            choice = int(choice)
            
            if choice == 1:
                self.show_all_api_urls()
            elif choice == 2:
                self.switch_to_primary_api()
            elif choice == 3:
                self.switch_to_backup_api()
            elif choice == 4:
                self.add_custom_api()
            elif choice == 5:
                self.delete_custom_api()
            elif choice == 6:
                self.test_current_api()
            elif choice == 7:
                self.toggle_monitoring()
            elif choice == 8:
                self.send_status_report()
            elif choice == 9:
                print("退出菜单，继续监控...")
                return False
            elif choice == 0:
                print("正在安全退出程序...")
                self.monitor.stop()
                return False
            else:
                print("无效选项，请重新输入")
            
            return True
        except ValueError:
            print("无效输入，请输入数字或快捷键")
            return True
        except Exception as e:
            logger.error(f"处理菜单选择时出错: {e}")
            return True
    
    def show_all_api_urls(self):
        """显示所有可用API地址"""
        print("\n所有可用API地址:")
        print(f"当前API地址: {self.api_manager.current_url}")
        print(f"主API地址: {self.api_manager.primary_url}")
        
        print("\n备用API地址:")
        for i, url in enumerate(self.api_manager.backup_urls, 1):
            print(f"{i}. {url}")
        
        print("\n自定义API地址:")
        custom_urls = self.api_manager.get_custom_urls()
        if custom_urls:
            for i, url in enumerate(custom_urls, 1):
                print(f"{i}. {url}")
        else:
            print("暂无自定义API地址")
    
    def switch_to_primary_api(self):
        """切换到主API地址"""
        if self.api_manager.switch_to_primary():
            print(f"已切换到主API地址: {self.api_manager.current_url}")
        else:
            print("切换失败，请检查网络连接")
    
    def switch_to_backup_api(self):
        """切换到备用API地址"""
        backup_urls = self.api_manager.backup_urls
        if not backup_urls:
            print("没有可用的备用API地址")
            return
        
        print("\n可用的备用API地址:")
        for i, url in enumerate(backup_urls, 1):
            print(f"{i}. {url}")
        
        print("\n请选择要切换的备用API地址编号:")
        try:
            choice = int(input().strip())
            if 1 <= choice <= len(backup_urls):
                url = backup_urls[choice - 1]
                if self.api_manager.switch_to_url(url):
                    print(f"已切换到备用API地址: {url}")
                else:
                    print("切换失败，请检查网络连接")
            else:
                print("无效选项")
        except ValueError:
            print("请输入有效的数字")
    
    def add_custom_api(self):
        """添加自定义API地址"""
        print("\n请输入要添加的自定义API地址:")
        url = input().strip()
        
        if not url:
            print("API地址不能为空")
            return
        
        if self.api_manager.add_custom_url(url):
            print(f"已添加自定义API地址: {url}")
        else:
            print("添加失败，可能是地址格式不正确或已存在")
    
    def delete_custom_api(self):
        """删除自定义API地址"""
        custom_urls = self.api_manager.get_custom_urls()
        if not custom_urls:
            print("没有可删除的自定义API地址")
            return
        
        print("\n可删除的自定义API地址:")
        for i, url in enumerate(custom_urls, 1):
            print(f"{i}. {url}")
        
        print("\n请选择要删除的自定义API地址编号:")
        try:
            choice = int(input().strip())
            if 1 <= choice <= len(custom_urls):
                url = custom_urls[choice - 1]
                if self.api_manager.remove_custom_url(url):
                    print(f"已删除自定义API地址: {url}")
                else:
                    print("删除失败")
            else:
                print("无效选项")
        except ValueError:
            print("请输入有效的数字")
    
    def test_current_api(self):
        """测试当前API地址连接"""
        print(f"\n正在测试当前API地址: {self.api_manager.current_url}")
        
        if self.api_manager.test_connection():
            print("连接测试成功，API地址可用")
        else:
            print("连接测试失败，API地址不可用")
            
            # 询问是否自动切换到可用地址
            print("\n是否自动切换到可用的API地址? (y/n)")
            choice = input().strip().lower()
            
            if choice == 'y':
                if self.api_manager.switch_to_available():
                    print(f"已自动切换到可用的API地址: {self.api_manager.current_url}")
                else:
                    print("没有找到可用的API地址，请检查网络连接")
    
    def toggle_monitoring(self):
        """切换监控状态"""
        if self.monitor.paused:
            self.monitor.resume()
            print("已恢复监控")
        else:
            self.monitor.pause()
            print("已暂停监控")
    
    def send_status_report(self):
        """发送状态报告到Telegram"""
        if self.monitor.send_status_report():
            print("已发送状态报告到Telegram")
        else:
            print("发送状态报告失败，请检查Telegram配置")
    
    def _menu_loop(self):
        """菜单循环"""
        while self.running:
            try:
                self.display_menu()
                choice = input().strip()
                
                if not self.handle_menu_choice(choice):
                    break
                
                time.sleep(0.1)
            except Exception as e:
                logger.error(f"菜单循环出错: {e}")
                time.sleep(1)
    
    def start(self):
        """启动菜单"""
        if self.running:
            logger.warning("菜单已在运行")
            return
        
        self.running = True
        self.menu_thread = threading.Thread(target=self._menu_loop)
        self.menu_thread.daemon = True
        self.menu_thread.start()
        
        logger.info("交互式菜单已启动")
    
    def stop(self):
        """停止菜单"""
        self.running = False
        
        if self.menu_thread and self.menu_thread.is_alive():
            self.menu_thread.join(timeout=1.0)
        
        logger.info("交互式菜单已停止")

def create_menu(monitor):
    """创建交互式菜单"""
    return InteractiveMenu(monitor)
