"""
Gate.io加密货币异动监控系统 - 单元测试
测试各个模块的功能
"""

import unittest
import os
import sys
import time
import json
from datetime import datetime
import logging

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入各模块
from src.data_collector import GateioDataCollector
from src.anomaly_detector import AnomalyDetector
from src.telegram_alerter import TelegramAlerter
from src.deep_analyzer import NewsAnalyzer, SocialMediaAnalyzer, CoinInfoFetcher, DeepAnalyzer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("test")

class TestDataCollector(unittest.TestCase):
    """测试数据采集模块"""
    
    def setUp(self):
        """测试前准备"""
        self.collector = GateioDataCollector(db_path="test_data.db")
    
    def tearDown(self):
        """测试后清理"""
        if os.path.exists("test_data.db"):
            os.remove("test_data.db")
    
    def test_fetch_all_tickers(self):
        """测试获取所有ticker数据"""
        tickers = self.collector.fetch_all_tickers()
        self.assertIsInstance(tickers, list)
        self.assertGreater(len(tickers), 0)
        
        # 检查第一个ticker的结构
        first_ticker = tickers[0]
        self.assertIn("currency_pair", first_ticker)
        self.assertIn("last", first_ticker)
        self.assertIn("base_volume", first_ticker)
    
    def test_save_and_get_ticker_data(self):
        """测试保存和获取ticker数据"""
        # 获取数据
        tickers = self.collector.fetch_all_tickers()
        
        # 保存数据
        self.collector.save_ticker_data(tickers)
        
        # 获取最新数据
        latest_data = self.collector.get_latest_price_data()
        self.assertIsInstance(latest_data, dict)
        self.assertGreater(len(latest_data), 0)
    
    def test_update_data(self):
        """测试更新数据"""
        success = self.collector.update_data()
        self.assertTrue(success)
        
        # 检查缓存
        self.assertIn("tickers", self.collector.memory_cache)
        self.assertIn("tickers", self.collector.last_update_time)


class TestAnomalyDetector(unittest.TestCase):
    """测试异常检测模块"""
    
    def setUp(self):
        """测试前准备"""
        self.collector = GateioDataCollector(db_path="test_data.db")
        self.collector.update_data()  # 确保有数据
        
        self.detector = AnomalyDetector(
            collector=self.collector,
            price_change_threshold=10.0,  # 使用较低的阈值以便测试
            volume_change_threshold=50.0
        )
    
    def tearDown(self):
        """测试后清理"""
        if os.path.exists("test_data.db"):
            os.remove("test_data.db")
    
    def test_detect_price_anomalies(self):
        """测试检测价格异常"""
        # 由于实际价格变化不确定，这里主要测试函数是否正常运行
        anomalies = self.detector.detect_price_anomalies()
        self.assertIsInstance(anomalies, list)
    
    def test_detect_volume_anomalies(self):
        """测试检测交易量异常"""
        # 由于实际交易量变化不确定，这里主要测试函数是否正常运行
        anomalies = self.detector.detect_volume_anomalies()
        self.assertIsInstance(anomalies, list)
    
    def test_filter_and_prioritize_alerts(self):
        """测试过滤和排序异常事件"""
        # 创建模拟异常
        mock_anomalies = [
            {
                "type": "price",
                "symbol": "BTC_USDT",
                "price_change_pct": 15.0,
                "detected_at": datetime.now().isoformat()
            },
            {
                "type": "price",
                "symbol": "ETH_USDT",
                "price_change_pct": 20.0,
                "detected_at": datetime.now().isoformat()
            },
            {
                "type": "volume",
                "symbol": "XRP_USDT",
                "volume_change_pct": 150.0,
                "detected_at": datetime.now().isoformat()
            }
        ]
        
        # 过滤和排序
        prioritized = self.detector.filter_and_prioritize_alerts(mock_anomalies, max_alerts=2)
        
        # 检查结果
        self.assertEqual(len(prioritized), 2)
        self.assertEqual(prioritized[0]["symbol"], "ETH_USDT")  # 价格变化最大的应该排在前面


class TestTelegramAlerter(unittest.TestCase):
    """测试Telegram警报推送模块"""
    
    def setUp(self):
        """测试前准备"""
        self.alerter = TelegramAlerter(config_file="test_telegram_config.json")
    
    def tearDown(self):
        """测试后清理"""
        if os.path.exists("test_telegram_config.json"):
            os.remove("test_telegram_config.json")
    
    def test_save_and_load_config(self):
        """测试保存和加载配置"""
        # 保存配置
        token = "test_token"
        chat_id = "test_chat_id"
        success = self.alerter.save_config(token, chat_id)
        self.assertTrue(success)
        
        # 检查配置是否已保存
        self.assertEqual(self.alerter.token, token)
        self.assertEqual(self.alerter.chat_id, chat_id)
        
        # 创建新实例加载配置
        new_alerter = TelegramAlerter(config_file="test_telegram_config.json")
        self.assertEqual(new_alerter.token, token)
        self.assertEqual(new_alerter.chat_id, chat_id)
    
    def test_format_alert_message(self):
        """测试格式化警报消息"""
        # 创建模拟异常
        mock_anomaly = {
            "type": "price",
            "symbol": "BTC_USDT",
            "current_price": 50000,
            "reference_price": 45000,
            "price_change_pct": 11.11,
            "volume_24h": 1000000,
            "detected_at": datetime.now().isoformat()
        }
        
        # 格式化消息
        message = self.alerter.format_alert_message(mock_anomaly)
        
        # 检查消息内容
        self.assertIn("BTC_USDT", message)
        self.assertIn("11.11%", message)
        self.assertIn("50000", message)
        self.assertIn("45000", message)


class TestDeepAnalyzer(unittest.TestCase):
    """测试深度分析模块"""
    
    def setUp(self):
        """测试前准备"""
        self.news_analyzer = NewsAnalyzer()
        self.social_analyzer = SocialMediaAnalyzer()
        self.coin_info_fetcher = CoinInfoFetcher()
        self.deep_analyzer = DeepAnalyzer()
    
    def test_get_crypto_news(self):
        """测试获取加密货币新闻"""
        news = self.news_analyzer.get_crypto_news(limit=5)
        self.assertIsInstance(news, list)
        if news:  # 如果有新闻
            self.assertIn("title", news[0])
            self.assertIn("body", news[0])
    
    def test_get_coin_news(self):
        """测试获取特定币种的新闻"""
        news = self.news_analyzer.get_coin_news("BTC_USDT", limit=3)
        self.assertIsInstance(news, list)
    
    def test_analyze_news_sentiment(self):
        """测试分析新闻情感"""
        # 创建模拟新闻
        mock_news = [
            {
                "title": "Bitcoin surges to new all-time high",
                "body": "The price of Bitcoin has reached a new all-time high today, with investors bullish on the future."
            },
            {
                "title": "Ethereum upgrade successful",
                "body": "The Ethereum network has successfully completed its latest upgrade, improving scalability."
            }
        ]
        
        # 分析情感
        sentiment = self.news_analyzer.analyze_news_sentiment(mock_news)
        
        # 检查结果
        self.assertIn("sentiment", sentiment)
        self.assertIn("score", sentiment)
        self.assertEqual(sentiment["sentiment"], "positive")  # 应该是积极的
    
    def test_get_coin_info(self):
        """测试获取币种信息"""
        info = self.coin_info_fetcher.get_coin_info("BTC_USDT")
        self.assertIsInstance(info, dict)
        self.assertEqual(info["symbol"], "BTC_USDT")
        self.assertIn("market_data", info)
        self.assertIn("links", info)
    
    def test_analyze_possible_reasons(self):
        """测试分析异动可能的原因"""
        # 创建模拟异常
        mock_anomaly = {
            "type": "price",
            "price_change_pct": 15.0
        }
        
        # 分析可能原因
        analysis = self.deep_analyzer.analyze_possible_reasons("BTC_USDT", mock_anomaly)
        
        # 检查结果
        self.assertIn("possible_reasons", analysis)
        self.assertGreater(len(analysis["possible_reasons"]), 0)
        self.assertIn("news_sentiment", analysis)
        self.assertIn("social_analysis", analysis)
        self.assertIn("coin_info", analysis)
    
    def test_format_analysis_message(self):
        """测试格式化分析结果为消息"""
        # 创建模拟分析结果
        mock_analysis = {
            "symbol": "BTC_USDT",
            "anomaly_type": "price",
            "price_direction": "上涨",
            "possible_reasons": [
                "积极新闻推动价格上涨",
                "社交媒体上的积极讨论"
            ],
            "coin_info": {
                "name": "Bitcoin",
                "market_data": {
                    "current_price_usd": 50000,
                    "market_cap_usd": 1000000000000
                },
                "social_data": {
                    "twitter_followers": 1000000
                },
                "links": {
                    "homepage": "https://bitcoin.org",
                    "twitter_screen_name": "bitcoin"
                }
            }
        }
        
        # 格式化消息
        message = self.deep_analyzer.format_analysis_message(mock_analysis)
        
        # 检查消息内容
        self.assertIn("BTC_USDT", message)
        self.assertIn("积极新闻推动价格上涨", message)
        self.assertIn("Bitcoin", message)
        self.assertIn("50000", message)


if __name__ == "__main__":
    unittest.main()
