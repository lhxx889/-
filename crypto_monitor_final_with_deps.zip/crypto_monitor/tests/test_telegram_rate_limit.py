"""
Gate.io加密货币异动监控系统 - Telegram限流处理测试
"""

import logging
import time
import sys
import os
import random
from datetime import datetime

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入增强版Telegram推送模块
from src.enhanced_telegram_alerter import EnhancedTelegramAlerter, RateLimiter, MessageBatcher

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("telegram_test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("telegram_test")

def test_rate_limiter():
    """测试速率限制器"""
    logger.info("=== 测试速率限制器 ===")
    
    # 创建速率限制器（每10秒最多5个请求）
    rate_limiter = RateLimiter(max_requests=5, time_window=10)
    
    # 测试多次请求
    for i in range(10):
        wait_time = rate_limiter.wait_if_needed()
        if wait_time > 0:
            logger.info(f"请求 {i+1}: 需要等待 {wait_time:.2f} 秒")
            time.sleep(wait_time)
        else:
            logger.info(f"请求 {i+1}: 无需等待")
        
        rate_limiter.record_request()
        time.sleep(0.5)  # 模拟请求处理时间
    
    logger.info("速率限制器测试完成")

def test_message_batcher():
    """测试消息批处理器"""
    logger.info("=== 测试消息批处理器 ===")
    
    # 创建消息批处理器（最多3条消息，最长等待5秒）
    batcher = MessageBatcher(max_batch_size=3, max_wait_time=5)
    
    # 添加消息
    for i in range(5):
        message = f"测试消息 {i+1}"
        logger.info(f"添加消息: {message}")
        batcher.add_message(message)
        
        # 检查是否有就绪的批次
        batch = batcher.get_batch_if_ready()
        if batch:
            combined = batcher.combine_messages(batch)
            logger.info(f"批次就绪，合并后的消息:\n{combined}")
        
        time.sleep(1)
    
    # 等待最后一批消息
    time.sleep(5)
    batch = batcher.get_batch_if_ready()
    if batch:
        combined = batcher.combine_messages(batch)
        logger.info(f"最后一批消息:\n{combined}")
    
    logger.info("消息批处理器测试完成")

def test_telegram_send_with_rate_limit():
    """测试带速率限制的Telegram发送"""
    logger.info("=== 测试带速率限制的Telegram发送 ===")
    
    # 创建警报器
    alerter = EnhancedTelegramAlerter()
    
    # 检查是否已配置
    if not alerter.is_configured():
        logger.error("Telegram未配置，无法进行测试")
        return
    
    # 发送多条消息
    for i in range(10):
        message = f"测试消息 {i+1} - 时间: {datetime.now().strftime('%H:%M:%S')}"
        logger.info(f"发送消息: {message}")
        
        result = alerter.send_message(message)
        if result:
            logger.info(f"消息 {i+1} 已加入队列")
        else:
            logger.warning(f"消息 {i+1} 加入队列失败")
        
        # 随机等待
        wait_time = random.uniform(0.5, 2.0)
        time.sleep(wait_time)
    
    # 等待所有消息发送完成
    logger.info("等待所有消息发送完成...")
    time.sleep(15)
    
    logger.info("带速率限制的Telegram发送测试完成")

def test_anomaly_alerts():
    """测试异常警报"""
    logger.info("=== 测试异常警报 ===")
    
    # 创建警报器
    alerter = EnhancedTelegramAlerter(dedup_window=60)  # 设置较短的去重窗口用于测试
    
    # 检查是否已配置
    if not alerter.is_configured():
        logger.error("Telegram未配置，无法进行测试")
        return
    
    # 创建测试异常数据
    test_anomalies = [
        {
            "type": "price",
            "symbol": "BTC_USDT",
            "current_price": 50000,
            "reference_price": 45000,
            "price_change_pct": 11.11,
            "volume_24h": 1000000,
            "detected_at": datetime.now().isoformat()
        },
        {
            "type": "price",
            "symbol": "ETH_USDT",
            "current_price": 3000,
            "reference_price": 2700,
            "price_change_pct": 11.11,
            "volume_24h": 500000,
            "detected_at": datetime.now().isoformat()
        },
        {
            "type": "volume",
            "symbol": "DOGE_USDT",
            "current_price": 0.1,
            "reference_price": 0.1,
            "price_change_pct": 0,
            "volume_24h": 200000,
            "detected_at": datetime.now().isoformat()
        },
        # 重复的异常，应该被去重
        {
            "type": "price",
            "symbol": "BTC_USDT",
            "current_price": 51000,
            "reference_price": 45000,
            "price_change_pct": 13.33,
            "volume_24h": 1100000,
            "detected_at": datetime.now().isoformat()
        }
    ]
    
    # 发送异常警报
    for i, anomaly in enumerate(test_anomalies):
        logger.info(f"发送异常警报 {i+1}: {anomaly['symbol']} ({anomaly['type']})")
        
        result = alerter.send_anomaly_alert(anomaly)
        if result:
            logger.info(f"异常警报 {i+1} 已加入队列")
        else:
            logger.warning(f"异常警报 {i+1} 加入队列失败或被去重")
        
        # 等待
        time.sleep(2)
    
    # 等待所有消息发送完成
    logger.info("等待所有消息发送完成...")
    time.sleep(15)
    
    logger.info("异常警报测试完成")

def main():
    """主函数"""
    logger.info("开始Telegram限流处理测试")
    
    # 测试速率限制器
    test_rate_limiter()
    
    # 测试消息批处理器
    test_message_batcher()
    
    # 测试带速率限制的Telegram发送
    test_telegram_send_with_rate_limit()
    
    # 测试异常警报
    test_anomaly_alerts()
    
    logger.info("所有测试完成")

if __name__ == "__main__":
    main()
