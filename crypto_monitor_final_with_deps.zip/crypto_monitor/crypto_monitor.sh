#!/bin/bash
# Gate.io加密货币异动监控系统 - 多功能快捷启动脚本

# 定义颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 定义路径
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOG_FILE="$SCRIPT_DIR/crypto_monitor.log"
PID_FILE="$SCRIPT_DIR/crypto_monitor.pid"
SERVICE_NAME="crypto_monitor"

# 显示帮助信息
show_help() {
    echo -e "${BLUE}Gate.io加密货币异动监控系统 - 多功能快捷启动脚本${NC}"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  start         启动监控系统"
    echo "  stop          停止监控系统"
    echo "  restart       重启监控系统"
    echo "  status        查看监控系统状态"
    echo "  setup         运行设置向导"
    echo "  config        更新API配置"
    echo "  telegram      管理Telegram账号"
    echo "  service       安装/卸载系统服务"
    echo "  logs          查看日志"
    echo "  help          显示此帮助信息"
    echo ""
}

# 检查Python环境
check_python() {
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}错误: 未找到Python3，请先安装Python3${NC}"
        exit 1
    fi
}

# 检查依赖
check_dependencies() {
    if [ ! -f "$SCRIPT_DIR/requirements.txt" ]; then
        echo -e "${RED}错误: 未找到requirements.txt文件${NC}"
        exit 1
    fi
    
    echo -e "${BLUE}检查依赖...${NC}"
    python3 -m pip install -r "$SCRIPT_DIR/requirements.txt"
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}错误: 安装依赖失败${NC}"
        exit 1
    fi
}

# 启动监控系统
start_monitor() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p "$PID" > /dev/null; then
            echo -e "${YELLOW}监控系统已经在运行中 (PID: $PID)${NC}"
            return 0
        else
            echo -e "${YELLOW}发现过期的PID文件，将删除${NC}"
            rm -f "$PID_FILE"
        fi
    fi
    
    echo -e "${BLUE}启动监控系统...${NC}"
    
    # 检查Python环境和依赖
    check_python
    check_dependencies
    
    # 启动监控系统
    cd "$SCRIPT_DIR"
    nohup python3 main.py > /dev/null 2>&1 &
    
    # 保存PID
    PID=$!
    echo $PID > "$PID_FILE"
    
    echo -e "${GREEN}监控系统已启动 (PID: $PID)${NC}"
    echo -e "${BLUE}使用 '$0 logs' 查看日志${NC}"
}

# 停止监控系统
stop_monitor() {
    if [ ! -f "$PID_FILE" ]; then
        echo -e "${YELLOW}监控系统未运行${NC}"
        return 0
    fi
    
    PID=$(cat "$PID_FILE")
    if ! ps -p "$PID" > /dev/null; then
        echo -e "${YELLOW}监控系统未运行，但发现过期的PID文件，将删除${NC}"
        rm -f "$PID_FILE"
        return 0
    fi
    
    echo -e "${BLUE}停止监控系统 (PID: $PID)...${NC}"
    
    # 尝试优雅地终止进程
    kill -15 "$PID"
    
    # 等待进程终止
    for i in {1..10}; do
        if ! ps -p "$PID" > /dev/null; then
            break
        fi
        echo -e "${BLUE}等待进程终止... ($i/10)${NC}"
        sleep 1
    done
    
    # 如果进程仍在运行，强制终止
    if ps -p "$PID" > /dev/null; then
        echo -e "${YELLOW}进程未响应，强制终止${NC}"
        kill -9 "$PID"
    fi
    
    # 删除PID文件
    rm -f "$PID_FILE"
    
    echo -e "${GREEN}监控系统已停止${NC}"
}

# 重启监控系统
restart_monitor() {
    echo -e "${BLUE}重启监控系统...${NC}"
    stop_monitor
    sleep 2
    start_monitor
}

# 查看监控系统状态
check_status() {
    if [ ! -f "$PID_FILE" ]; then
        echo -e "${YELLOW}监控系统未运行${NC}"
        return 1
    fi
    
    PID=$(cat "$PID_FILE")
    if ! ps -p "$PID" > /dev/null; then
        echo -e "${YELLOW}监控系统未运行，但发现过期的PID文件，将删除${NC}"
        rm -f "$PID_FILE"
        return 1
    fi
    
    # 获取进程运行时间
    if command -v ps &> /dev/null; then
        PROCESS_INFO=$(ps -p "$PID" -o etime=)
        echo -e "${GREEN}监控系统正在运行 (PID: $PID)${NC}"
        echo -e "${BLUE}运行时间: $PROCESS_INFO${NC}"
    else
        echo -e "${GREEN}监控系统正在运行 (PID: $PID)${NC}"
    fi
    
    # 显示最近的日志
    if [ -f "$LOG_FILE" ]; then
        echo -e "${BLUE}最近的日志:${NC}"
        tail -n 5 "$LOG_FILE"
    fi
    
    return 0
}

# 运行设置向导
run_setup() {
    echo -e "${BLUE}运行设置向导...${NC}"
    
    # 检查Python环境和依赖
    check_python
    check_dependencies
    
    # 运行设置向导
    cd "$SCRIPT_DIR"
    python3 main.py --setup
}

# 更新API配置
update_config() {
    echo -e "${BLUE}更新API配置...${NC}"
    
    # 检查Python环境和依赖
    check_python
    check_dependencies
    
    # 更新API配置
    cd "$SCRIPT_DIR"
    python3 main.py --config
}

# 管理Telegram账号
manage_telegram() {
    echo -e "${BLUE}Telegram账号管理${NC}"
    
    # 检查Python环境和依赖
    check_python
    check_dependencies
    
    # 创建Telegram管理脚本
    TELEGRAM_MANAGER="$SCRIPT_DIR/telegram_manager.py"
    
    if [ ! -f "$TELEGRAM_MANAGER" ]; then
        cat > "$TELEGRAM_MANAGER" << 'EOF'
#!/usr/bin/env python3
"""
Gate.io加密货币异动监控系统 - Telegram账号管理工具
"""

import sys
import os
import logging
import json
import argparse

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入多Telegram账号管理器
try:
    from src.multi_telegram_manager import MultiTelegramManager
    telegram_manager = MultiTelegramManager()
except ImportError:
    print("错误: 无法导入多Telegram账号管理器")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("telegram_manager")

def list_accounts():
    """列出所有账号"""
    accounts = telegram_manager.get_account_names()
    status = telegram_manager.get_account_status()
    
    if not accounts:
        print("没有配置Telegram账号")
        return
    
    print(f"共有 {len(accounts)} 个Telegram账号:")
    print("-" * 60)
    print(f"{'名称':<15} {'状态':<10} {'连续错误':<10} {'冷却时间(秒)':<15}")
    print("-" * 60)
    
    for name in accounts:
        account_status = status.get(name, {})
        is_active = account_status.get("is_active", False)
        consecutive_errors = account_status.get("consecutive_errors", 0)
        cooldown_time = account_status.get("cooldown_time", 0)
        
        status_str = "活跃" if is_active else "禁用"
        print(f"{name:<15} {status_str:<10} {consecutive_errors:<10} {cooldown_time:<15.2f}")
    
    print("-" * 60)

def add_account():
    """添加账号"""
    print("添加新的Telegram账号")
    print("-" * 40)
    
    name = input("账号名称: ")
    if not name:
        print("错误: 账号名称不能为空")
        return
    
    # 检查账号是否已存在
    if name in telegram_manager.get_account_names():
        overwrite = input(f"账号 '{name}' 已存在，是否覆盖? (y/n): ")
        if overwrite.lower() != 'y':
            print("操作已取消")
            return
    
    token = input("Telegram Bot Token: ")
    if not token:
        print("错误: Token不能为空")
        return
    
    chat_id = input("Telegram Chat ID: ")
    if not chat_id:
        print("错误: Chat ID不能为空")
        return
    
    # 添加账号
    success = telegram_manager.add_account(name, token, chat_id)
    
    if success:
        print(f"账号 '{name}' 添加成功")
        
        # 测试连接
        test = input("是否测试连接? (y/n): ")
        if test.lower() == 'y':
            print(f"测试账号 '{name}' 连接...")
            success = telegram_manager.test_account(name)
            if success:
                print(f"账号 '{name}' 连接测试成功")
            else:
                print(f"账号 '{name}' 连接测试失败")
    else:
        print(f"账号 '{name}' 添加失败")

def remove_account():
    """删除账号"""
    accounts = telegram_manager.get_account_names()
    
    if not accounts:
        print("没有配置Telegram账号")
        return
    
    print("选择要删除的账号:")
    for i, name in enumerate(accounts, 1):
        print(f"{i}. {name}")
    
    choice = input("请输入账号编号 (或输入 'q' 取消): ")
    if choice.lower() == 'q':
        print("操作已取消")
        return
    
    try:
        index = int(choice) - 1
        if 0 <= index < len(accounts):
            name = accounts[index]
            confirm = input(f"确认删除账号 '{name}'? (y/n): ")
            if confirm.lower() == 'y':
                success = telegram_manager.remove_account(name)
                if success:
                    print(f"账号 '{name}' 删除成功")
                else:
                    print(f"账号 '{name}' 删除失败")
            else:
                print("操作已取消")
        else:
            print("错误: 无效的账号编号")
    except ValueError:
        print("错误: 请输入有效的数字")

def test_accounts():
    """测试账号连接"""
    accounts = telegram_manager.get_account_names()
    
    if not accounts:
        print("没有配置Telegram账号")
        return
    
    print("测试所有Telegram账号连接...")
    results = telegram_manager.test_all_accounts()
    
    print("-" * 40)
    print(f"{'账号名称':<15} {'测试结果':<10}")
    print("-" * 40)
    
    for name, success in results.items():
        result_str = "成功" if success else "失败"
        print(f"{name:<15} {result_str:<10}")
    
    print("-" * 40)

def send_test_message():
    """发送测试消息"""
    accounts = telegram_manager.get_account_names()
    
    if not accounts:
        print("没有配置Telegram账号")
        return
    
    print("选择要使用的账号:")
    print("0. 自动选择最佳账号")
    for i, name in enumerate(accounts, 1):
        print(f"{i}. {name}")
    
    choice = input("请输入账号编号 (或输入 'q' 取消): ")
    if choice.lower() == 'q':
        print("操作已取消")
        return
    
    try:
        specific_account = None
        if choice != '0':
            index = int(choice) - 1
            if 0 <= index < len(accounts):
                specific_account = accounts[index]
            else:
                print("错误: 无效的账号编号")
                return
        
        message = input("请输入测试消息 (默认: 'Gate.io加密货币异动监控系统测试消息'): ")
        if not message:
            message = "Gate.io加密货币异动监控系统测试消息"
        
        print("发送测试消息...")
        success, used_account = telegram_manager.send_message(message, specific_account=specific_account)
        
        if success:
            print(f"测试消息发送成功，使用账号: {used_account}")
        else:
            print("测试消息发送失败")
    except ValueError:
        print("错误: 请输入有效的数字")

def show_menu():
    """显示菜单"""
    print("\nTelegram账号管理")
    print("=" * 40)
    print("1. 列出所有账号")
    print("2. 添加账号")
    print("3. 删除账号")
    print("4. 测试账号连接")
    print("5. 发送测试消息")
    print("0. 退出")
    print("=" * 40)
    
    choice = input("请选择操作: ")
    return choice

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Telegram账号管理工具")
    parser.add_argument("--list", action="store_true", help="列出所有账号")
    parser.add_argument("--add", action="store_true", help="添加账号")
    parser.add_argument("--remove", action="store_true", help="删除账号")
    parser.add_argument("--test", action="store_true", help="测试账号连接")
    parser.add_argument("--send", action="store_true", help="发送测试消息")
    
    args = parser.parse_args()
    
    # 如果指定了命令行参数，执行相应操作
    if args.list:
        list_accounts()
        return
    elif args.add:
        add_account()
        return
    elif args.remove:
        remove_account()
        return
    elif args.test:
        test_accounts()
        return
    elif args.send:
        send_test_message()
        return
    
    # 如果没有指定命令行参数，显示交互式菜单
    while True:
        choice = show_menu()
        
        if choice == '1':
            list_accounts()
        elif choice == '2':
            add_account()
        elif choice == '3':
            remove_account()
        elif choice == '4':
            test_accounts()
        elif choice == '5':
            send_test_message()
        elif choice == '0':
            print("退出Telegram账号管理")
            break
        else:
            print("错误: 无效的选择")

if __name__ == "__main__":
    main()
EOF
        chmod +x "$TELEGRAM_MANAGER"
    fi
    
    # 运行Telegram管理脚本
    cd "$SCRIPT_DIR"
    python3 "$TELEGRAM_MANAGER"
}

# 安装/卸载系统服务
manage_service() {
    if [ "$EUID" -ne 0 ]; then
        echo -e "${RED}错误: 需要root权限来管理系统服务${NC}"
        echo -e "${BLUE}请使用sudo运行: sudo $0 service${NC}"
        return 1
    fi
    
    echo -e "${BLUE}系统服务管理${NC}"
    echo "1. 安装系统服务"
    echo "2. 卸载系统服务"
    echo "3. 启动系统服务"
    echo "4. 停止系统服务"
    echo "5. 重启系统服务"
    echo "6. 查看系统服务状态"
    echo "0. 返回"
    
    read -p "请选择操作: " choice
    
    case $choice in
        1)
            install_service
            ;;
        2)
            uninstall_service
            ;;
        3)
            systemctl start $SERVICE_NAME
            echo -e "${GREEN}服务已启动${NC}"
            ;;
        4)
            systemctl stop $SERVICE_NAME
            echo -e "${GREEN}服务已停止${NC}"
            ;;
        5)
            systemctl restart $SERVICE_NAME
            echo -e "${GREEN}服务已重启${NC}"
            ;;
        6)
            systemctl status $SERVICE_NAME
            ;;
        0)
            return 0
            ;;
        *)
            echo -e "${RED}错误: 无效的选择${NC}"
            ;;
    esac
}

# 安装系统服务
install_service() {
    # 创建服务文件
    cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=Gate.io Crypto Monitor Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$SCRIPT_DIR
ExecStart=/usr/bin/python3 $SCRIPT_DIR/main.py
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
    
    # 重新加载systemd配置
    systemctl daemon-reload
    
    # 启用服务
    systemctl enable $SERVICE_NAME
    
    echo -e "${GREEN}系统服务已安装并启用${NC}"
    echo -e "${BLUE}使用以下命令管理服务:${NC}"
    echo "  sudo systemctl start $SERVICE_NAME"
    echo "  sudo systemctl stop $SERVICE_NAME"
    echo "  sudo systemctl restart $SERVICE_NAME"
    echo "  sudo systemctl status $SERVICE_NAME"
}

# 卸载系统服务
uninstall_service() {
    # 停止服务
    systemctl stop $SERVICE_NAME
    
    # 禁用服务
    systemctl disable $SERVICE_NAME
    
    # 删除服务文件
    rm -f /etc/systemd/system/$SERVICE_NAME.service
    
    # 重新加载systemd配置
    systemctl daemon-reload
    
    echo -e "${GREEN}系统服务已卸载${NC}"
}

# 查看日志
view_logs() {
    if [ ! -f "$LOG_FILE" ]; then
        echo -e "${YELLOW}日志文件不存在${NC}"
        return 1
    fi
    
    echo -e "${BLUE}日志查看选项:${NC}"
    echo "1. 查看最新的10行日志"
    echo "2. 查看最新的50行日志"
    echo "3. 查看全部日志"
    echo "4. 实时查看日志"
    echo "0. 返回"
    
    read -p "请选择操作: " choice
    
    case $choice in
        1)
            tail -n 10 "$LOG_FILE"
            ;;
        2)
            tail -n 50 "$LOG_FILE"
            ;;
        3)
            less "$LOG_FILE"
            ;;
        4)
            tail -f "$LOG_FILE"
            ;;
        0)
            return 0
            ;;
        *)
            echo -e "${RED}错误: 无效的选择${NC}"
            ;;
    esac
}

# 主函数
main() {
    # 如果没有参数，显示帮助信息
    if [ $# -eq 0 ]; then
        show_help
        exit 0
    fi
    
    # 处理参数
    case "$1" in
        start)
            start_monitor
            ;;
        stop)
            stop_monitor
            ;;
        restart)
            restart_monitor
            ;;
        status)
            check_status
            ;;
        setup)
            run_setup
            ;;
        config)
            update_config
            ;;
        telegram)
            manage_telegram
            ;;
        service)
            manage_service
            ;;
        logs)
            view_logs
            ;;
        help)
            show_help
            ;;
        *)
            echo -e "${RED}错误: 未知的选项 '$1'${NC}"
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"
