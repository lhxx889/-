#!/bin/bash

# Gate.io加密货币异动监控系统一键安装脚本

echo "====================================================="
echo "  Gate.io加密货币异动监控系统一键安装脚本"
echo "====================================================="
echo ""

# 检查Python版本
echo "检查Python环境..."
if command -v python3 &>/dev/null; then
    PYTHON_CMD=python3
elif command -v python &>/dev/null; then
    PYTHON_CMD=python
else
    echo "错误: 未找到Python。请先安装Python 3.8或更高版本。"
    exit 1
fi

# 检查Python版本是否>=3.8
PYTHON_VERSION=$($PYTHON_CMD -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]); then
    echo "错误: Python版本必须是3.8或更高版本。当前版本: $PYTHON_VERSION"
    exit 1
fi

echo "Python版本检查通过: $PYTHON_VERSION"
echo ""

# 检查系统依赖
echo "检查系统依赖..."
if command -v apt-get &>/dev/null; then
    echo "检测到Debian/Ubuntu系统，安装系统依赖..."
    sudo apt-get update
    sudo apt-get install -y python3-dev python3-pip python3-venv build-essential libssl-dev libffi-dev
elif command -v yum &>/dev/null; then
    echo "检测到CentOS/RHEL系统，安装系统依赖..."
    sudo yum install -y python3-devel python3-pip gcc openssl-devel libffi-devel
elif command -v brew &>/dev/null; then
    echo "检测到macOS系统，安装系统依赖..."
    brew install openssl
else
    echo "警告: 无法确定系统类型，跳过系统依赖安装。如果后续安装失败，请手动安装所需依赖。"
fi

# 创建虚拟环境
echo "创建Python虚拟环境..."
$PYTHON_CMD -m venv venv
if [ $? -ne 0 ]; then
    echo "错误: 创建虚拟环境失败。请确保已安装venv模块。"
    echo "尝试安装venv模块..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y python3-venv
    elif command -v yum &>/dev/null; then
        sudo yum install -y python3-venv
    fi
    # 重试创建虚拟环境
    $PYTHON_CMD -m venv venv
    if [ $? -ne 0 ]; then
        echo "错误: 创建虚拟环境仍然失败。请手动安装venv模块。"
        exit 1
    fi
fi

# 激活虚拟环境
echo "激活虚拟环境..."
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
else
    echo "错误: 无法找到虚拟环境激活脚本。"
    exit 1
fi

# 升级pip
echo "升级pip..."
pip install --upgrade pip

# 安装依赖
echo "安装依赖库..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "错误: 安装依赖库失败。尝试单独安装每个依赖..."
    
    # 读取requirements.txt并逐行安装
    while IFS= read -r line || [[ -n "$line" ]]; do
        # 跳过空行和注释
        if [[ -z "$line" || "$line" =~ ^# ]]; then
            continue
        fi
        
        echo "安装: $line"
        pip install "$line"
        if [ $? -ne 0 ]; then
            echo "警告: 安装 $line 失败，继续安装其他依赖..."
        fi
    done < requirements.txt
fi

# 创建必要的目录
echo "创建必要的目录..."
mkdir -p charts
mkdir -p logs

echo "依赖库安装完成。"
echo ""

# 运行设置向导
echo "现在将运行设置向导，请按照提示配置系统..."
echo ""
python main.py --setup

# 创建启动脚本
echo "创建启动脚本..."
cat > start_monitor.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
else
    echo "错误: 无法找到虚拟环境激活脚本。"
    exit 1
fi

# 启动监控系统
python main.py
EOF

chmod +x start_monitor.sh

# 创建服务文件（如果是Linux系统）
if [ "$(uname)" == "Linux" ]; then
    echo "检测到Linux系统，创建systemd服务文件..."
    
    # 获取当前目录的绝对路径
    INSTALL_DIR=$(pwd)
    
    # 创建服务文件
    cat > crypto_monitor.service << EOF
[Unit]
Description=Gate.io Crypto Monitor Service
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/main.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    echo "服务文件已创建: $INSTALL_DIR/crypto_monitor.service"
    echo "要安装为系统服务，请运行:"
    echo "sudo cp $INSTALL_DIR/crypto_monitor.service /etc/systemd/system/"
    echo "sudo systemctl daemon-reload"
    echo "sudo systemctl enable crypto_monitor.service"
    echo "sudo systemctl start crypto_monitor.service"
    echo ""
fi

# 创建快捷启动脚本
echo "创建快捷启动脚本..."
cat > crypto_monitor.sh << 'EOF'
#!/bin/bash
# Gate.io加密货币异动监控系统快捷启动脚本

# 获取脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# 激活虚拟环境
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
else
    echo "错误: 无法找到虚拟环境激活脚本。"
    exit 1
fi

# 命令行参数处理
case "$1" in
    start)
        echo "启动监控系统..."
        nohup python main.py > crypto_monitor.log 2>&1 &
        echo $! > crypto_monitor.pid
        echo "监控系统已在后台启动，PID: $(cat crypto_monitor.pid)"
        ;;
    stop)
        if [ -f crypto_monitor.pid ]; then
            PID=$(cat crypto_monitor.pid)
            echo "停止监控系统 (PID: $PID)..."
            kill $PID
            rm crypto_monitor.pid
            echo "监控系统已停止"
        else
            echo "监控系统未运行"
        fi
        ;;
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
    status)
        if [ -f crypto_monitor.pid ]; then
            PID=$(cat crypto_monitor.pid)
            if ps -p $PID > /dev/null; then
                echo "监控系统正在运行，PID: $PID"
            else
                echo "监控系统已崩溃，PID文件存在但进程不存在"
                rm crypto_monitor.pid
            fi
        else
            echo "监控系统未运行"
        fi
        ;;
    logs)
        if [ -f crypto_monitor.log ]; then
            tail -n 50 crypto_monitor.log
        else
            echo "日志文件不存在"
        fi
        ;;
    setup)
        echo "运行设置向导..."
        python main.py --setup
        ;;
    telegram)
        echo "Telegram账号管理..."
        echo "1. 添加账号"
        echo "2. 测试账号连接"
        echo "3. 发送测试消息"
        echo "4. 查看账号列表"
        echo "0. 返回"
        read -p "请选择: " choice
        case $choice in
            1)
                python -c "from src.multi_telegram_manager import telegram_manager; name=input('账号名称: '); token=input('Bot Token: '); chat_id=input('Chat ID: '); telegram_manager.add_account(name, token, chat_id); print('账号已添加')"
                ;;
            2)
                python -c "from src.multi_telegram_manager import telegram_manager; name=input('账号名称 (留空测试所有账号): '); result = telegram_manager.test_account(name) if name else telegram_manager.test_all_accounts(); print('测试完成')"
                ;;
            3)
                python -c "from src.enhanced_multi_telegram_alerter import telegram_alerter; message=input('消息内容: '); telegram_alerter.send_message(message); print('消息已发送')"
                ;;
            4)
                python -c "from src.multi_telegram_manager import telegram_manager; accounts = telegram_manager.get_accounts(); print(f'共有 {len(accounts)} 个账号:'); [print(f'{i+1}. {name}') for i, name in enumerate(accounts.keys())]"
                ;;
            *)
                echo "返回主菜单"
                ;;
        esac
        ;;
    config)
        echo "更新配置..."
        python main.py --config
        ;;
    test)
        echo "测试Telegram连接..."
        python main.py --test
        ;;
    service)
        if [ "$(uname)" == "Linux" ]; then
            echo "系统服务管理..."
            echo "1. 安装系统服务"
            echo "2. 启动系统服务"
            echo "3. 停止系统服务"
            echo "4. 重启系统服务"
            echo "5. 查看服务状态"
            echo "0. 返回"
            read -p "请选择: " choice
            case $choice in
                1)
                    echo "安装系统服务..."
                    sudo cp crypto_monitor.service /etc/systemd/system/
                    sudo systemctl daemon-reload
                    sudo systemctl enable crypto_monitor.service
                    echo "系统服务已安装并设置为开机启动"
                    ;;
                2)
                    echo "启动系统服务..."
                    sudo systemctl start crypto_monitor.service
                    ;;
                3)
                    echo "停止系统服务..."
                    sudo systemctl stop crypto_monitor.service
                    ;;
                4)
                    echo "重启系统服务..."
                    sudo systemctl restart crypto_monitor.service
                    ;;
                5)
                    echo "查看服务状态..."
                    sudo systemctl status crypto_monitor.service
                    ;;
                *)
                    echo "返回主菜单"
                    ;;
            esac
        else
            echo "当前系统不支持systemd服务"
        fi
        ;;
    *)
        echo "Gate.io加密货币异动监控系统快捷启动脚本"
        echo "用法: $0 {start|stop|restart|status|logs|setup|telegram|config|test|service}"
        echo ""
        echo "  start    - 启动监控系统"
        echo "  stop     - 停止监控系统"
        echo "  restart  - 重启监控系统"
        echo "  status   - 查看监控系统状态"
        echo "  logs     - 查看最近的日志"
        echo "  setup    - 运行设置向导"
        echo "  telegram - 管理Telegram账号"
        echo "  config   - 更新配置"
        echo "  test     - 测试Telegram连接"
        echo "  service  - 管理系统服务"
        ;;
esac
EOF

chmod +x crypto_monitor.sh

echo "====================================================="
echo "  安装完成！"
echo "====================================================="
echo ""
echo "要启动监控系统，请运行:"
echo "./crypto_monitor.sh start"
echo ""
echo "查看更多命令选项:"
echo "./crypto_monitor.sh"
echo ""
echo "如需帮助，请参阅README.md文件。"
echo ""
