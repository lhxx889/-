# 加密货币交易所监控方案（基础版）

## 需求概述

根据您的需求，我们设计一个专注于监控功能的脚本，主要功能包括：

1. 监控币安和Gate交易所的加密货币价格变动（涨幅/跌幅过大）
2. 监控币安最新公告和新上币公告（每小时一次）
3. 将监控到的信息推送到Telegram

## 整体架构设计

监控系统分为以下几个核心模块：

### 1. 数据采集模块
- 币安API接口调用
- Gate API接口调用
- 公告爬取模块

### 2. 数据处理模块
- 价格变动计算
- 异常检测（涨跌幅阈值判断）
- 公告解析与过滤

### 3. 通知推送模块
- Telegram Bot集成
- 消息格式化
- 推送控制

### 4. 配置管理模块
- 监控参数配置
- API密钥管理
- 阈值设置

### 5. 运行控制模块
- 定时任务替代方案
- 错误处理与日志
- 状态监控

## 技术选型

### 编程语言与框架
- **Python**: 适合数据处理和API调用，有丰富的加密货币交易所库
- **主要库**:
  - `python-binance`: 币安官方API客户端
  - `ccxt`: 统一的加密货币交易所API库，支持多个交易所
  - `python-telegram-bot`: Telegram Bot API的Python封装
  - `requests`: HTTP请求库，用于爬取公告
  - `pandas`: 数据处理和分析
  - `schedule`: 简单的定时任务调度（本地运行时使用）

## 模块详细设计

### 1. 价格监控模块

#### 核心功能
- 从币安和Gate获取价格数据
- 计算不同时间周期的涨跌幅
- 检测异常价格变动
- 生成价格预警消息

#### 实现方案
```python
# 价格监控模块伪代码
class PriceMonitor:
    def __init__(self, config):
        self.config = config
        self.binance_client = setup_binance_client(config)
        self.gate_client = setup_gate_client(config)
        self.symbols = config.get("symbols", [])
        self.thresholds = config.get("thresholds", {})
        
    def fetch_prices(self):
        """获取所有监控币种的价格"""
        binance_prices = self._fetch_binance_prices()
        gate_prices = self._fetch_gate_prices()
        return {"binance": binance_prices, "gate": gate_prices}
        
    def _fetch_binance_prices(self):
        """获取币安价格数据"""
        prices = {}
        for symbol in self.symbols:
            try:
                ticker = self.binance_client.get_ticker(symbol=symbol)
                prices[symbol] = {
                    "price": float(ticker["lastPrice"]),
                    "change_24h": float(ticker["priceChangePercent"])
                }
            except Exception as e:
                logger.error(f"获取币安{symbol}价格失败: {e}")
        return prices
        
    def _fetch_gate_prices(self):
        """获取Gate价格数据"""
        prices = {}
        for symbol in self.symbols:
            try:
                # 转换为Gate支持的格式
                gate_symbol = symbol.replace("/", "_")
                ticker = self.gate_client.get_ticker(gate_symbol)
                prices[symbol] = {
                    "price": float(ticker["last"]),
                    "change_24h": float(ticker["change_percentage"]) * 100
                }
            except Exception as e:
                logger.error(f"获取Gate{symbol}价格失败: {e}")
        return prices
        
    def check_price_alerts(self, prices):
        """检查价格预警"""
        alerts = []
        for exchange, exchange_prices in prices.items():
            for symbol, data in exchange_prices.items():
                # 检查24小时涨跌幅
                if abs(data["change_24h"]) > self.thresholds.get("change_24h", 10):
                    alerts.append({
                        "exchange": exchange,
                        "symbol": symbol,
                        "price": data["price"],
                        "change": data["change_24h"],
                        "type": "24h_change"
                    })
                    
                # 可以添加其他时间周期的检查
                
        return alerts
```

#### 价格监控配置示例
```python
price_monitor_config = {
    "symbols": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT"],
    "thresholds": {
        "change_5m": 3.0,   # 5分钟涨跌幅阈值
        "change_15m": 5.0,  # 15分钟涨跌幅阈值
        "change_1h": 7.0,   # 1小时涨跌幅阈值
        "change_24h": 15.0  # 24小时涨跌幅阈值
    },
    "check_interval": 60    # 检查间隔（秒）
}
```

### 2. 公告监控模块

#### 核心功能
- 获取币安最新公告
- 过滤新上币公告
- 与历史记录比较，找出新公告
- 生成公告通知消息

#### 实现方案
```python
# 公告监控模块伪代码
class AnnouncementMonitor:
    def __init__(self, config):
        self.config = config
        self.binance_client = setup_binance_client(config)
        self.history_file = config.get("history_file", "announcement_history.json")
        self.load_history()
        
    def load_history(self):
        """加载历史公告记录"""
        try:
            with open(self.history_file, "r") as f:
                self.history = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.history = {"announcements": [], "new_listings": []}
            
    def save_history(self):
        """保存历史公告记录"""
        with open(self.history_file, "w") as f:
            json.dump(self.history, f)
            
    def fetch_announcements(self):
        """获取币安最新公告"""
        try:
            # 使用币安API获取公告
            announcements = self.binance_client.get_announcements()
            return announcements
        except Exception as e:
            logger.error(f"获取币安公告失败: {e}")
            # 备选方案：爬取币安公告页面
            return self._scrape_announcements()
            
    def _scrape_announcements(self):
        """爬取币安公告页面（备选方案）"""
        announcements = []
        try:
            response = requests.get("https://www.binance.com/en/support/announcement/c-48")
            if response.status_code == 200:
                # 解析HTML获取公告信息
                # 这里需要根据实际页面结构进行解析
                pass
        except Exception as e:
            logger.error(f"爬取币安公告失败: {e}")
        return announcements
        
    def filter_new_listings(self, announcements):
        """过滤新上币公告"""
        new_listings = []
        for announcement in announcements:
            title = announcement.get("title", "").lower()
            if any(keyword in title for keyword in ["listing", "新币上线", "will list"]):
                new_listings.append(announcement)
        return new_listings
        
    def find_new_announcements(self, announcements):
        """找出新公告"""
        new_announcements = []
        existing_ids = [a["id"] for a in self.history["announcements"]]
        
        for announcement in announcements:
            if announcement["id"] not in existing_ids:
                new_announcements.append(announcement)
                self.history["announcements"].append({
                    "id": announcement["id"],
                    "title": announcement["title"],
                    "date": announcement["date"]
                })
                
        return new_announcements
        
    def find_new_listings(self, listings):
        """找出新上币公告"""
        new_listings = []
        existing_ids = [a["id"] for a in self.history["new_listings"]]
        
        for listing in listings:
            if listing["id"] not in existing_ids:
                new_listings.append(listing)
                self.history["new_listings"].append({
                    "id": listing["id"],
                    "title": listing["title"],
                    "date": listing["date"]
                })
                
        return new_listings
        
    def check_announcements(self):
        """检查新公告"""
        announcements = self.fetch_announcements()
        listings = self.filter_new_listings(announcements)
        
        new_announcements = self.find_new_announcements(announcements)
        new_listings = self.find_new_listings(listings)
        
        self.save_history()
        
        return {
            "new_announcements": new_announcements,
            "new_listings": new_listings
        }
```

#### 公告监控配置示例
```python
announcement_config = {
    "history_file": "data/announcement_history.json",
    "check_interval": 3600,  # 每小时检查一次
    "keywords": {
        "listing": ["listing", "新币上线", "will list"],
        "important": ["update", "upgrade", "maintenance", "维护", "更新"]
    }
}
```

### 3. Telegram推送模块

#### 核心功能
- 设置Telegram Bot
- 格式化不同类型的消息
- 发送消息到指定频道或群组
- 控制消息推送频率

#### 实现方案
```python
# Telegram推送模块伪代码
class TelegramNotifier:
    def __init__(self, config):
        self.config = config
        self.token = config["token"]
        self.chat_id = config["chat_id"]
        self.bot = telegram.Bot(token=self.token)
        self.last_notification_time = {}
        
    def send_message(self, message, parse_mode="Markdown"):
        """发送消息到Telegram"""
        try:
            self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode=parse_mode
            )
            return True
        except Exception as e:
            logger.error(f"发送Telegram消息失败: {e}")
            return False
            
    def format_price_alert(self, alert):
        """格式化价格预警消息"""
        exchange = alert["exchange"].capitalize()
        symbol = alert["symbol"]
        price = alert["price"]
        change = alert["change"]
        
        if change > 0:
            direction = "上涨"
            emoji = "🚀"
        else:
            direction = "下跌"
            emoji = "📉"
            
        message = f"{emoji} *价格预警* {emoji}\n\n"
        message += f"交易所: `{exchange}`\n"
        message += f"币种: `{symbol}`\n"
        message += f"{direction}: `{abs(change)}%`\n"
        message += f"当前价格: `{price}`"
        
        return message
        
    def format_announcement(self, announcement):
        """格式化公告消息"""
        title = announcement["title"]
        url = announcement.get("url", "")
        date = announcement.get("date", "")
        
        message = f"📢 *币安最新公告* 📢\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def format_new_listing(self, listing):
        """格式化新上币公告消息"""
        title = listing["title"]
        url = listing.get("url", "")
        date = listing.get("date", "")
        
        message = f"🔥 *币安新币上线* 🔥\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def notify_price_alert(self, alert):
        """发送价格预警通知"""
        # 检查是否需要限流
        symbol = alert["symbol"]
        alert_type = alert["type"]
        key = f"{symbol}_{alert_type}"
        
        current_time = time.time()
        if key in self.last_notification_time:
            time_diff = current_time - self.last_notification_time[key]
            min_interval = self.config.get("min_alert_interval", 300)  # 默认5分钟
            
            if time_diff < min_interval:
                logger.info(f"跳过{symbol}的{alert_type}预警，距离上次通知仅{time_diff}秒")
                return False
                
        message = self.format_price_alert(alert)
        result = self.send_message(message)
        
        if result:
            self.last_notification_time[key] = current_time
            
        return result
        
    def notify_announcement(self, announcement):
        """发送公告通知"""
        message = self.format_announcement(announcement)
        return self.send_message(message)
        
    def notify_new_listing(self, listing):
        """发送新上币通知"""
        message = self.format_new_listing(listing)
        return self.send_message(message)
```

#### Telegram推送配置示例
```python
telegram_config = {
    "token": "YOUR_TELEGRAM_BOT_TOKEN",
    "chat_id": "YOUR_CHAT_ID",
    "min_alert_interval": 300,  # 同一币种同类型预警的最小间隔（秒）
    "max_daily_alerts": 20      # 每日最大预警次数
}
```

### 4. 主程序与运行控制

#### 核心功能
- 初始化各模块
- 实现定时检查逻辑
- 处理错误和异常情况
- 提供日志记录

#### 实现方案
```python
# 主程序伪代码
class CryptoMonitor:
    def __init__(self, config_file):
        self.config = self._load_config(config_file)
        self.price_monitor = PriceMonitor(self.config["price_monitor"])
        self.announcement_monitor = AnnouncementMonitor(self.config["announcement_monitor"])
        self.telegram_notifier = TelegramNotifier(self.config["telegram"])
        self.running = False
        
    def _load_config(self, config_file):
        """加载配置文件"""
        with open(config_file, "r") as f:
            return json.load(f)
            
    def check_prices(self):
        """检查价格并发送预警"""
        try:
            prices = self.price_monitor.fetch_prices()
            alerts = self.price_monitor.check_price_alerts(prices)
            
            for alert in alerts:
                self.telegram_notifier.notify_price_alert(alert)
                
            return len(alerts)
        except Exception as e:
            logger.error(f"价格检查失败: {e}")
            return 0
            
    def check_announcements(self):
        """检查公告并发送通知"""
        try:
            results = self.announcement_monitor.check_announcements()
            
            for announcement in results["new_announcements"]:
                self.telegram_notifier.notify_announcement(announcement)
                
            for listing in results["new_listings"]:
                self.telegram_notifier.notify_new_listing(listing)
                
            return len(results["new_announcements"]) + len(results["new_listings"])
        except Exception as e:
            logger.error(f"公告检查失败: {e}")
            return 0
            
    def run_once(self):
        """执行一次完整检查"""
        price_alerts = self.check_prices()
        
        # 检查是否到达整点
        current_minute = datetime.now().minute
        if current_minute < 5:  # 每小时开始的5分钟内检查公告
            announcement_alerts = self.check_announcements()
        else:
            announcement_alerts = 0
            
        return price_alerts + announcement_alerts
        
    def run_continuous(self):
        """持续运行监控"""
        self.running = True
        self.telegram_notifier.send_message("🤖 加密货币监控已启动")
        
        try:
            while self.running:
                self.run_once()
                
                # 等待下一次检查
                time.sleep(self.config.get("check_interval", 60))
        except KeyboardInterrupt:
            self.running = False
            self.telegram_notifier.send_message("🛑 加密货币监控已停止")
            
    def stop(self):
        """停止监控"""
        self.running = False
```

#### 主程序配置示例
```python
{
    "price_monitor": {
        "symbols": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT"],
        "thresholds": {
            "change_5m": 3.0,
            "change_15m": 5.0,
            "change_1h": 7.0,
            "change_24h": 15.0
        }
    },
    "announcement_monitor": {
        "history_file": "data/announcement_history.json",
        "check_interval": 3600
    },
    "telegram": {
        "token": "YOUR_TELEGRAM_BOT_TOKEN",
        "chat_id": "YOUR_CHAT_ID",
        "min_alert_interval": 300
    },
    "check_interval": 60,
    "log_file": "logs/crypto_monitor.log"
}
```

## 定时任务替代方案

由于系统不支持定时任务，以下是几种替代方案：

### 方案A: 云服务器部署
- 在自己的云服务器上部署脚本
- 使用Linux的crontab设置定时任务
- 优点: 完全自主控制，稳定可靠
- 缺点: 需要自行维护服务器

```bash
# crontab示例
# 每5分钟检查价格
*/5 * * * * python /path/to/price_monitor.py

# 每小时检查公告
0 * * * * python /path/to/announcement_monitor.py
```

### 方案B: 云函数/无服务器部署
- 使用AWS Lambda、Google Cloud Functions等云函数服务
- 设置触发器定时执行
- 优点: 无需维护服务器，按使用付费
- 缺点: 有执行时间限制，配置相对复杂

### 方案C: 持续运行的轻量级服务
- 使用循环+sleep实现定时检查
- 部署在低成本VPS上
- 优点: 实现简单，灵活控制
- 缺点: 需要确保进程持续运行

```python
# 持续运行示例
def main():
    monitor = CryptoMonitor("config.json")
    monitor.run_continuous()

if __name__ == "__main__":
    main()
```

## 安全性与可靠性建议

### API密钥管理
- 使用只读API密钥，不需要交易权限
- 使用环境变量或配置文件存储密钥，避免硬编码
- 定期轮换API密钥

### 错误处理
- 实现完善的异常处理机制
- 添加重试机制，应对网络波动
- 设置监控失败通知，确保系统正常运行

### 数据存储
- 使用数据库或文件存储历史数据
- 定期备份配置和历史记录
- 实现数据清理机制，避免数据过度累积

## 扩展性建议

### 支持更多交易所
- 使用ccxt库可轻松扩展支持其他交易所
- 设计模块化结构，便于添加新交易所

### 更多监控指标
- 交易量异常监控
- 买卖盘深度变化监控
- 资金流向监控
- 社交媒体情绪分析

## 实施路线图

### 第一阶段: 基础功能
1. 实现币安和Gate价格监控
2. 实现币安公告监控
3. 实现Telegram基础推送

### 第二阶段: 功能完善
1. 优化监控算法，减少误报
2. 完善公告过滤机制
3. 增强Telegram交互功能

### 第三阶段: 扩展功能
1. 添加更多交易所支持
2. 实现更多监控指标
3. 添加数据可视化功能

## 总结

本方案提供了一个完整的加密货币交易所监控系统设计，专注于价格监控、公告监控和Telegram推送功能。通过模块化设计，系统具有良好的可扩展性和可维护性。

由于系统不支持定时任务，建议采用云服务器部署或云函数方案实现定时监控。根据您的具体需求和技术环境，可以选择最适合的部署方式。

如需进一步定制或有任何疑问，请随时告知。
