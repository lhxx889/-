# telegram_commands.py

import logging
import os
import time
from datetime import datetime

# Placeholder for plotting library (matplotlib)
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
    logging.warning("Matplotlib not found. Chart generation will be disabled.")

logger = logging.getLogger(__name__)

class TelegramCommandHandler:
    def __init__(self, config, price_monitor, announcement_monitor, coin_enricher):
        """Initialize the command handler.

        Args:
            config (dict): Configuration for commands.
            price_monitor: Instance of the PriceMonitor class.
            announcement_monitor: Instance of the AnnouncementMonitor class.
            coin_enricher: Instance of the CoinDetailEnricher class.
        """
        self.config = config
        self.price_monitor = price_monitor
        self.announcement_monitor = announcement_monitor
        self.coin_enricher = coin_enricher
        self.user_settings = {}  # Store user-specific settings (e.g., paused status, thresholds)
        self.command_handlers = self._setup_command_handlers()
        self.command_shortcuts = self._setup_command_shortcuts()
        self._load_user_settings() # Load settings if persisted

    def _setup_command_handlers(self):
        """Set up the mapping between command strings and handler methods."""
        return {
            "start": self.handle_start,
            "help": self.handle_help,
            "status": self.handle_status,
            "price": self.handle_price,
            "chart": self.handle_chart,
            "top": self.handle_top,
            "bottom": self.handle_bottom,
            "watch": self.handle_watch,
            "unwatch": self.handle_unwatch,
            "watchlist": self.handle_watchlist,
            "threshold": self.handle_threshold,
            "pause": self.handle_pause,
            "resume": self.handle_resume,
            "info": self.handle_info,
            "news": self.handle_news,
            "social": self.handle_social,
            "contract": self.handle_contract,
            "announcements": self.handle_announcements,
            "listings": self.handle_listings,
            "exchange": self.handle_exchange,
            "alert": self.handle_alert,
            "compare": self.handle_compare,
            "volume": self.handle_volume,
            "settings": self.handle_settings
        }

    def _setup_command_shortcuts(self):
        """Set up command shortcuts."""
        return {
            "p": "price",
            "c": "chart",
            "t": "top",
            "b": "bottom",
            "w": "watch",
            "uw": "unwatch",
            "wl": "watchlist",
            "i": "info",
            "n": "news",
            "a": "announcements",
            "l": "listings"
        }

    def _load_user_settings(self):
        """Load user settings from a persistent store (e.g., a file)."""
        # Placeholder: Implement loading from a file (e.g., JSON)
        settings_file = self.config.get("user_settings_file", "data/user_settings.json")
        if os.path.exists(settings_file):
            try:
                import json
                with open(settings_file, 'r') as f:
                    self.user_settings = json.load(f)
                logger.info(f"Loaded user settings from {settings_file}")
            except Exception as e:
                logger.error(f"Failed to load user settings: {e}")
        else:
             logger.info("User settings file not found, starting with empty settings.")
             # Ensure the directory exists
             os.makedirs(os.path.dirname(settings_file), exist_ok=True)

    def _save_user_settings(self):
        """Save user settings to a persistent store."""
        # Placeholder: Implement saving to a file (e.g., JSON)
        settings_file = self.config.get("user_settings_file", "data/user_settings.json")
        try:
            import json
            with open(settings_file, 'w') as f:
                json.dump(self.user_settings, f, indent=4)
            logger.info(f"Saved user settings to {settings_file}")
        except Exception as e:
            logger.error(f"Failed to save user settings: {e}")

    def process_command(self, command, args, user_id, chat_id):
        """Process an incoming command."""
        user_id_str = str(user_id) # Use string for JSON keys

        # Check for shortcuts
        if command in self.command_shortcuts:
            command = self.command_shortcuts[command]

        if command in self.command_handlers:
            # Check user permission
            if not self._check_user_permission(user_id_str, command):
                return "您没有执行此命令的权限"

            # Execute the command handler
            try:
                # Pass user_id as string
                response = self.command_handlers[command](args, user_id_str, chat_id)
                # Save settings if they might have changed
                if command in ["watch", "unwatch", "threshold", "pause", "resume", "settings", "alert"]:
                     self._save_user_settings()
                return response
            except Exception as e:
                logger.exception(f"Error processing command {command} for user {user_id_str}")
                return f"处理命令时出错: {str(e)}"
        else:
            return f"未知命令: /{command}。使用 /help 查看可用命令。"

    def _check_user_permission(self, user_id, command):
        """Check if the user has permission to execute the command."""
        # Placeholder: Implement role-based access control if needed
        # For now, allow all commands for all users
        # user_role = self.user_settings.get(user_id, {}).get("role", "user")
        # command_permissions = self.config.get("command_permissions", {})
        # allowed_roles = command_permissions.get(command, ["admin", "user"])
        # return user_role in allowed_roles
        return True # Allow all for now

    # --- Command Handlers --- #

    def handle_start(self, args, user_id, chat_id):
        """Handle the /start command."""
        welcome_message = (
            "👋 *欢迎使用加密货币监控机器人*\n\n"
            "我可以帮助您监控币价变动、查询币种信息、获取交易所公告等。\n\n"
            "🔹 使用 /help 查看所有可用命令\n"
            "🔹 使用 /price <币种> 查询当前价格\n"
            "🔹 使用 /watch <币种> 添加监控\n"
            "🔹 使用 /status 查看系统状态\n\n"
            "祝您交易愉快！"
        )
        return welcome_message

    def handle_help(self, args, user_id, chat_id):
        """Handle the /help command."""
        help_message = "*可用命令列表*\n\n"
        # (Copy help message content from design doc)
        help_message += "*基础命令:*\n"
        help_message += "/start - 启动机器人\n"
        help_message += "/help - 显示此帮助信息\n"
        help_message += "/status - 显示系统状态\n\n"
        help_message += "*价格查询:*\n"
        help_message += "/price (/p) <币种> [交易所] - 查询币种价格\n"
        help_message += "/chart (/c) <币种> [时间周期] - 获取价格图表\n"
        help_message += "/top (/t) [数量] - 查询涨幅最高的币种\n"
        help_message += "/bottom (/b) [数量] - 查询跌幅最大的币种\n\n"
        help_message += "*监控设置:*\n"
        help_message += "/watch (/w) <币种> - 添加币种到监控列表\n"
        help_message += "/unwatch (/uw) <币种> - 从监控列表移除币种\n"
        help_message += "/watchlist (/wl) - 显示当前监控的币种列表\n"
        help_message += "/threshold <类型> <值> - 设置预警阈值 (类型: 5m, 15m, 1h, 24h)\n"
        help_message += "/pause - 暂停所有预警通知\n"
        help_message += "/resume - 恢复所有预警通知\n\n"
        help_message += "*币种信息:*\n"
        help_message += "/info (/i) <币种> - 获取币种详细信息\n"
        help_message += "/news (/n) <币种> [数量] - 获取币种相关新闻\n"
        help_message += "/social <币种> - 获取币种社交媒体情绪\n"
        help_message += "/contract <币种> - 获取币种合约信息\n\n"
        help_message += "*公告查询:*\n"
        help_message += "/announcements (/a) [数量] - 获取最新公告\n"
        help_message += "/listings (/l) [数量] - 获取最新上币公告\n"
        help_message += "/exchange <交易所> [数量] - 获取指定交易所的公告\n\n"
        help_message += "*高级命令:*\n"
        help_message += "/alert <币种> <条件> <值> - 设置自定义预警 (条件: >, <, >=, <=)\n"
        help_message += "/compare <币种1> <币种2> - 比较两个币种的表现\n"
        help_message += "/volume <币种> [交易所] - 查询交易量信息\n"
        help_message += "/settings - 显示和修改用户设置\n"
        return help_message

    def handle_status(self, args, user_id, chat_id):
        """Handle the /status command."""
        try:
            monitored_symbols = len(self.price_monitor.get_monitored_symbols(user_id))
            active_alerts = self.price_monitor.get_active_alerts_count(user_id)
            last_price_check = self.price_monitor.get_last_check_time()
            last_announcement_check = self.announcement_monitor.get_last_check_time()

            last_price_check_str = datetime.fromtimestamp(last_price_check).strftime('%Y-%m-%d %H:%M:%S') if last_price_check else "从未"
            last_announcement_check_str = datetime.fromtimestamp(last_announcement_check).strftime('%Y-%m-%d %H:%M:%S') if last_announcement_check else "从未"

            user_settings = self.user_settings.get(user_id, {})
            notifications_paused = user_settings.get("notifications_paused", False)

            status_message = "📊 *系统状态*\n\n"
            status_message += f"您的监控币种数量: `{monitored_symbols}`\n"
            status_message += f"您的活跃预警数量: `{active_alerts}`\n"
            status_message += f"最后价格检查 (系统): `{last_price_check_str}`\n"
            status_message += f"最后公告检查 (系统): `{last_announcement_check_str}`\n"
            status_message += f"您的通知状态: `{'已暂停' if notifications_paused else '正常'}`\n"

            # Placeholder for system uptime
            # uptime = self._get_system_uptime()
            # status_message += f"系统运行时间: `{uptime}`\n"

            return status_message
        except Exception as e:
            logger.exception("Error getting status")
            return "获取系统状态失败。"

    def handle_price(self, args, user_id, chat_id):
        """Handle the /price command."""
        if not args:
            return "请指定币种，例如: /price BTC"

        symbol_input = args[0].upper()
        exchange = args[1].lower() if len(args) > 1 else None

        # Standardize symbol (e.g., BTC -> BTC/USDT)
        symbol = f"{symbol_input}/USDT" if '/' not in symbol_input else symbol_input

        try:
            price_data = self.price_monitor.fetch_specific_price(symbol, exchange)
            if not price_data:
                return f"未找到 {symbol} 的价格信息。请确保币种名称正确。"

            response = f"💰 *{symbol} 价格信息*\n\n"
            for ex, data in price_data.items():
                response += f"*{ex.capitalize()}*\n"
                response += f"当前价格: `{data.get('price', 'N/A')}`\n"
                change_24h = data.get('change_24h')
                if change_24h is not None:
                    emoji = "🚀" if change_24h > 0 else "📉" if change_24h < 0 else "➖"
                    response += f"24小时变化: `{change_24h:.2f}%` {emoji}\n"
                volume_24h = data.get('volume_24h')
                if volume_24h is not None:
                     response += f"24小时交易量: `${self._format_number(volume_24h)}`\n"
                response += "\n"

            response += f"查看图表请使用: `/chart {symbol_input}`"
            return response
        except Exception as e:
            logger.exception(f"Error fetching price for {symbol}")
            return f"获取 {symbol} 价格失败: {str(e)}"

    def handle_chart(self, args, user_id, chat_id):
        """Handle the /chart command."""
        if not plt:
             return "图表生成功能不可用 (缺少 matplotlib)。"
        if not args:
            return "请指定币种和时间周期，例如: /chart BTC 1d"

        symbol_input = args[0].upper()
        timeframe = args[1].lower() if len(args) > 1 else self.config.get("chart_settings", {}).get("default_timeframe", "1d")
        available_timeframes = self.config.get("chart_settings", {}).get("available_timeframes", ["1h", "4h", "1d", "1w", "1m"])

        if timeframe not in available_timeframes:
            return f"无效的时间周期。可用周期: {', '.join(available_timeframes)}"

        symbol = f"{symbol_input}/USDT" if '/' not in symbol_input else symbol_input

        try:
            # Fetch historical data (assuming price_monitor has this method)
            historical_data = self.price_monitor.fetch_historical_data(symbol, timeframe)
            if not historical_data:
                return f"未找到 {symbol} 的 {timeframe} 历史数据。"

            # Generate chart
            output_dir = self.config.get("chart_settings", {}).get("output_dir", "/tmp")
            chart_path = self._generate_price_chart(symbol, historical_data, timeframe, output_dir)
            if not chart_path:
                return "生成图表失败。"

            # Return chart info for the bot manager to send
            return {
                "type": "photo",
                "path": chart_path,
                "caption": f"{symbol} {timeframe} 价格走势图"
            }
        except Exception as e:
            logger.exception(f"Error generating chart for {symbol}")
            return f"生成 {symbol} 图表失败: {str(e)}"

    def handle_top(self, args, user_id, chat_id):
        """Handle the /top command."""
        limit = int(args[0]) if args and args[0].isdigit() else self.config.get("max_results", {}).get("top", 5)
        limit = min(limit, 20)

        try:
            top_gainers = self.price_monitor.get_top_gainers(limit)
            if not top_gainers:
                return "未能获取涨幅数据。"

            response = f"🚀 *24小时涨幅最高的{len(top_gainers)}个币种*\n\n"
            for i, coin in enumerate(top_gainers, 1):
                response += f"{i}. *{coin['symbol']}*: `+{coin['change']:.2f}%`"
                if 'price' in coin:
                    response += f" (价格: `{coin['price']}`)"
                response += "\n"
            return response
        except Exception as e:
            logger.exception("Error getting top gainers")
            return "获取涨幅数据失败。"

    def handle_bottom(self, args, user_id, chat_id):
        """Handle the /bottom command."""
        limit = int(args[0]) if args and args[0].isdigit() else self.config.get("max_results", {}).get("bottom", 5)
        limit = min(limit, 20)

        try:
            top_losers = self.price_monitor.get_top_losers(limit)
            if not top_losers:
                return "未能获取跌幅数据。"

            response = f"📉 *24小时跌幅最大的{len(top_losers)}个币种*\n\n"
            for i, coin in enumerate(top_losers, 1):
                response += f"{i}. *{coin['symbol']}*: `{coin['change']:.2f}%`"
                if 'price' in coin:
                    response += f" (价格: `{coin['price']}`)"
                response += "\n"
            return response
        except Exception as e:
            logger.exception("Error getting top losers")
            return "获取跌幅数据失败。"

    def handle_watch(self, args, user_id, chat_id):
        """Handle the /watch command."""
        if not args:
            return "请指定币种，例如: /watch BTC"
        symbol_input = args[0].upper()
        symbol = f"{symbol_input}/USDT" if '/' not in symbol_input else symbol_input

        try:
            # Assuming price_monitor handles user-specific watchlists
            success = self.price_monitor.add_symbol_to_watchlist(symbol, user_id)
            if success:
                return f"✅ 已添加 {symbol} 到您的监控列表。"
            else:
                # Could be already watched or invalid symbol
                return f"未能添加 {symbol}。可能已在列表中或币种无效。"
        except Exception as e:
            logger.exception(f"Error watching {symbol} for user {user_id}")
            return f"添加 {symbol} 到监控列表失败。"

    def handle_unwatch(self, args, user_id, chat_id):
        """Handle the /unwatch command."""
        if not args:
            return "请指定币种，例如: /unwatch BTC"
        symbol_input = args[0].upper()
        symbol = f"{symbol_input}/USDT" if '/' not in symbol_input else symbol_input

        try:
            success = self.price_monitor.remove_symbol_from_watchlist(symbol, user_id)
            if success:
                return f"✅ 已从您的监控列表移除 {symbol}。"
            else:
                return f"未能移除 {symbol}。可能不在您的监控列表中。"
        except Exception as e:
            logger.exception(f"Error unwatching {symbol} for user {user_id}")
            return f"从监控列表移除 {symbol} 失败。"

    def handle_watchlist(self, args, user_id, chat_id):
        """Handle the /watchlist command."""
        try:
            watchlist = self.price_monitor.get_user_watchlist(user_id)
            if not watchlist:
                return "您的监控列表为空。使用 /watch <币种> 添加。"

            response = f"📋 *您的监控列表* ({len(watchlist)}个币种)\n\n"
            for i, symbol in enumerate(watchlist, 1):
                # Fetch current data for watched symbols
                price_data = self.price_monitor.get_symbol_data(symbol)
                if price_data:
                    price = price_data.get('price', 'N/A')
                    change_24h = price_data.get('change_24h', 0)
                    emoji = "🚀" if change_24h > 0 else "📉" if change_24h < 0 else "➖"
                    response += f"{i}. *{symbol}*: `{price}` ({change_24h:.2f}% {emoji})\n"
                else:
                    response += f"{i}. *{symbol}*: `数据暂无`\n"
            return response
        except Exception as e:
            logger.exception(f"Error getting watchlist for user {user_id}")
            return "获取监控列表失败。"

    def handle_threshold(self, args, user_id, chat_id):
        """Handle the /threshold command."""
        if len(args) < 2:
            return "请指定类型和值，例如: /threshold 1h 5"

        alert_type = args[0].lower()
        try:
            threshold_value = float(args[1])
        except ValueError:
            return "阈值必须是数字。"

        valid_types = ["5m", "15m", "1h", "24h"]
        if alert_type not in valid_types:
            return f"无效的类型。有效类型: {', '.join(valid_types)}"

        try:
            # Store threshold in user settings
            user_settings = self.user_settings.setdefault(user_id, {})
            user_thresholds = user_settings.setdefault("thresholds", {})
            user_thresholds[alert_type] = threshold_value
            # No need to call save here, process_command handles it
            # self._save_user_settings()
            return f"✅ 已设置您的 {alert_type} 预警阈值为 {threshold_value}%"
        except Exception as e:
            logger.exception(f"Error setting threshold for user {user_id}")
            return "设置阈值失败。"

    def handle_pause(self, args, user_id, chat_id):
        """Handle the /pause command."""
        try:
            self.user_settings.setdefault(user_id, {})["notifications_paused"] = True
            # self._save_user_settings()
            return "✅ 已暂停您的所有预警通知。使用 /resume 恢复。"
        except Exception as e:
            logger.exception(f"Error pausing notifications for user {user_id}")
            return "暂停通知失败。"

    def handle_resume(self, args, user_id, chat_id):
        """Handle the /resume command."""
        try:
            self.user_settings.setdefault(user_id, {})["notifications_paused"] = False
            # self._save_user_settings()
            return "✅ 已恢复您的所有预警通知。"
        except Exception as e:
            logger.exception(f"Error resuming notifications for user {user_id}")
            return "恢复通知失败。"

    def handle_info(self, args, user_id, chat_id):
        """Handle the /info command."""
        if not args:
            return "请指定币种，例如: /info BTC"
        symbol_input = args[0].upper()

        try:
            # Use coin enricher
            coin_info = self.coin_enricher.get_coin_info(symbol_input)
            if not coin_info:
                return f"未找到 {symbol_input} 的信息。"

            # Format the response based on the design
            response = f"ℹ️ *{coin_info.get('name', symbol_input)} ({symbol_input}) 信息*\n\n"
            # ... (rest of the formatting from design doc) ...
            # Basic Info
            response += "*基本信息:*\n"
            description = coin_info.get('description', '暂无描述')
            max_desc_len = self.config.get("max_description_length", 300)
            if len(description) > max_desc_len:
                description = description[:max_desc_len-3] + "..."
            response += f"{description}\n\n"
            categories = coin_info.get('categories')
            if categories:
                response += f"类别: `{', '.join(categories)}`\n"
            launch_date = coin_info.get('launch_date')
            if launch_date:
                response += f"发布日期: `{launch_date}`\n"
            response += "\n"

            # Market Data
            response += "*市场数据:*\n"
            market_cap = coin_info.get('market_cap')
            if market_cap is not None:
                response += f"市值: `${self._format_number(market_cap)}`\n"
            rank = coin_info.get('rank')
            if rank is not None:
                response += f"市值排名: `#{rank}`\n"
            volume_24h = coin_info.get('volume_24h')
            if volume_24h is not None:
                response += f"24小时交易量: `${self._format_number(volume_24h)}`\n"
            circulating_supply = coin_info.get('circulating_supply')
            if circulating_supply is not None:
                response += f"流通供应量: `{self._format_number(circulating_supply)} {symbol_input}`\n"
            total_supply = coin_info.get('total_supply')
            if total_supply is not None:
                response += f"总供应量: `{self._format_number(total_supply)} {symbol_input}`\n"
            response += "\n"

            # Links
            links = coin_info.get('links')
            if links:
                response += "*相关链接:*\n"
                link_parts = []
                if links.get('website'): link_parts.append(f"[官网]({links['website']})")
                if links.get('twitter'): link_parts.append(f"[Twitter]({links['twitter']})")
                if links.get('telegram'): link_parts.append(f"[Telegram]({links['telegram']})")
                if links.get('github'): link_parts.append(f"[GitHub]({links['github']})")
                if links.get('explorer'): link_parts.append(f"[区块浏览器]({links['explorer']})")
                response += " | ".join(link_parts) if link_parts else "暂无相关链接"
                response += "\n"

            return response
        except Exception as e:
            logger.exception(f"Error getting info for {symbol_input}")
            return f"获取 {symbol_input} 信息失败。"

    def handle_news(self, args, user_id, chat_id):
        """Handle the /news command."""
        if not args:
            return "请指定币种，例如: /news BTC"
        symbol_input = args[0].upper()
        limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else self.config.get("max_results", {}).get("news", 5)
        limit = min(limit, 10)

        try:
            news_items = self.coin_enricher.get_coin_news(symbol_input, limit)
            if not news_items:
                return f"未找到 {symbol_input} 的相关新闻。"

            response = f"📰 *{symbol_input} 相关新闻* (最近{len(news_items)}条)\n\n"
            for i, item in enumerate(news_items, 1):
                response += f"{i}. [{item.get('title', '无标题')}]({item.get('url', '#')})\n"
                source = item.get('source')
                date = item.get('date')
                if source or date:
                    response += f"   来源: {source or '未知'} | 日期: {date or '未知'}\n"
                response += "\n"
            return response
        except Exception as e:
            logger.exception(f"Error getting news for {symbol_input}")
            return f"获取 {symbol_input} 新闻失败。"

    def handle_social(self, args, user_id, chat_id):
        """Handle the /social command."""
        if not args:
            return "请指定币种，例如: /social BTC"
        symbol_input = args[0].upper()

        try:
            social_data = self.coin_enricher.get_social_sentiment(symbol_input)
            if not social_data:
                return f"未找到 {symbol_input} 的社交媒体数据。"

            response = f"📊 *{symbol_input} 社交媒体情绪分析*\n\n"
            overall = social_data.get('overall')
            if overall is not None:
                emoji = "😃" if overall > 70 else "🙂" if overall > 50 else "😐" if overall > 30 else "🙁"
                response += f"整体情绪: `{overall:.1f}%` {emoji}\n\n"

            platforms = social_data.get('platforms')
            if platforms:
                response += "*平台情绪:*\n"
                for platform, value in platforms.items():
                    emoji = "😃" if value > 70 else "🙂" if value > 50 else "😐" if value > 30 else "🙁"
                    response += f"{platform.capitalize()}: `{value:.1f}%` {emoji}\n"
                response += "\n"

            mentions = social_data.get('mentions')
            if mentions is not None:
                response += f"24小时提及次数: `{mentions}`\n"
            trending_score = social_data.get('trending_score')
            if trending_score is not None:
                response += f"热度指数: `{trending_score}`\n"

            return response
        except Exception as e:
            logger.exception(f"Error getting social data for {symbol_input}")
            return f"获取 {symbol_input} 社交数据失败。"

    def handle_contract(self, args, user_id, chat_id):
        """Handle the /contract command."""
        if not args:
            return "请指定币种，例如: /contract USDT"
        symbol_input = args[0].upper()

        try:
            contract_info_list = self.coin_enricher.get_contract_info(symbol_input)
            if not contract_info_list:
                return f"未找到 {symbol_input} 的合约信息。"

            response = f"📝 *{symbol_input} 合约信息*\n\n"
            if not isinstance(contract_info_list, list):
                contract_info_list = [contract_info_list] # Ensure it's a list

            for i, contract in enumerate(contract_info_list, 1):
                response += f"*合约 {i}:*\n"
                response += f"平台: `{contract.get('platform', 'N/A')}`\n"
                response += f"地址: `{contract.get('contract_address', 'N/A')}`\n"
                token_standard = contract.get('token_standard')
                if token_standard:
                    response += f"标准: `{token_standard}`\n"
                response += "\n"
            return response
        except Exception as e:
            logger.exception(f"Error getting contract info for {symbol_input}")
            return f"获取 {symbol_input} 合约信息失败。"

    def handle_announcements(self, args, user_id, chat_id):
        """Handle the /announcements command."""
        limit = int(args[0]) if args and args[0].isdigit() else self.config.get("max_results", {}).get("announcements", 5)
        limit = min(limit, 10)

        try:
            announcements = self.announcement_monitor.get_latest_announcements(limit)
            if not announcements:
                return "未找到最新公告。"

            response = f"📢 *最新交易所公告* (最近{len(announcements)}条)\n\n"
            for i, ann in enumerate(announcements, 1):
                title = ann.get('title', '无标题')
                exchange = ann.get('exchange', '未知').capitalize()
                date = ann.get('date', '未知日期')
                url = ann.get('url', '')
                response += f"{i}. *{exchange}*: "
                if url:
                    response += f"[{title}]({url})\n"
                else:
                    response += f"{title}\n"
                response += f"   日期: {date}\n\n"
            return response
        except Exception as e:
            logger.exception("Error getting announcements")
            return "获取最新公告失败。"

    def handle_listings(self, args, user_id, chat_id):
        """Handle the /listings command."""
        limit = int(args[0]) if args and args[0].isdigit() else self.config.get("max_results", {}).get("listings", 5)
        limit = min(limit, 10)

        try:
            listings = self.announcement_monitor.get_latest_listings(limit)
            if not listings:
                return "未找到最新上币公告。"

            response = f"🔥 *最新上币公告* (最近{len(listings)}条)\n\n"
            for i, listing in enumerate(listings, 1):
                title = listing.get('title', '无标题')
                exchange = listing.get('exchange', '未知').capitalize()
                date = listing.get('date', '未知日期')
                url = listing.get('url', '')
                response += f"{i}. *{exchange}*: "
                if url:
                    response += f"[{title}]({url})\n"
                else:
                    response += f"{title}\n"
                response += f"   日期: {date}\n\n"
            return response
        except Exception as e:
            logger.exception("Error getting listings")
            return "获取最新上币公告失败。"

    def handle_exchange(self, args, user_id, chat_id):
        """Handle the /exchange command."""
        if not args:
            return "请指定交易所和数量，例如: /exchange binance 5"

        exchange_name = args[0].lower()
        limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 5
        limit = min(limit, 10)

        valid_exchanges = ["binance", "gate"] # Should get from config or monitor
        if exchange_name not in valid_exchanges:
            return f"无效的交易所。支持的交易所: {', '.join(valid_exchanges)}"

        try:
            announcements = self.announcement_monitor.get_exchange_announcements(exchange_name, limit)
            if not announcements:
                return f"未找到 {exchange_name.capitalize()} 的最新公告。"

            response = f"📢 *{exchange_name.capitalize()} 最新公告* (最近{len(announcements)}条)\n\n"
            for i, ann in enumerate(announcements, 1):
                title = ann.get('title', '无标题')
                date = ann.get('date', '未知日期')
                url = ann.get('url', '')
                if url:
                    response += f"{i}. [{title}]({url})\n"
                else:
                    response += f"{i}. {title}\n"
                response += f"   日期: {date}\n\n"
            return response
        except Exception as e:
            logger.exception(f"Error getting announcements for {exchange_name}")
            return f"获取 {exchange_name.capitalize()} 公告失败。"

    def handle_alert(self, args, user_id, chat_id):
        """Handle the /alert command (custom alerts)."""
        if len(args) < 3:
            return "请指定币种、条件和值，例如: /alert BTC > 50000"

        symbol_input = args[0].upper()
        condition = args[1]
        try:
            value = float(args[2])
        except ValueError:
            return "值必须是数字。"

        symbol = f"{symbol_input}/USDT" if '/' not in symbol_input else symbol_input
        valid_conditions = [">", "<", ">=", "<="]
        if condition not in valid_conditions:
            return f"无效的条件。有效条件: {', '.join(valid_conditions)}"

        try:
            # Assuming price_monitor handles custom alerts per user
            alert_id = self.price_monitor.add_custom_alert(symbol, condition, value, user_id)
            if alert_id:
                return f"✅ 已设置 {symbol} {condition} {value} 的自定义预警 (ID: {alert_id})。"
            else:
                return "❌ 设置自定义预警失败。"
        except Exception as e:
            logger.exception(f"Error setting custom alert for user {user_id}")
            return "设置自定义预警失败。"

    def handle_compare(self, args, user_id, chat_id):
        """Handle the /compare command."""
        if len(args) < 2:
            return "请指定两个币种进行比较，例如: /compare BTC ETH"

        symbol1_input = args[0].upper()
        symbol2_input = args[1].upper()
        symbol1 = f"{symbol1_input}/USDT" if '/' not in symbol1_input else symbol1_input
        symbol2 = f"{symbol2_input}/USDT" if '/' not in symbol2_input else symbol2_input

        try:
            data1 = self.price_monitor.get_symbol_data(symbol1)
            data2 = self.price_monitor.get_symbol_data(symbol2)

            if not data1 or not data2:
                missing = []
                if not data1: missing.append(symbol1)
                if not data2: missing.append(symbol2)
                return f"未能获取以下币种的数据: {', '.join(missing)}。"

            # Fetch historical data for comparison (e.g., 7d)
            history1 = self.price_monitor.fetch_historical_data(symbol1, "1d", limit=7)
            history2 = self.price_monitor.fetch_historical_data(symbol2, "1d", limit=7)
            perf1_7d = self._calculate_performance(history1, 7) if history1 else None
            perf2_7d = self._calculate_performance(history2, 7) if history2 else None

            # Format comparison response
            response = f"📊 *{symbol1_input} vs {symbol2_input} 比较*\n\n"
            # ... (rest of the formatting from design doc) ...
            # Current Price
            response += "*当前价格:*\n"
            response += f"{symbol1_input}: `{data1.get('price', 'N/A')}`\n"
            response += f"{symbol2_input}: `{data2.get('price', 'N/A')}`\n\n"
            # 24h Change
            response += "*24小时变化:*\n"
            change1_24h = data1.get('change_24h', 0)
            change2_24h = data2.get('change_24h', 0)
            emoji1 = "🚀" if change1_24h > 0 else "📉" if change1_24h < 0 else "➖"
            emoji2 = "🚀" if change2_24h > 0 else "📉" if change2_24h < 0 else "➖"
            response += f"{symbol1_input}: `{change1_24h:.2f}%` {emoji1}\n"
            response += f"{symbol2_input}: `{change2_24h:.2f}%` {emoji2}\n\n"
            # 7d Performance
            if perf1_7d is not None and perf2_7d is not None:
                response += "*7天表现:*\n"
                emoji1_7d = "🚀" if perf1_7d > 0 else "📉" if perf1_7d < 0 else "➖"
                emoji2_7d = "🚀" if perf2_7d > 0 else "📉" if perf2_7d < 0 else "➖"
                response += f"{symbol1_input}: `{perf1_7d:.2f}%` {emoji1_7d}\n"
                response += f"{symbol2_input}: `{perf2_7d:.2f}%` {emoji2_7d}\n\n"
            # Volume
            response += "*24小时交易量:*\n"
            volume1 = data1.get('volume_24h', 0)
            volume2 = data2.get('volume_24h', 0)
            response += f"{symbol1_input}: `${self._format_number(volume1)}`\n"
            response += f"{symbol2_input}: `${self._format_number(volume2)}`\n\n"
            # Relative Performance
            response += "*相对表现:*\n"
            if change1_24h > change2_24h: response += f"24h: {symbol1_input} 优于 {symbol2_input} `{(change1_24h - change2_24h):.2f}%`\n"
            elif change2_24h > change1_24h: response += f"24h: {symbol2_input} 优于 {symbol1_input} `{(change2_24h - change1_24h):.2f}%`\n"
            else: response += f"24h: 两者表现相当\n"
            if perf1_7d is not None and perf2_7d is not None:
                if perf1_7d > perf2_7d: response += f"7d: {symbol1_input} 优于 {symbol2_input} `{(perf1_7d - perf2_7d):.2f}%`\n"
                elif perf2_7d > perf1_7d: response += f"7d: {symbol2_input} 优于 {symbol1_input} `{(perf2_7d - perf1_7d):.2f}%`\n"
                else: response += f"7d: 两者表现相当\n"

            return response
        except Exception as e:
            logger.exception(f"Error comparing {symbol1} and {symbol2}")
            return "比较币种失败。"

    def handle_volume(self, args, user_id, chat_id):
        """Handle the /volume command."""
        if not args:
            return "请指定币种，例如: /volume BTC"
        symbol_input = args[0].upper()
        exchange = args[1].lower() if len(args) > 1 else None
        symbol = f"{symbol_input}/USDT" if '/' not in symbol_input else symbol_input

        try:
            # Assuming price_monitor can provide volume data
            volume_data = self.price_monitor.get_volume_data(symbol, exchange)
            if not volume_data:
                return f"未找到 {symbol} 的交易量信息。"

            response = f"📊 *{symbol} 交易量信息*\n\n"
            for ex, data in volume_data.items():
                response += f"*{ex.capitalize()}*\n"
                vol_24h = data.get('volume_24h')
                if vol_24h is not None:
                    response += f"24小时交易量: `${self._format_number(vol_24h)}`\n"
                vol_change_24h = data.get('volume_change_24h')
                if vol_change_24h is not None:
                    emoji = "🚀" if vol_change_24h > 0 else "📉" if vol_change_24h < 0 else "➖"
                    response += f"24小时交易量变化: `{vol_change_24h:.2f}%` {emoji}\n"
                # Add buy/sell ratio if available
                buy_vol = data.get('buy_volume_24h')
                sell_vol = data.get('sell_volume_24h')
                if buy_vol is not None and sell_vol is not None:
                    total_vol = buy_vol + sell_vol
                    if total_vol > 0:
                        buy_perc = (buy_vol / total_vol) * 100
                        sell_perc = (sell_vol / total_vol) * 100
                        response += f"买入比例: `{buy_perc:.2f}%`\n"
                        response += f"卖出比例: `{sell_perc:.2f}%` "
                        response += "(买压 > 卖压 📈)\n" if buy_vol > sell_vol else "(卖压 > 买压 📉)\n"
                response += "\n"
            return response
        except Exception as e:
            logger.exception(f"Error getting volume for {symbol}")
            return f"获取 {symbol} 交易量信息失败。"

    def handle_settings(self, args, user_id, chat_id):
        """Handle the /settings command."""
        settings = self.user_settings.setdefault(user_id, {})

        if not args:
            # Display current settings
            response = "⚙️ *您的设置*\n\n"
            notifications_paused = settings.get("notifications_paused", False)
            response += f"通知状态: `{'已暂停' if notifications_paused else '正常'}` (/pause, /resume)\n"
            response += "\n*预警阈值* (/threshold <类型> <值>):\n"
            default_thresholds = self.config.get("default_thresholds", {})
            user_thresholds = settings.get("thresholds", {})
            for alert_type in ["5m", "15m", "1h", "24h"]:
                threshold = user_thresholds.get(alert_type, default_thresholds.get(alert_type, "默认"))
                response += f"  {alert_type}: `{threshold}%`\n"
            # Add other settings display here if needed
            return response
        else:
            # Modify settings (Simplified example)
            setting_key = args[0].lower()
            if setting_key == "threshold" and len(args) >= 3:
                alert_type = args[1].lower()
                try:
                    threshold_value = float(args[2])
                    valid_types = ["5m", "15m", "1h", "24h"]
                    if alert_type not in valid_types:
                        return f"无效的类型。有效类型: {', '.join(valid_types)}"
                    user_thresholds = settings.setdefault("thresholds", {})
                    user_thresholds[alert_type] = threshold_value
                    # self._save_user_settings()
                    return f"✅ 已更新您的 {alert_type} 预警阈值为 {threshold_value}%"
                except ValueError:
                    return "阈值必须是数字。"
                except Exception as e:
                     logger.exception(f"Error updating threshold for user {user_id}")
                     return "更新阈值失败。"
            else:
                return "无效的设置命令。使用 /settings 查看当前设置。"

    # --- Helper Methods --- #

    def _format_number(self, number):
        """Format large numbers for readability."""
        if number is None:
            return "N/A"
        try:
            num = float(number)
            if num >= 1_000_000_000:
                return f"{num / 1_000_000_000:.2f}B"
            elif num >= 1_000_000:
                return f"{num / 1_000_000:.2f}M"
            elif num >= 1_000:
                return f"{num / 1_000:.2f}K"
            else:
                # Adjust precision based on number size
                if abs(num) < 0.01 and num != 0:
                    return f"{num:.6f}"
                elif abs(num) < 1:
                    return f"{num:.4f}"
                else:
                    return f"{num:.2f}"
        except (ValueError, TypeError):
            return str(number) # Return original if not a number

    def _generate_price_chart(self, symbol, historical_data, timeframe, output_dir):
        """Generate a price chart using matplotlib."""
        if not plt:
            logger.warning("Matplotlib not available, cannot generate chart.")
            return None
        try:
            os.makedirs(output_dir, exist_ok=True)
            timestamps = [entry[0] for entry in historical_data] # Assuming timestamp is first element
            prices = [entry[1] for entry in historical_data]     # Assuming price is second element

            # Convert timestamps (assuming ms)
            dates = [datetime.fromtimestamp(ts / 1000) for ts in timestamps]

            plt.figure(figsize=(10, 5))
            plt.plot(dates, prices, label=symbol)
            plt.title(f"{symbol} 价格 ({timeframe})")
            plt.ylabel("价格 (USDT)") # Assuming USDT pair
            plt.xlabel("时间")
            plt.xticks(rotation=30)
            plt.grid(True)
            plt.tight_layout()
            plt.legend()

            # Use a unique filename
            filename = f"{symbol.replace('/', '_')}_{timeframe}_{int(time.time())}.png"
            chart_path = os.path.join(output_dir, filename)
            plt.savefig(chart_path)
            plt.close() # Close the plot to free memory
            logger.info(f"Generated chart: {chart_path}")
            return chart_path
        except Exception as e:
            logger.exception(f"Failed to generate chart for {symbol}")
            return None

    def _calculate_performance(self, historical_data, days):
        """Calculate performance over a number of days."""
        if not historical_data or len(historical_data) < 2:
            return None
        try:
            # Assuming data is sorted chronologically, OHLCV format [ts, o, h, l, c, v]
            # Or simpler format [ts, price]
            if isinstance(historical_data[0], list):
                if len(historical_data[0]) >= 5: # OHLCV
                    prices = [entry[4] for entry in historical_data] # Use close price
                else: # Assume [ts, price]
                    prices = [entry[1] for entry in historical_data]
            else: # Simple list of prices?
                 prices = historical_data # Less robust

            if len(prices) <= days:
                old_price = prices[0]
            else:
                old_price = prices[-days -1] # Price from 'days' ago

            latest_price = prices[-1]

            if old_price is not None and old_price != 0:
                performance = ((latest_price - old_price) / old_price) * 100
                return round(performance, 2)
            else:
                return None
        except Exception as e:
            logger.error(f"Error calculating performance: {e}")
            return None

# Example usage (requires other modules to be defined)
if __name__ == '__main__':
    # This part is for testing/demonstration, won't run in production
    logging.basicConfig(level=logging.INFO)
    
    # Mock dependencies
    class MockPriceMonitor:
        def get_monitored_symbols(self, user_id): return ["BTC/USDT", "ETH/USDT"]
        def get_active_alerts_count(self, user_id): return 2
        def get_last_check_time(self): return time.time() - 120
        def fetch_specific_price(self, symbol, exchange=None): return {exchange or "binance": {"price": 50000, "change_24h": 2.5, "volume_24h": 1000000000}}
        def fetch_historical_data(self, symbol, timeframe, limit=None): return [[time.time()*1000 - i*3600*1000, 50000 - i*100] for i in range(24)]
        def get_top_gainers(self, limit): return [{"symbol": "AAA/USDT", "change": 15.0, "price": 1.2}, {"symbol": "BBB/USDT", "change": 12.5, "price": 0.5}]
        def get_top_losers(self, limit): return [{"symbol": "CCC/USDT", "change": -10.0, "price": 2.1}, {"symbol": "DDD/USDT", "change": -8.5, "price": 3.5}]
        def add_symbol_to_watchlist(self, symbol, user_id): return True
        def remove_symbol_from_watchlist(self, symbol, user_id): return True
        def get_user_watchlist(self, user_id): return ["BTC/USDT", "ETH/USDT"]
        def get_symbol_data(self, symbol): return {"price": 50000, "change_24h": 2.5}
        def add_custom_alert(self, symbol, condition, value, user_id): return f"alert_{int(time.time())}"
        def get_volume_data(self, symbol, exchange=None): return {exchange or "binance": {"volume_24h": 1000000000, "volume_change_24h": 5.0, "buy_volume_24h": 600000000, "sell_volume_24h": 400000000}}

    class MockAnnouncementMonitor:
        def get_last_check_time(self): return time.time() - 3600
        def get_latest_announcements(self, limit): return [{"title": "Test Announcement 1", "exchange": "Binance", "date": "2025-06-02", "url": "http://example.com"}]
        def get_latest_listings(self, limit): return [{"title": "New Listing: XYZ", "exchange": "Gate", "date": "2025-06-02", "url": "http://example.com"}]
        def get_exchange_announcements(self, exchange, limit): return [{"title": f"{exchange.capitalize()} Announcement", "exchange": exchange, "date": "2025-06-02", "url": "http://example.com"}]

    class MockCoinEnricher:
        def get_coin_info(self, symbol): return {"name": symbol.split('/')[0], "description": "A test coin.", "market_cap": 1000000000, "rank": 1, "volume_24h": 50000000, "circulating_supply": 1000000, "total_supply": 2000000, "links": {"website": "http://example.com"}}
        def get_coin_news(self, symbol, limit): return [{"title": "Test News", "url": "http://example.com", "source": "Test Source", "date": "2025-06-02"}]
        def get_social_sentiment(self, symbol): return {"overall": 65.5, "platforms": {"twitter": 70.0, "reddit": 60.0}, "mentions": 1000, "trending_score": 80}
        def get_contract_info(self, symbol): return [{"platform": "Ethereum", "contract_address": "0x123...", "token_standard": "ERC20"}]

    # Config (simplified)
    test_config = {
        "user_settings_file": "/tmp/test_user_settings.json",
        "command_permissions": {},
        "default_thresholds": {"1h": 5.0},
        "max_results": {"top": 5, "bottom": 5, "news": 3, "announcements": 3, "listings": 3},
        "chart_settings": {"default_timeframe": "1d", "available_timeframes": ["1h", "1d"], "output_dir": "/tmp"}
    }

    # Initialize
    price_monitor = MockPriceMonitor()
    ann_monitor = MockAnnouncementMonitor()
    enricher = MockCoinEnricher()
    handler = TelegramCommandHandler(test_config, price_monitor, ann_monitor, enricher)

    # Test a command
    print("--- Testing /status ---")
    print(handler.process_command("status", [], "12345", "chat1"))
    print("--- Testing /price BTC ---")
    print(handler.process_command("price", ["BTC"], "12345", "chat1"))
    print("--- Testing /chart ETH 1d ---")
    chart_info = handler.process_command("chart", ["ETH", "1d"], "12345", "chat1")
    print(chart_info)
    if isinstance(chart_info, dict) and chart_info.get("type") == "photo":
        print(f"Chart generated at: {chart_info['path']}")
        # In real scenario, bot manager would send this file
        # os.remove(chart_info['path']) # Clean up test file
    print("--- Testing /watchlist ---")
    print(handler.process_command("watchlist", [], "12345", "chat1"))
    print("--- Testing /threshold 1h 10 ---")
    print(handler.process_command("threshold", ["1h", "10"], "12345", "chat1"))
    print("--- Testing /settings ---")
    print(handler.process_command("settings", [], "12345", "chat1"))
    print("--- Testing /info SOL ---")
    print(handler.process_command("info", ["SOL"], "12345", "chat1"))
    print("--- Testing /news ADA 2 ---")
    print(handler.process_command("news", ["ADA", "2"], "12345", "chat1"))
    print("--- Testing /announcements ---")
    print(handler.process_command("announcements", [], "12345", "chat1"))
    print("--- Testing shortcut /p ETH ---")
    print(handler.process_command("p", ["ETH"], "12345", "chat1"))

