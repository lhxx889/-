#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
import os
import json

# 读取README文件
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

# 读取requirements.txt
with open('requirements.txt', 'r', encoding='utf-8') as f:
    requirements = f.read().splitlines()

# 设置基本信息
setup(
    name="crypto_monitor",
    version="1.0.0",
    author="Crypto Monitor Team",
    author_email="example@example.com",
    description="加密货币交易所监控系统",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/example/crypto_monitor",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'crypto-monitor=crypto_monitor.main:main',
            'crypto-setup=crypto_monitor.quick_settings:main',
        ],
    },
    include_package_data=True,
    package_data={
        '': ['*.md', '*.json'],
    },
)
