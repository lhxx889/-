# 加密货币交易所监控方案（增强版）

## 需求概述

根据您的需求，我们设计一个专注于监控功能的脚本，主要功能包括：

1. 监控币安和Gate交易所的加密货币价格变动（涨幅/跌幅过大）
2. 监控币安最新公告和新上币公告（每小时一次）
3. 将监控到的信息推送到多个Telegram账号
4. 实现智能API轮询机制

## 整体架构设计

监控系统分为以下几个核心模块：

### 1. 数据采集模块
- 币安API接口调用
- Gate API接口调用
- 智能轮询控制
- 公告爬取模块

### 2. 数据处理模块
- 价格变动计算
- 异常检测（涨跌幅阈值判断）
- 公告解析与过滤

### 3. 通知推送模块
- 多账号Telegram Bot集成
- 消息格式化
- 消息分发策略
- 推送控制

### 4. 配置管理模块
- 监控参数配置
- API密钥管理
- 阈值设置
- 多账号配置

### 5. 运行控制模块
- 定时任务替代方案
- 错误处理与日志
- 状态监控

## 技术选型

### 编程语言与框架
- **Python**: 适合数据处理和API调用，有丰富的加密货币交易所库
- **主要库**:
  - `python-binance`: 币安官方API客户端
  - `ccxt`: 统一的加密货币交易所API库，支持多个交易所
  - `python-telegram-bot`: Telegram Bot API的Python封装
  - `requests`: HTTP请求库，用于爬取公告
  - `pandas`: 数据处理和分析
  - `schedule`: 简单的定时任务调度（本地运行时使用）
  - `websocket-client`: WebSocket连接支持
  - `aiohttp`: 异步HTTP请求支持

## 模块详细设计

### 1. 智能API轮询模块

#### 核心功能
- 实现自适应轮询间隔
- 批量处理API请求
- 错误处理与重试机制
- API限流控制

#### 实现方案
```python
# API轮询模块伪代码
class ApiPollingManager:
    def __init__(self, config):
        self.config = config
        self.base_interval = config.get("base_interval", 60)  # 基础轮询间隔（秒）
        self.min_interval = config.get("min_interval", 10)    # 最小轮询间隔（秒）
        self.max_interval = config.get("max_interval", 300)   # 最大轮询间隔（秒）
        self.current_interval = self.base_interval
        self.volatility_history = []
        self.error_counts = {}
        self.last_request_time = {}
        
    def calculate_adaptive_interval(self, market_volatility):
        """根据市场波动性计算自适应轮询间隔"""
        # 记录最近的波动性
        self.volatility_history.append(market_volatility)
        if len(self.volatility_history) > 10:
            self.volatility_history.pop(0)
            
        # 计算平均波动性
        avg_volatility = sum(self.volatility_history) / len(self.volatility_history)
        
        # 根据波动性调整间隔
        if avg_volatility > 5.0:  # 高波动
            self.current_interval = max(self.min_interval, self.base_interval * 0.5)
        elif avg_volatility < 1.0:  # 低波动
            self.current_interval = min(self.max_interval, self.base_interval * 1.5)
        else:  # 正常波动
            self.current_interval = self.base_interval
            
        return self.current_interval
        
    def should_request(self, api_name):
        """判断是否应该发送请求"""
        current_time = time.time()
        
        # 检查是否达到最小请求间隔
        if api_name in self.last_request_time:
            elapsed = current_time - self.last_request_time[api_name]
            min_api_interval = self.config.get(f"{api_name}_min_interval", self.min_interval)
            
            if elapsed < min_api_interval:
                return False
                
        return True
        
    def record_request(self, api_name):
        """记录API请求"""
        self.last_request_time[api_name] = time.time()
        
    def record_error(self, api_name, error):
        """记录API错误"""
        if api_name not in self.error_counts:
            self.error_counts[api_name] = 0
            
        self.error_counts[api_name] += 1
        logger.error(f"{api_name} API错误: {error}, 错误计数: {self.error_counts[api_name]}")
        
    def get_retry_delay(self, api_name):
        """获取重试延迟（指数退避）"""
        error_count = self.error_counts.get(api_name, 0)
        if error_count == 0:
            return 0
            
        # 指数退避算法
        base_delay = 2
        max_delay = 300  # 最大5分钟
        
        delay = min(max_delay, base_delay ** min(error_count, 8))
        jitter = random.uniform(0, 0.1 * delay)  # 添加随机抖动
        
        return delay + jitter
        
    def reset_error(self, api_name):
        """重置API错误计数"""
        if api_name in self.error_counts:
            self.error_counts[api_name] = 0
```

#### API轮询配置示例
```python
api_polling_config = {
    "base_interval": 60,       # 基础轮询间隔（秒）
    "min_interval": 10,        # 最小轮询间隔（秒）
    "max_interval": 300,       # 最大轮询间隔（秒）
    "binance_min_interval": 3, # 币安API最小间隔
    "gate_min_interval": 5,    # Gate API最小间隔
    "use_websocket": True,     # 是否使用WebSocket
    "batch_requests": True     # 是否批量请求
}
```

### 2. 价格监控模块

#### 核心功能
- 从币安和Gate获取价格数据
- 计算不同时间周期的涨跌幅
- 检测异常价格变动
- 生成价格预警消息

#### 实现方案
```python
# 价格监控模块伪代码
class PriceMonitor:
    def __init__(self, config, api_manager):
        self.config = config
        self.api_manager = api_manager
        self.binance_client = setup_binance_client(config)
        self.gate_client = setup_gate_client(config)
        self.symbols = config.get("symbols", [])
        self.thresholds = config.get("thresholds", {})
        self.price_history = {}
        self.websocket_connections = {}
        
        # 如果配置了WebSocket，则初始化连接
        if config.get("use_websocket", False):
            self._setup_websocket_connections()
            
    def _setup_websocket_connections(self):
        """设置WebSocket连接"""
        try:
            # 设置币安WebSocket
            binance_symbols = [s.lower().replace("/", "") for s in self.symbols]
            binance_streams = [f"{s}@ticker" for s in binance_symbols]
            self.websocket_connections["binance"] = self.binance_client.start_multiplex_socket(
                binance_streams,
                self._handle_binance_websocket_message
            )
            
            # 设置Gate WebSocket (如果支持)
            # Gate WebSocket实现略
            
            logger.info("WebSocket连接已设置")
        except Exception as e:
            logger.error(f"设置WebSocket连接失败: {e}")
            
    def _handle_binance_websocket_message(self, msg):
        """处理币安WebSocket消息"""
        try:
            if "e" in msg and msg["e"] == "24hrTicker":
                symbol = msg["s"]
                price = float(msg["c"])
                change_24h = float(msg["P"])
                
                # 更新价格历史
                if symbol not in self.price_history:
                    self.price_history[symbol] = []
                    
                self.price_history[symbol].append({
                    "price": price,
                    "change_24h": change_24h,
                    "timestamp": time.time()
                })
                
                # 保持历史记录在合理范围内
                if len(self.price_history[symbol]) > 100:
                    self.price_history[symbol] = self.price_history[symbol][-100:]
                    
                # 检查是否需要发送预警
                self._check_single_price_alert("binance", symbol, price, change_24h)
        except Exception as e:
            logger.error(f"处理WebSocket消息失败: {e}")
        
    def fetch_prices(self):
        """获取所有监控币种的价格"""
        results = {}
        
        # 检查是否应该请求币安API
        if self.api_manager.should_request("binance"):
            try:
                binance_prices = self._fetch_binance_prices()
                results["binance"] = binance_prices
                self.api_manager.record_request("binance")
                self.api_manager.reset_error("binance")
            except Exception as e:
                self.api_manager.record_error("binance", e)
                logger.error(f"获取币安价格失败: {e}")
                
        # 检查是否应该请求Gate API
        if self.api_manager.should_request("gate"):
            try:
                gate_prices = self._fetch_gate_prices()
                results["gate"] = gate_prices
                self.api_manager.record_request("gate")
                self.api_manager.reset_error("gate")
            except Exception as e:
                self.api_manager.record_error("gate", e)
                logger.error(f"获取Gate价格失败: {e}")
                
        return results
        
    def _fetch_binance_prices(self):
        """获取币安价格数据"""
        prices = {}
        
        if self.config.get("batch_requests", True):
            # 批量请求所有币种价格
            try:
                tickers = self.binance_client.get_all_tickers()
                symbol_map = {s.replace("/", ""): s for s in self.symbols}
                
                for ticker in tickers:
                    symbol = ticker["symbol"]
                    if symbol in symbol_map:
                        original_symbol = symbol_map[symbol]
                        prices[original_symbol] = {
                            "price": float(ticker["price"]),
                            "timestamp": time.time()
                        }
                        
                # 获取24小时变化
                tickers_24h = self.binance_client.get_ticker()
                for ticker in tickers_24h:
                    symbol = ticker["symbol"]
                    if symbol in symbol_map:
                        original_symbol = symbol_map[symbol]
                        if original_symbol in prices:
                            prices[original_symbol]["change_24h"] = float(ticker["priceChangePercent"])
            except Exception as e:
                logger.error(f"批量获取币安价格失败: {e}")
                raise
        else:
            # 单独请求每个币种
            for symbol in self.symbols:
                try:
                    ticker = self.binance_client.get_ticker(symbol=symbol.replace("/", ""))
                    prices[symbol] = {
                        "price": float(ticker["lastPrice"]),
                        "change_24h": float(ticker["priceChangePercent"]),
                        "timestamp": time.time()
                    }
                except Exception as e:
                    logger.error(f"获取币安{symbol}价格失败: {e}")
                    
        return prices
        
    def _fetch_gate_prices(self):
        """获取Gate价格数据"""
        prices = {}
        
        if self.config.get("batch_requests", True):
            # 批量请求所有币种价格
            try:
                tickers = self.gate_client.get_tickers()
                
                for symbol in self.symbols:
                    gate_symbol = symbol.replace("/", "_")
                    for ticker in tickers:
                        if ticker["currency_pair"] == gate_symbol:
                            prices[symbol] = {
                                "price": float(ticker["last"]),
                                "change_24h": float(ticker["change_percentage"]) * 100,
                                "timestamp": time.time()
                            }
                            break
            except Exception as e:
                logger.error(f"批量获取Gate价格失败: {e}")
                raise
        else:
            # 单独请求每个币种
            for symbol in self.symbols:
                try:
                    gate_symbol = symbol.replace("/", "_")
                    ticker = self.gate_client.get_ticker(gate_symbol)
                    prices[symbol] = {
                        "price": float(ticker["last"]),
                        "change_24h": float(ticker["change_percentage"]) * 100,
                        "timestamp": time.time()
                    }
                except Exception as e:
                    logger.error(f"获取Gate{symbol}价格失败: {e}")
                    
        return prices
        
    def calculate_market_volatility(self, prices):
        """计算市场整体波动性"""
        if not prices:
            return 0.0
            
        changes = []
        for exchange_data in prices.values():
            for symbol_data in exchange_data.values():
                if "change_24h" in symbol_data:
                    changes.append(abs(symbol_data["change_24h"]))
                    
        if not changes:
            return 0.0
            
        return sum(changes) / len(changes)
        
    def check_price_alerts(self, prices):
        """检查价格预警"""
        alerts = []
        
        for exchange, exchange_prices in prices.items():
            for symbol, data in exchange_prices.items():
                # 检查24小时涨跌幅
                if "change_24h" in data and abs(data["change_24h"]) > self.thresholds.get("change_24h", 10):
                    alerts.append({
                        "exchange": exchange,
                        "symbol": symbol,
                        "price": data["price"],
                        "change": data["change_24h"],
                        "type": "24h_change"
                    })
                    
                # 检查短期价格变化（如果有历史数据）
                if symbol in self.price_history and len(self.price_history[symbol]) > 1:
                    current_price = data["price"]
                    
                    # 检查5分钟变化
                    five_min_ago = time.time() - 300
                    five_min_prices = [p for p in self.price_history[symbol] if p["timestamp"] >= five_min_ago]
                    
                    if five_min_prices:
                        oldest_price = five_min_prices[0]["price"]
                        change_5m = ((current_price - oldest_price) / oldest_price) * 100
                        
                        if abs(change_5m) > self.thresholds.get("change_5m", 3):
                            alerts.append({
                                "exchange": exchange,
                                "symbol": symbol,
                                "price": current_price,
                                "change": change_5m,
                                "type": "5m_change"
                            })
                    
        return alerts
        
    def _check_single_price_alert(self, exchange, symbol, price, change_24h):
        """检查单个价格是否需要预警（用于WebSocket更新）"""
        # 检查24小时涨跌幅
        if abs(change_24h) > self.thresholds.get("change_24h", 10):
            return {
                "exchange": exchange,
                "symbol": symbol,
                "price": price,
                "change": change_24h,
                "type": "24h_change"
            }
            
        return None
```

#### 价格监控配置示例
```python
price_monitor_config = {
    "symbols": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT"],
    "thresholds": {
        "change_5m": 3.0,   # 5分钟涨跌幅阈值
        "change_15m": 5.0,  # 15分钟涨跌幅阈值
        "change_1h": 7.0,   # 1小时涨跌幅阈值
        "change_24h": 15.0  # 24小时涨跌幅阈值
    },
    "use_websocket": true,  # 使用WebSocket获取实时价格
    "batch_requests": true  # 批量请求价格数据
}
```

### 3. 公告监控模块

#### 核心功能
- 获取币安最新公告
- 过滤新上币公告
- 与历史记录比较，找出新公告
- 生成公告通知消息

#### 实现方案
```python
# 公告监控模块伪代码
class AnnouncementMonitor:
    def __init__(self, config, api_manager):
        self.config = config
        self.api_manager = api_manager
        self.binance_client = setup_binance_client(config)
        self.history_file = config.get("history_file", "announcement_history.json")
        self.load_history()
        
    def load_history(self):
        """加载历史公告记录"""
        try:
            with open(self.history_file, "r") as f:
                self.history = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.history = {"announcements": [], "new_listings": []}
            
    def save_history(self):
        """保存历史公告记录"""
        with open(self.history_file, "w") as f:
            json.dump(self.history, f)
            
    def fetch_announcements(self):
        """获取币安最新公告"""
        # 检查是否应该请求API
        if not self.api_manager.should_request("binance_announcement"):
            logger.info("跳过币安公告请求，未达到最小间隔")
            return []
            
        try:
            # 使用币安API获取公告
            announcements = self.binance_client.get_announcements()
            self.api_manager.record_request("binance_announcement")
            self.api_manager.reset_error("binance_announcement")
            return announcements
        except Exception as e:
            self.api_manager.record_error("binance_announcement", e)
            logger.error(f"获取币安公告失败: {e}")
            
            # 如果API失败，尝试爬取网页
            retry_delay = self.api_manager.get_retry_delay("binance_announcement")
            if retry_delay > 0:
                logger.info(f"将在{retry_delay}秒后重试")
                time.sleep(retry_delay)
                
            return self._scrape_announcements()
            
    def _scrape_announcements(self):
        """爬取币安公告页面（备选方案）"""
        announcements = []
        try:
            response = requests.get("https://www.binance.com/en/support/announcement/c-48")
            if response.status_code == 200:
                # 解析HTML获取公告信息
                # 这里需要根据实际页面结构进行解析
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 示例解析逻辑，实际需要根据页面结构调整
                announcement_items = soup.select('.css-1ej4hfo')
                
                for item in announcement_items:
                    try:
                        title_elem = item.select_one('.css-1nqr3jw')
                        date_elem = item.select_one('.css-1fobf8d')
                        link_elem = item.select_one('a')
                        
                        if title_elem and link_elem:
                            title = title_elem.text.strip()
                            date = date_elem.text.strip() if date_elem else ""
                            url = "https://www.binance.com" + link_elem['href'] if link_elem.has_attr('href') else ""
                            
                            announcements.append({
                                "id": hashlib.md5(title.encode()).hexdigest(),
                                "title": title,
                                "date": date,
                                "url": url
                            })
                    except Exception as e:
                        logger.error(f"解析公告项失败: {e}")
                        
        except Exception as e:
            logger.error(f"爬取币安公告失败: {e}")
            
        return announcements
        
    def filter_new_listings(self, announcements):
        """过滤新上币公告"""
        new_listings = []
        keywords = self.config.get("keywords", {}).get("listing", ["listing", "新币上线", "will list"])
        
        for announcement in announcements:
            title = announcement.get("title", "").lower()
            if any(keyword.lower() in title for keyword in keywords):
                new_listings.append(announcement)
                
        return new_listings
        
    def find_new_announcements(self, announcements):
        """找出新公告"""
        new_announcements = []
        existing_ids = [a["id"] for a in self.history["announcements"]]
        
        for announcement in announcements:
            if announcement["id"] not in existing_ids:
                new_announcements.append(announcement)
                self.history["announcements"].append({
                    "id": announcement["id"],
                    "title": announcement["title"],
                    "date": announcement.get("date", ""),
                    "url": announcement.get("url", "")
                })
                
        return new_announcements
        
    def find_new_listings(self, listings):
        """找出新上币公告"""
        new_listings = []
        existing_ids = [a["id"] for a in self.history["new_listings"]]
        
        for listing in listings:
            if listing["id"] not in existing_ids:
                new_listings.append(listing)
                self.history["new_listings"].append({
                    "id": listing["id"],
                    "title": listing["title"],
                    "date": listing.get("date", ""),
                    "url": listing.get("url", "")
                })
                
        return new_listings
        
    def check_announcements(self):
        """检查新公告"""
        announcements = self.fetch_announcements()
        
        if not announcements:
            return {"new_announcements": [], "new_listings": []}
            
        listings = self.filter_new_listings(announcements)
        
        new_announcements = self.find_new_announcements(announcements)
        new_listings = self.find_new_listings(listings)
        
        self.save_history()
        
        return {
            "new_announcements": new_announcements,
            "new_listings": new_listings
        }
```

#### 公告监控配置示例
```python
announcement_config = {
    "history_file": "data/announcement_history.json",
    "check_interval": 3600,  # 每小时检查一次
    "keywords": {
        "listing": ["listing", "新币上线", "will list", "new cryptocurrency", "new token"],
        "important": ["update", "upgrade", "maintenance", "维护", "更新", "system", "trading"]
    }
}
```

### 4. Telegram多账号推送模块

#### 核心功能
- 支持多个Telegram Bot配置
- 消息分发策略
- 账号状态监控
- 消息格式化和发送

#### 实现方案
```python
# Telegram多账号推送模块伪代码
class MultiAccountTelegramNotifier:
    def __init__(self, config):
        self.config = config
        self.accounts = self._setup_accounts(config.get("accounts", []))
        self.default_account = config.get("default_account", "main")
        self.message_routing = config.get("message_routing", {})
        self.last_notification_time = {}
        self.account_status = {}
        
    def _setup_accounts(self, accounts_config):
        """设置多个Telegram账号"""
        accounts = {}
        
        for account in accounts_config:
            name = account.get("name", "unnamed")
            token = account.get("token", "")
            chat_id = account.get("chat_id", "")
            
            if token and chat_id:
                try:
                    bot = telegram.Bot(token=token)
                    accounts[name] = {
                        "bot": bot,
                        "chat_id": chat_id,
                        "token": token,
                        "priority": account.get("priority", 0)
                    }
                    self.account_status[name] = {
                        "active": True,
                        "last_check": time.time(),
                        "error_count": 0
                    }
                    logger.info(f"Telegram账号 {name} 设置成功")
                except Exception as e:
                    logger.error(f"Telegram账号 {name} 设置失败: {e}")
                    
        return accounts
        
    def get_account_for_message(self, message_type):
        """根据消息类型获取应使用的账号"""
        # 检查消息路由配置
        if message_type in self.message_routing:
            account_name = self.message_routing[message_type]
            if account_name in self.accounts:
                if self.account_status[account_name]["active"]:
                    return account_name
                else:
                    logger.warning(f"账号 {account_name} 不活跃，使用默认账号")
                    
        # 使用默认账号
        if self.default_account in self.accounts and self.account_status[self.default_account]["active"]:
            return self.default_account
            
        # 如果默认账号不可用，使用优先级最高的活跃账号
        active_accounts = [(name, data["priority"]) 
                          for name, data in self.accounts.items() 
                          if self.account_status[name]["active"]]
        
        if active_accounts:
            # 按优先级排序，选择最高优先级
            active_accounts.sort(key=lambda x: x[1], reverse=True)
            return active_accounts[0][0]
            
        # 如果没有活跃账号，尝试使用任何可用账号
        if self.accounts:
            return list(self.accounts.keys())[0]
            
        logger.error("没有可用的Telegram账号")
        return None
        
    def send_message(self, message, message_type="general", parse_mode="Markdown", accounts=None):
        """发送消息到Telegram"""
        if not self.accounts:
            logger.error("没有配置Telegram账号")
            return False
            
        # 确定要发送到哪些账号
        target_accounts = []
        
        if accounts == "all":
            # 发送到所有账号
            target_accounts = list(self.accounts.keys())
        elif accounts and isinstance(accounts, list):
            # 发送到指定账号列表
            target_accounts = [acc for acc in accounts if acc in self.accounts]
        else:
            # 根据消息类型选择账号
            account = self.get_account_for_message(message_type)
            if account:
                target_accounts = [account]
                
        if not target_accounts:
            logger.error("没有目标账号可发送消息")
            return False
            
        # 发送消息到所有目标账号
        success = False
        for account_name in target_accounts:
            try:
                account = self.accounts[account_name]
                account["bot"].send_message(
                    chat_id=account["chat_id"],
                    text=message,
                    parse_mode=parse_mode
                )
                
                # 更新账号状态
                self.account_status[account_name]["active"] = True
                self.account_status[account_name]["last_check"] = time.time()
                self.account_status[account_name]["error_count"] = 0
                
                success = True
                logger.info(f"消息已发送到账号 {account_name}")
            except Exception as e:
                # 更新账号状态
                self.account_status[account_name]["error_count"] += 1
                if self.account_status[account_name]["error_count"] >= 3:
                    self.account_status[account_name]["active"] = False
                    
                logger.error(f"发送消息到账号 {account_name} 失败: {e}")
                
        return success
        
    def check_accounts_status(self):
        """检查所有账号状态"""
        for name, account in self.accounts.items():
            try:
                # 发送测试消息或获取bot信息
                bot_info = account["bot"].get_me()
                
                # 更新账号状态
                self.account_status[name]["active"] = True
                self.account_status[name]["last_check"] = time.time()
                self.account_status[name]["error_count"] = 0
                
                logger.info(f"账号 {name} 状态正常: {bot_info.first_name}")
            except Exception as e:
                self.account_status[name]["error_count"] += 1
                if self.account_status[name]["error_count"] >= 3:
                    self.account_status[name]["active"] = False
                    
                logger.error(f"账号 {name} 状态检查失败: {e}")
                
        # 返回活跃账号数量
        active_count = sum(1 for status in self.account_status.values() if status["active"])
        return active_count
        
    def format_price_alert(self, alert):
        """格式化价格预警消息"""
        exchange = alert["exchange"].capitalize()
        symbol = alert["symbol"]
        price = alert["price"]
        change = alert["change"]
        
        if change > 0:
            direction = "上涨"
            emoji = "🚀"
        else:
            direction = "下跌"
            emoji = "📉"
            
        message = f"{emoji} *价格预警* {emoji}\n\n"
        message += f"交易所: `{exchange}`\n"
        message += f"币种: `{symbol}`\n"
        message += f"{direction}: `{abs(change)}%`\n"
        message += f"当前价格: `{price}`"
        
        return message
        
    def format_announcement(self, announcement):
        """格式化公告消息"""
        title = announcement["title"]
        url = announcement.get("url", "")
        date = announcement.get("date", "")
        
        message = f"📢 *币安最新公告* 📢\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def format_new_listing(self, listing):
        """格式化新上币公告消息"""
        title = listing["title"]
        url = listing.get("url", "")
        date = listing.get("date", "")
        
        message = f"🔥 *币安新币上线* 🔥\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def notify_price_alert(self, alert):
        """发送价格预警通知"""
        # 检查是否需要限流
        symbol = alert["symbol"]
        alert_type = alert["type"]
        key = f"{symbol}_{alert_type}"
        
        current_time = time.time()
        if key in self.last_notification_time:
            time_diff = current_time - self.last_notification_time[key]
            min_interval = self.config.get("min_alert_interval", 300)  # 默认5分钟
            
            if time_diff < min_interval:
                logger.info(f"跳过{symbol}的{alert_type}预警，距离上次通知仅{time_diff}秒")
                return False
                
        message = self.format_price_alert(alert)
        
        # 根据预警类型确定发送账号
        if alert_type == "24h_change" and abs(alert["change"]) > 20:
            # 大幅波动，发送到所有账号
            result = self.send_message(message, message_type="major_price_alert", accounts="all")
        else:
            # 普通波动，使用默认路由
            result = self.send_message(message, message_type="price_alert")
            
        if result:
            self.last_notification_time[key] = current_time
            
        return result
        
    def notify_announcement(self, announcement):
        """发送公告通知"""
        message = self.format_announcement(announcement)
        return self.send_message(message, message_type="announcement")
        
    def notify_new_listing(self, listing):
        """发送新上币通知"""
        message = self.format_new_listing(listing)
        # 新上币是高优先级消息，发送到所有账号
        return self.send_message(message, message_type="new_listing", accounts="all")
```

#### Telegram多账号配置示例
```python
telegram_config = {
    "accounts": [
        {
            "name": "main",
            "token": "YOUR_MAIN_BOT_TOKEN",
            "chat_id": "YOUR_MAIN_CHAT_ID",
            "priority": 10
        },
        {
            "name": "backup",
            "token": "YOUR_BACKUP_BOT_TOKEN",
            "chat_id": "YOUR_BACKUP_CHAT_ID",
            "priority": 5
        },
        {
            "name": "alerts",
            "token": "YOUR_ALERTS_BOT_TOKEN",
            "chat_id": "YOUR_ALERTS_CHAT_ID",
            "priority": 8
        }
    ],
    "default_account": "main",
    "message_routing": {
        "price_alert": "alerts",
        "major_price_alert": "main",
        "announcement": "main",
        "new_listing": "main",
        "system": "backup"
    },
    "min_alert_interval": 300,  # 同一币种同类型预警的最小间隔（秒）
    "max_daily_alerts": 20      # 每日最大预警次数
}
```

### 5. 主程序与运行控制

#### 核心功能
- 初始化各模块
- 实现智能轮询逻辑
- 处理错误和异常情况
- 提供日志记录

#### 实现方案
```python
# 主程序伪代码
class CryptoMonitor:
    def __init__(self, config_file):
        self.config = self._load_config(config_file)
        self.api_manager = ApiPollingManager(self.config.get("api_polling", {}))
        self.price_monitor = PriceMonitor(self.config["price_monitor"], self.api_manager)
        self.announcement_monitor = AnnouncementMonitor(self.config["announcement_monitor"], self.api_manager)
        self.telegram_notifier = MultiAccountTelegramNotifier(self.config["telegram"])
        self.running = False
        self.last_announcement_check = 0
        
    def _load_config(self, config_file):
        """加载配置文件"""
        with open(config_file, "r") as f:
            return json.load(f)
            
    def check_prices(self):
        """检查价格并发送预警"""
        try:
            prices = self.price_monitor.fetch_prices()
            if not prices:
                logger.info("没有获取到价格数据")
                return 0
                
            # 计算市场波动性，用于调整轮询间隔
            market_volatility = self.price_monitor.calculate_market_volatility(prices)
            next_interval = self.api_manager.calculate_adaptive_interval(market_volatility)
            logger.info(f"市场波动性: {market_volatility:.2f}%, 下次轮询间隔: {next_interval}秒")
            
            # 检查价格预警
            alerts = self.price_monitor.check_price_alerts(prices)
            
            for alert in alerts:
                self.telegram_notifier.notify_price_alert(alert)
                
            return len(alerts)
        except Exception as e:
            logger.error(f"价格检查失败: {e}")
            return 0
            
    def check_announcements(self):
        """检查公告并发送通知"""
        current_time = time.time()
        announcement_interval = self.config["announcement_monitor"].get("check_interval", 3600)
        
        # 检查是否达到公告检查间隔
        if current_time - self.last_announcement_check < announcement_interval:
            time_to_next = announcement_interval - (current_time - self.last_announcement_check)
            logger.info(f"距离下次公告检查还有{time_to_next:.0f}秒")
            return 0
            
        try:
            results = self.announcement_monitor.check_announcements()
            self.last_announcement_check = current_time
            
            for announcement in results["new_announcements"]:
                self.telegram_notifier.notify_announcement(announcement)
                
            for listing in results["new_listings"]:
                self.telegram_notifier.notify_new_listing(listing)
                
            return len(results["new_announcements"]) + len(results["new_listings"])
        except Exception as e:
            logger.error(f"公告检查失败: {e}")
            return 0
            
    def check_telegram_accounts(self):
        """定期检查Telegram账号状态"""
        try:
            active_count = self.telegram_notifier.check_accounts_status()
            logger.info(f"Telegram账号状态检查完成，{active_count}个账号活跃")
            
            if active_count == 0:
                logger.warning("没有活跃的Telegram账号，通知功能将不可用")
                
            return active_count
        except Exception as e:
            logger.error(f"Telegram账号状态检查失败: {e}")
            return 0
            
    def run_once(self):
        """执行一次完整检查"""
        price_alerts = self.check_prices()
        announcement_alerts = self.check_announcements()
            
        return price_alerts + announcement_alerts
        
    def run_continuous(self):
        """持续运行监控"""
        self.running = True
        
        # 发送启动通知到所有账号
        self.telegram_notifier.send_message(
            "🤖 加密货币监控已启动\n\n" +
            f"监控币种: {', '.join(self.config['price_monitor']['symbols'])}\n" +
            f"监控交易所: 币安, Gate",
            message_type="system",
            accounts="all"
        )
        
        try:
            # 初始检查Telegram账号状态
            self.check_telegram_accounts()
            
            last_account_check = time.time()
            account_check_interval = 3600  # 每小时检查一次账号状态
            
            while self.running:
                start_time = time.time()
                
                # 运行一次检查
                self.run_once()
                
                # 定期检查Telegram账号状态
                current_time = time.time()
                if current_time - last_account_check > account_check_interval:
                    self.check_telegram_accounts()
                    last_account_check = current_time
                
                # 计算等待时间
                elapsed = time.time() - start_time
                wait_time = max(1, self.api_manager.current_interval - elapsed)
                
                logger.info(f"等待{wait_time:.1f}秒后进行下一次检查")
                time.sleep(wait_time)
                
        except KeyboardInterrupt:
            self.running = False
            self.telegram_notifier.send_message("🛑 加密货币监控已停止", message_type="system")
        except Exception as e:
            logger.error(f"运行时错误: {e}")
            self.telegram_notifier.send_message(f"❌ 监控系统错误: {str(e)}", message_type="system")
            self.running = False
            
    def stop(self):
        """停止监控"""
        self.running = False
```

#### 主程序配置示例
```python
{
    "api_polling": {
        "base_interval": 60,
        "min_interval": 10,
        "max_interval": 300,
        "binance_min_interval": 3,
        "gate_min_interval": 5,
        "use_websocket": true,
        "batch_requests": true
    },
    "price_monitor": {
        "symbols": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT"],
        "thresholds": {
            "change_5m": 3.0,
            "change_15m": 5.0,
            "change_1h": 7.0,
            "change_24h": 15.0
        },
        "use_websocket": true,
        "batch_requests": true
    },
    "announcement_monitor": {
        "history_file": "data/announcement_history.json",
        "check_interval": 3600,
        "keywords": {
            "listing": ["listing", "新币上线", "will list"],
            "important": ["update", "upgrade", "maintenance"]
        }
    },
    "telegram": {
        "accounts": [
            {
                "name": "main",
                "token": "YOUR_MAIN_BOT_TOKEN",
                "chat_id": "YOUR_MAIN_CHAT_ID",
                "priority": 10
            },
            {
                "name": "backup",
                "token": "YOUR_BACKUP_BOT_TOKEN",
                "chat_id": "YOUR_BACKUP_CHAT_ID",
                "priority": 5
            }
        ],
        "default_account": "main",
        "message_routing": {
            "price_alert": "main",
            "announcement": "main",
            "new_listing": "main",
            "system": "backup"
        },
        "min_alert_interval": 300
    },
    "log_file": "logs/crypto_monitor.log",
    "log_level": "INFO"
}
```

## 定时任务替代方案

由于系统不支持定时任务，以下是几种替代方案：

### 方案A: 云服务器部署
- 在自己的云服务器上部署脚本
- 使用Linux的crontab设置定时任务
- 优点: 完全自主控制，稳定可靠
- 缺点: 需要自行维护服务器

```bash
# crontab示例
# 每5分钟检查价格
*/5 * * * * python /path/to/price_monitor.py

# 每小时检查公告
0 * * * * python /path/to/announcement_monitor.py
```

### 方案B: 云函数/无服务器部署
- 使用AWS Lambda、Google Cloud Functions等云函数服务
- 设置触发器定时执行
- 优点: 无需维护服务器，按使用付费
- 缺点: 有执行时间限制，配置相对复杂

### 方案C: 持续运行的轻量级服务
- 使用循环+sleep实现定时检查
- 部署在低成本VPS上
- 优点: 实现简单，灵活控制
- 缺点: 需要确保进程持续运行

```python
# 持续运行示例
def main():
    monitor = CryptoMonitor("config.json")
    monitor.run_continuous()

if __name__ == "__main__":
    main()
```

## 安全性与可靠性建议

### API密钥管理
- 使用只读API密钥，不需要交易权限
- 使用环境变量或配置文件存储密钥，避免硬编码
- 定期轮换API密钥

### 错误处理
- 实现完善的异常处理机制
- 添加重试机制，应对网络波动
- 设置监控失败通知，确保系统正常运行

### 数据存储
- 使用数据库或文件存储历史数据
- 定期备份配置和历史记录
- 实现数据清理机制，避免数据过度累积

## 扩展性建议

### 支持更多交易所
- 使用ccxt库可轻松扩展支持其他交易所
- 设计模块化结构，便于添加新交易所

### 更多监控指标
- 交易量异常监控
- 买卖盘深度变化监控
- 资金流向监控
- 社交媒体情绪分析

## 实施路线图

### 第一阶段: 基础功能
1. 实现智能API轮询机制
2. 实现币安和Gate价格监控
3. 实现币安公告监控
4. 实现Telegram多账号推送

### 第二阶段: 功能完善
1. 优化监控算法，减少误报
2. 完善公告过滤机制
3. 增强Telegram交互功能
4. 优化API轮询策略

### 第三阶段: 扩展功能
1. 添加更多交易所支持
2. 实现更多监控指标
3. 添加数据可视化功能
4. 实现高级消息路由策略

## 总结

本方案提供了一个完整的加密货币交易所监控系统设计，专注于价格监控、公告监控和Telegram多账号推送功能。通过智能API轮询和多账号支持，系统具有更高的可靠性和灵活性。

由于系统不支持定时任务，建议采用云服务器部署或云函数方案实现定时监控。根据您的具体需求和技术环境，可以选择最适合的部署方式。

如需进一步定制或有任何疑问，请随时告知。
