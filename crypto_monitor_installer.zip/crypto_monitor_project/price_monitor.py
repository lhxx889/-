# 价格监控模块
# price_monitor.py

import logging
import time
import threading
import json
from datetime import datetime
import traceback

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("price_monitor")

class PriceMonitor:
    """价格监控模块，负责监控交易所的价格变动"""
    
    def __init__(self, config_manager):
        """初始化价格监控模块
        
        Args:
            config_manager: ConfigManager实例
        """
        self.config_manager = config_manager
        self.config = config_manager.get_config()
        self.running = False
        self.thread = None
        self.last_check_time = 0
        self.monitored_symbols = {}  # 用户ID -> 监控的币种列表
        self.symbol_data = {}  # 币种 -> 价格数据
        self.alerts = {}  # 用户ID -> 自定义预警列表
        
        # 初始化交易所API
        self._init_exchanges()
    
    def _init_exchanges(self):
        """初始化交易所API"""
        try:
            # 这里是示例代码，实际实现需要根据具体的交易所API库
            self.exchanges = {}
            exchanges_config = self.config.get("exchanges", {})
            
            # 初始化币安API
            if exchanges_config.get("binance", {}).get("enabled", False):
                try:
                    from binance.client import Client
                    api_key = self.config_manager.get_sensitive_value("exchanges", "binance.api_key")
                    api_secret = self.config_manager.get_sensitive_value("exchanges", "binance.api_secret")
                    if api_key and api_secret:
                        self.exchanges["binance"] = Client(api_key, api_secret)
                        logger.info("币安API初始化成功")
                    else:
                        logger.warning("币安API密钥未配置")
                except ImportError:
                    logger.error("未找到币安API库，请安装: pip install python-binance")
                except Exception as e:
                    logger.error(f"初始化币安API失败: {e}")
            
            # 初始化Gate API
            if exchanges_config.get("gate", {}).get("enabled", False):
                try:
                    import ccxt
                    api_key = self.config_manager.get_sensitive_value("exchanges", "gate.api_key")
                    api_secret = self.config_manager.get_sensitive_value("exchanges", "gate.api_secret")
                    if api_key and api_secret:
                        self.exchanges["gate"] = ccxt.gateio({
                            'apiKey': api_key,
                            'secret': api_secret,
                        })
                        logger.info("Gate API初始化成功")
                    else:
                        logger.warning("Gate API密钥未配置")
                except ImportError:
                    logger.error("未找到CCXT库，请安装: pip install ccxt")
                except Exception as e:
                    logger.error(f"初始化Gate API失败: {e}")
            
            if not self.exchanges:
                logger.warning("未初始化任何交易所API，将使用模拟数据")
                # 使用模拟交易所
                self.exchanges["mock"] = MockExchange()
        except Exception as e:
            logger.error(f"初始化交易所API失败: {e}")
            # 使用模拟交易所作为后备
            self.exchanges["mock"] = MockExchange()
    
    def start(self):
        """启动价格监控"""
        if self.running:
            logger.warning("价格监控已在运行中")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop)
        self.thread.daemon = True
        self.thread.start()
        logger.info("价格监控已启动")
    
    def stop(self):
        """停止价格监控"""
        if not self.running:
            return
        
        self.running = False
        if self.thread:
            self.thread.join(timeout=5.0)
        logger.info("价格监控已停止")
    
    def _monitor_loop(self):
        """监控循环"""
        while self.running:
            try:
                # 获取监控间隔
                interval = self.config.get("monitoring", {}).get("price_check_interval", 60)
                
                # 检查价格
                self._check_prices()
                
                # 更新最后检查时间
                self.last_check_time = time.time()
                
                # 等待下一次检查
                time.sleep(interval)
            except Exception as e:
                logger.error(f"价格监控异常: {e}")
                logger.error(traceback.format_exc())
                time.sleep(10)  # 出错后等待一段时间再重试
    
    def _check_prices(self):
        """检查价格变动"""
        # 获取所有监控的币种
        all_symbols = set()
        for symbols in self.monitored_symbols.values():
            all_symbols.update(symbols)
        
        if not all_symbols:
            return
        
        # 获取价格数据
        for symbol in all_symbols:
            try:
                price_data = self._fetch_price(symbol)
                if price_data:
                    # 更新价格数据
                    self.symbol_data[symbol] = price_data
                    
                    # 检查价格变动
                    self._check_price_changes(symbol, price_data)
                    
                    # 检查自定义预警
                    self._check_custom_alerts(symbol, price_data)
            except Exception as e:
                logger.error(f"检查{symbol}价格失败: {e}")
    
    def _fetch_price(self, symbol):
        """获取币种价格
        
        Args:
            symbol: 币种符号，如 BTC/USDT
        
        Returns:
            dict: 价格数据
        """
        price_data = {}
        
        for exchange_name, exchange in self.exchanges.items():
            try:
                # 这里是示例代码，实际实现需要根据具体的交易所API
                if exchange_name == "binance":
                    # 币安API
                    symbol_binance = symbol.replace("/", "")
                    ticker = exchange.get_ticker(symbol=symbol_binance)
                    price = float(ticker["lastPrice"])
                    change_24h = float(ticker["priceChangePercent"])
                    volume_24h = float(ticker["volume"]) * price
                elif exchange_name == "gate":
                    # Gate API
                    ticker = exchange.fetch_ticker(symbol)
                    price = ticker["last"]
                    change_24h = ticker["percentage"]
                    volume_24h = ticker["quoteVolume"]
                elif exchange_name == "mock":
                    # 模拟交易所
                    ticker = exchange.get_ticker(symbol)
                    price = ticker["price"]
                    change_24h = ticker["change_24h"]
                    volume_24h = ticker["volume_24h"]
                else:
                    continue
                
                price_data[exchange_name] = {
                    "price": price,
                    "change_24h": change_24h,
                    "volume_24h": volume_24h,
                    "timestamp": time.time()
                }
            except Exception as e:
                logger.error(f"从{exchange_name}获取{symbol}价格失败: {e}")
        
        return price_data
    
    def _check_price_changes(self, symbol, price_data):
        """检查价格变动
        
        Args:
            symbol: 币种符号
            price_data: 价格数据
        """
        # 获取阈值配置
        thresholds = self.config.get("thresholds", {}).get("price", {})
        
        # 检查每个交易所的价格变动
        for exchange_name, data in price_data.items():
            change_24h = data.get("change_24h", 0)
            
            # 检查24小时变动
            threshold_24h = thresholds.get("24h", 15.0)
            if abs(change_24h) >= threshold_24h:
                # 触发预警
                self._trigger_alert(symbol, exchange_name, "24h", change_24h, data)
    
    def _check_custom_alerts(self, symbol, price_data):
        """检查自定义预警
        
        Args:
            symbol: 币种符号
            price_data: 价格数据
        """
        for user_id, alerts in self.alerts.items():
            for alert in alerts:
                if alert["symbol"] == symbol:
                    exchange = alert.get("exchange", "binance")
                    if exchange in price_data:
                        price = price_data[exchange].get("price", 0)
                        condition = alert["condition"]
                        value = alert["value"]
                        
                        # 检查条件
                        triggered = False
                        if condition == ">" and price > value:
                            triggered = True
                        elif condition == "<" and price < value:
                            triggered = True
                        elif condition == ">=" and price >= value:
                            triggered = True
                        elif condition == "<=" and price <= value:
                            triggered = True
                        
                        if triggered:
                            # 触发自定义预警
                            self._trigger_custom_alert(user_id, alert, price)
    
    def _trigger_alert(self, symbol, exchange, period, change, data):
        """触发预警
        
        Args:
            symbol: 币种符号
            exchange: 交易所名称
            period: 时间周期
            change: 变动百分比
            data: 价格数据
        """
        # 这里应该将预警发送到Telegram
        # 在实际实现中，应该调用Telegram机器人发送消息
        logger.info(f"预警: {symbol} 在 {exchange} 的 {period} 变动达到 {change:.2f}%")
        
        # 示例：打印预警信息
        direction = "上涨" if change > 0 else "下跌"
        price = data.get("price", 0)
        message = f"🚨 价格预警: {symbol} 价格 {direction} {abs(change):.2f}%\n"
        message += f"当前价格: {price}\n"
        message += f"交易所: {exchange.capitalize()}"
        
        logger.info(message)
    
    def _trigger_custom_alert(self, user_id, alert, price):
        """触发自定义预警
        
        Args:
            user_id: 用户ID
            alert: 预警配置
            price: 当前价格
        """
        # 这里应该将预警发送到Telegram
        # 在实际实现中，应该调用Telegram机器人发送消息
        symbol = alert["symbol"]
        condition = alert["condition"]
        value = alert["value"]
        
        logger.info(f"自定义预警: {symbol} {condition} {value} 已触发，当前价格: {price}")
        
        # 示例：打印预警信息
        message = f"🔔 自定义预警触发: {symbol}\n"
        message += f"条件: 价格 {condition} {value}\n"
        message += f"当前价格: {price}"
        
        logger.info(message)
        
        # 移除已触发的预警
        self.remove_custom_alert(alert["id"], user_id)
    
    def get_monitored_symbols(self, user_id):
        """获取用户监控的币种列表
        
        Args:
            user_id: 用户ID
        
        Returns:
            list: 币种列表
        """
        return self.monitored_symbols.get(user_id, [])
    
    def add_symbol_to_watchlist(self, symbol, user_id):
        """添加币种到监控列表
        
        Args:
            symbol: 币种符号
            user_id: 用户ID
        
        Returns:
            bool: 是否成功
        """
        if user_id not in self.monitored_symbols:
            self.monitored_symbols[user_id] = []
        
        if symbol not in self.monitored_symbols[user_id]:
            self.monitored_symbols[user_id].append(symbol)
            return True
        
        return False
    
    def remove_symbol_from_watchlist(self, symbol, user_id):
        """从监控列表移除币种
        
        Args:
            symbol: 币种符号
            user_id: 用户ID
        
        Returns:
            bool: 是否成功
        """
        if user_id in self.monitored_symbols and symbol in self.monitored_symbols[user_id]:
            self.monitored_symbols[user_id].remove(symbol)
            return True
        
        return False
    
    def get_user_watchlist(self, user_id):
        """获取用户监控列表
        
        Args:
            user_id: 用户ID
        
        Returns:
            list: 币种列表
        """
        return self.monitored_symbols.get(user_id, [])
    
    def get_active_alerts_count(self, user_id):
        """获取用户活跃预警数量
        
        Args:
            user_id: 用户ID
        
        Returns:
            int: 预警数量
        """
        return len(self.alerts.get(user_id, []))
    
    def get_last_check_time(self):
        """获取最后检查时间
        
        Returns:
            float: 时间戳
        """
        return self.last_check_time
    
    def fetch_specific_price(self, symbol, exchange=None):
        """获取特定币种的价格
        
        Args:
            symbol: 币种符号
            exchange: 交易所名称，如果为None则获取所有交易所
        
        Returns:
            dict: 价格数据
        """
        try:
            if symbol in self.symbol_data and time.time() - self.last_check_time < 60:
                # 使用缓存数据
                price_data = self.symbol_data[symbol]
                if exchange:
                    return {exchange: price_data.get(exchange, {})}
                return price_data
            
            # 重新获取价格
            price_data = self._fetch_price(symbol)
            if price_data:
                self.symbol_data[symbol] = price_data
                if exchange:
                    return {exchange: price_data.get(exchange, {})}
                return price_data
            
            return {}
        except Exception as e:
            logger.error(f"获取{symbol}价格失败: {e}")
            return {}
    
    def fetch_historical_data(self, symbol, timeframe="1d", limit=None):
        """获取历史数据
        
        Args:
            symbol: 币种符号
            timeframe: 时间周期
            limit: 数量限制
        
        Returns:
            list: 历史数据
        """
        try:
            # 这里是示例代码，实际实现需要根据具体的交易所API
            for exchange_name, exchange in self.exchanges.items():
                try:
                    if exchange_name == "binance":
                        # 币安API
                        symbol_binance = symbol.replace("/", "")
                        klines = exchange.get_klines(
                            symbol=symbol_binance,
                            interval=timeframe,
                            limit=limit or 100
                        )
                        return [[
                            int(k[0]),  # 开盘时间
                            float(k[1]),  # 开盘价
                            float(k[2]),  # 最高价
                            float(k[3]),  # 最低价
                            float(k[4]),  # 收盘价
                            float(k[5])   # 交易量
                        ] for k in klines]
                    elif exchange_name == "gate":
                        # Gate API
                        ohlcv = exchange.fetch_ohlcv(
                            symbol,
                            timeframe,
                            limit=limit
                        )
                        return ohlcv
                    elif exchange_name == "mock":
                        # 模拟交易所
                        return exchange.get_historical_data(symbol, timeframe, limit)
                except Exception as e:
                    logger.error(f"从{exchange_name}获取{symbol}历史数据失败: {e}")
                    continue
            
            return []
        except Exception as e:
            logger.error(f"获取{symbol}历史数据失败: {e}")
            return []
    
    def get_top_gainers(self, limit=5):
        """获取涨幅最高的币种
        
        Args:
            limit: 数量限制
        
        Returns:
            list: 币种列表
        """
        try:
            # 收集所有币种的涨跌幅
            gainers = []
            for symbol, data in self.symbol_data.items():
                for exchange, price_data in data.items():
                    change = price_data.get("change_24h", 0)
                    if change > 0:
                        gainers.append({
                            "symbol": symbol,
                            "exchange": exchange,
                            "change": change,
                            "price": price_data.get("price", 0)
                        })
            
            # 按涨幅排序
            gainers.sort(key=lambda x: x["change"], reverse=True)
            
            return gainers[:limit]
        except Exception as e:
            logger.error(f"获取涨幅最高币种失败: {e}")
            return []
    
    def get_top_losers(self, limit=5):
        """获取跌幅最大的币种
        
        Args:
            limit: 数量限制
        
        Returns:
            list: 币种列表
        """
        try:
            # 收集所有币种的涨跌幅
            losers = []
            for symbol, data in self.symbol_data.items():
                for exchange, price_data in data.items():
                    change = price_data.get("change_24h", 0)
                    if change < 0:
                        losers.append({
                            "symbol": symbol,
                            "exchange": exchange,
                            "change": change,
                            "price": price_data.get("price", 0)
                        })
            
            # 按跌幅排序
            losers.sort(key=lambda x: x["change"])
            
            return losers[:limit]
        except Exception as e:
            logger.error(f"获取跌幅最大币种失败: {e}")
            return []
    
    def get_symbol_data(self, symbol):
        """获取币种数据
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 币种数据
        """
        # 如果有缓存数据，使用第一个交易所的数据
        if symbol in self.symbol_data:
            for exchange, data in self.symbol_data[symbol].items():
                return data
        
        # 否则重新获取
        price_data = self.fetch_specific_price(symbol)
        if price_data:
            for exchange, data in price_data.items():
                return data
        
        return None
    
    def add_custom_alert(self, symbol, condition, value, user_id):
        """添加自定义预警
        
        Args:
            symbol: 币种符号
            condition: 条件
            value: 值
            user_id: 用户ID
        
        Returns:
            str: 预警ID
        """
        if user_id not in self.alerts:
            self.alerts[user_id] = []
        
        alert_id = f"alert_{int(time.time())}_{len(self.alerts[user_id])}"
        
        self.alerts[user_id].append({
            "id": alert_id,
            "symbol": symbol,
            "condition": condition,
            "value": value,
            "created_at": time.time()
        })
        
        return alert_id
    
    def remove_custom_alert(self, alert_id, user_id):
        """移除自定义预警
        
        Args:
            alert_id: 预警ID
            user_id: 用户ID
        
        Returns:
            bool: 是否成功
        """
        if user_id in self.alerts:
            for i, alert in enumerate(self.alerts[user_id]):
                if alert["id"] == alert_id:
                    self.alerts[user_id].pop(i)
                    return True
        
        return False
    
    def get_volume_data(self, symbol, exchange=None):
        """获取交易量数据
        
        Args:
            symbol: 币种符号
            exchange: 交易所名称
        
        Returns:
            dict: 交易量数据
        """
        try:
            price_data = self.fetch_specific_price(symbol, exchange)
            
            result = {}
            for ex, data in price_data.items():
                volume_24h = data.get("volume_24h", 0)
                
                # 这里是示例代码，实际实现需要根据具体的交易所API
                # 获取买卖交易量比例
                buy_volume = volume_24h * 0.55  # 示例数据
                sell_volume = volume_24h * 0.45  # 示例数据
                
                result[ex] = {
                    "volume_24h": volume_24h,
                    "volume_change_24h": 5.0,  # 示例数据
                    "buy_volume_24h": buy_volume,
                    "sell_volume_24h": sell_volume
                }
            
            return result
        except Exception as e:
            logger.error(f"获取{symbol}交易量数据失败: {e}")
            return {}


class MockExchange:
    """模拟交易所，用于测试和演示"""
    
    def __init__(self):
        """初始化模拟交易所"""
        self.tickers = {
            "BTC/USDT": {
                "price": 50000.0,
                "change_24h": 2.5,
                "volume_24h": 1000000000.0
            },
            "ETH/USDT": {
                "price": 3000.0,
                "change_24h": 1.8,
                "volume_24h": 500000000.0
            },
            "BNB/USDT": {
                "price": 400.0,
                "change_24h": -0.5,
                "volume_24h": 200000000.0
            },
            "SOL/USDT": {
                "price": 100.0,
                "change_24h": 5.0,
                "volume_24h": 150000000.0
            },
            "ADA/USDT": {
                "price": 0.5,
                "change_24h": -2.0,
                "volume_24h": 100000000.0
            }
        }
    
    def get_ticker(self, symbol):
        """获取币种行情
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 行情数据
        """
        if symbol in self.tickers:
            return self.tickers[symbol]
        
        # 生成随机数据
        import random
        return {
            "price": random.uniform(0.1, 1000.0),
            "change_24h": random.uniform(-10.0, 10.0),
            "volume_24h": random.uniform(1000000.0, 1000000000.0)
        }
    
    def get_historical_data(self, symbol, timeframe="1d", limit=100):
        """获取历史数据
        
        Args:
            symbol: 币种符号
            timeframe: 时间周期
            limit: 数量限制
        
        Returns:
            list: 历史数据
        """
        import random
        
        # 获取基础价格
        ticker = self.get_ticker(symbol)
        base_price = ticker["price"]
        
        # 生成历史数据
        now = int(time.time() * 1000)
        interval = 86400000  # 1天的毫秒数
        if timeframe == "1h":
            interval = 3600000
        elif timeframe == "1w":
            interval = 604800000
        
        data = []
        for i in range(limit or 100):
            timestamp = now - (limit - i - 1) * interval
            open_price = base_price * (1 + random.uniform(-0.1, 0.1))
            close_price = base_price * (1 + random.uniform(-0.1, 0.1))
            high_price = max(open_price, close_price) * (1 + random.uniform(0, 0.05))
            low_price = min(open_price, close_price) * (1 - random.uniform(0, 0.05))
            volume = ticker["volume_24h"] * random.uniform(0.5, 1.5)
            
            data.append([
                timestamp,
                open_price,
                high_price,
                low_price,
                close_price,
                volume
            ])
        
        return data
