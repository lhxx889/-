# Telegram多账号推送模块设计

## 功能概述

根据您的需求，我们设计了一个支持多账号的Telegram推送模块，主要功能包括：

1. 支持配置多个Telegram Bot和接收账号
2. 灵活的消息分发策略，可按消息类型路由到不同账号
3. 账号状态监控和自动切换机制
4. 消息格式化和发送控制

## 模块设计

### 多账号Telegram推送模块

```python
# Telegram多账号推送模块伪代码
class MultiAccountTelegramNotifier:
    def __init__(self, config):
        self.config = config
        self.accounts = self._setup_accounts(config.get("accounts", []))
        self.default_account = config.get("default_account", "main")
        self.message_routing = config.get("message_routing", {})
        self.last_notification_time = {}
        self.account_status = {}
        
    def _setup_accounts(self, accounts_config):
        """设置多个Telegram账号"""
        accounts = {}
        
        for account in accounts_config:
            name = account.get("name", "unnamed")
            token = account.get("token", "")
            chat_id = account.get("chat_id", "")
            
            if token and chat_id:
                try:
                    bot = telegram.Bot(token=token)
                    accounts[name] = {
                        "bot": bot,
                        "chat_id": chat_id,
                        "token": token,
                        "priority": account.get("priority", 0)
                    }
                    self.account_status[name] = {
                        "active": True,
                        "last_check": time.time(),
                        "error_count": 0
                    }
                    logger.info(f"Telegram账号 {name} 设置成功")
                except Exception as e:
                    logger.error(f"Telegram账号 {name} 设置失败: {e}")
                    
        return accounts
        
    def get_account_for_message(self, message_type):
        """根据消息类型获取应使用的账号"""
        # 检查消息路由配置
        if message_type in self.message_routing:
            account_name = self.message_routing[message_type]
            if account_name in self.accounts:
                if self.account_status[account_name]["active"]:
                    return account_name
                else:
                    logger.warning(f"账号 {account_name} 不活跃，使用默认账号")
                    
        # 使用默认账号
        if self.default_account in self.accounts and self.account_status[self.default_account]["active"]:
            return self.default_account
            
        # 如果默认账号不可用，使用优先级最高的活跃账号
        active_accounts = [(name, data["priority"]) 
                          for name, data in self.accounts.items() 
                          if self.account_status[name]["active"]]
        
        if active_accounts:
            # 按优先级排序，选择最高优先级
            active_accounts.sort(key=lambda x: x[1], reverse=True)
            return active_accounts[0][0]
            
        # 如果没有活跃账号，尝试使用任何可用账号
        if self.accounts:
            return list(self.accounts.keys())[0]
            
        logger.error("没有可用的Telegram账号")
        return None
        
    def send_message(self, message, message_type="general", parse_mode="Markdown", accounts=None):
        """发送消息到Telegram"""
        if not self.accounts:
            logger.error("没有配置Telegram账号")
            return False
            
        # 确定要发送到哪些账号
        target_accounts = []
        
        if accounts == "all":
            # 发送到所有账号
            target_accounts = list(self.accounts.keys())
        elif accounts and isinstance(accounts, list):
            # 发送到指定账号列表
            target_accounts = [acc for acc in accounts if acc in self.accounts]
        else:
            # 根据消息类型选择账号
            account = self.get_account_for_message(message_type)
            if account:
                target_accounts = [account]
                
        if not target_accounts:
            logger.error("没有目标账号可发送消息")
            return False
            
        # 发送消息到所有目标账号
        success = False
        for account_name in target_accounts:
            try:
                account = self.accounts[account_name]
                account["bot"].send_message(
                    chat_id=account["chat_id"],
                    text=message,
                    parse_mode=parse_mode
                )
                
                # 更新账号状态
                self.account_status[account_name]["active"] = True
                self.account_status[account_name]["last_check"] = time.time()
                self.account_status[account_name]["error_count"] = 0
                
                success = True
                logger.info(f"消息已发送到账号 {account_name}")
            except Exception as e:
                # 更新账号状态
                self.account_status[account_name]["error_count"] += 1
                if self.account_status[account_name]["error_count"] >= 3:
                    self.account_status[account_name]["active"] = False
                    
                logger.error(f"发送消息到账号 {account_name} 失败: {e}")
                
        return success
        
    def check_accounts_status(self):
        """检查所有账号状态"""
        for name, account in self.accounts.items():
            try:
                # 发送测试消息或获取bot信息
                bot_info = account["bot"].get_me()
                
                # 更新账号状态
                self.account_status[name]["active"] = True
                self.account_status[name]["last_check"] = time.time()
                self.account_status[name]["error_count"] = 0
                
                logger.info(f"账号 {name} 状态正常: {bot_info.first_name}")
            except Exception as e:
                self.account_status[name]["error_count"] += 1
                if self.account_status[name]["error_count"] >= 3:
                    self.account_status[name]["active"] = False
                    
                logger.error(f"账号 {name} 状态检查失败: {e}")
                
        # 返回活跃账号数量
        active_count = sum(1 for status in self.account_status.values() if status["active"])
        return active_count
        
    def format_price_alert(self, alert):
        """格式化价格预警消息"""
        exchange = alert["exchange"].capitalize()
        symbol = alert["symbol"]
        price = alert["price"]
        change = alert["change"]
        
        if change > 0:
            direction = "上涨"
            emoji = "🚀"
        else:
            direction = "下跌"
            emoji = "📉"
            
        message = f"{emoji} *价格预警* {emoji}\n\n"
        message += f"交易所: `{exchange}`\n"
        message += f"币种: `{symbol}`\n"
        message += f"{direction}: `{abs(change)}%`\n"
        message += f"当前价格: `{price}`"
        
        return message
        
    def format_announcement(self, announcement):
        """格式化公告消息"""
        title = announcement["title"]
        url = announcement.get("url", "")
        date = announcement.get("date", "")
        exchange = announcement.get("exchange", "").capitalize()
        
        message = f"📢 *{exchange}最新公告* 📢\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def format_new_listing(self, listing):
        """格式化新上币公告消息"""
        title = listing["title"]
        url = listing.get("url", "")
        date = listing.get("date", "")
        exchange = listing.get("exchange", "").capitalize()
        
        message = f"🔥 *{exchange}新币上线* 🔥\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def notify_price_alert(self, alert):
        """发送价格预警通知"""
        # 检查是否需要限流
        symbol = alert["symbol"]
        alert_type = alert["type"]
        key = f"{symbol}_{alert_type}"
        
        current_time = time.time()
        if key in self.last_notification_time:
            time_diff = current_time - self.last_notification_time[key]
            min_interval = self.config.get("min_alert_interval", 300)  # 默认5分钟
            
            if time_diff < min_interval:
                logger.info(f"跳过{symbol}的{alert_type}预警，距离上次通知仅{time_diff}秒")
                return False
                
        message = self.format_price_alert(alert)
        
        # 根据预警类型确定发送账号
        if alert_type == "24h_change" and abs(alert["change"]) > 20:
            # 大幅波动，发送到所有账号
            result = self.send_message(message, message_type="major_price_alert", accounts="all")
        else:
            # 普通波动，使用默认路由
            result = self.send_message(message, message_type="price_alert")
            
        if result:
            self.last_notification_time[key] = current_time
            
        return result
        
    def notify_announcement(self, announcement):
        """发送公告通知"""
        message = self.format_announcement(announcement)
        return self.send_message(message, message_type="announcement")
        
    def notify_new_listing(self, listing):
        """发送新上币通知"""
        message = self.format_new_listing(listing)
        # 新上币是高优先级消息，发送到所有账号
        return self.send_message(message, message_type="new_listing", accounts="all")
        
    def send_system_message(self, message, level="info"):
        """发送系统消息"""
        if level == "error":
            emoji = "❌"
            message_type = "system_error"
        elif level == "warning":
            emoji = "⚠️"
            message_type = "system_warning"
        else:
            emoji = "ℹ️"
            message_type = "system_info"
            
        formatted_message = f"{emoji} *系统消息* {emoji}\n\n{message}"
        
        # 系统错误消息发送到所有账号
        if level == "error":
            return self.send_message(formatted_message, message_type=message_type, accounts="all")
        else:
            return self.send_message(formatted_message, message_type=message_type)
```

## 配置示例

```python
telegram_config = {
    "accounts": [
        {
            "name": "main",
            "token": "YOUR_MAIN_BOT_TOKEN",
            "chat_id": "YOUR_MAIN_CHAT_ID",
            "priority": 10
        },
        {
            "name": "backup",
            "token": "YOUR_BACKUP_BOT_TOKEN",
            "chat_id": "YOUR_BACKUP_CHAT_ID",
            "priority": 5
        },
        {
            "name": "alerts",
            "token": "YOUR_ALERTS_BOT_TOKEN",
            "chat_id": "YOUR_ALERTS_CHAT_ID",
            "priority": 8
        }
    ],
    "default_account": "main",
    "message_routing": {
        "price_alert": "alerts",
        "major_price_alert": "main",
        "announcement": "main",
        "new_listing": "main",
        "system_info": "backup",
        "system_warning": "backup",
        "system_error": "main"
    },
    "min_alert_interval": 300,  # 同一币种同类型预警的最小间隔（秒）
    "max_daily_alerts": 20      # 每日最大预警次数
}
```

## 实现细节与注意事项

### 1. 账号管理与状态监控

多账号推送模块需要有效管理多个Telegram Bot账号，并监控它们的状态：

- **账号初始化**：在启动时初始化所有配置的Telegram Bot
- **状态检查**：定期检查每个账号的连接状态
- **错误计数**：记录每个账号的错误次数，连续失败超过阈值则标记为不活跃
- **自动切换**：当首选账号不可用时，自动切换到备用账号

### 2. 消息路由策略

根据消息类型将通知发送到不同的账号：

- **类型路由**：根据消息类型（如价格预警、公告、系统消息等）选择目标账号
- **优先级路由**：当指定账号不可用时，按优先级选择备用账号
- **广播消息**：重要消息（如新上币公告、系统错误）发送到所有账号
- **自定义路由**：允许通过配置文件自定义消息路由规则

### 3. 消息限流与控制

为避免消息轰炸，实现了消息限流机制：

- **时间间隔控制**：同一类型的消息在指定时间内只发送一次
- **每日限额**：设置每日最大预警次数，避免异常情况下发送过多消息
- **优先级排序**：当消息过多时，优先发送重要消息

### 4. 消息格式化

为不同类型的消息设计了统一的格式化方法：

- **价格预警格式**：包含交易所、币种、涨跌幅、当前价格等信息
- **公告消息格式**：包含交易所、标题、发布时间、详情链接等
- **系统消息格式**：包含消息级别、内容等
- **Markdown支持**：使用Markdown格式美化消息，提高可读性

## 与其他模块的集成

### 1. 与价格监控模块集成

```python
# 价格监控与推送集成伪代码
def check_prices(self):
    """检查价格并发送预警"""
    try:
        prices = self.price_monitor.fetch_prices()
        if not prices:
            logger.info("没有获取到价格数据")
            return 0
            
        # 计算市场波动性，用于调整轮询间隔
        market_volatility = self.price_monitor.calculate_market_volatility(prices)
        next_interval = self.api_manager.calculate_adaptive_interval(market_volatility)
        logger.info(f"市场波动性: {market_volatility:.2f}%, 下次轮询间隔: {next_interval}秒")
        
        # 检查价格预警
        alerts = self.price_monitor.check_price_alerts(prices)
        
        alert_count = 0
        for alert in alerts:
            if self.telegram_notifier.notify_price_alert(alert):
                alert_count += 1
                
        return alert_count
    except Exception as e:
        logger.error(f"价格检查失败: {e}")
        self.telegram_notifier.send_system_message(f"价格监控失败: {str(e)}", level="error")
        return 0
```

### 2. 与公告监控模块集成

```python
# 公告监控与推送集成伪代码
def check_announcements(self):
    """检查公告并发送通知"""
    current_time = time.time()
    announcement_interval = self.config["announcement_monitor"].get("check_interval", 3600)
    
    # 检查是否达到公告检查间隔
    if current_time - self.last_announcement_check < announcement_interval:
        time_to_next = announcement_interval - (current_time - self.last_announcement_check)
        logger.info(f"距离下次公告检查还有{time_to_next:.0f}秒")
        return 0
        
    try:
        results = self.announcement_monitor.check_announcements()
        self.last_announcement_check = current_time
        
        notification_count = 0
        
        # 处理币安公告
        for announcement in results["binance"]["new_announcements"]:
            if self.telegram_notifier.notify_announcement(announcement):
                notification_count += 1
                
        for listing in results["binance"]["new_listings"]:
            if self.telegram_notifier.notify_new_listing(listing):
                notification_count += 1
                
        # 处理Gate公告
        for announcement in results["gate"]["new_announcements"]:
            if self.telegram_notifier.notify_announcement(announcement):
                notification_count += 1
                
        for listing in results["gate"]["new_listings"]:
            if self.telegram_notifier.notify_new_listing(listing):
                notification_count += 1
                
        return notification_count
    except Exception as e:
        logger.error(f"公告检查失败: {e}")
        self.telegram_notifier.send_system_message(f"公告监控失败: {str(e)}", level="error")
        return 0
```

## 扩展功能

### 1. 交互式命令支持

除了被动推送消息外，还可以添加交互式命令支持，允许用户通过Telegram发送命令控制监控系统：

```python
def setup_command_handlers(self):
    """设置命令处理器"""
    for account_name, account in self.accounts.items():
        bot = account["bot"]
        dispatcher = Dispatcher(bot, None, workers=0)
        
        # 注册命令处理器
        dispatcher.add_handler(CommandHandler("status", self._handle_status_command))
        dispatcher.add_handler(CommandHandler("price", self._handle_price_command))
        dispatcher.add_handler(CommandHandler("settings", self._handle_settings_command))
        
        # 启动轮询
        self.dispatchers[account_name] = dispatcher
        Thread(target=dispatcher.start_polling).start()
        
def _handle_status_command(self, update, context):
    """处理状态查询命令"""
    chat_id = update.effective_chat.id
    
    # 检查是否是授权用户
    if str(chat_id) not in [account["chat_id"] for account in self.accounts.values()]:
        update.message.reply_text("未授权的访问")
        return
        
    # 生成状态报告
    status_message = self._generate_status_report()
    update.message.reply_text(status_message, parse_mode="Markdown")
    
def _handle_price_command(self, update, context):
    """处理价格查询命令"""
    chat_id = update.effective_chat.id
    
    # 检查是否是授权用户
    if str(chat_id) not in [account["chat_id"] for account in self.accounts.values()]:
        update.message.reply_text("未授权的访问")
        return
        
    # 解析参数
    args = context.args
    if not args:
        update.message.reply_text("请提供币种符号，例如: /price BTC/USDT")
        return
        
    symbol = args[0].upper()
    
    # 获取价格
    try:
        prices = self.price_monitor.fetch_specific_price(symbol)
        if not prices:
            update.message.reply_text(f"未找到{symbol}的价格信息")
            return
            
        # 格式化价格信息
        price_message = self._format_price_info(symbol, prices)
        update.message.reply_text(price_message, parse_mode="Markdown")
    except Exception as e:
        update.message.reply_text(f"获取价格失败: {str(e)}")
```

### 2. 消息分组与摘要

为避免消息过多，可以实现消息分组和摘要功能：

```python
def send_grouped_alerts(self, alerts, group_interval=300):
    """分组发送预警"""
    if not alerts:
        return 0
        
    # 按交易所和类型分组
    grouped_alerts = {}
    for alert in alerts:
        exchange = alert["exchange"]
        alert_type = alert["type"]
        key = f"{exchange}_{alert_type}"
        
        if key not in grouped_alerts:
            grouped_alerts[key] = []
            
        grouped_alerts[key].append(alert)
        
    # 发送分组消息
    sent_count = 0
    for key, group in grouped_alerts.items():
        if len(group) == 1:
            # 单个预警直接发送
            if self.notify_price_alert(group[0]):
                sent_count += 1
        else:
            # 多个预警发送摘要
            message = self.format_alert_summary(group)
            if self.send_message(message, message_type="price_alert_summary"):
                sent_count += 1
                
    return sent_count
    
def format_alert_summary(self, alerts):
    """格式化预警摘要"""
    if not alerts:
        return ""
        
    exchange = alerts[0]["exchange"].capitalize()
    alert_type = alerts[0]["type"]
    
    if alert_type == "24h_change":
        title = f"24小时大幅波动"
    elif alert_type == "5m_change":
        title = f"5分钟快速波动"
    else:
        title = f"{alert_type}波动"
        
    message = f"📊 *{exchange}{title}摘要* 📊\n\n"
    
    # 按涨跌幅排序
    alerts.sort(key=lambda x: abs(x["change"]), reverse=True)
    
    # 添加涨幅币种
    up_alerts = [a for a in alerts if a["change"] > 0]
    if up_alerts:
        message += "*上涨:*\n"
        for alert in up_alerts[:5]:  # 最多显示5个
            message += f"- `{alert['symbol']}`: +{alert['change']:.2f}%\n"
        if len(up_alerts) > 5:
            message += f"- _以及其他{len(up_alerts)-5}个币种_\n"
        message += "\n"
        
    # 添加跌幅币种
    down_alerts = [a for a in alerts if a["change"] < 0]
    if down_alerts:
        message += "*下跌:*\n"
        for alert in down_alerts[:5]:  # 最多显示5个
            message += f"- `{alert['symbol']}`: {alert['change']:.2f}%\n"
        if len(down_alerts) > 5:
            message += f"- _以及其他{len(down_alerts)-5}个币种_\n"
            
    return message
```

### 3. 消息模板系统

实现一个灵活的消息模板系统，允许通过配置文件自定义消息格式：

```python
def load_message_templates(self):
    """加载消息模板"""
    template_file = self.config.get("template_file", "message_templates.json")
    try:
        with open(template_file, "r", encoding="utf-8") as f:
            self.templates = json.load(f)
        logger.info(f"已加载{len(self.templates)}个消息模板")
    except (FileNotFoundError, json.JSONDecodeError):
        logger.warning(f"未找到模板文件或格式错误，使用默认模板")
        self.templates = {
            "price_alert": "{emoji} *价格预警* {emoji}\n\n交易所: `{exchange}`\n币种: `{symbol}`\n{direction}: `{change}%`\n当前价格: `{price}`",
            "announcement": "📢 *{exchange}最新公告* 📢\n\n*{title}*\n\n发布时间: `{date}`\n\n[查看详情]({url})",
            "new_listing": "🔥 *{exchange}新币上线* 🔥\n\n*{title}*\n\n发布时间: `{date}`\n\n[查看详情]({url})"
        }
        
def format_message_with_template(self, template_name, data):
    """使用模板格式化消息"""
    template = self.templates.get(template_name)
    if not template:
        logger.warning(f"未找到模板 {template_name}，使用默认格式")
        return str(data)
        
    try:
        # 处理特殊字段
        if "change" in data and "direction" not in data:
            data["direction"] = "上涨" if data["change"] > 0 else "下跌"
            data["emoji"] = "🚀" if data["change"] > 0 else "📉"
            data["change"] = abs(data["change"])
            
        return template.format(**data)
    except KeyError as e:
        logger.error(f"模板格式化错误，缺少字段: {e}")
        return str(data)
```

## 总结

Telegram多账号推送模块提供了一个灵活、可靠的消息推送解决方案，具有以下优势：

1. **多账号支持**：可配置多个Telegram Bot，提高推送可靠性
2. **智能路由**：根据消息类型和重要性选择合适的推送账号
3. **状态监控**：自动检测账号状态，在账号不可用时切换备用账号
4. **消息控制**：实现消息限流和分组，避免消息轰炸
5. **格式化输出**：为不同类型的消息提供统一、美观的格式

该模块与价格监控和公告监控模块无缝集成，确保所有监控到的信息能够及时、可靠地推送给用户。通过扩展功能，还可以实现交互式命令、消息分组和自定义模板等高级特性。
