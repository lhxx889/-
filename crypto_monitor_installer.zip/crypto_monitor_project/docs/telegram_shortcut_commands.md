# Telegram快捷命令功能设计

## 功能概述

为了提高用户体验和系统可用性，我们设计了一套完整的Telegram快捷命令功能，允许用户通过简单的命令与加密货币监控系统进行交互。这些命令可以帮助用户快速查询价格、设置预警、获取币种信息、管理监控设置等。

## 命令设计

### 基础命令

| 命令 | 描述 | 示例 |
|------|------|------|
| `/start` | 启动机器人，显示欢迎信息和可用命令列表 | `/start` |
| `/help` | 显示帮助信息和命令说明 | `/help` |
| `/status` | 显示系统状态，包括监控币种数量、活跃预警等 | `/status` |

### 价格查询命令

| 命令 | 描述 | 示例 |
|------|------|------|
| `/price <币种>` | 查询指定币种的当前价格 | `/price BTC` |
| `/price <币种> <交易所>` | 查询指定交易所的币种价格 | `/price ETH binance` |
| `/chart <币种> <时间周期>` | 获取币种价格图表 | `/chart BTC 1d` |
| `/top <数量>` | 查询涨幅最高的几个币种 | `/top 5` |
| `/bottom <数量>` | 查询跌幅最大的几个币种 | `/bottom 5` |

### 监控设置命令

| 命令 | 描述 | 示例 |
|------|------|------|
| `/watch <币种>` | 添加币种到监控列表 | `/watch SOL` |
| `/unwatch <币种>` | 从监控列表移除币种 | `/unwatch ADA` |
| `/watchlist` | 显示当前监控的币种列表 | `/watchlist` |
| `/threshold <类型> <值>` | 设置预警阈值 | `/threshold 1h 5` |
| `/pause` | 暂停所有预警通知 | `/pause` |
| `/resume` | 恢复所有预警通知 | `/resume` |

### 币种信息命令

| 命令 | 描述 | 示例 |
|------|------|------|
| `/info <币种>` | 获取币种详细信息 | `/info BTC` |
| `/news <币种>` | 获取币种相关新闻 | `/news ETH` |
| `/social <币种>` | 获取币种社交媒体情绪 | `/social BNB` |
| `/contract <币种>` | 获取币种合约信息 | `/contract USDT` |

### 公告查询命令

| 命令 | 描述 | 示例 |
|------|------|------|
| `/announcements <数量>` | 获取最新公告 | `/announcements 5` |
| `/listings <数量>` | 获取最新上币公告 | `/listings 3` |
| `/exchange <交易所> <数量>` | 获取指定交易所的公告 | `/exchange binance 5` |

### 高级命令

| 命令 | 描述 | 示例 |
|------|------|------|
| `/alert <币种> <条件> <值>` | 设置自定义预警 | `/alert BTC >50000` |
| `/compare <币种1> <币种2>` | 比较两个币种的表现 | `/compare BTC ETH` |
| `/volume <币种> <交易所>` | 查询交易量信息 | `/volume BTC binance` |
| `/settings` | 显示和修改用户设置 | `/settings` |

## 命令实现

### 命令处理器设计

```python
# Telegram命令处理器伪代码
class TelegramCommandHandler:
    def __init__(self, config, price_monitor, announcement_monitor, coin_enricher):
        self.config = config
        self.price_monitor = price_monitor
        self.announcement_monitor = announcement_monitor
        self.coin_enricher = coin_enricher
        self.user_settings = {}
        self.command_handlers = self._setup_command_handlers()
        
    def _setup_command_handlers(self):
        """设置命令处理器映射"""
        return {
            "start": self.handle_start,
            "help": self.handle_help,
            "status": self.handle_status,
            "price": self.handle_price,
            "chart": self.handle_chart,
            "top": self.handle_top,
            "bottom": self.handle_bottom,
            "watch": self.handle_watch,
            "unwatch": self.handle_unwatch,
            "watchlist": self.handle_watchlist,
            "threshold": self.handle_threshold,
            "pause": self.handle_pause,
            "resume": self.handle_resume,
            "info": self.handle_info,
            "news": self.handle_news,
            "social": self.handle_social,
            "contract": self.handle_contract,
            "announcements": self.handle_announcements,
            "listings": self.handle_listings,
            "exchange": self.handle_exchange,
            "alert": self.handle_alert,
            "compare": self.handle_compare,
            "volume": self.handle_volume,
            "settings": self.handle_settings
        }
        
    def process_command(self, command, args, user_id, chat_id):
        """处理命令"""
        if command in self.command_handlers:
            # 检查用户权限
            if not self._check_user_permission(user_id, command):
                return "您没有执行此命令的权限"
                
            # 执行命令处理器
            try:
                return self.command_handlers[command](args, user_id, chat_id)
            except Exception as e:
                logger.error(f"处理命令 {command} 失败: {e}")
                return f"处理命令失败: {str(e)}"
        else:
            return f"未知命令: {command}。使用 /help 查看可用命令。"
            
    def _check_user_permission(self, user_id, command):
        """检查用户是否有权限执行命令"""
        # 获取用户角色
        user_role = self.user_settings.get(user_id, {}).get("role", "user")
        
        # 管理员可以执行所有命令
        if user_role == "admin":
            return True
            
        # 检查命令权限
        command_permissions = self.config.get("command_permissions", {})
        allowed_roles = command_permissions.get(command, ["admin", "user"])
        
        return user_role in allowed_roles
        
    # 基础命令处理器
    
    def handle_start(self, args, user_id, chat_id):
        """处理/start命令"""
        welcome_message = (
            "👋 *欢迎使用加密货币监控机器人*\n\n"
            "我可以帮助您监控币价变动、查询币种信息、获取交易所公告等。\n\n"
            "🔹 使用 /help 查看所有可用命令\n"
            "🔹 使用 /price <币种> 查询当前价格\n"
            "🔹 使用 /watch <币种> 添加监控\n"
            "🔹 使用 /status 查看系统状态\n\n"
            "祝您交易愉快！"
        )
        return welcome_message
        
    def handle_help(self, args, user_id, chat_id):
        """处理/help命令"""
        help_message = "*可用命令列表*\n\n"
        
        # 基础命令
        help_message += "*基础命令:*\n"
        help_message += "/start - 启动机器人\n"
        help_message += "/help - 显示此帮助信息\n"
        help_message += "/status - 显示系统状态\n\n"
        
        # 价格查询命令
        help_message += "*价格查询:*\n"
        help_message += "/price <币种> - 查询币种价格\n"
        help_message += "/chart <币种> <时间周期> - 获取价格图表\n"
        help_message += "/top <数量> - 查询涨幅最高的币种\n"
        help_message += "/bottom <数量> - 查询跌幅最大的币种\n\n"
        
        # 监控设置命令
        help_message += "*监控设置:*\n"
        help_message += "/watch <币种> - 添加币种到监控列表\n"
        help_message += "/unwatch <币种> - 从监控列表移除币种\n"
        help_message += "/watchlist - 显示当前监控的币种列表\n"
        help_message += "/threshold <类型> <值> - 设置预警阈值\n"
        help_message += "/pause - 暂停所有预警通知\n"
        help_message += "/resume - 恢复所有预警通知\n\n"
        
        # 币种信息命令
        help_message += "*币种信息:*\n"
        help_message += "/info <币种> - 获取币种详细信息\n"
        help_message += "/news <币种> - 获取币种相关新闻\n"
        help_message += "/social <币种> - 获取币种社交媒体情绪\n"
        help_message += "/contract <币种> - 获取币种合约信息\n\n"
        
        # 公告查询命令
        help_message += "*公告查询:*\n"
        help_message += "/announcements <数量> - 获取最新公告\n"
        help_message += "/listings <数量> - 获取最新上币公告\n"
        help_message += "/exchange <交易所> <数量> - 获取指定交易所的公告\n\n"
        
        # 高级命令
        help_message += "*高级命令:*\n"
        help_message += "/alert <币种> <条件> <值> - 设置自定义预警\n"
        help_message += "/compare <币种1> <币种2> - 比较两个币种的表现\n"
        help_message += "/volume <币种> <交易所> - 查询交易量信息\n"
        help_message += "/settings - 显示和修改用户设置\n"
        
        return help_message
        
    def handle_status(self, args, user_id, chat_id):
        """处理/status命令"""
        # 获取系统状态
        monitored_symbols = len(self.price_monitor.get_monitored_symbols())
        active_alerts = self.price_monitor.get_active_alerts_count()
        last_price_check = self.price_monitor.get_last_check_time()
        last_announcement_check = self.announcement_monitor.get_last_check_time()
        
        # 格式化时间
        if last_price_check:
            last_price_check_str = datetime.fromtimestamp(last_price_check).strftime('%Y-%m-%d %H:%M:%S')
        else:
            last_price_check_str = "从未"
            
        if last_announcement_check:
            last_announcement_check_str = datetime.fromtimestamp(last_announcement_check).strftime('%Y-%m-%d %H:%M:%S')
        else:
            last_announcement_check_str = "从未"
            
        # 获取用户设置
        user_settings = self.user_settings.get(user_id, {})
        notifications_paused = user_settings.get("notifications_paused", False)
        
        status_message = "📊 *系统状态*\n\n"
        status_message += f"监控币种数量: `{monitored_symbols}`\n"
        status_message += f"活跃预警数量: `{active_alerts}`\n"
        status_message += f"最后价格检查: `{last_price_check_str}`\n"
        status_message += f"最后公告检查: `{last_announcement_check_str}`\n"
        status_message += f"通知状态: `{'已暂停' if notifications_paused else '正常'}`\n"
        
        # 添加系统运行时间
        uptime = self._get_system_uptime()
        status_message += f"系统运行时间: `{uptime}`\n"
        
        return status_message
        
    # 价格查询命令处理器
    
    def handle_price(self, args, user_id, chat_id):
        """处理/price命令"""
        if not args:
            return "请指定币种，例如: /price BTC"
            
        symbol = args[0].upper()
        exchange = args[1].lower() if len(args) > 1 else None
        
        # 标准化符号格式
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
            
        try:
            # 获取价格
            price_data = self.price_monitor.fetch_specific_price(symbol, exchange)
            
            if not price_data:
                return f"未找到 {symbol} 的价格信息"
                
            # 格式化响应
            response = f"💰 *{symbol} 价格信息*\n\n"
            
            for ex, data in price_data.items():
                response += f"*{ex.capitalize()}*\n"
                response += f"当前价格: `{data['price']}`\n"
                
                if 'change_24h' in data:
                    change = data['change_24h']
                    emoji = "🚀" if change > 0 else "📉"
                    response += f"24小时变化: `{change}%` {emoji}\n"
                    
                if 'volume_24h' in data:
                    response += f"24小时交易量: `${self._format_number(data['volume_24h'])}`\n"
                    
                response += "\n"
                
            # 添加图表命令提示
            response += f"查看图表请使用: `/chart {symbol.split('/')[0]}`"
            
            return response
        except Exception as e:
            logger.error(f"获取价格失败: {e}")
            return f"获取价格失败: {str(e)}"
            
    def handle_chart(self, args, user_id, chat_id):
        """处理/chart命令"""
        if not args:
            return "请指定币种和时间周期，例如: /chart BTC 1d"
            
        symbol = args[0].upper()
        timeframe = args[1].lower() if len(args) > 1 else "1d"
        
        # 标准化符号格式
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
            
        try:
            # 获取历史数据
            historical_data = self.price_monitor.fetch_historical_data(symbol, timeframe)
            
            if not historical_data:
                return f"未找到 {symbol} 的历史数据"
                
            # 生成图表
            chart_path = self._generate_price_chart(symbol, historical_data, timeframe)
            
            if not chart_path:
                return "生成图表失败"
                
            # 返回图表路径，由调用者负责发送图片
            return {
                "type": "photo",
                "path": chart_path,
                "caption": f"{symbol} {timeframe} 价格走势图"
            }
        except Exception as e:
            logger.error(f"生成图表失败: {e}")
            return f"生成图表失败: {str(e)}"
            
    def handle_top(self, args, user_id, chat_id):
        """处理/top命令"""
        limit = int(args[0]) if args and args[0].isdigit() else 5
        limit = min(limit, 20)  # 限制最多返回20个
        
        try:
            # 获取涨幅最高的币种
            top_gainers = self.price_monitor.get_top_gainers(limit)
            
            if not top_gainers:
                return "未找到涨幅数据"
                
            response = f"🚀 *涨幅最高的{len(top_gainers)}个币种*\n\n"
            
            for i, coin in enumerate(top_gainers, 1):
                response += f"{i}. *{coin['symbol']}*: `+{coin['change']}%`"
                if 'price' in coin:
                    response += f" (价格: `{coin['price']}`)"
                response += "\n"
                
            return response
        except Exception as e:
            logger.error(f"获取涨幅最高币种失败: {e}")
            return f"获取涨幅最高币种失败: {str(e)}"
            
    def handle_bottom(self, args, user_id, chat_id):
        """处理/bottom命令"""
        limit = int(args[0]) if args and args[0].isdigit() else 5
        limit = min(limit, 20)  # 限制最多返回20个
        
        try:
            # 获取跌幅最大的币种
            top_losers = self.price_monitor.get_top_losers(limit)
            
            if not top_losers:
                return "未找到跌幅数据"
                
            response = f"📉 *跌幅最大的{len(top_losers)}个币种*\n\n"
            
            for i, coin in enumerate(top_losers, 1):
                response += f"{i}. *{coin['symbol']}*: `{coin['change']}%`"
                if 'price' in coin:
                    response += f" (价格: `{coin['price']}`)"
                response += "\n"
                
            return response
        except Exception as e:
            logger.error(f"获取跌幅最大币种失败: {e}")
            return f"获取跌幅最大币种失败: {str(e)}"
            
    # 监控设置命令处理器
    
    def handle_watch(self, args, user_id, chat_id):
        """处理/watch命令"""
        if not args:
            return "请指定币种，例如: /watch BTC"
            
        symbol = args[0].upper()
        
        # 标准化符号格式
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
            
        try:
            # 添加到监控列表
            result = self.price_monitor.add_symbol_to_watchlist(symbol, user_id)
            
            if result:
                return f"✅ 已添加 {symbol} 到监控列表"
            else:
                return f"❌ 添加失败，{symbol} 可能已在监控列表中或不受支持"
        except Exception as e:
            logger.error(f"添加监控失败: {e}")
            return f"添加监控失败: {str(e)}"
            
    def handle_unwatch(self, args, user_id, chat_id):
        """处理/unwatch命令"""
        if not args:
            return "请指定币种，例如: /unwatch BTC"
            
        symbol = args[0].upper()
        
        # 标准化符号格式
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
            
        try:
            # 从监控列表移除
            result = self.price_monitor.remove_symbol_from_watchlist(symbol, user_id)
            
            if result:
                return f"✅ 已从监控列表移除 {symbol}"
            else:
                return f"❌ 移除失败，{symbol} 可能不在监控列表中"
        except Exception as e:
            logger.error(f"移除监控失败: {e}")
            return f"移除监控失败: {str(e)}"
            
    def handle_watchlist(self, args, user_id, chat_id):
        """处理/watchlist命令"""
        try:
            # 获取用户的监控列表
            watchlist = self.price_monitor.get_user_watchlist(user_id)
            
            if not watchlist:
                return "您的监控列表为空。使用 /watch <币种> 添加币种到监控列表。"
                
            response = f"📋 *您的监控列表* ({len(watchlist)}个币种)\n\n"
            
            for i, symbol in enumerate(watchlist, 1):
                # 获取当前价格和24小时变化
                price_data = self.price_monitor.get_symbol_data(symbol)
                
                if price_data:
                    price = price_data.get('price', 'N/A')
                    change = price_data.get('change_24h', 0)
                    emoji = "🚀" if change > 0 else "📉" if change < 0 else "➖"
                    response += f"{i}. *{symbol}*: `{price}` ({change}% {emoji})\n"
                else:
                    response += f"{i}. *{symbol}*: `数据暂无`\n"
                    
            return response
        except Exception as e:
            logger.error(f"获取监控列表失败: {e}")
            return f"获取监控列表失败: {str(e)}"
            
    def handle_threshold(self, args, user_id, chat_id):
        """处理/threshold命令"""
        if len(args) < 2:
            return "请指定类型和值，例如: /threshold 1h 5"
            
        alert_type = args[0].lower()
        try:
            threshold = float(args[1])
        except ValueError:
            return "阈值必须是数字"
            
        # 验证类型
        valid_types = ["5m", "15m", "1h", "24h"]
        if alert_type not in valid_types:
            return f"无效的类型。有效类型: {', '.join(valid_types)}"
            
        try:
            # 设置阈值
            self.price_monitor.set_user_threshold(user_id, alert_type, threshold)
            return f"✅ 已设置 {alert_type} 预警阈值为 {threshold}%"
        except Exception as e:
            logger.error(f"设置阈值失败: {e}")
            return f"设置阈值失败: {str(e)}"
            
    def handle_pause(self, args, user_id, chat_id):
        """处理/pause命令"""
        try:
            # 暂停通知
            self.user_settings.setdefault(user_id, {})["notifications_paused"] = True
            return "✅ 已暂停所有预警通知。使用 /resume 恢复通知。"
        except Exception as e:
            logger.error(f"暂停通知失败: {e}")
            return f"暂停通知失败: {str(e)}"
            
    def handle_resume(self, args, user_id, chat_id):
        """处理/resume命令"""
        try:
            # 恢复通知
            self.user_settings.setdefault(user_id, {})["notifications_paused"] = False
            return "✅ 已恢复所有预警通知。"
        except Exception as e:
            logger.error(f"恢复通知失败: {e}")
            return f"恢复通知失败: {str(e)}"
            
    # 币种信息命令处理器
    
    def handle_info(self, args, user_id, chat_id):
        """处理/info命令"""
        if not args:
            return "请指定币种，例如: /info BTC"
            
        symbol = args[0].upper()
        
        try:
            # 获取币种信息
            coin_info = self.coin_enricher.get_coin_info(symbol)
            
            if not coin_info:
                return f"未找到 {symbol} 的信息"
                
            # 格式化响应
            response = f"ℹ️ *{coin_info.get('name', symbol)} ({symbol}) 信息*\n\n"
            
            # 基本信息
            response += "*基本信息:*\n"
            if 'description' in coin_info:
                description = coin_info['description']
                if len(description) > 300:
                    description = description[:297] + "..."
                response += f"{description}\n\n"
                
            if 'categories' in coin_info and coin_info['categories']:
                response += f"类别: `{', '.join(coin_info['categories'])}`\n"
                
            if 'launch_date' in coin_info:
                response += f"发布日期: `{coin_info['launch_date']}`\n\n"
                
            # 市场数据
            response += "*市场数据:*\n"
            if 'market_cap' in coin_info:
                response += f"市值: `${self._format_number(coin_info['market_cap'])}`\n"
                
            if 'rank' in coin_info:
                response += f"市值排名: `#{coin_info['rank']}`\n"
                
            if 'volume_24h' in coin_info:
                response += f"24小时交易量: `${self._format_number(coin_info['volume_24h'])}`\n"
                
            if 'circulating_supply' in coin_info:
                response += f"流通供应量: `{self._format_number(coin_info['circulating_supply'])} {symbol}`\n"
                
            if 'total_supply' in coin_info:
                response += f"总供应量: `{self._format_number(coin_info['total_supply'])} {symbol}`\n\n"
                
            # 链接
            if 'links' in coin_info:
                links = coin_info['links']
                response += "*相关链接:*\n"
                
                link_parts = []
                if links.get('website'):
                    link_parts.append(f"[官网]({links['website']})")
                if links.get('twitter'):
                    link_parts.append(f"[Twitter]({links['twitter']})")
                if links.get('telegram'):
                    link_parts.append(f"[Telegram]({links['telegram']})")
                if links.get('github'):
                    link_parts.append(f"[GitHub]({links['github']})")
                if links.get('explorer'):
                    link_parts.append(f"[区块浏览器]({links['explorer']})")
                    
                response += " | ".join(link_parts) if link_parts else "暂无相关链接"
                
            return response
        except Exception as e:
            logger.error(f"获取币种信息失败: {e}")
            return f"获取币种信息失败: {str(e)}"
            
    def handle_news(self, args, user_id, chat_id):
        """处理/news命令"""
        if not args:
            return "请指定币种，例如: /news BTC"
            
        symbol = args[0].upper()
        limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 5
        limit = min(limit, 10)  # 限制最多返回10条
        
        try:
            # 获取币种相关新闻
            news = self.coin_enricher.get_coin_news(symbol, limit)
            
            if not news:
                return f"未找到 {symbol} 的相关新闻"
                
            response = f"📰 *{symbol} 相关新闻*\n\n"
            
            for i, item in enumerate(news, 1):
                response += f"{i}. [{item['title']}]({item['url']})\n"
                if 'source' in item:
                    response += f"   来源: {item['source']}"
                if 'date' in item:
                    response += f" | 日期: {item['date']}"
                response += "\n\n"
                
            return response
        except Exception as e:
            logger.error(f"获取新闻失败: {e}")
            return f"获取新闻失败: {str(e)}"
            
    def handle_social(self, args, user_id, chat_id):
        """处理/social命令"""
        if not args:
            return "请指定币种，例如: /social BTC"
            
        symbol = args[0].upper()
        
        try:
            # 获取社交媒体情绪
            social_data = self.coin_enricher.get_social_sentiment(symbol)
            
            if not social_data:
                return f"未找到 {symbol} 的社交媒体数据"
                
            response = f"📊 *{symbol} 社交媒体情绪分析*\n\n"
            
            if 'overall' in social_data:
                sentiment = social_data['overall']
                emoji = "😃" if sentiment > 70 else "🙂" if sentiment > 50 else "😐" if sentiment > 30 else "🙁"
                response += f"整体情绪: `{sentiment}%` {emoji}\n\n"
                
            if 'platforms' in social_data:
                response += "*平台情绪:*\n"
                for platform, value in social_data['platforms'].items():
                    emoji = "😃" if value > 70 else "🙂" if value > 50 else "😐" if value > 30 else "🙁"
                    response += f"{platform}: `{value}%` {emoji}\n"
                    
            if 'mentions' in social_data:
                response += f"\n24小时提及次数: `{social_data['mentions']}`\n"
                
            if 'trending_score' in social_data:
                response += f"热度指数: `{social_data['trending_score']}`\n"
                
            return response
        except Exception as e:
            logger.error(f"获取社交情绪失败: {e}")
            return f"获取社交情绪失败: {str(e)}"
            
    def handle_contract(self, args, user_id, chat_id):
        """处理/contract命令"""
        if not args:
            return "请指定币种，例如: /contract USDT"
            
        symbol = args[0].upper()
        
        try:
            # 获取合约信息
            contract_info = self.coin_enricher.get_contract_info(symbol)
            
            if not contract_info:
                return f"未找到 {symbol} 的合约信息"
                
            response = f"📝 *{symbol} 合约信息*\n\n"
            
            if isinstance(contract_info, list):
                # 多个合约
                for i, contract in enumerate(contract_info, 1):
                    response += f"*合约 {i}:*\n"
                    response += f"平台: `{contract.get('platform', 'N/A')}`\n"
                    response += f"合约地址: `{contract.get('contract_address', 'N/A')}`\n"
                    if 'token_standard' in contract:
                        response += f"代币标准: `{contract['token_standard']}`\n"
                    response += "\n"
            else:
                # 单个合约
                response += f"平台: `{contract_info.get('platform', 'N/A')}`\n"
                response += f"合约地址: `{contract_info.get('contract_address', 'N/A')}`\n"
                if 'token_standard' in contract_info:
                    response += f"代币标准: `{contract_info['token_standard']}`\n"
                    
            return response
        except Exception as e:
            logger.error(f"获取合约信息失败: {e}")
            return f"获取合约信息失败: {str(e)}"
            
    # 公告查询命令处理器
    
    def handle_announcements(self, args, user_id, chat_id):
        """处理/announcements命令"""
        limit = int(args[0]) if args and args[0].isdigit() else 5
        limit = min(limit, 10)  # 限制最多返回10条
        
        try:
            # 获取最新公告
            announcements = self.announcement_monitor.get_latest_announcements(limit)
            
            if not announcements:
                return "未找到最新公告"
                
            response = f"📢 *最新交易所公告* (最近{len(announcements)}条)\n\n"
            
            for i, announcement in enumerate(announcements, 1):
                title = announcement.get('title', 'N/A')
                exchange = announcement.get('exchange', 'N/A').capitalize()
                date = announcement.get('date', 'N/A')
                url = announcement.get('url', '')
                
                response += f"{i}. *{exchange}*: "
                if url:
                    response += f"[{title}]({url})\n"
                else:
                    response += f"{title}\n"
                    
                response += f"   日期: {date}\n\n"
                
            return response
        except Exception as e:
            logger.error(f"获取公告失败: {e}")
            return f"获取公告失败: {str(e)}"
            
    def handle_listings(self, args, user_id, chat_id):
        """处理/listings命令"""
        limit = int(args[0]) if args and args[0].isdigit() else 5
        limit = min(limit, 10)  # 限制最多返回10条
        
        try:
            # 获取最新上币公告
            listings = self.announcement_monitor.get_latest_listings(limit)
            
            if not listings:
                return "未找到最新上币公告"
                
            response = f"🔥 *最新上币公告* (最近{len(listings)}条)\n\n"
            
            for i, listing in enumerate(listings, 1):
                title = listing.get('title', 'N/A')
                exchange = listing.get('exchange', 'N/A').capitalize()
                date = listing.get('date', 'N/A')
                url = listing.get('url', '')
                
                response += f"{i}. *{exchange}*: "
                if url:
                    response += f"[{title}]({url})\n"
                else:
                    response += f"{title}\n"
                    
                response += f"   日期: {date}\n\n"
                
            return response
        except Exception as e:
            logger.error(f"获取上币公告失败: {e}")
            return f"获取上币公告失败: {str(e)}"
            
    def handle_exchange(self, args, user_id, chat_id):
        """处理/exchange命令"""
        if not args:
            return "请指定交易所和数量，例如: /exchange binance 5"
            
        exchange = args[0].lower()
        limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 5
        limit = min(limit, 10)  # 限制最多返回10条
        
        # 验证交易所
        valid_exchanges = ["binance", "gate"]
        if exchange not in valid_exchanges:
            return f"无效的交易所。支持的交易所: {', '.join(valid_exchanges)}"
            
        try:
            # 获取指定交易所的公告
            announcements = self.announcement_monitor.get_exchange_announcements(exchange, limit)
            
            if not announcements:
                return f"未找到 {exchange.capitalize()} 的最新公告"
                
            response = f"📢 *{exchange.capitalize()} 最新公告* (最近{len(announcements)}条)\n\n"
            
            for i, announcement in enumerate(announcements, 1):
                title = announcement.get('title', 'N/A')
                date = announcement.get('date', 'N/A')
                url = announcement.get('url', '')
                
                if url:
                    response += f"{i}. [{title}]({url})\n"
                else:
                    response += f"{i}. {title}\n"
                    
                response += f"   日期: {date}\n\n"
                
            return response
        except Exception as e:
            logger.error(f"获取交易所公告失败: {e}")
            return f"获取交易所公告失败: {str(e)}"
            
    # 高级命令处理器
    
    def handle_alert(self, args, user_id, chat_id):
        """处理/alert命令"""
        if len(args) < 3:
            return "请指定币种、条件和值，例如: /alert BTC >50000"
            
        symbol = args[0].upper()
        condition = args[1]
        try:
            value = float(args[2])
        except ValueError:
            return "值必须是数字"
            
        # 标准化符号格式
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
            
        # 验证条件
        valid_conditions = [">", "<", ">=", "<="]
        if condition not in valid_conditions:
            return f"无效的条件。有效条件: {', '.join(valid_conditions)}"
            
        try:
            # 设置自定义预警
            alert_id = self.price_monitor.add_custom_alert(symbol, condition, value, user_id)
            
            if alert_id:
                return f"✅ 已设置 {symbol} {condition} {value} 的自定义预警"
            else:
                return "❌ 设置自定义预警失败"
        except Exception as e:
            logger.error(f"设置自定义预警失败: {e}")
            return f"设置自定义预警失败: {str(e)}"
            
    def handle_compare(self, args, user_id, chat_id):
        """处理/compare命令"""
        if len(args) < 2:
            return "请指定两个币种，例如: /compare BTC ETH"
            
        symbol1 = args[0].upper()
        symbol2 = args[1].upper()
        
        # 标准化符号格式
        if '/' not in symbol1:
            symbol1 = f"{symbol1}/USDT"
        if '/' not in symbol2:
            symbol2 = f"{symbol2}/USDT"
            
        try:
            # 获取两个币种的数据
            data1 = self.price_monitor.get_symbol_data(symbol1)
            data2 = self.price_monitor.get_symbol_data(symbol2)
            
            if not data1 or not data2:
                return f"未找到 {symbol1} 或 {symbol2} 的数据"
                
            # 获取历史数据用于比较
            history1 = self.price_monitor.fetch_historical_data(symbol1, "1d", limit=7)
            history2 = self.price_monitor.fetch_historical_data(symbol2, "1d", limit=7)
            
            # 计算7天表现
            perf1_7d = self._calculate_performance(history1, 7) if history1 else None
            perf2_7d = self._calculate_performance(history2, 7) if history2 else None
            
            # 格式化响应
            response = f"📊 *{symbol1.split('/')[0]} vs {symbol2.split('/')[0]} 比较*\n\n"
            
            # 当前价格
            response += "*当前价格:*\n"
            response += f"{symbol1.split('/')[0]}: `{data1.get('price', 'N/A')}`\n"
            response += f"{symbol2.split('/')[0]}: `{data2.get('price', 'N/A')}`\n\n"
            
            # 24小时变化
            response += "*24小时变化:*\n"
            change1_24h = data1.get('change_24h', 0)
            change2_24h = data2.get('change_24h', 0)
            emoji1 = "🚀" if change1_24h > 0 else "📉" if change1_24h < 0 else "➖"
            emoji2 = "🚀" if change2_24h > 0 else "📉" if change2_24h < 0 else "➖"
            response += f"{symbol1.split('/')[0]}: `{change1_24h}%` {emoji1}\n"
            response += f"{symbol2.split('/')[0]}: `{change2_24h}%` {emoji2}\n\n"
            
            # 7天表现
            if perf1_7d is not None and perf2_7d is not None:
                response += "*7天表现:*\n"
                emoji1 = "🚀" if perf1_7d > 0 else "📉" if perf1_7d < 0 else "➖"
                emoji2 = "🚀" if perf2_7d > 0 else "📉" if perf2_7d < 0 else "➖"
                response += f"{symbol1.split('/')[0]}: `{perf1_7d}%` {emoji1}\n"
                response += f"{symbol2.split('/')[0]}: `{perf2_7d}%` {emoji2}\n\n"
                
            # 交易量
            response += "*24小时交易量:*\n"
            volume1 = data1.get('volume_24h', 0)
            volume2 = data2.get('volume_24h', 0)
            response += f"{symbol1.split('/')[0]}: `${self._format_number(volume1)}`\n"
            response += f"{symbol2.split('/')[0]}: `${self._format_number(volume2)}`\n\n"
            
            # 相对表现
            response += "*相对表现:*\n"
            if change1_24h > change2_24h:
                diff = change1_24h - change2_24h
                response += f"24小时内 {symbol1.split('/')[0]} 表现优于 {symbol2.split('/')[0]} `{diff:.2f}%`\n"
            elif change2_24h > change1_24h:
                diff = change2_24h - change1_24h
                response += f"24小时内 {symbol2.split('/')[0]} 表现优于 {symbol1.split('/')[0]} `{diff:.2f}%`\n"
            else:
                response += f"24小时内两者表现相当\n"
                
            if perf1_7d is not None and perf2_7d is not None:
                if perf1_7d > perf2_7d:
                    diff = perf1_7d - perf2_7d
                    response += f"7天内 {symbol1.split('/')[0]} 表现优于 {symbol2.split('/')[0]} `{diff:.2f}%`\n"
                elif perf2_7d > perf1_7d:
                    diff = perf2_7d - perf1_7d
                    response += f"7天内 {symbol2.split('/')[0]} 表现优于 {symbol1.split('/')[0]} `{diff:.2f}%`\n"
                else:
                    response += f"7天内两者表现相当\n"
                    
            return response
        except Exception as e:
            logger.error(f"比较币种失败: {e}")
            return f"比较币种失败: {str(e)}"
            
    def handle_volume(self, args, user_id, chat_id):
        """处理/volume命令"""
        if not args:
            return "请指定币种，例如: /volume BTC"
            
        symbol = args[0].upper()
        exchange = args[1].lower() if len(args) > 1 else None
        
        # 标准化符号格式
        if '/' not in symbol:
            symbol = f"{symbol}/USDT"
            
        try:
            # 获取交易量信息
            volume_data = self.price_monitor.get_volume_data(symbol, exchange)
            
            if not volume_data:
                return f"未找到 {symbol} 的交易量信息"
                
            response = f"📊 *{symbol} 交易量信息*\n\n"
            
            for ex, data in volume_data.items():
                response += f"*{ex.capitalize()}*\n"
                
                if 'volume_24h' in data:
                    response += f"24小时交易量: `${self._format_number(data['volume_24h'])}`\n"
                    
                if 'volume_change_24h' in data:
                    change = data['volume_change_24h']
                    emoji = "🚀" if change > 0 else "📉" if change < 0 else "➖"
                    response += f"24小时交易量变化: `{change}%` {emoji}\n"
                    
                if 'buy_volume_24h' in data and 'sell_volume_24h' in data:
                    buy_volume = data['buy_volume_24h']
                    sell_volume = data['sell_volume_24h']
                    total_volume = buy_volume + sell_volume
                    
                    if total_volume > 0:
                        buy_percentage = (buy_volume / total_volume) * 100
                        sell_percentage = (sell_volume / total_volume) * 100
                        
                        response += f"买入比例: `{buy_percentage:.2f}%`\n"
                        response += f"卖出比例: `{sell_percentage:.2f}%`\n"
                        
                        if buy_volume > sell_volume:
                            response += "买入压力大于卖出压力 📈\n"
                        else:
                            response += "卖出压力大于买入压力 📉\n"
                            
                response += "\n"
                
            return response
        except Exception as e:
            logger.error(f"获取交易量信息失败: {e}")
            return f"获取交易量信息失败: {str(e)}"
            
    def handle_settings(self, args, user_id, chat_id):
        """处理/settings命令"""
        try:
            # 获取用户设置
            settings = self.user_settings.get(user_id, {})
            
            # 如果没有参数，显示当前设置
            if not args:
                response = "⚙️ *用户设置*\n\n"
                
                # 通知设置
                notifications_paused = settings.get("notifications_paused", False)
                response += f"通知状态: `{'已暂停' if notifications_paused else '正常'}`\n"
                
                # 阈值设置
                thresholds = settings.get("thresholds", {})
                response += "\n*预警阈值:*\n"
                for alert_type in ["5m", "15m", "1h", "24h"]:
                    threshold = thresholds.get(alert_type, self.config.get("default_thresholds", {}).get(alert_type, "默认"))
                    response += f"{alert_type}: `{threshold}%`\n"
                    
                # 监控列表
                watchlist = self.price_monitor.get_user_watchlist(user_id)
                response += f"\n监控币种数量: `{len(watchlist)}`\n"
                
                # 自定义预警
                custom_alerts = self.price_monitor.get_user_custom_alerts(user_id)
                response += f"自定义预警数量: `{len(custom_alerts)}`\n"
                
                # 设置命令
                response += "\n*设置命令:*\n"
                response += "/threshold <类型> <值> - 设置预警阈值\n"
                response += "/pause - 暂停所有预警通知\n"
                response += "/resume - 恢复所有预警通知\n"
                
                return response
            else:
                # 处理设置修改
                setting = args[0].lower()
                
                if setting == "notifications":
                    if len(args) < 2:
                        return "请指定通知状态，例如: /settings notifications on"
                        
                    value = args[1].lower()
                    if value in ["on", "enable", "resume"]:
                        settings["notifications_paused"] = False
                        self.user_settings[user_id] = settings
                        return "✅ 已恢复通知"
                    elif value in ["off", "disable", "pause"]:
                        settings["notifications_paused"] = True
                        self.user_settings[user_id] = settings
                        return "✅ 已暂停通知"
                    else:
                        return "无效的值。使用 on/off 或 enable/disable"
                        
                elif setting == "threshold":
                    if len(args) < 3:
                        return "请指定类型和值，例如: /settings threshold 1h 5"
                        
                    alert_type = args[1].lower()
                    try:
                        threshold = float(args[2])
                    except ValueError:
                        return "阈值必须是数字"
                        
                    # 验证类型
                    valid_types = ["5m", "15m", "1h", "24h"]
                    if alert_type not in valid_types:
                        return f"无效的类型。有效类型: {', '.join(valid_types)}"
                        
                    # 设置阈值
                    thresholds = settings.get("thresholds", {})
                    thresholds[alert_type] = threshold
                    settings["thresholds"] = thresholds
                    self.user_settings[user_id] = settings
                    
                    return f"✅ 已设置 {alert_type} 预警阈值为 {threshold}%"
                else:
                    return f"未知设置: {setting}。使用 /settings 查看可用设置。"
        except Exception as e:
            logger.error(f"处理设置失败: {e}")
            return f"处理设置失败: {str(e)}"
            
    # 辅助方法
    
    def _format_number(self, number):
        """格式化数字"""
        if number is None or number == 0:
            return "N/A"
            
        if number >= 1_000_000_000:
            return f"{number / 1_000_000_000:.2f}B"
        elif number >= 1_000_000:
            return f"{number / 1_000_000:.2f}M"
        elif number >= 1_000:
            return f"{number / 1_000:.2f}K"
        else:
            return f"{number:.2f}"
            
    def _generate_price_chart(self, symbol, historical_data, timeframe, output_dir="/tmp"):
        """生成价格图表"""
        try:
            # 确保输出目录存在
            os.makedirs(output_dir, exist_ok=True)
            
            # 准备数据
            timestamps = [entry[0] for entry in historical_data]
            prices = [entry[1] for entry in historical_data]
            
            # 转换时间戳为可读时间
            if timeframe in ["1m", "5m", "15m", "30m", "1h", "2h", "4h"]:
                date_format = '%m-%d %H:%M'
            else:
                date_format = '%Y-%m-%d'
                
            dates = [datetime.fromtimestamp(ts / 1000).strftime(date_format) for ts in timestamps]
            
            # 创建图表
            plt.figure(figsize=(10, 6))
            plt.plot(dates, prices, 'b-')
            plt.title(f"{symbol} 价格走势 ({timeframe})")
            plt.xlabel("日期")
            plt.ylabel("价格 (USDT)")
            plt.xticks(rotation=45)
            plt.grid(True)
            plt.tight_layout()
            
            # 保存图表
            chart_path = os.path.join(output_dir, f"{symbol.replace('/', '_')}_{timeframe}_chart.png")
            plt.savefig(chart_path)
            plt.close()
            
            return chart_path
        except Exception as e:
            logger.error(f"生成价格图表失败: {e}")
            return None
            
    def _calculate_performance(self, historical_data, days):
        """计算性能表现"""
        if not historical_data or len(historical_data) < 2:
            return None
            
        # 获取最新价格和N天前价格
        latest_price = historical_data[-1][1]
        
        # 找到N天前的数据点
        if len(historical_data) <= days:
            old_price = historical_data[0][1]
        else:
            old_price = historical_data[-days][1]
            
        # 计算百分比变化
        if old_price > 0:
            performance = ((latest_price - old_price) / old_price) * 100
            return round(performance, 2)
        else:
            return None
            
    def _get_system_uptime(self):
        """获取系统运行时间"""
        try:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = float(f.readline().split()[0])
                
            # 转换为可读格式
            days = int(uptime_seconds / 86400)
            hours = int((uptime_seconds % 86400) / 3600)
            minutes = int((uptime_seconds % 3600) / 60)
            
            if days > 0:
                return f"{days}天 {hours}小时 {minutes}分钟"
            elif hours > 0:
                return f"{hours}小时 {minutes}分钟"
            else:
                return f"{minutes}分钟"
        except:
            return "未知"
```

### 与Telegram Bot API集成

```python
# 与Telegram Bot API集成伪代码
class TelegramBotManager:
    def __init__(self, config, command_handler):
        self.config = config
        self.command_handler = command_handler
        self.bots = {}
        self.dispatchers = {}
        self.setup_bots()
        
    def setup_bots(self):
        """设置所有Telegram Bot"""
        for account in self.config.get("accounts", []):
            name = account.get("name", "unnamed")
            token = account.get("token", "")
            
            if token:
                try:
                    bot = telegram.Bot(token=token)
                    self.bots[name] = bot
                    
                    # 设置命令处理器
                    dispatcher = Dispatcher(bot, None, workers=0)
                    self._setup_handlers(dispatcher)
                    self.dispatchers[name] = dispatcher
                    
                    # 启动轮询
                    Thread(target=dispatcher.start_polling).start()
                    
                    logger.info(f"Telegram Bot {name} 设置成功")
                except Exception as e:
                    logger.error(f"Telegram Bot {name} 设置失败: {e}")
                    
    def _setup_handlers(self, dispatcher):
        """设置命令处理器"""
        # 命令处理器
        dispatcher.add_handler(CommandHandler("start", self._handle_command))
        dispatcher.add_handler(CommandHandler("help", self._handle_command))
        dispatcher.add_handler(CommandHandler("status", self._handle_command))
        dispatcher.add_handler(CommandHandler("price", self._handle_command))
        dispatcher.add_handler(CommandHandler("chart", self._handle_command))
        dispatcher.add_handler(CommandHandler("top", self._handle_command))
        dispatcher.add_handler(CommandHandler("bottom", self._handle_command))
        dispatcher.add_handler(CommandHandler("watch", self._handle_command))
        dispatcher.add_handler(CommandHandler("unwatch", self._handle_command))
        dispatcher.add_handler(CommandHandler("watchlist", self._handle_command))
        dispatcher.add_handler(CommandHandler("threshold", self._handle_command))
        dispatcher.add_handler(CommandHandler("pause", self._handle_command))
        dispatcher.add_handler(CommandHandler("resume", self._handle_command))
        dispatcher.add_handler(CommandHandler("info", self._handle_command))
        dispatcher.add_handler(CommandHandler("news", self._handle_command))
        dispatcher.add_handler(CommandHandler("social", self._handle_command))
        dispatcher.add_handler(CommandHandler("contract", self._handle_command))
        dispatcher.add_handler(CommandHandler("announcements", self._handle_command))
        dispatcher.add_handler(CommandHandler("listings", self._handle_command))
        dispatcher.add_handler(CommandHandler("exchange", self._handle_command))
        dispatcher.add_handler(CommandHandler("alert", self._handle_command))
        dispatcher.add_handler(CommandHandler("compare", self._handle_command))
        dispatcher.add_handler(CommandHandler("volume", self._handle_command))
        dispatcher.add_handler(CommandHandler("settings", self._handle_command))
        
        # 错误处理器
        dispatcher.add_error_handler(self._error_handler)
        
    def _handle_command(self, update, context):
        """处理命令"""
        try:
            # 获取命令和参数
            message = update.message
            command = message.text.split()[0][1:].lower()  # 移除/并转为小写
            args = message.text.split()[1:] if len(message.text.split()) > 1 else []
            
            # 获取用户信息
            user_id = message.from_user.id
            chat_id = message.chat_id
            
            # 处理命令
            response = self.command_handler.process_command(command, args, user_id, chat_id)
            
            # 发送响应
            if isinstance(response, dict) and response.get("type") == "photo":
                # 发送图片
                with open(response["path"], 'rb') as photo:
                    message.reply_photo(
                        photo=photo,
                        caption=response.get("caption"),
                        parse_mode="Markdown"
                    )
                    
                # 清理临时文件
                try:
                    os.remove(response["path"])
                except:
                    pass
            else:
                # 发送文本消息
                message.reply_text(
                    text=response,
                    parse_mode="Markdown"
                )
        except Exception as e:
            logger.error(f"处理命令失败: {e}")
            update.message.reply_text(f"处理命令时出错: {str(e)}")
            
    def _error_handler(self, update, context):
        """处理错误"""
        try:
            logger.error(f"更新 {update} 导致错误 {context.error}")
        except:
            logger.error(f"处理错误时出错")
            
    def send_message(self, account_name, chat_id, text, parse_mode="Markdown"):
        """发送消息"""
        if account_name in self.bots:
            try:
                self.bots[account_name].send_message(
                    chat_id=chat_id,
                    text=text,
                    parse_mode=parse_mode
                )
                return True
            except Exception as e:
                logger.error(f"发送消息失败: {e}")
                return False
        else:
            logger.error(f"账号 {account_name} 不存在")
            return False
            
    def send_photo(self, account_name, chat_id, photo_path, caption=None, parse_mode="Markdown"):
        """发送图片"""
        if account_name in self.bots:
            try:
                with open(photo_path, 'rb') as photo:
                    self.bots[account_name].send_photo(
                        chat_id=chat_id,
                        photo=photo,
                        caption=caption,
                        parse_mode=parse_mode if caption else None
                    )
                return True
            except Exception as e:
                logger.error(f"发送图片失败: {e}")
                return False
        else:
            logger.error(f"账号 {account_name} 不存在")
            return False
```

### 与主控模块集成

```python
# 与主控模块集成伪代码
class CryptoMonitor:
    def __init__(self, config_file):
        self.config = self._load_config(config_file)
        self.api_manager = ApiPollingManager(self.config.get("api_polling", {}))
        self.price_monitor = PriceMonitor(self.config["price_monitor"], self.api_manager)
        self.announcement_monitor = DualExchangeAnnouncementMonitor(self.config["announcement_monitor"], self.api_manager)
        self.coin_enricher = CoinDetailEnricher(self.config["coin_enricher"], self.api_manager)
        
        # 设置命令处理器
        self.command_handler = TelegramCommandHandler(
            self.config["telegram_commands"],
            self.price_monitor,
            self.announcement_monitor,
            self.coin_enricher
        )
        
        # 设置Telegram Bot管理器
        self.telegram_bot_manager = TelegramBotManager(
            self.config["telegram"],
            self.command_handler
        )
        
        # 设置增强版推送模块
        self.telegram_notifier = EnhancedTelegramNotifier(self.config["telegram"])
        
        self.running = False
        self.last_announcement_check = 0
        
    # ... 其他方法 ...
    
    def check_prices(self):
        """检查价格并发送预警"""
        try:
            prices = self.price_monitor.fetch_prices()
            if not prices:
                logger.info("没有获取到价格数据")
                return 0
                
            # 计算市场波动性，用于调整轮询间隔
            market_volatility = self.price_monitor.calculate_market_volatility(prices)
            next_interval = self.api_manager.calculate_adaptive_interval(market_volatility)
            logger.info(f"市场波动性: {market_volatility:.2f}%, 下次轮询间隔: {next_interval}秒")
            
            # 检查价格预警
            alerts = self.price_monitor.check_price_alerts(prices)
            
            alert_count = 0
            for alert in alerts:
                # 检查用户是否暂停了通知
                user_id = alert.get("user_id")
                if user_id and self.command_handler.user_settings.get(user_id, {}).get("notifications_paused", False):
                    logger.info(f"用户 {user_id} 已暂停通知，跳过预警")
                    continue
                    
                # 丰富预警信息
                enriched_alert = self.coin_enricher.enrich_alert(alert)
                
                # 获取历史价格数据用于生成图表
                try:
                    symbol = alert["symbol"].replace("/", "")
                    exchange = alert["exchange"].lower()
                    
                    if exchange == "binance":
                        historical_data = self.price_monitor.fetch_binance_historical_data(symbol, "1h", limit=24)
                    elif exchange == "gate":
                        historical_data = self.price_monitor.fetch_gate_historical_data(symbol, "1h", limit=24)
                    else:
                        historical_data = None
                        
                    if historical_data:
                        enriched_alert["historical_data"] = historical_data
                except Exception as e:
                    logger.error(f"获取{symbol}历史数据失败: {e}")
                    enriched_alert["historical_data"] = None
                
                # 发送丰富的预警通知
                if self.telegram_notifier.notify_enriched_price_alert(enriched_alert):
                    alert_count += 1
                    
            return alert_count
        except Exception as e:
            logger.error(f"价格检查失败: {e}")
            self.telegram_notifier.send_system_message(f"价格监控失败: {str(e)}", level="error")
            return 0
```

## 配置示例

```python
telegram_commands_config = {
    "command_permissions": {
        "start": ["admin", "user"],
        "help": ["admin", "user"],
        "status": ["admin", "user"],
        "price": ["admin", "user"],
        "chart": ["admin", "user"],
        "top": ["admin", "user"],
        "bottom": ["admin", "user"],
        "watch": ["admin", "user"],
        "unwatch": ["admin", "user"],
        "watchlist": ["admin", "user"],
        "threshold": ["admin", "user"],
        "pause": ["admin", "user"],
        "resume": ["admin", "user"],
        "info": ["admin", "user"],
        "news": ["admin", "user"],
        "social": ["admin", "user"],
        "contract": ["admin", "user"],
        "announcements": ["admin", "user"],
        "listings": ["admin", "user"],
        "exchange": ["admin", "user"],
        "alert": ["admin", "user"],
        "compare": ["admin", "user"],
        "volume": ["admin", "user"],
        "settings": ["admin", "user"]
    },
    "default_thresholds": {
        "5m": 3.0,
        "15m": 5.0,
        "1h": 7.0,
        "24h": 15.0
    },
    "max_results": {
        "top": 10,
        "bottom": 10,
        "news": 5,
        "announcements": 5,
        "listings": 5
    },
    "chart_settings": {
        "default_timeframe": "1d",
        "available_timeframes": ["1h", "4h", "1d", "1w", "1m"],
        "output_dir": "/tmp"
    }
}
```

## 实现细节与注意事项

### 1. 命令处理流程

Telegram命令处理流程如下：

1. 用户在Telegram中发送命令（如`/price BTC`）
2. Telegram Bot API接收命令并传递给处理器
3. 命令处理器解析命令和参数
4. 命令处理器检查用户权限
5. 命令处理器执行相应的处理函数
6. 处理函数返回响应内容
7. Bot发送响应给用户

### 2. 权限控制

为确保安全，系统实现了权限控制机制：

- **用户角色**：区分管理员和普通用户
- **命令权限**：为每个命令设置允许的用户角色
- **权限检查**：在执行命令前检查用户权限
- **配置灵活性**：通过配置文件调整权限设置

### 3. 错误处理

系统实现了全面的错误处理机制：

- **命令解析错误**：当命令格式不正确时提供帮助信息
- **执行错误**：捕获并记录执行过程中的错误
- **API错误**：处理与交易所API通信时的错误
- **用户反馈**：向用户提供清晰的错误信息

### 4. 用户设置管理

系统支持用户个性化设置：

- **阈值设置**：用户可以设置自己的预警阈值
- **通知控制**：用户可以暂停和恢复通知
- **监控列表**：用户可以管理自己的监控列表
- **设置持久化**：用户设置会被保存，重启后仍然有效

### 5. 图表生成

系统支持生成价格图表：

- **多时间周期**：支持不同时间周期的图表
- **自定义样式**：可以调整图表样式和大小
- **临时文件管理**：生成图表后自动清理临时文件
- **错误处理**：当图表生成失败时提供文本替代

## 与其他模块的集成

### 1. 与价格监控模块集成

命令处理器与价格监控模块集成，允许用户：

- 查询当前价格
- 获取价格图表
- 查看涨跌幅排行
- 添加和移除监控币种
- 设置预警阈值
- 创建自定义预警

### 2. 与公告监控模块集成

命令处理器与公告监控模块集成，允许用户：

- 查询最新公告
- 查询最新上币公告
- 查询特定交易所的公告
- 获取公告详情

### 3. 与币种详情聚合模块集成

命令处理器与币种详情聚合模块集成，允许用户：

- 获取币种详细信息
- 查询币种相关新闻
- 获取社交媒体情绪分析
- 查询合约信息

### 4. 与推送模块集成

命令处理器与推送模块集成，确保：

- 命令响应通过正确的账号发送
- 图片和文本消息格式一致
- 用户设置影响推送行为
- 错误信息正确传递

## 扩展功能

### 1. 自定义键盘按钮

可以添加自定义键盘按钮，提高用户体验：

```python
def send_message_with_keyboard(self, account_name, chat_id, text, keyboard_buttons, parse_mode="Markdown"):
    """发送带自定义键盘的消息"""
    if account_name in self.bots:
        try:
            # 创建自定义键盘
            keyboard = []
            for row in keyboard_buttons:
                keyboard.append([KeyboardButton(text) for text in row])
                
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            
            self.bots[account_name].send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
            return True
        except Exception as e:
            logger.error(f"发送带键盘的消息失败: {e}")
            return False
    else:
        logger.error(f"账号 {account_name} 不存在")
        return False
```

### 2. 内联键盘按钮

可以添加内联键盘按钮，支持更复杂的交互：

```python
def send_message_with_inline_keyboard(self, account_name, chat_id, text, inline_buttons, parse_mode="Markdown"):
    """发送带内联键盘的消息"""
    if account_name in self.bots:
        try:
            # 创建内联键盘
            keyboard = []
            for row in inline_buttons:
                keyboard_row = []
                for button in row:
                    if isinstance(button, tuple) and len(button) == 2:
                        text, callback_data = button
                        keyboard_row.append(InlineKeyboardButton(text, callback_data=callback_data))
                    elif isinstance(button, tuple) and len(button) == 3:
                        text, url, _ = button
                        keyboard_row.append(InlineKeyboardButton(text, url=url))
                keyboard.append(keyboard_row)
                
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            self.bots[account_name].send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
            return True
        except Exception as e:
            logger.error(f"发送带内联键盘的消息失败: {e}")
            return False
    else:
        logger.error(f"账号 {account_name} 不存在")
        return False
```

### 3. 命令快捷方式

可以实现命令快捷方式，简化用户操作：

```python
def setup_command_shortcuts(self):
    """设置命令快捷方式"""
    shortcuts = {
        "p": "price",
        "c": "chart",
        "t": "top",
        "b": "bottom",
        "w": "watch",
        "uw": "unwatch",
        "wl": "watchlist",
        "i": "info",
        "n": "news",
        "a": "announcements",
        "l": "listings"
    }
    
    for shortcut, command in shortcuts.items():
        self.command_shortcuts[shortcut] = command
        
def process_command(self, command, args, user_id, chat_id):
    """处理命令，支持快捷方式"""
    # 检查是否是快捷方式
    if command in self.command_shortcuts:
        command = self.command_shortcuts[command]
        
    if command in self.command_handlers:
        # 检查用户权限
        if not self._check_user_permission(user_id, command):
            return "您没有执行此命令的权限"
            
        # 执行命令处理器
        try:
            return self.command_handlers[command](args, user_id, chat_id)
        except Exception as e:
            logger.error(f"处理命令 {command} 失败: {e}")
            return f"处理命令失败: {str(e)}"
    else:
        return f"未知命令: {command}。使用 /help 查看可用命令。"
```

## 总结

Telegram快捷命令功能为加密货币监控系统提供了一个直观、便捷的用户界面，使用户能够通过简单的命令与系统交互。该功能具有以下优势：

1. **易用性**：用户可以通过简单的命令快速获取信息和控制系统
2. **功能全面**：涵盖价格查询、监控设置、币种信息、公告查询等所有核心功能
3. **个性化**：用户可以设置自己的监控列表、预警阈值和通知偏好
4. **交互性**：支持图表、自定义键盘和内联按钮，提高用户体验
5. **安全性**：实现权限控制，确保命令安全执行

该功能与系统的其他模块无缝集成，为用户提供了一个完整、高效的加密货币监控解决方案。
