# 币安和Gate交易所公告监控模块设计

## 功能概述

根据您的需求，我们设计了一个同时监控币安和Gate交易所的公告监控模块，主要功能包括：

1. 监控币安最新公告和新上币公告（每小时一次）
2. 监控Gate最新公告和新上币公告（每小时一次）
3. 与历史记录比较，找出新公告
4. 生成公告通知消息并推送到Telegram

## 模块设计

### 公告监控模块

```python
# 双交易所公告监控模块伪代码
class DualExchangeAnnouncementMonitor:
    def __init__(self, config, api_manager):
        self.config = config
        self.api_manager = api_manager
        self.binance_client = setup_binance_client(config)
        self.gate_client = setup_gate_client(config)
        self.history_file = config.get("history_file", "announcement_history.json")
        self.load_history()
        
    def load_history(self):
        """加载历史公告记录"""
        try:
            with open(self.history_file, "r") as f:
                self.history = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.history = {
                "binance": {"announcements": [], "new_listings": []},
                "gate": {"announcements": [], "new_listings": []}
            }
            
    def save_history(self):
        """保存历史公告记录"""
        with open(self.history_file, "w") as f:
            json.dump(self.history, f)
            
    def fetch_binance_announcements(self):
        """获取币安最新公告"""
        # 检查是否应该请求API
        if not self.api_manager.should_request("binance_announcement"):
            logger.info("跳过币安公告请求，未达到最小间隔")
            return []
            
        try:
            # 使用币安API获取公告
            announcements = self.binance_client.get_announcements()
            self.api_manager.record_request("binance_announcement")
            self.api_manager.reset_error("binance_announcement")
            return announcements
        except Exception as e:
            self.api_manager.record_error("binance_announcement", e)
            logger.error(f"获取币安公告失败: {e}")
            
            # 如果API失败，尝试爬取网页
            retry_delay = self.api_manager.get_retry_delay("binance_announcement")
            if retry_delay > 0:
                logger.info(f"将在{retry_delay}秒后重试")
                time.sleep(retry_delay)
                
            return self._scrape_binance_announcements()
            
    def _scrape_binance_announcements(self):
        """爬取币安公告页面（备选方案）"""
        announcements = []
        try:
            response = requests.get("https://www.binance.com/en/support/announcement/c-48")
            if response.status_code == 200:
                # 解析HTML获取公告信息
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 示例解析逻辑，实际需要根据页面结构调整
                announcement_items = soup.select('.css-1ej4hfo')
                
                for item in announcement_items:
                    try:
                        title_elem = item.select_one('.css-1nqr3jw')
                        date_elem = item.select_one('.css-1fobf8d')
                        link_elem = item.select_one('a')
                        
                        if title_elem and link_elem:
                            title = title_elem.text.strip()
                            date = date_elem.text.strip() if date_elem else ""
                            url = "https://www.binance.com" + link_elem['href'] if link_elem.has_attr('href') else ""
                            
                            announcements.append({
                                "id": hashlib.md5(title.encode()).hexdigest(),
                                "title": title,
                                "date": date,
                                "url": url,
                                "exchange": "binance"
                            })
                    except Exception as e:
                        logger.error(f"解析币安公告项失败: {e}")
                        
        except Exception as e:
            logger.error(f"爬取币安公告失败: {e}")
            
        return announcements
        
    def fetch_gate_announcements(self):
        """获取Gate最新公告"""
        # 检查是否应该请求API
        if not self.api_manager.should_request("gate_announcement"):
            logger.info("跳过Gate公告请求，未达到最小间隔")
            return []
            
        try:
            # Gate可能没有直接的API，使用爬虫获取
            announcements = self._scrape_gate_announcements()
            self.api_manager.record_request("gate_announcement")
            self.api_manager.reset_error("gate_announcement")
            return announcements
        except Exception as e:
            self.api_manager.record_error("gate_announcement", e)
            logger.error(f"获取Gate公告失败: {e}")
            
            # 如果失败，设置重试
            retry_delay = self.api_manager.get_retry_delay("gate_announcement")
            if retry_delay > 0:
                logger.info(f"将在{retry_delay}秒后重试")
                time.sleep(retry_delay)
                
            return []
            
    def _scrape_gate_announcements(self):
        """爬取Gate公告页面"""
        announcements = []
        try:
            # 英文公告页面
            response = requests.get("https://www.gate.io/article/announcements")
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # 示例解析逻辑，实际需要根据页面结构调整
                announcement_items = soup.select('.article-list li')
                
                for item in announcement_items:
                    try:
                        link_elem = item.select_one('a')
                        date_elem = item.select_one('.date')
                        
                        if link_elem:
                            title = link_elem.text.strip()
                            date = date_elem.text.strip() if date_elem else ""
                            url = "https://www.gate.io" + link_elem['href'] if link_elem.has_attr('href') else ""
                            
                            announcements.append({
                                "id": hashlib.md5(title.encode()).hexdigest(),
                                "title": title,
                                "date": date,
                                "url": url,
                                "exchange": "gate"
                            })
                    except Exception as e:
                        logger.error(f"解析Gate公告项失败: {e}")
                        
            # 也可以爬取中文公告页面
            response_cn = requests.get("https://www.gate.io/cn/article/announcements")
            if response_cn.status_code == 200:
                soup_cn = BeautifulSoup(response_cn.text, 'html.parser')
                
                # 类似的解析逻辑
                # ...
                
        except Exception as e:
            logger.error(f"爬取Gate公告失败: {e}")
            
        return announcements
        
    def filter_new_listings(self, announcements, exchange):
        """过滤新上币公告"""
        new_listings = []
        keywords = self.config.get("keywords", {}).get("listing", ["listing", "新币上线", "will list", "上线"])
        
        for announcement in announcements:
            title = announcement.get("title", "").lower()
            if any(keyword.lower() in title for keyword in keywords):
                new_listings.append(announcement)
                
        return new_listings
        
    def find_new_announcements(self, announcements, exchange):
        """找出新公告"""
        new_announcements = []
        existing_ids = [a["id"] for a in self.history[exchange]["announcements"]]
        
        for announcement in announcements:
            if announcement["id"] not in existing_ids:
                new_announcements.append(announcement)
                self.history[exchange]["announcements"].append({
                    "id": announcement["id"],
                    "title": announcement["title"],
                    "date": announcement.get("date", ""),
                    "url": announcement.get("url", ""),
                    "exchange": exchange
                })
                
        return new_announcements
        
    def find_new_listings(self, listings, exchange):
        """找出新上币公告"""
        new_listings = []
        existing_ids = [a["id"] for a in self.history[exchange]["new_listings"]]
        
        for listing in listings:
            if listing["id"] not in existing_ids:
                new_listings.append(listing)
                self.history[exchange]["new_listings"].append({
                    "id": listing["id"],
                    "title": listing["title"],
                    "date": listing.get("date", ""),
                    "url": listing.get("url", ""),
                    "exchange": exchange
                })
                
        return new_listings
        
    def check_announcements(self):
        """检查两个交易所的新公告"""
        results = {
            "binance": {"new_announcements": [], "new_listings": []},
            "gate": {"new_announcements": [], "new_listings": []}
        }
        
        # 检查币安公告
        binance_announcements = self.fetch_binance_announcements()
        if binance_announcements:
            binance_listings = self.filter_new_listings(binance_announcements, "binance")
            results["binance"]["new_announcements"] = self.find_new_announcements(binance_announcements, "binance")
            results["binance"]["new_listings"] = self.find_new_listings(binance_listings, "binance")
            
        # 检查Gate公告
        gate_announcements = self.fetch_gate_announcements()
        if gate_announcements:
            gate_listings = self.filter_new_listings(gate_announcements, "gate")
            results["gate"]["new_announcements"] = self.find_new_announcements(gate_announcements, "gate")
            results["gate"]["new_listings"] = self.find_new_listings(gate_listings, "gate")
            
        # 保存历史记录
        self.save_history()
        
        return results
```

### 公告格式化与推送

```python
# 公告格式化与推送伪代码（扩展自Telegram推送模块）
class MultiAccountTelegramNotifier:
    # ... 其他方法保持不变 ...
    
    def format_announcement(self, announcement):
        """格式化公告消息"""
        title = announcement["title"]
        url = announcement.get("url", "")
        date = announcement.get("date", "")
        exchange = announcement.get("exchange", "").capitalize()
        
        message = f"📢 *{exchange}最新公告* 📢\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def format_new_listing(self, listing):
        """格式化新上币公告消息"""
        title = listing["title"]
        url = listing.get("url", "")
        date = listing.get("date", "")
        exchange = listing.get("exchange", "").capitalize()
        
        message = f"🔥 *{exchange}新币上线* 🔥\n\n"
        message += f"*{title}*\n\n"
        if date:
            message += f"发布时间: `{date}`\n\n"
        if url:
            message += f"[查看详情]({url})"
            
        return message
        
    def notify_announcement(self, announcement):
        """发送公告通知"""
        message = self.format_announcement(announcement)
        return self.send_message(message, message_type="announcement")
        
    def notify_new_listing(self, listing):
        """发送新上币通知"""
        message = self.format_new_listing(listing)
        # 新上币是高优先级消息，发送到所有账号
        return self.send_message(message, message_type="new_listing", accounts="all")
```

### 主程序集成

```python
# 主程序集成伪代码
class CryptoMonitor:
    def __init__(self, config_file):
        self.config = self._load_config(config_file)
        self.api_manager = ApiPollingManager(self.config.get("api_polling", {}))
        self.price_monitor = PriceMonitor(self.config["price_monitor"], self.api_manager)
        self.announcement_monitor = DualExchangeAnnouncementMonitor(self.config["announcement_monitor"], self.api_manager)
        self.telegram_notifier = MultiAccountTelegramNotifier(self.config["telegram"])
        self.running = False
        self.last_announcement_check = 0
        
    # ... 其他方法保持不变 ...
    
    def check_announcements(self):
        """检查公告并发送通知"""
        current_time = time.time()
        announcement_interval = self.config["announcement_monitor"].get("check_interval", 3600)
        
        # 检查是否达到公告检查间隔
        if current_time - self.last_announcement_check < announcement_interval:
            time_to_next = announcement_interval - (current_time - self.last_announcement_check)
            logger.info(f"距离下次公告检查还有{time_to_next:.0f}秒")
            return 0
            
        try:
            results = self.announcement_monitor.check_announcements()
            self.last_announcement_check = current_time
            
            notification_count = 0
            
            # 处理币安公告
            for announcement in results["binance"]["new_announcements"]:
                self.telegram_notifier.notify_announcement(announcement)
                notification_count += 1
                
            for listing in results["binance"]["new_listings"]:
                self.telegram_notifier.notify_new_listing(listing)
                notification_count += 1
                
            # 处理Gate公告
            for announcement in results["gate"]["new_announcements"]:
                self.telegram_notifier.notify_announcement(announcement)
                notification_count += 1
                
            for listing in results["gate"]["new_listings"]:
                self.telegram_notifier.notify_new_listing(listing)
                notification_count += 1
                
            return notification_count
        except Exception as e:
            logger.error(f"公告检查失败: {e}")
            return 0
```

## 配置示例

```python
announcement_config = {
    "history_file": "data/announcement_history.json",
    "check_interval": 3600,  # 每小时检查一次
    "keywords": {
        "listing": ["listing", "新币上线", "will list", "上线", "new coin", "new token", "new cryptocurrency"],
        "important": ["update", "upgrade", "maintenance", "维护", "更新", "system", "trading", "fee", "deposit", "withdraw"]
    },
    "binance_announcement_min_interval": 3600,  # 币安公告最小请求间隔
    "gate_announcement_min_interval": 3600      # Gate公告最小请求间隔
}
```

## 实现细节与注意事项

### 1. Gate公告获取方式

Gate交易所可能没有提供官方API来获取公告，因此我们使用网页爬虫方式获取公告信息。这种方式有以下注意事项：

- 网页结构可能会变化，需要定期检查爬虫是否正常工作
- 可能需要处理反爬虫机制，如添加请求头、控制请求频率等
- 考虑同时爬取英文和中文公告页面，确保获取全面信息

### 2. 公告去重与历史记录

- 使用公告标题的MD5哈希作为唯一标识符
- 分别存储币安和Gate的公告历史，避免混淆
- 定期清理过旧的历史记录，避免文件过大

### 3. 错误处理与重试机制

- 对每个交易所的公告获取失败进行独立处理
- 实现指数退避重试，避免频繁失败请求
- 当一个交易所的公告获取失败时，不影响另一个交易所的处理

### 4. 多语言支持

- 考虑同时处理中英文公告
- 对于重要公告，可以使用翻译API提供双语版本
- 关键词过滤需同时支持中英文关键词

## 扩展建议

### 1. 公告内容分析

- 实现自然语言处理功能，分析公告内容的重要性
- 根据公告内容自动分类（维护公告、上币公告、活动公告等）
- 提取公告中的关键信息（如维护时间、上币时间等）

### 2. 公告影响预测

- 分析历史数据，预测公告对币价的潜在影响
- 对特别重要的公告（如大型升级、重大合作等）给予特殊标记
- 结合社交媒体反应，评估公告的市场影响力

### 3. 更多交易所支持

- 设计通用的公告监控接口，便于添加更多交易所
- 优先考虑添加OKX、Huobi等主流交易所
- 为不同交易所设置不同的检查频率和重要性级别
