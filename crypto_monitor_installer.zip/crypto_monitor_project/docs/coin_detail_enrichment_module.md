# 币种详情与市场信息聚合模块设计

## 功能概述

根据您的需求，我们设计了一个币种详情与市场信息聚合模块，用于在价格预警触发时收集并整合丰富的币种信息。该模块将从多个数据源获取信息，进行自动分析，并将完整内容提供给推送模块。主要功能包括：

1. 收集币种基础市场数据（涨跌幅、交易量、市值等）
2. 获取币种详细信息（币种简介、合约信息等）
3. 进行市场动态分析和涨跌原因分析
4. 收集相关链接（社交媒体、官网等）
5. 整合所有信息并格式化输出

## 模块设计

### 币种详情聚合器

```python
# 币种详情与市场信息聚合模块伪代码
class CoinDetailEnricher:
    def __init__(self, config, api_manager):
        self.config = config
        self.api_manager = api_manager
        self.binance_client = setup_binance_client(config)
        self.gate_client = setup_gate_client(config)
        self.coingecko_client = setup_coingecko_client(config)
        self.coinmarketcap_client = setup_coinmarketcap_client(config)
        self.cache = {}  # 缓存已获取的币种信息
        self.cache_expiry = {}  # 缓存过期时间
        self.cache_duration = config.get("cache_duration", 3600)  # 默认缓存1小时
        
    def enrich_alert(self, alert):
        """使用详细信息丰富价格预警"""
        symbol = alert["symbol"]
        exchange = alert["exchange"]
        
        # 检查缓存
        cache_key = f"{exchange}_{symbol}"
        if self._is_cache_valid(cache_key):
            logger.info(f"使用缓存的{symbol}信息")
            enriched_data = self.cache[cache_key]
            # 更新价格和涨跌幅信息
            enriched_data["price"] = alert["price"]
            enriched_data["change_24h"] = alert["change"]
            return {**alert, **enriched_data}
            
        # 收集完整信息
        try:
            # 1. 获取基础市场数据
            market_data = self._get_market_data(symbol, exchange)
            
            # 2. 获取币种详细信息
            coin_info = self._get_coin_info(symbol)
            
            # 3. 获取合约信息
            contract_info = self._get_contract_info(symbol)
            
            # 4. 分析涨跌原因
            price_analysis = self._analyze_price_movement(symbol, alert["change"], market_data)
            
            # 5. 获取外部分析
            external_analysis = self._get_external_analysis(symbol)
            
            # 6. 获取相关链接
            links = self._get_coin_links(symbol)
            
            # 整合所有信息
            enriched_data = {
                **market_data,
                "coin_info": coin_info,
                "contract_info": contract_info,
                "price_analysis": price_analysis,
                "external_analysis": external_analysis,
                "links": links
            }
            
            # 更新缓存
            self._update_cache(cache_key, enriched_data)
            
            # 返回丰富的预警信息
            return {**alert, **enriched_data}
        except Exception as e:
            logger.error(f"丰富{symbol}信息失败: {e}")
            # 如果丰富信息失败，仍返回原始预警
            return alert
            
    def _is_cache_valid(self, key):
        """检查缓存是否有效"""
        if key not in self.cache or key not in self.cache_expiry:
            return False
            
        current_time = time.time()
        return current_time < self.cache_expiry[key]
        
    def _update_cache(self, key, data):
        """更新缓存"""
        self.cache[key] = data
        self.cache_expiry[key] = time.time() + self.cache_duration
        
        # 清理过期缓存
        expired_keys = [k for k, v in self.cache_expiry.items() if time.time() > v]
        for k in expired_keys:
            if k in self.cache:
                del self.cache[k]
            del self.cache_expiry[k]
            
    def _get_market_data(self, symbol, exchange):
        """获取市场数据"""
        market_data = {
            "volume_24h": None,
            "market_cap": None,
            "circulating_supply": None,
            "total_supply": None,
            "rank": None,
            "ath": None,
            "atl": None
        }
        
        # 尝试从交易所API获取
        try:
            if exchange.lower() == "binance":
                ticker_24h = self.binance_client.get_ticker(symbol=symbol.replace("/", ""))
                market_data["volume_24h"] = float(ticker_24h["quoteVolume"])
            elif exchange.lower() == "gate":
                ticker_24h = self.gate_client.get_ticker(symbol.replace("/", "_"))
                market_data["volume_24h"] = float(ticker_24h["quote_volume"])
        except Exception as e:
            logger.error(f"从{exchange}获取{symbol}市场数据失败: {e}")
            
        # 如果交易所数据不完整，尝试从CoinGecko获取
        if None in market_data.values():
            try:
                # 将交易对符号转换为CoinGecko格式
                base_symbol = symbol.split('/')[0].lower()
                coin_data = self.coingecko_client.get_coin_by_symbol(base_symbol)
                
                if coin_data:
                    market_data["market_cap"] = coin_data["market_data"]["market_cap"]["usd"]
                    market_data["volume_24h"] = market_data["volume_24h"] or coin_data["market_data"]["total_volume"]["usd"]
                    market_data["circulating_supply"] = coin_data["market_data"]["circulating_supply"]
                    market_data["total_supply"] = coin_data["market_data"]["total_supply"]
                    market_data["rank"] = coin_data["market_cap_rank"]
                    market_data["ath"] = coin_data["market_data"]["ath"]["usd"]
                    market_data["atl"] = coin_data["market_data"]["atl"]["usd"]
            except Exception as e:
                logger.error(f"从CoinGecko获取{symbol}市场数据失败: {e}")
                
        # 如果仍有缺失数据，尝试从CoinMarketCap获取
        if None in market_data.values():
            try:
                base_symbol = symbol.split('/')[0].upper()
                coin_data = self.coinmarketcap_client.get_coin_by_symbol(base_symbol)
                
                if coin_data:
                    market_data["market_cap"] = market_data["market_cap"] or coin_data["quote"]["USD"]["market_cap"]
                    market_data["volume_24h"] = market_data["volume_24h"] or coin_data["quote"]["USD"]["volume_24h"]
                    market_data["circulating_supply"] = market_data["circulating_supply"] or coin_data["circulating_supply"]
                    market_data["total_supply"] = market_data["total_supply"] or coin_data["total_supply"]
                    market_data["rank"] = market_data["rank"] or coin_data["cmc_rank"]
            except Exception as e:
                logger.error(f"从CoinMarketCap获取{symbol}市场数据失败: {e}")
                
        return market_data
        
    def _get_coin_info(self, symbol):
        """获取币种详细信息"""
        coin_info = {
            "name": None,
            "description": None,
            "categories": [],
            "launch_date": None,
            "algorithm": None,
            "proof_type": None
        }
        
        # 尝试从CoinGecko获取
        try:
            base_symbol = symbol.split('/')[0].lower()
            coin_data = self.coingecko_client.get_coin_by_symbol(base_symbol)
            
            if coin_data:
                coin_info["name"] = coin_data["name"]
                coin_info["description"] = coin_data["description"]["en"][:500] + "..." if len(coin_data["description"]["en"]) > 500 else coin_data["description"]["en"]
                coin_info["categories"] = coin_data["categories"]
                coin_info["algorithm"] = coin_data.get("hashing_algorithm")
                coin_info["proof_type"] = coin_data.get("proof_type")
        except Exception as e:
            logger.error(f"从CoinGecko获取{symbol}详细信息失败: {e}")
            
        # 如果数据不完整，尝试从CoinMarketCap获取
        if None in [coin_info["name"], coin_info["description"]]:
            try:
                base_symbol = symbol.split('/')[0].upper()
                coin_data = self.coinmarketcap_client.get_coin_metadata(base_symbol)
                
                if coin_data:
                    coin_info["name"] = coin_info["name"] or coin_data["name"]
                    coin_info["description"] = coin_info["description"] or (coin_data["description"][:500] + "..." if len(coin_data["description"]) > 500 else coin_data["description"])
                    coin_info["launch_date"] = coin_data.get("date_launched")
                    if "category" in coin_data and coin_data["category"]:
                        coin_info["categories"].append(coin_data["category"])
            except Exception as e:
                logger.error(f"从CoinMarketCap获取{symbol}详细信息失败: {e}")
                
        return coin_info
        
    def _get_contract_info(self, symbol):
        """获取合约信息"""
        contract_info = {
            "platform": None,
            "contract_address": None,
            "decimals": None
        }
        
        # 尝试从CoinGecko获取
        try:
            base_symbol = symbol.split('/')[0].lower()
            coin_data = self.coingecko_client.get_coin_by_symbol(base_symbol)
            
            if coin_data and "platforms" in coin_data:
                platforms = coin_data["platforms"]
                # 优先获取以太坊合约
                if "ethereum" in platforms and platforms["ethereum"]:
                    contract_info["platform"] = "Ethereum"
                    contract_info["contract_address"] = platforms["ethereum"]
                # 其次获取其他主流平台
                elif "binance-smart-chain" in platforms and platforms["binance-smart-chain"]:
                    contract_info["platform"] = "Binance Smart Chain"
                    contract_info["contract_address"] = platforms["binance-smart-chain"]
                elif "polygon-pos" in platforms and platforms["polygon-pos"]:
                    contract_info["platform"] = "Polygon"
                    contract_info["contract_address"] = platforms["polygon-pos"]
                # 如果有任何平台的合约
                else:
                    for platform, address in platforms.items():
                        if address:
                            contract_info["platform"] = platform
                            contract_info["contract_address"] = address
                            break
        except Exception as e:
            logger.error(f"从CoinGecko获取{symbol}合约信息失败: {e}")
            
        # 如果数据不完整，尝试从其他来源获取
        if None in [contract_info["platform"], contract_info["contract_address"]]:
            try:
                # 这里可以添加其他来源的合约信息获取逻辑
                pass
            except Exception as e:
                logger.error(f"获取{symbol}合约信息失败: {e}")
                
        return contract_info
        
    def _analyze_price_movement(self, symbol, change_percent, market_data):
        """分析价格变动原因"""
        analysis = {
            "summary": None,
            "factors": [],
            "sentiment": None,
            "technical_indicators": {}
        }
        
        # 基于变动幅度生成基础分析
        if change_percent > 0:
            if change_percent > 20:
                analysis["summary"] = f"{symbol}价格大幅上涨{change_percent:.2f}%"
                analysis["sentiment"] = "极度看涨"
            elif change_percent > 10:
                analysis["summary"] = f"{symbol}价格显著上涨{change_percent:.2f}%"
                analysis["sentiment"] = "看涨"
            else:
                analysis["summary"] = f"{symbol}价格小幅上涨{change_percent:.2f}%"
                analysis["sentiment"] = "略微看涨"
        else:
            if change_percent < -20:
                analysis["summary"] = f"{symbol}价格大幅下跌{abs(change_percent):.2f}%"
                analysis["sentiment"] = "极度看跌"
            elif change_percent < -10:
                analysis["summary"] = f"{symbol}价格显著下跌{abs(change_percent):.2f}%"
                analysis["sentiment"] = "看跌"
            else:
                analysis["summary"] = f"{symbol}价格小幅下跌{abs(change_percent):.2f}%"
                analysis["sentiment"] = "略微看跌"
                
        # 分析可能的因素
        factors = []
        
        # 检查交易量变化
        if market_data["volume_24h"]:
            # 这里假设我们有历史交易量数据进行比较
            # 实际实现中需要存储历史数据
            volume_change = 0  # 这里应该计算实际的交易量变化
            if volume_change > 50:
                factors.append("交易量大幅增加，可能有重大消息或机构参与")
            elif volume_change > 20:
                factors.append("交易量明显增加，市场兴趣提升")
                
        # 检查市场整体趋势
        # 这里需要获取市场整体数据
        market_trend = "上涨"  # 实际实现中应该获取真实市场趋势
        if market_trend == "上涨" and change_percent > 0:
            factors.append("顺应整体市场上涨趋势")
        elif market_trend == "下跌" and change_percent < 0:
            factors.append("跟随整体市场下跌趋势")
        elif market_trend == "上涨" and change_percent < 0:
            factors.append("逆市下跌，可能有负面消息影响")
        elif market_trend == "下跌" and change_percent > 0:
            factors.append("逆市上涨，可能有利好消息")
            
        # 检查是否接近历史高点或低点
        if market_data["ath"] and market_data["price"]:
            ath_distance = (market_data["ath"] - market_data["price"]) / market_data["ath"] * 100
            if ath_distance < 5:
                factors.append(f"接近历史最高价，距ATH仅{ath_distance:.2f}%")
                
        if market_data["atl"] and market_data["price"]:
            atl_distance = (market_data["price"] - market_data["atl"]) / market_data["price"] * 100
            if atl_distance < 5:
                factors.append(f"接近历史最低价，距ATL仅{atl_distance:.2f}%")
                
        # 添加技术指标分析
        # 这里需要实际计算技术指标
        analysis["technical_indicators"] = {
            "rsi": 65,  # 示例值，实际应计算
            "macd": "看涨",  # 示例值，实际应计算
            "ma_cross": "金叉"  # 示例值，实际应计算
        }
        
        if analysis["technical_indicators"]["rsi"] > 70:
            factors.append("RSI超买，可能面临回调风险")
        elif analysis["technical_indicators"]["rsi"] < 30:
            factors.append("RSI超卖，可能出现反弹机会")
            
        if analysis["technical_indicators"]["macd"] == "看涨":
            factors.append("MACD指标看涨，动能增强")
        elif analysis["technical_indicators"]["macd"] == "看跌":
            factors.append("MACD指标看跌，动能减弱")
            
        if analysis["technical_indicators"]["ma_cross"] == "金叉":
            factors.append("均线金叉，可能开始上升趋势")
        elif analysis["technical_indicators"]["ma_cross"] == "死叉":
            factors.append("均线死叉，可能开始下降趋势")
            
        analysis["factors"] = factors
        
        return analysis
        
    def _get_external_analysis(self, symbol):
        """获取外部分析内容"""
        external_analysis = {
            "news": [],
            "social_sentiment": None,
            "analyst_opinions": []
        }
        
        # 获取相关新闻
        try:
            base_symbol = symbol.split('/')[0]
            news_items = self._fetch_crypto_news(base_symbol)
            external_analysis["news"] = news_items[:3]  # 最多3条新闻
        except Exception as e:
            logger.error(f"获取{symbol}相关新闻失败: {e}")
            
        # 获取社交媒体情绪
        try:
            sentiment = self._fetch_social_sentiment(base_symbol)
            external_analysis["social_sentiment"] = sentiment
        except Exception as e:
            logger.error(f"获取{symbol}社交媒体情绪失败: {e}")
            
        # 获取分析师观点
        try:
            opinions = self._fetch_analyst_opinions(base_symbol)
            external_analysis["analyst_opinions"] = opinions[:2]  # 最多2条分析师观点
        except Exception as e:
            logger.error(f"获取{symbol}分析师观点失败: {e}")
            
        return external_analysis
        
    def _fetch_crypto_news(self, coin_symbol):
        """获取加密货币相关新闻"""
        news = []
        
        # 尝试从CryptoCompare获取新闻
        try:
            url = f"https://min-api.cryptocompare.com/data/v2/news/?categories={coin_symbol.lower()}&excludeCategories=Sponsored"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                if "Data" in data:
                    for item in data["Data"][:5]:  # 最多获取5条
                        news.append({
                            "title": item["title"],
                            "url": item["url"],
                            "source": item["source"],
                            "published_at": item["published_on"]
                        })
        except Exception as e:
            logger.error(f"从CryptoCompare获取{coin_symbol}新闻失败: {e}")
            
        # 如果没有获取到足够的新闻，尝试其他来源
        if len(news) < 3:
            try:
                # 这里可以添加其他新闻源的获取逻辑
                pass
            except Exception as e:
                logger.error(f"获取{coin_symbol}新闻失败: {e}")
                
        return news
        
    def _fetch_social_sentiment(self, coin_symbol):
        """获取社交媒体情绪"""
        sentiment = {
            "overall": None,
            "twitter": None,
            "reddit": None,
            "telegram": None
        }
        
        # 尝试从Santiment或类似API获取社交情绪
        try:
            # 这里应该实现实际的社交情绪获取逻辑
            # 示例数据
            sentiment["overall"] = "中性偏多"
            sentiment["twitter"] = "看涨"
            sentiment["reddit"] = "中性"
            sentiment["telegram"] = "看涨"
        except Exception as e:
            logger.error(f"获取{coin_symbol}社交情绪失败: {e}")
            
        return sentiment
        
    def _fetch_analyst_opinions(self, coin_symbol):
        """获取分析师观点"""
        opinions = []
        
        # 尝试从TradingView或类似平台获取分析师观点
        try:
            # 这里应该实现实际的分析师观点获取逻辑
            # 示例数据
            opinions = [
                {
                    "analyst": "CryptoAnalyst1",
                    "opinion": "看涨",
                    "target_price": "预计30天内上涨15%",
                    "source": "TradingView"
                },
                {
                    "analyst": "TokenExpert",
                    "opinion": "中性",
                    "target_price": "预计维持当前价格区间",
                    "source": "CoinDesk"
                }
            ]
        except Exception as e:
            logger.error(f"获取{coin_symbol}分析师观点失败: {e}")
            
        return opinions
        
    def _get_coin_links(self, symbol):
        """获取币种相关链接"""
        links = {
            "website": None,
            "twitter": None,
            "telegram": None,
            "github": None,
            "explorer": None
        }
        
        # 尝试从CoinGecko获取链接
        try:
            base_symbol = symbol.split('/')[0].lower()
            coin_data = self.coingecko_client.get_coin_by_symbol(base_symbol)
            
            if coin_data and "links" in coin_data:
                if "homepage" in coin_data["links"] and coin_data["links"]["homepage"]:
                    links["website"] = coin_data["links"]["homepage"][0]
                if "twitter_screen_name" in coin_data["links"] and coin_data["links"]["twitter_screen_name"]:
                    links["twitter"] = f"https://twitter.com/{coin_data['links']['twitter_screen_name']}"
                if "telegram_channel_identifier" in coin_data["links"] and coin_data["links"]["telegram_channel_identifier"]:
                    links["telegram"] = f"https://t.me/{coin_data['links']['telegram_channel_identifier']}"
                if "repos_url" in coin_data["links"] and "github" in coin_data["links"]["repos_url"]:
                    links["github"] = coin_data["links"]["repos_url"]["github"][0] if coin_data["links"]["repos_url"]["github"] else None
                
                # 获取区块浏览器链接
                if "blockchain_site" in coin_data["links"] and coin_data["links"]["blockchain_site"]:
                    for site in coin_data["links"]["blockchain_site"]:
                        if site:
                            links["explorer"] = site
                            break
        except Exception as e:
            logger.error(f"从CoinGecko获取{symbol}链接失败: {e}")
            
        # 如果数据不完整，尝试从CoinMarketCap获取
        if None in links.values():
            try:
                base_symbol = symbol.split('/')[0].upper()
                coin_data = self.coinmarketcap_client.get_coin_metadata(base_symbol)
                
                if coin_data and "urls" in coin_data:
                    if "website" in coin_data["urls"] and coin_data["urls"]["website"]:
                        links["website"] = links["website"] or coin_data["urls"]["website"][0]
                    if "twitter" in coin_data["urls"] and coin_data["urls"]["twitter"]:
                        links["twitter"] = links["twitter"] or coin_data["urls"]["twitter"][0]
                    if "chat" in coin_data["urls"] and coin_data["urls"]["chat"]:
                        for chat in coin_data["urls"]["chat"]:
                            if "telegram" in chat or "t.me" in chat:
                                links["telegram"] = links["telegram"] or chat
                                break
                    if "source_code" in coin_data["urls"] and coin_data["urls"]["source_code"]:
                        links["github"] = links["github"] or coin_data["urls"]["source_code"][0]
                    if "explorer" in coin_data["urls"] and coin_data["urls"]["explorer"]:
                        links["explorer"] = links["explorer"] or coin_data["urls"]["explorer"][0]
            except Exception as e:
                logger.error(f"从CoinMarketCap获取{symbol}链接失败: {e}")
                
        return links
```

### 第三方API客户端

```python
# CoinGecko API客户端伪代码
class CoinGeckoClient:
    def __init__(self, config):
        self.api_key = config.get("coingecko_api_key")
        self.base_url = "https://api.coingecko.com/api/v3"
        self.pro_url = "https://pro-api.coingecko.com/api/v3"
        self.use_pro = self.api_key is not None
        self.coin_list = None
        self.last_update = 0
        self.update_interval = 3600  # 每小时更新一次币种列表
        
    def _get_url(self):
        """获取API URL"""
        return self.pro_url if self.use_pro else self.base_url
        
    def _get_headers(self):
        """获取请求头"""
        headers = {}
        if self.use_pro:
            headers["x-cg-pro-api-key"] = self.api_key
        return headers
        
    def _update_coin_list(self):
        """更新币种列表"""
        current_time = time.time()
        if self.coin_list is None or current_time - self.last_update > self.update_interval:
            url = f"{self._get_url()}/coins/list"
            response = requests.get(url, headers=self._get_headers())
            if response.status_code == 200:
                self.coin_list = response.json()
                self.last_update = current_time
                
    def get_coin_id(self, symbol):
        """根据符号获取币种ID"""
        self._update_coin_list()
        if not self.coin_list:
            return None
            
        symbol = symbol.lower()
        for coin in self.coin_list:
            if coin["symbol"] == symbol:
                return coin["id"]
                
        return None
        
    def get_coin_by_symbol(self, symbol):
        """根据符号获取币种信息"""
        coin_id = self.get_coin_id(symbol)
        if not coin_id:
            return None
            
        url = f"{self._get_url()}/coins/{coin_id}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false"
        response = requests.get(url, headers=self._get_headers())
        if response.status_code == 200:
            return response.json()
            
        return None
        
    def get_coin_market_chart(self, symbol, days=1):
        """获取币种市场图表数据"""
        coin_id = self.get_coin_id(symbol)
        if not coin_id:
            return None
            
        url = f"{self._get_url()}/coins/{coin_id}/market_chart?vs_currency=usd&days={days}"
        response = requests.get(url, headers=self._get_headers())
        if response.status_code == 200:
            return response.json()
            
        return None

# CoinMarketCap API客户端伪代码
class CoinMarketCapClient:
    def __init__(self, config):
        self.api_key = config.get("coinmarketcap_api_key")
        self.base_url = "https://pro-api.coinmarketcap.com/v1"
        self.headers = {
            "X-CMC_PRO_API_KEY": self.api_key,
            "Accept": "application/json"
        }
        self.symbol_map = {}
        self.last_update = 0
        self.update_interval = 3600  # 每小时更新一次映射
        
    def _update_symbol_map(self):
        """更新符号映射"""
        current_time = time.time()
        if not self.symbol_map or current_time - self.last_update > self.update_interval:
            url = f"{self.base_url}/cryptocurrency/map"
            response = requests.get(url, headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                if "data" in data:
                    self.symbol_map = {item["symbol"]: item["id"] for item in data["data"]}
                    self.last_update = current_time
                    
    def get_coin_id(self, symbol):
        """根据符号获取币种ID"""
        self._update_symbol_map()
        return self.symbol_map.get(symbol.upper())
        
    def get_coin_by_symbol(self, symbol):
        """根据符号获取币种信息"""
        coin_id = self.get_coin_id(symbol)
        if not coin_id:
            return None
            
        url = f"{self.base_url}/cryptocurrency/quotes/latest"
        params = {
            "id": coin_id,
            "convert": "USD"
        }
        
        response = requests.get(url, headers=self.headers, params=params)
        if response.status_code == 200:
            data = response.json()
            if "data" in data and str(coin_id) in data["data"]:
                return data["data"][str(coin_id)]
                
        return None
        
    def get_coin_metadata(self, symbol):
        """获取币种元数据"""
        coin_id = self.get_coin_id(symbol)
        if not coin_id:
            return None
            
        url = f"{self.base_url}/cryptocurrency/info"
        params = {
            "id": coin_id
        }
        
        response = requests.get(url, headers=self.headers, params=params)
        if response.status_code == 200:
            data = response.json()
            if "data" in data and str(coin_id) in data["data"]:
                return data["data"][str(coin_id)]
                
        return None
```

### 与其他模块的集成

```python
# 与价格监控模块集成伪代码
class PriceMonitor:
    # ... 原有代码 ...
    
    def check_price_alerts(self, prices):
        """检查价格预警"""
        alerts = []
        
        for exchange, exchange_prices in prices.items():
            for symbol, data in exchange_prices.items():
                # 检查24小时涨跌幅
                if "change_24h" in data and abs(data["change_24h"]) > self.thresholds.get("change_24h", 10):
                    alerts.append({
                        "exchange": exchange,
                        "symbol": symbol,
                        "price": data["price"],
                        "change": data["change_24h"],
                        "type": "24h_change"
                    })
                    
                # ... 其他检查 ...
                    
        return alerts

# 与Telegram推送模块集成伪代码
class MultiAccountTelegramNotifier:
    # ... 原有代码 ...
    
    def format_enriched_price_alert(self, enriched_alert):
        """格式化丰富的价格预警消息"""
        exchange = enriched_alert["exchange"].capitalize()
        symbol = enriched_alert["symbol"]
        price = enriched_alert["price"]
        change = enriched_alert["change"]
        
        if change > 0:
            direction = "上涨"
            emoji = "🚀"
        else:
            direction = "下跌"
            emoji = "📉"
            
        # 基本价格信息
        message = f"{emoji} *价格预警* {emoji}\n\n"
        message += f"交易所: `{exchange}`\n"
        message += f"币种: `{symbol}`\n"
        message += f"{direction}: `{abs(change)}%`\n"
        message += f"当前价格: `{price}`\n\n"
        
        # 添加市场数据
        if "volume_24h" in enriched_alert:
            message += f"*市场数据*\n"
            if enriched_alert["volume_24h"]:
                message += f"24小时交易量: `${self._format_number(enriched_alert['volume_24h'])}`\n"
            if enriched_alert.get("market_cap"):
                message += f"市值: `${self._format_number(enriched_alert['market_cap'])}`\n"
            if enriched_alert.get("rank"):
                message += f"市值排名: `#{enriched_alert['rank']}`\n"
            if enriched_alert.get("circulating_supply"):
                message += f"流通供应量: `{self._format_number(enriched_alert['circulating_supply'])} {symbol.split('/')[0]}`\n"
            message += "\n"
            
        # 添加币种信息
        if "coin_info" in enriched_alert and enriched_alert["coin_info"]["description"]:
            message += f"*币种简介*\n"
            message += f"{enriched_alert['coin_info']['description']}\n\n"
            
        # 添加合约信息
        if "contract_info" in enriched_alert and enriched_alert["contract_info"]["platform"]:
            message += f"*合约信息*\n"
            message += f"平台: `{enriched_alert['contract_info']['platform']}`\n"
            message += f"合约地址: `{enriched_alert['contract_info']['contract_address']}`\n\n"
            
        # 添加价格分析
        if "price_analysis" in enriched_alert and enriched_alert["price_analysis"]["summary"]:
            message += f"*价格分析*\n"
            message += f"{enriched_alert['price_analysis']['summary']}\n"
            
            if enriched_alert["price_analysis"]["factors"]:
                message += "\n*可能因素*:\n"
                for factor in enriched_alert["price_analysis"]["factors"]:
                    message += f"- {factor}\n"
            message += "\n"
            
        # 添加外部分析
        if "external_analysis" in enriched_alert:
            ext = enriched_alert["external_analysis"]
            
            # 添加新闻
            if ext["news"]:
                message += f"*相关新闻*\n"
                for news in ext["news"]:
                    message += f"- [{news['title']}]({news['url']})\n"
                message += "\n"
                
            # 添加社交情绪
            if ext["social_sentiment"] and ext["social_sentiment"]["overall"]:
                message += f"*社交媒体情绪*: {ext['social_sentiment']['overall']}\n\n"
                
            # 添加分析师观点
            if ext["analyst_opinions"]:
                message += f"*分析师观点*\n"
                for opinion in ext["analyst_opinions"]:
                    message += f"- {opinion['analyst']} ({opinion['source']}): {opinion['opinion']}, {opinion['target_price']}\n"
                message += "\n"
                
        # 添加相关链接
        if "links" in enriched_alert:
            message += f"*相关链接*\n"
            links = enriched_alert["links"]
            
            if links["website"]:
                message += f"[官网]({links['website']}) | "
            if links["twitter"]:
                message += f"[Twitter]({links['twitter']}) | "
            if links["telegram"]:
                message += f"[Telegram]({links['telegram']}) | "
            if links["github"]:
                message += f"[GitHub]({links['github']}) | "
            if links["explorer"]:
                message += f"[区块浏览器]({links['explorer']})"
                
        return message
        
    def _format_number(self, number):
        """格式化数字"""
        if number is None:
            return "N/A"
            
        if number >= 1_000_000_000:
            return f"{number / 1_000_000_000:.2f}B"
        elif number >= 1_000_000:
            return f"{number / 1_000_000:.2f}M"
        elif number >= 1_000:
            return f"{number / 1_000:.2f}K"
        else:
            return f"{number:.2f}"
            
    def notify_enriched_price_alert(self, enriched_alert):
        """发送丰富的价格预警通知"""
        # 检查是否需要限流
        symbol = enriched_alert["symbol"]
        alert_type = enriched_alert["type"]
        key = f"{symbol}_{alert_type}"
        
        current_time = time.time()
        if key in self.last_notification_time:
            time_diff = current_time - self.last_notification_time[key]
            min_interval = self.config.get("min_alert_interval", 300)  # 默认5分钟
            
            if time_diff < min_interval:
                logger.info(f"跳过{symbol}的{alert_type}预警，距离上次通知仅{time_diff}秒")
                return False
                
        message = self.format_enriched_price_alert(enriched_alert)
        
        # 根据预警类型确定发送账号
        if alert_type == "24h_change" and abs(enriched_alert["change"]) > 20:
            # 大幅波动，发送到所有账号
            result = self.send_message(message, message_type="major_price_alert", accounts="all")
        else:
            # 普通波动，使用默认路由
            result = self.send_message(message, message_type="price_alert")
            
        if result:
            self.last_notification_time[key] = current_time
            
        return result
```

### 主程序集成

```python
# 主程序集成伪代码
class CryptoMonitor:
    def __init__(self, config_file):
        self.config = self._load_config(config_file)
        self.api_manager = ApiPollingManager(self.config.get("api_polling", {}))
        self.price_monitor = PriceMonitor(self.config["price_monitor"], self.api_manager)
        self.announcement_monitor = DualExchangeAnnouncementMonitor(self.config["announcement_monitor"], self.api_manager)
        self.coin_enricher = CoinDetailEnricher(self.config["coin_enricher"], self.api_manager)
        self.telegram_notifier = MultiAccountTelegramNotifier(self.config["telegram"])
        self.running = False
        self.last_announcement_check = 0
        
    # ... 其他方法 ...
    
    def check_prices(self):
        """检查价格并发送预警"""
        try:
            prices = self.price_monitor.fetch_prices()
            if not prices:
                logger.info("没有获取到价格数据")
                return 0
                
            # 计算市场波动性，用于调整轮询间隔
            market_volatility = self.price_monitor.calculate_market_volatility(prices)
            next_interval = self.api_manager.calculate_adaptive_interval(market_volatility)
            logger.info(f"市场波动性: {market_volatility:.2f}%, 下次轮询间隔: {next_interval}秒")
            
            # 检查价格预警
            alerts = self.price_monitor.check_price_alerts(prices)
            
            alert_count = 0
            for alert in alerts:
                # 丰富预警信息
                enriched_alert = self.coin_enricher.enrich_alert(alert)
                
                # 发送丰富的预警通知
                if self.telegram_notifier.notify_enriched_price_alert(enriched_alert):
                    alert_count += 1
                    
            return alert_count
        except Exception as e:
            logger.error(f"价格检查失败: {e}")
            self.telegram_notifier.send_system_message(f"价格监控失败: {str(e)}", level="error")
            return 0
```

## 配置示例

```python
coin_enricher_config = {
    "cache_duration": 3600,  # 缓存时间（秒）
    "coingecko_api_key": "YOUR_COINGECKO_API_KEY",  # 可选，使用免费API时留空
    "coinmarketcap_api_key": "YOUR_COINMARKETCAP_API_KEY",
    "cryptocompare_api_key": "YOUR_CRYPTOCOMPARE_API_KEY",  # 可选
    "santiment_api_key": "YOUR_SANTIMENT_API_KEY",  # 可选
    "max_description_length": 500,  # 币种描述最大长度
    "max_news_items": 3,  # 最大新闻条数
    "max_analyst_opinions": 2,  # 最大分析师观点数
    "technical_indicators": ["rsi", "macd", "ma_cross"],  # 要计算的技术指标
    "enable_social_sentiment": true,  # 是否启用社交情绪分析
    "enable_news": true,  # 是否启用新闻获取
    "enable_analyst_opinions": true  # 是否启用分析师观点获取
}
```

## 实现细节与注意事项

### 1. 数据源选择与优先级

按照您的要求，我们设计了以下数据源优先级：

1. **交易所官方API**：
   - 币安API和Gate API用于获取基础价格和交易量数据
   - 这些API通常有速率限制，需要合理控制请求频率

2. **知名加密货币数据平台**：
   - CoinGecko：提供全面的币种信息、市场数据和链接
   - CoinMarketCap：提供市值排名、币种描述和元数据
   - CryptoCompare：提供新闻和社交媒体数据

3. **其他第三方数据源**：
   - Santiment：提供社交媒体情绪分析
   - TradingView：提供技术分析和分析师观点
   - 区块链浏览器API：提供合约信息和链上数据

### 2. 缓存机制

为了减少API调用并提高响应速度，我们实现了多层缓存机制：

- **币种信息缓存**：币种基本信息和链接缓存1小时
- **市场数据缓存**：价格和交易量等实时性较高的数据缓存时间较短
- **分析内容缓存**：新闻和分析师观点等内容缓存时间适中
- **智能缓存失效**：当检测到大幅价格变动时，自动使部分缓存失效

### 3. 错误处理与降级策略

系统设计了完善的错误处理和降级策略：

- **多源备份**：当主要数据源不可用时，自动切换到备用数据源
- **部分数据降级**：当无法获取完整信息时，仍返回已获取的部分数据
- **错误隔离**：单个数据源的错误不影响整体功能
- **重试机制**：对临时性错误实现智能重试

### 4. 自动分析算法

价格变动原因分析基于多种因素：

- **技术指标**：RSI、MACD、移动平均线等指标计算
- **交易量分析**：交易量变化与价格变化的相关性
- **市场对比**：与整体市场趋势的对比
- **历史模式识别**：识别类似的历史价格模式
- **关键水平分析**：支撑位、阻力位、历史高低点等

### 5. 外部内容抓取

系统从多个来源抓取外部分析内容：

- **新闻API**：从专业加密货币新闻API获取相关新闻
- **社交媒体**：分析Twitter、Reddit等平台上的讨论热度和情绪
- **分析师观点**：从专业分析平台获取分析师预测
- **内容过滤**：过滤低质量内容，优先展示高质量分析

## 扩展功能

### 1. 高级技术分析

可以扩展系统以提供更深入的技术分析：

```python
def perform_advanced_technical_analysis(self, symbol, historical_data):
    """执行高级技术分析"""
    analysis = {
        "support_levels": [],
        "resistance_levels": [],
        "patterns": [],
        "indicators": {}
    }
    
    # 计算支撑位和阻力位
    analysis["support_levels"] = self._calculate_support_levels(historical_data)
    analysis["resistance_levels"] = self._calculate_resistance_levels(historical_data)
    
    # 识别图表形态
    analysis["patterns"] = self._identify_chart_patterns(historical_data)
    
    # 计算高级指标
    analysis["indicators"]["rsi"] = self._calculate_rsi(historical_data)
    analysis["indicators"]["macd"] = self._calculate_macd(historical_data)
    analysis["indicators"]["bollinger_bands"] = self._calculate_bollinger_bands(historical_data)
    analysis["indicators"]["fibonacci_retracement"] = self._calculate_fibonacci_retracement(historical_data)
    
    return analysis
```

### 2. 链上数据分析

可以添加链上数据分析，提供更全面的币种信息：

```python
def get_on_chain_data(self, symbol, contract_info):
    """获取链上数据"""
    on_chain_data = {
        "active_addresses": None,
        "transaction_volume": None,
        "large_transactions": [],
        "holder_distribution": {},
        "token_age": None
    }
    
    if not contract_info["contract_address"]:
        return on_chain_data
        
    platform = contract_info["platform"].lower()
    address = contract_info["contract_address"]
    
    try:
        if platform == "ethereum":
            # 使用Etherscan API获取以太坊链上数据
            on_chain_data = self._get_ethereum_data(address)
        elif platform == "binance-smart-chain":
            # 使用BscScan API获取BSC链上数据
            on_chain_data = self._get_bsc_data(address)
        # 添加其他链的支持
    except Exception as e:
        logger.error(f"获取{symbol}链上数据失败: {e}")
        
    return on_chain_data
```

### 3. 市场情绪指标

可以添加市场情绪指标，帮助用户理解整体市场环境：

```python
def get_market_sentiment_indicators(self):
    """获取市场情绪指标"""
    sentiment = {
        "fear_greed_index": None,
        "btc_dominance": None,
        "market_trend": None,
        "funding_rates": {},
        "liquidations": {}
    }
    
    try:
        # 获取恐慌贪婪指数
        response = requests.get("https://api.alternative.me/fng/")
        if response.status_code == 200:
            data = response.json()
            sentiment["fear_greed_index"] = {
                "value": int(data["data"][0]["value"]),
                "classification": data["data"][0]["value_classification"]
            }
            
        # 获取BTC市场占比
        response = requests.get("https://api.coingecko.com/api/v3/global")
        if response.status_code == 200:
            data = response.json()
            sentiment["btc_dominance"] = data["data"]["market_cap_percentage"]["btc"]
            
        # 其他市场情绪指标...
    except Exception as e:
        logger.error(f"获取市场情绪指标失败: {e}")
        
    return sentiment
```

## 总结

币种详情与市场信息聚合模块提供了一个全面的解决方案，可以在价格预警触发时收集并整合丰富的币种信息。该模块从多个数据源获取信息，进行自动分析，并将完整内容提供给推送模块。

主要优势包括：

1. **多源数据整合**：从交易所API、专业数据平台和第三方服务获取全面信息
2. **智能缓存机制**：减少API调用，提高响应速度
3. **自动分析算法**：基于多种因素分析价格变动原因
4. **完善的错误处理**：确保在部分数据源不可用时仍能提供有价值的信息
5. **灵活的扩展性**：可以轻松添加新的数据源和分析功能

该模块与价格监控和推送模块无缝集成，确保用户在收到价格预警时能够获得全面、深入的币种信息，帮助做出更明智的决策。
