# 项目文件清单

以下是加密货币监控系统的所有文件清单，用于一键安装包的打包：

## 核心模块
- `price_monitor.py` - 价格监控模块
- `announcement_monitor.py` - 公告监控模块
- `coin_detail_enricher.py` - 币种详情与市场信息聚合模块
- `telegram_bot.py` - Telegram机器人主模块
- `telegram_commands.py` - Telegram命令处理模块
- `quick_settings.py` - 快速设置模块
- `main.py` - 主程序入口

## 配置文件
- `config.json` - 默认配置文件模板
- `requirements.txt` - 依赖包列表

## 文档
- `README.md` - 项目说明文档
- `INSTALL.md` - 安装说明文档
- `quick_settings_design.md` - 快速设置模块设计文档
- `telegram_shortcut_commands.md` - Telegram快捷命令设计文档
- `dual_exchange_announcement_monitor.md` - 双交易所公告监控设计文档
- `enhanced_telegram_push.md` - 增强版Telegram推送设计文档
- `coin_detail_enrichment_module.md` - 币种详情模块设计文档

## 验证报告
- `quick_settings_validation.md` - 快速设置模块验证报告
- `telegram_commands_validation.md` - Telegram命令验证报告
- `system_validation_enhanced.md` - 系统验证报告

## 安装脚本
- `install.sh` - Linux/macOS安装脚本
- `install.bat` - Windows安装脚本
- `setup.py` - Python安装脚本
