#!/bin/bash
# 安装内置代理组件

# 检测系统类型和架构
ARCH=$(uname -m)
case $ARCH in
    x86_64)
        ARCH="amd64"
        ;;
    aarch64)
        ARCH="arm64"
        ;;
    armv7l)
        ARCH="armv7"
        ;;
    *)
        echo "不支持的架构: $ARCH"
        exit 1
        ;;
esac

OS=$(uname -s | tr '[:upper:]' '[:lower:]')
case $OS in
    linux)
        OS="linux"
        ;;
    darwin)
        OS="darwin"
        ;;
    *)
        echo "不支持的操作系统: $OS"
        exit 1
        ;;
esac

# 脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 安装sing-box
echo "正在安装sing-box代理组件..."

# 检查是否有预编译二进制文件
BINARY_PATH="$PROJECT_DIR/bin/sing-box-$OS-$ARCH"
if [ -f "$BINARY_PATH" ]; then
    echo "使用预编译二进制文件..."
    cp "$BINARY_PATH" /usr/local/bin/sing-box
    chmod +x /usr/local/bin/sing-box
else
    echo "未找到预编译二进制文件，从网络安装..."
    bash -c "$(curl -L https://sing-box.app/install.sh)"
fi

# 创建配置目录
mkdir -p /etc/sing-box

# 复制配置文件
cp "$PROJECT_DIR/config/proxy_template.json" /etc/sing-box/config.json

# 设置服务
if [ -d "/etc/systemd/system" ]; then
    cp "$PROJECT_DIR/bin/sing-box.service" /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable sing-box
    systemctl restart sing-box
    echo "服务已启动并设置为开机自启"
else
    echo "未检测到systemd，请手动启动sing-box"
    echo "命令: sing-box run -c /etc/sing-box/config.json"
fi

echo "代理服务安装完成！"
echo "SOCKS5代理: 127.0.0.1:1080"
echo "HTTP代理: 127.0.0.1:7890"
