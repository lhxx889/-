#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交易所公告扫描脚本 - 监控Binance.US和Gate.io的公告页面
"""

import requests
import json
import time
import logging
import os
from datetime import datetime
from bs4 import BeautifulSoup
import hashlib

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("announcement_scanner.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("announcement_scanner")

# 配置参数
BINANCE_ANNOUNCEMENT_URL = "https://support.binance.us/en/collections/10384537-announcements"
GATE_ANNOUNCEMENT_URL = "https://www.gate.io/announcements"
GATE_API_ANNOUNCEMENT_URL = "https://www.gate.io/announcements/apiupdates"
SCAN_INTERVAL = 3600  # 扫描间隔，秒（1小时）
HISTORY_FILE = "announcement_history.json"
NEW_LISTINGS_KEYWORDS = ["listing", "新上币", "new coin", "new token", "will list", "上线"]

def get_page_content(url):
    """
    获取网页内容
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"获取网页内容失败: {url}, 错误: {e}")
        return None

def parse_binance_announcements(html_content):
    """
    解析Binance.US公告页面
    """
    if not html_content:
        return []
    
    announcements = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 根据实际页面结构调整选择器
        articles = soup.select('article.article-list-item')
        
        for article in articles:
            try:
                title_element = article.select_one('h3.article-list-item-title')
                link_element = article.select_one('a')
                date_element = article.select_one('time')
                
                if title_element and link_element:
                    title = title_element.text.strip()
                    link = link_element.get('href')
                    if not link.startswith('http'):
                        link = f"https://support.binance.us{link}"
                    
                    date = date_element.text.strip() if date_element else "未知日期"
                    
                    announcement = {
                        "exchange": "Binance.US",
                        "title": title,
                        "url": link,
                        "date": date,
                        "id": hashlib.md5(f"{title}_{link}".encode()).hexdigest(),
                        "is_new_listing": any(keyword.lower() in title.lower() for keyword in NEW_LISTINGS_KEYWORDS)
                    }
                    announcements.append(announcement)
            except Exception as e:
                logger.error(f"解析Binance.US公告项目时出错: {e}")
        
        logger.info(f"成功解析 {len(announcements)} 条Binance.US公告")
    except Exception as e:
        logger.error(f"解析Binance.US公告页面失败: {e}")
    
    return announcements

def parse_gate_announcements(html_content):
    """
    解析Gate.io公告页面
    """
    if not html_content:
        return []
    
    announcements = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 根据实际页面结构调整选择器
        articles = soup.select('div.article-item') or soup.select('div.announcement-item')
        
        for article in articles:
            try:
                title_element = article.select_one('h3') or article.select_one('div.title')
                link_element = article.select_one('a')
                date_element = article.select_one('time') or article.select_one('div.date')
                
                if title_element and link_element:
                    title = title_element.text.strip()
                    link = link_element.get('href')
                    if not link.startswith('http'):
                        link = f"https://www.gate.io{link}"
                    
                    date = date_element.text.strip() if date_element else "未知日期"
                    
                    announcement = {
                        "exchange": "Gate.io",
                        "title": title,
                        "url": link,
                        "date": date,
                        "id": hashlib.md5(f"{title}_{link}".encode()).hexdigest(),
                        "is_new_listing": any(keyword.lower() in title.lower() for keyword in NEW_LISTINGS_KEYWORDS)
                    }
                    announcements.append(announcement)
            except Exception as e:
                logger.error(f"解析Gate.io公告项目时出错: {e}")
        
        logger.info(f"成功解析 {len(announcements)} 条Gate.io公告")
    except Exception as e:
        logger.error(f"解析Gate.io公告页面失败: {e}")
    
    return announcements

def load_announcement_history():
    """
    加载历史公告记录
    """
    if not os.path.exists(HISTORY_FILE):
        return []
    
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"加载历史公告记录失败: {e}")
        return []

def save_announcement_history(announcements):
    """
    保存公告历史记录
    """
    try:
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(announcements, f, ensure_ascii=False, indent=2)
        logger.info(f"已保存 {len(announcements)} 条公告历史记录")
    except Exception as e:
        logger.error(f"保存公告历史记录失败: {e}")

def filter_new_announcements(all_announcements, history):
    """
    过滤出新公告
    """
    history_ids = {item['id'] for item in history}
    new_announcements = [item for item in all_announcements if item['id'] not in history_ids]
    return new_announcements

def notify_new_announcements(new_announcements):
    """
    通知新公告
    """
    if not new_announcements:
        logger.info("没有发现新公告")
        return
    
    # 分离新上币公告和普通公告
    new_listings = [a for a in new_announcements if a['is_new_listing']]
    regular_announcements = [a for a in new_announcements if not a['is_new_listing']]
    
    # 记录到日志
    if new_listings:
        logger.info(f"发现 {len(new_listings)} 条新上币公告:")
        for announcement in new_listings:
            logger.info(f"[新上币] {announcement['exchange']} - {announcement['title']} - {announcement['url']}")
    
    if regular_announcements:
        logger.info(f"发现 {len(regular_announcements)} 条普通公告:")
        for announcement in regular_announcements:
            logger.info(f"{announcement['exchange']} - {announcement['title']} - {announcement['url']}")
    
    # 保存到文件
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    try:
        # 读取现有数据
        try:
            with open("new_announcements.json", "r", encoding='utf-8') as f:
                existing_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        # 添加新数据
        for announcement in new_announcements:
            announcement['discovery_time'] = current_time
            existing_data.append(announcement)
        
        # 写回文件
        with open("new_announcements.json", "w", encoding='utf-8') as f:
            json.dump(existing_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"已保存 {len(new_announcements)} 条新公告记录")
    
    except Exception as e:
        logger.error(f"保存新公告记录失败: {e}")

def scan_announcements():
    """
    扫描公告的主函数
    """
    logger.info("开始扫描交易所公告...")
    
    try:
        # 加载历史记录
        history = load_announcement_history()
        
        # 获取Binance.US公告
        binance_html = get_page_content(BINANCE_ANNOUNCEMENT_URL)
        binance_announcements = parse_binance_announcements(binance_html)
        
        # 获取Gate.io公告
        gate_html = get_page_content(GATE_ANNOUNCEMENT_URL)
        gate_announcements = parse_gate_announcements(gate_html)
        
        # 获取Gate.io API公告
        gate_api_html = get_page_content(GATE_API_ANNOUNCEMENT_URL)
        gate_api_announcements = parse_gate_announcements(gate_api_html)
        
        # 合并所有公告
        all_announcements = binance_announcements + gate_announcements + gate_api_announcements
        
        # 过滤新公告
        new_announcements = filter_new_announcements(all_announcements, history)
        
        # 通知新公告
        notify_new_announcements(new_announcements)
        
        # 更新历史记录
        history.extend(new_announcements)
        save_announcement_history(history)
        
        return len(new_announcements)
    
    except Exception as e:
        logger.error(f"扫描公告过程中发生错误: {e}")
        return 0

if __name__ == "__main__":
    try:
        while True:
            new_count = scan_announcements()
            logger.info(f"本次扫描发现 {new_count} 条新公告")
            logger.info(f"等待 {SCAN_INTERVAL} 秒后进行下一次扫描...")
            time.sleep(SCAN_INTERVAL)
    
    except KeyboardInterrupt:
        logger.info("扫描程序被手动终止")
    except Exception as e:
        logger.error(f"程序异常终止: {e}")
