#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
代理管理模块 - 负责内置代理的管理和状态监控
"""

import os
import sys
import json
import time
import logging
import subprocess
import requests
import socket
from typing import Dict, Any, Optional, Tuple

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

logger = logging.getLogger("proxy_manager")

class ProxyManager:
    """代理管理器类"""
    
    def __init__(self, config: Dict[str, Any]):
        """初始化代理管理器
        
        Args:
            config: 配置字典
        """
        self.config = config
        self.proxy_installed = self._check_proxy_installed()
        self.proxy_running = self._check_proxy_running()
    
    def _check_proxy_installed(self) -> bool:
        """检查代理是否已安装
        
        Returns:
            bool: 是否已安装
        """
        return os.path.exists("/usr/local/bin/sing-box") and os.path.exists("/etc/sing-box/config.json")
    
    def _check_proxy_running(self) -> bool:
        """检查代理是否正在运行
        
        Returns:
            bool: 是否正在运行
        """
        # 检查SOCKS5端口
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('127.0.0.1', 1080))
            sock.close()
            if result == 0:
                return True
        except:
            pass
        
        # 检查HTTP端口
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('127.0.0.1', 7890))
            sock.close()
            if result == 0:
                return True
        except:
            pass
        
        return False
    
    def install_proxy(self) -> bool:
        """安装内置代理
        
        Returns:
            bool: 安装是否成功
        """
        try:
            script_path = os.path.join(script_dir, "scripts", "install_proxy.sh")
            
            # 确保脚本有执行权限
            os.chmod(script_path, 0o755)
            
            # 执行安装脚本
            result = subprocess.run(["bash", script_path], capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info("代理安装成功")
                self.proxy_installed = True
                self.proxy_running = True
                return True
            else:
                logger.error(f"代理安装失败: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"代理安装异常: {e}")
            return False
    
    def start_proxy(self) -> bool:
        """启动代理服务
        
        Returns:
            bool: 启动是否成功
        """
        if not self.proxy_installed:
            logger.error("代理未安装，无法启动")
            return False
        
        try:
            result = subprocess.run(["systemctl", "start", "sing-box"], capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info("代理服务启动成功")
                self.proxy_running = True
                return True
            else:
                logger.error(f"代理服务启动失败: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"代理服务启动异常: {e}")
            return False
    
    def stop_proxy(self) -> bool:
        """停止代理服务
        
        Returns:
            bool: 停止是否成功
        """
        if not self.proxy_installed:
            logger.error("代理未安装，无法停止")
            return False
        
        try:
            result = subprocess.run(["systemctl", "stop", "sing-box"], capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info("代理服务停止成功")
                self.proxy_running = False
                return True
            else:
                logger.error(f"代理服务停止失败: {result.stderr}")
                return False
        except Exception as e:
            logger.error(f"代理服务停止异常: {e}")
            return False
    
    def test_proxy(self) -> Tuple[bool, str]:
        """测试代理连接
        
        Returns:
            Tuple[bool, str]: (是否成功, 结果信息)
        """
        if not self.proxy_running:
            return False, "代理服务未运行"
        
        try:
            # 测试SOCKS5代理
            proxies = {
                "http": "socks5://127.0.0.1:1080",
                "https": "socks5://127.0.0.1:1080"
            }
            
            response = requests.get("https://api.coingecko.com/api/v3/ping", 
                                   proxies=proxies, 
                                   timeout=10)
            
            if response.status_code == 200:
                return True, f"代理连接测试成功: {response.text}"
            else:
                return False, f"代理连接测试失败: HTTP {response.status_code}"
        except Exception as e:
            return False, f"代理连接测试异常: {e}"
    
    def get_proxy_status(self) -> Dict[str, Any]:
        """获取代理状态信息
        
        Returns:
            Dict[str, Any]: 状态信息字典
        """
        status = {
            "installed": self.proxy_installed,
            "running": self.proxy_running,
            "socks5_address": "socks5://127.0.0.1:1080" if self.proxy_running else None,
            "http_address": "http://127.0.0.1:7890" if self.proxy_running else None
        }
        
        # 更新运行状态
        if self.proxy_installed:
            self.proxy_running = self._check_proxy_running()
            status["running"] = self.proxy_running
        
        return status
    
    def apply_proxy_to_config(self) -> bool:
        """将代理设置应用到全局配置
        
        Returns:
            bool: 是否成功
        """
        if not self.proxy_running:
            return False
        
        try:
            # 更新配置
            self.config["use_proxy"] = True
            self.config["proxy"] = {
                "http": "http://127.0.0.1:7890",
                "https": "http://127.0.0.1:7890"
            }
            
            logger.info("代理设置已应用到配置")
            return True
        except Exception as e:
            logger.error(f"应用代理设置失败: {e}")
            return False
