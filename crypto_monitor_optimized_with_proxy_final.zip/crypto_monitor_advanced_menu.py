#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交易所监控系统 - 高级交互式主菜单
整合Binance.US和Gate.io的价格监控与公告扫描功能
支持Telegram推送、币种详情查询、社交媒体链接和涨跌原因分析
"""

import os
import sys
import json
import time
import signal
import logging
import argparse
import threading
import subprocess
from datetime import datetime

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入模块，如果失败则提示安装
try:
    import requests
    from bs4 import BeautifulSoup
    import pytz  # 用于时区转换
except ImportError:
    print("缺少必要的Python库。请运行以下命令安装：")
    print("pip install requests beautifulsoup4 pytz")
    sys.exit(1)

# 导入代理管理模块
try:
    from proxy_manager import ProxyManager
except ImportError:
    print("缺少代理管理模块。请确保proxy_manager.py文件存在。")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "crypto_monitor_advanced.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("crypto_monitor_advanced_menu")

# 全局配置
CONFIG = {
    "price_change_threshold": 5.0,  # 涨跌幅阈值，百分比
    "price_check_interval": 300,    # 价格检查间隔，秒（5分钟）
    "announcement_scan_interval": 3600,  # 公告扫描间隔，秒（1小时）
    "use_proxy": False,             # 是否使用代理
    "proxy": {                      # 代理配置
        "http": "socks5://127.0.0.1:1080",
        "https": "socks5://127.0.0.1:1080"
    },
    "binance_enabled": True,        # 是否启用Binance.US监控
    "gate_enabled": True,           # 是否启用Gate.io监控
    "announcement_enabled": True,   # 是否启用公告扫描
    "data_dir": os.path.join(script_dir, "data"),  # 数据存储目录
    
    # Telegram推送配置
    "telegram_enabled": False,      # 是否启用Telegram推送
    "telegram_bot_token": "",       # Telegram机器人Token
    "telegram_chat_id": "",         # Telegram聊天ID
    "telegram_price_notify": True,  # 是否推送价格变动
    "telegram_announcement_notify": True,  # 是否推送公告
    "telegram_min_price_change": 10.0,  # 价格变动推送的最小阈值（百分比）
    "telegram_batch_mode": True,    # 是否批量推送（多条合并为一条）
    "telegram_batch_interval": 60,  # 批量推送间隔（秒）
    
    # 币种信息查询配置
    "show_shanghai_time": True,     # 是否显示上海时间
    "show_coin_details": True,      # 是否显示币种详细信息
    
    # 高级功能配置
    "show_holders_count": True,     # 是否显示持币人数
    "show_social_links": True,      # 是否显示社交媒体链接
    "show_price_change_reason": True,  # 是否显示价格变动原因分析
    "etherscan_api_key": "",        # Etherscan API密钥
    "ethplorer_api_key": "",        # Ethplorer API密钥
}

# API端点
COINGECKO_API_URL = "https://api.coingecko.com/api/v3"
COINGECKO_COIN_LIST_ENDPOINT = "/coins/list"
COINGECKO_COIN_DETAIL_ENDPOINT = "/coins/{id}"
COINGECKO_COIN_MARKET_ENDPOINT = "/coins/markets"

# 配置文件路径
CONFIG_FILE = os.path.join(script_dir, "config_advanced.json")

# 监控进程
monitor_process = None
is_running = False

# 代理管理器
proxy_manager = None

# 上海时区
shanghai_tz = pytz.timezone("Asia/Shanghai")

# 确保数据目录存在
if not os.path.exists(CONFIG["data_dir"]):
    os.makedirs(CONFIG["data_dir"])

def get_shanghai_time(dt=None):
    """获取当前或指定时间的上海时间字符串"""
    if dt is None:
        dt = datetime.now(pytz.utc)
    shanghai_dt = dt.astimezone(shanghai_tz)
    return shanghai_dt.strftime("%Y-%m-%d %H:%M:%S %Z%z")

def clear_screen():
    """清除屏幕"""
    os.system('cls' if os.name == 'nt' else 'clear')

def load_config():
    """加载配置"""
    global CONFIG
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
                CONFIG.update(loaded_config)
                logger.info("已加载配置文件")
    except Exception as e:
        logger.error(f"加载配置文件失败: {e}")

def save_config():
    """保存配置"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(CONFIG, f, ensure_ascii=False, indent=2)
        logger.info("已保存配置文件")
    except Exception as e:
        logger.error(f"保存配置文件失败: {e}")

def test_telegram_connection():
    """测试Telegram连接"""
    if not CONFIG["telegram_enabled"] or not CONFIG["telegram_bot_token"] or not CONFIG["telegram_chat_id"]:
        print("Telegram推送未启用或配置不完整，无法测试连接")
        return False
    
    print("正在测试Telegram连接...")
    try:
        url = f"https://api.telegram.org/bot{CONFIG['telegram_bot_token']}/sendMessage"
        data = {
            "chat_id": CONFIG["telegram_chat_id"],
            "text": f"🔔 *交易所监控系统测试消息*\n\n系统已成功连接，此为测试消息。\n当前时间: {get_shanghai_time()}",
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        
        # 是否使用代理
        proxies = CONFIG["proxy"] if CONFIG["use_proxy"] else None
        
        response = requests.post(url, data=data, proxies=proxies, timeout=10)
        response.raise_for_status()
        
        print("Telegram连接测试成功！")
        return True
    except Exception as e:
        print(f"Telegram连接测试失败: {e}")
        return False

def start_monitoring():
    """启动监控"""
    global monitor_process, is_running
    
    if is_running:
        print("监控已经在运行中")
        return
    
    try:
        # 构建命令行参数
        cmd = [sys.executable, os.path.join(script_dir, "crypto_monitor_advanced.py")]
        
        # 添加配置文件参数
        cmd.extend(["--config", CONFIG_FILE])
        
        # 启动进程
        monitor_process = subprocess.Popen(cmd)
        is_running = True
        print("高级监控已启动！")
        
        # 保存配置
        save_config()
    except Exception as e:
        print(f"启动监控失败: {e}")

def stop_monitoring():
    """停止监控"""
    global monitor_process, is_running
    
    if not is_running:
        print("监控未在运行")
        return
    
    try:
        if monitor_process:
            monitor_process.terminate()
            monitor_process.wait(timeout=5)
            monitor_process = None
            is_running = False
            print("监控已停止")
    except Exception as e:
        print(f"停止监控失败: {e}")
        try:
            if monitor_process:
                monitor_process.kill()
                monitor_process = None
        except:
            pass
        is_running = False

def format_large_number(num):
    """格式化大数字，添加逗号分隔符"""
    try:
        return f"{num:,.0f}"
    except (TypeError, ValueError):
        return "N/A"

def search_coin(query):
    """搜索币种"""
    try:
        url = f"{COINGECKO_API_URL}{COINGECKO_COIN_LIST_ENDPOINT}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        coins = response.json()
        
        # 按名称、符号或ID搜索
        query = query.lower()
        results = []
        
        for coin in coins:
            if (query in coin.get("name", "").lower() or 
                query in coin.get("symbol", "").lower() or 
                query in coin.get("id", "").lower()):
                results.append(coin)
                if len(results) >= 20:  # 限制结果数量
                    break
        
        return results
    except Exception as e:
        print(f"搜索币种失败: {e}")
        return []

def get_coin_details(coin_id):
    """获取币种详细信息"""
    try:
        url = f"{COINGECKO_API_URL}{COINGECKO_COIN_DETAIL_ENDPOINT.format(id=coin_id)}"
        params = {
            "localization": "false",
            "tickers": "false",
            "market_data": "true",
            "community_data": "true",
            "developer_data": "false",
            "sparkline": "false"
        }
        
        # 是否使用代理
        proxies = CONFIG["proxy"] if CONFIG["use_proxy"] else None
        
        response = requests.get(url, params=params, proxies=proxies, timeout=10)
        response.raise_for_status()
        
        return response.json()
    except Exception as e:
        print(f"获取币种详情失败: {e}")
        return None

def get_token_holders_count(coin_details):
    """获取持币人数 (尝试多个API源)"""
    if not coin_details or not CONFIG["show_holders_count"]:
        return None
    
    # 尝试从CoinGecko获取持币人数 (如果有)
    if "community_data" in coin_details and "holders_count" in coin_details["community_data"]:
        return coin_details["community_data"]["holders_count"]
    
    # 获取合约地址
    contract_address = None
    platforms = coin_details.get("platforms", {})
    if "ethereum" in platforms and platforms["ethereum"]:
        contract_address = platforms["ethereum"]
    
    if not contract_address:
        return None
    
    # 尝试从Etherscan获取持币人数
    try:
        if CONFIG.get("etherscan_api_key"):
            url = "https://api.etherscan.io/api"
            params = {
                "module": "token",
                "action": "tokenholderlist",
                "contractaddress": contract_address,
                "apikey": CONFIG.get("etherscan_api_key")
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "1" and "result" in data:
                    return len(data["result"])
    except Exception as e:
        print(f"从Etherscan获取持币人数失败: {e}")
    
    # 尝试从Ethplorer获取持币人数
    try:
        if CONFIG.get("ethplorer_api_key"):
            url = f"https://api.ethplorer.io/getTokenInfo/{contract_address}"
            params = {
                "apiKey": CONFIG.get("ethplorer_api_key", "freekey")
            }
            
            response = requests.get(url, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if "holdersCount" in data:
                    return data["holdersCount"]
    except Exception as e:
        print(f"从Ethplorer获取持币人数失败: {e}")
    
    return None

def get_social_links(coin_details):
    """获取社交媒体链接"""
    if not coin_details or "links" not in coin_details or not CONFIG["show_social_links"]:
        return {}
    
    links = coin_details["links"]
    social_links = {}
    
    # 官网
    if "homepage" in links and links["homepage"] and links["homepage"][0]:
        social_links["website"] = links["homepage"][0]
    
    # Telegram
    if "telegram_channel_identifier" in links and links["telegram_channel_identifier"]:
        social_links["telegram"] = f"https://t.me/{links['telegram_channel_identifier']}"
    
    # Twitter/X
    if "twitter_screen_name" in links and links["twitter_screen_name"]:
        social_links["twitter"] = f"https://twitter.com/{links['twitter_screen_name']}"
    
    # Discord
    if "chat_url" in links and links["chat_url"] and any("discord" in url for url in links["chat_url"]):
        for url in links["chat_url"]:
            if "discord" in url:
                social_links["discord"] = url
                break
    
    # Reddit
    if "subreddit_url" in links and links["subreddit_url"]:
        social_links["reddit"] = links["subreddit_url"]
    
    return social_links

def display_coin_details(coin_details):
    """显示币种详细信息"""
    if not coin_details:
        print("无法获取币种详情")
        return
    
    clear_screen()
    print("=" * 60)
    print(f"                币种详情: {coin_details.get('name', 'Unknown')}")
    print("=" * 60)
    
    # 基本信息
    print(f"名称: {coin_details.get('name', 'N/A')}")
    print(f"符号: {coin_details.get('symbol', 'N/A').upper()}")
    print(f"排名: #{coin_details.get('market_cap_rank', 'N/A')}")
    
    # 市场数据
    market_data = coin_details.get("market_data", {})
    if market_data:
        print("\n价格信息:")
        print(f"当前价格 (USD): ${market_data.get('current_price', {}).get('usd', 'N/A')}")
        print(f"24小时变化: {market_data.get('price_change_percentage_24h', 'N/A')}%")
        print(f"7天变化: {market_data.get('price_change_percentage_7d', 'N/A')}%")
        print(f"30天变化: {market_data.get('price_change_percentage_30d', 'N/A')}%")
        
        print("\n市值信息:")
        market_cap = market_data.get('market_cap', {}).get('usd')
        if market_cap:
            print(f"市值: ${format_large_number(market_cap)}")
        
        volume = market_data.get('total_volume', {}).get('usd')
        if volume:
            print(f"24小时交易量: ${format_large_number(volume)}")
        
        circulating_supply = market_data.get('circulating_supply')
        if circulating_supply:
            print(f"流通量: {format_large_number(circulating_supply)} {coin_details.get('symbol', '').upper()}")
        
        total_supply = market_data.get('total_supply')
        if total_supply:
            print(f"总供应量: {format_large_number(total_supply)} {coin_details.get('symbol', '').upper()}")
        
        print("\n历史高低点:")
        ath = market_data.get('ath', {}).get('usd')
        if ath:
            print(f"历史最高点: ${ath} ({market_data.get('ath_date', {}).get('usd', 'N/A')})")
        
        atl = market_data.get('atl', {}).get('usd')
        if atl:
            print(f"历史最低点: ${atl} ({market_data.get('atl_date', {}).get('usd', 'N/A')})")
    
    # 持币人数
    if CONFIG["show_holders_count"]:
        holders_count = get_token_holders_count(coin_details)
        if holders_count:
            print(f"\n持币人数: {format_large_number(holders_count)}")
    
    # 社交媒体链接
    if CONFIG["show_social_links"]:
        social_links = get_social_links(coin_details)
        if social_links:
            print("\n社交媒体链接:")
            if "website" in social_links:
                print(f"官网: {social_links['website']}")
            if "telegram" in social_links:
                print(f"Telegram: {social_links['telegram']}")
            if "twitter" in social_links:
                print(f"X/Twitter: {social_links['twitter']}")
            if "discord" in social_links:
                print(f"Discord: {social_links['discord']}")
            if "reddit" in social_links:
                print(f"Reddit: {social_links['reddit']}")
    
    # 链接
    links = coin_details.get("links", {})
    if links:
        print("\n相关链接:")
        blockchain_site = links.get("blockchain_site", [])
        if blockchain_site and blockchain_site[0]:
            print(f"区块浏览器: {blockchain_site[0]}")
        
        repos_url = links.get("repos_url", {}).get("github", [])
        if repos_url and repos_url[0]:
            print(f"GitHub: {repos_url[0]}")
    
    # 描述
    description = coin_details.get("description", {}).get("en", "")
    if description:
        print("\n简介:")
        # 截取前300个字符
        short_desc = description[:300] + "..." if len(description) > 300 else description
        print(short_desc)
    
    # 上海时间
    if CONFIG["show_shanghai_time"]:
        print(f"\n当前上海时间: {get_shanghai_time()}")
    
    print("\n按Enter键返回...")
    input()

def coin_search_menu():
    """币种搜索菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                币种信息查询")
        print("=" * 60)
        print("请输入币种名称、符号或ID进行搜索")
        print("例如: bitcoin, btc, ethereum, eth")
        print("输入 '0' 返回主菜单")
        print("-" * 60)
        
        query = input("搜索: ")
        
        if query == "0":
            break
        
        if not query or len(query) < 2:
            print("请输入至少2个字符")
            time.sleep(1)
            continue
        
        print("正在搜索...")
        results = search_coin(query)
        
        if not results:
            print("未找到匹配的币种")
            print("按Enter键继续...")
            input()
            continue
        
        while True:
            clear_screen()
            print("=" * 60)
            print("                搜索结果")
            print("=" * 60)
            print("ID    符号    名称")
            print("-" * 60)
            
            for i, coin in enumerate(results):
                print(f"{i+1:<5} {coin.get('symbol', '').upper():<7} {coin.get('name', '')}")
            
            print("-" * 60)
            print("输入数字查看详情，或输入 '0' 返回搜索")
            
            choice = input("选择: ")
            
            if choice == "0":
                break
            
            try:
                index = int(choice) - 1
                if 0 <= index < len(results):
                    print("正在获取详情...")
                    coin_id = results[index]["id"]
                    details = get_coin_details(coin_id)
                    display_coin_details(details)
                else:
                    print("无效选择")
                    time.sleep(1)
            except ValueError:
                print("请输入有效数字")
                time.sleep(1)

def show_main_menu():
    """显示主菜单"""
    clear_screen()
    print("=" * 60)
    print("                交易所监控系统 - 高级主菜单")
    print("=" * 60)
    print(f"当前状态: {'运行中' if is_running else '已停止'}")
    if CONFIG["show_shanghai_time"]:
        print(f"上海时间: {get_shanghai_time()}")
    print("-" * 60)
    print("1. 启动/停止监控")
    print("2. 配置Telegram推送")
    print("3. 设置价格监控参数")
    print("4. 设置公告扫描参数")
    print("5. 配置代理设置")
    print("6. 币种信息查询")
    print("7. 高级功能设置")
    print("8. 显示设置")
    print("9. 查看当前配置")
    print("10. 内置代理管理")  # 新增内置代理管理选项
    print("0. 退出程序")
    print("-" * 60)
    
    choice = input("请输入选项 [0-10]: ")
    return choice

def telegram_menu():
    """Telegram配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                Telegram推送配置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['telegram_enabled'] else '启用'}Telegram推送")
        
        if CONFIG["telegram_enabled"]:
            print(f"2. 设置机器人Token (当前: {CONFIG['telegram_bot_token'][:10]}...)")
            print(f"3. 设置聊天ID (当前: {CONFIG['telegram_chat_id']})")
            print(f"4. {'禁用' if CONFIG['telegram_price_notify'] else '启用'}价格变动推送")
            print(f"5. {'禁用' if CONFIG['telegram_announcement_notify'] else '启用'}公告推送")
            print(f"6. 设置价格推送阈值 (当前: {CONFIG['telegram_min_price_change']}%)")
            print(f"7. {'禁用' if CONFIG['telegram_batch_mode'] else '启用'}批量推送模式")
            print(f"8. 设置批量推送间隔 (当前: {CONFIG['telegram_batch_interval']}秒)")
            print("9. 测试Telegram连接")
        
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请输入选项: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["telegram_enabled"] = not CONFIG["telegram_enabled"]
            if CONFIG["telegram_enabled"]:
                print("已启用Telegram推送")
            else:
                print("已禁用Telegram推送")
            save_config()
        elif CONFIG["telegram_enabled"]:
            if choice == "2":
                token = input("请输入Telegram机器人Token: ")
                if token:
                    CONFIG["telegram_bot_token"] = token
                    print("已设置Telegram机器人Token")
                    save_config()
            elif choice == "3":
                chat_id = input("请输入Telegram聊天ID: ")
                if chat_id:
                    CONFIG["telegram_chat_id"] = chat_id
                    print("已设置Telegram聊天ID")
                    save_config()
            elif choice == "4":
                CONFIG["telegram_price_notify"] = not CONFIG["telegram_price_notify"]
                print(f"价格变动推送已{'启用' if CONFIG['telegram_price_notify'] else '禁用'}")
                save_config()
            elif choice == "5":
                CONFIG["telegram_announcement_notify"] = not CONFIG["telegram_announcement_notify"]
                print(f"公告推送已{'启用' if CONFIG['telegram_announcement_notify'] else '禁用'}")
                save_config()
            elif choice == "6":
                try:
                    threshold = float(input(f"请输入价格推送阈值 (当前: {CONFIG['telegram_min_price_change']}%): "))
                    if threshold > 0:
                        CONFIG["telegram_min_price_change"] = threshold
                        print(f"已设置价格推送阈值为 {threshold}%")
                        save_config()
                except ValueError:
                    print("输入无效，请输入有效的数字")
            elif choice == "7":
                CONFIG["telegram_batch_mode"] = not CONFIG["telegram_batch_mode"]
                print(f"批量推送模式已{'启用' if CONFIG['telegram_batch_mode'] else '禁用'}")
                save_config()
            elif choice == "8":
                try:
                    interval = int(input(f"请输入批量推送间隔 (当前: {CONFIG['telegram_batch_interval']}秒): "))
                    if interval > 0:
                        CONFIG["telegram_batch_interval"] = interval
                        print(f"已设置批量推送间隔为 {interval}秒")
                        save_config()
                except ValueError:
                    print("输入无效，请输入有效的数字")
            elif choice == "9":
                test_telegram_connection()
                input("按Enter键继续...")
        
        time.sleep(1)

def price_monitor_menu():
    """价格监控配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                价格监控配置")
        print("=" * 60)
        print(f"1. 设置价格涨跌幅阈值 (当前: {CONFIG['price_change_threshold']}%)")
        print(f"2. 设置价格检查间隔 (当前: {CONFIG['price_check_interval']}秒)")
        print(f"3. {'禁用' if CONFIG['binance_enabled'] else '启用'}Binance.US监控")
        print(f"4. {'禁用' if CONFIG['gate_enabled'] else '启用'}Gate.io监控")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请输入选项: ")
        
        if choice == "0":
            break
        elif choice == "1":
            try:
                threshold = float(input(f"请输入价格涨跌幅阈值 (当前: {CONFIG['price_change_threshold']}%): "))
                if threshold > 0:
                    CONFIG["price_change_threshold"] = threshold
                    print(f"已设置价格涨跌幅阈值为 {threshold}%")
                    save_config()
            except ValueError:
                print("输入无效，请输入有效的数字")
        elif choice == "2":
            try:
                interval = int(input(f"请输入价格检查间隔 (当前: {CONFIG['price_check_interval']}秒): "))
                if interval > 0:
                    CONFIG["price_check_interval"] = interval
                    print(f"已设置价格检查间隔为 {interval}秒")
                    save_config()
            except ValueError:
                print("输入无效，请输入有效的数字")
        elif choice == "3":
            CONFIG["binance_enabled"] = not CONFIG["binance_enabled"]
            print(f"Binance.US监控已{'启用' if CONFIG['binance_enabled'] else '禁用'}")
            save_config()
        elif choice == "4":
            CONFIG["gate_enabled"] = not CONFIG["gate_enabled"]
            print(f"Gate.io监控已{'启用' if CONFIG['gate_enabled'] else '禁用'}")
            save_config()
        
        time.sleep(1)

def announcement_menu():
    """公告扫描配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                公告扫描配置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['announcement_enabled'] else '启用'}公告扫描")
        print(f"2. 设置公告扫描间隔 (当前: {CONFIG['announcement_scan_interval']}秒)")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请输入选项: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["announcement_enabled"] = not CONFIG["announcement_enabled"]
            print(f"公告扫描已{'启用' if CONFIG['announcement_enabled'] else '禁用'}")
            save_config()
        elif choice == "2":
            try:
                interval = int(input(f"请输入公告扫描间隔 (当前: {CONFIG['announcement_scan_interval']}秒): "))
                if interval > 0:
                    CONFIG["announcement_scan_interval"] = interval
                    print(f"已设置公告扫描间隔为 {interval}秒")
                    save_config()
            except ValueError:
                print("输入无效，请输入有效的数字")
        
        time.sleep(1)

def proxy_menu():
    """代理配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                代理设置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['use_proxy'] else '启用'}代理")
        
        if CONFIG["use_proxy"]:
            print(f"2. 设置HTTP代理 (当前: {CONFIG['proxy']['http']})")
            print(f"3. 设置HTTPS代理 (当前: {CONFIG['proxy']['https']})")
        
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请输入选项: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["use_proxy"] = not CONFIG["use_proxy"]
            print(f"代理已{'启用' if CONFIG['use_proxy'] else '禁用'}")
            save_config()
        elif CONFIG["use_proxy"]:
            if choice == "2":
                proxy = input(f"请输入HTTP代理 (当前: {CONFIG['proxy']['http']}): ")
                if proxy:
                    CONFIG["proxy"]["http"] = proxy
                    print(f"已设置HTTP代理为 {proxy}")
                    save_config()
            elif choice == "3":
                proxy = input(f"请输入HTTPS代理 (当前: {CONFIG['proxy']['https']}): ")
                if proxy:
                    CONFIG["proxy"]["https"] = proxy
                    print(f"已设置HTTPS代理为 {proxy}")
                    save_config()
        
        time.sleep(1)

def advanced_settings_menu():
    """高级功能设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                高级功能设置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['show_holders_count'] else '启用'}持币人数显示")
        print(f"2. {'禁用' if CONFIG['show_social_links'] else '启用'}社交媒体链接显示")
        print(f"3. {'禁用' if CONFIG['show_price_change_reason'] else '启用'}价格变动原因分析")
        print(f"4. 设置Etherscan API密钥 (当前: {CONFIG['etherscan_api_key'][:5]}... 或未设置)")
        print(f"5. 设置Ethplorer API密钥 (当前: {CONFIG['ethplorer_api_key'][:5]}... 或未设置)")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请输入选项: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["show_holders_count"] = not CONFIG["show_holders_count"]
            print(f"持币人数显示已{'启用' if CONFIG['show_holders_count'] else '禁用'}")
            save_config()
        elif choice == "2":
            CONFIG["show_social_links"] = not CONFIG["show_social_links"]
            print(f"社交媒体链接显示已{'启用' if CONFIG['show_social_links'] else '禁用'}")
            save_config()
        elif choice == "3":
            CONFIG["show_price_change_reason"] = not CONFIG["show_price_change_reason"]
            print(f"价格变动原因分析已{'启用' if CONFIG['show_price_change_reason'] else '禁用'}")
            save_config()
        elif choice == "4":
            api_key = input("请输入Etherscan API密钥: ")
            CONFIG["etherscan_api_key"] = api_key
            print("已设置Etherscan API密钥")
            save_config()
        elif choice == "5":
            api_key = input("请输入Ethplorer API密钥 (留空使用免费密钥): ")
            CONFIG["ethplorer_api_key"] = api_key if api_key else "freekey"
            print("已设置Ethplorer API密钥")
            save_config()
        
        time.sleep(1)

def display_settings_menu():
    """显示设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                显示设置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['show_shanghai_time'] else '启用'}上海时间显示")
        print(f"2. {'禁用' if CONFIG['show_coin_details'] else '启用'}币种详细信息显示")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请输入选项: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["show_shanghai_time"] = not CONFIG["show_shanghai_time"]
            print(f"上海时间显示已{'启用' if CONFIG['show_shanghai_time'] else '禁用'}")
            save_config()
        elif choice == "2":
            CONFIG["show_coin_details"] = not CONFIG["show_coin_details"]
            print(f"币种详细信息显示已{'启用' if CONFIG['show_coin_details'] else '禁用'}")
            save_config()
        
        time.sleep(1)

def view_config():
    """查看当前配置"""
    clear_screen()
    print("=" * 60)
    print("                当前配置")
    print("=" * 60)
    print("基本设置:")
    print(f"- 价格涨跌幅阈值: {CONFIG['price_change_threshold']}%")
    print(f"- 价格检查间隔: {CONFIG['price_check_interval']}秒")
    print(f"- 公告扫描间隔: {CONFIG['announcement_scan_interval']}秒")
    print(f"- 数据存储目录: {CONFIG['data_dir']}")
    print("\n监控设置:")
    print(f"- Binance.US监控: {'启用' if CONFIG['binance_enabled'] else '禁用'}")
    print(f"- Gate.io监控: {'启用' if CONFIG['gate_enabled'] else '禁用'}")
    print(f"- 公告扫描: {'启用' if CONFIG['announcement_enabled'] else '禁用'}")
    print("\n代理设置:")
    print(f"- 使用代理: {'是' if CONFIG['use_proxy'] else '否'}")
    if CONFIG["use_proxy"]:
        print(f"- HTTP代理: {CONFIG['proxy']['http']}")
        print(f"- HTTPS代理: {CONFIG['proxy']['https']}")
    
    print("\nTelegram推送设置:")
    print(f"- Telegram推送: {'启用' if CONFIG['telegram_enabled'] else '禁用'}")
    if CONFIG["telegram_enabled"]:
        print(f"- 机器人Token: {CONFIG['telegram_bot_token'][:10]}...")
        print(f"- 聊天ID: {CONFIG['telegram_chat_id']}")
        print(f"- 价格变动推送: {'启用' if CONFIG['telegram_price_notify'] else '禁用'}")
        print(f"- 公告推送: {'启用' if CONFIG['telegram_announcement_notify'] else '禁用'}")
        print(f"- 价格推送阈值: {CONFIG['telegram_min_price_change']}%")
        print(f"- 批量推送模式: {'启用' if CONFIG['telegram_batch_mode'] else '禁用'}")
        print(f"- 批量推送间隔: {CONFIG['telegram_batch_interval']}秒")
    
    print("\n显示设置:")
    print(f"- 上海时间显示: {'启用' if CONFIG['show_shanghai_time'] else '禁用'}")
    print(f"- 币种详细信息显示: {'启用' if CONFIG['show_coin_details'] else '禁用'}")
    
    print("\n高级功能设置:")
    print(f"- 持币人数显示: {'启用' if CONFIG['show_holders_count'] else '禁用'}")
    print(f"- 社交媒体链接显示: {'启用' if CONFIG['show_social_links'] else '禁用'}")
    print(f"- 价格变动原因分析: {'启用' if CONFIG['show_price_change_reason'] else '禁用'}")
    print(f"- Etherscan API密钥: {'已设置' if CONFIG['etherscan_api_key'] else '未设置'}")
    print(f"- Ethplorer API密钥: {'已设置' if CONFIG['ethplorer_api_key'] else '未设置'}")
    
    if CONFIG["show_shanghai_time"]:
        print(f"\n当前上海时间: {get_shanghai_time()}")
    
    print("\n按Enter键返回主菜单...")
    input()

def view_logs():
    """查看监控日志"""
    clear_screen()
    print("=" * 60)
    print("                监控日志")
    print("=" * 60)
    
    log_file = os.path.join(script_dir, "crypto_monitor_advanced.log")
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r') as f:
                # 读取最后100行
                lines = f.readlines()
                if len(lines) > 100:
                    print(f"显示最近100行日志 (共{len(lines)}行):")
                    for line in lines[-100:]:
                        print(line.strip())
                else:
                    print(f"显示全部日志 (共{len(lines)}行):")
                    for line in lines:
                        print(line.strip())
        except Exception as e:
            print(f"读取日志文件失败: {e}")
    else:
        print("日志文件不存在")
    
    print("\n按Enter键返回主菜单...")
    input()

def handle_exit():
    """处理退出"""
    if is_running:
        stop_monitoring()
    print("正在退出程序...")
    sys.exit(0)

def signal_handler(sig, frame):
    """信号处理函数"""
    print("\n接收到中断信号，正在退出...")
    handle_exit()

def built_in_proxy_menu():
    """内置代理管理菜单"""
    global proxy_manager
    
    # 如果代理管理器未初始化，则初始化
    if proxy_manager is None:
        proxy_manager = ProxyManager(CONFIG)
    
    while True:
        clear_screen()
        print("=" * 60)
        print("                内置代理管理")
        print("=" * 60)
        
        # 获取代理状态
        status = proxy_manager.get_proxy_status()
        
        print(f"代理安装状态: {'已安装' if status['installed'] else '未安装'}")
        print(f"代理运行状态: {'运行中' if status['running'] else '未运行'}")
        
        if status['running']:
            print(f"SOCKS5代理地址: {status['socks5_address']}")
            print(f"HTTP代理地址: {status['http_address']}")
        
        print("-" * 60)
        print("1. 安装内置代理")
        print("2. 启动代理服务")
        print("3. 停止代理服务")
        print("4. 测试代理连接")
        print("5. 应用代理设置")
        print("0. 返回上级菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "1":
            print("正在安装内置代理...")
            success = proxy_manager.install_proxy()
            if success:
                print("代理安装成功！")
            else:
                print("代理安装失败，请查看日志")
            input("按Enter键继续...")
        
        elif choice == "2":
            print("正在启动代理服务...")
            success = proxy_manager.start_proxy()
            if success:
                print("代理服务启动成功！")
            else:
                print("代理服务启动失败，请查看日志")
            input("按Enter键继续...")
        
        elif choice == "3":
            print("正在停止代理服务...")
            success = proxy_manager.stop_proxy()
            if success:
                print("代理服务停止成功！")
            else:
                print("代理服务停止失败，请查看日志")
            input("按Enter键继续...")
        
        elif choice == "4":
            print("正在测试代理连接...")
            success, message = proxy_manager.test_proxy()
            if success:
                print(f"测试成功: {message}")
            else:
                print(f"测试失败: {message}")
            input("按Enter键继续...")
        
        elif choice == "5":
            print("正在应用代理设置...")
            success = proxy_manager.apply_proxy_to_config()
            if success:
                print("代理设置已应用到系统！")
                save_config()
            else:
                print("应用代理设置失败，请确保代理服务正在运行")
            input("按Enter键继续...")
        
        elif choice == "0":
            break

def main():
    """主函数"""
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 加载配置
    load_config()
    
    # 初始化代理管理器
    global proxy_manager
    proxy_manager = ProxyManager(CONFIG)
    
    # 主循环
    while True:
        choice = show_main_menu()
        
        if choice == "1":
            if is_running:
                stop_monitoring()
            else:
                start_monitoring()
            time.sleep(1)
        elif choice == "2":
            telegram_menu()
        elif choice == "3":
            price_monitor_menu()
        elif choice == "4":
            announcement_menu()
        elif choice == "5":
            proxy_menu()
        elif choice == "6":
            coin_search_menu()
        elif choice == "7":
            advanced_settings_menu()
        elif choice == "8":
            display_settings_menu()
        elif choice == "9":
            view_config()
        elif choice == "10":
            built_in_proxy_menu()  # 新增内置代理管理菜单
        elif choice == "0":
            handle_exit()
        else:
            print("无效选项，请重新输入")
            time.sleep(1)

if __name__ == "__main__":
    main()
