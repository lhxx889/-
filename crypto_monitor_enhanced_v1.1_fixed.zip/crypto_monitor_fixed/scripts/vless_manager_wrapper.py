#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VLESS管理器Python包装器
用于从主菜单调用VLESS管理器
"""

import os
import sys
import subprocess
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("vless_manager.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("vless_manager")

def run_vless_manager():
    """运行VLESS管理器"""
    try:
        # 获取脚本目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # VLESS管理器脚本路径
        vless_manager_script = os.path.join(script_dir, "vless_manager.sh")
        
        # 确保脚本有执行权限
        if not os.access(vless_manager_script, os.X_OK):
            os.chmod(vless_manager_script, 0o755)
            logger.info(f"已添加执行权限: {vless_manager_script}")
        
        # 运行VLESS管理器
        logger.info("启动VLESS管理器...")
        result = subprocess.run(vless_manager_script, shell=True)
        
        if result.returncode == 0:
            logger.info("VLESS管理器已正常退出")
        else:
            logger.error(f"VLESS管理器退出，返回码: {result.returncode}")
        
        return result.returncode
    except Exception as e:
        logger.error(f"运行VLESS管理器时出错: {e}")
        return 1

def main():
    """主函数"""
    return run_vless_manager()

if __name__ == "__main__":
    sys.exit(main())

