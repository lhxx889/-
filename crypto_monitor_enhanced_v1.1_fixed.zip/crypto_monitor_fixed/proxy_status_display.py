#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
代理状态显示模块
为加密货币监控程序提供代理状态显示功能
"""

import os
import sys
import json
import time
import logging
from datetime import datetime

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入代理自动切换管理器
try:
    from proxy_auto_switch import ProxyAutoSwitchManager
    from proxy_manager import ProxyManager
except ImportError:
    ProxyAutoSwitchManager = None
    ProxyManager = None

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "proxy_status.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("proxy_status")

class ProxyStatusDisplay:
    """代理状态显示类，负责显示当前代理状态"""
    
    def __init__(self, auto_switch_manager=None, proxy_manager=None):
        """初始化代理状态显示
        
        Args:
            auto_switch_manager: 代理自动切换管理器实例
            proxy_manager: 代理管理器实例
        """
        self.auto_switch_manager = auto_switch_manager
        self.proxy_manager = proxy_manager
        
        # 如果没有提供管理器实例，尝试创建
        if self.auto_switch_manager is None and ProxyAutoSwitchManager is not None:
            if self.proxy_manager is None and ProxyManager is not None:
                self.proxy_manager = ProxyManager()
            
            if self.proxy_manager is not None:
                self.auto_switch_manager = ProxyAutoSwitchManager(self.proxy_manager)
        
        # 代理状态历史记录
        self.status_history = []
        
        # 状态文件路径
        self.status_file = os.path.join(script_dir, "data", "proxy_status_history.json")
        
        # 确保数据目录存在
        os.makedirs(os.path.dirname(self.status_file), exist_ok=True)
        
        # 加载历史记录
        self.load_status_history()
    
    def load_status_history(self):
        """加载代理状态历史记录"""
        try:
            if os.path.exists(self.status_file):
                with open(self.status_file, 'r') as f:
                    self.status_history = json.load(f)
                logger.info(f"已加载 {len(self.status_history)} 条代理状态历史记录")
        except Exception as e:
            logger.error(f"加载代理状态历史记录失败: {e}")
    
    def save_status_history(self):
        """保存代理状态历史记录"""
        try:
            # 限制历史记录数量，最多保留100条
            if len(self.status_history) > 100:
                self.status_history = self.status_history[-100:]
            
            with open(self.status_file, 'w') as f:
                json.dump(self.status_history, f, indent=2)
            logger.info(f"已保存 {len(self.status_history)} 条代理状态历史记录")
        except Exception as e:
            logger.error(f"保存代理状态历史记录失败: {e}")
    
    def get_proxy_status(self):
        """获取当前代理状态
        
        Returns:
            dict: 代理状态信息
        """
        status = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "enabled": False,
            "direct_mode": True,
            "current_node": None,
            "switch_count": 0,
            "last_switch_time": None,
            "failed_apis": [],
            "proxy_service_running": False
        }
        
        # 如果有代理自动切换管理器，获取其状态
        if self.auto_switch_manager is not None:
            auto_switch_status = self.auto_switch_manager.get_proxy_status()
            
            status["enabled"] = auto_switch_status.get("enabled", False)
            status["direct_mode"] = auto_switch_status.get("direct_mode", True)
            status["current_node"] = auto_switch_status.get("current_node")
            status["switch_count"] = auto_switch_status.get("switch_count", 0)
            status["last_switch_time"] = auto_switch_status.get("last_switch_time")
            status["failed_apis"] = list(auto_switch_status.get("failed_apis", set()))
        
        # 如果有代理管理器，获取代理服务状态
        if self.proxy_manager is not None:
            proxy_status = self.proxy_manager.get_proxy_status()
            status["proxy_service_running"] = proxy_status.get("running", False)
        
        # 添加到历史记录
        self.status_history.append(status)
        
        # 保存历史记录
        self.save_status_history()
        
        return status
    
    def format_proxy_status(self, status=None):
        """格式化代理状态信息为可读文本
        
        Args:
            status: 代理状态信息，如果为None则获取当前状态
            
        Returns:
            str: 格式化后的代理状态文本
        """
        if status is None:
            status = self.get_proxy_status()
        
        lines = []
        lines.append("=== 代理状态 ===")
        lines.append(f"时间: {status['timestamp']}")
        lines.append(f"代理启用: {'是' if status['enabled'] else '否'}")
        lines.append(f"代理服务运行: {'是' if status['proxy_service_running'] else '否'}")
        lines.append(f"直连模式: {'是' if status['direct_mode'] else '否'}")
        
        if status['current_node'] is not None:
            node = status['current_node']
            lines.append(f"当前节点: {node['name']} ({node['server']}:{node['port']})")
        else:
            lines.append("当前节点: 无")
        
        if status['last_switch_time'] is not None:
            last_switch_time = datetime.fromtimestamp(status['last_switch_time']).strftime("%Y-%m-%d %H:%M:%S")
            lines.append(f"最后切换时间: {last_switch_time}")
        else:
            lines.append("最后切换时间: 无")
        
        lines.append(f"切换次数: {status['switch_count']}")
        
        if status['failed_apis']:
            lines.append("失败的API:")
            for api in status['failed_apis']:
                lines.append(f"  - {api}")
        else:
            lines.append("失败的API: 无")
        
        return "\n".join(lines)
    
    def get_status_history_summary(self):
        """获取代理状态历史记录摘要
        
        Returns:
            str: 格式化后的代理状态历史记录摘要
        """
        if not self.status_history:
            return "没有代理状态历史记录"
        
        lines = []
        lines.append("=== 代理状态历史记录摘要 ===")
        
        # 计算统计信息
        total_switches = 0
        direct_mode_count = 0
        node_usage = {}
        
        for status in self.status_history:
            total_switches += status.get("switch_count", 0)
            
            if status.get("direct_mode", True):
                direct_mode_count += 1
            
            node = status.get("current_node")
            if node is not None and "name" in node:
                node_name = node["name"]
                node_usage[node_name] = node_usage.get(node_name, 0) + 1
        
        lines.append(f"历史记录数量: {len(self.status_history)}")
        lines.append(f"总切换次数: {total_switches}")
        lines.append(f"直连模式次数: {direct_mode_count}")
        
        if node_usage:
            lines.append("节点使用情况:")
            for node_name, count in sorted(node_usage.items(), key=lambda x: x[1], reverse=True):
                percentage = count / len(self.status_history) * 100
                lines.append(f"  - {node_name}: {count}次 ({percentage:.1f}%)")
        
        return "\n".join(lines)
    
    def display_current_status(self):
        """显示当前代理状态"""
        status = self.get_proxy_status()
        formatted_status = self.format_proxy_status(status)
        print(formatted_status)
        return formatted_status
    
    def display_status_history(self):
        """显示代理状态历史记录"""
        summary = self.get_status_history_summary()
        print(summary)
        return summary
    
    def generate_status_report(self, include_history=True):
        """生成代理状态报告
        
        Args:
            include_history: 是否包含历史记录摘要
            
        Returns:
            str: 代理状态报告
        """
        lines = []
        
        # 添加当前状态
        status = self.get_proxy_status()
        formatted_status = self.format_proxy_status(status)
        lines.append(formatted_status)
        
        # 添加历史记录摘要
        if include_history:
            lines.append("\n")
            summary = self.get_status_history_summary()
            lines.append(summary)
        
        return "\n".join(lines)
    
    def save_status_report(self, filename=None):
        """保存代理状态报告到文件
        
        Args:
            filename: 文件名，如果为None则使用默认文件名
            
        Returns:
            str: 保存的文件路径
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"proxy_status_report_{timestamp}.txt"
        
        filepath = os.path.join(script_dir, "data", filename)
        
        try:
            report = self.generate_status_report()
            
            with open(filepath, 'w') as f:
                f.write(report)
            
            logger.info(f"代理状态报告已保存到: {filepath}")
            return filepath
        except Exception as e:
            logger.error(f"保存代理状态报告失败: {e}")
            return None

# 如果直接运行此脚本，执行测试
if __name__ == "__main__":
    # 创建代理管理器
    if ProxyManager is not None:
        proxy_manager = ProxyManager()
    else:
        proxy_manager = None
    
    # 创建代理自动切换管理器
    if ProxyAutoSwitchManager is not None and proxy_manager is not None:
        auto_switch_manager = ProxyAutoSwitchManager(proxy_manager)
    else:
        auto_switch_manager = None
    
    # 创建代理状态显示
    status_display = ProxyStatusDisplay(auto_switch_manager, proxy_manager)
    
    # 显示当前状态
    print("当前代理状态:")
    status_display.display_current_status()
    
    # 显示历史记录摘要
    print("\n代理状态历史记录摘要:")
    status_display.display_status_history()
    
    # 保存状态报告
    report_path = status_display.save_status_report()
    if report_path:
        print(f"\n代理状态报告已保存到: {report_path}")

