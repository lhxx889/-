#!/bin/bash

# 加密货币监控程序修复脚本
# 此脚本将自动应用修复补丁到您的文件

echo "开始应用加密货币监控程序修复补丁..."

# 检查文件是否存在
if [ ! -f "crypto_monitor_telegram.py" ]; then
    echo "错误：找不到 crypto_monitor_telegram.py 文件"
    exit 1
fi

# 备份原文件
echo "备份原文件..."
cp crypto_monitor_telegram.py crypto_monitor_telegram.py.backup
echo "原文件已备份为 crypto_monitor_telegram.py.backup"

# 应用修复补丁
echo "应用修复补丁..."

# 检查是否已经包含修复内容
if grep -q "auto-switch" crypto_monitor_telegram.py; then
    echo "检测到文件已包含修复内容，跳过修复"
else
    echo "正在应用修复..."
    
    # 使用Python脚本应用修复
    python3 << 'EOF'
import re

# 读取文件内容
with open('crypto_monitor_telegram.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 查找并替换parse_arguments函数
old_pattern = r'(parser\.add_argument\(\'--no-announcement-notify\', action=\'store_true\',\s+help=\'禁用公告推送 \(默认: 启用\)\'\)\s+return parser\.parse_args\(\))'

new_content = '''parser.add_argument('--no-announcement-notify', action='store_true',
                        help='禁用公告推送 (默认: 启用)')
    
    # 代理自动切换相关参数
    parser.add_argument('--auto-switch', action='store_true',
                        help='启用自动切换代理 (默认: 不启用)')
    
    parser.add_argument('--auto-switch-retry', type=int, default=3,
                        help='自动切换重试次数 (默认: 3)')
    
    parser.add_argument('--auto-switch-test-interval', type=int, default=300,
                        help='自动测试间隔，秒 (默认: 300)')
    
    return parser.parse_args()'''

content = re.sub(old_pattern, new_content, content, flags=re.MULTILINE | re.DOTALL)

# 查找并替换update_config_from_args函数
old_pattern2 = r'(CONFIG\["telegram_announcement_notify"\] = not args\.no_announcement_notify\s+# 更新文件路径)'

new_content2 = '''CONFIG["telegram_announcement_notify"] = not args.no_announcement_notify
    
    # 更新代理自动切换配置
    if hasattr(args, 'auto_switch'):
        CONFIG["auto_switch_enabled"] = args.auto_switch
    if hasattr(args, 'auto_switch_retry'):
        CONFIG["auto_switch_retry"] = args.auto_switch_retry
    if hasattr(args, 'auto_switch_test_interval'):
        CONFIG["auto_switch_test_interval"] = args.auto_switch_test_interval
    
    # 更新文件路径'''

content = re.sub(old_pattern2, new_content2, content, flags=re.MULTILINE | re.DOTALL)

# 写回文件
with open('crypto_monitor_telegram.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("修复补丁应用完成")
EOF

fi

echo "修复完成！"
echo ""
echo "修复内容："
echo "1. 添加了 --auto-switch 参数支持"
echo "2. 添加了 --auto-switch-retry 参数支持"
echo "3. 添加了 --auto-switch-test-interval 参数支持"
echo "4. 更新了配置处理逻辑"
echo ""
echo "现在您可以正常使用增强版监控程序了。"
echo "如果需要恢复原文件，请使用备份文件：crypto_monitor_telegram.py.backup"

