#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
加密货币监控程序修复工具
用于应用修复补丁到 crypto_monitor_telegram.py 文件
"""

import os
import sys
import shutil
import re
from datetime import datetime

def backup_file(filepath):
    """备份原文件"""
    backup_path = f"{filepath}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(filepath, backup_path)
    print(f"原文件已备份为: {backup_path}")
    return backup_path

def check_if_fixed(filepath):
    """检查文件是否已经修复"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        return '--auto-switch' in content
    except Exception as e:
        print(f"检查文件时出错: {e}")
        return False

def apply_fix(filepath):
    """应用修复补丁"""
    try:
        # 读取文件内容
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 修复1: 在parse_arguments函数中添加新参数
        pattern1 = r"(parser\.add_argument\('--no-announcement-notify', action='store_true',\s+help='禁用公告推送 \(默认: 启用\)'\)\s+return parser\.parse_args\(\))"
        
        replacement1 = """parser.add_argument('--no-announcement-notify', action='store_true',
                        help='禁用公告推送 (默认: 启用)')
    
    # 代理自动切换相关参数
    parser.add_argument('--auto-switch', action='store_true',
                        help='启用自动切换代理 (默认: 不启用)')
    
    parser.add_argument('--auto-switch-retry', type=int, default=3,
                        help='自动切换重试次数 (默认: 3)')
    
    parser.add_argument('--auto-switch-test-interval', type=int, default=300,
                        help='自动测试间隔，秒 (默认: 300)')
    
    return parser.parse_args()"""
        
        content = re.sub(pattern1, replacement1, content, flags=re.MULTILINE | re.DOTALL)
        
        # 修复2: 在update_config_from_args函数中添加配置处理
        pattern2 = r"(CONFIG\[\"telegram_announcement_notify\"\] = not args\.no_announcement_notify\s+# 更新文件路径)"
        
        replacement2 = """CONFIG["telegram_announcement_notify"] = not args.no_announcement_notify
    
    # 更新代理自动切换配置
    if hasattr(args, 'auto_switch'):
        CONFIG["auto_switch_enabled"] = args.auto_switch
    if hasattr(args, 'auto_switch_retry'):
        CONFIG["auto_switch_retry"] = args.auto_switch_retry
    if hasattr(args, 'auto_switch_test_interval'):
        CONFIG["auto_switch_test_interval"] = args.auto_switch_test_interval
    
    # 更新文件路径"""
        
        content = re.sub(pattern2, replacement2, content, flags=re.MULTILINE | re.DOTALL)
        
        # 写回文件
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return True
        
    except Exception as e:
        print(f"应用修复时出错: {e}")
        return False

def main():
    """主函数"""
    print("=" * 60)
    print("        加密货币监控程序修复工具")
    print("=" * 60)
    
    # 检查文件是否存在
    target_file = "crypto_monitor_telegram.py"
    if not os.path.exists(target_file):
        print(f"错误: 找不到文件 {target_file}")
        print("请确保在包含该文件的目录中运行此脚本")
        sys.exit(1)
    
    # 检查是否已经修复
    if check_if_fixed(target_file):
        print("检测到文件已包含修复内容")
        choice = input("是否要重新应用修复? (y/N): ").lower()
        if choice != 'y':
            print("跳过修复")
            return
    
    # 备份原文件
    print("正在备份原文件...")
    backup_path = backup_file(target_file)
    
    # 应用修复
    print("正在应用修复补丁...")
    if apply_fix(target_file):
        print("✓ 修复补丁应用成功!")
        print()
        print("修复内容:")
        print("1. 添加了 --auto-switch 参数支持")
        print("2. 添加了 --auto-switch-retry 参数支持") 
        print("3. 添加了 --auto-switch-test-interval 参数支持")
        print("4. 更新了配置处理逻辑")
        print()
        print("现在您可以正常使用增强版监控程序了!")
        print(f"如需恢复原文件，请使用备份: {backup_path}")
    else:
        print("✗ 修复补丁应用失败!")
        print("正在恢复原文件...")
        shutil.copy2(backup_path, target_file)
        print("原文件已恢复")

if __name__ == "__main__":
    main()

