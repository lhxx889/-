# 加密货币监控系统 - 修复版本 v1.1

## 版本更新说明

### v1.1 (2025-06-08)

**修复内容：**
- 修复了增强版菜单程序启动监控时的闪退问题
- 添加了自动切换代理相关参数支持
- 改进了命令行参数解析逻辑
- 增强了配置处理功能

**新增功能：**
- 支持 `--auto-switch` 参数
- 支持 `--auto-switch-retry` 参数  
- 支持 `--auto-switch-test-interval` 参数
- 新增自动修复工具

**修复的问题：**
- 解决了 `crypto_monitor_menu_enhanced.py` 启动监控时的参数错误
- 修复了命令行参数不匹配导致的程序崩溃
- 改进了错误处理机制

**技术改进：**
- 优化了参数解析器
- 增强了配置管理
- 改进了代码兼容性

## 安装和使用

### 快速开始

1. 解压安装包到目标目录
2. 进入程序目录
3. 运行增强版菜单程序：
   ```bash
   python3 crypto_monitor_menu_enhanced.py
   ```

### 如果从旧版本升级

如果您已经有旧版本的程序，可以使用以下方法之一进行升级：

#### 方法1：使用自动修复脚本
```bash
./apply_fix.sh
```

#### 方法2：使用Python修复工具
```bash
python3 fix_tool.py
```

#### 方法3：手动替换文件
直接用新版本的 `crypto_monitor_telegram.py` 替换旧版本文件

## 文件说明

### 核心程序文件
- `crypto_monitor_menu_enhanced.py` - 增强版主菜单程序
- `crypto_monitor_telegram.py` - 核心监控程序（已修复）
- `crypto_monitor.py` - 基础监控程序
- `proxy_manager.py` - 代理管理器
- `api_wrapper.py` - API包装器

### 修复工具
- `apply_fix.sh` - 自动修复脚本
- `fix_tool.py` - Python修复工具
- `README_FIX.md` - 修复说明文档
- `BUGFIX_REPORT.md` - 详细修复报告

### 配置和数据
- `config/` - 配置文件目录
- `data/` - 数据存储目录
- `scripts/` - 辅助脚本目录

## 系统要求

- Python 3.7+
- requests 库
- beautifulsoup4 库

## 支持的功能

- Binance.US 价格监控
- Gate.io 价格监控
- 交易所公告扫描
- Telegram 推送通知
- VLESS 代理管理
- 自动代理切换
- 交互式配置界面

## 故障排除

如果遇到问题，请参考：
- `README_FIX.md` - 修复说明
- `BUGFIX_REPORT.md` - 问题分析报告
- `user_guide.md` - 用户指南

## 更新历史

- v1.1 (2025-06-08): 修复闪退问题，增加自动切换代理支持
- v1.0: 初始版本

