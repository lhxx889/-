# 加密货币监控系统 - API优化版使用说明

## 系统概述

加密货币监控系统API优化版是在深度增强版基础上进一步优化的版本，专门解决了CoinGecko API请求限制问题，并增强了系统的稳定性和可靠性。本版本实现了API请求智能管理、高效缓存系统和多数据源自动切换功能，确保即使在API限流情况下也能持续提供高质量的币种信息。

## 主要优化功能

1. **API请求智能管理**：
   - 动态延迟机制，根据API响应自动调整请求间隔
   - 指数退避算法，遇到429错误时自动增加等待时间
   - 请求队列管理，避免短时间内发送过多请求
   - 自动恢复机制，临时API不可用时自动重试

2. **高效缓存系统**：
   - 本地缓存所有API响应，减少重复请求
   - 分层缓存策略，不同类型数据使用不同的过期时间
   - 缓存一致性保证，确保数据准确性
   - 自动缓存清理，避免磁盘空间占用过大

3. **多数据源自动切换**：
   - 集成CoinGecko和CoinMarketCap双数据源
   - 根据可用性和优先级自动切换数据源
   - 数据源状态监控，自动检测和恢复
   - 跨平台ID映射，确保币种信息一致性

4. **系统稳定性增强**：
   - 全面的异常处理和日志记录
   - 自动重试机制，提高请求成功率
   - 优雅的降级策略，确保核心功能可用
   - 资源使用优化，降低系统负载

## 安装方法

### 基础安装

1. **解压下载的压缩包**：
   ```bash
   unzip crypto_monitor_optimized.zip -d crypto_monitor_optimized
   cd crypto_monitor_optimized
   ```

2. **安装必要的Python库**：
   ```bash
   pip install requests beautifulsoup4 pytz
   ```

3. **如需使用代理功能，还需安装socks支持**：
   ```bash
   pip install requests[socks]
   ```

4. **确保脚本有执行权限**：
   ```bash
   chmod +x crypto_monitor_optimized.py crypto_monitor_advanced_menu.py
   ```

## 使用方法

### 命令行使用

直接运行优化版监控脚本：
```bash
./crypto_monitor_optimized.py
```

可用的命令行参数：
```
--config CONFIG           配置文件路径
--price-only              仅监控价格
--announcement-only       仅监控公告
--telegram                启用Telegram通知
--telegram-token TOKEN    Telegram机器人Token
--telegram-chat CHAT      Telegram聊天ID
--proxy                   启用代理
--threshold THRESHOLD     价格变动阈值（百分比）
--notification-threshold  通知阈值（百分比）
--price-interval INTERVAL 价格检查间隔（秒）
--announcement-interval   公告检查间隔（秒）
```

### 交互式菜单

使用交互式菜单进行配置和控制：
```bash
./crypto_monitor_advanced_menu.py
```

## API管理器配置

API管理器可以通过配置文件进行详细配置：

```json
{
  "api_manager": {
    "cache_expiry": {
      "coin_list": 86400,
      "coin_detail": 3600,
      "market_data": 300
    },
    "data_sources": {
      "coingecko": {
        "enabled": true,
        "priority": 1,
        "api_key": ""
      },
      "coinmarketcap": {
        "enabled": true,
        "priority": 2,
        "api_key": ""
      }
    }
  }
}
```

### 缓存过期时间配置

- `coin_list`: 币种列表缓存过期时间（秒），默认24小时
- `coin_detail`: 币种详情缓存过期时间（秒），默认1小时
- `market_data`: 市场数据缓存过期时间（秒），默认5分钟

### 数据源配置

- `enabled`: 是否启用该数据源
- `priority`: 数据源优先级，数字越小优先级越高
- `api_key`: 数据源API密钥（如果有）

## 高级功能

### 添加API密钥

为了提高API请求限制，建议添加API密钥：

1. **CoinGecko API密钥**：
   - 注册CoinGecko Pro账户：https://www.coingecko.com/en/api/pricing
   - 获取API密钥
   - 在配置文件中添加：`"api_key": "YOUR_API_KEY"`

2. **CoinMarketCap API密钥**：
   - 注册CoinMarketCap开发者账户：https://coinmarketcap.com/api/
   - 获取API密钥
   - 在配置文件中添加：`"api_key": "YOUR_API_KEY"`

### 自定义缓存策略

可以根据需要调整缓存过期时间：

- 频繁变动的数据（如价格）：较短的缓存时间（5-15分钟）
- 相对稳定的数据（如币种详情）：较长的缓存时间（1-6小时）
- 很少变动的数据（如币种列表）：很长的缓存时间（12-24小时）

## 常见问题

1. **如何解决API请求限制问题？**
   - 系统已内置智能请求管理，会自动处理大多数限制
   - 添加API密钥可以获得更高的请求限额
   - 增加缓存过期时间可以减少请求频率
   - 启用多数据源可以分散请求压力

2. **如何清除缓存？**
   - 删除`cache`目录下的文件即可清除所有缓存
   - 或者使用API管理器的`_clear_cache()`方法

3. **如何添加新的数据源？**
   - 在`crypto_monitor_api_manager.py`中实现新数据源的接口
   - 在配置文件中添加新数据源的配置

4. **系统占用磁盘空间过大怎么办？**
   - 定期清理`cache`目录
   - 减少保存的历史数据量
   - 调整日志级别，减少日志输出

## 文件说明

- `crypto_monitor_optimized.py` - 优化版核心监控脚本
- `crypto_monitor_api_manager.py` - API请求智能管理器
- `crypto_monitor_advanced_menu.py` - 交互式主菜单
- `config.json` - 配置文件
- `cache/` - 缓存目录
  - `coin_list/` - 币种列表缓存
  - `coin_detail/` - 币种详情缓存
  - `market_data/` - 市场数据缓存
- `data/` - 数据存储目录
  - `price_history.json` - 价格历史记录
  - `significant_price_changes.json` - 显著价格变动记录
  - `announcement_history.json` - 公告历史记录

## 更新日志

### API优化版 (2025-06-05)
- 新增API请求智能管理功能
- 新增高效缓存系统
- 新增多数据源自动切换
- 优化系统稳定性和可靠性
- 解决CoinGecko API请求限制问题

### 深度增强版 (2025-06-05)
- 新增持币人数统计功能
- 新增历史价格变化显示
- 新增社交媒体链接集成
- 新增官网链接显示
- 新增自动化涨跌原因分析

### 增强版 (2025-06-04)
- 新增币种详细资料集成
- 新增上海时间显示
- 新增币种信息查询功能
- 优化交互式主菜单

### 基础版 (2025-06-03)
- 初始版本发布
- 基本价格监控功能
- 基本公告扫描功能
- Telegram推送功能
