# 加密货币监控系统 - 完整安装包 v1.1

这是加密货币监控系统的完整安装包，包含了所有必要的文件和最新的修复。

## 🆕 v1.1 更新内容

- ✅ **修复了增强版菜单程序的闪退问题**
- ✅ **添加了自动切换代理功能支持**
- ✅ **改进了命令行参数处理**
- ✅ **增强了错误处理机制**

## 📦 安装包内容

### 主程序文件
- `crypto_monitor_menu_enhanced.py` - 增强版交互式主菜单
- `crypto_monitor_telegram.py` - 核心监控程序（已修复）
- `crypto_monitor.py` - 基础监控程序
- `proxy_manager.py` - 代理管理器
- `api_wrapper.py` - API包装器
- `proxy_auto_switch.py` - 自动代理切换
- `proxy_status_display.py` - 代理状态显示

### 修复工具（新增）
- `apply_fix.sh` - 自动修复脚本
- `fix_tool.py` - Python修复工具
- `README_FIX.md` - 修复说明文档
- `BUGFIX_REPORT.md` - 详细修复报告

### 配置和脚本
- `config/` - 配置文件目录
- `scripts/` - 辅助脚本目录
- `data/` - 数据存储目录

### 文档
- `README.md` - 基础说明
- `README_ENHANCED.md` - 增强版说明
- `INSTALLATION_GUIDE.md` - 安装指南
- `PROXY_SETUP_GUIDE.md` - 代理设置指南
- `VERSION_CHANGELOG.md` - 版本更新日志

## 🚀 快速开始

1. **解压安装包**
   ```bash
   unzip crypto_monitor_enhanced.zip
   cd crypto_monitor
   ```

2. **安装依赖**
   ```bash
   pip install requests beautifulsoup4
   ```

3. **运行程序**
   ```bash
   python3 crypto_monitor_menu_enhanced.py
   ```

## 🔧 从旧版本升级

如果您已经有旧版本，可以使用以下方法升级：

### 自动修复（推荐）
```bash
./apply_fix.sh
```

### Python修复工具
```bash
python3 fix_tool.py
```

## ✨ 主要功能

- 📈 **价格监控**: 实时监控 Binance.US 和 Gate.io 价格变动
- 📢 **公告扫描**: 自动扫描交易所新公告和上币信息
- 📱 **Telegram推送**: 支持价格变动和公告的Telegram通知
- 🔄 **代理管理**: 完整的VLESS代理管理和自动切换
- 🎛️ **交互界面**: 友好的菜单式操作界面
- ⚙️ **灵活配置**: 支持多种参数和配置选项

## 📋 系统要求

- Python 3.7 或更高版本
- requests 库
- beautifulsoup4 库
- Linux/Windows/macOS 系统

## 🆘 故障排除

如果遇到问题，请查看：
- `README_FIX.md` - 修复说明
- `BUGFIX_REPORT.md` - 问题分析
- `user_guide.md` - 详细使用指南

## 📞 技术支持

如果您在使用过程中遇到任何问题，请参考相关文档或联系技术支持。

---

**版本**: v1.1  
**发布日期**: 2025-06-08  
**修复状态**: ✅ 已修复闪退问题

