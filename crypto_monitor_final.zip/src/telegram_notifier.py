#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Telegram通知模块 - Gate.io加密货币异动监控系统
"""

import os
import json
import logging
import requests
import time
from typing import Dict, List, Any, Optional
import sys

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import (
    TELEGRAM_API_URL, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID,
    LOG_LEVEL, LOG_FILE
)

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("telegram_notifier")

class TelegramBot:
    """Telegram机器人类"""
    
    def __init__(self, token: str):
        self.token = token
        self.api_url = f"{TELEGRAM_API_URL}{token}"
    
    def send_message(self, chat_id: str, text: str, parse_mode: str = "HTML") -> bool:
        """发送消息"""
        url = f"{self.api_url}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode
        }
        
        try:
            response = requests.post(url, json=payload)
            response.raise_for_status()
            logger.info(f"消息发送成功: {response.json()}")
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"消息发送失败: {e}")
            return False

def setup_telegram_bot(token: str) -> Dict:
    """设置Telegram机器人"""
    url = f"{TELEGRAM_API_URL}{token}/getMe"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        if data.get("ok"):
            logger.info(f"Telegram机器人设置成功: @{data['result']['username']}")
            return data["result"]
        else:
            logger.error(f"Telegram机器人设置失败: {data}")
            return {}
    except requests.exceptions.RequestException as e:
        logger.error(f"Telegram机器人设置失败: {e}")
        return {}

def format_abnormal_message(abnormal: Dict) -> str:
    """格式化异常消息"""
    currency_pair = abnormal.get("currency_pair", "")
    current_price = abnormal.get("current_price", 0)
    previous_price = abnormal.get("previous_price", 0)
    price_change_pct = abnormal.get("price_change_pct", 0)
    current_volume = abnormal.get("current_volume", 0)
    previous_volume = abnormal.get("previous_volume", 0)
    volume_change_pct = abnormal.get("volume_change_pct", 0)
    reasons = abnormal.get("reasons", [])
    timestamp = abnormal.get("timestamp", "")
    
    # 判断价格变化方向
    price_direction = "上涨" if current_price > previous_price else "下跌"
    price_emoji = "📈" if current_price > previous_price else "📉"
    
    # 判断交易量变化方向
    volume_direction = "增加" if current_volume > previous_volume else "减少"
    volume_emoji = "📈" if current_volume > previous_volume else "📉"
    
    # 格式化消息
    message = f"""
<b>⚠️ {currency_pair} 异常波动警报</b>

<b>价格变化:</b>
• 当前价格: {current_price}
• 之前价格: {previous_price}
• 变化幅度: {price_emoji} {price_direction} {price_change_pct:.2f}%

<b>交易量变化:</b>
• 当前交易量: {current_volume}
• 之前交易量: {previous_volume}
• 变化幅度: {volume_emoji} {volume_direction} {volume_change_pct:.2f}%

<b>异动原因:</b>
"""
    
    for reason in reasons:
        message += f"• {reason}\n"
    
    message += f"\n<b>检测时间:</b> {timestamp}"
    
    return message

def send_abnormal_alerts(abnormal_list: List[Dict], bot_token: str, chat_id: str) -> bool:
    """发送异常警报"""
    if not abnormal_list:
        return True
    
    bot = TelegramBot(bot_token)
    success = True
    
    for abnormal in abnormal_list:
        message = format_abnormal_message(abnormal)
        if not bot.send_message(chat_id, message):
            success = False
        
        # 避免发送过快
        time.sleep(1)
    
    return success

def main():
    """主函数 - 用于测试"""
    logger.info("Telegram通知模块测试")
    
    # 测试设置机器人
    if not TELEGRAM_BOT_TOKEN:
        print("请设置TELEGRAM_BOT_TOKEN")
        return
    
    bot_info = setup_telegram_bot(TELEGRAM_BOT_TOKEN)
    if not bot_info:
        print("设置机器人失败")
        return
    
    print(f"机器人设置成功: @{bot_info.get('username')}")
    
    # 测试发送消息
    if not TELEGRAM_CHAT_ID:
        print("请设置TELEGRAM_CHAT_ID")
        return
    
    bot = TelegramBot(TELEGRAM_BOT_TOKEN)
    success = bot.send_message(TELEGRAM_CHAT_ID, "这是一条测试消息")
    
    if success:
        print("消息发送成功")
    else:
        print("消息发送失败")

if __name__ == "__main__":
    main()
