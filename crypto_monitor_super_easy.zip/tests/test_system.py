#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试脚本 - Gate.io加密货币异动监控系统
"""

import os
import sys
import json
import time
import logging
from datetime import datetime

# 添加src目录到路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

# 导入模块
from config import (
    API_BASE_URL, DATA_DIR, LOG_LEVEL, LOG_FILE,
    PRICE_CHANGE_THRESHOLD, VOLUME_SURGE_THRESHOLD
)
from telegram_notifier import TelegramBot, setup_telegram_bot
from token_details import TokenDetailsAPI
from reason_analyzer import ReasonAnalyzer
from main import GateioAPI, DataManager

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("test")

def test_api_connection():
    """测试API连接"""
    print("\n=== 测试API连接 ===")
    api = GateioAPI()
    
    # 测试获取所有币种信息
    currencies = api.get_currencies()
    if currencies:
        print(f"✅ API连接成功，获取到{len(currencies)}个币种信息")
        return True
    else:
        print("❌ API连接失败")
        return False

def test_data_manager():
    """测试数据管理器"""
    print("\n=== 测试数据管理器 ===")
    data_manager = DataManager()
    
    # 测试获取所有交易对的Ticker信息
    success = data_manager.fetch_all_tickers()
    if success:
        print(f"✅ 获取Ticker信息成功，共{len(data_manager.current_data)}个交易对")
        
        # 保存当前数据
        data_manager.save_current_data()
        print("✅ 保存当前数据成功")
        
        # 加载上一次数据
        data_manager.load_previous_data()
        print(f"✅ 加载上一次数据成功，共{len(data_manager.previous_data)}个交易对")
        
        return True
    else:
        print("❌ 获取Ticker信息失败")
        return False

def test_abnormal_detection():
    """测试异常波动检测"""
    print("\n=== 测试异常波动检测 ===")
    data_manager = DataManager()
    
    # 加载上一次数据
    data_manager.load_previous_data()
    
    # 如果没有上一次数据，先获取并保存一次
    if not data_manager.previous_data:
        print("没有上一次数据，先获取并保存一次")
        data_manager.fetch_all_tickers()
        data_manager.save_current_data()
        
        # 修改部分数据以模拟异常波动
        print("修改部分数据以模拟异常波动")
        for pair, data in list(data_manager.current_data.items())[:5]:  # 取前5个交易对
            try:
                # 修改价格，模拟大幅上涨
                data["last"] = str(float(data["last"]) * 1.5)  # 上涨50%
                # 修改交易量，模拟交易量激增
                data["base_volume"] = str(float(data["base_volume"]) * 3)  # 增加200%
                data_manager.current_data[pair] = data
            except (ValueError, KeyError) as e:
                print(f"修改数据失败: {e}")
        
        # 保存修改后的数据
        modified_path = os.path.join(DATA_DIR, "modified_tickers.json")
        with open(modified_path, 'w') as f:
            json.dump(data_manager.current_data, f)
        print(f"✅ 已保存修改后的数据到{modified_path}")
        
        print("等待5秒后继续...")
        time.sleep(5)
        
        # 重新加载数据
        data_manager = DataManager()
        data_manager.load_previous_data()
        
        # 获取新数据
        data_manager.fetch_all_tickers()
    
    # 检测异常波动
    abnormal = data_manager.detect_abnormal_movements()
    
    if abnormal:
        print(f"✅ 检测到{len(abnormal)}个异常波动")
        for item in abnormal[:3]:  # 只显示前3个
            print(f"  - {item['currency_pair']}: {', '.join(item['reasons'])}")
        return True, abnormal
    else:
        print("❓ 未检测到异常波动，这可能是正常的，因为市场可能没有大幅波动")
        return True, []

def test_telegram_bot(bot_token=None):
    """测试Telegram机器人"""
    print("\n=== 测试Telegram机器人 ===")
    
    if not bot_token:
        print("请输入Telegram Bot Token进行测试 (如果已在config.py中设置则直接回车):")
        input_token = input().strip()
        if input_token:
            bot_token = input_token
    
    if not bot_token:
        print("❌ 未提供Bot Token，跳过测试")
        return False, None
    
    # 设置机器人
    bot_info = setup_telegram_bot(bot_token)
    if not bot_info:
        print("❌ 设置Telegram机器人失败")
        return False, None
    
    print(f"✅ 机器人设置成功: @{bot_info.get('username')}")
    print("请将此机器人添加到您的Telegram群组或频道中")
    
    print("请输入Telegram Chat ID (群组ID或频道用户名):")
    chat_id = input().strip()
    
    if not chat_id:
        print("❌ 未提供Chat ID，跳过测试")
        return False, None
    
    # 发送测试消息
    bot = TelegramBot(bot_token)
    success = bot.send_message(chat_id, "这是一条测试消息 - Gate.io加密货币异动监控系统")
    
    if success:
        print("✅ 发送测试消息成功")
        return True, (bot_token, chat_id)
    else:
        print("❌ 发送测试消息失败，请检查Chat ID是否正确")
        return False, None

def test_token_details():
    """测试币种详情查询"""
    print("\n=== 测试币种详情查询 ===")
    token_api = TokenDetailsAPI()
    
    # 测试获取币种详情
    currencies = ["BTC", "ETH", "DOGE"]
    for currency in currencies:
        print(f"获取{currency}详情...")
        details = token_api.get_currency_detail(currency)
        if details:
            print(f"✅ 获取{currency}详情成功")
            # 测试格式化消息
            message = token_api.format_token_details_message(currency)
            print(f"✅ 格式化{currency}详情消息成功")
        else:
            print(f"❌ 获取{currency}详情失败")
            return False
    
    return True

def test_reason_analyzer():
    """测试异动原因分析"""
    print("\n=== 测试异动原因分析 ===")
    analyzer = ReasonAnalyzer()
    
    # 创建模拟异常波动数据
    abnormal = {
        "currency_pair": "BTC_USDT",
        "current_price": 50000,
        "previous_price": 45000,
        "price_change_pct": 11.11,
        "current_volume": 1000000,
        "previous_volume": 500000,
        "volume_change_pct": 100,
        "reasons": ["价格上涨11.11%", "交易量增加100%"],
        "timestamp": datetime.now().isoformat()
    }
    
    # 分析异常波动原因
    print(f"分析{abnormal['currency_pair']}异常波动原因...")
    analysis = analyzer.analyze_abnormal_movement(abnormal)
    
    if analysis and "reasons" in analysis:
        print(f"✅ 分析异常波动原因成功")
        print(f"  - 可能原因: {', '.join(analysis['reasons'][:2])}")
        
        # 测试格式化消息
        message = analyzer.format_reason_message(abnormal, analysis)
        print(f"✅ 格式化原因分析消息成功")
        
        return True
    else:
        print(f"❌ 分析异常波动原因失败")
        return False

def test_full_process(bot_info=None):
    """测试完整流程"""
    print("\n=== 测试完整流程 ===")
    
    if not bot_info:
        print("未提供Telegram Bot信息，跳过完整流程测试")
        return False
    
    bot_token, chat_id = bot_info
    
    # 创建模拟异常波动数据
    abnormal = {
        "currency_pair": "BTC_USDT",
        "current_price": 50000,
        "previous_price": 45000,
        "price_change_pct": 11.11,
        "current_volume": 1000000,
        "previous_volume": 500000,
        "volume_change_pct": 100,
        "reasons": ["价格上涨11.11%", "交易量增加100%"],
        "timestamp": datetime.now().isoformat()
    }
    
    # 初始化分析器
    analyzer = ReasonAnalyzer()
    token_api = TokenDetailsAPI()
    
    try:
        # 分析异常原因
        analysis = analyzer.analyze_abnormal_movement(abnormal)
        
        # 获取币种详情
        currency_pair = abnormal.get("currency_pair", "")
        currency = currency_pair.split("_")[0] if "_" in currency_pair else currency_pair
        
        # 格式化异常消息
        from telegram_notifier import format_abnormal_message
        abnormal_message = format_abnormal_message(abnormal)
        
        # 格式化原因分析消息
        reason_message = analyzer.format_reason_message(abnormal, analysis)
        
        # 格式化币种详情消息
        token_message = token_api.format_token_details_message(currency)
        
        # 发送消息
        bot = TelegramBot(bot_token)
        
        print("发送异常波动警报...")
        success1 = bot.send_message(chat_id, abnormal_message)
        time.sleep(1)  # 避免发送过快
        
        print("发送原因分析...")
        success2 = bot.send_message(chat_id, reason_message)
        time.sleep(1)  # 避免发送过快
        
        print("发送币种详情...")
        success3 = bot.send_message(chat_id, token_message)
        
        if success1 and success2 and success3:
            print("✅ 完整流程测试成功")
            return True
        else:
            print("❌ 完整流程测试失败")
            return False
    except Exception as e:
        print(f"❌ 完整流程测试出错: {e}")
        return False

def main():
    """主函数"""
    print("Gate.io加密货币异动监控系统测试开始")
    
    # 确保数据目录存在
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # 测试API连接
    if not test_api_connection():
        print("API连接测试失败，终止测试")
        return
    
    # 测试数据管理器
    if not test_data_manager():
        print("数据管理器测试失败，终止测试")
        return
    
    # 测试异常波动检测
    abnormal_success, abnormal_data = test_abnormal_detection()
    if not abnormal_success:
        print("异常波动检测测试失败，终止测试")
        return
    
    # 测试币种详情查询
    if not test_token_details():
        print("币种详情查询测试失败，终止测试")
        return
    
    # 测试异动原因分析
    if not test_reason_analyzer():
        print("异动原因分析测试失败，终止测试")
        return
    
    # 测试Telegram机器人
    telegram_success, bot_info = test_telegram_bot()
    
    # 测试完整流程
    if telegram_success:
        test_full_process(bot_info)
    
    print("\nGate.io加密货币异动监控系统测试完成")

if __name__ == "__main__":
    main()
