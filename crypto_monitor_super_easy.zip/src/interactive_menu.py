#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交互式菜单模块 - Gate.io加密货币异动监控系统
提供运行时交互式菜单，支持动态切换监控网址和管理备用网址
"""

import os
import sys
import time
import threading
import logging
from typing import Dict, List, Any, Callable, Optional

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import LOG_LEVEL, LOG_FILE
from src.api_manager import get_api_manager, APIManager

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("interactive_menu")

class InteractiveMenu:
    """交互式菜单类"""
    
    def __init__(self, monitor_instance=None):
        self.api_manager = get_api_manager()
        self.monitor_instance = monitor_instance
        self.running = False
        self.menu_thread = None
        self.monitoring_paused = False
    
    def start(self):
        """启动交互式菜单"""
        if self.menu_thread and self.menu_thread.is_alive():
            logger.warning("交互式菜单已在运行")
            return
        
        self.running = True
        self.menu_thread = threading.Thread(target=self._menu_loop, daemon=True)
        self.menu_thread.start()
        logger.info("交互式菜单已启动")
    
    def stop(self):
        """停止交互式菜单"""
        self.running = False
        if self.menu_thread and self.menu_thread.is_alive():
            self.menu_thread.join(timeout=1.0)
        logger.info("交互式菜单已停止")
    
    def _menu_loop(self):
        """菜单循环"""
        while self.running:
            try:
                # 显示菜单选项
                self._show_menu()
                
                # 获取用户输入
                choice = input("\n请输入选项编号: ").strip()
                
                # 处理用户选择
                self._handle_choice(choice)
                
                # 暂停一下，避免CPU占用过高
                time.sleep(0.1)
            except KeyboardInterrupt:
                logger.info("收到中断信号，退出菜单")
                self.running = False
                break
            except Exception as e:
                logger.error(f"菜单操作出错: {e}")
                time.sleep(1)
    
    def _show_menu(self):
        """显示菜单选项"""
        current_url = self.api_manager.current_url
        
        print("\n" + "="*50)
        print("Gate.io加密货币异动监控系统 - 交互式菜单")
        print("="*50)
        print(f"当前API地址: {current_url}")
        print("-"*50)
        print("1. 查看所有可用API地址")
        print("2. 切换到主API地址")
        print("3. 切换到备用API地址")
        print("4. 添加自定义API地址")
        print("5. 删除自定义API地址")
        print("6. 测试当前API地址连接")
        print("-"*50)
        if self.monitoring_paused:
            print("7. 恢复监控")
        else:
            print("7. 暂停监控")
        print("8. 退出菜单（继续监控）")
        print("9. 退出程序")
        print("="*50)
    
    def _handle_choice(self, choice: str):
        """处理用户选择"""
        if choice == "1":
            self._show_all_urls()
        elif choice == "2":
            self._switch_to_primary_url()
        elif choice == "3":
            self._switch_to_backup_url()
        elif choice == "4":
            self._add_custom_url()
        elif choice == "5":
            self._remove_custom_url()
        elif choice == "6":
            self._test_current_url()
        elif choice == "7":
            self._toggle_monitoring()
        elif choice == "8":
            print("退出菜单，继续监控...")
            self.running = False
        elif choice == "9":
            print("正在退出程序...")
            self.running = False
            if self.monitor_instance:
                self.monitor_instance.stop()
            else:
                sys.exit(0)
        else:
            print("无效的选项，请重新输入")
    
    def _show_all_urls(self):
        """显示所有可用API地址"""
        all_urls = self.api_manager.get_all_urls()
        current_url = self.api_manager.current_url
        
        print("\n所有可用API地址:")
        print("-"*50)
        print(f"主API地址: {self.api_manager.primary_url}" + (" (当前)" if current_url == self.api_manager.primary_url else ""))
        
        print("\n备用API地址:")
        for i, url in enumerate(self.api_manager.backup_urls, 1):
            print(f"{i}. {url}" + (" (当前)" if current_url == url else ""))
        
        if self.api_manager.custom_urls:
            print("\n自定义API地址:")
            for i, url in enumerate(self.api_manager.custom_urls, 1):
                print(f"{i}. {url}" + (" (当前)" if current_url == url else ""))
        else:
            print("\n暂无自定义API地址")
        
        input("\n按Enter键继续...")
    
    def _switch_to_primary_url(self):
        """切换到主API地址"""
        success = self.api_manager.switch_to_url(self.api_manager.primary_url)
        if success:
            print(f"已切换到主API地址: {self.api_manager.primary_url}")
        else:
            print("切换失败，请检查API地址是否有效")
    
    def _switch_to_backup_url(self):
        """切换到备用API地址"""
        backup_urls = self.api_manager.backup_urls
        if not backup_urls:
            print("没有可用的备用API地址")
            return
        
        print("\n可用的备用API地址:")
        for i, url in enumerate(backup_urls, 1):
            print(f"{i}. {url}")
        
        try:
            choice = input("\n请选择备用API地址编号 (输入0返回): ").strip()
            if choice == "0":
                return
            
            index = int(choice) - 1
            if 0 <= index < len(backup_urls):
                success = self.api_manager.switch_to_url(backup_urls[index])
                if success:
                    print(f"已切换到备用API地址: {backup_urls[index]}")
                else:
                    print("切换失败，请检查API地址是否有效")
            else:
                print("无效的选项")
        except ValueError:
            print("请输入有效的数字")
    
    def _add_custom_url(self):
        """添加自定义API地址"""
        url = input("\n请输入自定义API地址 (输入0返回): ").strip()
        if url == "0":
            return
        
        success = self.api_manager.add_custom_url(url)
        if success:
            print(f"已添加自定义API地址: {url}")
            
            # 询问是否切换到新添加的地址
            choice = input("是否切换到新添加的API地址? (y/n): ").strip().lower()
            if choice == "y":
                self.api_manager.switch_to_url(url)
                print(f"已切换到API地址: {url}")
        else:
            print("添加失败，请检查API地址是否有效")
    
    def _remove_custom_url(self):
        """删除自定义API地址"""
        custom_urls = self.api_manager.custom_urls
        if not custom_urls:
            print("没有可用的自定义API地址")
            return
        
        print("\n可用的自定义API地址:")
        for i, url in enumerate(custom_urls, 1):
            print(f"{i}. {url}")
        
        try:
            choice = input("\n请选择要删除的API地址编号 (输入0返回): ").strip()
            if choice == "0":
                return
            
            index = int(choice) - 1
            if 0 <= index < len(custom_urls):
                url = custom_urls[index]
                confirm = input(f"确认删除 {url}? (y/n): ").strip().lower()
                if confirm == "y":
                    success = self.api_manager.remove_custom_url(url)
                    if success:
                        print(f"已删除自定义API地址: {url}")
                    else:
                        print("删除失败")
                else:
                    print("已取消删除")
            else:
                print("无效的选项")
        except ValueError:
            print("请输入有效的数字")
    
    def _test_current_url(self):
        """测试当前API地址连接"""
        print("\n正在测试当前API地址连接...")
        success = self.api_manager.test_current_url()
        if success:
            print(f"连接测试成功: {self.api_manager.current_url}")
        else:
            print(f"连接测试失败: {self.api_manager.current_url}")
            
            # 询问是否切换到健康的URL
            choice = input("是否切换到健康的API地址? (y/n): ").strip().lower()
            if choice == "y":
                healthy_url = self.api_manager.get_healthy_url()
                if healthy_url:
                    print(f"已切换到健康的API地址: {healthy_url}")
                else:
                    print("没有找到健康的API地址")
    
    def _toggle_monitoring(self):
        """切换监控状态"""
        if not self.monitor_instance:
            print("监控实例未初始化，无法切换状态")
            return
        
        if self.monitoring_paused:
            # 恢复监控
            self.monitor_instance.resume()
            self.monitoring_paused = False
            print("已恢复监控")
        else:
            # 暂停监控
            self.monitor_instance.pause()
            self.monitoring_paused = True
            print("已暂停监控")

def create_menu(monitor_instance=None) -> InteractiveMenu:
    """创建交互式菜单实例"""
    return InteractiveMenu(monitor_instance)

if __name__ == "__main__":
    # 测试代码
    menu = create_menu()
    menu.start()
    
    try:
        # 保持主线程运行
        while menu.running:
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("收到中断信号，退出程序")
    finally:
        menu.stop()
