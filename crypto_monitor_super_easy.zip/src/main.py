#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
主程序 - Gate.io加密货币异动监控系统
集成所有模块，实现完整功能，支持交互式菜单和动态切换API地址
"""

import os
import sys
import time
import json
import logging
import requests
import threading
import signal
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import (
    CHECK_INTERVAL, PRICE_CHANGE_THRESHOLD, 
    VOLUME_SURGE_THRESHOLD, CONTINUOUS_RUN, LOG_LEVEL, LOG_FILE,
    DATA_DIR, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
)

# 导入各模块
from src.api_manager import get_api_manager
from src.interactive_menu import create_menu
from src.telegram_notifier import TelegramBot, send_abnormal_alerts, setup_telegram_bot, format_abnormal_message
from src.token_details import TokenDetailsAPI
from src.reason_analyzer import ReasonAnalyzer

# 确保数据目录存在
os.makedirs(DATA_DIR, exist_ok=True)

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("crypto_monitor")

class DataManager:
    """数据管理器"""
    
    def __init__(self):
        self.api_manager = get_api_manager()
        self.previous_data = {}  # 上一次的数据
        self.current_data = {}   # 当前数据
        self.alerts = []         # 异动警报
    
    def load_previous_data(self):
        """加载上一次的数据"""
        try:
            file_path = os.path.join(DATA_DIR, "previous_tickers.json")
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    self.previous_data = json.load(f)
                logger.info(f"已加载上一次数据，共{len(self.previous_data)}个交易对")
            else:
                logger.info("未找到上一次数据，将在本次运行后创建")
        except Exception as e:
            logger.error(f"加载上一次数据失败: {e}")
    
    def save_current_data(self):
        """保存当前数据作为下一次的上一次数据"""
        try:
            file_path = os.path.join(DATA_DIR, "previous_tickers.json")
            with open(file_path, 'w') as f:
                json.dump(self.current_data, f)
            logger.info(f"已保存当前数据，共{len(self.current_data)}个交易对")
        except Exception as e:
            logger.error(f"保存当前数据失败: {e}")
    
    def fetch_all_tickers(self):
        """获取所有交易对的Ticker信息"""
        tickers = self.api_manager.request("GET", "/spot/tickers")
        if tickers:
            # 将列表转换为以currency_pair为键的字典
            self.current_data = {ticker["currency_pair"]: ticker for ticker in tickers}
            logger.info(f"已获取{len(self.current_data)}个交易对的Ticker信息")
            return True
        else:
            logger.error("获取Ticker信息失败")
            return False
    
    def detect_abnormal_movements(self):
        """检测异常波动"""
        if not self.previous_data:
            logger.info("没有上一次数据，无法检测异常波动")
            return []
        
        abnormal = []
        for pair, current in self.current_data.items():
            if pair not in self.previous_data:
                continue
            
            previous = self.previous_data[pair]
            
            # 计算价格变化百分比
            try:
                prev_price = float(previous.get("last", 0))
                curr_price = float(current.get("last", 0))
                if prev_price > 0:
                    price_change_pct = abs((curr_price - prev_price) / prev_price * 100)
                else:
                    price_change_pct = 0
                
                # 计算交易量变化百分比
                prev_volume = float(previous.get("base_volume", 0))
                curr_volume = float(current.get("base_volume", 0))
                if prev_volume > 0:
                    volume_change_pct = abs((curr_volume - prev_volume) / prev_volume * 100)
                else:
                    volume_change_pct = 0
                
                # 检测异常
                is_abnormal = False
                reasons = []
                
                if price_change_pct >= PRICE_CHANGE_THRESHOLD:
                    is_abnormal = True
                    direction = "上涨" if curr_price > prev_price else "下跌"
                    reasons.append(f"价格{direction}{price_change_pct:.2f}%")
                
                if volume_change_pct >= VOLUME_SURGE_THRESHOLD:
                    is_abnormal = True
                    direction = "增加" if curr_volume > prev_volume else "减少"
                    reasons.append(f"交易量{direction}{volume_change_pct:.2f}%")
                
                if is_abnormal:
                    abnormal.append({
                        "currency_pair": pair,
                        "current_price": curr_price,
                        "previous_price": prev_price,
                        "price_change_pct": price_change_pct,
                        "current_volume": curr_volume,
                        "previous_volume": prev_volume,
                        "volume_change_pct": volume_change_pct,
                        "reasons": reasons,
                        "timestamp": datetime.now().isoformat()
                    })
            except (ValueError, TypeError) as e:
                logger.error(f"处理交易对{pair}时出错: {e}")
        
        logger.info(f"检测到{len(abnormal)}个异常波动")
        return abnormal

class CryptoMonitor:
    """加密货币监控器"""
    
    def __init__(self):
        self.data_manager = DataManager()
        self.running = False
        self.paused = False
        self.monitor_thread = None
        self.menu = None
    
    def setup_bot(self):
        """设置Telegram机器人"""
        global TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
        
        if not TELEGRAM_BOT_TOKEN:
            print("请输入Telegram Bot Token:")
            TELEGRAM_BOT_TOKEN = input().strip()
        
        # 设置机器人
        bot_info = setup_telegram_bot(TELEGRAM_BOT_TOKEN)
        if not bot_info:
            logger.error("设置Telegram机器人失败")
            return False
        
        print(f"机器人设置成功: @{bot_info.get('username')}")
        print("请将此机器人添加到您的Telegram群组或频道中")
        
        if not TELEGRAM_CHAT_ID:
            print("请输入Telegram Chat ID (群组ID或频道用户名):")
            TELEGRAM_CHAT_ID = input().strip()
        
        # 发送测试消息
        bot = TelegramBot(TELEGRAM_BOT_TOKEN)
        success = bot.send_message(TELEGRAM_CHAT_ID, "Gate.io加密货币异动监控系统已启动，正在监控中...")
        
        if not success:
            logger.error("发送测试消息失败，请检查Chat ID是否正确")
            return False
        
        logger.info("Telegram机器人设置成功")
        return True
    
    def process_abnormal_movements(self, abnormal_list):
        """处理异常波动"""
        if not abnormal_list:
            return
        
        # 初始化分析器
        analyzer = ReasonAnalyzer()
        token_api = TokenDetailsAPI()
        
        for abnormal in abnormal_list:
            try:
                # 分析异常原因
                analysis = analyzer.analyze_abnormal_movement(abnormal)
                
                # 获取币种详情
                currency_pair = abnormal.get("currency_pair", "")
                currency = currency_pair.split("_")[0] if "_" in currency_pair else currency_pair
                
                # 格式化异常消息
                abnormal_message = format_abnormal_message(abnormal)
                
                # 格式化原因分析消息
                reason_message = analyzer.format_reason_message(abnormal, analysis)
                
                # 格式化币种详情消息
                token_message = token_api.format_token_details_message(currency)
                
                # 发送消息
                bot = TelegramBot(TELEGRAM_BOT_TOKEN)
                
                # 发送异常警报
                bot.send_message(TELEGRAM_CHAT_ID, abnormal_message)
                time.sleep(1)  # 避免发送过快
                
                # 发送原因分析
                bot.send_message(TELEGRAM_CHAT_ID, reason_message)
                time.sleep(1)  # 避免发送过快
                
                # 发送币种详情
                bot.send_message(TELEGRAM_CHAT_ID, token_message)
                
                logger.info(f"已发送{currency_pair}的异常波动警报、原因分析和币种详情")
            except Exception as e:
                logger.error(f"处理异常波动时出错: {e}")
    
    def start(self):
        """启动监控"""
        if self.running:
            logger.warning("监控已在运行")
            return
        
        # 设置Telegram机器人
        if not self.setup_bot():
            logger.error("设置Telegram机器人失败，程序退出")
            return
        
        # 加载上一次数据
        self.data_manager.load_previous_data()
        
        # 启动监控线程
        self.running = True
        self.paused = False
        self.monitor_thread = threading.Thread(target=self._monitor_loop)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        # 创建并启动交互式菜单
        self.menu = create_menu(self)
        self.menu.start()
        
        logger.info("监控已启动")
    
    def stop(self):
        """停止监控"""
        self.running = False
        
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=1.0)
        
        if self.menu:
            self.menu.stop()
        
        logger.info("监控已停止")
    
    def pause(self):
        """暂停监控"""
        self.paused = True
        logger.info("监控已暂停")
    
    def resume(self):
        """恢复监控"""
        self.paused = False
        logger.info("监控已恢复")
    
    def _monitor_loop(self):
        """监控循环"""
        while self.running:
            try:
                if not self.paused:
                    logger.info(f"开始新一轮检查，时间: {datetime.now().isoformat()}")
                    
                    # 获取所有交易对的Ticker信息
                    if self.data_manager.fetch_all_tickers():
                        # 检测异常波动
                        abnormal = self.data_manager.detect_abnormal_movements()
                        
                        # 处理异常波动
                        self.process_abnormal_movements(abnormal)
                        
                        # 保存当前数据作为下一次的上一次数据
                        self.data_manager.save_current_data()
                        
                        # 输出异常波动信息
                        if abnormal:
                            for item in abnormal:
                                logger.info(f"异常波动: {item['currency_pair']}, 原因: {', '.join(item['reasons'])}")
                            
                            # 保存异常波动信息
                            try:
                                timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                                file_path = os.path.join(DATA_DIR, f"abnormal_{timestamp}.json")
                                with open(file_path, 'w') as f:
                                    json.dump(abnormal, f)
                                logger.info(f"已保存异常波动信息到{file_path}")
                            except Exception as e:
                                logger.error(f"保存异常波动信息失败: {e}")
                
                # 如果不是持续运行，则退出
                if not CONTINUOUS_RUN:
                    self.running = False
                    break
                
                # 等待下一次检查
                logger.info(f"等待{CHECK_INTERVAL}秒后进行下一次检查")
                
                # 分段等待，以便能够及时响应暂停/恢复/停止命令
                wait_interval = 0.5  # 每次等待0.5秒
                for _ in range(int(CHECK_INTERVAL / wait_interval)):
                    if not self.running:
                        break
                    time.sleep(wait_interval)
            
            except Exception as e:
                logger.error(f"监控循环出错: {e}")
                time.sleep(5)  # 出错后等待一段时间再继续

def signal_handler(sig, frame):
    """信号处理函数"""
    print("\n收到中断信号，正在安全退出...")
    if monitor:
        monitor.stop()
    sys.exit(0)

# 全局监控器实例
monitor = None

def main():
    """主函数"""
    global monitor
    
    # 注册信号处理函数
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("Gate.io加密货币异动监控系统启动")
    
    # 确保数据目录存在
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # 创建并启动监控器
    monitor = CryptoMonitor()
    monitor.start()
    
    try:
        # 保持主线程运行
        while monitor.running:
            time.sleep(0.1)
    except KeyboardInterrupt:
        logger.info("收到中断信号，程序退出")
    except Exception as e:
        logger.error(f"程序运行出错: {e}")
    finally:
        if monitor:
            monitor.stop()
        logger.info("Gate.io加密货币异动监控系统关闭")

if __name__ == "__main__":
    main()
