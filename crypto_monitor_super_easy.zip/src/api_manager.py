#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
API管理器 - Gate.io加密货币异动监控系统
支持动态切换监控网址和备用网址管理
"""

import os
import json
import logging
import requests
import time
import sys
from typing import Dict, List, Any, Optional

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import (
    PRIMARY_API_URL, BACKUP_API_URLS, API_RATE_LIMIT, 
    API_RATE_WINDOW, LOG_LEVEL, LOG_FILE, DATA_DIR
)

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("api_manager")

class RateLimiter:
    """API请求速率限制器"""
    
    def __init__(self, limit: int, window: int):
        self.limit = limit  # 窗口期内最大请求数
        self.window = window  # 窗口期（秒）
        self.timestamps = []  # 请求时间戳列表
    
    def can_request(self) -> bool:
        """检查是否可以发送请求"""
        now = time.time()
        # 移除窗口期外的时间戳
        self.timestamps = [ts for ts in self.timestamps if now - ts < self.window]
        # 检查是否达到限制
        return len(self.timestamps) < self.limit
    
    def add_request(self):
        """记录一次请求"""
        self.timestamps.append(time.time())
    
    def wait_if_needed(self):
        """如果达到限制，等待到可以请求为止"""
        while not self.can_request():
            time.sleep(0.1)
        self.add_request()

class APIManager:
    """API管理器，支持动态切换API地址"""
    
    def __init__(self):
        # 加载配置
        self.primary_url = PRIMARY_API_URL
        self.backup_urls = BACKUP_API_URLS.copy()
        self.current_url = self.primary_url
        self.custom_urls = []
        
        # 创建速率限制器
        self.rate_limiter = RateLimiter(API_RATE_LIMIT, API_RATE_WINDOW)
        
        # 创建会话
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        
        # 加载自定义URL
        self.load_custom_urls()
        
        # 确保数据目录存在
        os.makedirs(DATA_DIR, exist_ok=True)
        
        logger.info(f"API管理器初始化完成，当前API地址: {self.current_url}")
    
    def load_custom_urls(self):
        """加载自定义URL"""
        try:
            custom_urls_file = os.path.join(DATA_DIR, "custom_urls.json")
            if os.path.exists(custom_urls_file):
                with open(custom_urls_file, 'r') as f:
                    data = json.load(f)
                    if "urls" in data and isinstance(data["urls"], list):
                        self.custom_urls = data["urls"]
                        logger.info(f"已加载{len(self.custom_urls)}个自定义URL")
        except Exception as e:
            logger.error(f"加载自定义URL失败: {e}")
    
    def save_custom_urls(self):
        """保存自定义URL"""
        try:
            custom_urls_file = os.path.join(DATA_DIR, "custom_urls.json")
            with open(custom_urls_file, 'w') as f:
                json.dump({"urls": self.custom_urls}, f)
            logger.info(f"已保存{len(self.custom_urls)}个自定义URL")
        except Exception as e:
            logger.error(f"保存自定义URL失败: {e}")
    
    def get_all_urls(self) -> List[str]:
        """获取所有可用的URL"""
        return [self.primary_url] + self.backup_urls + self.custom_urls
    
    def add_custom_url(self, url: str) -> bool:
        """添加自定义URL"""
        if not url:
            return False
        
        # 规范化URL格式
        if not url.startswith("http"):
            url = "https://" + url
        
        # 确保URL以/结尾
        if not url.endswith("/"):
            url += "/"
        
        # 检查URL是否已存在
        if url in self.get_all_urls():
            logger.warning(f"URL已存在: {url}")
            return False
        
        # 测试URL连接
        try:
            response = requests.get(url, timeout=5)
            if response.status_code >= 400:
                logger.error(f"URL连接测试失败，状态码: {response.status_code}")
                return False
        except Exception as e:
            logger.error(f"URL连接测试失败: {e}")
            return False
        
        # 添加URL
        self.custom_urls.append(url)
        self.save_custom_urls()
        logger.info(f"已添加自定义URL: {url}")
        return True
    
    def remove_custom_url(self, url: str) -> bool:
        """移除自定义URL"""
        if url in self.custom_urls:
            self.custom_urls.remove(url)
            self.save_custom_urls()
            logger.info(f"已移除自定义URL: {url}")
            
            # 如果当前URL被移除，切换到主URL
            if self.current_url == url:
                self.switch_to_url(self.primary_url)
            
            return True
        return False
    
    def switch_to_url(self, url: str) -> bool:
        """切换到指定URL"""
        if url in self.get_all_urls():
            self.current_url = url
            logger.info(f"已切换到URL: {url}")
            return True
        return False
    
    def switch_to_next_url(self) -> str:
        """切换到下一个可用URL"""
        all_urls = self.get_all_urls()
        if not all_urls:
            logger.error("没有可用的URL")
            return ""
        
        # 找到当前URL的索引
        try:
            current_index = all_urls.index(self.current_url)
        except ValueError:
            current_index = -1
        
        # 切换到下一个URL
        next_index = (current_index + 1) % len(all_urls)
        next_url = all_urls[next_index]
        self.current_url = next_url
        logger.info(f"已切换到下一个URL: {next_url}")
        return next_url
    
    def test_url(self, url: str) -> bool:
        """测试URL连接"""
        try:
            response = requests.get(url, timeout=5)
            return response.status_code < 400
        except Exception:
            return False
    
    def test_current_url(self) -> bool:
        """测试当前URL连接"""
        return self.test_url(self.current_url)
    
    def get_healthy_url(self) -> str:
        """获取健康的URL"""
        # 先测试当前URL
        if self.test_current_url():
            return self.current_url
        
        # 测试所有URL
        for url in self.get_all_urls():
            if self.test_url(url):
                self.current_url = url
                logger.info(f"已切换到健康URL: {url}")
                return url
        
        logger.error("没有健康的URL可用")
        return ""
    
    def request(self, method: str, endpoint: str, params: Dict = None) -> Any:
        """发送API请求"""
        self.rate_limiter.wait_if_needed()
        
        # 确保有健康的URL
        url = self.get_healthy_url()
        if not url:
            logger.error("没有健康的URL可用，请求失败")
            return None
        
        # 发送请求
        full_url = f"{url}{endpoint}"
        try:
            response = self.session.request(method, full_url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求错误: {e}")
            
            # 如果请求失败，尝试切换到下一个URL
            next_url = self.switch_to_next_url()
            if next_url and next_url != url:
                logger.info(f"尝试使用新URL重新请求")
                return self.request(method, endpoint, params)
            
            return None

# 创建全局API管理器实例
api_manager = APIManager()

def get_api_manager() -> APIManager:
    """获取API管理器实例"""
    return api_manager

if __name__ == "__main__":
    # 测试代码
    manager = get_api_manager()
    print(f"当前URL: {manager.current_url}")
    print(f"所有URL: {manager.get_all_urls()}")
    
    # 测试添加自定义URL
    success = manager.add_custom_url("https://api-example.com/v4")
    print(f"添加URL结果: {success}")
    
    # 测试切换URL
    success = manager.switch_to_url(manager.primary_url)
    print(f"切换URL结果: {success}")
    
    # 测试API请求
    result = manager.request("GET", "/spot/currencies")
    print(f"API请求结果: {result is not None}")
