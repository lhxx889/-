# 加密货币监控系统 - 修复版本 v1.2

## 版本更新说明

### v1.2 (2025-06-08)

**新增修复：**
- 修复了Telegram连接测试中的代理参数错误
- 解决了 `api_request() got an unexpected keyword argument 'proxies'` 问题
- 改进了与api_wrapper的兼容性

**修复内容：**
- 修复了增强版菜单程序启动监控时的闪退问题
- 添加了自动切换代理相关参数支持
- 改进了命令行参数解析逻辑
- 增强了配置处理功能
- **新增：修复了Telegram连接测试功能**

**技术改进：**
- 优化了Telegram连接测试的请求方式
- 添加了auto_proxy参数避免与api_wrapper冲突
- 改进了代理处理逻辑
- 增强了错误处理机制

### v1.1 (2025-06-08)

**修复内容：**
- 修复了增强版菜单程序启动监控时的闪退问题
- 添加了自动切换代理相关参数支持
- 改进了命令行参数解析逻辑
- 增强了配置处理功能

## 安装和使用

### 快速开始

1. 解压安装包到目标目录
2. 进入程序目录
3. 运行增强版菜单程序：
   ```bash
   python3 crypto_monitor_menu_enhanced.py
   ```

### 如果从旧版本升级

如果您已经有旧版本的程序，可以使用以下方法之一进行升级：

#### 方法1：使用自动修复脚本
```bash
./apply_fix.sh
```

#### 方法2：使用Python修复工具
```bash
python3 fix_tool.py
```

#### 方法3：手动替换文件
直接用新版本的文件替换旧版本文件

## 文件说明

### 核心程序文件
- `crypto_monitor_menu_enhanced.py` - 增强版主菜单程序（已修复Telegram测试）
- `crypto_monitor_telegram.py` - 核心监控程序（已修复参数问题）
- `crypto_monitor.py` - 基础监控程序
- `proxy_manager.py` - 代理管理器
- `api_wrapper.py` - API包装器

### 修复工具
- `apply_fix.sh` - 自动修复脚本
- `fix_tool.py` - Python修复工具
- `README_FIX.md` - 修复说明文档
- `BUGFIX_REPORT.md` - 详细修复报告

### 配置和数据
- `config/` - 配置文件目录
- `data/` - 数据存储目录
- `scripts/` - 辅助脚本目录

## 系统要求

- Python 3.7+
- requests 库
- beautifulsoup4 库

## 支持的功能

- Binance.US 价格监控
- Gate.io 价格监控
- 交易所公告扫描
- Telegram 推送通知（已修复连接测试）
- VLESS 代理管理
- 自动代理切换
- 交互式配置界面

## 故障排除

如果遇到问题，请参考：
- `README_FIX.md` - 修复说明
- `BUGFIX_REPORT.md` - 问题分析报告
- `user_guide.md` - 用户指南

## 更新历史

- v1.2 (2025-06-08): 修复Telegram连接测试问题，完善代理兼容性
- v1.1 (2025-06-08): 修复闪退问题，增加自动切换代理支持
- v1.0: 初始版本

