# 加密货币监控工具安装指南

## 系统要求

- 操作系统：Ubuntu 20.04+ / Debian 10+ / CentOS 7+
- Python版本：Python 3.6+
- 网络：稳定的互联网连接

## 安装步骤

### 1. 安装必要的依赖

```bash
# 更新软件包列表
apt update

# 安装Python和pip
apt install -y python3 python3-pip

# 安装必要的Python库
pip3 install requests beautifulsoup4 pytz

# 安装代理支持
pip3 install 'requests[socks]'
```

### 2. 解压安装包

```bash
# 解压安装包到指定目录
unzip crypto_monitor_optimized_with_proxy.zip -d crypto_monitor
cd crypto_monitor
```

### 3. 运行主菜单

```bash
# 使用Python3运行主菜单脚本
python3 crypto_monitor_advanced_menu.py
```

## 配置内置代理

### 方法一：使用内置代理管理菜单

1. 在主菜单中选择"10. 内置代理管理"
2. 选择"1. 安装内置代理"进行一键安装
3. 安装完成后选择"2. 启动代理服务"
4. 使用"4. 测试代理连接"验证代理是否正常工作
5. 最后选择"5. 应用代理设置"将代理应用到监控系统

### 方法二：使用自定义代理设置

1. 编辑`config/proxy_template.json`文件
2. 修改以下参数:
   ```json
   {
     "server": "您的代理服务器地址",
     "server_port": 您的端口号,
     "uuid": "您的UUID",
     "flow": "xtls-rprx-vision",
     "tls": {
       "server_name": "您的SNI",
       "reality": {
         "public_key": "您的公钥",
         "short_id": "您的short_id"
       }
     }
   }
   ```
3. 修改后重新安装或重启代理服务

## 常见问题解决

### 1. 代理安装失败

- 确保有足够的权限(root或sudo)
- 查看`proxy_manager.log`日志文件
- 尝试手动运行`scripts/install_proxy.sh`

### 2. 代理无法启动

- 检查端口1080和7890是否被占用
- 确认sing-box二进制文件存在且有执行权限
- 查看systemd服务日志:`journalctl -u sing-box`

### 3. API请求限制错误

- 增加价格检查间隔到至少5分钟
- 启用API响应缓存并设置较长的缓存时间
- 配置有效的API密钥

### 4. Python命令未找到

- 使用`python3`替代`python`命令
- 确认Python 3已正确安装

### 5. 代理连接测试失败

- 确认代理服务正在运行
- 检查网络连接和防火墙设置
- 尝试更换代理节点
