# 加密货币监控程序修复补丁

## 修复内容

本补丁修复了增强版菜单程序启动监控时的闪退问题。

## 修复文件

- `crypto_monitor_telegram.py`

## 修复方法

您可以选择以下任一方法应用修复：

### 方法1：使用修复脚本（推荐）

1. 打开终端，进入程序目录
2. 运行以下命令：
   ```bash
   ./apply_fix.sh
   ```
3. 脚本会自动备份原文件并应用修复

### 方法2：使用Python修复工具

1. 打开终端，进入程序目录
2. 运行以下命令：
   ```bash
   python3 fix_tool.py
   ```
3. 工具会自动备份原文件并应用修复

### 方法3：手动修改

如果您希望手动应用修复，请按照以下步骤操作：

1. 打开 `crypto_monitor_telegram.py` 文件
2. 找到 `parse_arguments()` 函数（约在第659行）
3. 在函数末尾，在 `return parser.parse_args()` 之前添加以下代码：
   ```python
   # 代理自动切换相关参数
   parser.add_argument('--auto-switch', action='store_true',
                       help='启用自动切换代理 (默认: 不启用)')
   
   parser.add_argument('--auto-switch-retry', type=int, default=3,
                       help='自动切换重试次数 (默认: 3)')
   
   parser.add_argument('--auto-switch-test-interval', type=int, default=300,
                       help='自动测试间隔，秒 (默认: 300)')
   ```
4. 找到 `update_config_from_args()` 函数（约在第730行）
5. 在更新Telegram配置的代码块后，在 `# 更新文件路径` 注释前添加以下代码：
   ```python
   # 更新代理自动切换配置
   if hasattr(args, 'auto_switch'):
       CONFIG["auto_switch_enabled"] = args.auto_switch
   if hasattr(args, 'auto_switch_retry'):
       CONFIG["auto_switch_retry"] = args.auto_switch_retry
   if hasattr(args, 'auto_switch_test_interval'):
       CONFIG["auto_switch_test_interval"] = args.auto_switch_test_interval
   ```

## 验证修复

应用修复后，请运行以下命令测试程序：

```bash
python3 crypto_monitor_menu_enhanced.py
```

选择选项1启动监控，程序应该能够正常启动而不会闪退。

