import sqlite3

conn = sqlite3.connect("settings.db")
conn.execute("""
CREATE TABLE IF NOT EXISTS config (
    id INTEGER PRIMARY KEY,
    telegram_token TEXT,
    telegram_chat_id TEXT
)
""")
conn.commit()

conn = sqlite3.connect("logs.db")
conn.execute("""
CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT,
    price REAL,
    volume REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()
print("✅ 数据库初始化完成")
