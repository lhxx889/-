import threading
import time
from utils.gateio_api import fetch_market_data
from utils.telegram_bot import send_telegram_alert
from utils.analyzer import analyze_spike
from utils.logger import setup_logger
import sqlite3

logger = setup_logger()

def load_config():
    conn = sqlite3.connect("settings.db")
    row = conn.execute("SELECT * FROM config WHERE id=1").fetchone()
    return row["telegram_token"], row["telegram_chat_id"] if row else (None, None)

def log_price(symbol, price, volume):
    conn = sqlite3.connect("logs.db")
    conn.execute("INSERT INTO price_history (symbol, price, volume) VALUES (?, ?, ?)", (symbol, price, volume))
    conn.commit()

def monitor():
    old_data = {}
    while True:
        try:
            market = fetch_market_data()
            for symbol, data in market.items():
                old = old_data.get(symbol)
                if old:
                    price_change = abs(data["price"] - old["price"]) / old["price"]
                    volume_change = data["volume"] - old["volume"]
                    if price_change > 0.45 or volume_change > old["volume"] * 2:
                        token, chat_id = load_config()
                        reason = analyze_spike(symbol, data)
                        message = f"🚨 异动警报: {symbol}\n价格: {data['price']}\n成交量: {data['volume']}\n原因: {reason}"
                        if token and chat_id:
                            send_telegram_alert(token, chat_id, message)
                        logger.info(message)
                        log_price(symbol, data["price"], data["volume"])
                old_data[symbol] = data
        except Exception as e:
            logger.error(f"监控错误: {e}")
        time.sleep(50)

if __name__ == "__main__":
    threading.Thread(target=monitor, daemon=True).start()
    while True:
        time.sleep(3600)
