from fastapi import FastAPI, Request, Form, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
import sqlite3
import asyncio

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return HTMLResponse(open("templates/dashboard.html").read())

@app.get("/config", response_class=HTMLResponse)
async def config_form(request: Request):
    conn = sqlite3.connect("settings.db")
    row = conn.execute("SELECT * FROM config WHERE id=1").fetchone()
    token = row["telegram_token"] if row else ""
    chat = row["telegram_chat_id"] if row else ""
    html = open("templates/config.html").read()
    return HTMLResponse(html.replace("{{ token }}", token).replace("{{ chat }}", chat))

@app.post("/config")
async def update_config(token: str = Form(...), chat: str = Form(...)):
    conn = sqlite3.connect("settings.db")
    conn.execute("REPLACE INTO config (id, telegram_token, telegram_chat_id) VALUES (1, ?, ?)", (token, chat))
    conn.commit()
    return {"status": "saved"}

@app.get("/chart", response_class=HTMLResponse)
async def chart_page(request: Request):
    return HTMLResponse(open("templates/chart.html").read())

@app.get("/api/chart")
async def chart_data(symbol: str):
    conn = sqlite3.connect("logs.db")
    rows = conn.execute("SELECT timestamp, price FROM price_history WHERE symbol=? ORDER BY timestamp DESC LIMIT 100", (symbol,)).fetchall()
    return {
        "labels": [r[0] for r in rows],
        "data": [r[1] for r in rows]
    }

@app.websocket("/ws/logs")
async def websocket_logs(websocket: WebSocket):
    await websocket.accept()
    try:
        with open("logs/monitor.log") as f:
            f.seek(0, 2)
            while True:
                line = f.readline()
                if line:
                    await websocket.send_text(line)
                else:
                    await asyncio.sleep(1)
    except WebSocketDisconnect:
        pass
