def analyze_spike(symbol, data):
    # 简单分析逻辑，可以扩展
    if data["volume"] > 1000000:
        return "成交量异常放大，可能有大户入场"
    elif data["price"] > 1000:
        return "价格较高，可能有新闻推动"
    return "暂无法确定原因"
