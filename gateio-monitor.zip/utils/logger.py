import logging

def setup_logger():
    logger = logging.getLogger("monitor")
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler("logs/monitor.log")
    fh.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(fh)
    return logger
