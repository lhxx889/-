import requests

def fetch_market_data():
    url = "https://api.gate.io/api2/1/tickers"
    response = requests.get(url)
    data = response.json()
    result = {}
    for symbol, val in data.items():
        result[symbol] = {
            "price": float(val["last"]),
            "volume": float(val["quoteVolume"])
        }
    return result
