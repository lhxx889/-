#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
币种详情查询模块 - Gate.io加密货币异动监控系统
"""

import os
import json
import logging
import requests
import time
import sys
from typing import Dict, List, Any, Optional
from datetime import datetime

# 添加src目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入配置
from src.config import (
    API_BASE_URL, DATA_DIR, LOG_LEVEL, LOG_FILE,
    API_RATE_LIMIT, API_RATE_WINDOW
)

# 配置日志
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("token_details")

class RateLimiter:
    """API请求速率限制器"""
    
    def __init__(self, limit: int, window: int):
        self.limit = limit  # 窗口期内最大请求数
        self.window = window  # 窗口期（秒）
        self.timestamps = []  # 请求时间戳列表
    
    def can_request(self) -> bool:
        """检查是否可以发送请求"""
        now = time.time()
        # 移除窗口期外的时间戳
        self.timestamps = [ts for ts in self.timestamps if now - ts < self.window]
        # 检查是否达到限制
        return len(self.timestamps) < self.limit
    
    def add_request(self):
        """记录一次请求"""
        self.timestamps.append(time.time())
    
    def wait_if_needed(self):
        """如果达到限制，等待到可以请求为止"""
        while not self.can_request():
            time.sleep(0.1)
        self.add_request()

class TokenDetailsAPI:
    """币种详情API接口封装"""
    
    def __init__(self):
        self.base_url = API_BASE_URL
        self.rate_limiter = RateLimiter(API_RATE_LIMIT, API_RATE_WINDOW)
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        
        # 创建缓存目录
        self.cache_dir = os.path.join(DATA_DIR, "token_cache")
        os.makedirs(self.cache_dir, exist_ok=True)
    
    def _request(self, method: str, endpoint: str, params: Dict = None) -> Any:
        """发送API请求"""
        self.rate_limiter.wait_if_needed()
        url = f"{self.base_url}{endpoint}"
        try:
            response = self.session.request(method, url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求错误: {e}")
            return None
    
    def get_currency_detail(self, currency: str) -> Dict:
        """获取币种详细信息"""
        # 检查缓存
        cache_file = os.path.join(self.cache_dir, f"{currency}.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    data = json.load(f)
                    # 检查缓存是否过期（24小时）
                    if data.get("cache_time") and (time.time() - data["cache_time"] < 86400):
                        logger.info(f"使用缓存的币种信息: {currency}")
                        return data
            except Exception as e:
                logger.error(f"读取缓存失败: {e}")
        
        # 获取币种基本信息
        currency_info = self._request("GET", f"/spot/currencies/{currency}")
        if not currency_info:
            logger.error(f"获取币种信息失败: {currency}")
            return {}
        
        # 获取交易对信息
        pairs = self._request("GET", "/spot/currency_pairs", {"currency": currency})
        
        # 获取市场统计信息
        tickers = []
        if pairs:
            for pair in pairs:
                pair_name = pair.get("id")
                if pair_name:
                    ticker = self._request("GET", "/spot/tickers", {"currency_pair": pair_name})
                    if ticker and len(ticker) > 0:
                        tickers.append(ticker[0])
        
        # 整合信息
        result = {
            "currency": currency,
            "name": currency_info.get("name", ""),
            "symbol": currency,
            "logo": f"https://www.gate.io/images/coin_icon/{currency}.png",  # 假设的logo URL格式
            "description": "",  # Gate.io API不直接提供描述
            "website": "",      # Gate.io API不直接提供网站
            "explorer": "",     # Gate.io API不直接提供区块浏览器
            "twitter": "",      # Gate.io API不直接提供Twitter
            "market_cap": 0,    # 需要计算
            "holders_count": 0, # Gate.io API不直接提供持币人数
            "pairs": pairs or [],
            "tickers": tickers or [],
            "cache_time": time.time()
        }
        
        # 计算市值（如果有价格和供应量）
        if tickers and len(tickers) > 0:
            try:
                # 使用USDT交易对的价格
                for ticker in tickers:
                    if ticker.get("currency_pair", "").endswith("_USDT"):
                        price = float(ticker.get("last", 0))
                        # 如果有供应量信息，计算市值
                        if "total_supply" in currency_info:
                            total_supply = float(currency_info.get("total_supply", 0))
                            result["market_cap"] = price * total_supply
                        break
            except (ValueError, TypeError) as e:
                logger.error(f"计算市值失败: {e}")
        
        # 保存到缓存
        try:
            with open(cache_file, 'w') as f:
                json.dump(result, f)
            logger.info(f"已缓存币种信息: {currency}")
        except Exception as e:
            logger.error(f"缓存币种信息失败: {e}")
        
        return result
    
    def search_token_social_info(self, currency: str) -> Dict:
        """搜索币种社交信息（Twitter/X链接等）"""
        # 这部分需要通过网页爬取或其他API获取
        # 由于Gate.io API不直接提供社交信息，这里返回空结果
        return {
            "twitter": "",
            "telegram": "",
            "discord": "",
            "reddit": ""
        }
    
    def format_token_details_message(self, currency: str) -> str:
        """格式化币种详情消息"""
        details = self.get_currency_detail(currency)
        if not details:
            return f"无法获取{currency}的详细信息"
        
        # 获取社交信息
        social_info = self.search_token_social_info(currency)
        
        # 格式化消息
        message = f"""
<b>📊 {details.get('name', currency)}({currency})详情</b>

<b>基本信息:</b>
• 名称: {details.get('name', '未知')}
• 符号: {currency}
• 市值: {'$' + f"{details.get('market_cap', 0):,.2f}" if details.get('market_cap', 0) > 0 else '未知'}
• 持币人数: {details.get('holders_count', '未知')}

<b>价格信息:</b>
"""
        
        # 添加交易对价格信息
        if details.get("tickers"):
            for ticker in details.get("tickers")[:5]:  # 最多显示5个交易对
                pair = ticker.get("currency_pair", "")
                price = ticker.get("last", "0")
                change = ticker.get("change_percentage", "0")
                
                # 判断涨跌
                change_symbol = "📈" if float(change) >= 0 else "📉"
                
                message += f"• {pair}: {price} ({change_symbol} {change}%)\n"
        else:
            message += "• 无价格信息\n"
        
        # 添加社交链接
        message += "\n<b>社交链接:</b>\n"
        if social_info.get("twitter"):
            message += f"• Twitter: {social_info.get('twitter')}\n"
        else:
            message += "• Twitter: 未知\n"
        
        if social_info.get("telegram"):
            message += f"• Telegram: {social_info.get('telegram')}\n"
        
        # 添加交易所链接
        message += f"\n<b>交易所链接:</b>\n• Gate.io: https://www.gate.io/trade/{currency}_USDT"
        
        return message

def main():
    """主函数 - 用于测试"""
    logger.info("币种详情查询模块测试")
    
    api = TokenDetailsAPI()
    
    # 测试获取币种详情
    currencies = ["BTC", "ETH", "DOGE"]
    for currency in currencies:
        details = api.get_currency_detail(currency)
        print(f"\n{currency} 详情:")
        print(json.dumps(details, indent=2))
        
        # 测试格式化消息
        message = api.format_token_details_message(currency)
        print(f"\n{currency} 格式化消息:")
        print(message)

if __name__ == "__main__":
    main()
