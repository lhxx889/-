#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys

# 显式检测必要的依赖库
try:
    import requests
except ImportError:
    print("缺少必要的Python库: requests")
    print("请运行以下命令安装：")
    print("pip3 install requests beautifulsoup4 pytz")
    sys.exit(1)

try:
    from bs4 import BeautifulSoup
except ImportError:
    print("缺少必要的Python库: beautifulsoup4")
    print("请运行以下命令安装：")
    print("pip3 install requests beautifulsoup4 pytz")
    sys.exit(1)

try:
    import pytz
except ImportError:
    print("缺少必要的Python库: pytz")
    print("请运行以下命令安装：")
    print("pip3 install requests beautifulsoup4 pytz")
    sys.exit(1)

import json
import time
import logging
import platform
import subprocess
from datetime import datetime
import traceback

# 导入代理管理器
try:
    from proxy_manager import ProxyManager
except ImportError:
    print("未找到proxy_manager模块，内置代理功能将不可用")
    ProxyManager = None

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('crypto_monitor_advanced.log')
    ]
)

logger = logging.getLogger('crypto_monitor_advanced_menu')

# 全局变量
CONFIG_FILE = "config_advanced.json"
CONFIG = {}
is_running = False
proxy_manager = None

def load_config():
    """加载配置"""
    global CONFIG
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r") as f:
                CONFIG = json.load(f)
        else:
            # 默认配置
            CONFIG = {
                "price_threshold": 5.0,
                "price_check_interval": 60,
                "announcement_scan_interval": 300,
                "data_dir": "data",
                "monitor_binance": True,
                "monitor_gate": True,
                "scan_announcements": True,
                "use_proxy": False,
                "proxy": {
                    "type": "http",
                    "host": "",
                    "port": 0
                },
                "telegram": {
                    "enabled": False,
                    "token": "",
                    "chat_id": "",
                    "price_alerts": True,
                    "announcement_alerts": True,
                    "price_threshold": 5.0,
                    "batch_mode": True,
                    "batch_interval": 60
                },
                "display": {
                    "shanghai_time": True,
                    "detailed_info": True
                },
                "advanced": {
                    "holders_count": False,
                    "social_links": False,
                    "price_change_analysis": False,
                    "etherscan_api_key": "",
                    "ethplorer_api_key": ""
                },
                "config_file": CONFIG_FILE
            }
            save_config()
    except Exception as e:
        logger.error(f"加载配置失败: {e}")
        CONFIG = {}

def save_config():
    """保存配置"""
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(CONFIG, f, indent=4)
    except Exception as e:
        logger.error(f"保存配置失败: {e}")

def clear_screen():
    """清屏"""
    os.system('cls' if os.name == 'nt' else 'clear')

def get_shanghai_time():
    """获取上海时间"""
    shanghai_tz = pytz.timezone('Asia/Shanghai')
    return datetime.now(shanghai_tz).strftime("%Y-%m-%d %H:%M:%S %Z%z")

def start_monitoring():
    """启动监控"""
    global is_running
    
    # 构建命令
    cmd = [
        "python3", "crypto_monitor_advanced.py",
        "--price-threshold", str(CONFIG.get("price_threshold", 5.0)),
        "--price-interval", str(CONFIG.get("price_check_interval", 60)),
        "--announcement-interval", str(CONFIG.get("announcement_scan_interval", 300)),
        "--data-dir", CONFIG.get("data_dir", "data")
    ]
    
    # 添加监控选项
    if CONFIG.get("monitor_binance", True):
        cmd.append("--monitor-binance")
    if CONFIG.get("monitor_gate", True):
        cmd.append("--monitor-gate")
    if CONFIG.get("scan_announcements", True):
        cmd.append("--scan-announcements")
    
    # 添加代理选项
    if CONFIG.get("use_proxy", False):
        proxy = CONFIG.get("proxy", {})
        cmd.extend([
            "--proxy-type", proxy.get("type", "http"),
            "--proxy-host", proxy.get("host", ""),
            "--proxy-port", str(proxy.get("port", 0))
        ])
    
    # 添加Telegram选项
    telegram = CONFIG.get("telegram", {})
    if telegram.get("enabled", False):
        cmd.extend([
            "--telegram-token", telegram.get("token", ""),
            "--telegram-chat-id", telegram.get("chat_id", ""),
            "--telegram-price-threshold", str(telegram.get("price_threshold", 5.0))
        ])
        
        if telegram.get("price_alerts", True):
            cmd.append("--telegram-price-alerts")
        if telegram.get("announcement_alerts", True):
            cmd.append("--telegram-announcement-alerts")
        if telegram.get("batch_mode", True):
            cmd.append("--telegram-batch-mode")
            cmd.extend(["--telegram-batch-interval", str(telegram.get("batch_interval", 60))])
    
    # 添加显示选项
    display = CONFIG.get("display", {})
    if display.get("shanghai_time", True):
        cmd.append("--shanghai-time")
    if display.get("detailed_info", True):
        cmd.append("--detailed-info")
    
    # 添加高级选项
    advanced = CONFIG.get("advanced", {})
    if advanced.get("holders_count", False):
        cmd.append("--holders-count")
        if advanced.get("etherscan_api_key"):
            cmd.extend(["--etherscan-api-key", advanced.get("etherscan_api_key")])
        if advanced.get("ethplorer_api_key"):
            cmd.extend(["--ethplorer-api-key", advanced.get("ethplorer_api_key")])
    if advanced.get("social_links", False):
        cmd.append("--social-links")
    if advanced.get("price_change_analysis", False):
        cmd.append("--price-change-analysis")
    
    # 启动进程
    try:
        subprocess.Popen(cmd)
        is_running = True
        logger.info("监控已启动")
        return True
    except Exception as e:
        logger.error(f"启动监控失败: {e}")
        return False

def stop_monitoring():
    """停止监控"""
    global is_running
    
    try:
        if platform.system() == "Windows":
            subprocess.run(["taskkill", "/f", "/im", "crypto_monitor_advanced.py"], 
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            subprocess.run(["pkill", "-f", "crypto_monitor_advanced.py"],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        is_running = False
        logger.info("监控已停止")
        return True
    except Exception as e:
        logger.error(f"停止监控失败: {e}")
        return False

def check_monitoring_status():
    """检查监控状态"""
    global is_running
    
    try:
        if platform.system() == "Windows":
            result = subprocess.run(["tasklist", "/fi", "imagename eq python.exe"], 
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            is_running = "crypto_monitor_advanced.py" in result.stdout
        else:
            result = subprocess.run(["pgrep", "-f", "crypto_monitor_advanced.py"],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            is_running = result.returncode == 0
    except Exception as e:
        logger.error(f"检查监控状态失败: {e}")
    
    return is_running

def main_menu():
    """主菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("        加密货币监控工具 - 深度增强版主菜单")
        print("=" * 60)
        
        # 显示当前状态
        status = "运行中" if check_monitoring_status() else "已停止"
        print(f"监控状态: {status}")
        
        # 显示上海时间
        if CONFIG.get("display", {}).get("shanghai_time", True):
            print(f"当前上海时间: {get_shanghai_time()}")
        
        print("-" * 60)
        print("1. 启动监控")
        print("2. 停止监控")
        print("3. 设置价格监控参数")
        print("4. 设置公告扫描参数")
        print("5. 配置监控选项")
        print("6. 配置代理设置")
        print("7. 配置Telegram推送")
        print("8. 配置显示选项")
        print("9. 高级功能设置")
        print("10. 内置代理管理")  # 新增内置代理管理选项
        print("11. 查看日志")
        print("0. 退出")
        
        choice = input("请选择: ")
        
        if choice == "1":
            if not check_monitoring_status():
                print("正在启动监控...")
                if start_monitoring():
                    print("监控已启动")
                else:
                    print("启动监控失败")
                input("按Enter键继续...")
            else:
                print("监控已经在运行中")
                input("按Enter键继续...")
        elif choice == "2":
            if check_monitoring_status():
                print("正在停止监控...")
                if stop_monitoring():
                    print("监控已停止")
                else:
                    print("停止监控失败")
                input("按Enter键继续...")
            else:
                print("监控已经停止")
                input("按Enter键继续...")
        elif choice == "3":
            price_monitor_menu()
        elif choice == "4":
            announcement_scan_menu()
        elif choice == "5":
            monitor_options_menu()
        elif choice == "6":
            proxy_settings_menu()
        elif choice == "7":
            telegram_settings_menu()
        elif choice == "8":
            display_settings_menu()
        elif choice == "9":
            advanced_settings_menu()
        elif choice == "10":
            built_in_proxy_menu()  # 新增内置代理管理菜单
        elif choice == "11":
            view_logs_menu()
        elif choice == "0":
            handle_exit()
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def price_monitor_menu():
    """价格监控参数设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                价格监控参数设置")
        print("=" * 60)
        print(f"1. 价格涨跌幅阈值: {CONFIG.get('price_threshold', 5.0)}%")
        print(f"2. 价格检查间隔: {CONFIG.get('price_check_interval', 60)}秒")
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            try:
                value = float(input("请输入新的价格涨跌幅阈值(%): "))
                if value <= 0:
                    print("阈值必须大于0")
                else:
                    CONFIG["price_threshold"] = value
                    save_config()
                    print(f"价格涨跌幅阈值已设置为 {value}%")
            except ValueError:
                print("请输入有效的数字")
            input("按Enter键继续...")
        elif choice == "2":
            try:
                value = int(input("请输入新的价格检查间隔(秒): "))
                if value <= 0:
                    print("间隔必须大于0")
                else:
                    CONFIG["price_check_interval"] = value
                    save_config()
                    print(f"价格检查间隔已设置为 {value}秒")
            except ValueError:
                print("请输入有效的整数")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def announcement_scan_menu():
    """公告扫描参数设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                公告扫描参数设置")
        print("=" * 60)
        print(f"1. 公告扫描间隔: {CONFIG.get('announcement_scan_interval', 300)}秒")
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            try:
                value = int(input("请输入新的公告扫描间隔(秒): "))
                if value <= 0:
                    print("间隔必须大于0")
                else:
                    CONFIG["announcement_scan_interval"] = value
                    save_config()
                    print(f"公告扫描间隔已设置为 {value}秒")
            except ValueError:
                print("请输入有效的整数")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def monitor_options_menu():
    """监控选项设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                监控选项设置")
        print("=" * 60)
        print(f"1. Binance.US监控: {'启用' if CONFIG.get('monitor_binance', True) else '禁用'}")
        print(f"2. Gate.io监控: {'启用' if CONFIG.get('monitor_gate', True) else '禁用'}")
        print(f"3. 公告扫描: {'启用' if CONFIG.get('scan_announcements', True) else '禁用'}")
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            CONFIG["monitor_binance"] = not CONFIG.get("monitor_binance", True)
            save_config()
            print(f"Binance.US监控已{'启用' if CONFIG['monitor_binance'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "2":
            CONFIG["monitor_gate"] = not CONFIG.get("monitor_gate", True)
            save_config()
            print(f"Gate.io监控已{'启用' if CONFIG['monitor_gate'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "3":
            CONFIG["scan_announcements"] = not CONFIG.get("scan_announcements", True)
            save_config()
            print(f"公告扫描已{'启用' if CONFIG['scan_announcements'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def proxy_settings_menu():
    """代理设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                代理设置")
        print("=" * 60)
        print(f"1. 使用代理: {'是' if CONFIG.get('use_proxy', False) else '否'}")
        
        if CONFIG.get("use_proxy", False):
            proxy = CONFIG.get("proxy", {})
            print(f"2. 代理类型: {proxy.get('type', 'http')}")
            print(f"3. 代理主机: {proxy.get('host', '')}")
            print(f"4. 代理端口: {proxy.get('port', 0)}")
        
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            CONFIG["use_proxy"] = not CONFIG.get("use_proxy", False)
            if CONFIG["use_proxy"] and "proxy" not in CONFIG:
                CONFIG["proxy"] = {"type": "http", "host": "", "port": 0}
            save_config()
            print(f"使用代理已设置为 {'是' if CONFIG['use_proxy'] else '否'}")
            input("按Enter键继续...")
        elif choice == "2" and CONFIG.get("use_proxy", False):
            print("选择代理类型:")
            print("1. HTTP")
            print("2. SOCKS5")
            proxy_type_choice = input("请选择: ")
            
            if proxy_type_choice == "1":
                CONFIG["proxy"]["type"] = "http"
                save_config()
                print("代理类型已设置为 HTTP")
            elif proxy_type_choice == "2":
                CONFIG["proxy"]["type"] = "socks5"
                save_config()
                print("代理类型已设置为 SOCKS5")
            else:
                print("无效选择，请重试")
            
            input("按Enter键继续...")
        elif choice == "3" and CONFIG.get("use_proxy", False):
            host = input("请输入代理主机: ")
            CONFIG["proxy"]["host"] = host
            save_config()
            print(f"代理主机已设置为 {host}")
            input("按Enter键继续...")
        elif choice == "4" and CONFIG.get("use_proxy", False):
            try:
                port = int(input("请输入代理端口: "))
                if port < 0 or port > 65535:
                    print("端口必须在0-65535范围内")
                else:
                    CONFIG["proxy"]["port"] = port
                    save_config()
                    print(f"代理端口已设置为 {port}")
            except ValueError:
                print("请输入有效的整数")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def telegram_settings_menu():
    """Telegram推送设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                Telegram推送设置")
        print("=" * 60)
        
        telegram = CONFIG.get("telegram", {})
        print(f"1. Telegram推送: {'启用' if telegram.get('enabled', False) else '禁用'}")
        
        if telegram.get("enabled", False):
            print(f"2. 机器人Token: {telegram.get('token', '')[:10]}...")
            print(f"3. 聊天ID: {telegram.get('chat_id', '')}")
            print(f"4. 价格变动推送: {'启用' if telegram.get('price_alerts', True) else '禁用'}")
            print(f"5. 公告推送: {'启用' if telegram.get('announcement_alerts', True) else '禁用'}")
            print(f"6. 价格推送阈值: {telegram.get('price_threshold', 5.0)}%")
            print(f"7. 批量推送模式: {'启用' if telegram.get('batch_mode', True) else '禁用'}")
            
            if telegram.get("batch_mode", True):
                print(f"8. 批量推送间隔: {telegram.get('batch_interval', 60)}秒")
        
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            if "telegram" not in CONFIG:
                CONFIG["telegram"] = {
                    "enabled": False,
                    "token": "",
                    "chat_id": "",
                    "price_alerts": True,
                    "announcement_alerts": True,
                    "price_threshold": 5.0,
                    "batch_mode": True,
                    "batch_interval": 60
                }
            
            CONFIG["telegram"]["enabled"] = not CONFIG["telegram"].get("enabled", False)
            save_config()
            print(f"Telegram推送已{'启用' if CONFIG['telegram']['enabled'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "2" and telegram.get("enabled", False):
            token = input("请输入Telegram机器人Token: ")
            CONFIG["telegram"]["token"] = token
            save_config()
            print("Telegram机器人Token已设置")
            input("按Enter键继续...")
        elif choice == "3" and telegram.get("enabled", False):
            chat_id = input("请输入Telegram聊天ID: ")
            CONFIG["telegram"]["chat_id"] = chat_id
            save_config()
            print("Telegram聊天ID已设置")
            input("按Enter键继续...")
        elif choice == "4" and telegram.get("enabled", False):
            CONFIG["telegram"]["price_alerts"] = not CONFIG["telegram"].get("price_alerts", True)
            save_config()
            print(f"价格变动推送已{'启用' if CONFIG['telegram']['price_alerts'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "5" and telegram.get("enabled", False):
            CONFIG["telegram"]["announcement_alerts"] = not CONFIG["telegram"].get("announcement_alerts", True)
            save_config()
            print(f"公告推送已{'启用' if CONFIG['telegram']['announcement_alerts'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "6" and telegram.get("enabled", False):
            try:
                value = float(input("请输入价格推送阈值(%): "))
                if value <= 0:
                    print("阈值必须大于0")
                else:
                    CONFIG["telegram"]["price_threshold"] = value
                    save_config()
                    print(f"价格推送阈值已设置为 {value}%")
            except ValueError:
                print("请输入有效的数字")
            input("按Enter键继续...")
        elif choice == "7" and telegram.get("enabled", False):
            CONFIG["telegram"]["batch_mode"] = not CONFIG["telegram"].get("batch_mode", True)
            save_config()
            print(f"批量推送模式已{'启用' if CONFIG['telegram']['batch_mode'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "8" and telegram.get("enabled", False) and telegram.get("batch_mode", True):
            try:
                value = int(input("请输入批量推送间隔(秒): "))
                if value <= 0:
                    print("间隔必须大于0")
                else:
                    CONFIG["telegram"]["batch_interval"] = value
                    save_config()
                    print(f"批量推送间隔已设置为 {value}秒")
            except ValueError:
                print("请输入有效的整数")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def display_settings_menu():
    """显示选项设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                显示选项设置")
        print("=" * 60)
        
        display = CONFIG.get("display", {})
        print(f"1. 上海时间显示: {'启用' if display.get('shanghai_time', True) else '禁用'}")
        print(f"2. 币种详细信息显示: {'启用' if display.get('detailed_info', True) else '禁用'}")
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            if "display" not in CONFIG:
                CONFIG["display"] = {"shanghai_time": True, "detailed_info": True}
            
            CONFIG["display"]["shanghai_time"] = not CONFIG["display"].get("shanghai_time", True)
            save_config()
            print(f"上海时间显示已{'启用' if CONFIG['display']['shanghai_time'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "2":
            if "display" not in CONFIG:
                CONFIG["display"] = {"shanghai_time": True, "detailed_info": True}
            
            CONFIG["display"]["detailed_info"] = not CONFIG["display"].get("detailed_info", True)
            save_config()
            print(f"币种详细信息显示已{'启用' if CONFIG['display']['detailed_info'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def advanced_settings_menu():
    """高级功能设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                高级功能设置")
        print("=" * 60)
        
        advanced = CONFIG.get("advanced", {})
        print(f"1. 持币人数显示: {'启用' if advanced.get('holders_count', False) else '禁用'}")
        print(f"2. 社交媒体链接显示: {'启用' if advanced.get('social_links', False) else '禁用'}")
        print(f"3. 价格变动原因分析: {'启用' if advanced.get('price_change_analysis', False) else '禁用'}")
        
        if advanced.get("holders_count", False):
            print(f"4. 设置Etherscan API密钥: {'已设置' if advanced.get('etherscan_api_key') else '未设置'}")
            print(f"5. 设置Ethplorer API密钥: {'已设置' if advanced.get('ethplorer_api_key') else '未设置'}")
        
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            if "advanced" not in CONFIG:
                CONFIG["advanced"] = {
                    "holders_count": False,
                    "social_links": False,
                    "price_change_analysis": False,
                    "etherscan_api_key": "",
                    "ethplorer_api_key": ""
                }
            
            CONFIG["advanced"]["holders_count"] = not CONFIG["advanced"].get("holders_count", False)
            save_config()
            print(f"持币人数显示已{'启用' if CONFIG['advanced']['holders_count'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "2":
            if "advanced" not in CONFIG:
                CONFIG["advanced"] = {
                    "holders_count": False,
                    "social_links": False,
                    "price_change_analysis": False,
                    "etherscan_api_key": "",
                    "ethplorer_api_key": ""
                }
            
            CONFIG["advanced"]["social_links"] = not CONFIG["advanced"].get("social_links", False)
            save_config()
            print(f"社交媒体链接显示已{'启用' if CONFIG['advanced']['social_links'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "3":
            if "advanced" not in CONFIG:
                CONFIG["advanced"] = {
                    "holders_count": False,
                    "social_links": False,
                    "price_change_analysis": False,
                    "etherscan_api_key": "",
                    "ethplorer_api_key": ""
                }
            
            CONFIG["advanced"]["price_change_analysis"] = not CONFIG["advanced"].get("price_change_analysis", False)
            save_config()
            print(f"价格变动原因分析已{'启用' if CONFIG['advanced']['price_change_analysis'] else '禁用'}")
            input("按Enter键继续...")
        elif choice == "4" and advanced.get("holders_count", False):
            api_key = input("请输入Etherscan API密钥: ")
            CONFIG["advanced"]["etherscan_api_key"] = api_key
            save_config()
            print("Etherscan API密钥已设置")
            input("按Enter键继续...")
        elif choice == "5" and advanced.get("holders_count", False):
            api_key = input("请输入Ethplorer API密钥: ")
            CONFIG["advanced"]["ethplorer_api_key"] = api_key
            save_config()
            print("Ethplorer API密钥已设置")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def built_in_proxy_menu():
    """内置代理管理菜单"""
    global proxy_manager
    
    # 初始化代理管理器
    if proxy_manager is None:
        try:
            proxy_manager = ProxyManager(CONFIG)
        except Exception as e:
            logger.error(f"初始化代理管理器失败: {e}")
            print("初始化代理管理器失败，内置代理功能不可用")
            input("按Enter键返回主菜单...")
            return
    
    while True:
        clear_screen()
        print("=" * 60)
        print("                内置代理管理")
        print("=" * 60)
        
        # 获取代理状态
        status = proxy_manager.get_proxy_status()
        
        print(f"代理安装状态: {'已安装' if status['installed'] else '未安装'}")
        print(f"代理运行状态: {'运行中' if status['running'] else '未运行'}")
        
        if status['running']:
            print("SOCKS5代理地址: 127.0.0.1:1080")
            print("HTTP代理地址: 127.0.0.1:7890")
        
        print("-" * 60)
        print("1. 安装内置代理")
        print("2. 启动代理服务")
        print("3. 停止代理服务")
        print("4. 测试代理连接")
        print("5. 应用代理设置")
        print("0. 返回上级菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "1":
            print("正在安装内置代理...")
            if proxy_manager.install_proxy():
                print("内置代理安装成功")
            else:
                print("内置代理安装失败")
            input("按Enter键继续...")
        elif choice == "2":
            print("正在启动代理服务...")
            if proxy_manager.start_proxy():
                print("代理服务启动成功")
            else:
                print("代理服务启动失败")
            input("按Enter键继续...")
        elif choice == "3":
            print("正在停止代理服务...")
            if proxy_manager.stop_proxy():
                print("代理服务停止成功")
            else:
                print("代理服务停止失败")
            input("按Enter键继续...")
        elif choice == "4":
            print("正在测试代理连接...")
            if proxy_manager.test_proxy_connection():
                print("代理连接测试成功")
            else:
                print("代理连接测试失败")
            input("按Enter键继续...")
        elif choice == "5":
            print("正在应用代理设置...")
            success = proxy_manager.apply_proxy_settings()
            if success:
                print("代理设置应用成功")
            else:
                print("代理设置应用失败")
            input("按Enter键继续...")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def view_logs_menu():
    """查看日志菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                查看日志")
        print("=" * 60)
        print("1. 查看监控日志")
        print("2. 查看公告扫描日志")
        print("3. 查看Binance.US监控日志")
        print("4. 查看Gate.io监控日志")
        print("5. 查看代理管理日志")
        print("0. 返回主菜单")
        
        choice = input("请选择: ")
        
        if choice == "1":
            view_log_file("crypto_monitor_advanced.log")
        elif choice == "2":
            view_log_file("announcement_scanner.log")
        elif choice == "3":
            view_log_file("binance_monitor.log")
        elif choice == "4":
            view_log_file("gate_monitor.log")
        elif choice == "5":
            view_log_file("proxy_manager.log")
        elif choice == "0":
            break
        else:
            print("无效选择，请重试")
            input("按Enter键继续...")

def view_log_file(log_file):
    """查看日志文件"""
    clear_screen()
    print("=" * 60)
    print(f"                {log_file}")
    print("=" * 60)
    
    try:
        if os.path.exists(log_file):
            # 读取最后100行
            if platform.system() == "Windows":
                # Windows下使用Python读取
                with open(log_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    for line in lines[-100:]:
                        print(line.strip())
            else:
                # Linux/macOS下使用tail命令
                subprocess.run(["tail", "-n", "100", log_file])
        else:
            print(f"日志文件 {log_file} 不存在")
    except Exception as e:
        print(f"读取日志文件失败: {e}")
    
    input("按Enter键返回...")

def handle_exit():
    """处理退出"""
    clear_screen()
    print("=" * 60)
    print("                退出确认")
    print("=" * 60)
    print("是否要退出程序？")
    print("1. 是")
    print("2. 否")
    
    choice = input("请选择: ")
    
    if choice == "1":
        if check_monitoring_status():
            print("监控仍在运行中，是否要停止监控？")
            print("1. 是")
            print("2. 否")
            
            stop_choice = input("请选择: ")
            
            if stop_choice == "1":
                print("正在停止监控...")
                stop_monitoring()
                print("监控已停止")
                print("正在退出程序...")
                sys.exit(0)
            else:
                print("监控将在后台继续运行")
                print("正在退出程序...")
                sys.exit(0)
        else:
            print("正在退出程序...")
            sys.exit(0)

def main():
    """主函数"""
    try:
        # 加载配置
        load_config()
        
        # 显示主菜单
        main_menu()
    except KeyboardInterrupt:
        print("\n程序被用户中断")
        sys.exit(0)
    except Exception as e:
        logger.error(f"程序出错: {e}")
        logger.error(traceback.format_exc())
        print(f"程序出错: {e}")
        input("按Enter键退出...")
        sys.exit(1)

if __name__ == "__main__":
    main()
