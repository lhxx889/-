#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试快捷配置代理脚本
"""

import os
import sys
import json
import time
import subprocess
import logging

# 添加父目录到路径，以便导入proxy_manager
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from proxy_manager import ProxyManager
except ImportError:
    print("错误：无法导入ProxyManager模块。请确保您在正确的目录中运行此脚本。")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('test_quick_proxy.log')
    ]
)

logger = logging.getLogger('test_quick_proxy')

def test_proxy_status():
    """测试代理状态"""
    print("测试代理状态...")
    proxy_manager = ProxyManager()
    status = proxy_manager.get_proxy_status()
    print(f"代理安装状态: {'已安装' if status['installed'] else '未安装'}")
    print(f"代理运行状态: {'运行中' if status['running'] else '未运行'}")
    return status

def test_proxy_connection():
    """测试代理连接"""
    print("测试代理连接...")
    proxy_manager = ProxyManager()
    result = proxy_manager.test_proxy_connection()
    print(f"代理连接测试结果: {'成功' if result else '失败'}")
    return result

def test_config_file():
    """测试配置文件"""
    print("测试配置文件...")
    config_file = "/etc/sing-box/config.json"
    if os.path.exists(config_file):
        try:
            with open(config_file, "r") as f:
                config = json.load(f)
                print("配置文件存在且格式正确")
                
                # 检查必要的配置项
                if "inbounds" in config and "outbounds" in config:
                    inbounds = config["inbounds"]
                    outbounds = config["outbounds"]
                    
                    # 检查入站配置
                    has_socks = any(inbound.get("type") == "socks" for inbound in inbounds)
                    has_http = any(inbound.get("type") == "http" for inbound in inbounds)
                    
                    print(f"SOCKS入站配置: {'存在' if has_socks else '不存在'}")
                    print(f"HTTP入站配置: {'存在' if has_http else '不存在'}")
                    
                    # 检查出站配置
                    if outbounds and len(outbounds) > 0:
                        outbound = outbounds[0]
                        print(f"出站类型: {outbound.get('type', '未知')}")
                        print(f"服务器: {outbound.get('server', '未知')}")
                        print(f"端口: {outbound.get('server_port', '未知')}")
                    else:
                        print("出站配置不存在")
                else:
                    print("配置文件缺少必要的配置项")
                
                return True
        except Exception as e:
            print(f"读取配置文件失败: {e}")
            return False
    else:
        print("配置文件不存在")
        return False

def main():
    """主函数"""
    print("=" * 60)
    print("            测试快捷配置代理脚本")
    print("=" * 60)
    
    # 测试代理状态
    status = test_proxy_status()
    print("-" * 60)
    
    # 测试配置文件
    config_result = test_config_file()
    print("-" * 60)
    
    # 如果代理已安装且正在运行，测试连接
    if status["installed"] and status["running"]:
        connection_result = test_proxy_connection()
    else:
        connection_result = False
        print("代理未安装或未运行，跳过连接测试")
    
    print("-" * 60)
    print("测试结果汇总:")
    print(f"代理安装状态: {'通过' if status['installed'] else '失败'}")
    print(f"代理运行状态: {'通过' if status['running'] else '失败'}")
    print(f"配置文件测试: {'通过' if config_result else '失败'}")
    print(f"连接测试: {'通过' if connection_result else '失败'}")
    
    # 总体测试结果
    if status["installed"] and status["running"] and config_result and connection_result:
        print("\n总体测试结果: 通过")
        return 0
    else:
        print("\n总体测试结果: 失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())

