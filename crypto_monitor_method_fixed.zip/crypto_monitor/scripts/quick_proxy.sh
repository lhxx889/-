#!/bin/bash
# 快捷配置代理启动器

# 获取脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 颜色输出
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}启动快捷配置代理工具...${NC}"

# 检查Python是否安装
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}错误: 未找到Python3，请先安装Python3${NC}"
    exit 1
fi

# 检查是否有root权限
if [ "$EUID" -ne 0 ]; then
    echo -e "${YELLOW}注意: 未使用root权限运行，某些功能可能需要sudo权限${NC}"
fi

# 切换到项目目录
cd "$PROJECT_DIR" || exit 1

# 运行Python脚本
python3 "$SCRIPT_DIR/quick_proxy_config.py"

# 检查退出状态
if [ $? -ne 0 ]; then
    echo -e "${RED}快捷配置代理工具运行失败${NC}"
    exit 1
fi

echo -e "${GREEN}快捷配置代理工具已退出${NC}"

