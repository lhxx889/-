# 加密货币监控系统 - 整合版

## 概述

这是一个功能强大的加密货币监控系统，可以监控Binance.US和Gate.io的加密货币价格变动，扫描交易所公告，并通过Telegram推送通知。系统集成了完整的代理管理功能，包括VLESS节点管理和链接导入/导出功能。

## 主要功能

### 加密货币监控
- 监控Binance.US和Gate.io的加密货币价格变动
- 扫描交易所公告
- 支持Telegram推送通知
- 提供交互式配置菜单

### 代理管理中心
- 集成代理管理功能
- 支持VLESS代理协议
- 完整的VLESS节点管理功能
- 支持从VLESS链接导入节点
- 支持导出节点为VLESS链接
- 代理连接测试功能
- 一键配置代理服务

## 安装指南

### 系统要求
- Python 3.6+
- 必要的Python库：requests, beautifulsoup4
- Linux或macOS系统（推荐Ubuntu/Debian）

### 安装步骤

1. 安装必要的Python库：
```bash
apt update
apt install -y python3-requests python3-bs4
```

或者使用pip：
```bash
pip3 install requests beautifulsoup4
```

2. 解压安装包：
```bash
unzip crypto_monitor_integrated.zip
cd crypto_monitor
```

3. 确保脚本有执行权限：
```bash
chmod +x *.py scripts/*.sh scripts/*.py
```

## 使用指南

### 启动整合版监控系统
```bash
python3 crypto_monitor_menu_integrated.py
```

### 主菜单选项
1. **启动/停止监控** - 开始或停止监控服务
2. **配置Telegram推送** - 设置Telegram机器人通知
3. **设置价格监控参数** - 调整价格监控阈值和间隔
4. **设置公告扫描参数** - 配置公告扫描功能
5. **代理管理中心** - 集成的代理管理功能
6. **查看当前配置** - 显示所有配置项
7. **查看监控日志** - 查看运行日志
8. **退出程序** - 退出监控系统

### 代理管理中心选项
1. **启用/禁用代理** - 开启或关闭代理功能
2. **基本代理设置** - 配置HTTP和HTTPS代理
3. **VLESS节点管理** - 打开VLESS节点管理器
4. **快捷配置代理** - 一键配置代理服务
5. **安装/修复代理服务** - 安装或修复sing-box服务
6. **测试代理连接** - 测试代理是否正常工作

### VLESS节点管理功能
通过代理管理中心的"VLESS节点管理"选项，您可以：
- 添加新的VLESS节点
- 从VLESS链接导入节点
- 删除现有节点
- 修改节点配置
- 查看所有已保存的节点
- 导出节点为VLESS链接
- 测试节点连接
- 应用节点配置

### 从VLESS链接导入节点
1. 在主菜单中选择"5. 代理管理中心"
2. 选择"3. VLESS节点管理"
3. 在VLESS管理器中选择"2. 从VLESS链接导入节点"
4. 粘贴VLESS链接，例如：
   ```
   vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态
   ```
5. 确认添加节点

## 配置指南

### Telegram通知设置
要启用Telegram通知，需要：
1. 创建Telegram机器人并获取Token
2. 获取您的Telegram聊天ID
3. 在菜单中选择"2. 配置Telegram推送"
4. 输入Token和聊天ID
5. 启用Telegram推送功能

### 代理配置
如果需要使用代理，可以：
1. 在主菜单中选择"5. 代理管理中心"
2. 选择"1. 启用代理"
3. 配置代理设置或使用VLESS节点管理

## 常见问题解决

### 程序无法启动
- 确保Python和所需库已正确安装
- 检查脚本是否有执行权限

### API请求限制错误
- 增加价格检查间隔，至少设置为5分钟

### 代理连接问题
- 在代理管理中心选择"6. 测试代理连接"
- 如果测试失败，选择"5. 安装/修复代理服务"
- 使用VLESS管理器测试节点连接

### Telegram推送失败
- 验证Token和聊天ID是否正确

### sing-box服务启动失败
如果遇到"sing-box.service: Failed with result 'exec'"错误，请在代理管理中心选择"5. 安装/修复代理服务"。

## 更新日志

### 2025-06-06 整合更新
- 整合了主菜单和VLESS管理功能
- 创建了统一的代理管理中心
- 修复了sing-box路径问题
- 添加了VLESS链接导入/导出功能

## 详细文档

- `VLESS_MANAGER_GUIDE.md` - VLESS节点管理器使用指南
- `INSTALLATION_GUIDE.md` - 详细安装指南
- `QUICK_PROXY_GUIDE.md` - 快速代理配置指南

## 技术支持

如有任何问题或需要帮助，请查看相关日志文件：
- `proxy_manager.log` - 代理管理器日志
- `crypto_monitor.log` - 监控系统日志
- `vless_manager.log` - VLESS管理器日志

