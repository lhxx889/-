"""
加密货币监控系统数据模型
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Exchange(db.Model):
    """交易所模型"""
    id = db.Column(db.String(50), primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    is_enabled = db.Column(db.Boolean, default=True)
    last_updated = db.Column(db.DateTime, default=datetime.now)
    api_status = db.Column(db.String(20), default="unknown")
    consecutive_failures = db.Column(db.Integer, default=0)
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "is_enabled": self.is_enabled,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
            "api_status": self.api_status,
            "consecutive_failures": self.consecutive_failures
        }

class Coin(db.Model):
    """币种模型"""
    id = db.Column(db.Integer, primary_key=True)
    exchange_id = db.Column(db.String(50), db.ForeignKey('exchange.id'), nullable=False)
    symbol = db.Column(db.String(50), nullable=False)
    name = db.Column(db.String(100))
    last_updated = db.Column(db.DateTime, default=datetime.now)
    
    # 建立唯一约束，确保每个交易所的每个币种只有一条记录
    __table_args__ = (db.UniqueConstraint('exchange_id', 'symbol'),)
    
    # 建立与交易所的关系
    exchange = db.relationship('Exchange', backref=db.backref('coins', lazy=True))
    
    def to_dict(self):
        return {
            "id": self.id,
            "exchange_id": self.exchange_id,
            "exchange_name": self.exchange.name if self.exchange else None,
            "symbol": self.symbol,
            "name": self.name,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None
        }

class PriceData(db.Model):
    """价格数据模型"""
    id = db.Column(db.Integer, primary_key=True)
    coin_id = db.Column(db.Integer, db.ForeignKey('coin.id'), nullable=False)
    price = db.Column(db.Float, nullable=False)
    volume_24h = db.Column(db.Float)
    change_percentage_24h = db.Column(db.Float)
    high_24h = db.Column(db.Float)
    low_24h = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.now, index=True)
    
    # 建立与币种的关系
    coin = db.relationship('Coin', backref=db.backref('price_data', lazy=True))
    
    def to_dict(self):
        return {
            "id": self.id,
            "coin_id": self.coin_id,
            "symbol": self.coin.symbol if self.coin else None,
            "exchange_id": self.coin.exchange_id if self.coin else None,
            "price": self.price,
            "volume_24h": self.volume_24h,
            "change_percentage_24h": self.change_percentage_24h,
            "high_24h": self.high_24h,
            "low_24h": self.low_24h,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None
        }

class Anomaly(db.Model):
    """异常记录模型"""
    id = db.Column(db.Integer, primary_key=True)
    coin_id = db.Column(db.Integer, db.ForeignKey('coin.id'), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # price, volume, pattern
    current_price = db.Column(db.Float, nullable=False)
    reference_price = db.Column(db.Float)
    price_change_pct = db.Column(db.Float)
    volume_24h = db.Column(db.Float)
    volume_change_pct = db.Column(db.Float)
    confidence_score = db.Column(db.Float, default=1.0)  # 置信度分数，用于高级异常检测
    algorithm = db.Column(db.String(50))  # 使用的算法，用于高级异常检测
    detected_at = db.Column(db.DateTime, default=datetime.now, index=True)
    is_notified = db.Column(db.Boolean, default=False)
    
    # 建立与币种的关系
    coin = db.relationship('Coin', backref=db.backref('anomalies', lazy=True))
    
    def to_dict(self):
        return {
            "id": self.id,
            "coin_id": self.coin_id,
            "symbol": self.coin.symbol if self.coin else None,
            "exchange_id": self.coin.exchange_id if self.coin else None,
            "exchange_name": self.coin.exchange.name if self.coin and self.coin.exchange else None,
            "type": self.type,
            "current_price": self.current_price,
            "reference_price": self.reference_price,
            "price_change_pct": self.price_change_pct,
            "volume_24h": self.volume_24h,
            "volume_change_pct": self.volume_change_pct,
            "confidence_score": self.confidence_score,
            "algorithm": self.algorithm,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
            "is_notified": self.is_notified
        }

class SystemConfig(db.Model):
    """系统配置模型"""
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(50), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=False)
    description = db.Column(db.String(255))
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    def to_dict(self):
        return {
            "id": self.id,
            "key": self.key,
            "value": self.value,
            "description": self.description,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

class FallbackConfig(db.Model):
    """备用数据源配置模型"""
    id = db.Column(db.Integer, primary_key=True)
    primary_exchange_id = db.Column(db.String(50), db.ForeignKey('exchange.id'), nullable=False)
    fallback_exchange_id = db.Column(db.String(50), db.ForeignKey('exchange.id'), nullable=False)
    is_enabled = db.Column(db.Boolean, default=True)
    priority = db.Column(db.Integer, default=1)  # 优先级，数字越小优先级越高
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # 建立与交易所的关系
    primary_exchange = db.relationship('Exchange', foreign_keys=[primary_exchange_id])
    fallback_exchange = db.relationship('Exchange', foreign_keys=[fallback_exchange_id])
    
    # 建立唯一约束，确保每个主交易所和备用交易所的组合只有一条记录
    __table_args__ = (db.UniqueConstraint('primary_exchange_id', 'fallback_exchange_id'),)
    
    def to_dict(self):
        return {
            "id": self.id,
            "primary_exchange_id": self.primary_exchange_id,
            "primary_exchange_name": self.primary_exchange.name if self.primary_exchange else None,
            "fallback_exchange_id": self.fallback_exchange_id,
            "fallback_exchange_name": self.fallback_exchange.name if self.fallback_exchange else None,
            "is_enabled": self.is_enabled,
            "priority": self.priority,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
