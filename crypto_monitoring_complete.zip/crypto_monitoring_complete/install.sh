#!/bin/bash
# 加密货币监控系统一键安装脚本
# 作者: Manus AI
# 日期: 2025-06-04

# 设置颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "\n${BLUE}[STEP]${NC} $1"
    echo -e "${BLUE}=====================================${NC}"
}

# 检查是否为root用户
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_warn "当前非root用户，某些操作可能需要sudo权限"
        USE_SUDO="sudo"
    else
        USE_SUDO=""
    fi
}

# 检查系统环境
check_system() {
    log_step "检查系统环境"
    
    # 检查操作系统
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        log_info "操作系统: $OS $VER"
    else
        log_warn "无法确定操作系统类型，将尝试继续安装"
        OS="Unknown"
    fi
    
    # 检查Python版本
    if command -v python3 &>/dev/null; then
        PYTHON_VER=$(python3 --version)
        log_info "Python版本: $PYTHON_VER"
    else
        log_error "未检测到Python3，将尝试安装"
        install_python
    fi
    
    # 检查pip
    if command -v pip3 &>/dev/null; then
        PIP_VER=$(pip3 --version)
        log_info "pip版本: $PIP_VER"
    else
        log_error "未检测到pip3，将尝试安装"
        install_pip
    fi
    
    # 检查git
    if command -v git &>/dev/null; then
        GIT_VER=$(git --version)
        log_info "Git版本: $GIT_VER"
    else
        log_error "未检测到git，将尝试安装"
        install_git
    fi
}

# 安装Python
install_python() {
    log_step "安装Python3"
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        $USE_SUDO apt-get update
        $USE_SUDO apt-get install -y python3 python3-dev
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        $USE_SUDO yum install -y python3 python3-devel
    elif [[ "$OS" == *"Fedora"* ]]; then
        $USE_SUDO dnf install -y python3 python3-devel
    else
        log_error "不支持的操作系统，请手动安装Python3"
        exit 1
    fi
    
    if command -v python3 &>/dev/null; then
        PYTHON_VER=$(python3 --version)
        log_info "Python安装成功: $PYTHON_VER"
    else
        log_error "Python安装失败，请手动安装"
        exit 1
    fi
}

# 安装pip
install_pip() {
    log_step "安装pip3"
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        $USE_SUDO apt-get update
        $USE_SUDO apt-get install -y python3-pip
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        $USE_SUDO yum install -y python3-pip
    elif [[ "$OS" == *"Fedora"* ]]; then
        $USE_SUDO dnf install -y python3-pip
    else
        log_error "不支持的操作系统，请手动安装pip3"
        exit 1
    fi
    
    if command -v pip3 &>/dev/null; then
        PIP_VER=$(pip3 --version)
        log_info "pip安装成功: $PIP_VER"
    else
        log_error "pip安装失败，请手动安装"
        exit 1
    fi
}

# 安装git
install_git() {
    log_step "安装git"
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        $USE_SUDO apt-get update
        $USE_SUDO apt-get install -y git
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        $USE_SUDO yum install -y git
    elif [[ "$OS" == *"Fedora"* ]]; then
        $USE_SUDO dnf install -y git
    else
        log_error "不支持的操作系统，请手动安装git"
        exit 1
    fi
    
    if command -v git &>/dev/null; then
        GIT_VER=$(git --version)
        log_info "git安装成功: $GIT_VER"
    else
        log_error "git安装失败，请手动安装"
        exit 1
    fi
}

# 安装系统依赖
install_system_dependencies() {
    log_step "安装系统依赖"
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        log_info "安装Ubuntu/Debian系统依赖"
        $USE_SUDO apt-get update
        $USE_SUDO apt-get install -y build-essential libssl-dev libffi-dev python3-dev wget curl
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        log_info "安装CentOS/RHEL系统依赖"
        $USE_SUDO yum groupinstall -y "Development Tools"
        $USE_SUDO yum install -y openssl-devel bzip2-devel libffi-devel wget curl
    elif [[ "$OS" == *"Fedora"* ]]; then
        log_info "安装Fedora系统依赖"
        $USE_SUDO dnf groupinstall -y "Development Tools"
        $USE_SUDO dnf install -y openssl-devel bzip2-devel libffi-devel wget curl
    else
        log_warn "不支持的操作系统，跳过系统依赖安装"
    fi
    
    log_info "系统依赖安装完成"
}

# 安装TA-Lib
install_talib() {
    log_step "安装TA-Lib"
    
    # 下载并编译TA-Lib
    cd /tmp
    wget http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
    tar -xzf ta-lib-0.4.0-src.tar.gz
    cd ta-lib/
    ./configure --prefix=/usr
    make
    $USE_SUDO make install
    cd ..
    rm -rf ta-lib-0.4.0-src.tar.gz ta-lib/
    
    log_info "TA-Lib安装完成"
}

# 克隆或更新代码库
setup_repository() {
    log_step "设置代码库"
    
    # 设置安装目录
    INSTALL_DIR="$HOME/crypto_monitoring"
    
    # 检查目录是否已存在
    if [ -d "$INSTALL_DIR" ]; then
        log_info "发现已存在的安装目录: $INSTALL_DIR"
        read -p "是否覆盖现有安装? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            log_info "备份现有安装..."
            BACKUP_DIR="$INSTALL_DIR.backup.$(date +%Y%m%d%H%M%S)"
            mv "$INSTALL_DIR" "$BACKUP_DIR"
            log_info "原安装已备份至: $BACKUP_DIR"
            mkdir -p "$INSTALL_DIR"
        else
            log_info "将在现有目录中更新..."
        fi
    else
        log_info "创建安装目录: $INSTALL_DIR"
        mkdir -p "$INSTALL_DIR"
    fi
    
    # 创建必要的子目录
    mkdir -p "$INSTALL_DIR/exchange_api"
    mkdir -p "$INSTALL_DIR/web_scraper"
    mkdir -p "$INSTALL_DIR/notification"
    mkdir -p "$INSTALL_DIR/results/announcements"
    mkdir -p "$INSTALL_DIR/results/binance_us"
    mkdir -p "$INSTALL_DIR/results/combined"
    mkdir -p "$INSTALL_DIR/logs"
    
    log_info "代码库设置完成: $INSTALL_DIR"
    
    # 返回安装目录路径
    echo "$INSTALL_DIR"
}

# 复制脚本文件
copy_scripts() {
    log_step "复制脚本文件"
    
    INSTALL_DIR=$1
    SOURCE_DIR=$2
    
    # 复制API监控脚本
    cp "$SOURCE_DIR/exchange_api/crypto_exchange_monitor.py" "$INSTALL_DIR/exchange_api/"
    log_info "已复制API监控脚本"
    
    # 复制网页爬虫脚本
    cp "$SOURCE_DIR/web_scraper/exchange_announcement_scraper_final.py" "$INSTALL_DIR/web_scraper/"
    log_info "已复制网页爬虫脚本"
    
    # 复制Telegram通知脚本
    cp "$SOURCE_DIR/notification/integrated_monitor.py" "$INSTALL_DIR/notification/"
    log_info "已复制Telegram集成监控脚本"
    
    cp "$SOURCE_DIR/notification/telegram_notifier.py" "$INSTALL_DIR/notification/"
    log_info "已复制Telegram通知脚本"
    
    # 复制配置文件
    cp "$SOURCE_DIR/notification/integrated_config.json" "$INSTALL_DIR/notification/"
    log_info "已复制配置文件"
    
    # 复制README和requirements
    cp "$SOURCE_DIR/README.md" "$INSTALL_DIR/"
    cp "$SOURCE_DIR/requirements.txt" "$INSTALL_DIR/"
    log_info "已复制README和requirements文件"
    
    log_info "脚本文件复制完成"
}

# 创建启动脚本
create_startup_scripts() {
    log_step "创建启动脚本"
    
    INSTALL_DIR=$1
    
    # 创建启动脚本
    cat > "$INSTALL_DIR/start_monitoring.sh" << 'EOF'
#!/bin/bash

# 加密货币监控系统启动脚本

# 设置颜色
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 显示帮助信息
show_help() {
    echo -e "${BLUE}加密货币监控系统启动脚本${NC}"
    echo
    echo "用法: $0 [选项]"
    echo
    echo "选项:"
    echo "  -h, --help                显示此帮助信息"
    echo "  -t, --telegram-token      设置Telegram Bot令牌"
    echo "  -m, --mode                设置运行模式 (api, web, telegram, full)"
    echo "  -b, --background          在后台运行"
    echo
    echo "示例:"
    echo "  $0 -t 123456789:ABCDefGhIJKlmNoPQRsTUVwxyZ -m full"
    echo "  $0 -t 123456789:ABCDefGhIJKlmNoPQRsTUVwxyZ -m telegram -b"
    echo
}

# 默认值
TELEGRAM_TOKEN=""
MODE="full"
BACKGROUND=false

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -h|--help)
            show_help
            exit 0
            ;;
        -t|--telegram-token)
            TELEGRAM_TOKEN="$2"
            shift
            shift
            ;;
        -m|--mode)
            MODE="$2"
            shift
            shift
            ;;
        -b|--background)
            BACKGROUND=true
            shift
            ;;
        *)
            echo -e "${RED}错误: 未知选项 $1${NC}"
            show_help
            exit 1
            ;;
    esac
done

# 检查Telegram令牌
if [[ -z "$TELEGRAM_TOKEN" && ("$MODE" == "telegram" || "$MODE" == "full") ]]; then
    echo -e "${YELLOW}警告: 未提供Telegram Bot令牌${NC}"
    read -p "请输入Telegram Bot令牌 (或按Enter跳过Telegram功能): " TELEGRAM_TOKEN
    echo
fi

# 确定脚本目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# 启动函数
start_api_monitor() {
    echo -e "${GREEN}启动API监控...${NC}"
    if [ "$BACKGROUND" = true ]; then
        python3 exchange_api/crypto_exchange_monitor.py > logs/api_monitor.log 2>&1 &
        echo $! > .api_monitor.pid
        echo -e "${GREEN}API监控已在后台启动，PID: $(cat .api_monitor.pid)${NC}"
    else
        python3 exchange_api/crypto_exchange_monitor.py
    fi
}

start_web_scraper() {
    echo -e "${GREEN}启动网页爬虫...${NC}"
    if [ "$BACKGROUND" = true ]; then
        python3 web_scraper/exchange_announcement_scraper_final.py > logs/web_scraper.log 2>&1 &
        echo $! > .web_scraper.pid
        echo -e "${GREEN}网页爬虫已在后台启动，PID: $(cat .web_scraper.pid)${NC}"
    else
        python3 web_scraper/exchange_announcement_scraper_final.py
    fi
}

start_telegram_notifier() {
    if [ -z "$TELEGRAM_TOKEN" ]; then
        echo -e "${YELLOW}未提供Telegram Bot令牌，跳过Telegram通知功能${NC}"
        return
    fi
    
    echo -e "${GREEN}启动Telegram通知...${NC}"
    if [ "$BACKGROUND" = true ]; then
        python3 notification/integrated_monitor.py "$TELEGRAM_TOKEN" > logs/telegram_notifier.log 2>&1 &
        echo $! > .telegram_notifier.pid
        echo -e "${GREEN}Telegram通知已在后台启动，PID: $(cat .telegram_notifier.pid)${NC}"
    else
        python3 notification/integrated_monitor.py "$TELEGRAM_TOKEN"
    fi
}

# 创建日志目录
mkdir -p logs

# 根据模式启动相应组件
case "$MODE" in
    api)
        start_api_monitor
        ;;
    web)
        start_web_scraper
        ;;
    telegram)
        start_telegram_notifier
        ;;
    full)
        if [ "$BACKGROUND" = true ]; then
            start_api_monitor
            start_web_scraper
            start_telegram_notifier
            echo -e "${GREEN}所有组件已在后台启动${NC}"
        else
            echo -e "${YELLOW}全模式下前台运行只能启动一个组件，默认启动Telegram通知${NC}"
            echo -e "${YELLOW}如需启动所有组件，请使用 -b 参数在后台运行${NC}"
            start_telegram_notifier
        fi
        ;;
    *)
        echo -e "${RED}错误: 未知模式 $MODE${NC}"
        show_help
        exit 1
        ;;
esac

echo -e "${GREEN}启动完成!${NC}"
EOF
    
    # 创建停止脚本
    cat > "$INSTALL_DIR/stop_monitoring.sh" << 'EOF'
#!/bin/bash

# 加密货币监控系统停止脚本

# 设置颜色
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 确定脚本目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# 停止API监控
if [ -f .api_monitor.pid ]; then
    PID=$(cat .api_monitor.pid)
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}停止API监控 (PID: $PID)...${NC}"
        kill $PID
        rm .api_monitor.pid
    else
        echo -e "${YELLOW}API监控进程不存在${NC}"
        rm .api_monitor.pid
    fi
else
    echo -e "${YELLOW}未找到API监控PID文件${NC}"
fi

# 停止网页爬虫
if [ -f .web_scraper.pid ]; then
    PID=$(cat .web_scraper.pid)
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}停止网页爬虫 (PID: $PID)...${NC}"
        kill $PID
        rm .web_scraper.pid
    else
        echo -e "${YELLOW}网页爬虫进程不存在${NC}"
        rm .web_scraper.pid
    fi
else
    echo -e "${YELLOW}未找到网页爬虫PID文件${NC}"
fi

# 停止Telegram通知
if [ -f .telegram_notifier.pid ]; then
    PID=$(cat .telegram_notifier.pid)
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}停止Telegram通知 (PID: $PID)...${NC}"
        kill $PID
        rm .telegram_notifier.pid
    else
        echo -e "${YELLOW}Telegram通知进程不存在${NC}"
        rm .telegram_notifier.pid
    fi
else
    echo -e "${YELLOW}未找到Telegram通知PID文件${NC}"
fi

echo -e "${GREEN}所有监控组件已停止${NC}"
EOF
    
    # 创建状态检查脚本
    cat > "$INSTALL_DIR/status_monitoring.sh" << 'EOF'
#!/bin/bash

# 加密货币监控系统状态检查脚本

# 设置颜色
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 确定脚本目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

echo -e "${BLUE}加密货币监控系统状态${NC}"
echo -e "${BLUE}=====================================${NC}"

# 检查API监控
if [ -f .api_monitor.pid ]; then
    PID=$(cat .api_monitor.pid)
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}API监控: 运行中 (PID: $PID)${NC}"
    else
        echo -e "${RED}API监控: 已停止 (PID文件存在但进程不存在)${NC}"
    fi
else
    echo -e "${YELLOW}API监控: 未运行${NC}"
fi

# 检查网页爬虫
if [ -f .web_scraper.pid ]; then
    PID=$(cat .web_scraper.pid)
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}网页爬虫: 运行中 (PID: $PID)${NC}"
    else
        echo -e "${RED}网页爬虫: 已停止 (PID文件存在但进程不存在)${NC}"
    fi
else
    echo -e "${YELLOW}网页爬虫: 未运行${NC}"
fi

# 检查Telegram通知
if [ -f .telegram_notifier.pid ]; then
    PID=$(cat .telegram_notifier.pid)
    if ps -p $PID > /dev/null; then
        echo -e "${GREEN}Telegram通知: 运行中 (PID: $PID)${NC}"
    else
        echo -e "${RED}Telegram通知: 已停止 (PID文件存在但进程不存在)${NC}"
    fi
else
    echo -e "${YELLOW}Telegram通知: 未运行${NC}"
fi

echo -e "${BLUE}=====================================${NC}"

# 检查日志文件
echo -e "${BLUE}日志文件状态:${NC}"
if [ -f logs/api_monitor.log ]; then
    SIZE=$(du -h logs/api_monitor.log | cut -f1)
    LAST_MODIFIED=$(stat -c %y logs/api_monitor.log)
    echo -e "${GREEN}API监控日志: $SIZE, 最后修改: $LAST_MODIFIED${NC}"
else
    echo -e "${YELLOW}API监控日志: 不存在${NC}"
fi

if [ -f logs/web_scraper.log ]; then
    SIZE=$(du -h logs/web_scraper.log | cut -f1)
    LAST_MODIFIED=$(stat -c %y logs/web_scraper.log)
    echo -e "${GREEN}网页爬虫日志: $SIZE, 最后修改: $LAST_MODIFIED${NC}"
else
    echo -e "${YELLOW}网页爬虫日志: 不存在${NC}"
fi

if [ -f logs/telegram_notifier.log ]; then
    SIZE=$(du -h logs/telegram_notifier.log | cut -f1)
    LAST_MODIFIED=$(stat -c %y logs/telegram_notifier.log)
    echo -e "${GREEN}Telegram通知日志: $SIZE, 最后修改: $LAST_MODIFIED${NC}"
else
    echo -e "${YELLOW}Telegram通知日志: 不存在${NC}"
fi

echo -e "${BLUE}=====================================${NC}"
echo -e "${GREEN}状态检查完成${NC}"
EOF
    
    # 设置执行权限
    chmod +x "$INSTALL_DIR/start_monitoring.sh"
    chmod +x "$INSTALL_DIR/stop_monitoring.sh"
    chmod +x "$INSTALL_DIR/status_monitoring.sh"
    
    log_info "启动脚本创建完成"
}

# 安装Python依赖
install_python_dependencies() {
    log_step "安装Python依赖"
    
    INSTALL_DIR=$1
    
    # 安装依赖
    cd "$INSTALL_DIR"
    pip3 install -r requirements.txt
    
    # 安装playwright浏览器
    python3 -m playwright install
    
    log_info "Python依赖安装完成"
}

# 主函数
main() {
    # 显示欢迎信息
    echo -e "${BLUE}=====================================${NC}"
    echo -e "${BLUE}  加密货币监控系统安装程序  ${NC}"
    echo -e "${BLUE}=====================================${NC}"
    
    # 检查root权限
    check_root
    
    # 检查系统环境
    check_system
    
    # 安装系统依赖
    install_system_dependencies
    
    # 安装TA-Lib
    install_talib
    
    # 设置代码库
    INSTALL_DIR=$(setup_repository)
    
    # 复制脚本文件
    copy_scripts "$INSTALL_DIR" "$PWD"
    
    # 创建启动脚本
    create_startup_scripts "$INSTALL_DIR"
    
    # 安装Python依赖
    install_python_dependencies "$INSTALL_DIR"
    
    # 显示安装完成信息
    echo -e "${BLUE}=====================================${NC}"
    echo -e "${GREEN}  加密货币监控系统安装完成!  ${NC}"
    echo -e "${BLUE}=====================================${NC}"
    echo -e "安装目录: ${GREEN}$INSTALL_DIR${NC}"
    echo -e "使用以下命令启动系统:"
    echo -e "cd ${GREEN}$INSTALL_DIR${NC}"
    echo -e "./start_monitoring.sh -t <your_telegram_bot_token> -m full -b"
    echo -e "详细使用说明请参阅: ${GREEN}$INSTALL_DIR/README.md${NC}"
}

# 执行主函数
main
