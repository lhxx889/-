"""
多交易所加密货币异动监控系统 - 主程序
负责协调多交易所数据采集、异常检测和告警
"""

import os
import time
import json
import logging
import signal
import sys
from datetime import datetime
from typing import Dict, List, Any, Optional

# 导入自定义模块
from multi_exchange_collector import MultiExchangeDataCollector
from multi_exchange_anomaly_detector import MultiExchangeAnomalyDetector
from multi_exchange_alerter import TelegramAlerter, MultiExchangeAlerter

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("multi_exchange_monitor")

class MultiExchangeCryptoMonitor:
    """多交易所加密货币异动监控系统主类"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化多交易所加密货币异动监控系统
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # 初始化模块
        self.data_collector = MultiExchangeDataCollector()
        self.anomaly_detector = MultiExchangeAnomalyDetector(
            self.data_collector,
            price_change_threshold=self.config["price_threshold"],
            volume_change_threshold=self.config["volume_threshold"]
        )
        
        # 初始化告警模块
        self.telegram_alerter = TelegramAlerter()
        self.multi_exchange_alerter = MultiExchangeAlerter(self.telegram_alerter)
        
        # 运行标志
        self.running = False
        
        logger.info("多交易所加密货币异动监控系统初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        default_config = {
            "check_interval": 60,  # 检查间隔（秒）
            "price_threshold": 30.0,  # 价格异动阈值（百分比）
            "volume_threshold": 200.0,  # 交易量异动阈值（百分比）
            "enabled_exchanges": ["gateio", "binance"],  # 启用的交易所
            "excluded_symbols": [],  # 排除的币种符号
            "max_alerts_per_batch": 5,  # 每批最大告警数量
            "data_retention_days": 7  # 数据保留天数
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # 合并默认配置和加载的配置
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    
                    logger.info(f"从配置文件加载配置成功")
                    return config
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，使用默认配置")
                return default_config
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
            return default_config
    
    def _save_config(self) -> bool:
        """
        保存配置到文件
        
        Returns:
            保存是否成功
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            logger.info(f"配置已保存到 {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"保存配置失败: {str(e)}")
            return False
    
    def start(self) -> None:
        """启动监控系统"""
        if self.running:
            logger.warning("监控系统已经在运行中")
            return
        
        self.running = True
        logger.info("启动多交易所监控系统")
        
        # 注册信号处理器
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        try:
            # 发送启动通知
            if self.telegram_alerter.is_configured():
                self.multi_exchange_alerter.send_system_status(
                    self.config["enabled_exchanges"],
                    self.config
                )
            
            # 主监控循环
            while self.running:
                try:
                    # 获取所有交易所的ticker数据
                    logger.info("获取所有交易所ticker数据")
                    self.data_collector.update_data(self.config["enabled_exchanges"])
                    
                    # 检测异常
                    logger.info("检测异常")
                    anomalies = self.anomaly_detector.detect_all_anomalies(self.config["enabled_exchanges"])
                    
                    # 过滤和排序异常
                    if anomalies:
                        filtered_anomalies = self.anomaly_detector.filter_and_prioritize_alerts(
                            anomalies, 
                            self.config["max_alerts_per_batch"]
                        )
                        
                        # 保存异常到数据库
                        self.anomaly_detector.save_anomalies_to_db(filtered_anomalies)
                        
                        # 发送告警
                        if self.telegram_alerter.is_configured():
                            self.multi_exchange_alerter.send_batch_alerts(
                                filtered_anomalies,
                                self.config["max_alerts_per_batch"]
                            )
                    
                    # 定期清理旧数据
                    if datetime.now().hour == 0 and datetime.now().minute < 5:
                        self.data_collector.clean_old_data(self.config["data_retention_days"])
                    
                    # 等待下一次检查
                    check_interval = self.config["check_interval"]
                    logger.info(f"等待 {check_interval}秒 后进行下一次检查")
                    
                    # 分段等待，以便能够及时响应停止信号
                    for _ in range(check_interval):
                        if not self.running:
                            break
                        time.sleep(1)
                except Exception as e:
                    logger.error(f"监控循环异常: {str(e)}")
                    time.sleep(10)  # 出错后等待一段时间再继续
        except KeyboardInterrupt:
            logger.info("接收到键盘中断信号，停止监控系统")
        finally:
            self.running = False
            logger.info("监控系统已停止")
    
    def stop(self) -> None:
        """停止监控系统"""
        if not self.running:
            logger.warning("监控系统未在运行")
            return
        
        logger.info("停止监控系统")
        self.running = False
    
    def _signal_handler(self, sig, frame) -> None:
        """
        信号处理器
        
        Args:
            sig: 信号
            frame: 帧
        """
        logger.info(f"接收到信号 {sig}，停止监控系统")
        self.stop()
    
    def update_config(self, new_config: Dict[str, Any]) -> bool:
        """
        更新配置
        
        Args:
            new_config: 新配置
            
        Returns:
            更新是否成功
        """
        try:
            # 更新配置
            for key, value in new_config.items():
                if key in self.config:
                    self.config[key] = value
            
            # 保存配置
            self._save_config()
            
            # 更新异常检测器参数
            self.anomaly_detector.price_change_threshold = self.config["price_threshold"]
            self.anomaly_detector.volume_change_threshold = self.config["volume_threshold"]
            
            logger.info("配置已更新")
            return True
        except Exception as e:
            logger.error(f"更新配置失败: {str(e)}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """
        获取系统状态
        
        Returns:
            系统状态字典
        """
        status = {
            "running": self.running,
            "config": self.config,
            "telegram_configured": self.telegram_alerter.is_configured(),
            "enabled_exchanges": self.config["enabled_exchanges"],
            "current_time": datetime.now().isoformat()
        }
        
        return status


# 测试代码
if __name__ == "__main__":
    # 创建多交易所加密货币异动监控系统实例
    monitor = MultiExchangeCryptoMonitor()
    
    # 显示系统状态
    status = monitor.get_status()
    print("系统状态:")
    print(f"  - 运行状态: {'运行中' if status['running'] else '已停止'}")
    print(f"  - Telegram配置: {'已配置' if status['telegram_configured'] else '未配置'}")
    print(f"  - 启用的交易所: {', '.join(status['enabled_exchanges'])}")
    print(f"  - 价格异动阈值: {status['config']['price_threshold']}%")
    print(f"  - 交易量异动阈值: {status['config']['volume_threshold']}%")
    print(f"  - 检查间隔: {status['config']['check_interval']}秒")
    
    # 如果作为主程序运行，启动监控系统
    if len(sys.argv) > 1 and sys.argv[1] == "start":
        print("启动监控系统...")
        monitor.start()
    else:
        print("\n使用方法: python multi_exchange_monitor.py start")
        print("或者在Python代码中导入并使用:")
        print("  from multi_exchange_monitor import MultiExchangeCryptoMonitor")
        print("  monitor = MultiExchangeCryptoMonitor()")
        print("  monitor.start()")
