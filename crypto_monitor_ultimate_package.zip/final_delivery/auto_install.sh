#!/bin/bash
echo "===== 加密货币监控系统 自适应安装脚本 ====="

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 检测系统信息
echo -e "${YELLOW}正在检测系统环境...${NC}"
OS_NAME=$(cat /etc/os-release | grep -w "NAME" | cut -d= -f2 | tr -d '"')
OS_VERSION=$(cat /etc/os-release | grep -w "VERSION_ID" | cut -d= -f2 | tr -d '"')
PYTHON_VERSION=$(python3 --version 2>/dev/null | cut -d' ' -f2 || echo "未安装")

echo -e "操作系统: ${GREEN}$OS_NAME${NC}"
echo -e "系统版本: ${GREEN}$OS_VERSION${NC}"
echo -e "Python版本: ${GREEN}$PYTHON_VERSION${NC}"

# 安装必要的系统包
echo -e "${YELLOW}正在安装必要的系统包...${NC}"
sudo apt update

# 检查并安装Python3
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}未检测到Python3，正在安装...${NC}"
    sudo apt install -y python3
else
    echo -e "${GREEN}Python3已安装: $(python3 --version)${NC}"
fi

# 检查并安装pip
if ! command -v pip3 &> /dev/null; then
    echo -e "${RED}未检测到pip3，正在安装...${NC}"
    sudo apt install -y python3-pip
else
    echo -e "${GREEN}pip3已安装: $(pip3 --version)${NC}"
fi

# 尝试安装虚拟环境包
echo -e "${YELLOW}正在安装Python虚拟环境支持...${NC}"
VENV_INSTALLED=false

# 尝试安装python3-venv
if sudo apt install -y python3-venv; then
    echo -e "${GREEN}成功安装python3-venv${NC}"
    VENV_INSTALLED=true
else
    # 如果失败，尝试安装特定版本的venv
    PYTHON_VERSION_SHORT=$(python3 --version 2>/dev/null | cut -d' ' -f2 | cut -d. -f1,2)
    if [ ! -z "$PYTHON_VERSION_SHORT" ]; then
        if sudo apt install -y python3.$PYTHON_VERSION_SHORT-venv; then
            echo -e "${GREEN}成功安装python3.$PYTHON_VERSION_SHORT-venv${NC}"
            VENV_INSTALLED=true
        else
            echo -e "${RED}无法安装Python虚拟环境包，将使用用户级安装方式${NC}"
        fi
    else
        echo -e "${RED}无法检测Python版本，将使用用户级安装方式${NC}"
    fi
fi

# 安装其他可能需要的依赖
echo -e "${YELLOW}正在安装其他可能需要的依赖...${NC}"
sudo apt install -y build-essential libssl-dev libffi-dev python3-dev

# 根据虚拟环境安装结果选择安装方式
if [ "$VENV_INSTALLED" = true ]; then
    echo -e "${GREEN}使用虚拟环境安装方式${NC}"
    
    # 创建并激活虚拟环境
    echo -e "${YELLOW}正在创建Python虚拟环境...${NC}"
    python3 -m venv venv
    
    if [ -f venv/bin/activate ]; then
        source venv/bin/activate
        echo -e "${GREEN}虚拟环境创建成功并已激活${NC}"
        
        # 安装依赖
        echo -e "${YELLOW}正在安装依赖包...${NC}"
        pip install --upgrade pip
        pip install -r requirements.txt
        
        # 创建启动脚本
        cat > start.sh << EOF
#!/bin/bash
source venv/bin/activate
cd src
python main.py
EOF
        chmod +x start.sh
    else
        echo -e "${RED}虚拟环境创建失败，切换到用户级安装方式${NC}"
        VENV_INSTALLED=false
    fi
fi

# 如果虚拟环境安装失败，使用用户级安装
if [ "$VENV_INSTALLED" = false ]; then
    echo -e "${YELLOW}使用用户级安装方式${NC}"
    
    # 安装依赖到用户目录
    echo -e "${YELLOW}正在安装依赖包到用户目录...${NC}"
    pip3 install --user --upgrade pip
    pip3 install --user -r requirements.txt
    
    # 创建启动脚本
    cat > start.sh << EOF
#!/bin/bash
cd src
python3 main.py
EOF
    chmod +x start.sh
fi

# 创建基础配置
echo -e "${YELLOW}正在创建基础配置...${NC}"
mkdir -p src/config
cat > src/config.json << EOF
{
  "enabled_exchanges": ["gateio", "binance"],
  "use_binance_testnet": true,
  "check_interval": 60,
  "price_change_threshold": 5.0,
  "volume_change_threshold": 20.0,
  "detection_sensitivity": "medium",
  "enable_advanced_detection": true
}
EOF

echo -e "${GREEN}===== 安装完成! =====${NC}"
echo -e "${GREEN}启动系统请运行: ./start.sh${NC}"
