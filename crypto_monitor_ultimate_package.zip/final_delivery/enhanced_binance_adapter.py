"""
增强版币安交易所适配器 - 支持测试网络和代理配置
"""

import requests
import time
import logging
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("binance_adapter")

class BinanceExchangeAPI:
    """币安交易所API适配器，支持主网/测试网和代理配置"""
    
    # 币安API基础URL选项
    MAIN_NET_URL = "https://api.binance.com/api/v3"
    TEST_NET_URL = "https://testnet.binance.vision/api/v3"
    
    # API端点
    ENDPOINTS = {
        "tickers": "/ticker/24hr",
        "exchange_info": "/exchangeInfo",
        "ticker": "/ticker/24hr",
        "klines": "/klines"
    }
    
    def __init__(self, use_testnet: bool = False, proxy: str = None, custom_base_url: str = None):
        """
        初始化币安交易所API适配器
        
        Args:
            use_testnet: 是否使用测试网络
            proxy: 代理服务器URL (如 "http://10.10.1.10:3128" 或 "socks5://user:pass@host:port")
            custom_base_url: 自定义API基础URL
        """
        # 设置API基础URL
        if custom_base_url:
            self.BASE_URL = custom_base_url
        elif use_testnet:
            self.BASE_URL = self.TEST_NET_URL
        else:
            self.BASE_URL = self.MAIN_NET_URL
        
        # 设置代理
        self.proxies = None
        if proxy:
            self.proxies = {
                "http": proxy,
                "https": proxy
            }
        
        logger.info(f"币安交易所API适配器初始化，API端点: {self.BASE_URL}，代理: {'已配置' if self.proxies else '未配置'}")
    
    @property
    def exchange_name(self) -> str:
        """获取交易所名称"""
        return "Binance"
    
    @property
    def exchange_id(self) -> str:
        """获取交易所唯一标识符"""
        return "binance"
    
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """
        获取所有交易对的ticker数据
        
        Returns:
            所有交易对的ticker数据列表
        """
        logger.info("获取币安所有交易对的ticker数据")
        url = f"{self.BASE_URL}{self.ENDPOINTS['tickers']}"
        response = self._make_request(url)
        if response:
            logger.info(f"成功获取币安{len(response)}个交易对的ticker数据")
            return response
        return []
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取特定交易对的ticker数据
        
        Args:
            symbol: 交易对符号，如"BTCUSDT"
            
        Returns:
            交易对的ticker数据或None（如果请求失败）
        """
        logger.info(f"获取币安{symbol}的ticker数据")
        url = f"{self.BASE_URL}{self.ENDPOINTS['ticker']}"
        params = {"symbol": symbol}
        return self._make_request(url, params)
    
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """
        获取所有可交易的交易对信息
        
        Returns:
            所有可交易的交易对信息列表
        """
        logger.info("获取币安所有可交易的交易对信息")
        url = f"{self.BASE_URL}{self.ENDPOINTS['exchange_info']}"
        response = self._make_request(url)
        if response and "symbols" in response:
            logger.info(f"成功获取币安{len(response['symbols'])}个交易对信息")
            return response["symbols"]
        return []
    
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """
        将币安特定的ticker数据格式转换为标准格式
        
        Args:
            ticker: 币安特定的ticker数据
            
        Returns:
            标准化的ticker数据
        """
        try:
            # 计算24小时变化百分比
            last_price = float(ticker.get("lastPrice", 0))
            open_price = float(ticker.get("openPrice", 0))
            change_pct = 0
            if open_price > 0:
                change_pct = ((last_price - open_price) / open_price) * 100
            
            # 标准化交易对符号
            symbol = ticker.get("symbol", "")
            # 币安使用直接连接的符号（如BTCUSDT），需要转换为带下划线的格式（如BTC_USDT）
            # 这里假设所有交易对都是以USDT、BTC、ETH等结尾
            normalized_symbol = symbol
            for quote in ["USDT", "BTC", "ETH", "BNB", "BUSD"]:
                if symbol.endswith(quote):
                    base = symbol[:-len(quote)]
                    normalized_symbol = f"{base}_{quote}"
                    break
            
            return {
                "exchange": self.exchange_id,
                "exchange_name": self.exchange_name,
                "symbol": normalized_symbol,
                "original_symbol": symbol,
                "price": last_price,
                "volume_24h": float(ticker.get("volume", 0)),
                "change_24h": change_pct,
                "high_24h": float(ticker.get("highPrice", 0)),
                "low_24h": float(ticker.get("lowPrice", 0)),
                "timestamp": datetime.now().isoformat(),  # 币安不直接提供时间戳，使用系统时间
                "original_data": ticker
            }
        except (ValueError, TypeError) as e:
            logger.warning(f"标准化币安ticker数据失败: {str(e)}")
            return {
                "exchange": self.exchange_id,
                "exchange_name": self.exchange_name,
                "symbol": ticker.get("symbol", ""),
                "original_symbol": ticker.get("symbol", ""),
                "price": 0.0,
                "volume_24h": 0.0,
                "change_24h": 0.0,
                "high_24h": 0.0,
                "low_24h": 0.0,
                "timestamp": datetime.now().isoformat(),
                "original_data": ticker
            }
    
    def get_exchange_url(self, symbol: str) -> str:
        """
        获取交易对在币安的URL链接
        
        Args:
            symbol: 交易对符号，可以是标准化的（如BTC_USDT）或原始的（如BTCUSDT）
            
        Returns:
            交易对在币安的URL链接
        """
        # 转换标准化符号为币安格式
        if "_" in symbol:
            parts = symbol.split("_")
            if len(parts) == 2:
                symbol = f"{parts[0]}{parts[1]}"
        
        return f"https://www.binance.com/en/trade/{symbol}"
    
    def fetch_klines(self, symbol: str, interval: str = "1h", limit: int = 24) -> List[List]:
        """
        获取K线数据
        
        Args:
            symbol: 交易对符号，如"BTCUSDT"
            interval: K线间隔，如"1m", "5m", "1h", "1d"
            limit: 获取的K线数量，最大500
            
        Returns:
            K线数据列表
        """
        logger.info(f"获取币安{symbol}的{interval}K线数据")
        
        # 转换标准化符号为币安格式
        if "_" in symbol:
            parts = symbol.split("_")
            if len(parts) == 2:
                symbol = f"{parts[0]}{parts[1]}"
        
        url = f"{self.BASE_URL}{self.ENDPOINTS['klines']}"
        params = {
            "symbol": symbol,
            "interval": interval,
            "limit": limit
        }
        
        response = self._make_request(url, params)
        if response:
            logger.info(f"成功获取币安{symbol}的{len(response)}条K线数据")
            return response
        return []
    
    def _make_request(self, url: str, params: Dict = None) -> Optional[Any]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API端点URL
            params: 请求参数
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    url, 
                    params=params, 
                    timeout=10,
                    proxies=self.proxies
                )
                
                # 检查是否返回451错误（因法律原因不可用）
                if response.status_code == 451:
                    logger.error(f"币安API访问受限（HTTP 451）: 可能是地理位置限制，请考虑使用VPN/代理或测试网络")
                    return None
                
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"币安API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"币安API请求最终失败: {str(e)}")
                    return None
            except json.JSONDecodeError as e:
                logger.error(f"解析币安API响应JSON失败: {str(e)}")
                return None


# 测试代码
if __name__ == "__main__":
    # 测试主网（可能会受到地理限制）
    print("测试主网...")
    binance_main = BinanceExchangeAPI(use_testnet=False)
    main_pairs = binance_main.fetch_all_currency_pairs()
    print(f"主网交易对数量: {len(main_pairs)}")
    
    # 测试测试网
    print("\n测试测试网...")
    binance_test = BinanceExchangeAPI(use_testnet=True)
    test_pairs = binance_test.fetch_all_currency_pairs()
    print(f"测试网交易对数量: {len(test_pairs)}")
    
    # 如果配置了代理，测试代理
    proxy_url = None  # 设置为您的代理URL，如 "http://10.10.1.10:3128"
    if proxy_url:
        print("\n测试代理...")
        binance_proxy = BinanceExchangeAPI(proxy=proxy_url)
        proxy_pairs = binance_proxy.fetch_all_currency_pairs()
        print(f"通过代理获取的交易对数量: {len(proxy_pairs)}")
    
    # 测试获取ticker数据
    print("\n测试获取ticker数据...")
    if len(test_pairs) > 0:
        # 使用测试网
        test_symbol = test_pairs[0]["symbol"]
        print(f"使用测试网获取{test_symbol}的ticker数据...")
        test_ticker = binance_test.fetch_ticker(test_symbol)
        if test_ticker:
            print(f"测试网{test_symbol}的价格: {test_ticker.get('lastPrice', 'N/A')}")
            
            # 测试标准化
            normalized = binance_test.normalize_ticker_data(test_ticker)
            print(f"标准化后的数据: {normalized['symbol']}, 价格: {normalized['price']}")
    
    print("\n测试完成!")
