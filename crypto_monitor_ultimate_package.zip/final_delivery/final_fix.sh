#!/bin/bash
echo "===== 最终依赖修复方案 ====="

# 确保在虚拟环境中
if [ -d "venv" ] && [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo "已激活虚拟环境"
else
    echo "创建新的虚拟环境..."
    python3 -m venv venv
    source venv/bin/activate
fi

# 升级pip
pip install --upgrade pip

# 安装核心依赖，不指定版本
echo "安装核心依赖..."
pip install flask flask-sqlalchemy pymysql requests

# 如果需要数据分析功能，安装这些包
echo "安装数据分析依赖..."
pip install matplotlib numpy pandas scikit-learn || echo "数据分析依赖安装失败，但不影响核心功能"

# 创建基础配置
echo "创建基础配置..."
mkdir -p src/config
cat > src/config.json << EOF
{
  "enabled_exchanges": ["gateio", "binance"],
  "use_binance_testnet": true,
  "check_interval": 60,
  "price_change_threshold": 5.0,
  "volume_change_threshold": 20.0,
  "detection_sensitivity": "medium",
  "enable_advanced_detection": true
}
EOF

# 创建启动脚本
cat > minimal_start.sh << EOF
#!/bin/bash
source venv/bin/activate
cd src
python main.py
EOF
chmod +x minimal_start.sh

echo "===== 修复完成! ====="
echo "启动系统请运行: ./minimal_start.sh"
