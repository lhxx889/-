#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 币种详细信息采集模块
功能：获取币种的详细信息，包括简介、合约信息、市值、社交链接等
"""

import os
import json
import time
import logging
import requests
from bs4 import BeautifulSoup
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("coin_info.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_coin_info")

class GateCoinInfo:
    """Gate.io币种详细信息采集类"""
    
    def __init__(self, config_file=None, config=None):
        """初始化币种信息采集器
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        self.base_url = "https://api.gateio.ws/api/v4"
        self.web_base_url = "https://www.gate.io"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        }
        self.cache_file = "coin_info_cache.json"
        self.coin_cache = {}  # 币种信息缓存
        
        self.config = {
            "cache_expiry": 86400,  # 缓存过期时间（秒），默认1天
            "max_retries": 3,       # 最大重试次数
            "retry_delay": 2,       # 重试延迟（秒）
            "request_timeout": 10,  # 请求超时（秒）
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.config.update(config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.config.update(user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 加载缓存的币种信息
        self.load_cache()
    
    def load_cache(self):
        """加载缓存的币种信息"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    self.coin_cache = json.load(f)
                logger.info(f"已加载币种信息缓存: {len(self.coin_cache)} 个币种")
            except Exception as e:
                logger.error(f"加载币种信息缓存失败: {e}")
                self.coin_cache = {}
    
    def save_cache(self):
        """保存币种信息到缓存"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.coin_cache, f, ensure_ascii=False, indent=2)
            logger.info(f"币种信息缓存已更新: {len(self.coin_cache)} 个币种")
        except Exception as e:
            logger.error(f"保存币种信息缓存失败: {e}")
    
    def api_request(self, endpoint, params=None):
        """发送API请求，带重试机制"""
        url = f"{self.base_url}{endpoint}"
        retries = 0
        
        while retries < self.config["max_retries"]:
            try:
                response = requests.get(
                    url, 
                    params=params, 
                    headers=self.headers, 
                    timeout=self.config["request_timeout"]
                )
                response.raise_for_status()
                return response.json()
            except Exception as e:
                retries += 1
                logger.warning(f"API请求失败 ({retries}/{self.config['max_retries']}): {e}")
                if retries < self.config["max_retries"]:
                    time.sleep(self.config["retry_delay"])
                else:
                    logger.error(f"API请求最终失败: {url}")
                    return None
    
    def fetch_page(self, url):
        """获取网页内容，带重试机制"""
        retries = 0
        
        while retries < self.config["max_retries"]:
            try:
                response = requests.get(
                    url, 
                    headers=self.headers, 
                    timeout=self.config["request_timeout"]
                )
                response.raise_for_status()
                return response.text
            except Exception as e:
                retries += 1
                logger.warning(f"网页请求失败 ({retries}/{self.config['max_retries']}): {e}")
                if retries < self.config["max_retries"]:
                    time.sleep(self.config["retry_delay"])
                else:
                    logger.error(f"网页请求最终失败: {url}")
                    return None
    
    def get_currency_detail(self, currency):
        """获取币种详细信息"""
        endpoint = f"/spot/currencies/{currency}"
        return self.api_request(endpoint)
    
    def get_ticker(self, currency_pair):
        """获取交易对行情"""
        endpoint = "/spot/tickers"
        params = {"currency_pair": currency_pair}
        result = self.api_request(endpoint, params)
        return result[0] if result else None
    
    def get_coin_info_from_web(self, currency):
        """从网页获取币种详细信息"""
        url = f"{self.web_base_url}/zh/trade/{currency}_USDT"
        html_content = self.fetch_page(url)
        if not html_content:
            return {}
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            info = {}
            
            # 尝试获取币种描述
            description_div = soup.select_one('div.coin-description')
            if description_div:
                info['description'] = description_div.text.strip()
            
            # 尝试获取社交链接
            social_links = soup.select('div.social-links a')
            for link in social_links:
                href = link.get('href', '')
                if 'twitter.com' in href or 'x.com' in href:
                    info['twitter'] = href
                elif 'telegram' in href:
                    info['telegram'] = href
                elif not href.startswith('https://www.gate.io') and 'website' not in info:
                    info['website'] = href
            
            return info
        except Exception as e:
            logger.error(f"解析币种网页信息失败: {e}")
            return {}
    
    def get_market_cap_info(self, currency):
        """获取市值信息"""
        # 注意：Gate.io API可能不直接提供市值信息，这里使用模拟数据
        # 实际应用中可能需要从其他来源获取或计算
        try:
            # 尝试从API获取流通量信息
            currency_detail = self.get_currency_detail(currency)
            ticker = self.get_ticker(f"{currency}_USDT")
            
            if currency_detail and ticker:
                # 如果API提供了流通量，可以计算市值
                if 'circulating_supply' in currency_detail:
                    circulating_supply = float(currency_detail['circulating_supply'])
                    price = float(ticker['last'])
                    market_cap = circulating_supply * price
                    return {
                        'market_cap': market_cap,
                        'circulating_supply': circulating_supply,
                        'price': price
                    }
            
            return {}
        except Exception as e:
            logger.error(f"获取市值信息失败: {e}")
            return {}
    
    def analyze_market_trend(self, currency, ticker_data):
        """分析市场趋势"""
        try:
            if not ticker_data:
                return ""
            
            price = float(ticker_data['last'])
            high_24h = float(ticker_data['high_24h'])
            low_24h = float(ticker_data['low_24h'])
            volume = float(ticker_data['quote_volume'])
            
            # 计算价格位置（在24小时高低点范围内的位置）
            price_range = high_24h - low_24h
            if price_range > 0:
                price_position = (price - low_24h) / price_range
            else:
                price_position = 0.5
            
            # 根据价格位置和成交量生成简单分析
            analysis = f"{currency} 当前价格 {price:.8f} USDT，"
            
            if price_position > 0.8:
                analysis += f"接近24小时高点 {high_24h:.8f} USDT，"
                if volume > 10000000:  # 假设高成交量阈值
                    analysis += "成交量较大，可能存在短期获利回吐压力。"
                else:
                    analysis += "但成交量一般，关注上方阻力位突破情况。"
            elif price_position < 0.2:
                analysis += f"接近24小时低点 {low_24h:.8f} USDT，"
                if volume > 10000000:
                    analysis += "成交量较大，可能有短期反弹机会。"
                else:
                    analysis += "成交量一般，关注下方支撑是否有效。"
            else:
                analysis += f"处于24小时价格区间中段，"
                analysis += f"上方阻力 {high_24h:.8f} USDT，下方支撑 {low_24h:.8f} USDT。"
            
            return analysis
        except Exception as e:
            logger.error(f"分析市场趋势失败: {e}")
            return ""
    
    def get_contract_info(self, currency):
        """获取合约信息"""
        try:
            # 尝试从API获取合约信息
            currency_detail = self.get_currency_detail(currency)
            
            if currency_detail and 'chain' in currency_detail:
                chains = currency_detail['chain'].split(',')
                contract_info = ""
                
                for chain in chains:
                    if chain and chain.strip():
                        contract_info += f"• {chain.strip()} 链\n"
                
                return contract_info if contract_info else "暂无合约信息"
            
            return "暂无合约信息"
        except Exception as e:
            logger.error(f"获取合约信息失败: {e}")
            return "暂无合约信息"
    
    def get_complete_coin_info(self, currency):
        """获取完整的币种信息"""
        # 检查缓存是否有效
        now = int(time.time())
        if currency in self.coin_cache:
            cache_time = self.coin_cache[currency].get('cache_time', 0)
            if now - cache_time < self.config["cache_expiry"]:
                logger.info(f"使用缓存的币种信息: {currency}")
                return self.coin_cache[currency]
        
        logger.info(f"获取币种详细信息: {currency}")
        
        # 获取API基础信息
        currency_detail = self.get_currency_detail(currency)
        if not currency_detail:
            logger.error(f"获取币种基础信息失败: {currency}")
            return None
        
        # 获取行情信息
        ticker = self.get_ticker(f"{currency}_USDT")
        if not ticker:
            logger.error(f"获取币种行情信息失败: {currency}")
            return None
        
        # 从网页获取额外信息
        web_info = self.get_coin_info_from_web(currency)
        
        # 获取市值信息
        market_info = self.get_market_cap_info(currency)
        
        # 获取合约信息
        contract_info = self.get_contract_info(currency)
        
        # 分析市场趋势
        market_analysis = self.analyze_market_trend(currency, ticker)
        
        # 整合所有信息
        coin_info = {
            'symbol': currency,
            'name': currency_detail.get('name', currency),
            'price': float(ticker['last']),
            'change_24h': float(ticker.get('change_percentage', 0)),
            'volume_24h': float(ticker['quote_volume']),
            'high_24h': float(ticker['high_24h']),
            'low_24h': float(ticker['low_24h']),
            'description': web_info.get('description', ''),
            'website': web_info.get('website', ''),
            'twitter': web_info.get('twitter', ''),
            'telegram': web_info.get('telegram', ''),
            'contract_info': contract_info,
            'market_cap': market_info.get('market_cap', 0),
            'circulating_supply': market_info.get('circulating_supply', 0),
            'market_analysis': market_analysis,
            'cache_time': now
        }
        
        # 更新缓存
        self.coin_cache[currency] = coin_info
        self.save_cache()
        
        return coin_info
    
    def get_new_coin_info(self, currency):
        """获取新上币的详细信息"""
        # 对于新上币，强制刷新缓存
        if currency in self.coin_cache:
            del self.coin_cache[currency]
        
        return self.get_complete_coin_info(currency)

if __name__ == "__main__":
    # 创建币种信息采集器实例
    coin_info = GateCoinInfo()
    
    # 测试获取BTC信息
    btc_info = coin_info.get_complete_coin_info("BTC")
    if btc_info:
        print(json.dumps(btc_info, indent=2, ensure_ascii=False))
    else:
        print("获取BTC信息失败")
