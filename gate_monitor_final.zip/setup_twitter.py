#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Twitter API一键设置工具
功能：
1. 自动配置Twitter API密钥
2. 自动验证API连接
3. 自动保存配置
4. 支持推特消息推送和数据采集
"""

import os
import sys
import json
import time
import argparse
import requests
import re
import base64
import getpass
from datetime import datetime

# 颜色定义
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[0;33m'
BLUE = '\033[0;34m'
NC = '\033[0m'  # No Color

def print_info(message):
    """打印信息"""
    print(f"{BLUE}[INFO]{NC} {message}")

def print_success(message):
    """打印成功信息"""
    print(f"{GREEN}[SUCCESS]{NC} {message}")

def print_warning(message):
    """打印警告信息"""
    print(f"{YELLOW}[WARNING]{NC} {message}")

def print_error(message):
    """打印错误信息"""
    print(f"{RED}[ERROR]{NC} {message}")

class TwitterSetup:
    """Twitter设置类"""
    
    def __init__(self):
        """初始化"""
        self.api_key = ""
        self.api_secret = ""
        self.access_token = ""
        self.access_token_secret = ""
        self.bearer_token = ""
        self.config_file = "twitter_config.json"
    
    def input_credentials(self):
        """输入Twitter API凭据"""
        print_info("请输入Twitter API凭据")
        print_info("您可以在 https://developer.twitter.com/en/portal/dashboard 创建或查看您的API密钥")
        
        self.api_key = input("API Key: ").strip()
        self.api_secret = input("API Secret: ").strip()
        self.access_token = input("Access Token: ").strip()
        self.access_token_secret = input("Access Token Secret: ").strip()
        self.bearer_token = input("Bearer Token (可选): ").strip()
        
        return bool(self.api_key and self.api_secret)
    
    def verify_credentials(self):
        """验证Twitter API凭据"""
        print_info("正在验证Twitter API凭据...")
        
        # 使用OAuth 1.0a验证
        if self.api_key and self.api_secret and self.access_token and self.access_token_secret:
            try:
                import tweepy
                
                auth = tweepy.OAuth1UserHandler(
                    self.api_key,
                    self.api_secret,
                    self.access_token,
                    self.access_token_secret
                )
                
                api = tweepy.API(auth)
                user = api.verify_credentials()
                
                print_success(f"OAuth 1.0a验证成功，用户: @{user.screen_name}")
                return True
            
            except ImportError:
                print_warning("未安装tweepy库，无法使用OAuth 1.0a验证")
                print_info("正在尝试使用Bearer Token验证...")
            
            except Exception as e:
                print_error(f"OAuth 1.0a验证失败: {e}")
                print_info("正在尝试使用Bearer Token验证...")
        
        # 使用Bearer Token验证
        if self.bearer_token:
            try:
                headers = {
                    "Authorization": f"Bearer {self.bearer_token}",
                    "Content-Type": "application/json"
                }
                
                response = requests.get(
                    "https://api.twitter.com/2/users/me",
                    headers=headers
                )
                
                if response.status_code == 200:
                    user_data = response.json().get("data", {})
                    username = user_data.get("username", "未知")
                    print_success(f"Bearer Token验证成功，用户: @{username}")
                    return True
                else:
                    print_error(f"Bearer Token验证失败，状态码: {response.status_code}")
                    print_error(f"错误信息: {response.text}")
                    return False
            
            except Exception as e:
                print_error(f"Bearer Token验证失败: {e}")
                return False
        
        print_error("验证失败，请检查您的API凭据")
        return False
    
    def install_dependencies(self):
        """安装依赖"""
        print_info("正在安装Twitter API依赖...")
        
        try:
            import pip
            pip.main(["install", "tweepy"])
            print_success("依赖安装成功")
            return True
        
        except Exception as e:
            print_error(f"依赖安装失败: {e}")
            print_info("请手动安装依赖: pip install tweepy")
            return False
    
    def save_config(self):
        """保存Twitter配置"""
        try:
            config = {
                "twitter": {
                    "enabled": True,
                    "api_key": self.api_key,
                    "api_secret": self.api_secret,
                    "access_token": self.access_token,
                    "access_token_secret": self.access_token_secret,
                    "bearer_token": self.bearer_token,
                    "monitor_keywords": ["crypto", "bitcoin", "ethereum", "gate.io"],
                    "monitor_accounts": ["@cz_binance", "@SBF_FTX", "@VitalikButerin"],
                    "update_interval": 300,
                    "max_tweets_per_request": 100
                }
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print_success(f"Twitter配置已保存到: {self.config_file}")
            return True
        
        except Exception as e:
            print_error(f"保存配置失败: {e}")
            return False
    
    def integrate_with_monitor(self):
        """集成到监控系统"""
        monitor_config_file = "config_main.json"
        
        try:
            # 读取现有配置
            if os.path.exists(monitor_config_file):
                with open(monitor_config_file, 'r') as f:
                    config = json.load(f)
            else:
                config = {}
            
            # 更新配置
            config["twitter_config"] = self.config_file
            
            # 保存配置
            with open(monitor_config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print_success(f"Twitter配置已集成到监控系统: {monitor_config_file}")
            return True
        
        except Exception as e:
            print_error(f"集成到监控系统失败: {e}")
            return False
    
    def create_twitter_module(self):
        """创建Twitter模块"""
        module_file = "gate_twitter_monitor.py"
        
        try:
            with open(module_file, 'w') as f:
                f.write("""#!/usr/bin/env python3
# -*- coding: utf-8 -*-

\"\"\"
Gate.io Twitter监控模块
功能：
1. 监控Twitter关键词和账号
2. 分析推文情绪和市场影响
3. 推送重要推文通知
\"\"\"

import os
import sys
import json
import time
import logging
import requests
from datetime import datetime, timedelta

try:
    import tweepy
    HAS_TWEEPY = True
except ImportError:
    HAS_TWEEPY = False

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("gate_twitter_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_twitter_monitor")

class TwitterMonitor:
    \"\"\"Twitter监控类\"\"\"
    
    def __init__(self, config_file=None, config=None):
        \"\"\"初始化
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        \"\"\"
        # 默认配置
        self.config = {
            "twitter": {
                "enabled": True,
                "api_key": "",
                "api_secret": "",
                "access_token": "",
                "access_token_secret": "",
                "bearer_token": "",
                "monitor_keywords": ["crypto", "bitcoin", "ethereum", "gate.io"],
                "monitor_accounts": ["@cz_binance", "@SBF_FTX", "@VitalikButerin"],
                "update_interval": 300,
                "max_tweets_per_request": 100
            }
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.update_config(self.config, config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(self.config, user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 初始化状态
        self.last_update = 0
        self.tweet_cache = {}
        self.api = None
        self.client = None
        
        # 初始化API
        self.init_api()
    
    def update_config(self, target, source):
        \"\"\"递归更新配置字典\"\"\"
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def init_api(self):
        \"\"\"初始化Twitter API\"\"\"
        if not self.config["twitter"]["enabled"]:
            logger.info("Twitter监控未启用")
            return
        
        if not HAS_TWEEPY:
            logger.error("未安装tweepy库，无法使用Twitter API")
            logger.info("请安装tweepy: pip install tweepy")
            return
        
        try:
            # 使用OAuth 1.0a初始化API
            if (self.config["twitter"]["api_key"] and 
                self.config["twitter"]["api_secret"] and 
                self.config["twitter"]["access_token"] and 
                self.config["twitter"]["access_token_secret"]):
                
                auth = tweepy.OAuth1UserHandler(
                    self.config["twitter"]["api_key"],
                    self.config["twitter"]["api_secret"],
                    self.config["twitter"]["access_token"],
                    self.config["twitter"]["access_token_secret"]
                )
                
                self.api = tweepy.API(auth)
                logger.info("Twitter API (OAuth 1.0a) 初始化成功")
            
            # 使用Bearer Token初始化客户端
            if self.config["twitter"]["bearer_token"]:
                self.client = tweepy.Client(
                    bearer_token=self.config["twitter"]["bearer_token"],
                    consumer_key=self.config["twitter"]["api_key"],
                    consumer_secret=self.config["twitter"]["api_secret"],
                    access_token=self.config["twitter"]["access_token"],
                    access_token_secret=self.config["twitter"]["access_token_secret"]
                )
                logger.info("Twitter Client (Bearer Token) 初始化成功")
            
            if not self.api and not self.client:
                logger.error("Twitter API初始化失败，请检查配置")
        
        except Exception as e:
            logger.error(f"Twitter API初始化失败: {e}")
    
    def search_tweets(self, query, count=100):
        \"\"\"搜索推文
        
        Args:
            query: 搜索关键词
            count: 返回结果数量
        
        Returns:
            list: 推文列表
        \"\"\"
        tweets = []
        
        try:
            if self.client:
                # 使用Twitter API v2
                response = self.client.search_recent_tweets(
                    query=query,
                    max_results=min(count, 100),
                    tweet_fields=["created_at", "public_metrics", "entities"]
                )
                
                if response.data:
                    for tweet in response.data:
                        tweets.append({
                            "id": tweet.id,
                            "text": tweet.text,
                            "created_at": tweet.created_at,
                            "retweet_count": tweet.public_metrics.get("retweet_count", 0),
                            "like_count": tweet.public_metrics.get("like_count", 0),
                            "reply_count": tweet.public_metrics.get("reply_count", 0),
                            "quote_count": tweet.public_metrics.get("quote_count", 0)
                        })
            
            elif self.api:
                # 使用Twitter API v1.1
                for tweet in tweepy.Cursor(self.api.search_tweets, q=query, count=count, tweet_mode="extended").items(count):
                    tweets.append({
                        "id": tweet.id,
                        "text": tweet.full_text,
                        "created_at": tweet.created_at,
                        "retweet_count": tweet.retweet_count,
                        "like_count": tweet.favorite_count,
                        "reply_count": 0,  # API v1.1不提供此字段
                        "quote_count": 0   # API v1.1不提供此字段
                    })
            
            logger.info(f"搜索推文成功，关键词: {query}，结果数量: {len(tweets)}")
            return tweets
        
        except Exception as e:
            logger.error(f"搜索推文失败: {e}")
            return []
    
    def get_user_tweets(self, username, count=100):
        \"\"\"获取用户推文
        
        Args:
            username: 用户名
            count: 返回结果数量
        
        Returns:
            list: 推文列表
        \"\"\"
        tweets = []
        
        try:
            # 移除@前缀
            if username.startswith("@"):
                username = username[1:]
            
            if self.client:
                # 获取用户ID
                user_response = self.client.get_user(username=username)
                
                if not user_response.data:
                    logger.error(f"获取用户失败: {username}")
                    return []
                
                user_id = user_response.data.id
                
                # 获取用户推文
                tweets_response = self.client.get_users_tweets(
                    id=user_id,
                    max_results=min(count, 100),
                    tweet_fields=["created_at", "public_metrics", "entities"]
                )
                
                if tweets_response.data:
                    for tweet in tweets_response.data:
                        tweets.append({
                            "id": tweet.id,
                            "text": tweet.text,
                            "created_at": tweet.created_at,
                            "retweet_count": tweet.public_metrics.get("retweet_count", 0),
                            "like_count": tweet.public_metrics.get("like_count", 0),
                            "reply_count": tweet.public_metrics.get("reply_count", 0),
                            "quote_count": tweet.public_metrics.get("quote_count", 0),
                            "user": username
                        })
            
            elif self.api:
                # 获取用户推文
                for tweet in tweepy.Cursor(self.api.user_timeline, screen_name=username, count=count, tweet_mode="extended").items(count):
                    tweets.append({
                        "id": tweet.id,
                        "text": tweet.full_text,
                        "created_at": tweet.created_at,
                        "retweet_count": tweet.retweet_count,
                        "like_count": tweet.favorite_count,
                        "reply_count": 0,  # API v1.1不提供此字段
                        "quote_count": 0,  # API v1.1不提供此字段
                        "user": username
                    })
            
            logger.info(f"获取用户推文成功，用户: {username}，结果数量: {len(tweets)}")
            return tweets
        
        except Exception as e:
            logger.error(f"获取用户推文失败: {e}")
            return []
    
    def analyze_tweet_sentiment(self, text):
        \"\"\"分析推文情绪
        
        Args:
            text: 推文文本
        
        Returns:
            dict: 情绪分析结果
        \"\"\"
        try:
            # 尝试使用NLTK的VADER情感分析
            from nltk.sentiment.vader import SentimentIntensityAnalyzer
            
            # 初始化分析器
            analyzer = SentimentIntensityAnalyzer()
            
            # 分析情绪
            sentiment = analyzer.polarity_scores(text)
            
            # 判断情绪
            if sentiment["compound"] >= 0.05:
                sentiment["label"] = "positive"
            elif sentiment["compound"] <= -0.05:
                sentiment["label"] = "negative"
            else:
                sentiment["label"] = "neutral"
            
            return sentiment
        
        except ImportError:
            # 如果没有NLTK，使用简单的关键词匹配
            positive_words = ["bullish", "up", "gain", "profit", "good", "great", "excellent", "moon", "rocket"]
            negative_words = ["bearish", "down", "loss", "bad", "terrible", "crash", "dump", "sell"]
            
            text_lower = text.lower()
            
            positive_count = sum(1 for word in positive_words if word in text_lower)
            negative_count = sum(1 for word in negative_words if word in text_lower)
            
            if positive_count > negative_count:
                sentiment = {
                    "pos": 0.6,
                    "neg": 0.2,
                    "neu": 0.2,
                    "compound": 0.4,
                    "label": "positive"
                }
            elif negative_count > positive_count:
                sentiment = {
                    "pos": 0.2,
                    "neg": 0.6,
                    "neu": 0.2,
                    "compound": -0.4,
                    "label": "negative"
                }
            else:
                sentiment = {
                    "pos": 0.3,
                    "neg": 0.3,
                    "neu": 0.4,
                    "compound": 0.0,
                    "label": "neutral"
                }
            
            return sentiment
        
        except Exception as e:
            logger.error(f"分析推文情绪失败: {e}")
            return {
                "pos": 0.0,
                "neg": 0.0,
                "neu": 1.0,
                "compound": 0.0,
                "label": "unknown"
            }
    
    def extract_coin_symbols(self, text):
        \"\"\"从推文中提取币种符号
        
        Args:
            text: 推文文本
        
        Returns:
            list: 币种符号列表
        \"\"\"
        # 常见币种符号
        common_symbols = [
            "BTC", "ETH", "USDT", "BNB", "XRP", "ADA", "SOL", "DOGE", "DOT", "SHIB",
            "AVAX", "MATIC", "LTC", "UNI", "LINK", "XLM", "ATOM", "XMR", "ALGO", "FIL"
        ]
        
        # 使用正则表达式匹配币种符号
        # 1. $符号后跟大写字母，如$BTC
        # 2. 纯大写字母，如BTC
        # 3. 常见币种符号
        
        symbols = []
        
        # 匹配$符号后跟大写字母
        dollar_pattern = r'\$([A-Z]{2,10})'
        dollar_matches = re.findall(dollar_pattern, text)
        symbols.extend(dollar_matches)
        
        # 匹配纯大写字母（至少3个字母）
        upper_pattern = r'\b([A-Z]{3,10})\b'
        upper_matches = re.findall(upper_pattern, text)
        symbols.extend(upper_matches)
        
        # 添加常见币种符号
        for symbol in common_symbols:
            if symbol in text and symbol not in symbols:
                symbols.append(symbol)
        
        # 去重
        symbols = list(set(symbols))
        
        return symbols
    
    def is_important_tweet(self, tweet):
        \"\"\"判断推文是否重要
        
        Args:
            tweet: 推文信息
        
        Returns:
            bool: 是否重要
        \"\"\"
        # 提取币种符号
        symbols = self.extract_coin_symbols(tweet["text"])
        
        # 分析情绪
        sentiment = self.analyze_tweet_sentiment(tweet["text"])
        
        # 判断重要性
        # 1. 包含币种符号
        # 2. 情绪明显（非中性）
        # 3. 转发或点赞数量较多
        
        has_symbols = len(symbols) > 0
        is_emotional = sentiment["label"] != "neutral"
        is_popular = tweet["retweet_count"] > 50 or tweet["like_count"] > 100
        
        return has_symbols and (is_emotional or is_popular)
    
    def format_tweet_message(self, tweet, symbols=None, sentiment=None):
        \"\"\"格式化推文消息
        
        Args:
            tweet: 推文信息
            symbols: 币种符号列表
            sentiment: 情绪分析结果
        
        Returns:
            str: 格式化后的消息
        \"\"\"
        if symbols is None:
            symbols = self.extract_coin_symbols(tweet["text"])
        
        if sentiment is None:
            sentiment = self.analyze_tweet_sentiment(tweet["text"])
        
        # 构建消息
        message = f"🔔 *Twitter重要推文*\\n\\n"
        
        # 添加用户信息
        if "user" in tweet:
            message += f"👤 *用户:* @{tweet['user']}\\n"
        
        # 添加推文内容
        message += f"📝 *内容:* {tweet['text']}\\n\\n"
        
        # 添加币种信息
        if symbols:
            message += f"💰 *相关币种:* {', '.join(symbols)}\\n"
        
        # 添加情绪分析
        sentiment_emoji = "😐"
        if sentiment["label"] == "positive":
            sentiment_emoji = "😀"
        elif sentiment["label"] == "negative":
            sentiment_emoji = "😟"
        
        message += f"{sentiment_emoji} *情绪分析:* {sentiment['label'].capitalize()} (得分: {sentiment['compound']:.2f})\\n"
        
        # 添加统计信息
        message += f"🔄 *转发:* {tweet['retweet_count']}  ❤️ *点赞:* {tweet['like_count']}\\n"
        
        # 添加时间信息
        created_at = tweet["created_at"]
        if isinstance(created_at, str):
            try:
                created_at = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
            except:
                try:
                    created_at = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
                except:
                    pass
        
        if isinstance(created_at, datetime):
            message += f"🕒 *发布时间:* {created_at.strftime('%Y-%m-%d %H:%M:%S')}\\n"
        
        # 添加链接
        message += f"🔗 *链接:* https://twitter.com/i/web/status/{tweet['id']}"
        
        return message
    
    def monitor_twitter(self):
        \"\"\"监控Twitter\"\"\"
        if not self.config["twitter"]["enabled"]:
            logger.info("Twitter监控未启用")
            return []
        
        if not self.api and not self.client:
            logger.error("Twitter API未初始化，无法监控")
            return []
        
        # 检查是否需要更新
        now = int(time.time())
        if now - self.last_update < self.config["twitter"]["update_interval"]:
            logger.info(f"Twitter监控更新间隔未到，跳过更新 (剩余 {self.config['twitter']['update_interval'] - (now - self.last_update)} 秒)")
            return []
        
        logger.info("开始监控Twitter...")
        
        important_tweets = []
        
        # 监控关键词
        for keyword in self.config["twitter"]["monitor_keywords"]:
            logger.info(f"监控关键词: {keyword}")
            
            tweets = self.search_tweets(
                query=keyword,
                count=self.config["twitter"]["max_tweets_per_request"]
            )
            
            for tweet in tweets:
                # 检查是否已处理过
                if tweet["id"] in self.tweet_cache:
                    continue
                
                # 判断是否重要
                if self.is_important_tweet(tweet):
                    important_tweets.append(tweet)
                
                # 添加到缓存
                self.tweet_cache[tweet["id"]] = tweet
        
        # 监控账号
        for account in self.config["twitter"]["monitor_accounts"]:
            logger.info(f"监控账号: {account}")
            
            tweets = self.get_user_tweets(
                username=account,
                count=self.config["twitter"]["max_tweets_per_request"]
            )
            
            for tweet in tweets:
                # 检查是否已处理过
                if tweet["id"] in self.tweet_cache:
                    continue
                
                # 判断是否重要
                if self.is_important_tweet(tweet):
                    important_tweets.append(tweet)
                
                # 添加到缓存
                self.tweet_cache[tweet["id"]] = tweet
        
        # 更新时间
        self.last_update = now
        
        # 清理缓存
        self.clean_cache()
        
        logger.info(f"Twitter监控完成，发现 {len(important_tweets)} 条重要推文")
        return important_tweets
    
    def clean_cache(self):
        \"\"\"清理缓存\"\"\"
        # 保留最近7天的推文
        cutoff_time = int(time.time()) - 7 * 24 * 60 * 60
        
        # 清理缓存
        for tweet_id in list(self.tweet_cache.keys()):
            tweet = self.tweet_cache[tweet_id]
            created_at = tweet["created_at"]
            
            if isinstance(created_at, str):
                try:
                    created_at = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                except:
                    try:
                        created_at = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
                    except:
                        continue
            
            if isinstance(created_at, datetime):
                if created_at.timestamp() < cutoff_time:
                    del self.tweet_cache[tweet_id]
        
        logger.info(f"缓存清理完成，剩余 {len(self.tweet_cache)} 条推文")

def main():
    \"\"\"主函数\"\"\"
    parser = argparse.ArgumentParser(description="Gate.io Twitter监控模块")
    parser.add_argument("--config", help="配置文件路径")
    parser.add_argument("--once", action="store_true", help="只运行一次")
    args = parser.parse_args()
    
    # 创建监控实例
    monitor = TwitterMonitor(args.config)
    
    # 运行监控
    if args.once:
        important_tweets = monitor.monitor_twitter()
        
        for tweet in important_tweets:
            message = monitor.format_tweet_message(tweet)
            print(message)
            print("=" * 80)
    else:
        try:
            while True:
                important_tweets = monitor.monitor_twitter()
                
                for tweet in important_tweets:
                    message = monitor.format_tweet_message(tweet)
                    print(message)
                    print("=" * 80)
                
                # 等待下一次更新
                time.sleep(monitor.config["twitter"]["update_interval"])
        
        except KeyboardInterrupt:
            logger.info("监控被用户中断")

if __name__ == "__main__":
    main()
""")
            
            print_success(f"Twitter模块已创建: {module_file}")
            return True
        
        except Exception as e:
            print_error(f"创建Twitter模块失败: {e}")
            return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Twitter API一键设置工具")
    parser.add_argument("--api_key", help="Twitter API Key")
    parser.add_argument("--api_secret", help="Twitter API Secret")
    parser.add_argument("--access_token", help="Twitter Access Token")
    parser.add_argument("--access_token_secret", help="Twitter Access Token Secret")
    parser.add_argument("--bearer_token", help="Twitter Bearer Token")
    args = parser.parse_args()
    
    # 创建Twitter设置实例
    twitter_setup = TwitterSetup()
    
    # 设置API凭据
    if args.api_key and args.api_secret:
        twitter_setup.api_key = args.api_key
        twitter_setup.api_secret = args.api_secret
        twitter_setup.access_token = args.access_token or ""
        twitter_setup.access_token_secret = args.access_token_secret or ""
        twitter_setup.bearer_token = args.bearer_token or ""
    else:
        # 输入API凭据
        if not twitter_setup.input_credentials():
            print_error("API凭据不完整，无法继续")
            return
    
    # 安装依赖
    twitter_setup.install_dependencies()
    
    # 验证API凭据
    if not twitter_setup.verify_credentials():
        print_error("API凭据验证失败，无法继续")
        return
    
    # 保存配置
    if not twitter_setup.save_config():
        print_error("保存配置失败，无法继续")
        return
    
    # 集成到监控系统
    twitter_setup.integrate_with_monitor()
    
    # 创建Twitter模块
    twitter_setup.create_twitter_module()
    
    print_success("Twitter API设置完成")

if __name__ == "__main__":
    main()
