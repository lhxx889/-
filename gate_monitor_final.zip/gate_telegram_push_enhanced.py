#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 增强版Telegram推送模块
功能：
1. 支持多账号推送，降低单一账号风险
2. 增强消息格式化，支持HTML和Markdown
3. 添加定时摘要推送功能
4. 支持互动式命令响应
"""

import os
import json
import time
import logging
import random
import threading
import requests
from datetime import datetime, timedelta
from collections import defaultdict

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("telegram_push_enhanced.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_telegram_push_enhanced")

class TelegramPush:
    """Gate.io增强版Telegram推送类"""
    
    def __init__(self, config_file=None, config=None):
        """初始化Telegram推送
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        # 默认配置
        self.config = {
            "accounts": [
                {
                    "bot_token": "YOUR_BOT_TOKEN_1_HERE",
                    "chat_id": "YOUR_CHAT_ID_1_HERE",
                    "message_thread_id": None,
                    "enabled": True,
                    "last_used": 0,
                    "error_count": 0
                }
            ],
            "proxy": None,  # 格式: "http://user:pass@host:port" 或 "socks5://user:pass@host:port"
            "rotation_strategy": "round_robin",  # round_robin, random, failover
            "max_errors": 3,  # 最大错误次数，超过后禁用账号
            "error_reset_time": 86400,  # 错误计数重置时间（秒）
            "message_format": "html",  # html, markdown
            "disable_web_page_preview": True,
            "disable_notification": False,
            "retry_count": 3,  # 发送失败重试次数
            "retry_delay": 2,  # 重试延迟（秒）
            "summary": {
                "enabled": True,
                "interval": 86400,  # 摘要间隔（秒），默认1天
                "max_items": 10,  # 每类最大项目数
                "last_sent": 0  # 上次发送时间
            },
            "interactive": {
                "enabled": True,
                "commands": {
                    "/help": "显示帮助信息",
                    "/status": "显示系统状态",
                    "/price": "查询币种价格",
                    "/alert": "设置价格预警"
                },
                "last_update_id": 0  # 上次处理的更新ID
            },
            "test_mode": False  # 测试模式，不实际发送消息
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.update_config(self.config, config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(self.config, user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 验证账号配置
        self.validate_accounts()
        
        # 初始化状态
        self.current_account_index = 0
        self.message_queue = []
        self.summary_data = defaultdict(list)
        self.lock = threading.Lock()
        
        # 启动后台线程
        if self.config["interactive"]["enabled"]:
            self.start_background_threads()
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def validate_accounts(self):
        """验证账号配置"""
        valid_accounts = []
        
        for account in self.config["accounts"]:
            if account.get("bot_token") and account.get("bot_token") != "YOUR_BOT_TOKEN_1_HERE" and \
               account.get("chat_id") and account.get("chat_id") != "YOUR_CHAT_ID_1_HERE" and \
               account.get("enabled", True):
                valid_accounts.append(account)
        
        self.config["accounts"] = valid_accounts
        logger.info(f"已验证 {len(valid_accounts)} 个有效Telegram账号")
    
    def get_next_account(self):
        """获取下一个账号"""
        with self.lock:
            if not self.config["accounts"]:
                logger.error("没有可用的Telegram账号")
                return None
            
            strategy = self.config["rotation_strategy"]
            
            if strategy == "round_robin":
                # 轮询策略
                for _ in range(len(self.config["accounts"])):
                    self.current_account_index = (self.current_account_index + 1) % len(self.config["accounts"])
                    account = self.config["accounts"][self.current_account_index]
                    
                    if account.get("enabled", True) and account.get("error_count", 0) < self.config["max_errors"]:
                        return account
            
            elif strategy == "random":
                # 随机策略
                enabled_accounts = [a for a in self.config["accounts"] if a.get("enabled", True) and a.get("error_count", 0) < self.config["max_errors"]]
                if enabled_accounts:
                    return random.choice(enabled_accounts)
            
            elif strategy == "failover":
                # 故障转移策略
                sorted_accounts = sorted(self.config["accounts"], key=lambda a: a.get("error_count", 0))
                for account in sorted_accounts:
                    if account.get("enabled", True) and account.get("error_count", 0) < self.config["max_errors"]:
                        return account
            
            # 如果所有账号都不可用，尝试重置错误计数
            now = int(time.time())
            for account in self.config["accounts"]:
                if account.get("last_error", 0) + self.config["error_reset_time"] < now:
                    account["error_count"] = 0
                    if account.get("enabled", True):
                        return account
            
            logger.error("所有Telegram账号都不可用")
            return None
    
    def mark_account_error(self, account):
        """标记账号错误"""
        if not account:
            return
        
        with self.lock:
            account["error_count"] = account.get("error_count", 0) + 1
            account["last_error"] = int(time.time())
            
            if account["error_count"] >= self.config["max_errors"]:
                logger.warning(f"账号 {account.get('bot_token', '')[:10]}... 错误次数过多，已禁用")
                account["enabled"] = False
    
    def mark_account_success(self, account):
        """标记账号成功"""
        if not account:
            return
        
        with self.lock:
            account["last_used"] = int(time.time())
            account["error_count"] = 0
    
    def send_message(self, text, title=None, parse_mode=None, disable_web_page_preview=None, disable_notification=None):
        """发送消息
        
        Args:
            text: 消息内容
            title: 消息标题，如果提供则会添加到消息开头
            parse_mode: 解析模式，html或markdown
            disable_web_page_preview: 是否禁用网页预览
            disable_notification: 是否禁用通知
        
        Returns:
            bool: 是否发送成功
        """
        if self.config["test_mode"]:
            logger.info(f"测试模式，不实际发送消息: {title if title else text[:30]}...")
            return True
        
        # 准备消息内容
        if title:
            if parse_mode == "html" or (parse_mode is None and self.config["message_format"] == "html"):
                full_text = f"<b>{title}</b>\n\n{text}"
            else:
                full_text = f"*{title}*\n\n{text}"
        else:
            full_text = text
        
        # 获取账号
        account = self.get_next_account()
        if not account:
            logger.error("没有可用的Telegram账号，无法发送消息")
            return False
        
        # 准备请求参数
        bot_token = account["bot_token"]
        chat_id = account["chat_id"]
        message_thread_id = account.get("message_thread_id")
        
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        
        params = {
            "chat_id": chat_id,
            "text": full_text,
            "parse_mode": parse_mode if parse_mode else self.config["message_format"],
            "disable_web_page_preview": disable_web_page_preview if disable_web_page_preview is not None else self.config["disable_web_page_preview"],
            "disable_notification": disable_notification if disable_notification is not None else self.config["disable_notification"]
        }
        
        if message_thread_id:
            params["message_thread_id"] = message_thread_id
        
        # 准备代理
        proxies = None
        if self.config["proxy"]:
            proxies = {
                "http": self.config["proxy"],
                "https": self.config["proxy"]
            }
        
        # 发送请求
        retry_count = 0
        while retry_count <= self.config["retry_count"]:
            try:
                response = requests.post(url, json=params, proxies=proxies, timeout=10)
                response.raise_for_status()
                
                # 标记账号成功
                self.mark_account_success(account)
                
                logger.info(f"消息发送成功: {title if title else text[:30]}...")
                return True
            
            except Exception as e:
                retry_count += 1
                logger.warning(f"发送消息失败 ({retry_count}/{self.config['retry_count']}): {e}")
                
                if retry_count <= self.config["retry_count"]:
                    time.sleep(self.config["retry_delay"])
                else:
                    # 标记账号错误
                    self.mark_account_error(account)
                    
                    logger.error(f"发送消息最终失败: {e}")
                    return False
    
    def send_photo(self, photo, caption=None, title=None, parse_mode=None):
        """发送图片
        
        Args:
            photo: 图片文件路径或URL
            caption: 图片说明
            title: 消息标题，如果提供则会添加到说明开头
            parse_mode: 解析模式，html或markdown
        
        Returns:
            bool: 是否发送成功
        """
        if self.config["test_mode"]:
            logger.info(f"测试模式，不实际发送图片: {photo}")
            return True
        
        # 准备说明内容
        if title and caption:
            if parse_mode == "html" or (parse_mode is None and self.config["message_format"] == "html"):
                full_caption = f"<b>{title}</b>\n\n{caption}"
            else:
                full_caption = f"*{title}*\n\n{caption}"
        elif title:
            if parse_mode == "html" or (parse_mode is None and self.config["message_format"] == "html"):
                full_caption = f"<b>{title}</b>"
            else:
                full_caption = f"*{title}*"
        else:
            full_caption = caption
        
        # 获取账号
        account = self.get_next_account()
        if not account:
            logger.error("没有可用的Telegram账号，无法发送图片")
            return False
        
        # 准备请求参数
        bot_token = account["bot_token"]
        chat_id = account["chat_id"]
        message_thread_id = account.get("message_thread_id")
        
        url = f"https://api.telegram.org/bot{bot_token}/sendPhoto"
        
        params = {
            "chat_id": chat_id
        }
        
        if full_caption:
            params["caption"] = full_caption
            params["parse_mode"] = parse_mode if parse_mode else self.config["message_format"]
        
        if message_thread_id:
            params["message_thread_id"] = message_thread_id
        
        # 准备代理
        proxies = None
        if self.config["proxy"]:
            proxies = {
                "http": self.config["proxy"],
                "https": self.config["proxy"]
            }
        
        # 发送请求
        retry_count = 0
        while retry_count <= self.config["retry_count"]:
            try:
                # 判断photo是URL还是文件路径
                if photo.startswith(('http://', 'https://')):
                    params["photo"] = photo
                    response = requests.post(url, json=params, proxies=proxies, timeout=30)
                else:
                    with open(photo, 'rb') as f:
                        files = {'photo': f}
                        response = requests.post(url, data=params, files=files, proxies=proxies, timeout=30)
                
                response.raise_for_status()
                
                # 标记账号成功
                self.mark_account_success(account)
                
                logger.info(f"图片发送成功: {photo}")
                return True
            
            except Exception as e:
                retry_count += 1
                logger.warning(f"发送图片失败 ({retry_count}/{self.config['retry_count']}): {e}")
                
                if retry_count <= self.config["retry_count"]:
                    time.sleep(self.config["retry_delay"])
                else:
                    # 标记账号错误
                    self.mark_account_error(account)
                    
                    logger.error(f"发送图片最终失败: {e}")
                    return False
    
    def add_to_summary(self, category, item):
        """添加项目到摘要
        
        Args:
            category: 项目类别
            item: 项目内容
        """
        if not self.config["summary"]["enabled"]:
            return
        
        with self.lock:
            # 限制每类项目数量
            max_items = self.config["summary"]["max_items"]
            if len(self.summary_data[category]) >= max_items:
                self.summary_data[category] = self.summary_data[category][:max_items-1]
            
            # 添加新项目
            self.summary_data[category].append(item)
    
    def send_summary(self, force=False):
        """发送摘要
        
        Args:
            force: 是否强制发送，忽略时间间隔
        
        Returns:
            bool: 是否发送成功
        """
        if not self.config["summary"]["enabled"]:
            return False
        
        now = int(time.time())
        interval = self.config["summary"]["interval"]
        last_sent = self.config["summary"]["last_sent"]
        
        # 检查是否需要发送
        if not force and now - last_sent < interval:
            return False
        
        with self.lock:
            # 如果没有数据，不发送
            if not self.summary_data:
                return False
            
            # 准备摘要内容
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if self.config["message_format"] == "html":
                summary = f"📋 <b>Gate.io 监控摘要 - {now_str}</b>\n\n"
                
                for category, items in self.summary_data.items():
                    if items:
                        summary += f"<b>{category}:</b>\n"
                        for item in items:
                            summary += f"• {item}\n"
                        summary += "\n"
            else:
                summary = f"📋 *Gate.io 监控摘要 - {now_str}*\n\n"
                
                for category, items in self.summary_data.items():
                    if items:
                        summary += f"*{category}:*\n"
                        for item in items:
                            summary += f"• {item}\n"
                        summary += "\n"
            
            # 发送摘要
            result = self.send_message(summary)
            
            if result:
                # 更新发送时间
                self.config["summary"]["last_sent"] = now
                # 清空摘要数据
                self.summary_data = defaultdict(list)
            
            return result
    
    def start_background_threads(self):
        """启动后台线程"""
        # 启动消息处理线程
        threading.Thread(target=self.process_updates_thread, daemon=True).start()
        logger.info("已启动消息处理线程")
        
        # 启动摘要发送线程
        if self.config["summary"]["enabled"]:
            threading.Thread(target=self.summary_thread, daemon=True).start()
            logger.info("已启动摘要发送线程")
    
    def process_updates_thread(self):
        """消息处理线程"""
        while True:
            try:
                self.process_updates()
                time.sleep(5)  # 每5秒检查一次
            except Exception as e:
                logger.error(f"处理消息更新异常: {e}")
                time.sleep(30)  # 出错后等待30秒
    
    def summary_thread(self):
        """摘要发送线程"""
        while True:
            try:
                self.send_summary()
                time.sleep(60)  # 每分钟检查一次
            except Exception as e:
                logger.error(f"发送摘要异常: {e}")
                time.sleep(300)  # 出错后等待5分钟
    
    def process_updates(self):
        """处理消息更新"""
        if not self.config["interactive"]["enabled"]:
            return
        
        # 获取账号
        account = self.get_next_account()
        if not account:
            logger.error("没有可用的Telegram账号，无法处理消息更新")
            return
        
        # 准备请求参数
        bot_token = account["bot_token"]
        last_update_id = self.config["interactive"]["last_update_id"]
        
        url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
        
        params = {
            "offset": last_update_id + 1,
            "timeout": 30
        }
        
        # 准备代理
        proxies = None
        if self.config["proxy"]:
            proxies = {
                "http": self.config["proxy"],
                "https": self.config["proxy"]
            }
        
        try:
            response = requests.post(url, json=params, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data.get("ok") and data.get("result"):
                updates = data["result"]
                
                for update in updates:
                    update_id = update.get("update_id", 0)
                    
                    # 更新最后处理的ID
                    if update_id > last_update_id:
                        self.config["interactive"]["last_update_id"] = update_id
                    
                    # 处理消息
                    if "message" in update and "text" in update["message"]:
                        message = update["message"]
                        chat_id = message.get("chat", {}).get("id")
                        text = message.get("text", "")
                        
                        # 只处理来自配置的聊天ID的消息
                        if str(chat_id) == str(account["chat_id"]):
                            self.handle_command(text, account)
        
        except Exception as e:
            logger.error(f"获取消息更新失败: {e}")
    
    def handle_command(self, text, account):
        """处理命令
        
        Args:
            text: 命令文本
            account: 账号信息
        """
        if not text.startswith("/"):
            return
        
        command = text.split()[0].lower()
        args = text.split()[1:] if len(text.split()) > 1 else []
        
        commands = self.config["interactive"]["commands"]
        
        if command == "/help":
            # 帮助命令
            help_text = "可用命令:\n\n"
            for cmd, desc in commands.items():
                help_text += f"{cmd} - {desc}\n"
            
            self.send_message(help_text, "帮助信息")
        
        elif command == "/status":
            # 状态命令
            status_text = "系统状态:\n\n"
            status_text += f"• 账号数量: {len(self.config['accounts'])}\n"
            status_text += f"• 当前账号: {account['bot_token'][:10]}...\n"
            status_text += f"• 轮换策略: {self.config['rotation_strategy']}\n"
            status_text += f"• 摘要功能: {'启用' if self.config['summary']['enabled'] else '禁用'}\n"
            
            self.send_message(status_text, "系统状态")
        
        elif command == "/price" and len(args) > 0:
            # 价格查询命令
            symbol = args[0].upper()
            self.send_message(f"正在查询 {symbol} 的价格信息...", "价格查询")
            
            # 这里应该调用币种信息模块获取价格
            # 由于是示例，这里只返回一个模拟消息
            price_text = f"{symbol} 价格信息:\n\n"
            price_text += "• 当前价格: 模拟数据\n"
            price_text += "• 24h变动: 模拟数据\n"
            price_text += "• 24h成交量: 模拟数据\n"
            
            self.send_message(price_text, f"{symbol} 价格信息")
        
        elif command == "/alert" and len(args) >= 3:
            # 设置预警命令
            try:
                symbol = args[0].upper()
                condition = args[1]  # > 或 <
                price = float(args[2])
                
                alert_text = f"已设置 {symbol} 价格预警:\n\n"
                alert_text += f"当价格 {condition} {price} 时通知您"
                
                self.send_message(alert_text, "价格预警设置")
                
                # 这里应该调用预警模块设置预警
                # 由于是示例，这里只返回一个确认消息
            except Exception as e:
                self.send_message(f"设置预警失败: {e}\n\n正确格式: /alert SYMBOL > PRICE", "错误")
        
        else:
            # 未知命令
            self.send_message(f"未知命令: {command}\n\n发送 /help 查看可用命令", "错误")

if __name__ == "__main__":
    # 创建Telegram推送实例
    telegram = TelegramPush()
    
    # 测试发送消息
    telegram.send_message("这是一条测试消息", "测试标题")
    
    # 测试添加摘要
    telegram.add_to_summary("价格预警", "BTC 价格上涨 5%")
    telegram.add_to_summary("新币上线", "Gate.io 已上线 XYZ 币")
    
    # 测试发送摘要
    telegram.send_summary(force=True)
