# Gate.io 高级监控系统

## 项目概述

Gate.io 高级监控系统是一个全面的加密货币监控解决方案，专为监控 Gate.io 交易所的价格变动、公告和新上币信息而设计。系统采用模块化架构，支持多种高级功能，包括币种详细信息采集、智能预警分析、代理IP轮换和多账号Telegram推送等。

## 系统架构

系统由以下核心模块组成：

1. **增强版币种信息采集模块** (`enhanced_coin_info.py`)
   - 改进的币种符号提取算法
   - 全面的币种元数据采集
   - 历史价格数据分析
   - 相似币种对比分析
   - 链上数据分析

2. **智能分析与预警系统** (`smart_alerts.py`)
   - 基于机器学习的异常价格波动检测
   - 交易量突增分析
   - 市场情绪分析
   - 自定义复合条件预警规则

3. **代理管理与反爬虫模块** (`proxy_manager.py`)
   - v2 box代理集成
   - IP轮换与负载均衡
   - Cookie管理和会话保持
   - 用户行为模拟
   - 增强的公告爬虫

4. **增强版Telegram推送模块** (`gate_telegram_push_enhanced.py`)
   - 多账号推送，降低单一账号风险
   - 增强消息格式化，支持HTML和Markdown
   - 定时摘要推送功能
   - 互动式命令响应

5. **系统集成与测试模块** (`integrated_test.py`)
   - 全系统集成测试
   - 性能和稳定性验证
   - 自动化测试报告生成

## 安装指南

### 系统要求

- Python 3.8+
- 网络连接
- v2 box代理服务（可选，用于反爬虫）
- Telegram Bot API Token（用于推送通知）

### 依赖安装

```bash
pip install requests python-telegram-bot scikit-learn nltk fake-useragent beautifulsoup4
```

### 初始配置

1. 创建配置文件：

```bash
python create_config_advanced.py --all
```

2. 编辑生成的配置文件：
   - `config_advanced.json`: 主配置文件
   - `telegram_config.json`: Telegram推送配置
   - `proxy_config.json`: 代理服务配置

## 使用指南

### 基本使用

运行监控系统（单次执行）：

```bash
python gate_monitor_advanced.py --once
```

持续监控模式：

```bash
python gate_monitor_advanced.py
```

### 定时任务设置

由于系统不支持内置的定时任务，请使用外部定时服务（如crontab或云函数）每小时触发一次：

```bash
# Linux Crontab示例 - 每小时执行一次
0 * * * * cd /path/to/gate_monitor && python gate_monitor_advanced.py --once
```

### 自定义监控

编辑 `config_advanced.json` 文件可自定义以下内容：

- 监控的币种列表
- 价格变动阈值
- 交易量监控参数
- 公告关键词过滤
- 预警规则配置

## 功能详解

### 1. 增强版币种信息采集

该模块大幅提升了币种信息的全面性和分析深度：

- **改进的币种符号提取算法**：使用多种正则表达式模式匹配策略，大幅提高从公告标题中提取币种符号的准确率
- **增强的币种元数据采集**：获取团队信息、发行时间、总供应量等扩展数据
- **历史价格数据分析**：计算移动平均线、RSI、MACD、布林带等技术指标，识别支撑位和阻力位
- **相似币种对比分析**：基于市值、交易量、价格变动等特征计算币种相似度
- **链上数据分析**：支持以太坊和币安智能链的链上数据获取，收集持币地址数量、代币转账频率等数据

### 2. 智能分析与预警系统

该模块使用先进的分析技术，提供深入的市场洞察：

- **基于机器学习的异常检测**：使用隔离森林算法检测异常价格模式
- **交易量突增分析**：智能检测交易量相对历史水平的突增情况
- **市场情绪分析**：基于NLTK的VADER情感分析引擎，对项目描述和公告内容进行情绪评分
- **自定义复合条件预警**：灵活的规则配置系统，支持多种条件组合
- **每日市场摘要**：自动生成市场整体情况摘要，包含涨幅/跌幅/交易量排名

### 3. 代理管理与反爬虫

该模块大大提高了公告抓取的稳定性和可靠性：

- **v2 box代理集成**：完整支持v2 box代理系统，通过API接口获取和管理出站节点
- **IP轮换与负载均衡**：智能代理轮换机制，按请求次数或时间间隔自动切换
- **Cookie管理和会话保持**：完整的Cookie持久化存储和加载，按域名管理Cookie
- **用户行为模拟**：随机User-Agent轮换，随机访问延迟，真实浏览模式
- **增强的公告爬虫**：多页面抓取支持，智能缓存机制，详细内容解析

### 4. 增强版Telegram推送

该模块提供了更可靠和功能丰富的通知系统：

- **多账号推送**：支持配置多个Telegram Bot账号，实现账号轮换推送
- **增强消息格式化**：支持HTML和Markdown格式，美观的消息布局
- **定时摘要推送**：自动汇总一段时间内的重要信息
- **互动式命令响应**：支持通过消息回复执行简单命令，如查询价格、设置预警等

## 高级配置

### 代理配置

编辑 `proxy_config.json` 文件：

```json
{
  "proxy": {
    "enabled": true,
    "type": "v2box",
    "v2box": {
      "api_url": "http://127.0.0.1:8080/api/v1",
      "auth_token": "YOUR_AUTH_TOKEN",
      "outbounds": []
    },
    "rotation_interval": 10
  }
}
```

### Telegram多账号配置

编辑 `telegram_config.json` 文件：

```json
{
  "accounts": [
    {
      "bot_token": "BOT_TOKEN_1",
      "chat_id": "CHAT_ID_1",
      "enabled": true
    },
    {
      "bot_token": "BOT_TOKEN_2",
      "chat_id": "CHAT_ID_2",
      "enabled": true
    }
  ],
  "rotation_strategy": "round_robin"
}
```

### 自定义预警规则

编辑 `rules_config.json` 文件：

```json
{
  "rules": [
    {
      "name": "价格突破",
      "conditions": [
        {
          "field": "price_change_percent",
          "operator": ">",
          "value": 5
        }
      ],
      "enabled": true
    },
    {
      "name": "交易量突增",
      "conditions": [
        {
          "field": "volume_change_percent",
          "operator": ">",
          "value": 100
        }
      ],
      "enabled": true
    }
  ]
}
```

## 系统测试

运行集成测试以验证系统各模块的协同工作能力：

```bash
python integrated_test.py
```

测试报告将保存在 `integration_test_report.txt` 文件中。

## 注意事项

1. 首次运行时会记录当前状态作为基准，不会产生预警
2. 所有数据均直接从Gate.io官方API和网站获取，不使用第三方数据源
3. 在测试过程中发现Gate.io公告页面可能会返回403错误，这可能是由于网站的反爬虫机制，实际部署时可能需要调整请求头或使用代理
4. 使用v2 box代理服务需要确保服务已正确配置并运行
5. Telegram推送功能需要有效的Bot Token和Chat ID

## 后续优化方向

1. 进一步优化公告页面的抓取，解决可能的403错误问题
2. 增强币种信息的解析准确性，特别是从公告标题中提取币种符号
3. 添加更多交易所支持，如Binance、OKX、Huobi等
4. 开发Web管理界面，便于配置管理和数据可视化
5. 实现数据持久化存储，支持历史数据查询和分析
6. 添加更多推送渠道，如Discord、Slack、邮件等

## 故障排除

### 常见问题

1. **无法获取公告**
   - 检查网络连接
   - 确认代理配置是否正确
   - 尝试调整请求头或使用不同的代理

2. **Telegram推送失败**
   - 验证Bot Token和Chat ID是否正确
   - 确认Bot是否已被启动
   - 检查网络连接和代理设置

3. **预警不触发**
   - 检查预警规则配置
   - 确认监控的币种是否正确
   - 首次运行不会触发预警，需要至少两次运行才能比较变化

### 日志文件

系统会生成以下日志文件，可用于故障排查：

- `gate_monitor_advanced.log`: 主程序日志
- `enhanced_coin_info.log`: 币种信息采集日志
- `smart_alerts.log`: 智能预警系统日志
- `proxy_manager.log`: 代理管理日志
- `telegram_push_enhanced.log`: Telegram推送日志
- `integrated_test.log`: 集成测试日志

## 联系与支持

如有任何问题或需要进一步的支持，请联系系统开发者。
