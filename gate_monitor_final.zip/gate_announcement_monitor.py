#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 公告监控模块
功能：抓取Gate.io交易所的公告和新上币公告，监控公告更新
"""

import os
import json
import time
import hashlib
import logging
import requests
from datetime import datetime
from bs4 import BeautifulSoup

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("announcement_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_announcement_monitor")

class GateAnnouncementMonitor:
    """Gate.io公告监控类"""
    
    def __init__(self, config_file=None, config=None):
        """初始化公告监控器
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        }
        self.announcement_url = "https://www.gate.io/zh/announcements"
        self.newlisted_url = "https://www.gate.io/zh/announcements/newlisted"
        self.cache_file = "announcement_cache.json"
        self.last_announcements = {}  # 存储上次检查的公告
        self.last_newlisted = {}  # 存储上次检查的新上币公告
        
        self.config = {
            "keywords": ["上线", "上架", "首发", "新增", "开放", "交易", "上市"],  # 关注的关键词
            "max_announcements": 20,  # 每次检查的公告数量
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.config.update(config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.config.update(user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 加载缓存的公告数据
        self.load_cache()
    
    def load_cache(self):
        """加载缓存的公告数据"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                    self.last_announcements = cache_data.get('announcements', {})
                    self.last_newlisted = cache_data.get('newlisted', {})
                logger.info(f"已加载公告缓存: {len(self.last_announcements)} 条普通公告, {len(self.last_newlisted)} 条新上币公告")
            except Exception as e:
                logger.error(f"加载公告缓存失败: {e}")
    
    def save_cache(self):
        """保存公告数据到缓存"""
        try:
            cache_data = {
                'announcements': self.last_announcements,
                'newlisted': self.last_newlisted,
                'updated_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
            logger.info("公告缓存已更新")
        except Exception as e:
            logger.error(f"保存公告缓存失败: {e}")
    
    def fetch_page(self, url):
        """获取页面内容"""
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            logger.error(f"获取页面失败 {url}: {e}")
            return None
    
    def parse_announcements(self, html_content):
        """解析普通公告页面"""
        if not html_content:
            return {}
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            announcements = {}
            
            # 查找公告列表项
            announcement_items = soup.select('a[href*="/announcements/article/"]')
            
            for item in announcement_items[:self.config['max_announcements']]:
                try:
                    # 获取公告标题
                    title = item.text.strip()
                    if not title:
                        continue
                    
                    # 获取公告链接
                    link = item.get('href')
                    if link and not link.startswith('http'):
                        link = f"https://www.gate.io{link}"
                    
                    # 生成公告ID
                    announcement_id = hashlib.md5(title.encode()).hexdigest()
                    
                    # 存储公告信息
                    announcements[announcement_id] = {
                        'title': title,
                        'link': link,
                        'timestamp': int(time.time()),
                        'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                except Exception as e:
                    logger.error(f"解析公告项失败: {e}")
                    continue
            
            logger.info(f"成功解析 {len(announcements)} 条公告")
            return announcements
        
        except Exception as e:
            logger.error(f"解析公告页面失败: {e}")
            return {}
    
    def parse_newlisted(self, html_content):
        """解析新上币公告页面"""
        if not html_content:
            return {}
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            newlisted = {}
            
            # 查找新上币公告列表项
            newlisted_items = soup.select('a[href*="/announcements/article/"]')
            
            for item in newlisted_items[:self.config['max_announcements']]:
                try:
                    # 获取公告标题
                    title = item.text.strip()
                    if not title:
                        continue
                    
                    # 获取公告链接
                    link = item.get('href')
                    if link and not link.startswith('http'):
                        link = f"https://www.gate.io{link}"
                    
                    # 生成公告ID
                    announcement_id = hashlib.md5(title.encode()).hexdigest()
                    
                    # 存储公告信息
                    newlisted[announcement_id] = {
                        'title': title,
                        'link': link,
                        'timestamp': int(time.time()),
                        'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                except Exception as e:
                    logger.error(f"解析新上币公告项失败: {e}")
                    continue
            
            logger.info(f"成功解析 {len(newlisted)} 条新上币公告")
            return newlisted
        
        except Exception as e:
            logger.error(f"解析新上币公告页面失败: {e}")
            return {}
    
    def find_new_announcements(self, current, last):
        """查找新的公告"""
        new_items = {}
        for item_id, item_data in current.items():
            if item_id not in last:
                new_items[item_id] = item_data
        return new_items
    
    def filter_announcements_by_keywords(self, announcements):
        """根据关键词过滤公告"""
        filtered = {}
        keywords = self.config['keywords']
        
        for item_id, item_data in announcements.items():
            title = item_data['title']
            if any(keyword in title for keyword in keywords):
                filtered[item_id] = item_data
        
        return filtered
    
    def run_announcement_check(self):
        """执行公告检查"""
        logger.info("开始执行公告监控检查...")
        
        # 获取普通公告页面
        announcement_html = self.fetch_page(self.announcement_url)
        current_announcements = self.parse_announcements(announcement_html)
        
        # 获取新上币公告页面
        newlisted_html = self.fetch_page(self.newlisted_url)
        current_newlisted = self.parse_newlisted(newlisted_html)
        
        # 如果是首次运行，仅记录当前公告
        if not self.last_announcements and not self.last_newlisted:
            self.last_announcements = current_announcements
            self.last_newlisted = current_newlisted
            self.save_cache()
            logger.info("首次运行，已记录当前公告基准")
            return None, None
        
        # 查找新的普通公告
        new_announcements = self.find_new_announcements(current_announcements, self.last_announcements)
        filtered_announcements = self.filter_announcements_by_keywords(new_announcements)
        
        # 查找新的上币公告
        new_newlisted = self.find_new_announcements(current_newlisted, self.last_newlisted)
        
        # 更新缓存
        self.last_announcements = current_announcements
        self.last_newlisted = current_newlisted
        self.save_cache()
        
        return filtered_announcements, new_newlisted
    
    def format_announcement_alert(self, new_announcements, new_newlisted):
        """格式化公告预警消息"""
        if not new_announcements and not new_newlisted:
            return None
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"📢 Gate.io 公告监控 - {now}\n\n"
        
        if new_announcements:
            message += "🔔 重要公告更新：\n"
            for _, data in new_announcements.items():
                message += f"- {data['title']}\n"
                message += f"  链接：{data['link']}\n\n"
        
        if new_newlisted:
            message += "🚀 新上币公告：\n"
            for _, data in new_newlisted.items():
                message += f"- {data['title']}\n"
                message += f"  链接：{data['link']}\n\n"
        
        return message

if __name__ == "__main__":
    # 创建公告监控器实例
    monitor = GateAnnouncementMonitor()
    
    # 执行公告检查
    new_announcements, new_newlisted = monitor.run_announcement_check()
    
    # 如果有新公告，打印警报消息
    if new_announcements or new_newlisted:
        alert_message = monitor.format_announcement_alert(new_announcements, new_newlisted)
        print(alert_message)
    else:
        print("没有检测到新的公告")
