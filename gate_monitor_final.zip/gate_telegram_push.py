#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io Telegram推送模块
功能：将价格监控和公告监控的结果推送到Telegram
支持多账号轮换推送，降低单一账号风险
"""

import os
import json
import time
import random
import logging
import requests
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("telegram_push.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_telegram_push")

class GateTelegramPush:
    """Gate.io Telegram推送类"""
    
    def __init__(self, config_file="telegram_config.json", config=None):
        """初始化Telegram推送器
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        self.default_config = {
            "accounts": [
                {
                    "bot_token": "",  # Telegram Bot Token
                    "chat_id": "",    # 目标聊天ID
                    "message_thread_id": None,  # 消息主题ID（用于群组话题）
                    "enabled": True,  # 是否启用
                    "last_used": 0,   # 上次使用时间戳
                    "error_count": 0  # 错误计数
                }
            ],
            "proxy": None,    # 代理设置（如果需要）
            "rotation_strategy": "round_robin",  # 账号轮换策略: round_robin, random, least_used
            "max_errors": 3,  # 最大错误次数，超过后禁用账号
            "error_reset_time": 86400,  # 错误计数重置时间（秒）
        }
        
        self.config = self.default_config.copy()
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.update_config(self.config, config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.update_config(self.config, user_config)
                logger.info(f"已加载Telegram配置: {config_file}")
                
                # 验证必要的配置项
                self.validate_config()
            except Exception as e:
                logger.error(f"加载Telegram配置失败: {e}")
                # 创建示例配置文件
                self.create_example_config(config_file)
        else:
            logger.warning(f"Telegram配置文件不存在: {config_file}，将使用默认配置")
            # 创建示例配置文件
            self.create_example_config(config_file)
        
        # 当前使用的账号索引
        self.current_account_index = 0
    
    def update_config(self, target, source):
        """递归更新配置字典"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self.update_config(target[key], value)
            else:
                target[key] = value
    
    def validate_config(self):
        """验证配置是否有效"""
        valid_accounts = []
        for account in self.config["accounts"]:
            if account.get("bot_token") and account.get("chat_id"):
                valid_accounts.append(account)
            else:
                logger.warning("发现无效账号配置，将被忽略")
        
        if not valid_accounts:
            logger.error("没有有效的Telegram账号配置")
        else:
            self.config["accounts"] = valid_accounts
            logger.info(f"已验证 {len(valid_accounts)} 个有效Telegram账号")
    
    def create_example_config(self, config_file):
        """创建示例配置文件"""
        example_config = {
            "accounts": [
                {
                    "bot_token": "YOUR_BOT_TOKEN_1_HERE",
                    "chat_id": "YOUR_CHAT_ID_1_HERE",
                    "message_thread_id": None,
                    "enabled": True,
                    "last_used": 0,
                    "error_count": 0
                },
                {
                    "bot_token": "YOUR_BOT_TOKEN_2_HERE",
                    "chat_id": "YOUR_CHAT_ID_2_HERE",
                    "message_thread_id": None,
                    "enabled": True,
                    "last_used": 0,
                    "error_count": 0
                }
            ],
            "proxy": None,
            "rotation_strategy": "round_robin",
            "max_errors": 3,
            "error_reset_time": 86400,
            "note": "请替换上面的占位符为实际的Bot Token和Chat ID"
        }
        
        try:
            with open(config_file, 'w') as f:
                json.dump(example_config, f, indent=2)
            logger.info(f"已创建示例配置文件: {config_file}")
        except Exception as e:
            logger.error(f"创建示例配置文件失败: {e}")
    
    def get_next_account(self):
        """获取下一个可用的账号"""
        accounts = self.config["accounts"]
        if not accounts:
            logger.error("没有可用的Telegram账号")
            return None
        
        # 过滤出启用且错误次数未超限的账号
        available_accounts = [
            (i, acc) for i, acc in enumerate(accounts) 
            if acc.get("enabled", True) and acc.get("error_count", 0) < self.config["max_errors"]
        ]
        
        if not available_accounts:
            logger.error("所有Telegram账号都不可用")
            return None
        
        # 根据轮换策略选择账号
        strategy = self.config.get("rotation_strategy", "round_robin")
        
        if strategy == "random":
            # 随机选择一个账号
            index, account = random.choice(available_accounts)
        elif strategy == "least_used":
            # 选择最久未使用的账号
            index, account = min(available_accounts, key=lambda x: x[1].get("last_used", 0))
        else:  # round_robin
            # 轮询选择账号
            current = self.current_account_index
            for _ in range(len(accounts)):
                current = (current + 1) % len(accounts)
                if (current, accounts[current]) in available_accounts:
                    index = current
                    account = accounts[current]
                    break
            else:
                # 如果没有找到可用账号，使用第一个可用账号
                index, account = available_accounts[0]
        
        # 更新当前账号索引和使用时间
        self.current_account_index = index
        account["last_used"] = int(time.time())
        
        return account
    
    def update_account_status(self, account_index, success):
        """更新账号状态"""
        if account_index < 0 or account_index >= len(self.config["accounts"]):
            return
        
        account = self.config["accounts"][account_index]
        
        # 如果成功，重置错误计数
        if success:
            account["error_count"] = 0
        else:
            # 如果失败，增加错误计数
            account["error_count"] = account.get("error_count", 0) + 1
            
            # 如果错误次数超过限制，禁用账号
            if account["error_count"] >= self.config["max_errors"]:
                account["enabled"] = False
                logger.warning(f"账号 {account_index} 已被禁用，错误次数: {account['error_count']}")
        
        # 重置长时间未使用的账号的错误计数
        now = int(time.time())
        reset_time = self.config.get("error_reset_time", 86400)  # 默认1天
        
        for acc in self.config["accounts"]:
            if now - acc.get("last_used", 0) > reset_time and acc.get("error_count", 0) > 0:
                acc["error_count"] = 0
                acc["enabled"] = True
                logger.info(f"账号错误计数已重置，长时间未使用")
    
    def send_message(self, message):
        """发送消息到Telegram"""
        if not message:
            logger.warning("消息内容为空，不发送")
            return False
        
        # 获取下一个可用账号
        account = self.get_next_account()
        if not account:
            logger.error("没有可用的Telegram账号，无法发送消息")
            return False
        
        account_index = self.current_account_index
        
        try:
            url = f"https://api.telegram.org/bot{account['bot_token']}/sendMessage"
            
            payload = {
                "chat_id": account["chat_id"],
                "text": message,
                "parse_mode": "HTML",
                "disable_web_page_preview": True
            }
            
            # 如果设置了消息主题ID，添加到请求参数中
            if account.get("message_thread_id"):
                payload["message_thread_id"] = account["message_thread_id"]
            
            # 设置代理（如果需要）
            proxies = None
            if self.config["proxy"]:
                proxies = {
                    "http": self.config["proxy"],
                    "https": self.config["proxy"]
                }
            
            response = requests.post(url, json=payload, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            logger.info(f"消息已成功发送到Telegram (账号 {account_index}): {len(message)} 字符")
            self.update_account_status(account_index, True)
            return True
        
        except Exception as e:
            logger.error(f"发送消息到Telegram失败 (账号 {account_index}): {e}")
            self.update_account_status(account_index, False)
            return False
    
    def send_price_alert(self, price_changes):
        """发送价格预警"""
        if not price_changes:
            logger.info("没有价格变动，不发送预警")
            return False
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"🔔 <b>Gate.io 价格监控 - {now}</b>\n\n"
        
        for symbol, data in price_changes.items():
            change = data['change_percent']
            direction = "🔺" if change > 0 else "🔻"
            message += f"{direction} <b>{symbol}</b>: {data['current_price']:.8f} USDT\n"
            message += f"   变动: {change:.2f}% | 24h成交: {data['volume_24h']:.2f} USDT\n"
            message += f"   24h高/低: {data['high_24h']:.8f}/{data['low_24h']:.8f}\n\n"
        
        return self.send_message(message)
    
    def send_announcement_alert(self, new_announcements, new_newlisted):
        """发送公告预警"""
        if not new_announcements and not new_newlisted:
            logger.info("没有新公告，不发送预警")
            return False
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"📢 <b>Gate.io 公告监控 - {now}</b>\n\n"
        
        if new_announcements:
            message += "<b>🔔 重要公告更新：</b>\n"
            for _, data in new_announcements.items():
                message += f"- <a href='{data['link']}'>{data['title']}</a>\n\n"
        
        if new_newlisted:
            message += "<b>🚀 新上币公告：</b>\n"
            for _, data in new_newlisted.items():
                message += f"- <a href='{data['link']}'>{data['title']}</a>\n\n"
        
        return self.send_message(message)
    
    def send_coin_info(self, coin_info):
        """发送币种详细信息"""
        if not coin_info:
            logger.info("没有币种信息，不发送")
            return False
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"ℹ️ <b>Gate.io 币种信息 - {now}</b>\n\n"
        
        message += f"<b>🪙 {coin_info['symbol']}</b>\n\n"
        
        if 'name' in coin_info:
            message += f"名称: {coin_info['name']}\n"
        
        if 'price' in coin_info:
            message += f"当前价格: {coin_info['price']} USDT\n"
        
        if 'change_24h' in coin_info:
            change = coin_info['change_24h']
            direction = "🔺" if change > 0 else "🔻"
            message += f"24h变动: {direction} {change:.2f}%\n"
        
        if 'volume_24h' in coin_info:
            message += f"24h成交量: {coin_info['volume_24h']:.2f} USDT\n"
        
        if 'market_cap' in coin_info:
            message += f"市值: {coin_info['market_cap']:.2f} USDT\n"
        
        if 'description' in coin_info and coin_info['description']:
            message += f"\n<b>项目简介:</b>\n{coin_info['description'][:500]}...\n"
        
        message += "\n<b>相关链接:</b>\n"
        
        if 'website' in coin_info and coin_info['website']:
            message += f"🌐 <a href='{coin_info['website']}'>官网</a>\n"
        
        if 'twitter' in coin_info and coin_info['twitter']:
            message += f"🐦 <a href='{coin_info['twitter']}'>Twitter</a>\n"
        
        if 'telegram' in coin_info and coin_info['telegram']:
            message += f"📱 <a href='{coin_info['telegram']}'>Telegram</a>\n"
        
        if 'contract_info' in coin_info and coin_info['contract_info']:
            message += f"\n<b>合约信息:</b>\n{coin_info['contract_info']}\n"
        
        if 'market_analysis' in coin_info and coin_info['market_analysis']:
            message += f"\n<b>市场分析:</b>\n{coin_info['market_analysis']}\n"
        
        return self.send_message(message)

if __name__ == "__main__":
    # 创建Telegram推送器实例
    pusher = GateTelegramPush()
    
    # 测试发送消息
    test_message = "这是一条测试消息，来自Gate.io监控系统"
    pusher.send_message(test_message)
