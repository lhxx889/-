#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 增强版币种信息采集模块
功能：获取币种的详细信息，包括团队信息、发行时间、总供应量、历史价格数据分析等
增强功能：
1. 改进从公告标题中提取币种符号的算法
2. 增加更多币种元数据采集
3. 添加历史价格数据分析
4. 实现自动关联相似币种的对比分析
5. 集成链上数据分析
"""

import os
import re
import json
import time
import logging
import requests
import numpy as np
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from collections import defaultdict
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("enhanced_coin_info.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_enhanced_coin_info")

class EnhancedCoinInfo:
    """Gate.io增强版币种详细信息采集类"""
    
    def __init__(self, config_file=None, config=None):
        """初始化增强版币种信息采集器
        
        Args:
            config_file: 配置文件路径
            config: 配置字典，优先级高于配置文件
        """
        self.base_url = "https://api.gateio.ws/api/v4"
        self.web_base_url = "https://www.gate.io"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        }
        self.cache_file = "enhanced_coin_info_cache.json"
        self.coin_cache = {}  # 币种信息缓存
        self.coin_vectors = {}  # 币种向量表示，用于相似性计算
        
        self.config = {
            "cache_expiry": 86400,  # 缓存过期时间（秒），默认1天
            "max_retries": 3,       # 最大重试次数
            "retry_delay": 2,       # 重试延迟（秒）
            "request_timeout": 10,  # 请求超时（秒）
            "history_days": 30,     # 历史数据天数
            "similar_coins_count": 5,  # 相似币种数量
            "chain_explorers": {     # 链上浏览器API配置
                "ethereum": {
                    "api_url": "https://api.etherscan.io/api",
                    "api_key": "YOUR_ETHERSCAN_API_KEY"
                },
                "binance": {
                    "api_url": "https://api.bscscan.com/api",
                    "api_key": "YOUR_BSCSCAN_API_KEY"
                }
            }
        }
        
        # 如果提供了配置字典，则直接使用
        if config:
            self.config.update(config)
            logger.info("已加载配置字典")
        # 如果提供了配置文件，则加载配置
        elif config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    self.config.update(user_config)
                logger.info(f"已加载配置文件: {config_file}")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
        
        # 加载缓存的币种信息
        self.load_cache()
    
    def load_cache(self):
        """加载缓存的币种信息"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    self.coin_cache = json.load(f)
                logger.info(f"已加载币种信息缓存: {len(self.coin_cache)} 个币种")
                
                # 初始化币种向量
                for symbol, info in self.coin_cache.items():
                    if 'features' in info:
                        self.coin_vectors[symbol] = info['features']
            except Exception as e:
                logger.error(f"加载币种信息缓存失败: {e}")
                self.coin_cache = {}
    
    def save_cache(self):
        """保存币种信息到缓存"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.coin_cache, f, ensure_ascii=False, indent=2)
            logger.info(f"币种信息缓存已更新: {len(self.coin_cache)} 个币种")
        except Exception as e:
            logger.error(f"保存币种信息缓存失败: {e}")
    
    def api_request(self, endpoint, params=None):
        """发送API请求，带重试机制"""
        url = f"{self.base_url}{endpoint}"
        retries = 0
        
        while retries < self.config["max_retries"]:
            try:
                response = requests.get(
                    url, 
                    params=params, 
                    headers=self.headers, 
                    timeout=self.config["request_timeout"]
                )
                response.raise_for_status()
                return response.json()
            except Exception as e:
                retries += 1
                logger.warning(f"API请求失败 ({retries}/{self.config['max_retries']}): {e}")
                if retries < self.config["max_retries"]:
                    time.sleep(self.config["retry_delay"])
                else:
                    logger.error(f"API请求最终失败: {url}")
                    return None
    
    def fetch_page(self, url):
        """获取网页内容，带重试机制"""
        retries = 0
        
        while retries < self.config["max_retries"]:
            try:
                response = requests.get(
                    url, 
                    headers=self.headers, 
                    timeout=self.config["request_timeout"]
                )
                response.raise_for_status()
                return response.text
            except Exception as e:
                retries += 1
                logger.warning(f"网页请求失败 ({retries}/{self.config['max_retries']}): {e}")
                if retries < self.config["max_retries"]:
                    time.sleep(self.config["retry_delay"])
                else:
                    logger.error(f"网页请求最终失败: {url}")
                    return None
    
    def extract_coin_from_announcement(self, title):
        """从公告标题中提取币种符号（增强版）
        
        使用多种模式匹配策略提高准确率
        """
        # 常见的公告标题模式
        patterns = [
            # 模式1: 币种(符号)
            r'([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)',
            # 模式2: 符号/USDT
            r'([A-Z0-9]{2,10})/USDT',
            # 模式3: 符号-USDT
            r'([A-Z0-9]{2,10})-USDT',
            # 模式4: 将上线符号(Symbol)
            r'将上线\s*([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)',
            # 模式5: 已上线符号(Symbol)
            r'已上线\s*([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)',
            # 模式6: 上架符号(Symbol)
            r'上架\s*([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)',
            # 模式7: 符号(Symbol)已上线
            r'([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)\s*已上线',
            # 模式8: 符号(Symbol)将上线
            r'([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)\s*将上线',
            # 模式9: 纯符号（通常是大写字母和数字的组合，长度2-10）
            r'\b([A-Z0-9]{2,10})\b'
        ]
        
        # 常见的排除词（避免误匹配）
        exclude_words = ['USDT', 'BTC', 'ETH', 'GATE', 'SPOT', 'SWAP', 'FUTURES', 'MARGIN']
        
        # 尝试每种模式
        for pattern in patterns:
            matches = re.findall(pattern, title)
            if matches:
                # 根据模式类型处理匹配结果
                if '(' in pattern:
                    # 如果模式包含括号，取第二个捕获组（通常是符号）
                    symbol = matches[0][1] if isinstance(matches[0], tuple) else matches[0]
                else:
                    # 否则取第一个捕获组
                    symbol = matches[0][0] if isinstance(matches[0], tuple) else matches[0]
                
                # 验证提取的符号
                if symbol and symbol not in exclude_words and 2 <= len(symbol) <= 10:
                    logger.info(f"从标题 '{title}' 中提取到币种符号: {symbol}")
                    return symbol
        
        # 如果所有模式都未匹配，尝试更宽松的匹配
        words = re.findall(r'\b([A-Z0-9]{2,10})\b', title)
        for word in words:
            if word not in exclude_words and 2 <= len(word) <= 10:
                logger.info(f"从标题 '{title}' 中提取到可能的币种符号: {word}")
                return word
        
        logger.warning(f"无法从标题 '{title}' 中提取币种符号")
        return None
    
    def extract_multiple_coins_from_announcement(self, title):
        """从公告标题中提取多个币种符号
        
        返回可能的币种符号列表
        """
        # 使用与单币种提取相同的模式，但返回所有匹配项
        patterns = [
            r'([A-Za-z0-9]+)\s*\(([A-Z0-9]{2,10})\)',
            r'([A-Z0-9]{2,10})/USDT',
            r'([A-Z0-9]{2,10})-USDT',
            r'\b([A-Z0-9]{2,10})\b'
        ]
        
        exclude_words = ['USDT', 'BTC', 'ETH', 'GATE', 'SPOT', 'SWAP', 'FUTURES', 'MARGIN']
        potential_symbols = set()
        
        for pattern in patterns:
            matches = re.findall(pattern, title)
            for match in matches:
                symbol = match[1] if isinstance(match, tuple) else match
                if symbol and symbol not in exclude_words and 2 <= len(symbol) <= 10:
                    potential_symbols.add(symbol)
        
        if potential_symbols:
            logger.info(f"从标题 '{title}' 中提取到多个币种符号: {potential_symbols}")
        else:
            logger.warning(f"无法从标题 '{title}' 中提取币种符号")
        
        return list(potential_symbols)
    
    def get_currency_detail(self, currency):
        """获取币种详细信息"""
        endpoint = f"/spot/currencies/{currency}"
        return self.api_request(endpoint)
    
    def get_ticker(self, currency_pair):
        """获取交易对行情"""
        endpoint = "/spot/tickers"
        params = {"currency_pair": currency_pair}
        result = self.api_request(endpoint, params)
        return result[0] if result else None
    
    def get_historical_candlesticks(self, currency_pair, interval='1d', limit=30):
        """获取历史K线数据"""
        endpoint = "/spot/candlesticks"
        params = {
            "currency_pair": currency_pair,
            "interval": interval,
            "limit": limit
        }
        return self.api_request(endpoint, params)
    
    def get_coin_info_from_web(self, currency):
        """从网页获取币种详细信息（增强版）"""
        url = f"{self.web_base_url}/zh/trade/{currency}_USDT"
        html_content = self.fetch_page(url)
        if not html_content:
            return {}
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            info = {}
            
            # 尝试获取币种描述
            description_div = soup.select_one('div.coin-description')
            if description_div:
                info['description'] = description_div.text.strip()
            
            # 尝试获取社交链接
            social_links = soup.select('div.social-links a')
            for link in social_links:
                href = link.get('href', '')
                if 'twitter.com' in href or 'x.com' in href:
                    info['twitter'] = href
                elif 'telegram' in href:
                    info['telegram'] = href
                elif 'discord' in href:
                    info['discord'] = href
                elif 'github.com' in href:
                    info['github'] = href
                elif 'medium.com' in href:
                    info['medium'] = href
                elif not href.startswith('https://www.gate.io') and 'website' not in info:
                    info['website'] = href
            
            # 尝试获取团队信息
            team_info_div = soup.select_one('div.team-info')
            if team_info_div:
                info['team_info'] = team_info_div.text.strip()
            
            # 尝试获取发行信息
            issue_info = {}
            issue_info_divs = soup.select('div.issue-info')
            for div in issue_info_divs:
                label_elem = div.select_one('span.label')
                value_elem = div.select_one('span.value')
                if label_elem and value_elem:
                    label = label_elem.text.strip()
                    value = value_elem.text.strip()
                    issue_info[label] = value
            
            if issue_info:
                info['issue_info'] = issue_info
            
            return info
        except Exception as e:
            logger.error(f"解析币种网页信息失败: {e}")
            return {}
    
    def get_market_cap_info(self, currency):
        """获取市值信息（增强版）"""
        try:
            # 尝试从API获取流通量信息
            currency_detail = self.get_currency_detail(currency)
            ticker = self.get_ticker(f"{currency}_USDT")
            
            if currency_detail and ticker:
                market_info = {}
                
                # 如果API提供了流通量，可以计算市值
                if 'circulating_supply' in currency_detail:
                    circulating_supply = float(currency_detail['circulating_supply'])
                    price = float(ticker['last'])
                    market_cap = circulating_supply * price
                    market_info['market_cap'] = market_cap
                    market_info['circulating_supply'] = circulating_supply
                    market_info['price'] = price
                
                # 尝试获取总供应量
                if 'total_supply' in currency_detail:
                    market_info['total_supply'] = float(currency_detail['total_supply'])
                
                # 尝试获取最大供应量
                if 'max_supply' in currency_detail:
                    market_info['max_supply'] = float(currency_detail['max_supply'])
                
                return market_info
            
            return {}
        except Exception as e:
            logger.error(f"获取市值信息失败: {e}")
            return {}
    
    def analyze_historical_data(self, currency):
        """分析历史价格数据，提供趋势判断"""
        try:
            # 获取历史K线数据
            candlesticks = self.get_historical_candlesticks(f"{currency}_USDT", interval='1d', limit=self.config['history_days'])
            if not candlesticks:
                logger.error(f"获取 {currency} 历史数据失败")
                return {}
            
            # 转换为DataFrame进行分析
            df = pd.DataFrame(candlesticks, columns=['timestamp', 'volume', 'close', 'high', 'low', 'open'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
            df = df.sort_values('timestamp')
            
            # 转换数据类型
            for col in ['volume', 'close', 'high', 'low', 'open']:
                df[col] = pd.to_numeric(df[col])
            
            # 计算移动平均线
            df['ma5'] = df['close'].rolling(window=5).mean()
            df['ma10'] = df['close'].rolling(window=10).mean()
            df['ma20'] = df['close'].rolling(window=20).mean()
            
            # 计算相对强弱指标(RSI)
            delta = df['close'].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.rolling(window=14).mean()
            avg_loss = loss.rolling(window=14).mean()
            rs = avg_gain / avg_loss
            df['rsi'] = 100 - (100 / (1 + rs))
            
            # 计算布林带
            df['middle_band'] = df['close'].rolling(window=20).mean()
            df['std'] = df['close'].rolling(window=20).std()
            df['upper_band'] = df['middle_band'] + (df['std'] * 2)
            df['lower_band'] = df['middle_band'] - (df['std'] * 2)
            
            # 计算MACD
            df['ema12'] = df['close'].ewm(span=12, adjust=False).mean()
            df['ema26'] = df['close'].ewm(span=26, adjust=False).mean()
            df['macd'] = df['ema12'] - df['ema26']
            df['signal'] = df['macd'].ewm(span=9, adjust=False).mean()
            df['histogram'] = df['macd'] - df['signal']
            
            # 计算支撑位和阻力位
            recent_df = df.tail(10)  # 使用最近10天的数据
            support_level = recent_df['low'].min()
            resistance_level = recent_df['high'].max()
            
            # 判断趋势
            current_close = df['close'].iloc[-1]
            prev_close = df['close'].iloc[-2] if len(df) > 1 else current_close
            ma5_current = df['ma5'].iloc[-1]
            ma20_current = df['ma20'].iloc[-1]
            
            trend = "中性"
            if ma5_current > ma20_current and current_close > ma5_current:
                trend = "强势上涨"
            elif ma5_current > ma20_current:
                trend = "上涨"
            elif ma5_current < ma20_current and current_close < ma5_current:
                trend = "强势下跌"
            elif ma5_current < ma20_current:
                trend = "下跌"
            
            # 计算波动率
            df['returns'] = df['close'].pct_change()
            volatility = df['returns'].std() * (252 ** 0.5)  # 年化波动率
            
            # 计算交易量趋势
            volume_trend = "稳定"
            recent_volume = df['volume'].tail(5).mean()
            previous_volume = df['volume'].iloc[-10:-5].mean() if len(df) >= 10 else recent_volume
            volume_change = (recent_volume - previous_volume) / previous_volume if previous_volume > 0 else 0
            
            if volume_change > 0.5:
                volume_trend = "大幅增加"
            elif volume_change > 0.2:
                volume_trend = "增加"
            elif volume_change < -0.5:
                volume_trend = "大幅减少"
            elif volume_change < -0.2:
                volume_trend = "减少"
            
            # 构建分析结果
            analysis = {
                'trend': trend,
                'support_level': float(support_level),
                'resistance_level': float(resistance_level),
                'rsi': float(df['rsi'].iloc[-1]) if not pd.isna(df['rsi'].iloc[-1]) else None,
                'macd': float(df['macd'].iloc[-1]) if not pd.isna(df['macd'].iloc[-1]) else None,
                'signal': float(df['signal'].iloc[-1]) if not pd.isna(df['signal'].iloc[-1]) else None,
                'volatility': float(volatility) if not pd.isna(volatility) else None,
                'volume_trend': volume_trend,
                'price_change_24h': float((current_close - prev_close) / prev_close * 100) if prev_close > 0 else 0,
                'price_change_7d': float((current_close - df['close'].iloc[-7]) / df['close'].iloc[-7] * 100) if len(df) >= 7 and df['close'].iloc[-7] > 0 else None,
                'price_change_30d': float((current_close - df['close'].iloc[0]) / df['close'].iloc[0] * 100) if df['close'].iloc[0] > 0 else None,
                'highest_price_30d': float(df['high'].max()),
                'lowest_price_30d': float(df['low'].min()),
                'average_volume_7d': float(df['volume'].tail(7).mean()) if len(df) >= 7 else None
            }
            
            # 生成分析文本
            analysis_text = f"{currency} 当前处于{trend}趋势，"
            
            if analysis['rsi'] is not None:
                if analysis['rsi'] > 70:
                    analysis_text += f"RSI为{analysis['rsi']:.2f}，处于超买区间，"
                elif analysis['rsi'] < 30:
                    analysis_text += f"RSI为{analysis['rsi']:.2f}，处于超卖区间，"
            
            analysis_text += f"近期支撑位在{analysis['support_level']:.8f}，阻力位在{analysis['resistance_level']:.8f}。"
            
            if analysis['volume_trend'] != "稳定":
                analysis_text += f"交易量呈{analysis['volume_trend']}趋势。"
            
            if analysis['price_change_7d'] is not None:
                direction = "上涨" if analysis['price_change_7d'] > 0 else "下跌"
                analysis_text += f"7天内价格{direction}{abs(analysis['price_change_7d']):.2f}%。"
            
            analysis['analysis_text'] = analysis_text
            
            return analysis
        
        except Exception as e:
            logger.error(f"分析历史价格数据失败: {e}")
            return {}
    
    def get_contract_info(self, currency):
        """获取合约信息（增强版）"""
        try:
            # 尝试从API获取合约信息
            currency_detail = self.get_currency_detail(currency)
            
            if currency_detail and 'chain' in currency_detail:
                chains = currency_detail['chain'].split(',')
                contract_info = {}
                
                for chain in chains:
                    if chain and chain.strip():
                        chain_name = chain.strip()
                        contract_info[chain_name] = {}
                        
                        # 如果API提供了合约地址，添加到信息中
                        if 'contract_address' in currency_detail:
                            contract_info[chain_name]['address'] = currency_detail['contract_address']
                        
                        # 尝试获取更多合约信息（如果API支持）
                        if 'decimals' in currency_detail:
                            contract_info[chain_name]['decimals'] = currency_detail['decimals']
                
                return contract_info if contract_info else {"note": "暂无详细合约信息"}
            
            return {"note": "暂无合约信息"}
        except Exception as e:
            logger.error(f"获取合约信息失败: {e}")
            return {"note": "获取合约信息失败"}
    
    def get_chain_data(self, currency, contract_info):
        """获取链上数据分析"""
        try:
            chain_data = {}
            
            # 检查是否有合约信息
            if not contract_info or isinstance(contract_info, str) or "note" in contract_info:
                return {"note": "无法获取链上数据，缺少合约信息"}
            
            # 遍历每个链的合约
            for chain_name, info in contract_info.items():
                if 'address' not in info:
                    continue
                
                contract_address = info['address']
                chain_config = None
                
                # 确定使用哪个链的配置
                if chain_name.lower() in ['ethereum', 'eth']:
                    chain_config = self.config['chain_explorers'].get('ethereum')
                elif chain_name.lower() in ['binance', 'bsc', 'bnb']:
                    chain_config = self.config['chain_explorers'].get('binance')
                
                if not chain_config or not chain_config.get('api_key'):
                    continue
                
                # 获取持币地址数量
                holders_data = self.get_token_holders(chain_config, contract_address)
                if holders_data:
                    chain_data[chain_name] = holders_data
            
            return chain_data if chain_data else {"note": "暂无链上数据"}
        
        except Exception as e:
            logger.error(f"获取链上数据失败: {e}")
            return {"note": f"获取链上数据失败: {str(e)}"}
    
    def get_token_holders(self, chain_config, contract_address):
        """获取代币持有者信息"""
        try:
            api_url = chain_config['api_url']
            api_key = chain_config['api_key']
            
            # 如果是示例API密钥，返回模拟数据
            if api_key == "YOUR_ETHERSCAN_API_KEY" or api_key == "YOUR_BSCSCAN_API_KEY":
                return {
                    "holders_count": "模拟数据 - 请配置实际API密钥",
                    "top_holders": "模拟数据 - 请配置实际API密钥"
                }
            
            # 构建API请求
            params = {
                'module': 'token',
                'action': 'tokeninfo',
                'contractaddress': contract_address,
                'apikey': api_key
            }
            
            response = requests.get(api_url, params=params, timeout=10)
            data = response.json()
            
            if data.get('status') == '1':
                result = data.get('result', {})
                return {
                    "holders_count": result.get('holders', 'Unknown'),
                    "total_supply": result.get('totalSupply', 'Unknown'),
                    "transfers_24h": "需要高级API访问权限",
                    "note": "完整链上数据需要配置高级API访问权限"
                }
            else:
                return {
                    "note": f"API返回错误: {data.get('message', 'Unknown error')}"
                }
        
        except Exception as e:
            logger.error(f"获取代币持有者信息失败: {e}")
            return {"note": f"获取持有者信息失败: {str(e)}"}
    
    def calculate_coin_features(self, coin_info):
        """计算币种特征向量，用于相似性比较"""
        features = []
        
        # 使用市值作为特征
        market_cap = coin_info.get('market_cap', 0)
        features.append(np.log1p(market_cap) if market_cap > 0 else 0)
        
        # 使用交易量作为特征
        volume = coin_info.get('volume_24h', 0)
        features.append(np.log1p(volume) if volume > 0 else 0)
        
        # 使用价格变动作为特征
        price_change = coin_info.get('change_24h', 0)
        features.append(price_change / 100)  # 归一化
        
        # 使用波动率作为特征
        volatility = coin_info.get('volatility', 0)
        features.append(volatility if volatility else 0)
        
        # 使用RSI作为特征
        rsi = coin_info.get('rsi', 50)
        features.append(rsi / 100 if rsi else 0.5)  # 归一化
        
        return features
    
    def find_similar_coins(self, currency, coin_info):
        """查找相似的币种"""
        try:
            # 计算当前币种的特征向量
            if 'features' not in coin_info:
                coin_info['features'] = self.calculate_coin_features(coin_info)
                self.coin_vectors[currency] = coin_info['features']
            
            # 如果没有足够的币种进行比较，返回空结果
            if len(self.coin_vectors) < 2:
                return []
            
            # 计算与其他币种的相似度
            similarities = []
            for symbol, features in self.coin_vectors.items():
                if symbol != currency:
                    # 计算余弦相似度
                    similarity = cosine_similarity([coin_info['features']], [features])[0][0]
                    similarities.append((symbol, similarity))
            
            # 按相似度排序
            similarities.sort(key=lambda x: x[1], reverse=True)
            
            # 返回最相似的N个币种
            similar_coins = []
            for symbol, similarity in similarities[:self.config['similar_coins_count']]:
                if symbol in self.coin_cache:
                    coin_data = self.coin_cache[symbol]
                    similar_coins.append({
                        'symbol': symbol,
                        'similarity': similarity,
                        'price': coin_data.get('price', 0),
                        'market_cap': coin_data.get('market_cap', 0),
                        'volume_24h': coin_data.get('volume_24h', 0),
                        'change_24h': coin_data.get('change_24h', 0)
                    })
            
            return similar_coins
        
        except Exception as e:
            logger.error(f"查找相似币种失败: {e}")
            return []
    
    def get_complete_coin_info(self, currency):
        """获取完整的币种信息（增强版）"""
        # 检查缓存是否有效
        now = int(time.time())
        if currency in self.coin_cache:
            cache_time = self.coin_cache[currency].get('cache_time', 0)
            if now - cache_time < self.config["cache_expiry"]:
                logger.info(f"使用缓存的币种信息: {currency}")
                return self.coin_cache[currency]
        
        logger.info(f"获取币种详细信息: {currency}")
        
        # 获取API基础信息
        currency_detail = self.get_currency_detail(currency)
        if not currency_detail:
            logger.error(f"获取币种基础信息失败: {currency}")
            return None
        
        # 获取行情信息
        ticker = self.get_ticker(f"{currency}_USDT")
        if not ticker:
            logger.error(f"获取币种行情信息失败: {currency}")
            return None
        
        # 从网页获取额外信息
        web_info = self.get_coin_info_from_web(currency)
        
        # 获取市值信息
        market_info = self.get_market_cap_info(currency)
        
        # 获取合约信息
        contract_info = self.get_contract_info(currency)
        
        # 分析历史价格数据
        historical_analysis = self.analyze_historical_data(currency)
        
        # 获取链上数据
        chain_data = self.get_chain_data(currency, contract_info)
        
        # 整合所有信息
        coin_info = {
            'symbol': currency,
            'name': currency_detail.get('name', currency),
            'price': float(ticker['last']),
            'change_24h': float(ticker.get('change_percentage', 0)),
            'volume_24h': float(ticker['quote_volume']),
            'high_24h': float(ticker['high_24h']),
            'low_24h': float(ticker['low_24h']),
            'description': web_info.get('description', ''),
            'website': web_info.get('website', ''),
            'twitter': web_info.get('twitter', ''),
            'telegram': web_info.get('telegram', ''),
            'discord': web_info.get('discord', ''),
            'github': web_info.get('github', ''),
            'medium': web_info.get('medium', ''),
            'team_info': web_info.get('team_info', ''),
            'issue_info': web_info.get('issue_info', {}),
            'contract_info': contract_info,
            'market_cap': market_info.get('market_cap', 0),
            'circulating_supply': market_info.get('circulating_supply', 0),
            'total_supply': market_info.get('total_supply', 0),
            'max_supply': market_info.get('max_supply', 0),
            'historical_analysis': historical_analysis,
            'chain_data': chain_data,
            'cache_time': now
        }
        
        # 添加历史分析中的关键指标
        if historical_analysis:
            for key in ['trend', 'support_level', 'resistance_level', 'rsi', 'volatility', 
                       'volume_trend', 'price_change_7d', 'price_change_30d', 'analysis_text']:
                if key in historical_analysis:
                    coin_info[key] = historical_analysis[key]
        
        # 计算特征向量
        coin_info['features'] = self.calculate_coin_features(coin_info)
        self.coin_vectors[currency] = coin_info['features']
        
        # 查找相似币种
        similar_coins = self.find_similar_coins(currency, coin_info)
        coin_info['similar_coins'] = similar_coins
        
        # 更新缓存
        self.coin_cache[currency] = coin_info
        self.save_cache()
        
        return coin_info
    
    def get_new_coin_info(self, currency):
        """获取新上币的详细信息（增强版）"""
        # 对于新上币，强制刷新缓存
        if currency in self.coin_cache:
            del self.coin_cache[currency]
        
        return self.get_complete_coin_info(currency)
    
    def format_coin_info_message(self, coin_info):
        """格式化币种信息为消息文本"""
        if not coin_info:
            return "无法获取币种信息"
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"ℹ️ <b>Gate.io 币种详细信息 - {now}</b>\n\n"
        
        message += f"<b>🪙 {coin_info['symbol']}</b>"
        if 'name' in coin_info and coin_info['name'] != coin_info['symbol']:
            message += f" ({coin_info['name']})\n\n"
        else:
            message += "\n\n"
        
        # 基本价格信息
        if 'price' in coin_info:
            message += f"当前价格: {coin_info['price']:.8f} USDT\n"
        
        if 'change_24h' in coin_info:
            change = coin_info['change_24h']
            direction = "🔺" if change > 0 else "🔻"
            message += f"24h变动: {direction} {change:.2f}%\n"
        
        if 'volume_24h' in coin_info:
            message += f"24h成交量: {coin_info['volume_24h']:.2f} USDT\n"
        
        if 'market_cap' in coin_info and coin_info['market_cap'] > 0:
            message += f"市值: {coin_info['market_cap']:.2f} USDT\n"
        
        # 供应量信息
        supply_info = []
        if 'circulating_supply' in coin_info and coin_info['circulating_supply'] > 0:
            supply_info.append(f"流通量: {coin_info['circulating_supply']:.2f}")
        if 'total_supply' in coin_info and coin_info['total_supply'] > 0:
            supply_info.append(f"总供应量: {coin_info['total_supply']:.2f}")
        if 'max_supply' in coin_info and coin_info['max_supply'] > 0:
            supply_info.append(f"最大供应量: {coin_info['max_supply']:.2f}")
        
        if supply_info:
            message += "\n<b>供应量信息:</b>\n" + "\n".join(supply_info) + "\n"
        
        # 历史分析
        if 'analysis_text' in coin_info and coin_info['analysis_text']:
            message += f"\n<b>市场分析:</b>\n{coin_info['analysis_text']}\n"
        
        # 项目描述
        if 'description' in coin_info and coin_info['description']:
            desc = coin_info['description']
            if len(desc) > 500:
                desc = desc[:497] + "..."
            message += f"\n<b>项目简介:</b>\n{desc}\n"
        
        # 团队信息
        if 'team_info' in coin_info and coin_info['team_info']:
            team = coin_info['team_info']
            if len(team) > 300:
                team = team[:297] + "..."
            message += f"\n<b>团队信息:</b>\n{team}\n"
        
        # 发行信息
        if 'issue_info' in coin_info and coin_info['issue_info']:
            message += "\n<b>发行信息:</b>\n"
            for key, value in coin_info['issue_info'].items():
                message += f"{key}: {value}\n"
        
        # 相关链接
        links = []
        for link_type in ['website', 'twitter', 'telegram', 'discord', 'github', 'medium']:
            if link_type in coin_info and coin_info[link_type]:
                link_name = link_type.capitalize()
                links.append(f"<a href='{coin_info[link_type]}'>{link_name}</a>")
        
        if links:
            message += "\n<b>相关链接:</b>\n" + " | ".join(links) + "\n"
        
        # 合约信息
        if 'contract_info' in coin_info and coin_info['contract_info'] and isinstance(coin_info['contract_info'], dict):
            if 'note' not in coin_info['contract_info']:
                message += "\n<b>合约信息:</b>\n"
                for chain, info in coin_info['contract_info'].items():
                    message += f"• {chain} 链"
                    if 'address' in info:
                        addr = info['address']
                        if len(addr) > 16:
                            addr = addr[:8] + "..." + addr[-8:]
                        message += f": {addr}\n"
                    else:
                        message += "\n"
        
        # 链上数据
        if 'chain_data' in coin_info and coin_info['chain_data'] and isinstance(coin_info['chain_data'], dict):
            if 'note' not in coin_info['chain_data']:
                message += "\n<b>链上数据:</b>\n"
                for chain, data in coin_info['chain_data'].items():
                    message += f"• {chain} 链:\n"
                    for key, value in data.items():
                        if key != 'note':
                            message += f"  {key}: {value}\n"
        
        # 相似币种
        if 'similar_coins' in coin_info and coin_info['similar_coins']:
            message += "\n<b>相似币种:</b>\n"
            for i, coin in enumerate(coin_info['similar_coins']):
                message += f"• {coin['symbol']}: 相似度 {coin['similarity']:.2f}, 价格 {coin['price']:.8f} USDT"
                if 'change_24h' in coin:
                    direction = "🔺" if coin['change_24h'] > 0 else "🔻"
                    message += f", 24h {direction} {coin['change_24h']:.2f}%"
                message += "\n"
        
        return message

if __name__ == "__main__":
    # 创建增强版币种信息采集器实例
    coin_info = EnhancedCoinInfo()
    
    # 测试获取BTC信息
    btc_info = coin_info.get_complete_coin_info("BTC")
    if btc_info:
        message = coin_info.format_coin_info_message(btc_info)
        print(message)
    else:
        print("获取BTC信息失败")
