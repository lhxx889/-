#!/bin/bash

# Gate.io 监控系统一键安装脚本
# 功能：自动安装所有依赖、配置环境、准备配置文件

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的信息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为root用户
check_root() {
    if [ "$EUID" -ne 0 ]; then
        print_warning "当前非root用户，部分功能可能受限"
        print_warning "建议使用 sudo ./install.sh 运行此脚本"
    fi
}

# 检查操作系统
check_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        print_info "检测到操作系统: $OS $VER"
    else
        print_warning "无法确定操作系统类型，将尝试继续安装"
        OS="Unknown"
    fi
}

# 安装系统依赖
install_system_deps() {
    print_info "开始安装系统依赖..."
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        apt-get update
        apt-get install -y python3 python3-pip curl wget unzip git
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]] || [[ "$OS" == *"Fedora"* ]]; then
        yum -y update
        yum -y install python3 python3-pip curl wget unzip git
    elif [[ "$OS" == *"Arch"* ]]; then
        pacman -Syu --noconfirm
        pacman -S --noconfirm python python-pip curl wget unzip git
    else
        print_warning "未知操作系统，请手动安装以下依赖: python3, python3-pip, curl, wget, unzip, git"
    fi
    
    if [ $? -eq 0 ]; then
        print_success "系统依赖安装完成"
    else
        print_error "系统依赖安装失败，请手动安装"
    fi
}

# 安装v2ray
install_v2ray() {
    print_info "开始安装v2ray..."
    
    if command -v v2ray >/dev/null 2>&1; then
        print_success "v2ray已安装，版本: $(v2ray version | head -n 1)"
    else
        print_info "正在安装v2ray..."
        bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)
        
        if [ $? -eq 0 ]; then
            print_success "v2ray安装完成"
        else
            print_error "v2ray安装失败，请手动安装"
            print_info "手动安装命令: bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)"
        fi
    fi
}

# 安装Python依赖
install_python_deps() {
    print_info "开始安装Python依赖..."
    
    # 创建虚拟环境
    if [ ! -d "venv" ]; then
        print_info "创建Python虚拟环境..."
        python3 -m venv venv
    fi
    
    # 激活虚拟环境
    source venv/bin/activate
    
    # 安装依赖
    print_info "安装Python包依赖..."
    pip install --upgrade pip
    pip install requests python-telegram-bot scikit-learn nltk fake-useragent beautifulsoup4 pandas numpy matplotlib
    
    if [ $? -eq 0 ]; then
        print_success "Python依赖安装完成"
    else
        print_error "Python依赖安装失败，请检查错误信息"
    fi
    
    # 下载NLTK数据
    print_info "下载NLTK数据..."
    python -c "import nltk; nltk.download('vader_lexicon')"
}

# 创建配置文件
create_config_files() {
    print_info "创建配置文件..."
    
    # 创建主配置文件
    if [ ! -f "config_main.json" ]; then
        cat > config_main.json << EOF
{
  "monitored_coins": ["BTC", "ETH", "GT", "DOGE", "SHIB"],
  "run_interval": 3600,
  "price_change_threshold": 5.0,
  "volume_change_threshold": 50.0,
  "proxy_config": "config_vless.json",
  "telegram_config": "telegram_config.json"
}
EOF
        print_success "创建主配置文件: config_main.json"
    fi
    
    # 创建VLESS代理配置文件
    if [ ! -f "config_vless.json" ]; then
        cat > config_vless.json << EOF
{
  "proxy": {
    "enabled": true,
    "type": "vless",
    "vless_uris": [
      "vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态"
    ],
    "use_local_v2ray": true,
    "v2ray_bin": "v2ray",
    "local_port_start": 10800,
    "rotation_interval": 10,
    "retry_times": 3,
    "timeout": 10,
    "test_url": "https://api.ipify.org?format=json",
    "blacklist_time": 300
  },
  "user_agent": {
    "enabled": true,
    "rotation": "random",
    "custom_agents": [
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
    ]
  },
  "cookie": {
    "enabled": true,
    "save_path": "cookies.txt",
    "domains": ["gate.io", "www.gate.io"],
    "expire_days": 7
  },
  "behavior": {
    "enabled": true,
    "random_delay": {
      "min": 1,
      "max": 3
    },
    "visit_patterns": {
      "enabled": true,
      "entry_pages": [
        "https://www.gate.io/",
        "https://www.gate.io/trade/BTC_USDT"
      ],
      "random_pages": [
        "https://www.gate.io/trade/ETH_USDT",
        "https://www.gate.io/marketlist"
      ],
      "probability": 0.3
    }
  }
}
EOF
        print_success "创建VLESS代理配置文件: config_vless.json"
    fi
    
    # 创建Telegram配置文件
    if [ ! -f "telegram_config.json" ]; then
        cat > telegram_config.json << EOF
{
  "accounts": [
    {
      "bot_token": "YOUR_BOT_TOKEN_HERE",
      "chat_id": "YOUR_CHAT_ID_HERE",
      "enabled": true
    }
  ],
  "rotation_strategy": "round_robin",
  "message_format": "html",
  "summary_interval": 86400,
  "interactive_commands": true
}
EOF
        print_warning "创建Telegram配置文件: telegram_config.json (请修改为您的Bot Token和Chat ID)"
    fi
    
    # 创建智能预警规则配置
    if [ ! -f "rules_config.json" ]; then
        cat > rules_config.json << EOF
{
  "rules": [
    {
      "name": "价格突破",
      "conditions": [
        {
          "field": "price_change_percent",
          "operator": ">",
          "value": 5
        }
      ],
      "enabled": true
    },
    {
      "name": "交易量突增",
      "conditions": [
        {
          "field": "volume_change_percent",
          "operator": ">",
          "value": 100
        }
      ],
      "enabled": true
    },
    {
      "name": "超买RSI警报",
      "conditions": [
        {
          "field": "rsi",
          "operator": ">",
          "value": 70
        }
      ],
      "enabled": true
    },
    {
      "name": "超卖RSI警报",
      "conditions": [
        {
          "field": "rsi",
          "operator": "<",
          "value": 30
        }
      ],
      "enabled": true
    }
  ]
}
EOF
        print_success "创建智能预警规则配置: rules_config.json"
    fi
}

# 创建启动脚本
create_startup_script() {
    print_info "创建启动脚本..."
    
    cat > start.sh << EOF
#!/bin/bash

# 激活虚拟环境
source venv/bin/activate

# 启动监控系统
python gate_monitor_vless.py \$@

# 如果需要后台运行，可以使用以下命令
# nohup python gate_monitor_vless.py > monitor.log 2>&1 &
EOF
    
    chmod +x start.sh
    print_success "创建启动脚本: start.sh"
    
    cat > crontab_setup.sh << EOF
#!/bin/bash

# 添加定时任务，每小时运行一次
CURRENT_DIR=\$(pwd)
(crontab -l 2>/dev/null; echo "0 * * * * cd \$CURRENT_DIR && ./start.sh --once > \$CURRENT_DIR/cron.log 2>&1") | crontab -

echo "已添加定时任务，每小时运行一次监控"
EOF
    
    chmod +x crontab_setup.sh
    print_success "创建定时任务设置脚本: crontab_setup.sh"
}

# 打包所有文件
package_files() {
    print_info "打包所有文件..."
    
    # 创建打包目录
    mkdir -p dist
    
    # 复制所有Python文件
    cp *.py dist/
    
    # 复制配置文件
    cp *.json dist/
    
    # 复制脚本
    cp *.sh dist/
    
    # 创建README
    cat > dist/README.md << EOF
# Gate.io 监控系统

## 安装说明

1. 运行安装脚本:
   \`\`\`
   ./install.sh
   \`\`\`

2. 配置Telegram:
   编辑 \`telegram_config.json\` 文件，填入您的Bot Token和Chat ID

3. 配置VLESS代理:
   编辑 \`config_vless.json\` 文件，填入您的VLESS URI

4. 启动监控:
   \`\`\`
   ./start.sh
   \`\`\`
   
   或者单次运行:
   \`\`\`
   ./start.sh --once
   \`\`\`

5. 设置定时任务:
   \`\`\`
   ./crontab_setup.sh
   \`\`\`

## 文件说明

- \`gate_monitor_vless.py\`: 主程序
- \`vless_proxy_manager.py\`: VLESS代理管理模块
- \`enhanced_coin_info.py\`: 增强币种信息采集模块
- \`smart_alerts.py\`: 智能分析与预警系统
- \`gate_telegram_push_enhanced.py\`: 增强版Telegram推送模块
- \`config_main.json\`: 主配置文件
- \`config_vless.json\`: VLESS代理配置
- \`telegram_config.json\`: Telegram配置
- \`rules_config.json\`: 智能预警规则配置

## 日志文件

- \`gate_monitor_vless.log\`: 主程序日志
- \`vless_proxy_manager.log\`: 代理管理日志
- \`enhanced_coin_info.log\`: 币种信息采集日志
- \`smart_alerts.log\`: 智能预警系统日志
- \`gate_telegram_push_enhanced.log\`: Telegram推送日志
EOF
    
    # 创建压缩包
    cd dist
    zip -r ../gate_monitor_package.zip *
    cd ..
    
    print_success "打包完成: gate_monitor_package.zip"
}

# 主函数
main() {
    echo "======================================================"
    echo "      Gate.io 监控系统一键安装脚本                    "
    echo "======================================================"
    
    check_root
    check_os
    install_system_deps
    install_v2ray
    install_python_deps
    create_config_files
    create_startup_script
    package_files
    
    echo "======================================================"
    print_success "安装完成！"
    echo "======================================================"
    echo ""
    print_info "使用说明:"
    echo "1. 编辑 telegram_config.json 文件，填入您的Bot Token和Chat ID"
    echo "2. 编辑 config_vless.json 文件，填入您的VLESS URI"
    echo "3. 运行 ./start.sh 启动监控系统"
    echo "4. 运行 ./crontab_setup.sh 设置定时任务"
    echo ""
    print_info "打包文件位置: $(pwd)/gate_monitor_package.zip"
    echo "======================================================"
}

# 执行主函数
main
