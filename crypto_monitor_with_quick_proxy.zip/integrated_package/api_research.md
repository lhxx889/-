# 交易所API与公告渠道调研结果

## Binance.US

### 行情数据API
- **基础URL**: https://api.binance.us/
- **API文档**: https://docs.binance.us/
- **主要行情接口**:
  - 24小时价格变动统计: `GET /api/v3/ticker/24hr`
    - 支持获取单个或多个交易对的24小时价格变动
    - 返回涨跌幅百分比、最高价、最低价等完整数据
  - 实时价格: `GET /api/v3/ticker/price`
    - 获取当前最新价格
  - K线数据: `GET /api/v3/klines`
    - 获取历史K线数据，支持多种时间周期
- **速率限制**: 
  - 公共API: 每10秒200次请求
  - 无需API密钥即可访问行情数据

### 公告渠道
- **官方公告页**: https://support.binance.us/en/collections/10384537-announcements
- **无专用API**: Binance.US没有提供专门的公告API
- **获取方式**: 
  - 网页爬虫抓取公告页内容
  - 可能存在RSS feed但未明确公开

## Gate.io

### 行情数据API
- **基础URL**: https://api.gateio.ws/api/v4
- **API文档**: https://www.gate.io/docs/developers/apiv4/
- **主要行情接口**:
  - Ticker信息: `GET /spot/tickers`
    - 支持获取单个或所有交易对的价格和涨跌幅
    - 返回数据包含`change_percentage`字段，直接显示涨跌百分比
  - 实时价格: 包含在ticker接口中
  - K线数据: `GET /spot/candlesticks`
    - 获取历史K线数据
- **速率限制**:
  - 公共API: 每10秒200次请求/每个端点
  - 无需API密钥即可访问行情数据

### 公告渠道
- **官方公告页**: https://www.gate.io/announcements
- **API更新公告**: https://www.gate.io/announcements/apiupdates
- **获取方式**:
  - 网页爬虫抓取公告页内容
  - 未发现专用的公告API或RSS feed

## 总结

两家交易所均提供完善的行情数据API，可直接获取币种价格和涨跌幅信息，无需API密钥。公告信息则需通过网页爬虫方式获取，两家交易所均未提供专用的公告API接口。

监控系统需要结合REST API获取行情数据，同时使用网页爬虫技术定期扫描公告页面，实现完整的监控功能。
