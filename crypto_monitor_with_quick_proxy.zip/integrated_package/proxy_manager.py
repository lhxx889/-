#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import logging
import platform
import subprocess
import requests
import socket
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('proxy_manager.log')
    ]
)

logger = logging.getLogger('proxy_manager')

class ProxyManager:
    """代理管理类，负责安装、启动、停止和测试代理服务"""
    
    def __init__(self, config=None):
        """初始化代理管理器
        
        Args:
            config: 配置字典，包含代理设置
        """
        self.config = config or {}
        self.system = platform.system().lower()
        self.arch = platform.machine().lower()
        
        # 设置路径
        self.config_dir = "/etc/sing-box"
        self.config_file = os.path.join(self.config_dir, "config.json")
        self.service_file = "/etc/systemd/system/sing-box.service"
        self.bin_path = "/usr/local/bin/sing-box"
        
        # 默认代理设置
        self.default_proxy = {
            "server": "ty.fk69.top",
            "server_port": 2026,
            "uuid": "aa05ee3d-ea0f-49e5-8692-4c4f69797110",
            "flow": "xtls-rprx-vision",
            "sni": "www.cloudflare.com",
            "public_key": "8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY",
            "short_id": ""
        }
        
        # 自定义代理设置
        self.custom_proxy = self.config.get('custom_proxy', {})
        
        # 初始化时检查代理状态
        self.proxy_status = self.get_proxy_status()
    
    def get_proxy_status(self):
        """获取代理状态
        
        Returns:
            dict: 包含安装状态和运行状态的字典
        """
        status = {
            "installed": False,
            "running": False
        }
        
        # 检查是否安装
        if self.system == "linux" or self.system == "darwin":
            # 检查多个可能的位置
            possible_paths = [
                "/usr/local/bin/sing-box",
                "/usr/bin/sing-box",
                "/bin/sing-box",
                os.path.expanduser("~/bin/sing-box")
            ]
            
            for path in possible_paths:
                if os.path.exists(path) and os.access(path, os.X_OK):
                    status["installed"] = True
                    self.bin_path = path
                    break
            
            # 检查配置文件
            if os.path.exists(self.config_file):
                status["installed"] = True
        
        # 检查是否运行
        if status["installed"]:
            if self.system == "linux":
                try:
                    # 使用systemctl检查服务状态
                    result = subprocess.run(
                        ["systemctl", "is-active", "sing-box"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True
                    )
                    if result.stdout.strip() == "active":
                        status["running"] = True
                except Exception:
                    # 尝试使用ps检查进程
                    try:
                        result = subprocess.run(
                            ["ps", "-ef"],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            text=True
                        )
                        if "sing-box" in result.stdout:
                            status["running"] = True
                    except Exception as e:
                        logger.error(f"检查代理运行状态失败: {e}")
            elif self.system == "darwin":
                try:
                    result = subprocess.run(
                        ["pgrep", "sing-box"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True
                    )
                    if result.returncode == 0:
                        status["running"] = True
                except Exception as e:
                    logger.error(f"检查代理运行状态失败: {e}")
        
        return status
    
    def install_proxy(self):
        """安装代理服务
        
        Returns:
            bool: 安装是否成功
        """
        try:
            if self.system not in ["linux", "darwin"]:
                logger.error(f"不支持的操作系统: {self.system}")
                return False
            
            # 下载并安装sing-box
            logger.info("开始安装sing-box...")
            
            # 创建临时目录
            temp_dir = os.path.expanduser("~/sing-box-temp")
            os.makedirs(temp_dir, exist_ok=True)
            
            # 下载安装脚本
            install_script = os.path.join(temp_dir, "install.sh")
            try:
                response = requests.get("https://sing-box.app/install.sh")
                with open(install_script, "w") as f:
                    f.write(response.text)
                os.chmod(install_script, 0o755)
                
                # 执行安装脚本
                result = subprocess.run(
                    ["bash", install_script],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                if result.returncode != 0:
                    logger.error(f"安装脚本执行失败: {result.stderr}")
                    return False
                
                logger.info("sing-box安装成功")
            except Exception as e:
                logger.error(f"下载或执行安装脚本失败: {e}")
                
                # 尝试直接从GitHub下载预编译二进制文件
                logger.info("尝试从GitHub下载预编译二进制文件...")
                
                # 确定架构
                arch_map = {
                    "x86_64": "amd64",
                    "amd64": "amd64",
                    "arm64": "arm64",
                    "aarch64": "arm64"
                }
                
                arch = arch_map.get(self.arch, "amd64")
                os_name = "linux" if self.system == "linux" else "darwin"
                
                # 下载最新版本
                version = "1.7.0"  # 可以改为动态获取最新版本
                download_url = f"https://github.com/SagerNet/sing-box/releases/download/v{version}/sing-box-{version}-{os_name}-{arch}.tar.gz"
                
                try:
                    # 下载文件
                    tar_file = os.path.join(temp_dir, "sing-box.tar.gz")
                    response = requests.get(download_url)
                    with open(tar_file, "wb") as f:
                        f.write(response.content)
                    
                    # 解压文件
                    extract_dir = os.path.join(temp_dir, "extract")
                    os.makedirs(extract_dir, exist_ok=True)
                    subprocess.run(
                        ["tar", "-xzf", tar_file, "-C", extract_dir],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE
                    )
                    
                    # 查找sing-box二进制文件
                    for root, _, files in os.walk(extract_dir):
                        for file in files:
                            if file == "sing-box":
                                binary_path = os.path.join(root, file)
                                # 复制到目标位置
                                os.makedirs(os.path.dirname(self.bin_path), exist_ok=True)
                                subprocess.run(
                                    ["cp", binary_path, self.bin_path],
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE
                                )
                                os.chmod(self.bin_path, 0o755)
                                logger.info(f"sing-box二进制文件已安装到 {self.bin_path}")
                                break
                except Exception as e2:
                    logger.error(f"下载预编译二进制文件失败: {e2}")
                    return False
            
            # 创建配置目录
            os.makedirs(self.config_dir, exist_ok=True)
            
            # 创建配置文件
            self.create_config_file()
            
            # 创建服务文件
            if self.system == "linux":
                service_content = f"""[Unit]
Description=sing-box service
Documentation=https://sing-box.app
After=network.target nss-lookup.target

[Service]
ExecStart={self.bin_path} run -c {self.config_file}
Restart=on-failure
RestartPreventExitStatus=23
LimitNPROC=10000
LimitNOFILE=1000000

[Install]
WantedBy=multi-user.target
"""
                with open(self.service_file, "w") as f:
                    f.write(service_content)
                
                # 重新加载systemd配置
                subprocess.run(
                    ["systemctl", "daemon-reload"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                
                # 启用服务
                subprocess.run(
                    ["systemctl", "enable", "sing-box"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            
            # 更新代理状态
            self.proxy_status = self.get_proxy_status()
            
            return True
        except Exception as e:
            logger.error(f"安装代理失败: {e}")
            return False
    
    def create_config_file(self):
        """创建代理配置文件
        
        Returns:
            bool: 创建是否成功
        """
        try:
            # 使用自定义代理设置或默认设置
            proxy = self.custom_proxy if self.custom_proxy else self.default_proxy
            
            config = {
                "inbounds": [
                    {
                        "type": "socks",
                        "tag": "socks-in",
                        "listen": "0.0.0.0",
                        "listen_port": 1080
                    },
                    {
                        "type": "http",
                        "tag": "http-in",
                        "listen": "0.0.0.0",
                        "listen_port": 7890
                    }
                ],
                "outbounds": [
                    {
                        "type": "vless",
                        "tag": "vless-out",
                        "server": proxy.get("server", self.default_proxy["server"]),
                        "server_port": proxy.get("server_port", self.default_proxy["server_port"]),
                        "uuid": proxy.get("uuid", self.default_proxy["uuid"]),
                        "flow": proxy.get("flow", self.default_proxy["flow"]),
                        "tls": {
                            "enabled": True,
                            "server_name": proxy.get("sni", self.default_proxy["sni"]),
                            "utls": {
                                "enabled": True,
                                "fingerprint": "chrome"
                            },
                            "reality": {
                                "enabled": True,
                                "public_key": proxy.get("public_key", self.default_proxy["public_key"]),
                                "short_id": proxy.get("short_id", self.default_proxy["short_id"])
                            }
                        }
                    }
                ]
            }
            
            with open(self.config_file, "w") as f:
                json.dump(config, f, indent=2)
            
            logger.info(f"配置文件已创建: {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"创建配置文件失败: {e}")
            return False
    
    def start_proxy(self):
        """启动代理服务
        
        Returns:
            bool: 启动是否成功
        """
        try:
            if not self.proxy_status["installed"]:
                logger.error("代理未安装，无法启动")
                return False
            
            if self.system == "linux":
                result = subprocess.run(
                    ["systemctl", "start", "sing-box"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                if result.returncode != 0:
                    logger.error(f"启动代理服务失败: {result.stderr}")
                    return False
            elif self.system == "darwin":
                # macOS上直接运行sing-box
                subprocess.Popen(
                    [self.bin_path, "run", "-c", self.config_file],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            
            # 等待服务启动
            time.sleep(2)
            
            # 更新代理状态
            self.proxy_status = self.get_proxy_status()
            
            if self.proxy_status["running"]:
                logger.info("代理服务启动成功")
                return True
            else:
                logger.error("代理服务启动失败")
                return False
        except Exception as e:
            logger.error(f"启动代理服务失败: {e}")
            return False
    
    def stop_proxy(self):
        """停止代理服务
        
        Returns:
            bool: 停止是否成功
        """
        try:
            if not self.proxy_status["installed"]:
                logger.error("代理未安装，无法停止")
                return False
            
            if not self.proxy_status["running"]:
                logger.info("代理服务已经停止")
                return True
            
            if self.system == "linux":
                result = subprocess.run(
                    ["systemctl", "stop", "sing-box"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                if result.returncode != 0:
                    logger.error(f"停止代理服务失败: {result.stderr}")
                    return False
            elif self.system == "darwin":
                # macOS上使用pkill停止sing-box
                subprocess.run(
                    ["pkill", "sing-box"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
            
            # 等待服务停止
            time.sleep(2)
            
            # 更新代理状态
            self.proxy_status = self.get_proxy_status()
            
            if not self.proxy_status["running"]:
                logger.info("代理服务停止成功")
                return True
            else:
                logger.error("代理服务停止失败")
                return False
        except Exception as e:
            logger.error(f"停止代理服务失败: {e}")
            return False
    
    def test_proxy_connection(self):
        """测试代理连接
        
        Returns:
            bool: 连接是否成功
        """
        try:
            if not self.proxy_status["installed"]:
                logger.error("代理未安装，无法测试连接")
                return False
            
            if not self.proxy_status["running"]:
                logger.error("代理服务未运行，无法测试连接")
                return False
            
            # 测试SOCKS5代理
            try:
                # 设置超时
                socket.setdefaulttimeout(10)
                
                # 创建代理会话
                proxies = {
                    "http": "socks5://127.0.0.1:1080",
                    "https": "socks5://127.0.0.1:1080"
                }
                
                # 测试连接
                response = requests.get("https://api.coingecko.com/api/v3/ping", proxies=proxies)
                
                if response.status_code == 200:
                    logger.info("代理连接测试成功")
                    return True
                else:
                    logger.error(f"代理连接测试失败: HTTP状态码 {response.status_code}")
                    return False
            except Exception as e:
                logger.error(f"SOCKS5代理测试失败: {e}")
                
                # 尝试HTTP代理
                try:
                    proxies = {
                        "http": "http://127.0.0.1:7890",
                        "https": "http://127.0.0.1:7890"
                    }
                    
                    response = requests.get("https://api.coingecko.com/api/v3/ping", proxies=proxies)
                    
                    if response.status_code == 200:
                        logger.info("HTTP代理连接测试成功")
                        return True
                    else:
                        logger.error(f"HTTP代理连接测试失败: HTTP状态码 {response.status_code}")
                        return False
                except Exception as e2:
                    logger.error(f"HTTP代理测试失败: {e2}")
                    return False
        except Exception as e:
            logger.error(f"测试代理连接失败: {e}")
            return False
    
    def apply_proxy_settings(self):
        """应用代理设置到系统配置
        
        Returns:
            bool: 应用是否成功
        """
        try:
            if not self.proxy_status["installed"]:
                logger.error("代理未安装，无法应用设置")
                return False
            
            if not self.proxy_status["running"]:
                logger.error("代理服务未运行，无法应用设置")
                return False
            
            # 更新配置
            if self.config:
                self.config["proxy"] = {
                    "enabled": True,
                    "type": "socks5",
                    "host": "127.0.0.1",
                    "port": 1080
                }
                
                # 保存配置
                config_file = self.config.get("config_file")
                if config_file and os.path.exists(config_file):
                    with open(config_file, "w") as f:
                        json.dump(self.config, f, indent=2)
                
                logger.info("代理设置已应用到配置")
                return True
            else:
                logger.error("无法应用代理设置：配置对象为空")
                return False
        except Exception as e:
            logger.error(f"应用代理设置失败: {e}")
            return False
    
    # 添加兼容性方法，解决方法名不匹配问题
    def apply_proxy_to_config(self):
        """兼容性方法，调用apply_proxy_settings"""
        return self.apply_proxy_settings()
    
    def set_custom_proxy(self, proxy_settings):
        """设置自定义代理
        
        Args:
            proxy_settings: 代理设置字典
        
        Returns:
            bool: 设置是否成功
        """
        try:
            # 验证必要的字段
            required_fields = ["server", "server_port", "uuid"]
            for field in required_fields:
                if field not in proxy_settings:
                    logger.error(f"缺少必要的代理设置字段: {field}")
                    return False
            
            # 更新自定义代理设置
            self.custom_proxy = proxy_settings
            
            # 如果代理已安装，更新配置文件
            if self.proxy_status["installed"]:
                # 停止代理服务
                if self.proxy_status["running"]:
                    self.stop_proxy()
                
                # 更新配置文件
                self.create_config_file()
                
                # 重新启动代理服务
                self.start_proxy()
            
            logger.info("自定义代理设置已更新")
            return True
        except Exception as e:
            logger.error(f"设置自定义代理失败: {e}")
            return False

# 命令行测试
if __name__ == "__main__":
    proxy_manager = ProxyManager()
    
    print("代理状态:", proxy_manager.proxy_status)
    
    if not proxy_manager.proxy_status["installed"]:
        print("安装代理...")
        proxy_manager.install_proxy()
    
    if not proxy_manager.proxy_status["running"]:
        print("启动代理...")
        proxy_manager.start_proxy()
    
    print("测试代理连接...")
    proxy_manager.test_proxy_connection()
