# 交易所监控系统使用说明 - 增强版

## 系统概述

本系统用于监控币安美国(Binance.US)和Gate.io交易所的币种涨跌幅，并定期扫描两家交易所的公告和新上币信息，实现自动化监控和通知功能。最新增强版本增加了币种详细资料、上海时间显示和币种信息查询功能，让您可以获取更全面的币种信息，并通过简单的交互式菜单操作所有功能。

## 主要功能

1. **币种价格监控**
   - 实时获取Binance.US和Gate.io所有币种的价格和涨跌幅数据
   - 支持设置涨跌幅阈值，超过阈值时触发通知
   - 自动记录显著价格变动，便于后续分析

2. **公告和新上币扫描**
   - 定期扫描交易所的公告页面
   - 智能识别新上币公告并优先提醒
   - 记录历史公告，避免重复通知

3. **Telegram实时推送**
   - 价格变动实时推送到Telegram，包含币种详细资料
   - 新公告即时通知，显示上海时间
   - 支持批量推送模式，减少消息打扰
   - 可单独设置价格推送阈值，过滤低波动率信息

4. **币种信息查询**
   - 通过名称、符号或ID搜索币种
   - 查看币种详细资料（市值、交易量、流通量等）
   - 显示历史价格数据和相关链接
   - 所有时间统一显示为上海时间（UTC+8）

5. **交互式主菜单**
   - 通过简单按键快速配置所有参数
   - 一键启动/停止监控
   - 实时查看系统状态和日志
   - 所有配置自动保存，重启后仍然有效

## 系统要求

- Python 3.6+
- 必要的Python库：requests, beautifulsoup4, pytz
- Telegram账号和机器人Token（如需使用推送功能）

## 安装步骤

1. 确保系统已安装Python 3.6或更高版本
2. 安装必要的Python库：
   ```
   pip install requests beautifulsoup4 pytz
   ```
3. 如需使用代理功能，还需安装socks支持：
   ```
   pip install requests[socks]
   ```
4. 将所有脚本文件放置在同一目录下
5. 确保主脚本有执行权限：
   ```
   chmod +x crypto_monitor_menu_enhanced.py
   chmod +x crypto_monitor_backend.py
   ```

## 使用方法

### 启动交互式主菜单

只需运行增强版主菜单脚本：

```
./crypto_monitor_menu_enhanced.py
```

### 主菜单功能

增强版主菜单提供以下功能选项：

1. **启动/停止监控**
   - 一键启动或停止监控系统
   - 显示当前监控状态和上海时间

2. **配置Telegram推送**
   - 启用/禁用Telegram推送
   - 设置机器人Token和聊天ID
   - 配置推送选项（价格、公告、阈值等）
   - 测试Telegram连接

3. **设置价格监控参数**
   - 调整价格涨跌幅阈值
   - 设置价格检查间隔
   - 启用/禁用特定交易所监控

4. **设置公告扫描参数**
   - 启用/禁用公告扫描
   - 调整公告扫描间隔

5. **配置代理设置**
   - 启用/禁用代理
   - 设置HTTP和HTTPS代理

6. **币种信息查询**
   - 搜索币种（按名称、符号或ID）
   - 查看币种详细资料
   - 显示市值、交易量、流通量等信息
   - 查看历史价格数据和相关链接

7. **显示设置**
   - 启用/禁用上海时间显示
   - 启用/禁用币种详细信息显示

8. **查看当前配置**
   - 显示所有当前配置参数

9. **查看监控日志**
   - 查看最近的监控日志

0. **退出程序**
   - 安全退出系统

### 币种信息查询

增强版系统提供了强大的币种信息查询功能：

1. 在主菜单中选择"币种信息查询"
2. 输入币种名称、符号或ID进行搜索（例如：bitcoin, btc, ethereum）
3. 从搜索结果列表中选择要查看的币种
4. 系统将显示币种的详细信息，包括：
   - 基本信息（名称、符号、排名）
   - 价格信息（当前价格、24小时/7天/30天变化）
   - 市值信息（市值、交易量、流通量、总供应量）
   - 历史高低点
   - 相关链接（官网、区块浏览器、GitHub）
   - 币种简介
   - 当前上海时间

### 增强版推送内容

增强版系统的Telegram推送内容更加丰富：

1. **价格变动推送**：
   ```
   🟢 Binance.US - BTCUSDT 上涨 12.34%
   💰 当前价格: 65000.0
   🏦 市值: $1,234,567,890
   📊 24h交易量: $45,678,901,234
   🔄 流通量: 19,000,000 BTC
   🔗 CoinGecko详情: https://www.coingecko.com/en/coins/bitcoin
   🕒 时间: 2025-06-05 13:04:22 CST+0800
   ```

2. **公告推送**：
   ```
   📢 Binance.US - 系统维护通知
   📅 公告日期: 2025-06-04 12:00:00 CST+0800
   🔗 链接: https://support.binance.us/...
   🕒 发现时间: 2025-06-05 13:04:22 CST+0800
   ```

3. **新上币公告**：
   ```
   🔔 Gate.io - [新上币] Gate.io将上线XXX代币
   📅 公告日期: 2025-06-04 12:00:00 CST+0800
   🔗 链接: https://www.gate.io/...
   🕒 发现时间: 2025-06-05 13:04:22 CST+0800
   ```

### 配置保存

所有通过主菜单进行的配置都会自动保存到`config.json`文件中，系统重启后会自动加载这些配置，无需重复设置。

## Telegram机器人配置

要使用Telegram推送功能，您需要先创建一个Telegram机器人并获取必要的Token和聊天ID：

### 1. 创建Telegram机器人

1. 在Telegram中搜索 `@BotFather` 并开始对话
2. 发送 `/newbot` 命令创建新机器人
3. 按照提示设置机器人名称和用户名
4. 创建成功后，BotFather会发送一个API Token给您，格式类似：`123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ`
5. 在主菜单中选择"配置Telegram推送"，然后输入此Token

### 2. 获取聊天ID

方法一：通过 @userinfobot 获取
1. 在Telegram中搜索 `@userinfobot` 并开始对话
2. 机器人会自动回复您的用户ID，这就是您的聊天ID
3. 在主菜单中选择"配置Telegram推送"，然后输入此聊天ID

方法二：通过API获取
1. 首先向您创建的机器人发送一条消息
2. 在浏览器中访问：`https://api.telegram.org/bot<您的TOKEN>/getUpdates`
   (将`<您的TOKEN>`替换为实际的机器人Token)
3. 在返回的JSON数据中找到 `message.chat.id` 字段，这就是您的聊天ID

## 设置为系统服务

### Linux (systemd)

创建服务文件：

```
sudo nano /etc/systemd/system/crypto-monitor.service
```

添加以下内容：

```
[Unit]
Description=Cryptocurrency Exchange Monitor Enhanced
After=network.target

[Service]
ExecStart=/path/to/crypto_monitor_backend.py --config /path/to/config.json
WorkingDirectory=/path/to/script/directory
User=yourusername
Restart=on-failure
RestartSec=30s

[Install]
WantedBy=multi-user.target
```

启用并启动服务：

```
sudo systemctl enable crypto-monitor.service
sudo systemctl start crypto-monitor.service
```

查看服务状态：

```
sudo systemctl status crypto-monitor.service
```

### Windows (任务计划程序)

1. 打开任务计划程序
2. 创建基本任务
3. 触发器选择"计算机启动时"
4. 操作选择"启动程序"
5. 程序/脚本选择Python解释器路径
6. 添加参数：完整路径到`crypto_monitor_backend.py --config 配置文件路径`
7. 完成配置并保存

## 故障排除

### 币种信息查询相关问题

1. **搜索结果为空**:
   - 确保输入的名称、符号或ID正确
   - 尝试使用更通用的关键词
   - 检查网络连接和代理设置

2. **无法获取币种详情**:
   - 可能是CoinGecko API限制，等待一段时间后重试
   - 检查网络连接和代理设置
   - 尝试使用代理功能绕过限制

3. **上海时间显示错误**:
   - 确保系统已安装pytz库
   - 检查系统时间是否正确

### 主菜单相关问题

1. **菜单显示异常**:
   - 确保终端支持ANSI转义序列
   - 尝试调整终端窗口大小

2. **无法启动监控**:
   - 检查Python路径是否正确
   - 确保crypto_monitor_backend.py文件存在且有执行权限
   - 查看日志文件了解详细错误信息

3. **配置无法保存**:
   - 确保脚本目录有写入权限
   - 检查config.json文件是否可写

### Telegram相关问题

1. **无法发送消息**:
   - 使用主菜单中的"测试Telegram连接"功能
   - 检查Token和聊天ID是否正确
   - 确保您已经向机器人发送过至少一条消息
   - 检查网络连接和代理设置

2. **消息格式错误**:
   - Telegram的Markdown解析有时会失败，尤其是当消息中包含特殊字符时
   - 如果发现格式问题，可以查看日志中的错误信息

### 其他常见问题

1. **无法获取数据**:
   - 检查网络连接
   - 检查API端点是否变更
   - 查看日志文件了解详细错误信息

2. **公告扫描403错误**:
   - 使用主菜单启用代理功能
   - 确保代理服务正常运行
   - 减少请求频率（增加公告扫描间隔）

3. **CoinGecko API限制**:
   - CoinGecko免费API有请求频率限制
   - 如果遇到限制，可以等待一段时间后重试
   - 考虑使用代理或减少请求频率

## 安全注意事项

1. **Token安全**:
   - 请妥善保管您的Telegram机器人Token，不要泄露给他人
   - 如果怀疑Token泄露，请通过@BotFather重新生成

2. **配置文件安全**:
   - config.json文件包含敏感信息，请确保其权限设置正确
   - 在共享环境中使用时，考虑加密存储敏感信息

3. **代理安全**:
   - 使用可信的代理服务
   - 定期更新代理配置

## 注意事项

1. **API使用限制**:
   - CoinGecko免费API有请求频率限制，过于频繁的请求可能导致暂时被封禁
   - 建议将价格检查间隔设置为至少5分钟，公告扫描间隔设置为至少1小时

2. **上海时间显示**:
   - 所有时间默认显示为上海时间（UTC+8）
   - 可以在"显示设置"中禁用上海时间显示

3. **币种详情数据**:
   - 币种详情数据来自CoinGecko API，可能存在延迟
   - 部分币种可能缺少某些信息（如市值、流通量等）

4. **系统资源使用**:
   - 长时间运行可能占用一定系统资源
   - 如果在资源受限的设备上运行，建议增加检查间隔时间
