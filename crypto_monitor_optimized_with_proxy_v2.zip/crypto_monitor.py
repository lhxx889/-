#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交易所监控系统主控脚本
整合Binance.US和Gate.io的价格监控与公告扫描功能
"""

import argparse
import logging
import os
import sys
import time
import threading
import json
from datetime import datetime

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入模块，如果失败则提示安装
try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("缺少必要的Python库。请运行以下命令安装：")
    print("pip install requests beautifulsoup4")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "crypto_monitor.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("crypto_monitor")

# 全局配置
CONFIG = {
    "price_change_threshold": 5.0,  # 涨跌幅阈值，百分比
    "price_check_interval": 300,    # 价格检查间隔，秒（5分钟）
    "announcement_scan_interval": 3600,  # 公告扫描间隔，秒（1小时）
    "use_proxy": False,             # 是否使用代理
    "proxy": {                      # 代理配置
        "http": "socks5://127.0.0.1:1080",
        "https": "socks5://127.0.0.1:1080"
    },
    "binance_enabled": True,        # 是否启用Binance.US监控
    "gate_enabled": True,           # 是否启用Gate.io监控
    "announcement_enabled": True,   # 是否启用公告扫描
    "data_dir": os.path.join(script_dir, "data")  # 数据存储目录
}

# API端点
BINANCE_BASE_URL = "https://api.binance.us"
BINANCE_TICKER_ENDPOINT = "/api/v3/ticker/24hr"
BINANCE_ANNOUNCEMENT_URL = "https://support.binance.us/en/collections/10384537-announcements"

GATE_BASE_URL = "https://api.gateio.ws/api/v4"
GATE_TICKER_ENDPOINT = "/spot/tickers"
GATE_ANNOUNCEMENT_URL = "https://www.gate.io/announcements"
GATE_API_ANNOUNCEMENT_URL = "https://www.gate.io/announcements/apiupdates"

# 新上币关键词
NEW_LISTINGS_KEYWORDS = ["listing", "新上币", "new coin", "new token", "will list", "上线"]

# 确保数据目录存在
if not os.path.exists(CONFIG["data_dir"]):
    os.makedirs(CONFIG["data_dir"])

# 文件路径
PRICE_CHANGES_FILE = os.path.join(CONFIG["data_dir"], "significant_price_changes.json")
ANNOUNCEMENT_HISTORY_FILE = os.path.join(CONFIG["data_dir"], "announcement_history.json")
NEW_ANNOUNCEMENTS_FILE = os.path.join(CONFIG["data_dir"], "new_announcements.json")

# 存储上次检查的价格，用于比较变化
last_prices = {}

def fetch_binance_tickers():
    """获取Binance.US所有交易对的24小时价格变动数据"""
    try:
        url = f"{BINANCE_BASE_URL}{BINANCE_TICKER_ENDPOINT}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        tickers = response.json()
        logger.info(f"成功获取Binance.US {len(tickers)} 个交易对数据")
        return tickers
    
    except requests.exceptions.RequestException as e:
        logger.error(f"获取Binance.US数据失败: {e}")
        return []

def process_binance_tickers(tickers):
    """处理Binance.US的ticker数据，识别超过阈值的价格变动"""
    significant_changes = []
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    for ticker in tickers:
        symbol = ticker['symbol']
        price = float(ticker['lastPrice'])
        price_change_percent = float(ticker['priceChangePercent'])
        
        # 检查是否超过阈值
        if abs(price_change_percent) >= CONFIG["price_change_threshold"]:
            change_direction = "上涨" if price_change_percent > 0 else "下跌"
            significant_changes.append({
                "exchange": "Binance.US",
                "symbol": symbol,
                "price": price,
                "change_percent": price_change_percent,
                "direction": change_direction,
                "time": current_time
            })
            
            logger.info(f"Binance.US - {symbol} {change_direction} {abs(price_change_percent):.2f}%, 当前价格: {price}")
        
        # 更新上次价格记录
        last_prices[f"binance_{symbol}"] = price
    
    return significant_changes

def fetch_gate_tickers():
    """获取Gate.io所有交易对的价格和涨跌幅数据"""
    try:
        url = f"{GATE_BASE_URL}{GATE_TICKER_ENDPOINT}"
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        tickers = response.json()
        logger.info(f"成功获取Gate.io {len(tickers)} 个交易对数据")
        return tickers
    
    except requests.exceptions.RequestException as e:
        logger.error(f"获取Gate.io数据失败: {e}")
        return []

def process_gate_tickers(tickers):
    """处理Gate.io的ticker数据，识别超过阈值的价格变动"""
    significant_changes = []
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    for ticker in tickers:
        symbol = ticker['currency_pair']
        price = float(ticker['last'])
        
        # Gate.io的API返回的change_percentage格式为"-8.91"（字符串）
        try:
            price_change_percent = float(ticker['change_percentage'])
        except (ValueError, KeyError):
            # 如果无法获取涨跌幅，则跳过
            continue
        
        # 检查是否超过阈值
        if abs(price_change_percent) >= CONFIG["price_change_threshold"]:
            change_direction = "上涨" if price_change_percent > 0 else "下跌"
            significant_changes.append({
                "exchange": "Gate.io",
                "symbol": symbol,
                "price": price,
                "change_percent": price_change_percent,
                "direction": change_direction,
                "time": current_time
            })
            
            logger.info(f"Gate.io - {symbol} {change_direction} {abs(price_change_percent):.2f}%, 当前价格: {price}")
        
        # 更新上次价格记录
        last_prices[f"gate_{symbol}"] = price
    
    return significant_changes

def save_significant_changes(changes):
    """保存显著价格变动到文件"""
    if not changes:
        return
    
    try:
        # 读取现有数据
        try:
            with open(PRICE_CHANGES_FILE, "r") as f:
                existing_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        # 添加新数据
        existing_data.extend(changes)
        
        # 写回文件
        with open(PRICE_CHANGES_FILE, "w") as f:
            json.dump(existing_data, f, indent=2)
        
        logger.info(f"已保存 {len(changes)} 条显著价格变动记录")
    
    except Exception as e:
        logger.error(f"保存价格变动记录失败: {e}")

def monitor_prices():
    """监控价格变动的主函数"""
    logger.info("开始监控价格变动...")
    
    try:
        significant_changes = []
        
        # 获取并处理Binance.US数据
        if CONFIG["binance_enabled"]:
            binance_tickers = fetch_binance_tickers()
            if binance_tickers:
                binance_changes = process_binance_tickers(binance_tickers)
                significant_changes.extend(binance_changes)
        
        # 获取并处理Gate.io数据
        if CONFIG["gate_enabled"]:
            gate_tickers = fetch_gate_tickers()
            if gate_tickers:
                gate_changes = process_gate_tickers(gate_tickers)
                significant_changes.extend(gate_changes)
        
        # 保存显著变动
        save_significant_changes(significant_changes)
        
        return len(significant_changes)
    
    except Exception as e:
        logger.error(f"监控过程中发生错误: {e}")
        return 0

def get_page_content(url):
    """获取网页内容"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        # 是否使用代理
        proxies = CONFIG["proxy"] if CONFIG["use_proxy"] else None
        
        response = requests.get(url, headers=headers, proxies=proxies, timeout=15)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"获取网页内容失败: {url}, 错误: {e}")
        return None

def parse_binance_announcements(html_content):
    """解析Binance.US公告页面"""
    if not html_content:
        return []
    
    announcements = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 根据实际页面结构调整选择器
        articles = soup.select('article.article-list-item')
        
        for article in articles:
            try:
                title_element = article.select_one('h3.article-list-item-title')
                link_element = article.select_one('a')
                date_element = article.select_one('time')
                
                if title_element and link_element:
                    title = title_element.text.strip()
                    link = link_element.get('href')
                    if not link.startswith('http'):
                        link = f"https://support.binance.us{link}"
                    
                    date = date_element.text.strip() if date_element else "未知日期"
                    
                    import hashlib
                    announcement = {
                        "exchange": "Binance.US",
                        "title": title,
                        "url": link,
                        "date": date,
                        "id": hashlib.md5(f"{title}_{link}".encode()).hexdigest(),
                        "is_new_listing": any(keyword.lower() in title.lower() for keyword in NEW_LISTINGS_KEYWORDS)
                    }
                    announcements.append(announcement)
            except Exception as e:
                logger.error(f"解析Binance.US公告项目时出错: {e}")
        
        logger.info(f"成功解析 {len(announcements)} 条Binance.US公告")
    except Exception as e:
        logger.error(f"解析Binance.US公告页面失败: {e}")
    
    return announcements

def parse_gate_announcements(html_content):
    """解析Gate.io公告页面"""
    if not html_content:
        return []
    
    announcements = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 根据实际页面结构调整选择器
        articles = soup.select('div.article-item') or soup.select('div.announcement-item')
        
        for article in articles:
            try:
                title_element = article.select_one('h3') or article.select_one('div.title')
                link_element = article.select_one('a')
                date_element = article.select_one('time') or article.select_one('div.date')
                
                if title_element and link_element:
                    title = title_element.text.strip()
                    link = link_element.get('href')
                    if not link.startswith('http'):
                        link = f"https://www.gate.io{link}"
                    
                    date = date_element.text.strip() if date_element else "未知日期"
                    
                    import hashlib
                    announcement = {
                        "exchange": "Gate.io",
                        "title": title,
                        "url": link,
                        "date": date,
                        "id": hashlib.md5(f"{title}_{link}".encode()).hexdigest(),
                        "is_new_listing": any(keyword.lower() in title.lower() for keyword in NEW_LISTINGS_KEYWORDS)
                    }
                    announcements.append(announcement)
            except Exception as e:
                logger.error(f"解析Gate.io公告项目时出错: {e}")
        
        logger.info(f"成功解析 {len(announcements)} 条Gate.io公告")
    except Exception as e:
        logger.error(f"解析Gate.io公告页面失败: {e}")
    
    return announcements

def load_announcement_history():
    """加载历史公告记录"""
    if not os.path.exists(ANNOUNCEMENT_HISTORY_FILE):
        return []
    
    try:
        with open(ANNOUNCEMENT_HISTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"加载历史公告记录失败: {e}")
        return []

def save_announcement_history(announcements):
    """保存公告历史记录"""
    try:
        with open(ANNOUNCEMENT_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(announcements, f, ensure_ascii=False, indent=2)
        logger.info(f"已保存 {len(announcements)} 条公告历史记录")
    except Exception as e:
        logger.error(f"保存公告历史记录失败: {e}")

def filter_new_announcements(all_announcements, history):
    """过滤出新公告"""
    history_ids = {item['id'] for item in history}
    new_announcements = [item for item in all_announcements if item['id'] not in history_ids]
    return new_announcements

def notify_new_announcements(new_announcements):
    """通知新公告"""
    if not new_announcements:
        logger.info("没有发现新公告")
        return
    
    # 分离新上币公告和普通公告
    new_listings = [a for a in new_announcements if a['is_new_listing']]
    regular_announcements = [a for a in new_announcements if not a['is_new_listing']]
    
    # 记录到日志
    if new_listings:
        logger.info(f"发现 {len(new_listings)} 条新上币公告:")
        for announcement in new_listings:
            logger.info(f"[新上币] {announcement['exchange']} - {announcement['title']} - {announcement['url']}")
    
    if regular_announcements:
        logger.info(f"发现 {len(regular_announcements)} 条普通公告:")
        for announcement in regular_announcements:
            logger.info(f"{announcement['exchange']} - {announcement['title']} - {announcement['url']}")
    
    # 保存到文件
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    try:
        # 读取现有数据
        try:
            with open(NEW_ANNOUNCEMENTS_FILE, "r", encoding='utf-8') as f:
                existing_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        # 添加新数据
        for announcement in new_announcements:
            announcement['discovery_time'] = current_time
            existing_data.append(announcement)
        
        # 写回文件
        with open(NEW_ANNOUNCEMENTS_FILE, "w", encoding='utf-8') as f:
            json.dump(existing_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"已保存 {len(new_announcements)} 条新公告记录")
    
    except Exception as e:
        logger.error(f"保存新公告记录失败: {e}")

def scan_announcements():
    """扫描公告的主函数"""
    logger.info("开始扫描交易所公告...")
    
    try:
        # 加载历史记录
        history = load_announcement_history()
        all_announcements = []
        
        # 获取Binance.US公告
        if CONFIG["binance_enabled"]:
            binance_html = get_page_content(BINANCE_ANNOUNCEMENT_URL)
            binance_announcements = parse_binance_announcements(binance_html)
            all_announcements.extend(binance_announcements)
        
        # 获取Gate.io公告
        if CONFIG["gate_enabled"]:
            gate_html = get_page_content(GATE_ANNOUNCEMENT_URL)
            gate_announcements = parse_gate_announcements(gate_html)
            all_announcements.extend(gate_announcements)
            
            # 获取Gate.io API公告
            gate_api_html = get_page_content(GATE_API_ANNOUNCEMENT_URL)
            gate_api_announcements = parse_gate_announcements(gate_api_html)
            all_announcements.extend(gate_api_announcements)
        
        # 过滤新公告
        new_announcements = filter_new_announcements(all_announcements, history)
        
        # 通知新公告
        notify_new_announcements(new_announcements)
        
        # 更新历史记录
        history.extend(new_announcements)
        save_announcement_history(history)
        
        return len(new_announcements)
    
    except Exception as e:
        logger.error(f"扫描公告过程中发生错误: {e}")
        return 0

def price_monitor_thread():
    """价格监控线程"""
    while True:
        try:
            changes_count = monitor_prices()
            logger.info(f"本次监控发现 {changes_count} 个显著价格变动")
            logger.info(f"等待 {CONFIG['price_check_interval']} 秒后进行下一次价格检查...")
            time.sleep(CONFIG["price_check_interval"])
        except KeyboardInterrupt:
            logger.info("价格监控线程被手动终止")
            break
        except Exception as e:
            logger.error(f"价格监控线程异常: {e}")
            time.sleep(60)  # 出错后等待一分钟再重试

def announcement_scanner_thread():
    """公告扫描线程"""
    while True:
        try:
            new_count = scan_announcements()
            logger.info(f"本次扫描发现 {new_count} 条新公告")
            logger.info(f"等待 {CONFIG['announcement_scan_interval']} 秒后进行下一次公告扫描...")
            time.sleep(CONFIG["announcement_scan_interval"])
        except KeyboardInterrupt:
            logger.info("公告扫描线程被手动终止")
            break
        except Exception as e:
            logger.error(f"公告扫描线程异常: {e}")
            time.sleep(60)  # 出错后等待一分钟再重试

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='交易所监控系统')
    
    parser.add_argument('--threshold', type=float, default=CONFIG["price_change_threshold"],
                        help=f'价格涨跌幅阈值，百分比 (默认: {CONFIG["price_change_threshold"]})')
    
    parser.add_argument('--price-interval', type=int, default=CONFIG["price_check_interval"],
                        help=f'价格检查间隔，秒 (默认: {CONFIG["price_check_interval"]})')
    
    parser.add_argument('--announcement-interval', type=int, default=CONFIG["announcement_scan_interval"],
                        help=f'公告扫描间隔，秒 (默认: {CONFIG["announcement_scan_interval"]})')
    
    parser.add_argument('--proxy', action='store_true',
                        help='使用代理 (默认: 不使用)')
    
    parser.add_argument('--no-binance', action='store_true',
                        help='禁用Binance.US监控 (默认: 启用)')
    
    parser.add_argument('--no-gate', action='store_true',
                        help='禁用Gate.io监控 (默认: 启用)')
    
    parser.add_argument('--no-announcement', action='store_true',
                        help='禁用公告扫描 (默认: 启用)')
    
    parser.add_argument('--price-only', action='store_true',
                        help='仅运行价格监控 (默认: 全部运行)')
    
    parser.add_argument('--announcement-only', action='store_true',
                        help='仅运行公告扫描 (默认: 全部运行)')
    
    parser.add_argument('--data-dir', type=str, default=CONFIG["data_dir"],
                        help=f'数据存储目录 (默认: {CONFIG["data_dir"]})')
    
    return parser.parse_args()

def update_config_from_args(args):
    """根据命令行参数更新配置"""
    CONFIG["price_change_threshold"] = args.threshold
    CONFIG["price_check_interval"] = args.price_interval
    CONFIG["announcement_scan_interval"] = args.announcement_interval
    CONFIG["use_proxy"] = args.proxy
    CONFIG["binance_enabled"] = not args.no_binance
    CONFIG["gate_enabled"] = not args.no_gate
    CONFIG["announcement_enabled"] = not args.no_announcement
    CONFIG["data_dir"] = args.data_dir
    
    # 处理互斥选项
    if args.price_only:
        CONFIG["announcement_enabled"] = False
    if args.announcement_only:
        CONFIG["binance_enabled"] = False
        CONFIG["gate_enabled"] = False
    
    # 更新文件路径
    global PRICE_CHANGES_FILE, ANNOUNCEMENT_HISTORY_FILE, NEW_ANNOUNCEMENTS_FILE
    PRICE_CHANGES_FILE = os.path.join(CONFIG["data_dir"], "significant_price_changes.json")
    ANNOUNCEMENT_HISTORY_FILE = os.path.join(CONFIG["data_dir"], "announcement_history.json")
    NEW_ANNOUNCEMENTS_FILE = os.path.join(CONFIG["data_dir"], "new_announcements.json")
    
    # 确保数据目录存在
    if not os.path.exists(CONFIG["data_dir"]):
        os.makedirs(CONFIG["data_dir"])

def main():
    """主函数"""
    # 解析命令行参数
    args = parse_arguments()
    update_config_from_args(args)
    
    # 打印启动配置
    logger.info("交易所监控系统启动")
    logger.info(f"价格涨跌幅阈值: {CONFIG['price_change_threshold']}%")
    logger.info(f"价格检查间隔: {CONFIG['price_check_interval']}秒")
    logger.info(f"公告扫描间隔: {CONFIG['announcement_scan_interval']}秒")
    logger.info(f"使用代理: {'是' if CONFIG['use_proxy'] else '否'}")
    logger.info(f"启用Binance.US监控: {'是' if CONFIG['binance_enabled'] else '否'}")
    logger.info(f"启用Gate.io监控: {'是' if CONFIG['gate_enabled'] else '否'}")
    logger.info(f"启用公告扫描: {'是' if CONFIG['announcement_enabled'] else '否'}")
    logger.info(f"数据存储目录: {CONFIG['data_dir']}")
    
    threads = []
    
    # 启动价格监控线程
    if CONFIG["binance_enabled"] or CONFIG["gate_enabled"]:
        price_thread = threading.Thread(target=price_monitor_thread, daemon=True)
        price_thread.start()
        threads.append(price_thread)
        logger.info("价格监控线程已启动")
    
    # 启动公告扫描线程
    if CONFIG["announcement_enabled"]:
        announcement_thread = threading.Thread(target=announcement_scanner_thread, daemon=True)
        announcement_thread.start()
        threads.append(announcement_thread)
        logger.info("公告扫描线程已启动")
    
    try:
        # 等待所有线程完成（实际上不会完成，除非被中断）
        for thread in threads:
            thread.join()
    except KeyboardInterrupt:
        logger.info("程序被手动终止")
    except Exception as e:
        logger.error(f"程序异常终止: {e}")
    finally:
        logger.info("交易所监控系统已停止")

if __name__ == "__main__":
    main()
