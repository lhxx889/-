#!/bin/bash
set -e

APP_DIR="$HOME/crypto_monitor"
SRC="$APP_DIR/gate_monitor_bot_full_advanced.py"
ENV_FILE="$APP_DIR/.env"
SERVICE_FILE="/etc/systemd/system/crypto_monitor.service"
LOG_DIR="$APP_DIR/logs"
PYTHON_BIN=$(which python3 || echo "/usr/bin/python3")

echo "🔍 检测系统环境..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
else
    echo "❌ 无法检测系统类型"
    exit 1
fi

echo "📦 安装依赖中..."
if [[ "$OS" == "ubuntu" || "$OS" == "debian" ]]; then
    sudo apt update
    sudo apt install -y python3 python3-pip curl
elif [[ "$OS" == "centos" || "$OS" == "rhel" ]]; then
    sudo yum install -y python3 python3-pip curl
else
    echo "❌ 不支持的系统：$OS"
    exit 1
fi

pip3 install --user requests tenacity

echo "📁 创建程序目录..."
mkdir -p "$APP_DIR" "$LOG_DIR"
cp gate_monitor_bot_full_advanced.py "$SRC"

# Create .env if not exists
if [ ! -f "$ENV_FILE" ]; then
    echo "📝 初始化 Telegram 配置..."
    read -p "请输入你的 TELEGRAM_BOT_TOKEN: " BOT_TOKEN
    read -p "请输入你的 TELEGRAM_CHAT_ID: " CHAT_ID
    echo "TELEGRAM_BOT_TOKEN=$BOT_TOKEN" > "$ENV_FILE"
    echo "TELEGRAM_CHAT_ID=$CHAT_ID" >> "$ENV_FILE"
else
    echo "✅ 已找到配置文件 .env，跳过输入。"
fi

# Create systemd service
echo "⚙️ 创建守护进程服务..."
sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=Crypto Monitor Bot
After=network.target

[Service]
ExecStart=$PYTHON_BIN $SRC
WorkingDirectory=$APP_DIR
EnvironmentFile=$ENV_FILE
Restart=always
StandardOutput=append:$LOG_DIR/monitor.log
StandardError=append:$LOG_DIR/monitor.log

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable crypto_monitor
sudo systemctl restart crypto_monitor

echo "✅ 安装完成并已启动守护进程。"
echo "🔄 使用以下命令管理："
echo "  sudo systemctl status crypto_monitor"
echo "  sudo systemctl restart crypto_monitor"
echo "  sudo systemctl stop crypto_monitor"
