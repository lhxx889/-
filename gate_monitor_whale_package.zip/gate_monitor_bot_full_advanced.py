
import asyncio
import time
import requests
import os
from typing import List, Dict
from tenacity import retry, wait_fixed, stop_after_attempt
from threading import Thread
from http.server import BaseHTTPRequestHandler, HTTPServer
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# === CONFIG ===
PERCENT_THRESHOLD = 30
CHECK_INTERVAL_SECONDS = 60
GATE_API_TICKERS_URL = "https://api.gate.io/api/v4/spot/tickers"
alerted_symbols = set()
last_alert_time = "无"

# Load from .env
from dotenv import load_dotenv
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '.env'))

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

retry_config = dict(wait=wait_fixed(3), stop=stop_after_attempt(5))

@retry(**retry_config)
def fetch_gate_tickers() -> List[Dict]:
    response = requests.get(GATE_API_TICKERS_URL, verify=True)
    response.raise_for_status()
    return response.json()

@retry(**retry_config)
def send_telegram_alert(message: str):
    requests.post(TELEGRAM_API_URL, data={
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message
    }, verify=True)

def get_coin_metadata(symbol: str) -> dict:
    try:
        coins = requests.get("https://api.coingecko.com/api/v3/coins/list").json()
        symbol_map = {c["symbol"]: c["id"] for c in coins}
        coin_id = symbol_map.get(symbol.lower())
        if not coin_id:
            return {"name": symbol.upper(), "market_cap": "N/A", "supply": "N/A", "twitter": "", "description": ""}
        url = f"https://api.coingecko.com/api/v3/coins/{coin_id}"
        data = requests.get(url, params={"localization": "false"}).json()
        return {
            "name": data["name"],
            "market_cap": data.get("market_data", {}).get("market_cap", {}).get("usd", "N/A"),
            "supply": data.get("market_data", {}).get("circulating_supply", "N/A"),
            "twitter": f"https://twitter.com/{data.get('links', {}).get('twitter_screen_name', '')}",
            "description": data.get("description", {}).get("en", "")[:300]
        }
    except Exception:
        return {"name": symbol.upper(), "market_cap": "N/A", "supply": "N/A", "twitter": "", "description": ""}

def filter_significant_changes(tickers: List[Dict]) -> List[Dict]:
    significant = []
    for t in tickers:
        try:
            percent_change = float(t.get("change_percentage", "0").replace('%', ''))
            symbol = t["currency_pair"]
            if abs(percent_change) >= PERCENT_THRESHOLD and symbol not in alerted_symbols:
                significant.append({
                    "symbol": symbol,
                    "percent_change": percent_change,
                    "last": t["last"],
                    "high": t["high_24h"],
                    "low": t["low_24h"],
                    "volume": t["base_volume"]
                })
                alerted_symbols.add(symbol)
        except Exception:
            continue
    return significant

def send_alerts_with_metadata(coins: List[Dict]):
    global last_alert_time
    for coin in coins:
        base_symbol = coin['symbol'].split("_")[0]
        change = coin['percent_change']
        direction = "🚀 上涨" if change > 0 else "📉 下跌"
        metadata = get_coin_metadata(base_symbol)
        msg = (
            f"{direction} | {coin['symbol']} ({metadata['name']})\n"
            f"涨跌幅: {change:.2f}%\n"
            f"最新价: {coin['last']}\n"
            f"市值: {metadata['market_cap']} | 流通量: {metadata['supply']}\n"
            f"📄 简介: {metadata['description']}\n"
            f"🔗 X链接: {metadata['twitter']}\n"
            f"#GateIO #Crypto"
        )
        send_telegram_alert(msg)
        last_alert_time = time.strftime("%Y-%m-%d %H:%M:%S")

async def monitor_loop():
    while True:
        print(f"[{time.strftime('%X')}] Fetching tickers...")
        try:
            tickers = fetch_gate_tickers()
            significant = filter_significant_changes(tickers)
            if significant:
                print(f"[INFO] Found {len(significant)} significant moves.")
                send_alerts_with_metadata(significant)
            else:
                print("[INFO] No significant price changes.")
        except Exception as e:
            print(f"[ERROR] Monitoring failed: {e}")
        await asyncio.sleep(CHECK_INTERVAL_SECONDS)

# === Telegram command handlers ===
async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        f"📊 当前监控状态：\n"
        f"- 活跃异动币种：{len(alerted_symbols)} 个\n"
        f"- 最近推送时间：{last_alert_time}\n"
        f"- 日志路径：~/crypto_monitor/logs/monitor.log"
    )
    await update.message.reply_text(text)

def start_telegram_command_bot():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("status", status))
    app.run_polling()

if __name__ == "__main__":
    # Start Telegram bot listener in parallel
    Thread(target=start_telegram_command_bot, daemon=True).start()
    asyncio.run(monitor_loop())


# === Additional command handlers ===

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "/status - 查看当前监控状态\n"
        "/help - 查看命令说明\n"
        "/reset_alerts - 重置推送记录（允许再次提醒）\n"
        "/uptime - 查看运行时长\n"
        "/reboot - 重启监控服务（需授权）"
    )
    await update.message.reply_text(text)

async def reset_alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    alerted_symbols.clear()
    await update.message.reply_text("✅ 已清除已推送币种记录，将重新开始推送。")

async def uptime(update: Update, context: ContextTypes.DEFAULT_TYPE):
    duration = datetime.now() - start_time
    await update.message.reply_text(f"⏱️ 当前运行时长: {duration}")

async def reboot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("♻️ 正在重启监控服务...")
    import subprocess
    subprocess.Popen(["sudo", "systemctl", "restart", "crypto_monitor"])

def start_telegram_command_bot():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("reset_alerts", reset_alerts))
    app.add_handler(CommandHandler("uptime", uptime))
    app.add_handler(CommandHandler("reboot", reboot))
    app.run_polling()


import pandas as pd
import mplfinance as mpf
from io import BytesIO

def fetch_kline_data(pair: str, interval: str = "5m", limit: int = 50) -> pd.DataFrame:
    url = "https://api.gate.io/api/v4/spot/candlesticks"
    params = {
        "currency_pair": pair,
        "interval": interval,
        "limit": limit
    }
    res = requests.get(url, params=params)
    res.raise_for_status()
    raw_data = res.json()
    raw_data.sort(key=lambda x: int(x[0]))
    df = pd.DataFrame(raw_data, columns=["timestamp", "volume", "close", "high", "low", "open"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit='s')
    df.set_index("timestamp", inplace=True)
    df = df.astype(float)
    df = df[["open", "high", "low", "close", "volume"]]
    return df

def generate_candlestick_chart(pair: str, interval="5m", limit=50) -> BytesIO:
    df = fetch_kline_data(pair, interval, limit)
    buf = BytesIO()
    mpf.plot(
        df,
        type="candle",
        volume=True,
        style="binance",
        title=f"{pair} K线图 ({interval} × {limit})",
        ylabel="价格",
        ylabel_lower="成交量",
        savefig=buf
    )
    buf.seek(0)
    return buf

def send_kline_chart(pair: str):
    image = generate_candlestick_chart(pair)
    requests.post(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto",
        data={"chat_id": TELEGRAM_CHAT_ID},
        files={"photo": ("chart.png", image)},
        verify=True
    )

# Modify alert sending to include chart
def send_alerts_with_metadata(coins: List[Dict]):
    global last_alert_time
    for coin in coins:
        base_symbol = coin['symbol'].split("_")[0]
        change = coin['percent_change']
        direction = "🚀 上涨" if change > 0 else "📉 下跌"
        metadata = get_coin_metadata(base_symbol)
        msg = (
            f"{direction} | {coin['symbol']} ({metadata['name']})\n"
            f"涨跌幅: {change:.2f}%\n"
            f"最新价: {coin['last']}\n"
            f"市值: {metadata['market_cap']} | 流通量: {metadata['supply']}\n"
            f"📄 简介: {metadata['description']}\n"
            f"🔗 X链接: {metadata['twitter']}\n"
            f"#GateIO #Crypto"
        )
        send_telegram_alert(msg)
        send_kline_chart(coin["symbol"])
        last_alert_time = time.strftime("%Y-%m-%d %H:%M:%S")


from apscheduler.schedulers.background import BackgroundScheduler
import matplotlib.pyplot as plt
import numpy as np

def generate_hourly_summary_chart():
    rising = 18
    falling = 12
    top_gainers = [("PEPE", 73.5), ("BSV", 65.4), ("LQTY", 60.1)]
    top_losers = [("RON", -41.1), ("LOOKS", -39.7), ("MDT", -35.0)]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    ax1.pie([rising, falling], labels=["上涨", "下跌"], autopct='%1.1f%%', colors=["green", "red"])
    ax1.set_title("市场涨跌币种分布")

    labels = [x[0] for x in top_gainers + top_losers]
    values = [x[1] for x in top_gainers + top_losers]
    colors = ['green'] * 3 + ['red'] * 3
    ax2.barh(labels, values, color=colors)
    ax2.set_title("涨/跌幅 TOP3 币种")
    ax2.axvline(0, color="gray", linestyle="--")

    plt.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    plt.close()
    return buf

def send_hourly_market_summary():
    image = generate_hourly_summary_chart()
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    caption = f"📊 每小时市场简报：{now}"
    requests.post(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto",
        data={"chat_id": TELEGRAM_CHAT_ID, "caption": caption},
        files={"photo": ("summary.png", image)},
        verify=True
    )

def start_hourly_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(send_hourly_market_summary, 'cron', minute=0)
    scheduler.start()


# === Entry Point (Final Integration) ===
if __name__ == "__main__":
    start_hourly_scheduler()  # 启动每小时任务
    Thread(target=start_telegram_command_bot, daemon=True).start()
    asyncio.run(monitor_loop())


def fetch_gate_announcements(limit: int = 20) -> List[Dict]:
    url = f"https://www.gate.io/api/v4/public/announcements?page=1&limit={limit}"
    try:
        res = requests.get(url)
        res.raise_for_status()
        return res.json().get("announcements", [])
    except Exception as e:
        return []

def analyze_announcements_for(symbol: str, lookback_hours: int = 6) -> List[str]:
    from datetime import datetime
    symbol = symbol.upper()
    now = datetime.utcnow()
    matched = []
    for ann in fetch_gate_announcements():
        title = ann.get("title", "")
        content = ann.get("content", "")
        ts = datetime.utcfromtimestamp(ann.get("timestamp", 0))
        if symbol in title.upper() or symbol in content.upper():
            if (now - ts).total_seconds() <= lookback_hours * 3600:
                matched.append(f"- {title}（{int((now - ts).total_seconds() // 3600)} 小时前）")
    return matched


# Modify send_alerts_with_metadata to include Gate.io announcement analysis
def send_alerts_with_metadata(coins: List[Dict]):
    global last_alert_time
    for coin in coins:
        base_symbol = coin['symbol'].split("_")[0]
        change = coin['percent_change']
        direction = "🚀 上涨" if change > 0 else "📉 下跌"
        metadata = get_coin_metadata(base_symbol)
        msg = (
            f"{direction} | {coin['symbol']} ({metadata['name']})\n"
            f"涨跌幅: {change:.2f}%\n"
            f"最新价: {coin['last']}\n"
            f"市值: {metadata['market_cap']} | 流通量: {metadata['supply']}\n"
            f"📄 简介: {metadata['description']}\n"
            f"🔗 X链接: {metadata['twitter']}"
        )

        reasons = analyze_announcements_for(base_symbol)
        if reasons:
            msg += "\n📢 Gate.io 公告：\n" + "\n".join(reasons)

        send_telegram_alert(msg)
        send_kline_chart(coin["symbol"])
        last_alert_time = time.strftime("%Y-%m-%d %H:%M:%S")


def fetch_status_updates(coin_id: str, hours: int = 6) -> List[str]:
    try:
        url = f"https://api.coingecko.com/api/v3/coins/{coin_id}/status_updates"
        res = requests.get(url)
        res.raise_for_status()
        updates = res.json().get("status_updates", [])
        now = datetime.utcnow()
        relevant = []
        for item in updates:
            created_at = datetime.strptime(item["created_at"], "%Y-%m-%dT%H:%M:%S.%fZ")
            delta = (now - created_at).total_seconds()
            if delta <= hours * 3600:
                summary = f"- {item['title']}（{int(delta // 3600)} 小时前）"
                relevant.append(summary)
        return relevant
    except Exception as e:
        return []


# Modified send_alerts_with_metadata to include CoinGecko project updates
def send_alerts_with_metadata(coins: List[Dict]):
    global last_alert_time
    for coin in coins:
        base_symbol = coin['symbol'].split("_")[0]
        change = coin['percent_change']
        direction = "🚀 上涨" if change > 0 else "📉 下跌"
        metadata = get_coin_metadata(base_symbol)
        msg = (
            f"{direction} | {coin['symbol']} ({metadata['name']})\n"
            f"涨跌幅: {change:.2f}%\n"
            f"最新价: {coin['last']}\n"
            f"市值: {metadata['market_cap']} | 流通量: {metadata['supply']}\n"
            f"📄 简介: {metadata['description']}\n"
            f"🔗 X链接: {metadata['twitter']}"
        )

        reasons = analyze_announcements_for(base_symbol)
        if reasons:
            msg += "\n📢 Gate.io 公告：\n" + "\n".join(reasons)

        coin_id = symbol_to_id_map.get(base_symbol.lower())
        if coin_id:
            news = fetch_status_updates(coin_id)
            if news:
                msg += "\n📰 项目动态：\n" + "\n".join(news)

        send_telegram_alert(msg)
        send_kline_chart(coin["symbol"])
        last_alert_time = time.strftime("%Y-%m-%d %H:%M:%S")


def get_holder_count_from_coingecko(symbol: str) -> str:
    try:
        coin_id = symbol_to_id_map.get(symbol.lower())
        if not coin_id:
            return "N/A"
        url = f"https://api.coingecko.com/api/v3/coins/{coin_id}"
        res = requests.get(url, params={"localization": "false"})
        res.raise_for_status()
        data = res.json()
        holders = data.get("community_data", {}).get("holders", None)
        if holders:
            return f"{int(holders):,}"
        return "N/A"
    except Exception:
        return "N/A"


# Modified alert logic to include holder count
def send_alerts_with_metadata(coins: List[Dict]):
    global last_alert_time
    for coin in coins:
        base_symbol = coin['symbol'].split("_")[0]
        change = coin['percent_change']
        direction = "🚀 上涨" if change > 0 else "📉 下跌"
        metadata = get_coin_metadata(base_symbol)
        holders = get_holder_count_from_coingecko(base_symbol)

        msg = (
            f"{direction} | {coin['symbol']} ({metadata['name']})\n"
            f"涨跌幅: {change:.2f}%\n"
            f"最新价: {coin['last']}\n"
            f"市值: {metadata['market_cap']} | 流通量: {metadata['supply']}\n"
            f"👥 当前持币人数: {holders}\n"
            f"📄 简介: {metadata['description']}\n"
            f"🔗 X链接: {metadata['twitter']}"
        )

        reasons = analyze_announcements_for(base_symbol)
        if reasons:
            msg += "\n📢 Gate.io 公告：\n" + "\n".join(reasons)

        coin_id = symbol_to_id_map.get(base_symbol.lower())
        if coin_id:
            news = fetch_status_updates(coin_id)
            if news:
                msg += "\n📰 项目动态：\n" + "\n".join(news)

        send_telegram_alert(msg)
        send_kline_chart(coin["symbol"])
        last_alert_time = time.strftime("%Y-%m-%d %H:%M:%S")
