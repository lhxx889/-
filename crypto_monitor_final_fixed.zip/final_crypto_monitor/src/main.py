"""
Gate.io加密货币异动监控系统 - 主程序
集成所有模块，提供完整的异动监控功能
"""

import logging
import time
import sys
import os
import argparse
import json
from datetime import datetime, timedelta
import signal
import threading

# 导入时区工具
try:
    from src.timezone_utils import format_time, get_current_time, timezone_manager
    timezone_utils_available = True
except ImportError:
    timezone_utils_available = False

# 导入自定义模块
from src.data_collector import DataCollector
from src.anomaly_detector import AnomalyDetector
from src.enhanced_telegram_alerter import EnhancedTelegramAlerter
from src.enhanced_coin_info import EnhancedCoinInfoFetcher
from src.enhanced_reason_analyzer import EnhancedReasonAnalyzer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("main")

# 全局变量
running = True
data_collector = None
anomaly_detector = None
telegram_alerter = None
coin_info_fetcher = None
reason_analyzer = None

def setup_timezone():
    """设置时区"""
    if not timezone_utils_available:
        logger.warning("时区工具模块不可用，将使用系统默认时区")
        return False
    
    # 设置为中国标准时间
    timezone_manager.save_config("Asia/Shanghai")
    logger.info(f"时区已设置为: {timezone_manager.timezone_str}")
    return True

def setup_telegram():
    """设置Telegram"""
    global telegram_alerter
    
    telegram_alerter = EnhancedTelegramAlerter()
    
    if telegram_alerter.is_configured():
        logger.info("Telegram已配置")
        return True
    
    logger.info("Telegram未配置，开始设置...")
    
    token = input("请输入Telegram Bot Token: ")
    chat_id = input("请输入Chat ID: ")
    
    if not token or not chat_id:
        logger.error("Token或Chat ID不能为空")
        return False
    
    if telegram_alerter.save_config(token, chat_id):
        logger.info("Telegram配置已保存")
        
        # 测试连接
        if telegram_alerter.test_connection():
            logger.info("Telegram连接测试成功")
            
            # 发送测试消息
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if timezone_utils_available:
                current_time = format_time()
            
            test_message = f"Gate.io加密货币异动监控系统已启动\n\n当前时间: {current_time}"
            if telegram_alerter.send_message(test_message):
                logger.info("测试消息已发送")
                return True
            else:
                logger.error("测试消息发送失败")
                return False
        else:
            logger.error("Telegram连接测试失败")
            return False
    else:
        logger.error("Telegram配置保存失败")
        return False

def setup_api_config():
    """设置API配置"""
    config_file = "api_config.json"
    
    if os.path.exists(config_file):
        logger.info("API配置文件已存在")
        return True
    
    logger.info("API配置文件不存在，创建默认配置...")
    
    default_config = {
        "gate_io": {
            "api_key": "",
            "api_secret": "",
            "base_url": "https://api.gateio.ws/api/v4"
        },
        "price_change_threshold": 30.0,  # 价格变化阈值（百分比）
        "volume_change_threshold": 300.0,  # 交易量变化阈值（百分比）
        "check_interval": 50,  # 检查间隔（秒）
        "top_coins_limit": 100  # 监控的前多少名币种
    }
    
    try:
        with open(config_file, 'w') as f:
            json.dump(default_config, f, indent=4)
        logger.info("默认API配置已创建")
        return True
    except Exception as e:
        logger.error(f"创建API配置文件失败: {str(e)}")
        return False

def load_api_config():
    """加载API配置"""
    config_file = "api_config.json"
    
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
        logger.info("API配置已加载")
        return config
    except Exception as e:
        logger.error(f"加载API配置失败: {str(e)}")
        return None

def update_api_config():
    """更新API配置"""
    config_file = "api_config.json"
    
    try:
        # 加载当前配置
        with open(config_file, 'r') as f:
            config = json.load(f)
        
        # 更新配置
        print("\n当前配置:")
        print(f"价格变化阈值: {config.get('price_change_threshold', 30.0)}%")
        print(f"交易量变化阈值: {config.get('volume_change_threshold', 300.0)}%")
        print(f"检查间隔: {config.get('check_interval', 50)}秒")
        print(f"监控的前多少名币种: {config.get('top_coins_limit', 100)}")
        
        print("\n请输入新的配置值（直接回车保持不变）:")
        
        # 价格变化阈值
        price_input = input(f"价格变化阈值 [{config.get('price_change_threshold', 30.0)}%]: ")
        if price_input:
            try:
                config['price_change_threshold'] = float(price_input)
            except:
                print("输入无效，保持原值")
        
        # 交易量变化阈值
        volume_input = input(f"交易量变化阈值 [{config.get('volume_change_threshold', 300.0)}%]: ")
        if volume_input:
            try:
                config['volume_change_threshold'] = float(volume_input)
            except:
                print("输入无效，保持原值")
        
        # 检查间隔
        interval_input = input(f"检查间隔 [{config.get('check_interval', 50)}秒]: ")
        if interval_input:
            try:
                config['check_interval'] = int(interval_input)
            except:
                print("输入无效，保持原值")
        
        # 监控的前多少名币种
        limit_input = input(f"监控的前多少名币种 [{config.get('top_coins_limit', 100)}]: ")
        if limit_input:
            try:
                config['top_coins_limit'] = int(limit_input)
            except:
                print("输入无效，保持原值")
        
        # 保存配置
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=4)
        
        logger.info("API配置已更新")
        print("\nAPI配置已更新")
        return True
    except Exception as e:
        logger.error(f"更新API配置失败: {str(e)}")
        print(f"\n更新API配置失败: {str(e)}")
        return False

def initialize_modules():
    """初始化所有模块"""
    global data_collector, anomaly_detector, telegram_alerter, coin_info_fetcher, reason_analyzer
    
    # 加载API配置
    config = load_api_config()
    if not config:
        return False
    
    # 初始化数据收集器
    data_collector = DataCollector(
        api_key=config.get('gate_io', {}).get('api_key', ''),
        api_secret=config.get('gate_io', {}).get('api_secret', ''),
        base_url=config.get('gate_io', {}).get('base_url', 'https://api.gateio.ws/api/v4')
    )
    
    # 初始化异常检测器
    anomaly_detector = AnomalyDetector(
        price_change_threshold=config.get('price_change_threshold', 30.0),
        volume_change_threshold=config.get('volume_change_threshold', 300.0)
    )
    
    # 初始化Telegram警报器
    telegram_alerter = EnhancedTelegramAlerter()
    
    # 初始化币种信息获取器
    coin_info_fetcher = EnhancedCoinInfoFetcher()
    
    # 初始化异动原因分析器
    reason_analyzer = EnhancedReasonAnalyzer()
    
    logger.info("所有模块初始化完成")
    return True

def process_anomalies(anomalies):
    """处理检测到的异常"""
    if not anomalies:
        return
    
    for anomaly in anomalies:
        try:
            # 获取币种信息
            symbol = anomaly.get("symbol", "")
            coin_info = coin_info_fetcher.get_coin_info(symbol)
            
            # 分析异动原因
            reasons = reason_analyzer.analyze_anomaly(anomaly, coin_info)
            
            # 添加分析结果到异常数据
            anomaly["analysis"] = reasons
            
            # 添加币种信息到异常数据
            anomaly["coin_info"] = coin_info
            
            # 发送警报
            telegram_alerter.send_anomaly_alert(anomaly)
            
        except Exception as e:
            logger.error(f"处理异常失败: {str(e)}")

def monitor_loop():
    """监控循环"""
    global running
    
    logger.info("开始监控循环")
    
    while running:
        try:
            # 获取所有币种的ticker数据
            logger.info("获取所有币种ticker数据")
            tickers = data_collector.get_all_tickers()
            
            # 检测异常
            anomalies = anomaly_detector.detect_anomalies(tickers)
            
            # 处理异常
            if anomalies:
                logger.info(f"检测到 {len(anomalies)} 个异常")
                process_anomalies(anomalies)
            
            # 等待下一次检查
            check_interval = load_api_config().get('check_interval', 50)
            logger.info(f"等待 {check_interval}秒后进行下一次检查")
            
            # 分段等待，以便能够及时响应停止信号
            for _ in range(check_interval):
                if not running:
                    break
                time.sleep(1)
                
        except Exception as e:
            logger.error(f"监控循环异常: {str(e)}")
            # 出错后等待一段时间再继续
            time.sleep(10)

def signal_handler(sig, frame):
    """信号处理函数"""
    global running
    logger.info("接收到停止信号，准备退出...")
    running = False

def setup_wizard():
    """设置向导"""
    print("\n===== Gate.io加密货币异动监控系统设置向导 =====\n")
    
    # 设置时区
    if timezone_utils_available:
        print("设置时区...")
        setup_timezone()
        print(f"时区已设置为: {timezone_manager.timezone_str}")
    
    # 设置API配置
    print("\n设置API配置...")
    if setup_api_config():
        update_api_config()
    
    # 设置Telegram
    print("\n设置Telegram...")
    if setup_telegram():
        print("Telegram设置成功")
    else:
        print("Telegram设置失败，请检查Token和Chat ID")
    
    print("\n设置完成！")

def main():
    """主函数"""
    global running
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Gate.io加密货币异动监控系统")
    parser.add_argument("--setup", action="store_true", help="运行设置向导")
    parser.add_argument("--config", action="store_true", help="更新API配置")
    args = parser.parse_args()
    
    # 设置时区
    if timezone_utils_available:
        setup_timezone()
    
    # 运行设置向导
    if args.setup:
        setup_wizard()
        return
    
    # 更新API配置
    if args.config:
        update_api_config()
        return
    
    # 设置API配置
    if not setup_api_config():
        logger.error("API配置设置失败")
        return
    
    # 初始化模块
    if not initialize_modules():
        logger.error("模块初始化失败")
        return
    
    # 检查Telegram是否已配置
    if not telegram_alerter.is_configured():
        logger.error("Telegram未配置，请先运行设置向导")
        print("Telegram未配置，请先运行设置向导：python main.py --setup")
        return
    
    # 设置信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 启动监控线程
    monitor_thread = threading.Thread(target=monitor_loop)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    # 发送启动消息
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if timezone_utils_available:
        current_time = format_time()
    
    start_message = f"Gate.io加密货币异动监控系统已启动\n\n当前时间: {current_time}"
    telegram_alerter.send_message(start_message)
    
    # 等待监控线程结束
    try:
        while monitor_thread.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("接收到键盘中断，准备退出...")
        running = False
    
    # 等待线程结束
    monitor_thread.join()
    
    logger.info("系统已停止")

if __name__ == "__main__":
    main()
