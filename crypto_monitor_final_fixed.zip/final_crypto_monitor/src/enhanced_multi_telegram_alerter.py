"""
Gate.io加密货币异动监控系统 - 增强版多Telegram账号警报器
支持多账号轮换、图表展示、防重复推送和限流处理
"""

import logging
import time
import json
import os
import requests
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import random
import threading
from collections import deque

# 导入时区工具
try:
    from src.timezone_utils import format_time, get_current_time, localize_time, parse_time
    timezone_utils_available = True
except ImportError:
    timezone_utils_available = False

# 导入多账号管理器
try:
    from src.multi_telegram_manager import MultiTelegramManager, telegram_manager
    multi_telegram_available = True
except ImportError:
    multi_telegram_available = False

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("enhanced_multi_telegram_alerter")

# 导入图表生成模块
try:
    from src.chart_generator import ChartGenerator, chart_generator
    chart_generator_available = True
except ImportError:
    logger.warning("图表生成模块导入失败，将禁用图表功能")
    chart_generator_available = False

class MessageBatcher:
    """消息批处理器，用于合并多条消息"""
    
    def __init__(self, max_batch_size: int = 5, max_wait_time: int = 10):
        """
        初始化消息批处理器
        
        Args:
            max_batch_size: 最大批处理大小
            max_wait_time: 最大等待时间（秒）
        """
        self.max_batch_size = max_batch_size
        self.max_wait_time = max_wait_time
        self.messages = []
        self.lock = threading.Lock()
        self.last_flush_time = time.time()
        self.timer = None
    
    def add_message(self, message: str) -> None:
        """
        添加消息到批处理队列
        
        Args:
            message: 消息内容
        """
        with self.lock:
            self.messages.append(message)
            
            # 如果这是第一条消息，启动定时器
            if len(self.messages) == 1:
                self.start_timer()
    
    def start_timer(self) -> None:
        """启动定时器"""
        if self.timer:
            self.timer.cancel()
        
        self.timer = threading.Timer(self.max_wait_time, self.flush_due_to_timeout)
        self.timer.daemon = True
        self.timer.start()
    
    def flush_due_to_timeout(self) -> List[str]:
        """
        由于超时而刷新消息队列
        
        Returns:
            消息列表
        """
        with self.lock:
            if self.messages:
                logger.info(f"由于超时刷新消息队列，消息数: {len(self.messages)}")
                self.last_flush_time = time.time()
                messages_to_flush = self.messages.copy()
                self.messages.clear()
                
                # 返回消息以便发送
                return messages_to_flush
            
            return []
    
    def get_batch_if_ready(self) -> List[str]:
        """
        如果批处理就绪，获取消息批次
        
        Returns:
            消息列表，如果未就绪则为空列表
        """
        with self.lock:
            # 如果达到最大批处理大小，刷新队列
            if len(self.messages) >= self.max_batch_size:
                logger.info(f"达到最大批处理大小，刷新消息队列，消息数: {len(self.messages)}")
                self.last_flush_time = time.time()
                
                # 取消定时器
                if self.timer:
                    self.timer.cancel()
                    self.timer = None
                
                messages_to_flush = self.messages.copy()
                self.messages.clear()
                return messages_to_flush
            
            # 如果超过最大等待时间，刷新队列
            current_time = time.time()
            if self.messages and current_time - self.last_flush_time >= self.max_wait_time:
                logger.info(f"超过最大等待时间，刷新消息队列，消息数: {len(self.messages)}")
                self.last_flush_time = current_time
                
                # 取消定时器
                if self.timer:
                    self.timer.cancel()
                    self.timer = None
                
                messages_to_flush = self.messages.copy()
                self.messages.clear()
                return messages_to_flush
            
            return []
    
    def combine_messages(self, messages: List[str]) -> str:
        """
        合并多条消息
        
        Args:
            messages: 消息列表
            
        Returns:
            合并后的消息
        """
        if not messages:
            return ""
        
        if len(messages) == 1:
            return messages[0]
        
        # 添加批处理标题
        combined = f"📊 批量异动警报 ({len(messages)}条)\n\n"
        
        # 添加分隔线和消息内容
        for i, message in enumerate(messages, 1):
            # 移除每条消息中可能的重复标题
            lines = message.split("\n")
            if lines and "异动警报" in lines[0]:
                message = "\n".join(lines[1:])
            
            combined += f"--- 警报 {i} ---\n{message}\n\n"
        
        return combined.strip()

class EnhancedMultiTelegramAlerter:
    """增强版多Telegram账号警报器，支持多账号轮换、图表展示、防重复推送和限流处理"""
    
    def __init__(self, config_file: str = "telegram_config.json", dedup_window: int = 3600):
        """
        初始化增强版多Telegram账号警报器
        
        Args:
            config_file: 配置文件路径
            dedup_window: 去重窗口时间（秒）
        """
        self.config_file = config_file
        self.dedup_window = dedup_window
        self.alert_history = {}
        
        # 初始化多账号管理器
        self.telegram_manager = telegram_manager if multi_telegram_available else None
        if self.telegram_manager:
            logger.info("多Telegram账号管理器初始化完成")
        
        # 初始化图表生成器
        self.chart_generator = chart_generator if chart_generator_available else None
        if self.chart_generator:
            logger.info("图表生成模块初始化完成")
        
        # 初始化消息批处理器
        self.message_batcher = MessageBatcher(max_batch_size=5, max_wait_time=10)
        
        # 启动消息处理线程
        self.running = True
        self.message_thread = threading.Thread(target=self._message_processing_thread)
        self.message_thread.daemon = True
        self.message_thread.start()
        
        logger.info("增强版多Telegram账号警报器初始化完成")
    
    def is_configured(self) -> bool:
        """
        检查Telegram是否已配置
        
        Returns:
            是否已配置
        """
        if self.telegram_manager:
            return self.telegram_manager.get_account_count() > 0
        else:
            # 如果多账号管理器不可用，检查旧配置
            try:
                if os.path.exists(self.config_file):
                    with open(self.config_file, 'r') as f:
                        config = json.load(f)
                        token = config.get("token")
                        chat_id = config.get("chat_id")
                        return token is not None and chat_id is not None
            except:
                pass
            return False
    
    def test_connection(self) -> bool:
        """
        测试Telegram连接
        
        Returns:
            连接是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法测试连接")
            return False
        
        if self.telegram_manager:
            # 测试所有账号
            results = self.telegram_manager.test_all_accounts()
            return any(results.values())
        else:
            # 如果多账号管理器不可用，使用旧方法测试
            try:
                if os.path.exists(self.config_file):
                    with open(self.config_file, 'r') as f:
                        config = json.load(f)
                        token = config.get("token")
                        
                        url = f"https://api.telegram.org/bot{token}/getMe"
                        response = requests.get(url, timeout=10)
                        response.raise_for_status()
                        data = response.json()
                        
                        if data.get("ok"):
                            logger.info(f"Telegram连接测试成功，机器人名称: {data.get('result', {}).get('username')}")
                            return True
                        else:
                            logger.warning(f"Telegram连接测试失败: {data.get('description')}")
                            return False
            except Exception as e:
                logger.error(f"Telegram连接测试失败: {str(e)}")
                return False
    
    def _message_processing_thread(self) -> None:
        """消息处理线程，定期检查并发送批处理消息"""
        logger.info("消息处理线程已启动")
        
        while self.running:
            try:
                # 检查是否有就绪的批次
                batch = self.message_batcher.get_batch_if_ready()
                if batch:
                    logger.info(f"发现就绪批次，消息数: {len(batch)}")
                    combined_message = self.message_batcher.combine_messages(batch)
                    self._send_message_with_multi_account(combined_message)
                
                # 检查定时器触发的批次
                batch = self.message_batcher.flush_due_to_timeout()
                if batch:
                    logger.info(f"定时器触发批次，消息数: {len(batch)}")
                    combined_message = self.message_batcher.combine_messages(batch)
                    self._send_message_with_multi_account(combined_message)
                
                # 短暂休眠，避免CPU占用过高
                time.sleep(1)
            except Exception as e:
                logger.error(f"消息处理线程异常: {str(e)}")
                time.sleep(5)  # 出错后等待一段时间再继续
    
    def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram消息
        
        Args:
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送消息")
            return False
        
        # 添加到批处理队列
        logger.info(f"添加消息到批处理队列: {text[:50]}...")
        self.message_batcher.add_message(text)
        return True
    
    # 添加兼容性方法，用于支持旧的接口调用
    def add_to_batch(self, text: str) -> bool:
        """
        添加消息到批处理队列（兼容性方法）
        
        Args:
            text: 消息文本
            
        Returns:
            添加是否成功
        """
        logger.info(f"通过兼容性接口添加消息到批处理队列: {text[:50]}...")
        return self.send_message(text)
    
    def _send_message_with_multi_account(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        使用多账号发送Telegram消息
        
        Args:
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送消息")
            return False
        
        logger.info(f"准备发送Telegram消息: {text[:50]}...")
        
        if self.telegram_manager:
            # 使用多账号管理器发送
            success, account_name = self.telegram_manager.send_message(text, parse_mode=parse_mode)
            if success:
                logger.info(f"使用账号 {account_name} 发送消息成功")
            else:
                logger.error("所有账号发送消息失败")
            return success
        else:
            # 如果多账号管理器不可用，使用旧方法发送
            try:
                if os.path.exists(self.config_file):
                    with open(self.config_file, 'r') as f:
                        config = json.load(f)
                        token = config.get("token")
                        chat_id = config.get("chat_id")
                        
                        url = f"https://api.telegram.org/bot{token}/sendMessage"
                        data = {
                            "chat_id": chat_id,
                            "text": text,
                            "parse_mode": parse_mode
                        }
                        
                        response = requests.post(url, data=data, timeout=30)
                        response.raise_for_status()
                        logger.info("Telegram消息发送成功")
                        return True
            except Exception as e:
                logger.error(f"Telegram消息发送失败: {str(e)}")
                return False
    
    def send_photo(self, photo_path: str, caption: str = None, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram图片
        
        Args:
            photo_path: 图片文件路径
            caption: 图片说明
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送图片")
            return False
        
        if not os.path.exists(photo_path):
            logger.warning(f"图片文件不存在: {photo_path}")
            return False
        
        logger.info(f"准备发送Telegram图片: {photo_path}")
        
        if self.telegram_manager:
            # 使用多账号管理器发送
            success, account_name = self.telegram_manager.send_photo(photo_path, caption=caption, parse_mode=parse_mode)
            if success:
                logger.info(f"使用账号 {account_name} 发送图片成功")
            else:
                logger.error("所有账号发送图片失败")
            return success
        else:
            # 如果多账号管理器不可用，使用旧方法发送
            try:
                if os.path.exists(self.config_file):
                    with open(self.config_file, 'r') as f:
                        config = json.load(f)
                        token = config.get("token")
                        chat_id = config.get("chat_id")
                        
                        url = f"https://api.telegram.org/bot{token}/sendPhoto"
                        
                        data = {
                            "chat_id": chat_id
                        }
                        if caption:
                            data["caption"] = caption
                            data["parse_mode"] = parse_mode
                        
                        with open(photo_path, 'rb') as photo_file:
                            files = {
                                "photo": photo_file
                            }
                            response = requests.post(url, data=data, files=files, timeout=60)
                            response.raise_for_status()
                        
                        logger.info("Telegram图片发送成功")
                        return True
            except Exception as e:
                logger.error(f"Telegram图片发送失败: {str(e)}")
                return False
    
    def is_duplicate_alert(self, symbol: str, alert_type: str) -> bool:
        """
        检查是否为重复警报
        
        Args:
            symbol: 币种符号
            alert_type: 警报类型
            
        Returns:
            是否为重复警报
        """
        alert_key = f"{symbol}_{alert_type}"
        current_time = time.time()
        
        # 检查是否在去重窗口内
        if alert_key in self.alert_history:
            last_time = self.alert_history[alert_key]
            time_diff = current_time - last_time
            
            if time_diff < self.dedup_window:
                logger.info(f"检测到重复警报: {alert_key}， 距上次警报 {time_diff:.2f} 秒")
                return True
        
        # 更新警报历史
        self.alert_history[alert_key] = current_time
        return False
    
    def generate_price_chart(self, symbol: str, price_data: List[Dict[str, Any]], save_dir: str = "charts") -> Optional[str]:
        """
        生成价格图表
        
        Args:
            symbol: 币种符号
            price_data: 价格数据列表，每项包含 timestamp, price, volume 等字段
            save_dir: 保存目录
            
        Returns:
            图表文件路径，如果生成失败则为None
        """
        if not chart_generator_available or not self.chart_generator:
            logger.warning("图表生成模块不可用，无法生成图表")
            return None
        
        try:
            # 确保保存目录存在
            os.makedirs(save_dir, exist_ok=True)
            
            # 生成图表
            chart_path = os.path.join(save_dir, f"{symbol.replace('/', '_')}_chart.png")
            
            # 提取数据
            timestamps = [item.get("timestamp") for item in price_data]
            prices = [item.get("price") for item in price_data]
            volumes = [item.get("volume") for item in price_data]
            
            # 生成图表
            self.chart_generator.generate_price_volume_chart(
                symbol=symbol,
                timestamps=timestamps,
                prices=prices,
                volumes=volumes,
                save_path=chart_path
            )
            
            logger.info(f"生成价格图表成功: {chart_path}")
            return chart_path
        except Exception as e:
            logger.error(f"生成价格图表失败: {str(e)}")
            return None
    
    def send_anomaly_alert(self, anomaly: Dict[str, Any]) -> bool:
        """
        发送异常警报
        
        Args:
            anomaly: 异常数据
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送异常警报")
            return False
        
        symbol = anomaly.get("symbol", "")
        alert_type = anomaly.get("type", "unknown")
        
        # 检查是否为重复警报
        if self.is_duplicate_alert(symbol, alert_type):
            logger.info(f"跳过重复警报: {symbol}_{alert_type}")
            return False
        
        try:
            # 构建警报消息
            message = self._build_anomaly_message(anomaly)
            
            # 检查是否有图表
            chart_path = anomaly.get("chart_path")
            if chart_path and os.path.exists(chart_path):
                # 发送带图表的警报
                return self.send_photo(chart_path, caption=message)
            else:
                # 发送纯文本警报
                return self.send_message(message)
        except Exception as e:
            logger.error(f"发送异常警报失败: {str(e)}")
            return False
    
    def _build_anomaly_message(self, anomaly: Dict[str, Any]) -> str:
        """
        构建异常警报消息
        
        Args:
            anomaly: 异常数据
            
        Returns:
            警报消息
        """
        symbol = anomaly.get("symbol", "")
        alert_type = anomaly.get("type", "unknown")
        change_percent = anomaly.get("change_percent", 0)
        current_price = anomaly.get("current_price", 0)
        
        # 获取当前时间
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if timezone_utils_available:
            current_time = format_time()
        
        # 构建基本信息
        if alert_type == "price":
            title = f"🚨 价格异动警报"
            change_text = f"价格变化: {change_percent:.2f}%"
        elif alert_type == "volume":
            title = f"📊 交易量异动警报"
            change_text = f"交易量变化: {change_percent:.2f}%"
        else:
            title = f"⚠️ 异常警报"
            change_text = f"变化: {change_percent:.2f}%"
        
        message = f"{title}\n\n"
        message += f"🪙 币种: {symbol}\n"
        message += f"💰 当前价格: {current_price}\n"
        message += f"📈 {change_text}\n"
        message += f"⏰ 时间: {current_time}\n"
        
        # 添加币种信息
        coin_info = anomaly.get("coin_info", {})
        if coin_info:
            message += f"\n📋 币种信息:\n"
            
            name = coin_info.get("name", "")
            if name:
                message += f"名称: {name}\n"
            
            description = coin_info.get("description", "")
            if description:
                # 截断过长的描述
                if len(description) > 200:
                    description = description[:200] + "..."
                message += f"简介: {description}\n"
            
            website = coin_info.get("website", "")
            if website:
                message += f"官网: {website}\n"
            
            social_links = coin_info.get("social_links", {})
            if social_links:
                message += "社交媒体:\n"
                for platform, link in social_links.items():
                    message += f"- {platform}: {link}\n"
        
        # 添加价格历史
        price_history = anomaly.get("price_history", {})
        if price_history:
            message += f"\n📊 价格历史:\n"
            
            day_change = price_history.get("24h_change", 0)
            message += f"24小时变化: {day_change:.2f}%\n"
            
            week_change = price_history.get("7d_change", 0)
            if week_change:
                message += f"7天变化: {week_change:.2f}%\n"
            
            volatility = anomaly.get("volatility", 0)
            if volatility:
                message += f"波动率: {volatility:.2f}%\n"
        
        # 添加合约信息
        contract_info = anomaly.get("contract_info", {})
        if contract_info:
            message += f"\n📝 合约信息:\n"
            
            funding_rate = contract_info.get("funding_rate", 0)
            message += f"资金费率: {funding_rate:.4f}%\n"
            
            open_interest = contract_info.get("open_interest", 0)
            if open_interest:
                message += f"未平仓合约: {open_interest}\n"
            
            long_short_ratio = contract_info.get("long_short_ratio", 0)
            if long_short_ratio:
                message += f"多空比例: {long_short_ratio:.2f}\n"
        
        # 添加异动原因
        reasons = anomaly.get("reasons", [])
        if reasons:
            message += f"\n🔍 可能原因:\n"
            for reason in reasons:
                message += f"- {reason}\n"
        
        return message
