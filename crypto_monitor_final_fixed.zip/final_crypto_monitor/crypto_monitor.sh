#!/bin/bash
# Gate.io加密货币异动监控系统快捷启动脚本

# 获取脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# 检查是否存在虚拟环境并激活
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
fi

# 命令行参数处理
case "$1" in
    start)
        echo "启动监控系统..."
        mkdir -p logs
        nohup python main.py > logs/crypto_monitor.log 2>&1 &
        echo $! > crypto_monitor.pid
        echo "监控系统已在后台启动，PID: $(cat crypto_monitor.pid)"
        ;;
    stop)
        if [ -f crypto_monitor.pid ]; then
            PID=$(cat crypto_monitor.pid)
            echo "停止监控系统 (PID: $PID)..."
            kill $PID 2>/dev/null || true
            rm crypto_monitor.pid
            echo "监控系统已停止"
        else
            echo "监控系统未运行"
        fi
        ;;
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
    status)
        if [ -f crypto_monitor.pid ]; then
            PID=$(cat crypto_monitor.pid)
            if ps -p $PID > /dev/null; then
                echo "监控系统正在运行，PID: $PID"
                echo "运行时间: $(ps -o etime= -p $PID)"
                echo "CPU使用率: $(ps -o %cpu= -p $PID)%"
                echo "内存使用: $(ps -o %mem= -p $PID)%"
            else
                echo "监控系统已崩溃，PID文件存在但进程不存在"
                rm crypto_monitor.pid
            fi
        else
            echo "监控系统未运行"
        fi
        ;;
    logs)
        if [ -f logs/crypto_monitor.log ]; then
            echo "显示最近的日志..."
            tail -n 50 logs/crypto_monitor.log
            echo ""
            echo "使用 '$0 logs -f' 实时查看日志"
        else
            echo "日志文件不存在"
        fi
        
        if [ "$2" == "-f" ]; then
            echo "实时查看日志..."
            tail -f logs/crypto_monitor.log
        fi
        ;;
    setup)
        echo "运行设置向导..."
        
        # 创建必要的目录
        mkdir -p config
        
        # 配置Telegram（简化版，直接写入文件）
        echo "===== Telegram配置 ====="
        echo "1. 添加新的Telegram账号"
        echo "2. 跳过Telegram配置"
        read -p "请选择: " choice
        
        if [ "$choice" == "1" ]; then
            read -p "账号名称: " name
            read -p "Telegram Bot Token: " token
            read -p "Telegram Chat ID: " chat_id
            
            # 直接创建Telegram配置文件，避免Python子进程
            cat > telegram_accounts.json << EOF
{
  "accounts": {
    "$name": {
      "token": "$token",
      "chat_id": "$chat_id",
      "is_active": true,
      "consecutive_errors": 0
    }
  },
  "current": "$name"
}
EOF
            echo "Telegram账号已添加"
        fi
        
        # 配置异动阈值（简化版，直接写入文件）
        echo "===== 异动阈值配置 ====="
        read -p "价格异动阈值 (百分比，默认: 30): " price_threshold
        price_threshold=${price_threshold:-30}
        
        read -p "交易量异动阈值 (百分比，默认: 200): " volume_threshold
        volume_threshold=${volume_threshold:-200}
        
        # 创建配置文件
        cat > config.json << EOF
{
  "price_threshold": $price_threshold,
  "volume_threshold": $volume_threshold,
  "check_interval": 50,
  "excluded_symbols": [],
  "api_key": "",
  "api_secret": ""
}
EOF
        echo "异动阈值已配置"
        
        # 配置时区（简化版，直接写入文件）
        cat > timezone_config.json << EOF
{
  "timezone": "Asia/Shanghai"
}
EOF
        echo "时区已设置为: Asia/Shanghai"
        
        echo "设置完成！您现在可以使用 ./crypto_monitor.sh start 启动监控系统"
        ;;
    telegram)
        echo "===== Telegram账号管理 ====="
        echo "1. 添加账号"
        echo "2. 测试账号连接"
        echo "3. 发送测试消息"
        echo "4. 查看账号列表"
        echo "5. 删除账号"
        echo "0. 返回"
        read -p "请选择: " choice
        case $choice in
            1)
                # 直接在脚本中处理，避免Python子进程
                read -p "账号名称: " name
                read -p "Bot Token: " token
                read -p "Chat ID: " chat_id
                
                mkdir -p config
                
                # 检查是否已存在配置文件
                if [ -f "telegram_accounts.json" ]; then
                    # 提取现有账号，添加新账号
                    # 这里使用简单的方式，实际应该用jq等工具处理JSON
                    mv telegram_accounts.json telegram_accounts.json.bak
                    cat > telegram_accounts.json << EOF
{
  "accounts": {
    "$name": {
      "token": "$token",
      "chat_id": "$chat_id",
      "is_active": true,
      "consecutive_errors": 0
    }
  },
  "current": "$name"
}
EOF
                else
                    # 创建新配置文件
                    cat > telegram_accounts.json << EOF
{
  "accounts": {
    "$name": {
      "token": "$token",
      "chat_id": "$chat_id",
      "is_active": true,
      "consecutive_errors": 0
    }
  },
  "current": "$name"
}
EOF
                fi
                echo "账号已添加: $name"
                ;;
            2)
                echo "此功能需要Python环境，请稍后使用 ./crypto_monitor.sh test 命令测试连接"
                ;;
            3)
                echo "此功能需要Python环境，请稍后使用 ./crypto_monitor.sh test 命令发送测试消息"
                ;;
            4)
                if [ -f "telegram_accounts.json" ]; then
                    echo "当前配置的Telegram账号:"
                    grep -o '"[^"]*": {' telegram_accounts.json | sed 's/": {//' | sed 's/"//g' | grep -v "accounts"
                else
                    echo "未找到Telegram配置文件"
                fi
                ;;
            5)
                echo "此功能需要Python环境，请手动编辑telegram_accounts.json文件删除账号"
                ;;
            *)
                echo "返回主菜单"
                ;;
        esac
        ;;
    config)
        echo "===== 配置管理 ====="
        echo "1. 配置异动阈值"
        echo "2. 配置排除币种"
        echo "0. 返回"
        read -p "请选择: " choice
        case $choice in
            1)
                # 直接在脚本中处理，避免Python子进程
                if [ -f "config.json" ]; then
                    # 显示当前配置
                    price=$(grep -o '"price_threshold": [0-9.]*' config.json | sed 's/"price_threshold": //')
                    volume=$(grep -o '"volume_threshold": [0-9.]*' config.json | sed 's/"volume_threshold": //')
                    
                    read -p "价格异动阈值 (百分比，当前: $price): " new_price
                    new_price=${new_price:-$price}
                    
                    read -p "交易量异动阈值 (百分比，当前: $volume): " new_volume
                    new_volume=${new_volume:-$volume}
                    
                    # 更新配置文件
                    sed -i "s/\"price_threshold\": [0-9.]*/\"price_threshold\": $new_price/" config.json
                    sed -i "s/\"volume_threshold\": [0-9.]*/\"volume_threshold\": $new_volume/" config.json
                    
                    echo "异动阈值已更新: 价格 $new_price%, 交易量 $new_volume%"
                else
                    # 创建新配置文件
                    read -p "价格异动阈值 (百分比，默认: 30): " price
                    price=${price:-30}
                    
                    read -p "交易量异动阈值 (百分比，默认: 200): " volume
                    volume=${volume:-200}
                    
                    cat > config.json << EOF
{
  "price_threshold": $price,
  "volume_threshold": $volume,
  "check_interval": 50,
  "excluded_symbols": [],
  "api_key": "",
  "api_secret": ""
}
EOF
                    echo "异动阈值已配置"
                fi
                ;;
            2)
                echo "请编辑config.json文件中的excluded_symbols数组来配置排除币种"
                ;;
            *)
                echo "返回主菜单"
                ;;
        esac
        ;;
    test)
        echo "===== 系统测试 ====="
        echo "1. 测试数据获取"
        echo "2. 测试图表生成"
        echo "0. 返回"
        read -p "请选择: " choice
        case $choice in
            1)
                python main.py --test-data
                ;;
            2)
                python main.py --test-chart
                ;;
            *)
                echo "返回主菜单"
                ;;
        esac
        ;;
    service)
        if [ "$(uname)" == "Linux" ]; then
            echo "===== 系统服务管理 ====="
            echo "1. 安装系统服务"
            echo "2. 启动系统服务"
            echo "3. 停止系统服务"
            echo "4. 重启系统服务"
            echo "5. 查看服务状态"
            echo "6. 卸载系统服务"
            echo "0. 返回"
            read -p "请选择: " choice
            case $choice in
                1)
                    echo "安装系统服务..."
                    sudo cp crypto_monitor.service /etc/systemd/system/
                    sudo systemctl daemon-reload
                    sudo systemctl enable crypto_monitor.service
                    echo "系统服务已安装并设置为开机启动"
                    ;;
                2)
                    echo "启动系统服务..."
                    sudo systemctl start crypto_monitor.service
                    ;;
                3)
                    echo "停止系统服务..."
                    sudo systemctl stop crypto_monitor.service
                    ;;
                4)
                    echo "重启系统服务..."
                    sudo systemctl restart crypto_monitor.service
                    ;;
                5)
                    echo "查看服务状态..."
                    sudo systemctl status crypto_monitor.service
                    ;;
                6)
                    echo "卸载系统服务..."
                    sudo systemctl stop crypto_monitor.service
                    sudo systemctl disable crypto_monitor.service
                    sudo rm /etc/systemd/system/crypto_monitor.service
                    sudo systemctl daemon-reload
                    echo "系统服务已卸载"
                    ;;
                *)
                    echo "返回主菜单"
                    ;;
            esac
        else
            echo "当前系统不支持systemd服务"
        fi
        ;;
    update)
        echo "检查更新..."
        if command -v git &>/dev/null && [ -d ".git" ]; then
            git pull
            echo "代码已更新，重新安装依赖..."
            pip install -r requirements.txt
            echo "更新完成"
        else
            echo "无法检查更新，未使用git仓库或git命令不可用"
        fi
        ;;
    backup)
        echo "创建备份..."
        BACKUP_DIR="backups/backup_$(date +%Y%m%d_%H%M%S)"
        mkdir -p "$BACKUP_DIR"
        cp -r config "$BACKUP_DIR/"
        cp *.json "$BACKUP_DIR/" 2>/dev/null || true
        cp *.db "$BACKUP_DIR/" 2>/dev/null || true
        echo "备份已创建: $BACKUP_DIR"
        ;;
    clean)
        echo "清理临时文件..."
        find . -name "*.pyc" -delete
        find . -name "__pycache__" -type d -exec rm -rf {} +
        find . -name "*.log" -size +10M -delete
        echo "临时文件已清理"
        ;;
    *)
        echo "===== Gate.io加密货币异动监控系统快捷启动脚本 ====="
        echo "用法: $0 {命令}"
        echo ""
        echo "基本命令:"
        echo "  start    - 启动监控系统"
        echo "  stop     - 停止监控系统"
        echo "  restart  - 重启监控系统"
        echo "  status   - 查看监控系统状态"
        echo "  logs     - 查看最近的日志 (使用 -f 参数实时查看)"
        echo ""
        echo "配置命令:"
        echo "  setup    - 运行设置向导"
        echo "  telegram - 管理Telegram账号"
        echo "  config   - 更新配置"
        echo ""
        echo "测试命令:"
        echo "  test     - 运行系统测试"
        echo ""
        echo "系统命令:"
        echo "  service  - 管理系统服务"
        echo "  update   - 检查并安装更新"
        echo "  backup   - 创建配置备份"
        echo "  clean    - 清理临时文件"
        echo ""
        ;;
esac
