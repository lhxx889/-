# Gate.io加密货币异动监控系统增强版使用说明

## 系统概述

Gate.io加密货币异动监控系统是一个专业的加密货币价格和交易量监控工具，能够实时检测异常波动并通过Telegram发送警报。本增强版在原有基础上添加了多项强大功能：

1. **多Telegram账号轮换**：支持配置多个Telegram Bot账号，智能轮换发送消息，避免API限制
2. **多快捷启动方式**：提供便捷的启动、停止、重启和管理脚本
3. **增强推送内容**：包含当前价格、历史价格走势、币种详细信息和合约交易数据
4. **价格图表展示**：自动生成并在推送消息中展示价格和交易量变化图表
5. **防重复推送机制**：智能识别并过滤短时间内的相似异动警报
6. **中国时区支持**：所有时间显示均为中国标准时间（UTC+8）

## 安装与配置

### 系统要求

- Python 3.6+
- 网络连接
- Gate.io API访问权限（可选）
- Telegram Bot Token和Chat ID

### 安装步骤

1. **解压文件**：
   ```bash
   unzip crypto_monitor_enhanced.zip
   cd crypto_monitor
   ```

2. **安装依赖**：
   ```bash
   pip install -r requirements.txt
   ```

3. **运行设置向导**：
   ```bash
   ./crypto_monitor.sh setup
   ```
   或
   ```bash
   python main.py --setup
   ```

4. **配置Telegram账号**：
   ```bash
   ./crypto_monitor.sh telegram
   ```
   按照提示添加一个或多个Telegram Bot账号

## 使用方法

### 快捷启动脚本

系统提供了多种便捷的启动和管理方式：

1. **启动监控**：
   ```bash
   ./crypto_monitor.sh start
   ```

2. **停止监控**：
   ```bash
   ./crypto_monitor.sh stop
   ```

3. **重启监控**：
   ```bash
   ./crypto_monitor.sh restart
   ```

4. **查看状态**：
   ```bash
   ./crypto_monitor.sh status
   ```

5. **查看日志**：
   ```bash
   ./crypto_monitor.sh logs
   ```

6. **管理Telegram账号**：
   ```bash
   ./crypto_monitor.sh telegram
   ```

7. **更新配置**：
   ```bash
   ./crypto_monitor.sh config
   ```

8. **安装为系统服务**（需要root权限）：
   ```bash
   sudo ./crypto_monitor.sh service
   ```
   然后选择"安装系统服务"选项

### 多Telegram账号管理

系统支持配置多个Telegram Bot账号，以避免API限制导致消息未发出：

1. **添加账号**：
   ```bash
   ./crypto_monitor.sh telegram
   ```
   然后选择"添加账号"选项

2. **测试账号**：
   ```bash
   ./crypto_monitor.sh telegram
   ```
   然后选择"测试账号连接"选项

3. **发送测试消息**：
   ```bash
   ./crypto_monitor.sh telegram
   ```
   然后选择"发送测试消息"选项

### 配置选项

系统提供了多种配置选项，可以通过设置向导或直接编辑配置文件进行修改：

1. **价格异动阈值**：检测价格变化的百分比阈值（默认30%）
2. **交易量异动阈值**：检测交易量变化的百分比阈值（默认200%）
3. **检查间隔**：两次检查之间的时间间隔（默认50秒）
4. **排除币种**：不需要监控的币种列表

## 推送内容说明

系统发送的Telegram警报消息包含以下丰富内容：

1. **基本信息**：
   - 币种符号和名称
   - 当前价格和变化百分比
   - 当前交易量和变化百分比
   - 异动检测时间（中国标准时间）

2. **币种信息**：
   - 币种简介和描述
   - 官方网站链接
   - 社交媒体信息（Twitter、Telegram等）

3. **价格历史**：
   - 24小时价格变化
   - 最高价和最低价
   - 价格波动率

4. **合约信息**：
   - 当前资金费率
   - 未平仓合约数量
   - 多空比例

5. **异动原因分析**：
   - 相关新闻及情感分析
   - 技术分析（价格模式、支撑位、阻力位）
   - 市场情绪评估

6. **价格图表**：
   - 24小时价格和交易量变化图表

## 常见问题

1. **消息未发送或发送失败**
   - 检查Telegram Bot Token和Chat ID是否正确
   - 确认Bot已被添加到目标聊天中
   - 查看日志文件了解详细错误信息
   - 尝试添加多个Telegram账号以避免API限制

2. **时间显示不正确**
   - 系统默认使用中国标准时间（UTC+8）
   - 如需修改，请联系开发者

3. **系统占用资源过多**
   - 尝试增加检查间隔时间
   - 减少监控的币种数量

4. **如何添加更多Telegram账号**
   - 运行`./crypto_monitor.sh telegram`
   - 选择"添加账号"选项
   - 按照提示输入账号名称、Token和Chat ID

## 高级功能

1. **批量消息处理**：
   - 系统会自动合并短时间内的多条消息，减少推送频率
   - 可以在`enhanced_multi_telegram_alerter.py`中调整批处理参数

2. **自定义图表样式**：
   - 修改`chart_generator.py`中的参数可以自定义图表样式

3. **添加自定义分析指标**：
   - 在`enhanced_reason_analyzer.py`中添加新的分析方法

4. **设置为系统服务**：
   - 使用`sudo ./crypto_monitor.sh service`安装为系统服务
   - 系统将在开机时自动启动并在崩溃后自动重启

## 技术支持

如果您在使用过程中遇到任何问题，请查看日志文件`crypto_monitor.log`获取详细错误信息，或联系开发者获取支持。
