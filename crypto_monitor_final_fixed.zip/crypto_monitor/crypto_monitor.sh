#!/bin/bash
# Gate.io加密货币异动监控系统快捷启动脚本
# 支持启动、停止、重启、状态查询等功能

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 配置
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$SCRIPT_DIR/crypto_monitor.log"
PID_FILE="$SCRIPT_DIR/crypto_monitor.pid"
TELEGRAM_CONFIG="$SCRIPT_DIR/telegram_accounts.json"
SYSTEM_SERVICE="crypto_monitor.service"

# 打印带颜色的消息
print_message() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# 检查依赖
check_dependencies() {
    print_message "$BLUE" "检查依赖..."
    
    # 检查是否为外部管理的Python环境
    if python3 -m pip install --dry-run requests 2>&1 | grep -q "externally-managed-environment"; then
        print_message "$YELLOW" "检测到外部管理的Python环境，将使用直接配置模式"
        return 0
    fi
    
    # 尝试安装依赖
    if ! python3 -m pip install -r "$SCRIPT_DIR/requirements.txt" > /dev/null 2>&1; then
        print_message "$YELLOW" "使用pip安装依赖失败，尝试使用系统包管理器..."
        
        # 检测系统类型
        if command -v apt-get > /dev/null; then
            print_message "$BLUE" "检测到Debian/Ubuntu系统"
            sudo apt-get update > /dev/null 2>&1
            sudo apt-get install -y python3-requests python3-matplotlib python3-numpy python3-pandas python3-pytz > /dev/null 2>&1
        elif command -v yum > /dev/null; then
            print_message "$BLUE" "检测到RHEL/CentOS系统"
            sudo yum install -y python3-requests python3-matplotlib python3-numpy python3-pandas python3-pytz > /dev/null 2>&1
        elif command -v pacman > /dev/null; then
            print_message "$BLUE" "检测到Arch Linux系统"
            sudo pacman -S --noconfirm python-requests python-matplotlib python-numpy python-pandas python-pytz > /dev/null 2>&1
        else
            print_message "$RED" "无法检测系统类型，请手动安装依赖"
            return 1
        fi
    fi
    
    return 0
}

# 启动监控
start_monitor() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null; then
            print_message "$YELLOW" "监控系统已经在运行 (PID: $pid)"
            return 0
        else
            rm -f "$PID_FILE"
        fi
    fi
    
    print_message "$BLUE" "启动加密货币异动监控系统..."
    nohup python3 "$SCRIPT_DIR/main.py" > "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    print_message "$GREEN" "监控系统已启动 (PID: $(cat "$PID_FILE"))"
}

# 停止监控
stop_monitor() {
    if [ ! -f "$PID_FILE" ]; then
        print_message "$YELLOW" "监控系统未运行"
        return 0
    fi
    
    local pid=$(cat "$PID_FILE")
    if ! ps -p "$pid" > /dev/null; then
        print_message "$YELLOW" "监控系统未运行 (PID文件过期)"
        rm -f "$PID_FILE"
        return 0
    fi
    
    print_message "$BLUE" "停止监控系统 (PID: $pid)..."
    kill "$pid"
    sleep 2
    
    if ps -p "$pid" > /dev/null; then
        print_message "$YELLOW" "正常停止失败，强制终止..."
        kill -9 "$pid"
        sleep 1
    fi
    
    rm -f "$PID_FILE"
    print_message "$GREEN" "监控系统已停止"
}

# 重启监控
restart_monitor() {
    print_message "$BLUE" "重启监控系统..."
    stop_monitor
    start_monitor
}

# 查看状态
check_status() {
    if [ ! -f "$PID_FILE" ]; then
        print_message "$YELLOW" "监控系统未运行"
        return 1
    fi
    
    local pid=$(cat "$PID_FILE")
    if ! ps -p "$pid" > /dev/null; then
        print_message "$YELLOW" "监控系统未运行 (PID文件过期)"
        rm -f "$PID_FILE"
        return 1
    fi
    
    local uptime=$(ps -o etime= -p "$pid")
    print_message "$GREEN" "监控系统正在运行"
    print_message "$BLUE" "PID: $pid"
    print_message "$BLUE" "运行时间: $uptime"
    print_message "$BLUE" "日志文件: $LOG_FILE"
    
    return 0
}

# 查看日志
view_log() {
    local lines=${1:-50}
    
    if [ ! -f "$LOG_FILE" ]; then
        print_message "$YELLOW" "日志文件不存在"
        return 1
    fi
    
    print_message "$BLUE" "显示最近 $lines 行日志:"
    tail -n "$lines" "$LOG_FILE"
}

# 安装为系统服务
install_service() {
    # 检测系统类型
    if command -v systemctl > /dev/null; then
        print_message "$BLUE" "检测到systemd系统，创建systemd服务文件..."
        
        # 创建服务文件
        cat > "$SCRIPT_DIR/$SYSTEM_SERVICE" << EOF
[Unit]
Description=Gate.io加密货币异动监控系统
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$SCRIPT_DIR
ExecStart=$(which python3) $SCRIPT_DIR/main.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
        
        print_message "$GREEN" "服务文件已创建: $SCRIPT_DIR/$SYSTEM_SERVICE"
        print_message "$BLUE" "要安装为系统服务，请运行:"
        echo "sudo cp $SCRIPT_DIR/$SYSTEM_SERVICE /etc/systemd/system/"
        echo "sudo systemctl daemon-reload"
        echo "sudo systemctl enable $SYSTEM_SERVICE"
        echo "sudo systemctl start $SYSTEM_SERVICE"
    else
        print_message "$YELLOW" "未检测到systemd，无法创建系统服务"
        return 1
    fi
}

# 设置向导
setup_wizard() {
    print_message "$BLUE" "运行设置向导..."
    
    # 创建配置目录
    mkdir -p "$SCRIPT_DIR/config"
    
    # 配置排除的币种
    print_message "$BLUE" "--- 币种配置 ---"
    local excluded_symbols=""
    if [ -f "$SCRIPT_DIR/config.json" ]; then
        excluded_symbols=$(python3 -c "import json; print(json.load(open('$SCRIPT_DIR/config.json')).get('excluded_symbols', ''))" 2>/dev/null)
    fi
    read -p "排除的币种符号 (用逗号分隔，当前: $excluded_symbols): " new_excluded
    if [ -n "$new_excluded" ]; then
        excluded_symbols="$new_excluded"
    fi
    
    # 配置Telegram
    print_message "$BLUE" "--- Telegram配置 ---"
    echo "1. 添加新的Telegram账号"
    echo "2. 跳过Telegram配置"
    read -p "请选择: " telegram_choice
    
    if [ "$telegram_choice" = "1" ]; then
        read -p "账号名称: " account_name
        read -p "Telegram Bot Token: " token
        read -p "Telegram Chat ID: " chat_id
        
        # 直接创建配置文件
        create_telegram_config "$account_name" "$token" "$chat_id"
    fi
    
    # 创建或更新配置文件
    cat > "$SCRIPT_DIR/config.json" << EOF
{
    "excluded_symbols": "$excluded_symbols",
    "price_change_threshold": 30.0,
    "volume_change_threshold": 200.0,
    "check_interval": 50
}
EOF
    
    print_message "$GREEN" "设置完成！"
}

# 创建Telegram配置
create_telegram_config() {
    local account_name="$1"
    local token="$2"
    local chat_id="$3"
    
    print_message "$BLUE" "创建Telegram配置..."
    
    # 检查现有配置
    local accounts="{}"
    if [ -f "$TELEGRAM_CONFIG" ]; then
        accounts=$(python3 -c "import json; print(json.dumps(json.load(open('$TELEGRAM_CONFIG')).get('accounts', {})))" 2>/dev/null)
        if [ $? -ne 0 ]; then
            accounts="{}"
        fi
    fi
    
    # 添加新账号
    accounts=$(python3 -c "
import json
accounts = json.loads('$accounts')
accounts['$account_name'] = {'token': '$token', 'chat_id': '$chat_id'}
print(json.dumps(accounts))
" 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        # 如果Python命令失败，使用纯文本方式创建
        cat > "$TELEGRAM_CONFIG" << EOF
{
  "accounts": {
    "$account_name": {
      "token": "$token",
      "chat_id": "$chat_id"
    }
  },
  "current": "$account_name"
}
EOF
    else
        # 使用Python创建的账号列表
        cat > "$TELEGRAM_CONFIG" << EOF
{
  "accounts": $accounts,
  "current": "$account_name"
}
EOF
    fi
    
    print_message "$GREEN" "Telegram账号 '$account_name' 已添加"
}

# 测试Telegram账号
test_telegram_account() {
    local account_name="$1"
    
    if [ ! -f "$TELEGRAM_CONFIG" ]; then
        print_message "$RED" "Telegram配置文件不存在"
        return 1
    fi
    
    print_message "$BLUE" "测试Telegram账号 '$account_name'..."
    
    # 获取账号信息
    local token=$(python3 -c "
import json
try:
    with open('$TELEGRAM_CONFIG', 'r') as f:
        config = json.load(f)
    accounts = config.get('accounts', {})
    account = accounts.get('$account_name')
    if account:
        print(account.get('token', ''))
except:
    pass
" 2>/dev/null)
    
    local chat_id=$(python3 -c "
import json
try:
    with open('$TELEGRAM_CONFIG', 'r') as f:
        config = json.load(f)
    accounts = config.get('accounts', {})
    account = accounts.get('$account_name')
    if account:
        print(account.get('chat_id', ''))
except:
    pass
" 2>/dev/null)
    
    if [ -z "$token" ] || [ -z "$chat_id" ]; then
        print_message "$RED" "无法获取账号信息"
        return 1
    fi
    
    # 发送测试消息
    print_message "$BLUE" "发送测试消息..."
    local response=$(curl -s "https://api.telegram.org/bot$token/sendMessage" \
        -d "chat_id=$chat_id" \
        -d "text=Gate.io加密货币异动监控系统测试消息 - $(date)")
    
    if echo "$response" | grep -q "\"ok\":true"; then
        print_message "$GREEN" "测试成功！消息已发送"
        return 0
    else
        print_message "$RED" "测试失败: $response"
        return 1
    fi
}

# Telegram账号管理
manage_telegram() {
    print_message "$BLUE" "Telegram账号管理"
    
    # 检查依赖
    check_dependencies
    if [ $? -ne 0 ]; then
        print_message "$RED" "错误: 安装依赖失败"
        return 1
    fi
    
    # 解析子命令
    local subcommand="$1"
    shift
    
    case "$subcommand" in
        "add")
            # 添加账号: telegram add <name> <token> <chat_id>
            if [ $# -lt 3 ]; then
                print_message "$RED" "用法: $0 telegram add <name> <token> <chat_id>"
                return 1
            fi
            create_telegram_config "$1" "$2" "$3"
            ;;
        "test")
            # 测试账号: telegram test <name>
            if [ $# -lt 1 ]; then
                print_message "$RED" "用法: $0 telegram test <name>"
                return 1
            fi
            test_telegram_account "$1"
            ;;
        "list")
            # 列出账号: telegram list
            if [ ! -f "$TELEGRAM_CONFIG" ]; then
                print_message "$YELLOW" "没有配置Telegram账号"
                return 1
            fi
            
            print_message "$BLUE" "已配置的Telegram账号:"
            python3 -c "
import json
try:
    with open('$TELEGRAM_CONFIG', 'r') as f:
        config = json.load(f)
    accounts = config.get('accounts', {})
    current = config.get('current', '')
    for name, account in accounts.items():
        marker = '*' if name == current else ' '
        print(f\"{marker} {name}: {account.get('chat_id', 'N/A')} ({account.get('token', 'N/A')[:10]}...)\")
except Exception as e:
    print(f\"错误: {str(e)}\")
" 2>/dev/null
            ;;
        "remove")
            # 删除账号: telegram remove <name>
            if [ $# -lt 1 ]; then
                print_message "$RED" "用法: $0 telegram remove <name>"
                return 1
            fi
            
            if [ ! -f "$TELEGRAM_CONFIG" ]; then
                print_message "$RED" "Telegram配置文件不存在"
                return 1
            fi
            
            python3 -c "
import json
try:
    with open('$TELEGRAM_CONFIG', 'r') as f:
        config = json.load(f)
    accounts = config.get('accounts', {})
    current = config.get('current', '')
    if '$1' in accounts:
        del accounts['$1']
        if current == '$1' and accounts:
            current = next(iter(accounts))
        config['accounts'] = accounts
        config['current'] = current
        with open('$TELEGRAM_CONFIG', 'w') as f:
            json.dump(config, f, indent=2)
        print('账号已删除')
    else:
        print('账号不存在')
except Exception as e:
    print(f\"错误: {str(e)}\")
" 2>/dev/null
            ;;
        "set-current")
            # 设置当前账号: telegram set-current <name>
            if [ $# -lt 1 ]; then
                print_message "$RED" "用法: $0 telegram set-current <name>"
                return 1
            fi
            
            if [ ! -f "$TELEGRAM_CONFIG" ]; then
                print_message "$RED" "Telegram配置文件不存在"
                return 1
            fi
            
            python3 -c "
import json
try:
    with open('$TELEGRAM_CONFIG', 'r') as f:
        config = json.load(f)
    accounts = config.get('accounts', {})
    if '$1' in accounts:
        config['current'] = '$1'
        with open('$TELEGRAM_CONFIG', 'w') as f:
            json.dump(config, f, indent=2)
        print('当前账号已设置为: $1')
    else:
        print('账号不存在')
except Exception as e:
    print(f\"错误: {str(e)}\")
" 2>/dev/null
            ;;
        *)
            # 默认显示帮助
            print_message "$BLUE" "Telegram账号管理命令:"
            echo "  $0 telegram add <name> <token> <chat_id> - 添加账号"
            echo "  $0 telegram test <name> - 测试账号"
            echo "  $0 telegram list - 列出所有账号"
            echo "  $0 telegram remove <name> - 删除账号"
            echo "  $0 telegram set-current <name> - 设置当前账号"
            ;;
    esac
}

# 主函数
main() {
    # 如果没有参数，显示帮助
    if [ $# -eq 0 ]; then
        print_message "$BLUE" "Gate.io加密货币异动监控系统"
        echo "用法: $0 <命令> [参数]"
        echo ""
        echo "命令:"
        echo "  start    - 启动监控系统"
        echo "  stop     - 停止监控系统"
        echo "  restart  - 重启监控系统"
        echo "  status   - 查看监控系统状态"
        echo "  log [n]  - 查看最近n行日志 (默认50行)"
        echo "  setup    - 运行设置向导"
        echo "  service  - 安装为系统服务"
        echo "  telegram - Telegram账号管理"
        echo ""
        echo "示例:"
        echo "  $0 start      # 启动监控系统"
        echo "  $0 log 100    # 查看最近100行日志"
        echo "  $0 telegram add mybot 123456:ABC-DEF 789012345  # 添加Telegram账号"
        return 0
    fi
    
    # 解析命令
    local command="$1"
    shift
    
    case "$command" in
        "start")
            check_dependencies && start_monitor
            ;;
        "stop")
            stop_monitor
            ;;
        "restart")
            restart_monitor
            ;;
        "status")
            check_status
            ;;
        "log")
            view_log "$1"
            ;;
        "setup")
            setup_wizard
            ;;
        "service")
            install_service
            ;;
        "telegram")
            manage_telegram "$@"
            ;;
        *)
            print_message "$RED" "未知命令: $command"
            print_message "$BLUE" "运行 '$0' 查看帮助"
            return 1
            ;;
    esac
}

# 执行主函数
main "$@"
