#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Telegram消息推送模块
"""

import time
import json
import logging
import requests
from typing import Dict, List, Any, Optional

from config import TELEGRAM_CONFIG
from utils import (
    send_telegram_message, get_unprocessed_price_alerts,
    get_unprocessed_new_listings, mark_price_alert_processed,
    mark_new_listing_processed, logger
)
from coin_details import process_price_alert, process_new_listing

def process_and_push_alerts():
    """
    处理未处理的价格预警并推送到Telegram
    """
    logger.info("开始处理价格预警...")
    
    # 获取未处理的价格预警
    alerts = get_unprocessed_price_alerts(limit=5)
    
    if not alerts:
        logger.info("没有未处理的价格预警")
        return
    
    logger.info(f"发现 {len(alerts)} 个未处理的价格预警")
    
    for alert in alerts:
        try:
            alert_id = alert[0]
            exchange = alert[1]
            symbol = alert[2]
            price = alert[3]
            price_change = alert[4]
            alert_type = alert[5]
            
            logger.info(f"处理 {exchange} 交易所 {symbol} 的价格预警...")
            
            # 构建预警信息字典
            alert_info = {
                'id': alert_id,
                'exchange': exchange,
                'symbol': symbol,
                'price': price,
                'price_change_24h': price_change,
                'volume_24h': 0,  # 需要从数据库补充
                'market_cap': 0,  # 需要从数据库补充
                'alert_type': alert_type
            }
            
            # 处理预警并生成消息
            message = process_price_alert(alert_info)
            
            # 发送到Telegram
            success = send_telegram_message(message)
            
            if success:
                # 标记为已处理
                mark_price_alert_processed(alert_id)
                logger.info(f"已成功处理并推送 {symbol} 的价格预警")
            else:
                logger.error(f"推送 {symbol} 的价格预警失败")
            
            # 避免频繁发送
            time.sleep(2)
            
        except Exception as e:
            logger.error(f"处理价格预警失败: {str(e)}")

def process_and_push_new_listings():
    """
    处理未处理的新币上线信息并推送到Telegram
    """
    logger.info("开始处理新币上线信息...")
    
    # 获取未处理的新币上线信息
    listings = get_unprocessed_new_listings(limit=5)
    
    if not listings:
        logger.info("没有未处理的新币上线信息")
        return
    
    logger.info(f"发现 {len(listings)} 个未处理的新币上线信息")
    
    for listing in listings:
        try:
            listing_id = listing[0]
            exchange = listing[1]
            symbol = listing[2]
            name = listing[3]
            listing_time = listing[4]
            initial_price = listing[5]
            announcement_url = listing[6]
            
            logger.info(f"处理 {exchange} 交易所 {symbol} 的新币上线信息...")
            
            # 构建上线信息字典
            listing_info = {
                'id': listing_id,
                'exchange': exchange,
                'symbol': symbol,
                'name': name,
                'listing_time': listing_time,
                'initial_price': initial_price,
                'announcement_url': announcement_url
            }
            
            # 处理上线信息并生成消息
            message = process_new_listing(listing_info)
            
            # 发送到Telegram
            success = send_telegram_message(message)
            
            if success:
                # 标记为已处理
                mark_new_listing_processed(listing_id)
                logger.info(f"已成功处理并推送 {symbol} 的新币上线信息")
            else:
                logger.error(f"推送 {symbol} 的新币上线信息失败")
            
            # 避免频繁发送
            time.sleep(2)
            
        except Exception as e:
            logger.error(f"处理新币上线信息失败: {str(e)}")

if __name__ == '__main__':
    # 测试代码
    process_and_push_alerts()
    process_and_push_new_listings()
