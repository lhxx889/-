#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io交易所价格监控模块
"""

import time
import json
import logging
from typing import Dict, List, Any, Optional

from config import API_CONFIG, MONITOR_CONFIG
from utils import (
    make_api_request, save_coin_price, save_price_alert,
    logger, format_number
)

def get_gate_tickers() -> List[Dict[str, Any]]:
    """
    获取Gate.io所有交易对的24小时行情数据
    
    Returns:
        交易对列表，每个交易对包含价格、涨跌幅等信息
    """
    try:
        response = make_api_request(
            exchange='gate',
            endpoint=API_CONFIG['gate']['ticker_url'],
            method='GET'
        )
        
        if not isinstance(response, list):
            logger.error(f"Gate.io行情数据格式错误: {response}")
            return []
        
        # 过滤出USDT交易对
        usdt_pairs = [
            ticker for ticker in response
            if ticker.get('currency_pair', '').endswith('_USDT')
        ]
        
        logger.info(f"已获取Gate.io {len(usdt_pairs)}个USDT交易对行情数据")
        return usdt_pairs
        
    except Exception as e:
        logger.error(f"获取Gate.io行情数据失败: {str(e)}")
        return []

def process_gate_tickers(tickers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    处理Gate.io行情数据，检测价格变化并保存到数据库
    
    Args:
        tickers: Gate.io行情数据列表
        
    Returns:
        触发预警的交易对列表
    """
    alerts = []
    
    for ticker in tickers:
        try:
            currency_pair = ticker.get('currency_pair', '')
            if not currency_pair.endswith('_USDT'):
                continue
            
            # 提取基础币种名称（去除_USDT后缀）
            base_symbol = currency_pair.split('_')[0]
            
            # 检查是否在排除列表中
            if base_symbol in MONITOR_CONFIG['excluded_symbols']:
                continue
            
            # 提取价格信息
            price = float(ticker.get('last', 0))
            price_change_pct = float(ticker.get('change_percentage', 0))
            volume = float(ticker.get('quote_volume', 0))  # 以USDT计价的交易量
            
            # 市值信息Gate.io API不直接提供，可以后续通过其他API补充
            market_cap = 0
            
            # 保存价格信息到数据库
            save_coin_price(
                exchange='gate',
                symbol=base_symbol,
                price=price,
                price_change_24h=price_change_pct,
                volume_24h=volume,
                market_cap=market_cap
            )
            
            # 检查是否触发价格预警
            increase_threshold = MONITOR_CONFIG['price_change_thresholds']['increase']
            decrease_threshold = MONITOR_CONFIG['price_change_thresholds']['decrease']
            
            # 检查交易量是否满足最小要求
            if volume < MONITOR_CONFIG['min_volume']:
                continue
            
            # 检查涨幅
            if price_change_pct >= increase_threshold:
                alert_id = save_price_alert(
                    exchange='gate',
                    symbol=base_symbol,
                    price=price,
                    price_change_24h=price_change_pct,
                    alert_type='increase'
                )
                
                alerts.append({
                    'id': alert_id,
                    'exchange': 'gate',
                    'symbol': base_symbol,
                    'price': price,
                    'price_change_24h': price_change_pct,
                    'volume_24h': volume,
                    'market_cap': market_cap,
                    'alert_type': 'increase'
                })
                
                logger.info(f"Gate.io {base_symbol} 涨幅达到 {price_change_pct:.2f}%，触发预警")
            
            # 检查跌幅
            elif price_change_pct <= decrease_threshold:
                alert_id = save_price_alert(
                    exchange='gate',
                    symbol=base_symbol,
                    price=price,
                    price_change_24h=price_change_pct,
                    alert_type='decrease'
                )
                
                alerts.append({
                    'id': alert_id,
                    'exchange': 'gate',
                    'symbol': base_symbol,
                    'price': price,
                    'price_change_24h': price_change_pct,
                    'volume_24h': volume,
                    'market_cap': market_cap,
                    'alert_type': 'decrease'
                })
                
                logger.info(f"Gate.io {base_symbol} 跌幅达到 {price_change_pct:.2f}%，触发预警")
                
        except Exception as e:
            logger.error(f"处理Gate.io交易对 {ticker.get('currency_pair', 'unknown')} 数据失败: {str(e)}")
    
    return alerts

def get_gate_currency_pairs() -> List[Dict[str, Any]]:
    """
    获取Gate.io所有交易对信息
    
    Returns:
        交易对信息列表
    """
    try:
        response = make_api_request(
            exchange='gate',
            endpoint=API_CONFIG['gate']['currency_pairs_url'],
            method='GET'
        )
        
        return response
        
    except Exception as e:
        logger.error(f"获取Gate.io交易对信息失败: {str(e)}")
        return []

def get_gate_candlesticks(currency_pair: str, interval: str = '1d', limit: int = 7) -> List[List]:
    """
    获取Gate.io K线数据
    
    Args:
        currency_pair: 交易对符号，如 'BTC_USDT'
        interval: K线间隔，如 '1d', '4h', '1h'
        limit: 获取的K线数量
        
    Returns:
        K线数据列表
    """
    try:
        params = {
            'currency_pair': currency_pair,
            'interval': interval,
            'limit': limit
        }
        
        response = make_api_request(
            exchange='gate',
            endpoint=API_CONFIG['gate']['candlesticks_url'],
            method='GET',
            params=params
        )
        
        return response
        
    except Exception as e:
        logger.error(f"获取Gate.io K线数据失败: {str(e)}")
        return []

def monitor_gate_prices() -> List[Dict[str, Any]]:
    """
    监控Gate.io价格变化
    
    Returns:
        触发预警的交易对列表
    """
    logger.info("开始监控Gate.io价格...")
    
    # 获取所有交易对行情
    tickers = get_gate_tickers()
    
    # 处理行情数据并检测价格变化
    alerts = process_gate_tickers(tickers)
    
    logger.info(f"Gate.io价格监控完成，发现 {len(alerts)} 个预警")
    return alerts

def analyze_gate_price_change(symbol: str, days: int = 7) -> Dict[str, Any]:
    """
    分析Gate.io币种价格变化原因
    
    Args:
        symbol: 币种符号，如 'BTC'
        days: 分析的天数
        
    Returns:
        分析结果字典
    """
    try:
        # 获取K线数据
        klines = get_gate_candlesticks(f"{symbol}_USDT", interval='1d', limit=days)
        
        if not klines:
            return {'analysis': '无法获取历史数据进行分析'}
        
        # 提取收盘价
        closes = [float(k[2]) for k in klines]
        
        # 提取交易量
        volumes = [float(k[6]) for k in klines]
        
        # 计算价格变化
        price_changes = [
            (closes[i] - closes[i-1]) / closes[i-1] * 100
            for i in range(1, len(closes))
        ]
        
        # 计算交易量变化
        volume_changes = [
            (volumes[i] - volumes[i-1]) / volumes[i-1] * 100
            for i in range(1, len(volumes))
        ]
        
        # 分析结果
        avg_price_change = sum(price_changes) / len(price_changes) if price_changes else 0
        avg_volume_change = sum(volume_changes) / len(volume_changes) if volume_changes else 0
        
        # 最近一天的价格和交易量变化
        latest_price_change = price_changes[-1] if price_changes else 0
        latest_volume_change = volume_changes[-1] if volume_changes else 0
        
        # 生成分析结果
        analysis = ""
        
        if latest_price_change > 0:
            if latest_volume_change > 50:
                analysis = f"{symbol}价格上涨 {latest_price_change:.2f}%，同时交易量大幅增加 {latest_volume_change:.2f}%，可能是由于重大利好消息或机构大量买入导致。"
            elif latest_volume_change > 20:
                analysis = f"{symbol}价格上涨 {latest_price_change:.2f}%，交易量增加 {latest_volume_change:.2f}%，市场买盘活跃，短期看涨。"
            else:
                analysis = f"{symbol}价格上涨 {latest_price_change:.2f}%，但交易量变化不大，可能是自然回调或小规模投资者行为。"
        else:
            if latest_volume_change > 50:
                analysis = f"{symbol}价格下跌 {abs(latest_price_change):.2f}%，同时交易量大幅增加 {latest_volume_change:.2f}%，可能是由于重大利空消息或大户抛售导致。"
            elif latest_volume_change > 20:
                analysis = f"{symbol}价格下跌 {abs(latest_price_change):.2f}%，交易量增加 {latest_volume_change:.2f}%，市场卖压较大，短期看跌。"
            else:
                analysis = f"{symbol}价格下跌 {abs(latest_price_change):.2f}%，但交易量变化不大，可能是获利了结或缺乏买盘支撑。"
        
        return {
            'analysis': analysis,
            'price_changes': price_changes,
            'volume_changes': volume_changes,
            'avg_price_change': avg_price_change,
            'avg_volume_change': avg_volume_change
        }
        
    except Exception as e:
        logger.error(f"分析Gate.io价格变化失败: {str(e)}")
        return {'analysis': '分析过程中出现错误'}

if __name__ == '__main__':
    # 测试代码
    alerts = monitor_gate_prices()
    print(f"发现 {len(alerts)} 个预警")
    
    for alert in alerts:
        print(f"{alert['symbol']} {alert['price_change_24h']}% {alert['alert_type']}")
        
        analysis = analyze_gate_price_change(alert['symbol'])
        print(analysis['analysis'])
        print("-" * 50)
