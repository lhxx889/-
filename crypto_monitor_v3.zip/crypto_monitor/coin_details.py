#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
币种详情抓取与分析模块
"""

import time
import json
import logging
import re
import requests
from typing import Dict, List, Any, Optional
from bs4 import BeautifulSoup
from datetime import datetime

from config import API_CONFIG, MONITOR_CONFIG, MESSAGE_TEMPLATES
from utils import (
    make_api_request, save_coin_details, get_coin_details,
    logger, format_number, format_timestamp
)
from binance_monitor import analyze_binance_price_change, get_binance_coin_info
from gate_monitor import analyze_gate_price_change
from listing_monitor import fetch_binance_coin_details, fetch_gate_coin_details

def fetch_coin_details(exchange: str, symbol: str) -> Dict[str, Any]:
    """
    抓取币种详细信息
    
    Args:
        exchange: 交易所名称 ('binance' 或 'gate')
        symbol: 币种符号，如 'BTC'
        
    Returns:
        币种详细信息字典
    """
    logger.info(f"开始抓取 {exchange} 交易所 {symbol} 币种详情...")
    
    # 首先检查缓存
    cached_details = get_coin_details(symbol)
    if cached_details:
        logger.info(f"使用缓存的 {symbol} 币种详情")
        return cached_details
    
    # 根据交易所选择不同的抓取方法
    if exchange == 'binance':
        details = fetch_binance_coin_details(symbol)
    else:  # gate
        details = fetch_gate_coin_details(symbol)
    
    # 如果抓取失败，尝试使用另一个交易所的数据
    if not details or not details.get('description'):
        logger.warning(f"{exchange} 交易所 {symbol} 币种详情抓取失败，尝试使用另一个交易所的数据")
        
        if exchange == 'binance':
            details = fetch_gate_coin_details(symbol)
        else:
            details = fetch_binance_coin_details(symbol)
    
    # 如果仍然失败，尝试使用CoinGecko API
    if not details or not details.get('description'):
        logger.warning(f"尝试使用CoinGecko API获取 {symbol} 币种详情")
        details = fetch_coingecko_coin_details(symbol)
    
    # 保存到数据库
    if details and details.get('symbol'):
        save_coin_details(
            symbol=details.get('symbol', ''),
            name=details.get('name', ''),
            description=details.get('description', ''),
            website=details.get('website', ''),
            twitter=details.get('twitter', ''),
            telegram=details.get('telegram', ''),
            total_supply=details.get('total_supply', 0),
            circulating_supply=details.get('circulating_supply', 0),
            max_supply=details.get('max_supply', 0)
        )
        
        logger.info(f"已保存 {symbol} 币种详情到数据库")
    
    return details

def fetch_coingecko_coin_details(symbol: str) -> Dict[str, Any]:
    """
    使用CoinGecko API获取币种详情
    
    Args:
        symbol: 币种符号，如 'BTC'
        
    Returns:
        币种详细信息字典
    """
    try:
        # 首先获取币种ID
        url = "https://api.coingecko.com/api/v3/coins/list"
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        coins = response.json()
        
        # 查找匹配的币种
        coin_id = None
        for coin in coins:
            if coin['symbol'].upper() == symbol.upper():
                coin_id = coin['id']
                break
        
        if not coin_id:
            logger.error(f"在CoinGecko找不到币种 {symbol}")
            return {}
        
        # 获取币种详情
        url = f"https://api.coingecko.com/api/v3/coins/{coin_id}?localization=false&tickers=false&market_data=true&community_data=true&developer_data=false"
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        coin_data = response.json()
        
        # 提取所需信息
        details = {
            'symbol': symbol,
            'name': coin_data.get('name', ''),
            'description': coin_data.get('description', {}).get('en', ''),
            'website': coin_data.get('links', {}).get('homepage', [''])[0],
            'twitter': f"https://twitter.com/{coin_data.get('links', {}).get('twitter_screen_name', '')}",
            'telegram': coin_data.get('links', {}).get('telegram_channel_identifier', ''),
            'total_supply': coin_data.get('market_data', {}).get('total_supply', 0),
            'circulating_supply': coin_data.get('market_data', {}).get('circulating_supply', 0),
            'max_supply': coin_data.get('market_data', {}).get('max_supply', 0)
        }
        
        # 格式化Telegram链接
        if details['telegram'] and not details['telegram'].startswith('http'):
            details['telegram'] = f"https://t.me/{details['telegram']}"
        
        return details
        
    except Exception as e:
        logger.error(f"获取CoinGecko币种 {symbol} 详情失败: {str(e)}")
        return {}

def analyze_price_change(exchange: str, symbol: str, price_change: float) -> str:
    """
    分析币种价格变化原因
    
    Args:
        exchange: 交易所名称 ('binance' 或 'gate')
        symbol: 币种符号，如 'BTC'
        price_change: 价格变化百分比
        
    Returns:
        分析结果文本
    """
    logger.info(f"开始分析 {exchange} 交易所 {symbol} 价格变化原因...")
    
    # 根据交易所选择不同的分析方法
    if exchange == 'binance':
        analysis_result = analyze_binance_price_change(symbol)
    else:  # gate
        analysis_result = analyze_gate_price_change(symbol)
    
    analysis = analysis_result.get('analysis', '')
    
    # 如果分析结果为空，提供一个通用分析
    if not analysis:
        if price_change > 0:
            analysis = f"{symbol}价格在过去24小时内上涨了{price_change:.2f}%。这可能是由于市场情绪改善、项目进展或大型投资者买入等因素导致。建议关注该项目的最新动态和市场整体趋势。"
        else:
            analysis = f"{symbol}价格在过去24小时内下跌了{abs(price_change):.2f}%。这可能是由于市场情绪恶化、利空消息或大型投资者抛售等因素导致。建议关注该项目的最新动态和市场整体趋势。"
    
    # 增加市场相关性分析
    try:
        # 获取BTC价格变化作为参考
        if exchange == 'binance':
            btc_analysis = analyze_binance_price_change('BTC')
        else:
            btc_analysis = analyze_gate_price_change('BTC')
        
        btc_price_changes = btc_analysis.get('price_changes', [])
        if btc_price_changes:
            btc_latest_change = btc_price_changes[-1]
            
            # 计算与BTC的相关性
            if (price_change > 0 and btc_latest_change > 0) or (price_change < 0 and btc_latest_change < 0):
                if abs(price_change) > abs(btc_latest_change) * 1.5:
                    analysis += f"\n\n与比特币相比，{symbol}表现更为强势，可能有独立的利好因素影响。"
                elif abs(price_change) < abs(btc_latest_change) * 0.5:
                    analysis += f"\n\n尽管与比特币走势一致，但{symbol}表现相对较弱，可能存在一些项目特有的不确定性。"
                else:
                    analysis += f"\n\n{symbol}价格变动与比特币基本一致，可能主要受整体市场情绪影响。"
            else:
                analysis += f"\n\n{symbol}价格走势与比特币相反，表明可能有独立的项目因素在起作用。"
    except Exception as e:
        logger.error(f"添加市场相关性分析失败: {str(e)}")
    
    return analysis

def format_price_alert_message(
    exchange: str,
    symbol: str,
    price: float,
    price_change: float,
    volume: float,
    market_cap: float,
    details: Dict[str, Any],
    analysis: str
) -> str:
    """
    格式化价格预警消息
    
    Args:
        exchange: 交易所名称
        symbol: 币种符号
        price: 当前价格
        price_change: 价格变化百分比
        volume: 24小时交易量
        market_cap: 市值
        details: 币种详情
        analysis: 价格变化分析
        
    Returns:
        格式化的消息文本
    """
    # 确定涨跌方向图标
    direction = "📈" if price_change >= 0 else "📉"
    
    # 格式化消息
    message = MESSAGE_TEMPLATES['price_alert'].format(
        coin_name=details.get('name', symbol),
        symbol=symbol,
        price=format_number(price, 8),
        price_change=abs(price_change),
        direction=direction,
        market_cap=format_number(market_cap),
        volume=format_number(volume),
        description=details.get('description', '')[:500] + '...' if len(details.get('description', '')) > 500 else details.get('description', ''),
        website=details.get('website', '#'),
        twitter=details.get('twitter', '#'),
        telegram=details.get('telegram', '#'),
        analysis=analysis
    )
    
    return message

def format_new_listing_message(
    exchange: str,
    symbol: str,
    name: str,
    listing_time: int,
    initial_price: float,
    details: Dict[str, Any]
) -> str:
    """
    格式化新币上线消息
    
    Args:
        exchange: 交易所名称
        symbol: 币种符号
        name: 币种名称
        listing_time: 上线时间戳
        initial_price: 初始价格
        details: 币种详情
        
    Returns:
        格式化的消息文本
    """
    # 格式化消息
    message = MESSAGE_TEMPLATES['new_listing'].format(
        exchange=exchange.upper(),
        coin_name=name,
        symbol=symbol,
        listing_time=format_timestamp(listing_time),
        description=details.get('description', '')[:500] + '...' if len(details.get('description', '')) > 500 else details.get('description', ''),
        website=details.get('website', '#'),
        twitter=details.get('twitter', '#'),
        telegram=details.get('telegram', '#'),
        initial_price=format_number(initial_price, 8) if initial_price > 0 else "待定"
    )
    
    return message

def process_price_alert(alert: Dict[str, Any]) -> str:
    """
    处理价格预警，获取币种详情并生成消息
    
    Args:
        alert: 价格预警信息
        
    Returns:
        格式化的消息文本
    """
    exchange = alert['exchange']
    symbol = alert['symbol']
    price = alert['price']
    price_change = alert['price_change_24h']
    volume = alert['volume_24h']
    market_cap = alert['market_cap']
    
    # 获取币种详情
    details = fetch_coin_details(exchange, symbol)
    
    # 分析价格变化原因
    analysis = analyze_price_change(exchange, symbol, price_change)
    
    # 格式化消息
    message = format_price_alert_message(
        exchange=exchange,
        symbol=symbol,
        price=price,
        price_change=price_change,
        volume=volume,
        market_cap=market_cap,
        details=details,
        analysis=analysis
    )
    
    return message

def process_new_listing(listing: Dict[str, Any]) -> str:
    """
    处理新币上线，获取币种详情并生成消息
    
    Args:
        listing: 新币上线信息
        
    Returns:
        格式化的消息文本
    """
    exchange = listing['exchange']
    symbol = listing['symbol']
    name = listing['name']
    listing_time = listing['listing_time']
    initial_price = listing.get('initial_price', 0)
    
    # 获取币种详情
    details = fetch_coin_details(exchange, symbol)
    
    # 格式化消息
    message = format_new_listing_message(
        exchange=exchange,
        symbol=symbol,
        name=name,
        listing_time=listing_time,
        initial_price=initial_price,
        details=details
    )
    
    return message

if __name__ == '__main__':
    # 测试代码
    test_symbol = 'BTC'
    
    # 测试币种详情抓取
    details = fetch_coin_details('binance', test_symbol)
    print(f"币种名称: {details.get('name', '')}")
    print(f"币种描述: {details.get('description', '')[:100]}...")
    print(f"官网: {details.get('website', '')}")
    print(f"Twitter: {details.get('twitter', '')}")
    print(f"Telegram: {details.get('telegram', '')}")
    print("-" * 50)
    
    # 测试价格变化分析
    analysis = analyze_price_change('binance', test_symbol, 5.0)
    print(f"价格变化分析: {analysis}")
    print("-" * 50)
    
    # 测试消息格式化
    message = format_price_alert_message(
        exchange='binance',
        symbol=test_symbol,
        price=30000.0,
        price_change=5.0,
        volume=1000000000.0,
        market_cap=500000000000.0,
        details=details,
        analysis=analysis
    )
    print(message)
