#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
主程序入口，集成所有功能模块
"""

import time
import logging
import argparse
import os
import sys
from datetime import datetime

# 导入配置和工具模块
from config import MONITOR_CONFIG, STORAGE_CONFIG
from utils import logger, init_database

# 导入功能模块
from binance_monitor import monitor_binance_prices
from gate_monitor import monitor_gate_prices
from listing_monitor import monitor_new_listings
from telegram_push import process_and_push_alerts, process_and_push_new_listings

def setup_environment():
    """
    设置运行环境
    """
    # 确保数据目录存在
    data_dir = os.path.dirname(STORAGE_CONFIG['db_file'])
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    
    # 初始化数据库
    init_database()
    
    logger.info("环境设置完成")

def run_monitoring_cycle():
    """
    运行一次完整的监控周期
    """
    try:
        # 监控币安价格
        binance_alerts = monitor_binance_prices()
        logger.info(f"币安价格监控完成，发现 {len(binance_alerts)} 个预警")
        
        # 监控Gate.io价格
        gate_alerts = monitor_gate_prices()
        logger.info(f"Gate.io价格监控完成，发现 {len(gate_alerts)} 个预警")
        
        # 监控新币上线
        new_listings = monitor_new_listings()
        logger.info(f"新币上线监控完成，发现 {len(new_listings)} 个新币")
        
        # 处理并推送价格预警
        process_and_push_alerts()
        
        # 处理并推送新币上线信息
        process_and_push_new_listings()
        
        logger.info("监控周期完成")
        
        return True
    except Exception as e:
        logger.error(f"监控周期执行失败: {str(e)}")
        return False

def run_continuous_monitoring():
    """
    持续运行监控程序
    """
    logger.info("开始持续监控...")
    
    cycle_count = 0
    
    try:
        while True:
            cycle_start_time = time.time()
            
            # 记录周期开始
            cycle_count += 1
            logger.info(f"开始第 {cycle_count} 个监控周期...")
            
            # 运行监控周期
            success = run_monitoring_cycle()
            
            # 计算周期耗时
            cycle_duration = time.time() - cycle_start_time
            logger.info(f"第 {cycle_count} 个监控周期耗时 {cycle_duration:.2f} 秒")
            
            # 计算需要等待的时间
            wait_time = max(0, MONITOR_CONFIG['polling_interval'] - cycle_duration)
            
            if wait_time > 0:
                logger.info(f"等待 {wait_time:.2f} 秒进行下一个监控周期...")
                time.sleep(wait_time)
            
    except KeyboardInterrupt:
        logger.info("收到中断信号，程序退出")
    except Exception as e:
        logger.error(f"持续监控过程中发生错误: {str(e)}")
        raise

def run_single_cycle():
    """
    运行单次监控周期（用于测试）
    """
    logger.info("开始单次监控周期...")
    
    setup_environment()
    success = run_monitoring_cycle()
    
    if success:
        logger.info("单次监控周期成功完成")
    else:
        logger.error("单次监控周期执行失败")

def main():
    """
    主函数
    """
    parser = argparse.ArgumentParser(description='加密货币监控程序')
    parser.add_argument('--test', action='store_true', help='运行单次监控周期（测试模式）')
    parser.add_argument('--log-level', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        default='INFO', help='日志级别')
    
    args = parser.parse_args()
    
    # 设置日志级别
    logger.setLevel(getattr(logging, args.log_level))
    
    # 设置环境
    setup_environment()
    
    # 根据参数决定运行模式
    if args.test:
        run_single_cycle()
    else:
        run_continuous_monitoring()

if __name__ == '__main__':
    main()
