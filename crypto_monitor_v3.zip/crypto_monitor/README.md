# 加密货币监控脚本使用说明

## 项目概述

本项目是一个加密货币监控脚本，可以监控币安和Gate.io交易所的所有加密货币24小时涨跌幅，以及新币上线公告。当币种涨跌幅达到设定阈值或发现新币上线时，脚本会自动抓取币种详情并通过Telegram推送通知。

## 主要功能

1. **价格监控**：监控币安和Gate.io所有交易对的24小时涨跌幅
2. **新币监控**：监控币安和Gate.io的新币上线公告
3. **阈值自定义**：支持自定义涨跌幅阈值
4. **API轮换**：支持多API密钥轮换，避免请求限制
5. **Telegram多账号**：支持多个Telegram机器人轮换推送，避免风控
6. **详情抓取**：当触发条件时，自动抓取币种详细信息
7. **原因分析**：自动分析币种价格变化原因

## 一键安装

### 快速开始

1. 解压下载的压缩包
2. 进入项目目录
3. 运行安装脚本

```bash
cd crypto_monitor
chmod +x install.sh
./install.sh
```

安装脚本会自动：
- 检查系统环境
- 安装Python和必要组件（如果缺失）
- 创建虚拟环境
- 安装所有依赖包
- 配置脚本环境
- 创建启动和停止脚本

### 启动和停止

安装完成后，使用以下命令启动和停止脚本：

```bash
# 前台运行
./start.sh

# 后台运行
./start_daemon.sh

# 停止运行
./stop.sh

# 测试模式（单次运行）
./start.sh --test
```

## 手动安装

如果一键安装脚本无法在您的环境中正常工作，您也可以按照以下步骤手动安装：

### 系统要求

- Python 3.7+
- 互联网连接
- 币安和Gate.io API密钥（可选，用于访问更多数据）
- Telegram机器人Token和聊天ID

### 安装依赖

```bash
pip install -r requirements.txt
```

### 配置文件

编辑 `config.py` 文件，设置以下内容：

1. **API配置**：
   - 添加币安和Gate.io的API密钥（可选）
   - 可添加多个API密钥用于轮换

2. **Telegram配置**：
   - 添加Telegram机器人Token和聊天ID
   - 可添加多个机器人用于轮换
   - 设置轮换间隔

3. **监控配置**：
   - 设置涨跌幅阈值
   - 设置API轮询间隔
   - 设置排除的交易对
   - 设置最小市值和交易量要求

示例：

```python
# API配置
API_CONFIG = {
    'binance': {
        'api_keys': [
            ('your_binance_api_key_1', 'your_binance_api_secret_1'),
            ('your_binance_api_key_2', 'your_binance_api_secret_2'),
        ],
        # 其他配置...
    },
    'gate': {
        'api_keys': [
            ('your_gate_api_key_1', 'your_gate_api_secret_1'),
            ('your_gate_api_key_2', 'your_gate_api_secret_2'),
        ],
        # 其他配置...
    }
}

# Telegram配置
TELEGRAM_CONFIG = {
    'bots': [
        {'token': 'your_telegram_bot_token_1', 'chat_ids': ['chat_id_1', 'chat_id_2']},
        {'token': 'your_telegram_bot_token_2', 'chat_ids': ['chat_id_3', 'chat_id_4']},
    ],
    'rotation_interval': 10,  # 每发送多少条消息后切换到下一个机器人
}

# 监控配置
MONITOR_CONFIG = {
    'price_change_thresholds': {
        'increase': 5.0,  # 涨幅阈值，百分比
        'decrease': -5.0,  # 跌幅阈值，百分比
    },
    'polling_interval': 60,  # API轮询间隔，单位秒
    # 其他配置...
}
```

## 运行脚本

### 测试模式

运行单次监控周期（用于测试配置是否正确）：

```bash
python main.py --test
```

### 持续监控模式

持续运行监控程序：

```bash
python main.py
```

### 后台运行

使用nohup或screen在服务器后台运行：

```bash
nohup python main.py > crypto_monitor.log 2>&1 &
```

或者

```bash
screen -S crypto_monitor
python main.py
# 按 Ctrl+A 然后按 D 分离screen
```

## 推送消息格式

### 价格预警消息

```
🚨 价格预警 🚨
币种: 比特币 (BTC)
价格: 30,000 USDT
24小时涨跌幅: 5.0% 📈
市值: 500B USD
24小时交易量: 1B USD

📊 币种简介:
比特币是一种基于去中心化，采用点对点网络与共识主动性，开放源代码，以区块链作为底层技术的加密货币...

🔗 链接:
[官网](https://bitcoin.org)
[Twitter](https://twitter.com/bitcoin)
[Telegram](https://t.me/bitcoin)

📈 涨跌原因分析:
BTC价格上涨5.0%，交易量增加20.5%，市场买盘活跃，短期看涨。与整体市场趋势一致，可能受到宏观经济数据改善的影响。
```

### 新币上线消息

```
🔔 新币上线公告 🔔
交易所: BINANCE
币种: 新币名称 (XYZ)
上线时间: 2025-06-01 12:00:00

📊 币种简介:
这是一个创新的区块链项目，专注于...

🔗 链接:
[官网](https://xyz.org)
[Twitter](https://twitter.com/xyz)
[Telegram](https://t.me/xyz)

💰 初始价格: 1.0 USDT
```

## 项目结构

```
crypto_monitor/
├── config.py           # 配置文件
├── utils.py            # 工具函数
├── binance_monitor.py  # 币安价格监控
├── gate_monitor.py     # Gate.io价格监控
├── listing_monitor.py  # 新币上线监控
├── coin_details.py     # 币种详情抓取
├── telegram_push.py    # Telegram推送
├── main.py             # 主程序入口
├── requirements.txt    # 依赖列表
├── install.sh          # 一键安装脚本
├── start.sh            # 启动脚本
├── start_daemon.sh     # 后台启动脚本
└── stop.sh             # 停止脚本
```

## 注意事项

1. 本脚本需要部署在您自己的服务器上才能持续运行
2. 请确保服务器有稳定的网络连接
3. 请遵守交易所的API使用限制
4. 推送频率过高可能导致Telegram机器人被限制，请合理设置阈值和轮换间隔
5. 本脚本仅供参考，投资决策请自行判断

## 常见问题

1. **如何创建Telegram机器人？**
   - 在Telegram中搜索 @BotFather
   - 发送 /newbot 命令
   - 按照提示设置机器人名称和用户名
   - 获取API Token

2. **如何获取聊天ID？**
   - 在Telegram中搜索 @userinfobot
   - 发送任意消息
   - 机器人会返回您的聊天ID

3. **如何获取交易所API密钥？**
   - 登录币安或Gate.io账户
   - 进入API管理页面
   - 创建新的API密钥
   - 注意保存API密钥和密钥，它们只显示一次

4. **如何调整监控参数？**
   - 编辑 config.py 文件中的 MONITOR_CONFIG 部分
   - 修改涨跌幅阈值、轮询间隔等参数
   - 重启脚本使更改生效

5. **如何添加更多交易所？**
   - 参考现有的币安和Gate.io监控模块
   - 创建新的交易所监控模块
   - 在 config.py 中添加新交易所的API配置
   - 在 main.py 中集成新模块

## 故障排除

1. **脚本无法启动**
   - 检查Python版本是否为3.7+
   - 检查是否安装了所有依赖
   - 检查配置文件是否正确

2. **无法获取交易所数据**
   - 检查网络连接
   - 检查API密钥是否正确
   - 检查API请求频率是否过高

3. **无法发送Telegram消息**
   - 检查机器人Token是否正确
   - 检查聊天ID是否正确
   - 确认机器人已被添加到聊天中
   - 检查是否达到Telegram API限制

4. **数据库错误**
   - 检查数据目录权限
   - 检查磁盘空间是否充足
   - 尝试删除数据库文件重新初始化

5. **安装脚本失败**
   - 尝试手动安装依赖：`pip install -r requirements.txt`
   - 检查系统是否满足最低要求
   - 查看安装日志以获取详细错误信息

## 更新日志

- 2025-06-01: 初始版本发布
- 2025-06-01: 添加一键安装脚本
