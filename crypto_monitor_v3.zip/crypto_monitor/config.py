#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
加密货币监控配置文件
"""

# API配置
API_CONFIG = {
    # 币安API配置
    'binance': {
        'api_keys': [
            # 添加多个API密钥用于轮换，格式: (api_key, api_secret)
            # ('your_binance_api_key_1', 'your_binance_api_secret_1'),
            # ('your_binance_api_key_2', 'your_binance_api_secret_2'),
        ],
        'base_url': 'https://api.binance.com',
        'ticker_url': '/api/v3/ticker/24hr',
        'klines_url': '/api/v3/klines',
        'exchange_info_url': '/api/v3/exchangeInfo',
        'announcement_url': 'https://www.binance.com/bapi/composite/v1/public/cms/article/catalog/list/query',
        'coin_info_url': 'https://www.binance.com/bapi/asset/v2/public/asset/asset/get-asset-detail',
    },
    
    # Gate.io API配置
    'gate': {
        'api_keys': [
            # 添加多个API密钥用于轮换，格式: (api_key, api_secret)
            # ('your_gate_api_key_1', 'your_gate_api_secret_1'),
            # ('your_gate_api_key_2', 'your_gate_api_secret_2'),
        ],
        'base_url': 'https://api.gateio.ws/api/v4',
        'ticker_url': '/spot/tickers',
        'candlesticks_url': '/spot/candlesticks',
        'currency_pairs_url': '/spot/currency_pairs',
        'announcement_url': 'https://www.gate.io/articlelist/ann',
        'coin_info_url': 'https://www.gate.io/trade/{symbol}',
    }
}

# Telegram配置
TELEGRAM_CONFIG = {
    'bots': [
        # 添加多个Telegram机器人Token用于轮换
        # {'token': 'your_telegram_bot_token_1', 'chat_ids': ['chat_id_1', 'chat_id_2']},
        # {'token': 'your_telegram_bot_token_2', 'chat_ids': ['chat_id_3', 'chat_id_4']},
    ],
    'rotation_interval': 10,  # 每发送多少条消息后切换到下一个机器人
}

# 监控配置
MONITOR_CONFIG = {
    'price_change_thresholds': {
        'increase': 5.0,  # 涨幅阈值，百分比
        'decrease': -5.0,  # 跌幅阈值，百分比
    },
    'polling_interval': 60,  # API轮询间隔，单位秒
    'max_retries': 3,  # API请求失败重试次数
    'retry_delay': 5,  # API请求失败重试延迟，单位秒
    'rotation_strategy': {
        'api_rotation_count': 100,  # 每发送多少请求后切换到下一个API密钥
        'user_agent_rotation': True,  # 是否启用User-Agent轮换
    },
    'excluded_symbols': [
        # 排除的交易对，例如稳定币等
        'USDT', 'USDC', 'BUSD', 'DAI', 'TUSD'
    ],
    'min_market_cap': 1000000,  # 最小市值，单位美元
    'min_volume': 100000,  # 最小24小时交易量，单位美元
}

# 推送消息模板
MESSAGE_TEMPLATES = {
    'price_alert': """
🚨 *价格预警* 🚨
币种: {coin_name} ({symbol})
价格: {price} USDT
24小时涨跌幅: {price_change}% {direction}
市值: {market_cap} USD
24小时交易量: {volume} USD

📊 *币种简介*:
{description}

🔗 *链接*:
[官网]({website})
[Twitter]({twitter})
[Telegram]({telegram})

📈 *涨跌原因分析*:
{analysis}
    """,
    
    'new_listing': """
🔔 *新币上线公告* 🔔
交易所: {exchange}
币种: {coin_name} ({symbol})
上线时间: {listing_time}

📊 *币种简介*:
{description}

🔗 *链接*:
[官网]({website})
[Twitter]({twitter})
[Telegram]({telegram})

💰 *初始价格*: {initial_price} USDT
    """
}

# 用户代理列表，用于API请求轮换
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (iPad; CPU OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
]

# 代理配置（可选）
PROXY_CONFIG = {
    'enabled': False,
    'proxies': [
        # 添加代理服务器，格式: {'http': 'http://host:port', 'https': 'https://host:port'}
        # {'http': 'http://proxy1.example.com:8080', 'https': 'https://proxy1.example.com:8080'},
        # {'http': 'http://proxy2.example.com:8080', 'https': 'https://proxy2.example.com:8080'},
    ],
    'rotation_interval': 50,  # 每发送多少请求后切换到下一个代理
}

# 日志配置
LOG_CONFIG = {
    'log_level': 'INFO',  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    'log_file': 'crypto_monitor.log',
    'max_log_size': 10 * 1024 * 1024,  # 10MB
    'backup_count': 5,
}

# 数据存储配置
STORAGE_CONFIG = {
    'db_file': 'crypto_data.db',  # SQLite数据库文件
    'cache_expire': 3600,  # 缓存过期时间，单位秒
}
