#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VLESS 代理管理模块
提供 VLESS 代理服务器的配置和连接管理功能
"""

import json
import uuid
import requests
import logging
import time
import base64
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse, parse_qs, unquote
import re

logger = logging.getLogger(__name__)

class VLESSProxyManager:
    """VLESS 代理管理器"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        self.servers = []
        self.current_server = None
        self.load_servers()
    
    def load_servers(self):
        """从配置和数据库加载服务器列表"""
        try:
            # 从配置文件加载
            vless_config = self.config.get('proxy.vless', {})
            config_servers = vless_config.get('servers', [])
            
            # 从数据库加载
            db_servers = self.db.get_proxy_servers('vless')
            
            # 合并服务器列表
            self.servers = []
            
            # 添加配置文件中的服务器
            for server in config_servers:
                if self.validate_vless_config(server):
                    self.servers.append(server)
            
            # 添加数据库中的服务器
            for db_server in db_servers:
                try:
                    server_config = json.loads(db_server['config'])
                    server_config['id'] = db_server['server_id']
                    server_config['name'] = db_server['name']
                    server_config['priority'] = db_server['priority']
                    server_config['active'] = bool(db_server['active'])
                    
                    if self.validate_vless_config(server_config):
                        self.servers.append(server_config)
                except Exception as e:
                    logger.error(f"加载数据库服务器配置失败: {e}")
            
            # 按优先级排序
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已加载 {len(self.servers)} 个 VLESS 服务器")
            
        except Exception as e:
            logger.error(f"加载 VLESS 服务器失败: {e}")
            self.servers = []
    
    def validate_vless_config(self, config: Dict) -> bool:
        """验证 VLESS 配置"""
        try:
            # 必填字段检查
            required_fields = ['address', 'port', 'uuid']
            for field in required_fields:
                if field not in config:
                    logger.error(f"VLESS 配置缺少必填字段: {field}")
                    return False
            
            # 地址验证
            address = config['address']
            if not self._is_valid_address(address):
                logger.error(f"无效的服务器地址: {address}")
                return False
            
            # 端口验证
            port = config['port']
            if not isinstance(port, int) or port < 1 or port > 65535:
                logger.error(f"无效的端口号: {port}")
                return False
            
            # UUID 验证
            uuid_str = config['uuid']
            if not self._is_valid_uuid(uuid_str):
                logger.error(f"无效的 UUID: {uuid_str}")
                return False
            
            # 网络类型验证
            network = config.get('network', 'tcp')
            if network not in ['tcp', 'ws', 'grpc']:
                logger.error(f"不支持的网络类型: {network}")
                return False
            
            # 安全类型验证
            security = config.get('security', 'none')
            if security not in ['none', 'tls', 'reality']:
                logger.error(f"不支持的安全类型: {security}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"VLESS 配置验证失败: {e}")
            return False
    
    def _is_valid_address(self, address: str) -> bool:
        """验证地址格式"""
        # 域名格式验证
        domain_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        # IP 地址格式验证
        ip_pattern = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        
        return bool(re.match(domain_pattern, address) or re.match(ip_pattern, address))
    
    def _is_valid_uuid(self, uuid_str: str) -> bool:
        """验证 UUID 格式"""
        try:
            uuid.UUID(uuid_str)
            return True
        except ValueError:
            return False
    
    def add_server(self, config: Dict) -> Dict:
        """添加 VLESS 服务器"""
        try:
            # 生成服务器 ID
            if 'id' not in config:
                config['id'] = f"vless-{uuid.uuid4().hex[:8]}"
            
            # 设置默认值
            config.setdefault('name', f"VLESS 服务器 {len(self.servers) + 1}")
            config.setdefault('encryption', 'none')
            config.setdefault('network', 'tcp')
            config.setdefault('security', 'none')
            config.setdefault('priority', 1)
            config.setdefault('active', True)
            
            # 验证配置
            if not self.validate_vless_config(config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 保存到数据库
            self.db.add_proxy_server(
                protocol='vless',
                server_id=config['id'],
                name=config['name'],
                config=json.dumps(config),
                priority=config['priority'],
                active=config['active']
            )
            
            # 添加到内存列表
            self.servers.append(config)
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已添加 VLESS 服务器: {config['name']}")
            
            return {
                'success': True,
                'server_id': config['id'],
                'message': f"VLESS 服务器 '{config['name']}' 添加成功"
            }
            
        except Exception as e:
            logger.error(f"添加 VLESS 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def update_server(self, server_id: str, config: Dict) -> Dict:
        """更新 VLESS 服务器配置"""
        try:
            # 查找服务器
            server_index = None
            for i, server in enumerate(self.servers):
                if server.get('id') == server_id:
                    server_index = i
                    break
            
            if server_index is None:
                return {'success': False, 'message': '服务器不存在'}
            
            # 更新配置
            updated_config = self.servers[server_index].copy()
            updated_config.update(config)
            updated_config['id'] = server_id  # 确保 ID 不变
            
            # 验证配置
            if not self.validate_vless_config(updated_config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 更新数据库
            self.db.update_proxy_server(
                server_id=server_id,
                name=updated_config['name'],
                config=json.dumps(updated_config),
                priority=updated_config['priority'],
                active=updated_config['active']
            )
            
            # 更新内存列表
            self.servers[server_index] = updated_config
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已更新 VLESS 服务器: {updated_config['name']}")
            
            return {
                'success': True,
                'message': f"VLESS 服务器 '{updated_config['name']}' 更新成功"
            }
            
        except Exception as e:
            logger.error(f"更新 VLESS 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def delete_server(self, server_id: str) -> Dict:
        """删除 VLESS 服务器"""
        try:
            # 查找服务器
            server_index = None
            server_name = None
            for i, server in enumerate(self.servers):
                if server.get('id') == server_id:
                    server_index = i
                    server_name = server.get('name', server_id)
                    break
            
            if server_index is None:
                return {'success': False, 'message': '服务器不存在'}
            
            # 从数据库删除
            self.db.delete_proxy_server(server_id)
            
            # 从内存列表删除
            del self.servers[server_index]
            
            # 如果删除的是当前服务器，清除当前服务器
            if self.current_server and self.current_server.get('id') == server_id:
                self.current_server = None
            
            logger.info(f"已删除 VLESS 服务器: {server_name}")
            
            return {
                'success': True,
                'message': f"VLESS 服务器 '{server_name}' 删除成功"
            }
            
        except Exception as e:
            logger.error(f"删除 VLESS 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_servers(self) -> List[Dict]:
        """获取所有 VLESS 服务器"""
        return self.servers.copy()
    
    def get_server(self, server_id: str) -> Optional[Dict]:
        """获取指定的 VLESS 服务器"""
        for server in self.servers:
            if server.get('id') == server_id:
                return server.copy()
        return None
    
    def test_connection(self, server_id: str) -> Dict:
        """测试 VLESS 服务器连接"""
        try:
            server = self.get_server(server_id)
            if not server:
                return {'success': False, 'message': '服务器不存在'}
            
            # 构建代理 URL
            proxy_url = self._build_proxy_url(server)
            if not proxy_url:
                return {'success': False, 'message': '无法构建代理 URL'}
            
            # 测试连接
            start_time = time.time()
            
            proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
            
            response = requests.get(
                'http://httpbin.org/ip',
                proxies=proxies,
                timeout=10
            )
            
            end_time = time.time()
            response_time = int((end_time - start_time) * 1000)
            
            if response.status_code == 200:
                data = response.json()
                external_ip = data.get('origin', 'Unknown')
                
                # 记录连接日志
                self.db.log_proxy_connection(
                    server_id=server_id,
                    protocol='vless',
                    response_time=response_time,
                    success=True,
                    external_ip=external_ip
                )
                
                return {
                    'success': True,
                    'response_time': response_time,
                    'external_ip': external_ip,
                    'message': 'VLESS 连接测试成功'
                }
            else:
                error_msg = f'HTTP 错误: {response.status_code}'
                
                # 记录连接日志
                self.db.log_proxy_connection(
                    server_id=server_id,
                    protocol='vless',
                    response_time=response_time,
                    success=False,
                    error_message=error_msg
                )
                
                return {'success': False, 'message': error_msg}
                
        except requests.exceptions.ProxyError as e:
            error_msg = f'代理连接失败: {str(e)}'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='vless',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
            
        except requests.exceptions.Timeout:
            error_msg = '连接超时'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='vless',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
            
        except Exception as e:
            error_msg = f'未知错误: {str(e)}'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='vless',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
    
    def _build_proxy_url(self, server: Dict) -> Optional[str]:
        """构建代理 URL"""
        try:
            # 注意：这里只是示例，实际的 VLESS 代理需要专门的客户端
            # 在实际应用中，需要集成 v2ray-core 或其他 VLESS 客户端
            
            # 这里返回一个占位符 URL，实际实现需要根据具体的代理客户端来构建
            address = server['address']
            port = server['port']
            
            # 简化的 URL 构建（实际需要更复杂的处理）
            return f"socks5://127.0.0.1:1080"  # 假设本地有 VLESS 客户端监听此端口
            
        except Exception as e:
            logger.error(f"构建 VLESS 代理 URL 失败: {e}")
            return None
    
    def get_proxy_config(self, server_id: str) -> Optional[Dict]:
        """获取代理配置"""
        server = self.get_server(server_id)
        if not server:
            return None
        
        proxy_url = self._build_proxy_url(server)
        if not proxy_url:
            return None
        
        return {
            'http': proxy_url,
            'https': proxy_url
        }
    
    def health_check(self) -> Dict:
        """健康检查所有服务器"""
        results = []
        
        for server in self.servers:
            if not server.get('active', True):
                continue
            
            server_id = server.get('id')
            result = self.test_connection(server_id)
            
            results.append({
                'server_id': server_id,
                'name': server.get('name', server_id),
                'healthy': result['success'],
                'response_time': result.get('response_time'),
                'error_message': result.get('message') if not result['success'] else None
            })
        
        return {
            'success': True,
            'protocol': 'vless',
            'results': results,
            'total_servers': len(self.servers),
            'healthy_servers': len([r for r in results if r['healthy']])
        }
    
    def get_best_server(self) -> Optional[Dict]:
        """获取最佳服务器"""
        active_servers = [s for s in self.servers if s.get('active', True)]
        if not active_servers:
            return None
        
        # 按优先级返回第一个活跃服务器
        return active_servers[0]
    
    def set_current_server(self, server_id: str) -> Dict:
        """设置当前使用的服务器"""
        server = self.get_server(server_id)
        if not server:
            return {'success': False, 'message': '服务器不存在'}
        
        self.current_server = server
        
        return {
            'success': True,
            'message': f"已切换到 VLESS 服务器: {server['name']}"
        }
    
    def get_current_server(self) -> Optional[Dict]:
        """获取当前使用的服务器"""
        return self.current_server.copy() if self.current_server else None
    
    def parse_vless_uri(self, vless_uri: str) -> Dict:
        """解析 VLESS URI 并返回配置信息"""
        try:
            # 检查 URI 格式
            if not vless_uri.startswith('vless://'):
                return {'success': False, 'message': '无效的 VLESS URI 格式'}
            
            # 移除 vless:// 前缀
            uri_content = vless_uri[8:]
            
            # 分离片段标识符（名称部分）
            if '#' in uri_content:
                uri_content, fragment = uri_content.split('#', 1)
                server_name = unquote(fragment)
            else:
                server_name = f"VLESS 服务器 {len(self.servers) + 1}"
            
            # 分离查询参数
            if '?' in uri_content:
                uri_base, query_string = uri_content.split('?', 1)
                query_params = parse_qs(query_string)
            else:
                uri_base = uri_content
                query_params = {}
            
            # 解析基本信息 (UUID@address:port)
            if '@' not in uri_base:
                return {'success': False, 'message': 'URI 格式错误：缺少 @ 符号'}
            
            uuid_part, address_port = uri_base.split('@', 1)
            
            # 验证 UUID
            if not self._is_valid_uuid(uuid_part):
                return {'success': False, 'message': f'无效的 UUID: {uuid_part}'}
            
            # 解析地址和端口
            if ':' not in address_port:
                return {'success': False, 'message': 'URI 格式错误：缺少端口号'}
            
            address, port_str = address_port.rsplit(':', 1)
            
            try:
                port = int(port_str)
                if port < 1 or port > 65535:
                    return {'success': False, 'message': f'无效的端口号: {port}'}
            except ValueError:
                return {'success': False, 'message': f'无效的端口号格式: {port_str}'}
            
            # 构建基本配置
            config = {
                'name': server_name,
                'address': address,
                'port': port,
                'uuid': uuid_part,
                'encryption': 'none',  # VLESS 默认不加密
                'network': 'tcp',      # 默认传输协议
                'security': 'none',    # 默认安全类型
                'priority': 1,
                'active': True
            }
            
            # 解析查询参数
            for key, values in query_params.items():
                if not values:
                    continue
                
                value = values[0]  # 取第一个值
                
                if key == 'type':
                    config['network'] = value
                elif key == 'encryption':
                    config['encryption'] = value
                elif key == 'security':
                    config['security'] = value
                elif key == 'sni':
                    config['sni'] = value
                elif key == 'alpn':
                    config['alpn'] = value
                elif key == 'fp':
                    config['fingerprint'] = value
                elif key == 'pbk':
                    config['public_key'] = value
                elif key == 'sid':
                    config['short_id'] = value
                elif key == 'flow':
                    config['flow'] = value
                elif key == 'path':
                    config['path'] = value
                elif key == 'host':
                    config['host'] = value
                elif key == 'serviceName':
                    config['service_name'] = value
                elif key == 'mode':
                    config['mode'] = value
                else:
                    # 保存未知参数
                    config[f'custom_{key}'] = value
            
            # 验证解析后的配置
            if not self.validate_vless_config(config):
                return {'success': False, 'message': '解析后的配置验证失败'}
            
            return {
                'success': True,
                'config': config,
                'message': f'VLESS URI 解析成功: {server_name}'
            }
            
        except Exception as e:
            logger.error(f"解析 VLESS URI 失败: {e}")
            return {'success': False, 'message': f'解析失败: {str(e)}'}
    
    def import_from_uri(self, vless_uri: str) -> Dict:
        """从 VLESS URI 导入服务器配置"""
        try:
            # 解析 URI
            parse_result = self.parse_vless_uri(vless_uri)
            if not parse_result['success']:
                return parse_result
            
            config = parse_result['config']
            
            # 检查是否已存在相同的服务器
            for existing_server in self.servers:
                if (existing_server.get('address') == config['address'] and 
                    existing_server.get('port') == config['port'] and
                    existing_server.get('uuid') == config['uuid']):
                    return {
                        'success': False, 
                        'message': f'服务器已存在: {existing_server.get("name", "未命名")}'
                    }
            
            # 添加服务器
            add_result = self.add_server(config)
            if add_result['success']:
                return {
                    'success': True,
                    'server_id': add_result['server_id'],
                    'config': config,
                    'message': f'从 URI 成功导入服务器: {config["name"]}'
                }
            else:
                return add_result
                
        except Exception as e:
            logger.error(f"从 URI 导入服务器失败: {e}")
            return {'success': False, 'message': f'导入失败: {str(e)}'}
    
    def export_to_uri(self, server_id: str) -> Dict:
        """将服务器配置导出为 VLESS URI"""
        try:
            server = self.get_server(server_id)
            if not server:
                return {'success': False, 'message': '服务器不存在'}
            
            # 构建基本 URI
            uuid_str = server['uuid']
            address = server['address']
            port = server['port']
            name = server.get('name', 'VLESS Server')
            
            uri = f"vless://{uuid_str}@{address}:{port}"
            
            # 构建查询参数
            params = []
            
            # 传输协议
            if server.get('network', 'tcp') != 'tcp':
                params.append(f"type={server['network']}")
            
            # 加密方式
            if server.get('encryption', 'none') != 'none':
                params.append(f"encryption={server['encryption']}")
            
            # 安全类型
            if server.get('security', 'none') != 'none':
                params.append(f"security={server['security']}")
            
            # 其他参数
            param_mapping = {
                'sni': 'sni',
                'alpn': 'alpn',
                'fingerprint': 'fp',
                'public_key': 'pbk',
                'short_id': 'sid',
                'flow': 'flow',
                'path': 'path',
                'host': 'host',
                'service_name': 'serviceName',
                'mode': 'mode'
            }
            
            for config_key, uri_key in param_mapping.items():
                if config_key in server and server[config_key]:
                    params.append(f"{uri_key}={server[config_key]}")
            
            # 添加自定义参数
            for key, value in server.items():
                if key.startswith('custom_') and value:
                    custom_key = key[7:]  # 移除 'custom_' 前缀
                    params.append(f"{custom_key}={value}")
            
            # 组装完整 URI
            if params:
                uri += '?' + '&'.join(params)
            
            # 添加名称
            uri += f"#{name}"
            
            return {
                'success': True,
                'uri': uri,
                'message': f'成功导出服务器 URI: {name}'
            }
            
        except Exception as e:
            logger.error(f"导出服务器 URI 失败: {e}")
            return {'success': False, 'message': f'导出失败: {str(e)}'}

