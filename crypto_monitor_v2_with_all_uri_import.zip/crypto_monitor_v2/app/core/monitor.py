#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
核心监控模块
负责价格监控和公告扫描的主要逻辑
"""

import logging
import threading
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any

from .api_client import ExchangeAPIManager
from .database import Database
from .notifications import NotificationManager

class CryptoMonitor:
    """加密货币监控器"""
    
    def __init__(self, config, database: Database):
        self.config = config
        self.db = database
        self.logger = logging.getLogger(__name__)
        
        # 初始化组件
        self.api_manager = ExchangeAPIManager(config)
        self.notification_manager = NotificationManager(config)
        
        # 监控状态
        self.is_running = False
        self.price_monitor_thread = None
        self.announcement_monitor_thread = None
        
        # 上次价格记录，用于比较变化
        self.last_prices = {}
    
    def start_monitoring(self):
        """启动监控"""
        if self.is_running:
            self.logger.warning("监控已在运行中")
            return
        
        self.is_running = True
        self.logger.info("启动加密货币监控...")
        
        # 启动价格监控线程
        self.price_monitor_thread = threading.Thread(
            target=self._price_monitor_loop, 
            daemon=True
        )
        self.price_monitor_thread.start()
        
        # 启动公告监控线程
        self.announcement_monitor_thread = threading.Thread(
            target=self._announcement_monitor_loop, 
            daemon=True
        )
        self.announcement_monitor_thread.start()
        
        self.logger.info("监控线程已启动")
    
    def stop_monitoring(self):
        """停止监控"""
        self.is_running = False
        self.logger.info("正在停止监控...")
        
        # 等待线程结束
        if self.price_monitor_thread and self.price_monitor_thread.is_alive():
            self.price_monitor_thread.join(timeout=5)
        
        if self.announcement_monitor_thread and self.announcement_monitor_thread.is_alive():
            self.announcement_monitor_thread.join(timeout=5)
        
        self.logger.info("监控已停止")
    
    def _price_monitor_loop(self):
        """价格监控循环"""
        self.logger.info("价格监控线程启动")
        
        while self.is_running:
            try:
                # 更新监控状态
                next_run = datetime.now() + timedelta(seconds=self.config.price_check_interval)
                self.db.update_monitor_status(
                    'price_monitor', 'running', 
                    '正在监控价格变动', next_run
                )
                
                # 执行价格监控
                changes_count = self._monitor_prices()
                
                self.logger.info(f"价格监控完成，发现 {changes_count} 个显著变动")
                
                # 等待下次检查
                time.sleep(self.config.price_check_interval)
                
            except Exception as e:
                self.logger.error(f"价格监控异常: {e}")
                self.db.update_monitor_status(
                    'price_monitor', 'error', 
                    f'监控异常: {str(e)}'
                )
                time.sleep(60)  # 出错后等待1分钟
        
        self.db.update_monitor_status('price_monitor', 'stopped', '监控已停止')
        self.logger.info("价格监控线程结束")
    
    def _announcement_monitor_loop(self):
        """公告监控循环"""
        self.logger.info("公告监控线程启动")
        
        while self.is_running:
            try:
                # 更新监控状态
                next_run = datetime.now() + timedelta(seconds=self.config.announcement_scan_interval)
                self.db.update_monitor_status(
                    'announcement_monitor', 'running', 
                    '正在扫描公告', next_run
                )
                
                # 执行公告扫描
                new_count = self._scan_announcements()
                
                self.logger.info(f"公告扫描完成，发现 {new_count} 条新公告")
                
                # 等待下次扫描
                time.sleep(self.config.announcement_scan_interval)
                
            except Exception as e:
                self.logger.error(f"公告监控异常: {e}")
                self.db.update_monitor_status(
                    'announcement_monitor', 'error', 
                    f'监控异常: {str(e)}'
                )
                time.sleep(60)  # 出错后等待1分钟
        
        self.db.update_monitor_status('announcement_monitor', 'stopped', '监控已停止')
        self.logger.info("公告监控线程结束")
    
    def _monitor_prices(self) -> int:
        """监控价格变动"""
        significant_changes = []
        
        # 获取所有交易所的ticker数据
        all_tickers = self.api_manager.get_all_tickers()
        
        for exchange, tickers in all_tickers.items():
            changes = self._process_tickers(exchange, tickers)
            significant_changes.extend(changes)
        
        # 保存到数据库
        for change in significant_changes:
            self.db.save_price_change(
                change['exchange'],
                change['symbol'],
                change['price'],
                change['change_percent'],
                change['direction']
            )
        
        # 发送通知
        if significant_changes:
            self.notification_manager.send_price_notifications(significant_changes)
        
        return len(significant_changes)
    
    def _process_tickers(self, exchange: str, tickers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """处理ticker数据，识别显著价格变动"""
        significant_changes = []
        threshold = self.config.price_change_threshold
        
        for ticker in tickers:
            try:
                if exchange == 'binance':
                    symbol = ticker['symbol']
                    price = float(ticker['lastPrice'])
                    change_percent = float(ticker['priceChangePercent'])
                elif exchange == 'gate':
                    symbol = ticker['currency_pair']
                    price = float(ticker['last'])
                    change_percent = float(ticker.get('change_percentage', 0))
                else:
                    continue
                
                # 检查是否超过阈值
                if abs(change_percent) >= threshold:
                    direction = "上涨" if change_percent > 0 else "下跌"
                    
                    change_data = {
                        "exchange": exchange.title(),
                        "symbol": symbol,
                        "price": price,
                        "change_percent": change_percent,
                        "direction": direction,
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    significant_changes.append(change_data)
                    
                    self.logger.info(
                        f"{exchange.title()} - {symbol} {direction} "
                        f"{abs(change_percent):.2f}%, 当前价格: {price}"
                    )
                
                # 更新价格记录
                self.last_prices[f"{exchange}_{symbol}"] = price
                
            except (ValueError, KeyError) as e:
                self.logger.error(f"处理{exchange}ticker数据时出错: {e}")
        
        return significant_changes
    
    def _scan_announcements(self) -> int:
        """扫描公告"""
        new_announcements = []
        
        # 获取所有交易所的公告数据
        all_announcements = self.api_manager.get_all_announcements()
        
        for exchange, announcements in all_announcements.items():
            for announcement in announcements:
                # 尝试保存到数据库（如果已存在会返回None）
                announcement_id = self.db.save_announcement(
                    announcement['exchange'],
                    announcement['title'],
                    announcement['url'],
                    announcement['date'],
                    announcement['content_hash'],
                    announcement['is_new_listing']
                )
                
                # 如果是新公告
                if announcement_id is not None:
                    announcement['id'] = announcement_id
                    new_announcements.append(announcement)
                    
                    log_prefix = "[新上币]" if announcement['is_new_listing'] else ""
                    self.logger.info(
                        f"{log_prefix} {announcement['exchange']} - "
                        f"{announcement['title']} - {announcement['url']}"
                    )
        
        # 发送通知
        if new_announcements:
            self.notification_manager.send_announcement_notifications(new_announcements)
        
        return len(new_announcements)
    
    def get_status(self) -> Dict[str, Any]:
        """获取监控状态"""
        return {
            'is_running': self.is_running,
            'monitor_status': self.db.get_monitor_status(),
            'statistics': self.db.get_statistics()
        }
    
    def manual_price_check(self) -> Dict[str, Any]:
        """手动执行价格检查"""
        self.logger.info("执行手动价格检查...")
        changes_count = self._monitor_prices()
        return {
            'success': True,
            'changes_count': changes_count,
            'timestamp': datetime.now().isoformat()
        }
    
    def manual_announcement_scan(self) -> Dict[str, Any]:
        """手动执行公告扫描"""
        self.logger.info("执行手动公告扫描...")
        new_count = self._scan_announcements()
        return {
            'success': True,
            'new_count': new_count,
            'timestamp': datetime.now().isoformat()
        }


    
    def set_proxy_manager(self, proxy_manager):
        """设置代理管理器"""
        self.proxy_manager = proxy_manager
        if hasattr(self.api_manager, 'set_proxy_manager'):
            self.api_manager.set_proxy_manager(proxy_manager)
        if hasattr(self.notification_manager, 'set_proxy_manager'):
            self.notification_manager.set_proxy_manager(proxy_manager)
        self.logger.info("代理管理器已设置")
    
    def get_proxy_status(self) -> Dict[str, Any]:
        """获取代理状态"""
        if hasattr(self, 'proxy_manager'):
            return self.proxy_manager.get_status()
        else:
            return {'enabled': False, 'message': '代理管理器未初始化'}
    
    def switch_proxy(self, protocol: str, server_id: str) -> Dict[str, Any]:
        """切换代理服务器"""
        if hasattr(self, 'proxy_manager'):
            return self.proxy_manager.switch_proxy(protocol, server_id)
        else:
            return {'success': False, 'message': '代理管理器未初始化'}

