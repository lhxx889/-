#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交易所监控系统主控脚本 - 带Telegram推送功能
整合Binance.US和Gate.io的价格监控与公告扫描功能
"""

import argparse
import logging
import os
import sys
import time
import threading
import json
from datetime import datetime

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入模块，如果失败则提示安装
try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("缺少必要的Python库。请运行以下命令安装：")
    print("pip install requests beautifulsoup4")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "crypto_monitor.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("crypto_monitor")

# 全局配置
CONFIG = {
    "price_change_threshold": 5.0,  # 涨跌幅阈值，百分比
    "price_check_interval": 300,    # 价格检查间隔，秒（5分钟）
    "announcement_scan_interval": 3600,  # 公告扫描间隔，秒（1小时）
    "use_proxy": False,             # 是否使用代理
    "proxy": {                      # 代理配置
        "http": "socks5://127.0.0.1:1080",
        "https": "socks5://127.0.0.1:1080"
    },
    "binance_enabled": True,        # 是否启用Binance.US监控
    "gate_enabled": True,           # 是否启用Gate.io监控
    "announcement_enabled": True,   # 是否启用公告扫描
    "data_dir": os.path.join(script_dir, "data"),  # 数据存储目录
    
    # Telegram推送配置
    "telegram_enabled": False,      # 是否启用Telegram推送
    "telegram_bot_token": "",       # Telegram机器人Token
    "telegram_chat_id": "",         # Telegram聊天ID
    "telegram_price_notify": True,  # 是否推送价格变动
    "telegram_announcement_notify": True,  # 是否推送公告
    "telegram_min_price_change": 10.0,  # 价格变动推送的最小阈值（百分比）
    "telegram_batch_mode": True,    # 是否批量推送（多条合并为一条）
    "telegram_batch_interval": 60,  # 批量推送间隔（秒）
}

# API端点
BINANCE_BASE_URL = "https://api.binance.us"
BINANCE_TICKER_ENDPOINT = "/api/v3/ticker/24hr"
BINANCE_ANNOUNCEMENT_URL = "https://support.binance.us/en/collections/10384537-announcements"

GATE_BASE_URL = "https://api.gateio.ws/api/v4"
GATE_TICKER_ENDPOINT = "/spot/tickers"
GATE_ANNOUNCEMENT_URL = "https://www.gate.io/announcements"
GATE_API_ANNOUNCEMENT_URL = "https://www.gate.io/announcements/apiupdates"

# 新上币关键词
NEW_LISTINGS_KEYWORDS = ["listing", "新上币", "new coin", "new token", "will list", "上线"]

# 确保数据目录存在
if not os.path.exists(CONFIG["data_dir"]):
    os.makedirs(CONFIG["data_dir"])

# 文件路径
PRICE_CHANGES_FILE = os.path.join(CONFIG["data_dir"], "significant_price_changes.json")
ANNOUNCEMENT_HISTORY_FILE = os.path.join(CONFIG["data_dir"], "announcement_history.json")
NEW_ANNOUNCEMENTS_FILE = os.path.join(CONFIG["data_dir"], "new_announcements.json")

# 存储上次检查的价格，用于比较变化
last_prices = {}

# 存储待推送的消息
pending_price_messages = []
pending_announcement_messages = []
last_batch_send_time = 0

def send_telegram_message(message):
    """发送Telegram消息"""
    if not CONFIG["telegram_enabled"] or not CONFIG["telegram_bot_token"] or not CONFIG["telegram_chat_id"]:
        return False
    
    try:
        url = f"https://api.telegram.org/bot{CONFIG['telegram_bot_token']}/sendMessage"
        data = {
            "chat_id": CONFIG["telegram_chat_id"],
            "text": message,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        
        # 是否使用代理
        proxies = CONFIG["proxy"] if CONFIG["use_proxy"] else None
        
        response = requests.post(url, data=data, proxies=proxies, timeout=10)
        response.raise_for_status()
        
        logger.info("已发送Telegram通知")
        return True
    except Exception as e:
        logger.error(f"发送Telegram通知失败: {e}")
        return False

def process_pending_messages():
    """处理待发送的消息"""
    global pending_price_messages, pending_announcement_messages, last_batch_send_time
    
    current_time = time.time()
    
    # 检查是否需要发送批量消息
    if (CONFIG["telegram_batch_mode"] and 
        (pending_price_messages or pending_announcement_messages) and 
        (current_time - last_batch_send_time >= CONFIG["telegram_batch_interval"])):
        
        # 处理价格变动消息
        if pending_price_messages:
            price_message = "*🔔 价格监控通知*\n\n"
            price_message += "\n".join(pending_price_messages[:20])  # 限制最多20条
            
            if len(pending_price_messages) > 20:
                price_message += f"\n\n...还有 {len(pending_price_messages) - 20} 条价格变动未显示"
            
            send_telegram_message(price_message)
            pending_price_messages = []
        
        # 处理公告消息
        if pending_announcement_messages:
            announcement_message = "*📢 公告监控通知*\n\n"
            announcement_message += "\n\n".join(pending_announcement_messages[:10])  # 限制最多10条
            
            if len(pending_announcement_messages) > 10:
                announcement_message += f"\n\n...还有 {len(pending_announcement_messages) - 10} 条公告未显示"
            
            send_telegram_message(announcement_message)
            pending_announcement_messages = []
        
        last_batch_send_time = current_time

def notify_price_change(exchange, symbol, price, change_percent, direction):
    """通知价格变动"""
    if not CONFIG["telegram_enabled"] or not CONFIG["telegram_price_notify"]:
        return
    
    # 只推送超过最小阈值的价格变动
    if abs(change_percent) < CONFIG["telegram_min_price_change"]:
        return
    
    # 构建消息
    emoji = "🔴" if direction == "下跌" else "🟢"
    message = f"{emoji} *{exchange}* - `{symbol}` {direction} *{abs(change_percent):.2f}%*，当前价格: {price}"
    
    if CONFIG["telegram_batch_mode"]:
        # 批量模式，先存储消息
        pending_price_messages.append(message)
        process_pending_messages()
    else:
        # 立即发送
        send_telegram_message(message)

def notify_new_announcement(announcement):
    """通知新公告"""
    if not CONFIG["telegram_enabled"] or not CONFIG["telegram_announcement_notify"]:
        return
    
    # 构建消息
    emoji = "🔔" if announcement["is_new_listing"] else "📢"
    title_prefix = "[新上币]" if announcement["is_new_listing"] else ""
    
    message = f"{emoji} *{announcement['exchange']}* - {title_prefix} *{announcement['title']}*\n"
    message += f"📅 日期: {announcement['date']}\n"
    message += f"🔗 链接: {announcement['url']}"
    
    if CONFIG["telegram_batch_mode"]:
        # 批量模式，先存储消息
        pending_announcement_messages.append(message)
        process_pending_messages()
    else:
        # 立即发送
        send_telegram_message(message)

def fetch_binance_tickers():
    """获取Binance.US所有交易对的24小时价格变动数据"""
    try:
        url = f"{BINANCE_BASE_URL}{BINANCE_TICKER_ENDPOINT}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        tickers = response.json()
        logger.info(f"成功获取Binance.US {len(tickers)} 个交易对数据")
        return tickers
    
    except requests.exceptions.RequestException as e:
        logger.error(f"获取Binance.US数据失败: {e}")
        return []

def process_binance_tickers(tickers):
    """处理Binance.US的ticker数据，识别超过阈值的价格变动"""
    significant_changes = []
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    for ticker in tickers:
        symbol = ticker['symbol']
        price = float(ticker['lastPrice'])
        price_change_percent = float(ticker['priceChangePercent'])
        
        # 检查是否超过阈值
        if abs(price_change_percent) >= CONFIG["price_change_threshold"]:
            change_direction = "上涨" if price_change_percent > 0 else "下跌"
            significant_changes.append({
                "exchange": "Binance.US",
                "symbol": symbol,
                "price": price,
                "change_percent": price_change_percent,
                "direction": change_direction,
                "time": current_time
            })
            
            logger.info(f"Binance.US - {symbol} {change_direction} {abs(price_change_percent):.2f}%, 当前价格: {price}")
            
            # 发送Telegram通知
            notify_price_change("Binance.US", symbol, price, price_change_percent, change_direction)
        
        # 更新上次价格记录
        last_prices[f"binance_{symbol}"] = price
    
    return significant_changes

def fetch_gate_tickers():
    """获取Gate.io所有交易对的价格和涨跌幅数据"""
    try:
        url = f"{GATE_BASE_URL}{GATE_TICKER_ENDPOINT}"
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        tickers = response.json()
        logger.info(f"成功获取Gate.io {len(tickers)} 个交易对数据")
        return tickers
    
    except requests.exceptions.RequestException as e:
        logger.error(f"获取Gate.io数据失败: {e}")
        return []

def process_gate_tickers(tickers):
    """处理Gate.io的ticker数据，识别超过阈值的价格变动"""
    significant_changes = []
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    for ticker in tickers:
        symbol = ticker['currency_pair']
        price = float(ticker['last'])
        
        # Gate.io的API返回的change_percentage格式为"-8.91"（字符串）
        try:
            price_change_percent = float(ticker['change_percentage'])
        except (ValueError, KeyError):
            # 如果无法获取涨跌幅，则跳过
            continue
        
        # 检查是否超过阈值
        if abs(price_change_percent) >= CONFIG["price_change_threshold"]:
            change_direction = "上涨" if price_change_percent > 0 else "下跌"
            significant_changes.append({
                "exchange": "Gate.io",
                "symbol": symbol,
                "price": price,
                "change_percent": price_change_percent,
                "direction": change_direction,
                "time": current_time
            })
            
            logger.info(f"Gate.io - {symbol} {change_direction} {abs(price_change_percent):.2f}%, 当前价格: {price}")
            
            # 发送Telegram通知
            notify_price_change("Gate.io", symbol, price, price_change_percent, change_direction)
        
        # 更新上次价格记录
        last_prices[f"gate_{symbol}"] = price
    
    return significant_changes

def save_significant_changes(changes):
    """保存显著价格变动到文件"""
    if not changes:
        return
    
    try:
        # 读取现有数据
        try:
            with open(PRICE_CHANGES_FILE, "r") as f:
                existing_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        # 添加新数据
        existing_data.extend(changes)
        
        # 写回文件
        with open(PRICE_CHANGES_FILE, "w") as f:
            json.dump(existing_data, f, indent=2)
        
        logger.info(f"已保存 {len(changes)} 条显著价格变动记录")
    
    except Exception as e:
        logger.error(f"保存价格变动记录失败: {e}")

def monitor_prices():
    """监控价格变动的主函数"""
    logger.info("开始监控价格变动...")
    
    try:
        significant_changes = []
        
        # 获取并处理Binance.US数据
        if CONFIG["binance_enabled"]:
            binance_tickers = fetch_binance_tickers()
            if binance_tickers:
                binance_changes = process_binance_tickers(binance_tickers)
                significant_changes.extend(binance_changes)
        
        # 获取并处理Gate.io数据
        if CONFIG["gate_enabled"]:
            gate_tickers = fetch_gate_tickers()
            if gate_tickers:
                gate_changes = process_gate_tickers(gate_tickers)
                significant_changes.extend(gate_changes)
        
        # 保存显著变动
        save_significant_changes(significant_changes)
        
        return len(significant_changes)
    
    except Exception as e:
        logger.error(f"监控过程中发生错误: {e}")
        return 0

def get_page_content(url):
    """获取网页内容"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        # 是否使用代理
        proxies = CONFIG["proxy"] if CONFIG["use_proxy"] else None
        
        response = requests.get(url, headers=headers, proxies=proxies, timeout=15)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"获取网页内容失败: {url}, 错误: {e}")
        return None

def parse_binance_announcements(html_content):
    """解析Binance.US公告页面"""
    if not html_content:
        return []
    
    announcements = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 根据实际页面结构调整选择器
        articles = soup.select('article.article-list-item')
        
        for article in articles:
            try:
                title_element = article.select_one('h3.article-list-item-title')
                link_element = article.select_one('a')
                date_element = article.select_one('time')
                
                if title_element and link_element:
                    title = title_element.text.strip()
                    link = link_element.get('href')
                    if not link.startswith('http'):
                        link = f"https://support.binance.us{link}"
                    
                    date = date_element.text.strip() if date_element else "未知日期"
                    
                    import hashlib
                    announcement = {
                        "exchange": "Binance.US",
                        "title": title,
                        "url": link,
                        "date": date,
                        "id": hashlib.md5(f"{title}_{link}".encode()).hexdigest(),
                        "is_new_listing": any(keyword.lower() in title.lower() for keyword in NEW_LISTINGS_KEYWORDS)
                    }
                    announcements.append(announcement)
            except Exception as e:
                logger.error(f"解析Binance.US公告项目时出错: {e}")
        
        logger.info(f"成功解析 {len(announcements)} 条Binance.US公告")
    except Exception as e:
        logger.error(f"解析Binance.US公告页面失败: {e}")
    
    return announcements

def parse_gate_announcements(html_content):
    """解析Gate.io公告页面"""
    if not html_content:
        return []
    
    announcements = []
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # 根据实际页面结构调整选择器
        articles = soup.select('div.article-item') or soup.select('div.announcement-item')
        
        for article in articles:
            try:
                title_element = article.select_one('h3') or article.select_one('div.title')
                link_element = article.select_one('a')
                date_element = article.select_one('time') or article.select_one('div.date')
                
                if title_element and link_element:
                    title = title_element.text.strip()
                    link = link_element.get('href')
                    if not link.startswith('http'):
                        link = f"https://www.gate.io{link}"
                    
                    date = date_element.text.strip() if date_element else "未知日期"
                    
                    import hashlib
                    announcement = {
                        "exchange": "Gate.io",
                        "title": title,
                        "url": link,
                        "date": date,
                        "id": hashlib.md5(f"{title}_{link}".encode()).hexdigest(),
                        "is_new_listing": any(keyword.lower() in title.lower() for keyword in NEW_LISTINGS_KEYWORDS)
                    }
                    announcements.append(announcement)
            except Exception as e:
                logger.error(f"解析Gate.io公告项目时出错: {e}")
        
        logger.info(f"成功解析 {len(announcements)} 条Gate.io公告")
    except Exception as e:
        logger.error(f"解析Gate.io公告页面失败: {e}")
    
    return announcements

def load_announcement_history():
    """加载历史公告记录"""
    if not os.path.exists(ANNOUNCEMENT_HISTORY_FILE):
        return []
    
    try:
        with open(ANNOUNCEMENT_HISTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"加载历史公告记录失败: {e}")
        return []

def save_announcement_history(announcements):
    """保存公告历史记录"""
    try:
        with open(ANNOUNCEMENT_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(announcements, f, ensure_ascii=False, indent=2)
        logger.info(f"已保存 {len(announcements)} 条公告历史记录")
    except Exception as e:
        logger.error(f"保存公告历史记录失败: {e}")

def filter_new_announcements(all_announcements, history):
    """过滤出新公告"""
    history_ids = {item['id'] for item in history}
    new_announcements = [item for item in all_announcements if item['id'] not in history_ids]
    return new_announcements

def notify_new_announcements(new_announcements):
    """通知新公告"""
    if not new_announcements:
        logger.info("没有发现新公告")
        return
    
    # 分离新上币公告和普通公告
    new_listings = [a for a in new_announcements if a['is_new_listing']]
    regular_announcements = [a for a in new_announcements if not a['is_new_listing']]
    
    # 记录到日志
    if new_listings:
        logger.info(f"发现 {len(new_listings)} 条新上币公告:")
        for announcement in new_listings:
            logger.info(f"[新上币] {announcement['exchange']} - {announcement['title']} - {announcement['url']}")
            # 发送Telegram通知
            notify_new_announcement(announcement)
    
    if regular_announcements:
        logger.info(f"发现 {len(regular_announcements)} 条普通公告:")
        for announcement in regular_announcements:
            logger.info(f"{announcement['exchange']} - {announcement['title']} - {announcement['url']}")
            # 发送Telegram通知
            notify_new_announcement(announcement)
    
    # 保存到文件
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    try:
        # 读取现有数据
        try:
            with open(NEW_ANNOUNCEMENTS_FILE, "r", encoding='utf-8') as f:
                existing_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        # 添加新数据
        for announcement in new_announcements:
            announcement['discovery_time'] = current_time
            existing_data.append(announcement)
        
        # 写回文件
        with open(NEW_ANNOUNCEMENTS_FILE, "w", encoding='utf-8') as f:
            json.dump(existing_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"已保存 {len(new_announcements)} 条新公告记录")
    
    except Exception as e:
        logger.error(f"保存新公告记录失败: {e}")

def scan_announcements():
    """扫描公告的主函数"""
    logger.info("开始扫描交易所公告...")
    
    try:
        # 加载历史记录
        history = load_announcement_history()
        all_announcements = []
        
        # 获取Binance.US公告
        if CONFIG["binance_enabled"]:
            binance_html = get_page_content(BINANCE_ANNOUNCEMENT_URL)
            binance_announcements = parse_binance_announcements(binance_html)
            all_announcements.extend(binance_announcements)
        
        # 获取Gate.io公告
        if CONFIG["gate_enabled"]:
            gate_html = get_page_content(GATE_ANNOUNCEMENT_URL)
            gate_announcements = parse_gate_announcements(gate_html)
            all_announcements.extend(gate_announcements)
            
            # 获取Gate.io API公告
            gate_api_html = get_page_content(GATE_API_ANNOUNCEMENT_URL)
            gate_api_announcements = parse_gate_announcements(gate_api_html)
            all_announcements.extend(gate_api_announcements)
        
        # 过滤新公告
        new_announcements = filter_new_announcements(all_announcements, history)
        
        # 通知新公告
        notify_new_announcements(new_announcements)
        
        # 更新历史记录
        history.extend(new_announcements)
        save_announcement_history(history)
        
        return len(new_announcements)
    
    except Exception as e:
        logger.error(f"扫描公告过程中发生错误: {e}")
        return 0

def price_monitor_thread():
    """价格监控线程"""
    while True:
        try:
            changes_count = monitor_prices()
            logger.info(f"本次监控发现 {changes_count} 个显著价格变动")
            logger.info(f"等待 {CONFIG['price_check_interval']} 秒后进行下一次价格检查...")
            time.sleep(CONFIG["price_check_interval"])
        except KeyboardInterrupt:
            logger.info("价格监控线程被手动终止")
            break
        except Exception as e:
            logger.error(f"价格监控线程异常: {e}")
            time.sleep(60)  # 出错后等待一分钟再重试

def announcement_scanner_thread():
    """公告扫描线程"""
    while True:
        try:
            new_count = scan_announcements()
            logger.info(f"本次扫描发现 {new_count} 条新公告")
            logger.info(f"等待 {CONFIG['announcement_scan_interval']} 秒后进行下一次公告扫描...")
            time.sleep(CONFIG["announcement_scan_interval"])
        except KeyboardInterrupt:
            logger.info("公告扫描线程被手动终止")
            break
        except Exception as e:
            logger.error(f"公告扫描线程异常: {e}")
            time.sleep(60)  # 出错后等待一分钟再重试

def telegram_message_processor_thread():
    """Telegram消息处理线程"""
    while True:
        try:
            process_pending_messages()
            time.sleep(1)  # 每秒检查一次
        except KeyboardInterrupt:
            logger.info("Telegram消息处理线程被手动终止")
            break
        except Exception as e:
            logger.error(f"Telegram消息处理线程异常: {e}")
            time.sleep(10)  # 出错后等待10秒再重试

def test_telegram_connection():
    """测试Telegram连接"""
    if not CONFIG["telegram_enabled"]:
        logger.info("Telegram推送未启用，跳过连接测试")
        return True
    
    logger.info("测试Telegram连接...")
    message = "🔔 *交易所监控系统启动通知*\n\n"
    message += "系统已成功启动，此为测试消息。\n"
    message += f"当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    message += f"价格监控阈值: {CONFIG['price_change_threshold']}%\n"
    message += f"价格推送阈值: {CONFIG['telegram_min_price_change']}%\n"
    message += f"批量推送模式: {'开启' if CONFIG['telegram_batch_mode'] else '关闭'}\n"
    message += f"批量推送间隔: {CONFIG['telegram_batch_interval']}秒\n\n"
    message += "如果您收到此消息，表示Telegram推送功能配置正确。"
    
    success = send_telegram_message(message)
    
    if success:
        logger.info("Telegram连接测试成功")
    else:
        logger.error("Telegram连接测试失败，请检查配置")
    
    return success

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='交易所监控系统 - 带Telegram推送功能')
    
    parser.add_argument('--threshold', type=float, default=CONFIG["price_change_threshold"],
                        help=f'价格涨跌幅阈值，百分比 (默认: {CONFIG["price_change_threshold"]})')
    
    parser.add_argument('--price-interval', type=int, default=CONFIG["price_check_interval"],
                        help=f'价格检查间隔，秒 (默认: {CONFIG["price_check_interval"]})')
    
    parser.add_argument('--announcement-interval', type=int, default=CONFIG["announcement_scan_interval"],
                        help=f'公告扫描间隔，秒 (默认: {CONFIG["announcement_scan_interval"]})')
    
    parser.add_argument('--proxy', action='store_true',
                        help='使用代理 (默认: 不使用)')
    
    parser.add_argument('--no-binance', action='store_true',
                        help='禁用Binance.US监控 (默认: 启用)')
    
    parser.add_argument('--no-gate', action='store_true',
                        help='禁用Gate.io监控 (默认: 启用)')
    
    parser.add_argument('--no-announcement', action='store_true',
                        help='禁用公告扫描 (默认: 启用)')
    
    parser.add_argument('--price-only', action='store_true',
                        help='仅运行价格监控 (默认: 全部运行)')
    
    parser.add_argument('--announcement-only', action='store_true',
                        help='仅运行公告扫描 (默认: 全部运行)')
    
    parser.add_argument('--data-dir', type=str, default=CONFIG["data_dir"],
                        help=f'数据存储目录 (默认: {CONFIG["data_dir"]})')
    
    # Telegram相关参数
    parser.add_argument('--telegram', action='store_true',
                        help='启用Telegram推送 (默认: 不启用)')
    
    parser.add_argument('--telegram-token', type=str, default="",
                        help='Telegram机器人Token')
    
    parser.add_argument('--telegram-chat', type=str, default="",
                        help='Telegram聊天ID')
    
    parser.add_argument('--telegram-min-change', type=float, default=CONFIG["telegram_min_price_change"],
                        help=f'价格变动推送的最小阈值，百分比 (默认: {CONFIG["telegram_min_price_change"]})')
    
    parser.add_argument('--no-batch', action='store_true',
                        help='禁用批量推送模式 (默认: 启用)')
    
    parser.add_argument('--batch-interval', type=int, default=CONFIG["telegram_batch_interval"],
                        help=f'批量推送间隔，秒 (默认: {CONFIG["telegram_batch_interval"]})')
    
    parser.add_argument('--no-price-notify', action='store_true',
                        help='禁用价格变动推送 (默认: 启用)')
    
    parser.add_argument('--no-announcement-notify', action='store_true',
                        help='禁用公告推送 (默认: 启用)')
    
    return parser.parse_args()

def update_config_from_args(args):
    """根据命令行参数更新配置"""
    CONFIG["price_change_threshold"] = args.threshold
    CONFIG["price_check_interval"] = args.price_interval
    CONFIG["announcement_scan_interval"] = args.announcement_interval
    CONFIG["use_proxy"] = args.proxy
    CONFIG["binance_enabled"] = not args.no_binance
    CONFIG["gate_enabled"] = not args.no_gate
    CONFIG["announcement_enabled"] = not args.no_announcement
    CONFIG["data_dir"] = args.data_dir
    
    # 处理互斥选项
    if args.price_only:
        CONFIG["announcement_enabled"] = False
    if args.announcement_only:
        CONFIG["binance_enabled"] = False
        CONFIG["gate_enabled"] = False
    
    # 更新Telegram配置
    CONFIG["telegram_enabled"] = args.telegram
    CONFIG["telegram_bot_token"] = args.telegram_token
    CONFIG["telegram_chat_id"] = args.telegram_chat
    CONFIG["telegram_min_price_change"] = args.telegram_min_change
    CONFIG["telegram_batch_mode"] = not args.no_batch
    CONFIG["telegram_batch_interval"] = args.batch_interval
    CONFIG["telegram_price_notify"] = not args.no_price_notify
    CONFIG["telegram_announcement_notify"] = not args.no_announcement_notify
    
    # 更新文件路径
    global PRICE_CHANGES_FILE, ANNOUNCEMENT_HISTORY_FILE, NEW_ANNOUNCEMENTS_FILE
    PRICE_CHANGES_FILE = os.path.join(CONFIG["data_dir"], "significant_price_changes.json")
    ANNOUNCEMENT_HISTORY_FILE = os.path.join(CONFIG["data_dir"], "announcement_history.json")
    NEW_ANNOUNCEMENTS_FILE = os.path.join(CONFIG["data_dir"], "new_announcements.json")
    
    # 确保数据目录存在
    if not os.path.exists(CONFIG["data_dir"]):
        os.makedirs(CONFIG["data_dir"])

def main():
    """主函数"""
    # 解析命令行参数
    args = parse_arguments()
    update_config_from_args(args)
    
    # 打印启动配置
    logger.info("交易所监控系统启动 - 带Telegram推送功能")
    logger.info(f"价格涨跌幅阈值: {CONFIG['price_change_threshold']}%")
    logger.info(f"价格检查间隔: {CONFIG['price_check_interval']}秒")
    logger.info(f"公告扫描间隔: {CONFIG['announcement_scan_interval']}秒")
    logger.info(f"使用代理: {'是' if CONFIG['use_proxy'] else '否'}")
    logger.info(f"启用Binance.US监控: {'是' if CONFIG['binance_enabled'] else '否'}")
    logger.info(f"启用Gate.io监控: {'是' if CONFIG['gate_enabled'] else '否'}")
    logger.info(f"启用公告扫描: {'是' if CONFIG['announcement_enabled'] else '否'}")
    logger.info(f"数据存储目录: {CONFIG['data_dir']}")
    logger.info(f"启用Telegram推送: {'是' if CONFIG['telegram_enabled'] else '否'}")
    
    if CONFIG["telegram_enabled"]:
        logger.info(f"Telegram价格推送阈值: {CONFIG['telegram_min_price_change']}%")
        logger.info(f"Telegram批量推送模式: {'启用' if CONFIG['telegram_batch_mode'] else '禁用'}")
        if CONFIG["telegram_batch_mode"]:
            logger.info(f"Telegram批量推送间隔: {CONFIG['telegram_batch_interval']}秒")
    
    # 测试Telegram连接
    if CONFIG["telegram_enabled"]:
        if not test_telegram_connection():
            logger.warning("Telegram连接测试失败，但系统将继续运行")
    
    threads = []
    
    # 启动价格监控线程
    if CONFIG["binance_enabled"] or CONFIG["gate_enabled"]:
        price_thread = threading.Thread(target=price_monitor_thread, daemon=True)
        price_thread.start()
        threads.append(price_thread)
        logger.info("价格监控线程已启动")
    
    # 启动公告扫描线程
    if CONFIG["announcement_enabled"]:
        announcement_thread = threading.Thread(target=announcement_scanner_thread, daemon=True)
        announcement_thread.start()
        threads.append(announcement_thread)
        logger.info("公告扫描线程已启动")
    
    # 启动Telegram消息处理线程
    if CONFIG["telegram_enabled"] and CONFIG["telegram_batch_mode"]:
        telegram_thread = threading.Thread(target=telegram_message_processor_thread, daemon=True)
        telegram_thread.start()
        threads.append(telegram_thread)
        logger.info("Telegram消息处理线程已启动")
    
    try:
        # 等待所有线程完成（实际上不会完成，除非被中断）
        for thread in threads:
            thread.join()
    except KeyboardInterrupt:
        logger.info("程序被手动终止")
    except Exception as e:
        logger.error(f"程序异常终止: {e}")
    finally:
        logger.info("交易所监控系统已停止")

if __name__ == "__main__":
    main()
