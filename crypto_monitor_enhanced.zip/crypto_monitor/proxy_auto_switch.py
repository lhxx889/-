#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
代理自动切换管理器
负责管理多个VLESS代理节点，并在API访问被拦截时自动切换到下一个可用的代理节点
"""

import os
import sys
import json
import time
import logging
import requests
import threading
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('proxy_auto_switch.log')
    ]
)

logger = logging.getLogger('proxy_auto_switch')

class ProxyAutoSwitchManager:
    """代理自动切换管理器，负责管理多个VLESS代理节点，并在API访问被拦截时自动切换"""
    
    def __init__(self, proxy_manager=None, config=None):
        """初始化代理自动切换管理器
        
        Args:
            proxy_manager: 代理管理器实例
            config: 配置字典，包含代理设置
        """
        self.config = config or {}
        self.proxy_manager = proxy_manager
        
        # 节点文件路径
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.nodes_file = os.path.join(script_dir, "config", "vless_nodes.json")
        
        # 当前使用的节点索引
        self.current_node_index = 0
        
        # 节点列表
        self.nodes = self.load_nodes()
        
        # 代理状态
        self.proxy_status = {
            "enabled": False,
            "current_node": None,
            "direct_mode": True,
            "last_switch_time": None,
            "switch_count": 0,
            "failed_apis": set()
        }
        
        # 测试API列表
        self.test_apis = [
            {"url": "https://api.binance.us/api/v3/ping", "name": "Binance.US"},
            {"url": "https://api.gateio.ws/api/v4/spot/currencies", "name": "Gate.io"},
            {"url": "https://api.coingecko.com/api/v3/ping", "name": "CoinGecko"}
        ]
        
        # 初始化锁，防止并发切换
        self.switch_lock = threading.Lock()
    
    def load_nodes(self):
        """加载VLESS节点列表
        
        Returns:
            list: VLESS节点列表
        """
        try:
            if not os.path.exists(self.nodes_file):
                logger.warning(f"节点文件不存在: {self.nodes_file}")
                return []
            
            with open(self.nodes_file, 'r') as f:
                nodes = json.load(f)
            
            logger.info(f"已加载 {len(nodes)} 个VLESS节点")
            return nodes
        except Exception as e:
            logger.error(f"加载VLESS节点失败: {e}")
            return []
    
    def get_current_node(self):
        """获取当前使用的节点
        
        Returns:
            dict: 当前节点信息，如果没有节点则返回None
        """
        if not self.nodes:
            return None
        
        if self.current_node_index >= len(self.nodes):
            self.current_node_index = 0
        
        return self.nodes[self.current_node_index]
    
    def switch_to_next_node(self):
        """切换到下一个节点
        
        Returns:
            bool: 切换是否成功
        """
        with self.switch_lock:
            if not self.nodes:
                logger.warning("没有可用的节点，无法切换")
                return False
            
            # 更新当前节点索引
            self.current_node_index = (self.current_node_index + 1) % len(self.nodes)
            
            # 获取新节点
            node = self.get_current_node()
            
            if not node:
                logger.warning("无法获取下一个节点")
                return False
            
            logger.info(f"切换到节点: {node['name']}")
            
            # 更新代理状态
            self.proxy_status["current_node"] = node
            self.proxy_status["last_switch_time"] = time.time()
            self.proxy_status["switch_count"] += 1
            self.proxy_status["direct_mode"] = False
            
            # 应用新节点配置
            if self.proxy_manager:
                try:
                    # 创建代理配置
                    proxy_config = {
                        "server": node["server"],
                        "server_port": node["port"],
                        "uuid": node["uuid"],
                        "flow": node["flow"],
                        "sni": node["sni"],
                        "public_key": node["public_key"],
                        "short_id": node["short_id"]
                    }
                    
                    # 更新代理配置
                    success = self.proxy_manager.update_custom_proxy(proxy_config)
                    
                    if success:
                        # 应用代理设置到监控系统
                        self.proxy_manager.apply_proxy_settings()
                        logger.info(f"成功应用节点 '{node['name']}' 的配置")
                        return True
                    else:
                        logger.error(f"应用节点 '{node['name']}' 的配置失败")
                        return False
                except Exception as e:
                    logger.error(f"切换代理节点时发生错误: {e}")
                    return False
            else:
                logger.warning("代理管理器未初始化，无法应用节点配置")
                return False
    
    def switch_to_direct(self):
        """切换到直连模式
        
        Returns:
            bool: 切换是否成功
        """
        with self.switch_lock:
            logger.info("切换到直连模式")
            
            # 更新代理状态
            self.proxy_status["current_node"] = None
            self.proxy_status["last_switch_time"] = time.time()
            self.proxy_status["direct_mode"] = True
            
            # 禁用代理
            if self.proxy_manager:
                try:
                    # 读取配置文件
                    config_file = os.path.join(os.getcwd(), "config.json")
                    if not os.path.exists(config_file):
                        config_file = os.path.join(os.path.dirname(os.getcwd()), "config.json")
                    
                    if os.path.exists(config_file):
                        with open(config_file, "r") as f:
                            config = json.load(f)
                        
                        # 禁用代理
                        config["use_proxy"] = False
                        
                        # 保存配置
                        with open(config_file, "w") as f:
                            json.dump(config, f, indent=2)
                        
                        logger.info("已禁用代理")
                        return True
                    else:
                        logger.warning(f"配置文件不存在: {config_file}")
                        return False
                except Exception as e:
                    logger.error(f"禁用代理时发生错误: {e}")
                    return False
            else:
                logger.warning("代理管理器未初始化，无法禁用代理")
                return False
    
    def test_api_with_proxy(self, api_url, timeout=10):
        """使用代理测试API连接
        
        Args:
            api_url: API URL
            timeout: 超时时间，秒
            
        Returns:
            bool: 测试是否成功
        """
        try:
            # 设置代理
            proxies = {
                "http": "socks5://127.0.0.1:1080",
                "https": "socks5://127.0.0.1:1080"
            }
            
            # 测试连接
            response = requests.get(api_url, proxies=proxies, timeout=timeout)
            
            # 检查状态码
            if response.status_code == 200:
                logger.info(f"使用代理测试API成功: {api_url}")
                return True
            else:
                logger.warning(f"使用代理测试API失败: {api_url}, 状态码: {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"使用代理测试API异常: {api_url}, 错误: {e}")
            return False
    
    def test_api_direct(self, api_url, timeout=10):
        """直接测试API连接（不使用代理）
        
        Args:
            api_url: API URL
            timeout: 超时时间，秒
            
        Returns:
            bool: 测试是否成功
        """
        try:
            # 测试连接
            response = requests.get(api_url, timeout=timeout)
            
            # 检查状态码
            if response.status_code == 200:
                logger.info(f"直接测试API成功: {api_url}")
                return True
            else:
                logger.warning(f"直接测试API失败: {api_url}, 状态码: {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"直接测试API异常: {api_url}, 错误: {e}")
            return False
    
    def handle_api_request(self, api_url, use_proxy=None, max_retries=3):
        """处理API请求，自动切换代理
        
        Args:
            api_url: API URL
            use_proxy: 是否使用代理，None表示自动判断
            max_retries: 最大重试次数
            
        Returns:
            response: 请求响应对象，如果所有尝试都失败则返回None
        """
        # 确定是否使用代理
        if use_proxy is None:
            use_proxy = not self.proxy_status["direct_mode"]
        
        # 设置代理
        proxies = None
        if use_proxy:
            proxies = {
                "http": "socks5://127.0.0.1:1080",
                "https": "socks5://127.0.0.1:1080"
            }
        
        # 尝试请求
        for retry in range(max_retries):
            try:
                response = requests.get(api_url, proxies=proxies, timeout=10)
                
                # 检查是否成功
                if response.status_code == 200:
                    return response
                
                # 如果是代理问题（403、429等状态码），尝试切换代理
                if use_proxy and response.status_code in [403, 429, 502, 503]:
                    logger.warning(f"API请求被拦截: {api_url}, 状态码: {response.status_code}, 尝试切换代理")
                    
                    # 记录失败的API
                    self.proxy_status["failed_apis"].add(api_url)
                    
                    # 切换到下一个节点
                    self.switch_to_next_node()
                    
                    # 更新代理设置
                    proxies = {
                        "http": "socks5://127.0.0.1:1080",
                        "https": "socks5://127.0.0.1:1080"
                    }
                else:
                    # 其他错误，直接返回响应
                    return response
            
            except requests.exceptions.RequestException as e:
                logger.error(f"API请求异常: {api_url}, 错误: {e}, 重试: {retry+1}/{max_retries}")
                
                # 如果是使用代理且连接错误，尝试切换代理
                if use_proxy and isinstance(e, (requests.exceptions.ConnectionError, requests.exceptions.Timeout)):
                    logger.warning(f"代理连接错误，尝试切换代理")
                    
                    # 记录失败的API
                    self.proxy_status["failed_apis"].add(api_url)
                    
                    # 切换到下一个节点
                    self.switch_to_next_node()
                    
                    # 更新代理设置
                    proxies = {
                        "http": "socks5://127.0.0.1:1080",
                        "https": "socks5://127.0.0.1:1080"
                    }
                
                # 最后一次重试失败
                if retry == max_retries - 1:
                    # 如果使用代理失败，尝试直连
                    if use_proxy:
                        logger.warning(f"所有代理节点都失败，尝试直连: {api_url}")
                        try:
                            response = requests.get(api_url, timeout=10)
                            
                            # 如果直连成功，切换到直连模式
                            if response.status_code == 200:
                                logger.info(f"直连成功: {api_url}")
                                self.switch_to_direct()
                                return response
                            else:
                                logger.warning(f"直连失败: {api_url}, 状态码: {response.status_code}")
                        except requests.exceptions.RequestException as e2:
                            logger.error(f"直连异常: {api_url}, 错误: {e2}")
                    
                    return None
        
        return None
    
    def get_proxy_status(self):
        """获取代理状态
        
        Returns:
            dict: 代理状态信息
        """
        # 更新节点列表
        self.nodes = self.load_nodes()
        
        # 获取当前节点
        current_node = self.get_current_node()
        
        # 更新代理状态
        self.proxy_status["current_node"] = current_node
        
        # 检查代理服务是否运行
        if self.proxy_manager:
            proxy_status = self.proxy_manager.get_proxy_status()
            self.proxy_status["enabled"] = proxy_status["running"]
        
        return self.proxy_status
    
    def test_all_nodes(self):
        """测试所有节点
        
        Returns:
            list: 测试结果列表
        """
        results = []
        
        if not self.nodes:
            logger.warning("没有可用的节点，无法测试")
            return results
        
        # 保存当前节点索引
        original_index = self.current_node_index
        
        # 测试每个节点
        for i, node in enumerate(self.nodes):
            self.current_node_index = i
            
            # 应用节点配置
            if self.proxy_manager:
                try:
                    # 创建代理配置
                    proxy_config = {
                        "server": node["server"],
                        "server_port": node["port"],
                        "uuid": node["uuid"],
                        "flow": node["flow"],
                        "sni": node["sni"],
                        "public_key": node["public_key"],
                        "short_id": node["short_id"]
                    }
                    
                    # 更新代理配置
                    success = self.proxy_manager.update_custom_proxy(proxy_config)
                    
                    if success:
                        logger.info(f"成功应用节点 '{node['name']}' 的配置")
                        
                        # 测试API
                        api_results = []
                        for api in self.test_apis:
                            api_success = self.test_api_with_proxy(api["url"])
                            api_results.append({
                                "name": api["name"],
                                "url": api["url"],
                                "success": api_success
                            })
                        
                        # 添加测试结果
                        results.append({
                            "node": node,
                            "success": any(r["success"] for r in api_results),
                            "api_results": api_results
                        })
                    else:
                        logger.error(f"应用节点 '{node['name']}' 的配置失败")
                        results.append({
                            "node": node,
                            "success": False,
                            "error": "应用配置失败"
                        })
                except Exception as e:
                    logger.error(f"测试节点 '{node['name']}' 时发生错误: {e}")
                    results.append({
                        "node": node,
                        "success": False,
                        "error": str(e)
                    })
            else:
                logger.warning("代理管理器未初始化，无法测试节点")
                results.append({
                    "node": node,
                    "success": False,
                    "error": "代理管理器未初始化"
                })
        
        # 恢复原始节点索引
        self.current_node_index = original_index
        
        # 重新应用原始节点配置
        if self.proxy_manager and self.nodes:
            node = self.nodes[self.current_node_index]
            proxy_config = {
                "server": node["server"],
                "server_port": node["port"],
                "uuid": node["uuid"],
                "flow": node["flow"],
                "sni": node["sni"],
                "public_key": node["public_key"],
                "short_id": node["short_id"]
            }
            self.proxy_manager.update_custom_proxy(proxy_config)
        
        return results
    
    def find_best_node(self):
        """查找最佳节点
        
        Returns:
            int: 最佳节点的索引
        """
        # 测试所有节点
        results = self.test_all_nodes()
        
        if not results:
            return 0
        
        # 查找成功率最高的节点
        best_index = 0
        best_success_count = 0
        
        for i, result in enumerate(results):
            if result["success"]:
                # 计算API成功数量
                success_count = sum(1 for api in result["api_results"] if api["success"])
                
                if success_count > best_success_count:
                    best_success_count = success_count
                    best_index = i
        
        return best_index
    
    def switch_to_best_node(self):
        """切换到最佳节点
        
        Returns:
            bool: 切换是否成功
        """
        with self.switch_lock:
            # 查找最佳节点
            best_index = self.find_best_node()
            
            # 切换到最佳节点
            self.current_node_index = best_index
            
            # 获取节点
            node = self.get_current_node()
            
            if not node:
                logger.warning("无法获取最佳节点")
                return False
            
            logger.info(f"切换到最佳节点: {node['name']}")
            
            # 更新代理状态
            self.proxy_status["current_node"] = node
            self.proxy_status["last_switch_time"] = time.time()
            self.proxy_status["switch_count"] += 1
            self.proxy_status["direct_mode"] = False
            
            # 应用节点配置
            if self.proxy_manager:
                try:
                    # 创建代理配置
                    proxy_config = {
                        "server": node["server"],
                        "server_port": node["port"],
                        "uuid": node["uuid"],
                        "flow": node["flow"],
                        "sni": node["sni"],
                        "public_key": node["public_key"],
                        "short_id": node["short_id"]
                    }
                    
                    # 更新代理配置
                    success = self.proxy_manager.update_custom_proxy(proxy_config)
                    
                    if success:
                        # 应用代理设置到监控系统
                        self.proxy_manager.apply_proxy_settings()
                        logger.info(f"成功应用节点 '{node['name']}' 的配置")
                        return True
                    else:
                        logger.error(f"应用节点 '{node['name']}' 的配置失败")
                        return False
                except Exception as e:
                    logger.error(f"切换代理节点时发生错误: {e}")
                    return False
            else:
                logger.warning("代理管理器未初始化，无法应用节点配置")
                return False

# 如果直接运行此脚本，执行测试
if __name__ == "__main__":
    # 导入代理管理器
    try:
        from proxy_manager import ProxyManager
        proxy_manager = ProxyManager()
    except ImportError:
        proxy_manager = None
    
    # 创建代理自动切换管理器
    auto_switch = ProxyAutoSwitchManager(proxy_manager)
    
    # 测试所有节点
    print("测试所有节点...")
    results = auto_switch.test_all_nodes()
    
    for i, result in enumerate(results):
        node = result["node"]
        print(f"节点 {i}: {node['name']} - {'成功' if result['success'] else '失败'}")
        
        if "api_results" in result:
            for api in result["api_results"]:
                print(f"  API {api['name']}: {'成功' if api['success'] else '失败'}")
    
    # 查找最佳节点
    best_index = auto_switch.find_best_node()
    print(f"最佳节点索引: {best_index}")
    
    # 切换到最佳节点
    success = auto_switch.switch_to_best_node()
    print(f"切换到最佳节点: {'成功' if success else '失败'}")
    
    # 获取代理状态
    status = auto_switch.get_proxy_status()
    print(f"代理状态: {status}")

