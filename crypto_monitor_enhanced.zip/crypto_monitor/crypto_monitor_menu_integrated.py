#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
交易所监控系统 - 交互式主菜单版
整合Binance.US和Gate.io的价格监控与公告扫描功能
支持Telegram推送和交互式配置
集成VLESS代理管理功能
"""

import os
import sys
import json
import time
import signal
import logging
import argparse
import threading
import subprocess
from datetime import datetime

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入模块，如果失败则提示安装
try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("缺少必要的Python库。请运行以下命令安装：")
    print("pip install requests beautifulsoup4")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "crypto_monitor.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("crypto_monitor")

# 全局配置
CONFIG = {
    "price_change_threshold": 5.0,  # 涨跌幅阈值，百分比
    "price_check_interval": 300,    # 价格检查间隔，秒（5分钟）
    "announcement_scan_interval": 3600,  # 公告扫描间隔，秒（1小时）
    "use_proxy": False,             # 是否使用代理
    "proxy": {                      # 代理配置
        "http": "socks5://127.0.0.1:1080",
        "https": "socks5://127.0.0.1:1080"
    },
    "binance_enabled": True,        # 是否启用Binance.US监控
    "gate_enabled": True,           # 是否启用Gate.io监控
    "announcement_enabled": True,   # 是否启用公告扫描
    "data_dir": os.path.join(script_dir, "data"),  # 数据存储目录
    
    # Telegram推送配置
    "telegram_enabled": False,      # 是否启用Telegram推送
    "telegram_bot_token": "",       # Telegram机器人Token
    "telegram_chat_id": "",         # Telegram聊天ID
    "telegram_price_notify": True,  # 是否推送价格变动
    "telegram_announcement_notify": True,  # 是否推送公告
    "telegram_min_price_change": 10.0,  # 价格变动推送的最小阈值（百分比）
    "telegram_batch_mode": True,    # 是否批量推送（多条合并为一条）
    "telegram_batch_interval": 60,  # 批量推送间隔（秒）
}

# 配置文件路径
CONFIG_FILE = os.path.join(script_dir, "config.json")

# 监控进程
monitor_process = None
is_running = False

# 确保数据目录存在
if not os.path.exists(CONFIG["data_dir"]):
    os.makedirs(CONFIG["data_dir"])

def clear_screen():
    """清除屏幕"""
    os.system('cls' if os.name == 'nt' else 'clear')

def load_config():
    """加载配置"""
    global CONFIG
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
                CONFIG.update(loaded_config)
                logger.info("已加载配置文件")
    except Exception as e:
        logger.error(f"加载配置文件失败: {e}")

def save_config():
    """保存配置"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(CONFIG, f, ensure_ascii=False, indent=2)
        logger.info("已保存配置文件")
    except Exception as e:
        logger.error(f"保存配置文件失败: {e}")

def test_telegram_connection():
    """测试Telegram连接"""
    if not CONFIG["telegram_enabled"] or not CONFIG["telegram_bot_token"] or not CONFIG["telegram_chat_id"]:
        print("Telegram推送未启用或配置不完整，无法测试连接")
        return False
    
    print("正在测试Telegram连接...")
    try:
        url = f"https://api.telegram.org/bot{CONFIG['telegram_bot_token']}/sendMessage"
        data = {
            "chat_id": CONFIG["telegram_chat_id"],
            "text": f"🔔 *交易所监控系统测试消息*\n\n系统已成功连接，此为测试消息。\n当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        
        # 是否使用代理
        proxies = CONFIG["proxy"] if CONFIG["use_proxy"] else None
        
        response = requests.post(url, data=data, proxies=proxies, timeout=10)
        response.raise_for_status()
        
        print("Telegram连接测试成功！")
        return True
    except Exception as e:
        print(f"Telegram连接测试失败: {e}")
        return False

def start_monitoring():
    """启动监控"""
    global monitor_process, is_running
    
    if is_running:
        print("监控已经在运行中")
        return
    
    try:
        # 构建命令行参数
        cmd = [sys.executable, os.path.join(script_dir, "crypto_monitor_telegram.py")]
        
        # 添加基本参数
        cmd.extend(["--threshold", str(CONFIG["price_change_threshold"])])
        cmd.extend(["--price-interval", str(CONFIG["price_check_interval"])])
        cmd.extend(["--announcement-interval", str(CONFIG["announcement_scan_interval"])])
        
        # 添加功能开关
        if CONFIG["use_proxy"]:
            cmd.append("--proxy")
        if not CONFIG["binance_enabled"]:
            cmd.append("--no-binance")
        if not CONFIG["gate_enabled"]:
            cmd.append("--no-gate")
        if not CONFIG["announcement_enabled"]:
            cmd.append("--no-announcement")
        
        # 添加Telegram配置
        if CONFIG["telegram_enabled"]:
            cmd.append("--telegram")
            cmd.extend(["--telegram-token", CONFIG["telegram_bot_token"]])
            cmd.extend(["--telegram-chat", CONFIG["telegram_chat_id"]])
            cmd.extend(["--telegram-min-change", str(CONFIG["telegram_min_price_change"])])
            
            if not CONFIG["telegram_batch_mode"]:
                cmd.append("--no-batch")
            else:
                cmd.extend(["--batch-interval", str(CONFIG["telegram_batch_interval"])])
            
            if not CONFIG["telegram_price_notify"]:
                cmd.append("--no-price-notify")
            if not CONFIG["telegram_announcement_notify"]:
                cmd.append("--no-announcement-notify")
        
        # 启动进程
        monitor_process = subprocess.Popen(cmd)
        is_running = True
        print("监控已启动！")
        
        # 保存配置
        save_config()
    except Exception as e:
        print(f"启动监控失败: {e}")

def stop_monitoring():
    """停止监控"""
    global monitor_process, is_running
    
    if not is_running:
        print("监控未在运行")
        return
    
    try:
        if monitor_process:
            monitor_process.terminate()
            monitor_process.wait(timeout=5)
            monitor_process = None
            is_running = False
            print("监控已停止")
    except Exception as e:
        print(f"停止监控失败: {e}")
        try:
            if monitor_process:
                monitor_process.kill()
                monitor_process = None
        except:
            pass
        is_running = False

def show_main_menu():
    """显示主菜单"""
    clear_screen()
    print("=" * 60)
    print("                交易所监控系统 - 主菜单")
    print("=" * 60)
    print(f"当前状态: {'运行中' if is_running else '已停止'}")
    print("-" * 60)
    print("1. 启动/停止监控")
    print("2. 配置Telegram推送")
    print("3. 设置价格监控参数")
    print("4. 设置公告扫描参数")
    print("5. 代理管理中心")
    print("6. 查看当前配置")
    print("7. 查看监控日志")
    print("8. 退出程序")
    print("-" * 60)
    
    choice = input("请选择 [1-8]: ")
    return choice

def telegram_menu():
    """Telegram配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                Telegram推送配置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['telegram_enabled'] else '启用'}Telegram推送")
        
        if CONFIG["telegram_enabled"]:
            print(f"2. 设置机器人Token (当前: {CONFIG['telegram_bot_token'][:10]}...)")
            print(f"3. 设置聊天ID (当前: {CONFIG['telegram_chat_id']})")
            print(f"4. {'禁用' if CONFIG['telegram_price_notify'] else '启用'}价格变动推送")
            print(f"5. {'禁用' if CONFIG['telegram_announcement_notify'] else '启用'}公告推送")
            print(f"6. 设置价格推送阈值 (当前: {CONFIG['telegram_min_price_change']}%)")
            print(f"7. {'禁用' if CONFIG['telegram_batch_mode'] else '启用'}批量推送模式")
            print(f"8. 设置批量推送间隔 (当前: {CONFIG['telegram_batch_interval']}秒)")
            print("9. 测试Telegram连接")
        
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["telegram_enabled"] = not CONFIG["telegram_enabled"]
            if CONFIG["telegram_enabled"]:
                print("已启用Telegram推送")
            else:
                print("已禁用Telegram推送")
            save_config()
        elif CONFIG["telegram_enabled"]:
            if choice == "2":
                token = input("请输入Telegram机器人Token: ")
                if token:
                    CONFIG["telegram_bot_token"] = token
                    print("已设置Telegram机器人Token")
                    save_config()
            elif choice == "3":
                chat_id = input("请输入Telegram聊天ID: ")
                if chat_id:
                    CONFIG["telegram_chat_id"] = chat_id
                    print("已设置Telegram聊天ID")
                    save_config()
            elif choice == "4":
                CONFIG["telegram_price_notify"] = not CONFIG["telegram_price_notify"]
                print(f"价格变动推送已{'启用' if CONFIG['telegram_price_notify'] else '禁用'}")
                save_config()
            elif choice == "5":
                CONFIG["telegram_announcement_notify"] = not CONFIG["telegram_announcement_notify"]
                print(f"公告推送已{'启用' if CONFIG['telegram_announcement_notify'] else '禁用'}")
                save_config()
            elif choice == "6":
                try:
                    threshold = float(input(f"请输入价格推送阈值 (当前: {CONFIG['telegram_min_price_change']}%): "))
                    if threshold > 0:
                        CONFIG["telegram_min_price_change"] = threshold
                        print(f"已设置价格推送阈值为 {threshold}%")
                        save_config()
                except ValueError:
                    print("输入无效，请输入有效的数字")
            elif choice == "7":
                CONFIG["telegram_batch_mode"] = not CONFIG["telegram_batch_mode"]
                print(f"批量推送模式已{'启用' if CONFIG['telegram_batch_mode'] else '禁用'}")
                save_config()
            elif choice == "8":
                try:
                    interval = int(input(f"请输入批量推送间隔 (当前: {CONFIG['telegram_batch_interval']}秒): "))
                    if interval > 0:
                        CONFIG["telegram_batch_interval"] = interval
                        print(f"已设置批量推送间隔为 {interval}秒")
                        save_config()
                except ValueError:
                    print("输入无效，请输入有效的数字")
            elif choice == "9":
                test_telegram_connection()
                input("按Enter键继续...")
        
        time.sleep(1)

def price_monitor_menu():
    """价格监控配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                价格监控配置")
        print("=" * 60)
        print(f"1. 设置价格涨跌幅阈值 (当前: {CONFIG['price_change_threshold']}%)")
        print(f"2. 设置价格检查间隔 (当前: {CONFIG['price_check_interval']}秒)")
        print(f"3. {'禁用' if CONFIG['binance_enabled'] else '启用'}Binance.US监控")
        print(f"4. {'禁用' if CONFIG['gate_enabled'] else '启用'}Gate.io监控")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "0":
            break
        elif choice == "1":
            try:
                threshold = float(input(f"请输入价格涨跌幅阈值 (当前: {CONFIG['price_change_threshold']}%): "))
                if threshold > 0:
                    CONFIG["price_change_threshold"] = threshold
                    print(f"已设置价格涨跌幅阈值为 {threshold}%")
                    save_config()
            except ValueError:
                print("输入无效，请输入有效的数字")
        elif choice == "2":
            try:
                interval = int(input(f"请输入价格检查间隔 (当前: {CONFIG['price_check_interval']}秒): "))
                if interval > 0:
                    CONFIG["price_check_interval"] = interval
                    print(f"已设置价格检查间隔为 {interval}秒")
                    save_config()
            except ValueError:
                print("输入无效，请输入有效的数字")
        elif choice == "3":
            CONFIG["binance_enabled"] = not CONFIG["binance_enabled"]
            print(f"Binance.US监控已{'启用' if CONFIG['binance_enabled'] else '禁用'}")
            save_config()
        elif choice == "4":
            CONFIG["gate_enabled"] = not CONFIG["gate_enabled"]
            print(f"Gate.io监控已{'启用' if CONFIG['gate_enabled'] else '禁用'}")
            save_config()
        
        time.sleep(1)

def announcement_menu():
    """公告扫描配置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                公告扫描配置")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['announcement_enabled'] else '启用'}公告扫描")
        print(f"2. 设置公告扫描间隔 (当前: {CONFIG['announcement_scan_interval']}秒)")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["announcement_enabled"] = not CONFIG["announcement_enabled"]
            print(f"公告扫描已{'启用' if CONFIG['announcement_enabled'] else '禁用'}")
            save_config()
        elif choice == "2":
            try:
                interval = int(input(f"请输入公告扫描间隔 (当前: {CONFIG['announcement_scan_interval']}秒): "))
                if interval > 0:
                    CONFIG["announcement_scan_interval"] = interval
                    print(f"已设置公告扫描间隔为 {interval}秒")
                    save_config()
            except ValueError:
                print("输入无效，请输入有效的数字")
        
        time.sleep(1)

def proxy_menu():
    """代理管理中心"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                代理管理中心")
        print("=" * 60)
        print(f"1. {'禁用' if CONFIG['use_proxy'] else '启用'}代理")
        print("2. 基本代理设置")
        print("3. VLESS节点管理")
        print("4. 快捷配置代理")
        print("5. 安装/修复代理服务")
        print("6. 测试代理连接")
        print("0. 返回主菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "0":
            break
        elif choice == "1":
            CONFIG["use_proxy"] = not CONFIG["use_proxy"]
            print(f"代理已{'启用' if CONFIG['use_proxy'] else '禁用'}")
            save_config()
        elif choice == "2":
            basic_proxy_menu()
        elif choice == "3":
            run_vless_manager()
        elif choice == "4":
            quick_proxy_config()
        elif choice == "5":
            install_proxy()
        elif choice == "6":
            test_proxy_connection()
        
        time.sleep(1)

def basic_proxy_menu():
    """基本代理设置菜单"""
    while True:
        clear_screen()
        print("=" * 60)
        print("                基本代理设置")
        print("=" * 60)
        print(f"1. 设置HTTP代理 (当前: {CONFIG['proxy']['http']})")
        print(f"2. 设置HTTPS代理 (当前: {CONFIG['proxy']['https']})")
        print("0. 返回上级菜单")
        print("-" * 60)
        
        choice = input("请选择: ")
        
        if choice == "0":
            break
        elif choice == "1":
            proxy = input(f"请输入HTTP代理 (当前: {CONFIG['proxy']['http']}): ")
            if proxy:
                CONFIG["proxy"]["http"] = proxy
                print(f"已设置HTTP代理为 {proxy}")
                save_config()
        elif choice == "2":
            proxy = input(f"请输入HTTPS代理 (当前: {CONFIG['proxy']['https']}): ")
            if proxy:
                CONFIG["proxy"]["https"] = proxy
                print(f"已设置HTTPS代理为 {proxy}")
                save_config()
        
        time.sleep(1)

def run_vless_manager():
    """运行VLESS节点管理器"""
    try:
        # VLESS管理器脚本路径
        vless_manager_script = os.path.join(script_dir, "scripts", "vless_manager.sh")
        
        # 确保脚本有执行权限
        if not os.access(vless_manager_script, os.X_OK):
            os.chmod(vless_manager_script, 0o755)
            logger.info(f"已添加执行权限: {vless_manager_script}")
        
        # 运行VLESS管理器
        print("正在启动VLESS节点管理器...")
        
        # 检查是否需要使用sudo
        if os.geteuid() != 0:
            cmd = f"sudo {vless_manager_script}"
        else:
            cmd = vless_manager_script
        
        subprocess.call(cmd, shell=True)
        print("VLESS节点管理器已退出")
    except Exception as e:
        print(f"运行VLESS管理器失败: {e}")
    
    input("按Enter键继续...")

def quick_proxy_config():
    """快捷配置代理"""
    try:
        # 运行快捷配置代理脚本
        script_path = os.path.join(script_dir, "scripts", "quick_proxy.sh")
        
        # 确保脚本有执行权限
        if not os.access(script_path, os.X_OK):
            os.chmod(script_path, 0o755)
        
        # 检查是否需要使用sudo
        if os.geteuid() != 0:
            cmd = f"sudo {script_path}"
        else:
            cmd = script_path
        
        # 运行脚本
        subprocess.call(cmd, shell=True)
        
        # 更新配置
        CONFIG["use_proxy"] = True
        CONFIG["proxy"] = {
            "http": "socks5://127.0.0.1:1080",
            "https": "socks5://127.0.0.1:1080"
        }
        save_config()
        
        print("代理配置已更新")
    except Exception as e:
        print(f"运行快捷配置代理脚本失败: {e}")
    
    input("按Enter键继续...")

def install_proxy():
    """安装/修复代理服务"""
    try:
        # 运行代理安装脚本
        script_path = os.path.join(script_dir, "scripts", "install_proxy.sh")
        
        # 确保脚本有执行权限
        if not os.access(script_path, os.X_OK):
            os.chmod(script_path, 0o755)
        
        # 检查是否需要使用sudo
        if os.geteuid() != 0:
            cmd = f"sudo {script_path}"
        else:
            cmd = script_path
        
        # 运行脚本
        print("正在安装/修复代理服务...")
        subprocess.call(cmd, shell=True)
        print("代理服务安装/修复完成")
    except Exception as e:
        print(f"安装/修复代理服务失败: {e}")
    
    input("按Enter键继续...")

def test_proxy_connection():
    """测试代理连接"""
    try:
        # 运行代理测试脚本
        script_path = os.path.join(script_dir, "scripts", "test_integration.py")
        
        # 确保Python脚本有执行权限
        if not os.access(script_path, os.X_OK):
            os.chmod(script_path, 0o755)
        
        # 运行脚本
        print("正在测试代理连接...")
        cmd = [sys.executable, script_path]
        subprocess.call(cmd)
    except Exception as e:
        print(f"测试代理连接失败: {e}")
    
    input("按Enter键继续...")

def view_config():
    """查看当前配置"""
    clear_screen()
    print("=" * 60)
    print("                当前配置")
    print("=" * 60)
    print("基本设置:")
    print(f"- 价格涨跌幅阈值: {CONFIG['price_change_threshold']}%")
    print(f"- 价格检查间隔: {CONFIG['price_check_interval']}秒")
    print(f"- 公告扫描间隔: {CONFIG['announcement_scan_interval']}秒")
    print(f"- 数据存储目录: {CONFIG['data_dir']}")
    print("\n监控设置:")
    print(f"- Binance.US监控: {'启用' if CONFIG['binance_enabled'] else '禁用'}")
    print(f"- Gate.io监控: {'启用' if CONFIG['gate_enabled'] else '禁用'}")
    print(f"- 公告扫描: {'启用' if CONFIG['announcement_enabled'] else '禁用'}")
    print("\n代理设置:")
    print(f"- 使用代理: {'是' if CONFIG['use_proxy'] else '否'}")
    if CONFIG["use_proxy"]:
        print(f"- HTTP代理: {CONFIG['proxy']['http']}")
        print(f"- HTTPS代理: {CONFIG['proxy']['https']}")
    print("\nTelegram推送设置:")
    print(f"- 启用Telegram推送: {'是' if CONFIG['telegram_enabled'] else '否'}")
    if CONFIG["telegram_enabled"]:
        print(f"- 机器人Token: {CONFIG['telegram_bot_token'][:10]}...")
        print(f"- 聊天ID: {CONFIG['telegram_chat_id']}")
        print(f"- 推送价格变动: {'是' if CONFIG['telegram_price_notify'] else '否'}")
        print(f"- 推送公告: {'是' if CONFIG['telegram_announcement_notify'] else '否'}")
        print(f"- 价格推送阈值: {CONFIG['telegram_min_price_change']}%")
        print(f"- 批量推送模式: {'启用' if CONFIG['telegram_batch_mode'] else '禁用'}")
        print(f"- 批量推送间隔: {CONFIG['telegram_batch_interval']}秒")
    
    input("\n按Enter键继续...")

def view_logs():
    """查看监控日志"""
    clear_screen()
    print("=" * 60)
    print("                监控日志")
    print("=" * 60)
    
    log_file = os.path.join(script_dir, "crypto_monitor.log")
    if os.path.exists(log_file):
        try:
            # 读取最后50行日志
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines[-50:]:
                    print(line.strip())
        except Exception as e:
            print(f"读取日志失败: {e}")
    else:
        print("日志文件不存在")
    
    input("\n按Enter键继续...")

def handle_exit():
    """处理退出"""
    if is_running:
        stop_monitoring()
    print("正在退出程序...")
    sys.exit(0)

def signal_handler(sig, frame):
    """信号处理函数"""
    print("\n接收到中断信号，正在退出...")
    handle_exit()

def main():
    """主函数"""
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 加载配置
    load_config()
    
    # 主循环
    while True:
        choice = show_main_menu()
        
        if choice == "1":
            if is_running:
                stop_monitoring()
            else:
                start_monitoring()
            time.sleep(1)
        elif choice == "2":
            telegram_menu()
        elif choice == "3":
            price_monitor_menu()
        elif choice == "4":
            announcement_menu()
        elif choice == "5":
            proxy_menu()
        elif choice == "6":
            view_config()
        elif choice == "7":
            view_logs()
        elif choice == "8":
            handle_exit()
        else:
            print("无效选项，请重新输入")
            time.sleep(1)

if __name__ == "__main__":
    main()

