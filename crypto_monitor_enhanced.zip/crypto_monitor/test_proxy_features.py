#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
代理功能测试脚本
用于测试自动切换代理功能和代理状态显示功能
"""

import os
import sys
import time
import logging

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "proxy_test.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("proxy_test")

def clear_screen():
    """清除屏幕"""
    os.system('cls' if os.name == 'nt' else 'clear')

def test_proxy_auto_switch():
    """测试代理自动切换功能"""
    try:
        from proxy_auto_switch import ProxyAutoSwitchManager
        from proxy_manager import ProxyManager
        
        print("正在测试代理自动切换功能...")
        
        # 初始化代理管理器
        proxy_manager = ProxyManager()
        
        # 初始化代理自动切换管理器
        auto_switch_manager = ProxyAutoSwitchManager(proxy_manager)
        
        # 获取所有节点
        nodes = auto_switch_manager.get_all_nodes()
        print(f"发现 {len(nodes)} 个节点")
        
        # 测试切换到最佳节点
        print("正在测试切换到最佳节点...")
        success = auto_switch_manager.switch_to_best_node()
        if success:
            print("切换到最佳节点成功")
            status = auto_switch_manager.get_proxy_status()
            if status["current_node"]:
                print(f"当前使用节点: {status['current_node']['name']}")
            else:
                print("当前未使用节点")
        else:
            print("切换到最佳节点失败")
        
        # 测试切换到下一个节点
        print("\n正在测试切换到下一个节点...")
        success = auto_switch_manager.switch_to_next_node()
        if success:
            print("切换到下一个节点成功")
            status = auto_switch_manager.get_proxy_status()
            if status["current_node"]:
                print(f"当前使用节点: {status['current_node']['name']}")
            else:
                print("当前未使用节点")
        else:
            print("切换到下一个节点失败")
        
        # 测试切换到直连模式
        print("\n正在测试切换到直连模式...")
        success = auto_switch_manager.switch_to_direct()
        if success:
            print("切换到直连模式成功")
            status = auto_switch_manager.get_proxy_status()
            if status["direct_mode"]:
                print("当前为直连模式")
            else:
                print("当前不是直连模式")
        else:
            print("切换到直连模式失败")
        
        # 测试API请求
        print("\n正在测试API请求...")
        from api_wrapper import patch_requests
        import requests
        
        # 替换requests函数，添加自动切换代理功能
        patch_requests()
        
        # 测试API请求
        try:
            response = requests.get("https://api.binance.us/api/v3/ticker/price", timeout=10)
            print(f"API请求成功，状态码: {response.status_code}")
            print(f"响应内容: {response.text[:100]}...")
        except Exception as e:
            print(f"API请求失败: {e}")
        
        return True
    except Exception as e:
        print(f"测试代理自动切换功能失败: {e}")
        logger.error(f"测试代理自动切换功能失败: {e}", exc_info=True)
        return False

def test_proxy_status_display():
    """测试代理状态显示功能"""
    try:
        from proxy_status_display import ProxyStatusDisplay
        from proxy_auto_switch import ProxyAutoSwitchManager
        from proxy_manager import ProxyManager
        
        print("正在测试代理状态显示功能...")
        
        # 初始化代理管理器
        proxy_manager = ProxyManager()
        
        # 初始化代理自动切换管理器
        auto_switch_manager = ProxyAutoSwitchManager(proxy_manager)
        
        # 初始化代理状态显示
        proxy_status_display = ProxyStatusDisplay(auto_switch_manager, proxy_manager)
        
        # 显示当前代理状态
        print("\n当前代理状态:")
        status_text = proxy_status_display.display_current_status()
        
        # 显示历史记录摘要
        print("\n历史记录摘要:")
        summary = proxy_status_display.display_status_history()
        
        # 保存状态报告
        print("\n正在保存状态报告...")
        report_path = proxy_status_display.save_status_report()
        if report_path:
            print(f"状态报告已保存到: {report_path}")
        else:
            print("保存状态报告失败")
        
        return True
    except Exception as e:
        print(f"测试代理状态显示功能失败: {e}")
        logger.error(f"测试代理状态显示功能失败: {e}", exc_info=True)
        return False

def main():
    """主函数"""
    clear_screen()
    print("=" * 60)
    print("                代理功能测试")
    print("=" * 60)
    
    # 测试代理自动切换功能
    print("\n[1] 测试代理自动切换功能")
    print("-" * 60)
    auto_switch_success = test_proxy_auto_switch()
    
    # 测试代理状态显示功能
    print("\n\n[2] 测试代理状态显示功能")
    print("-" * 60)
    status_display_success = test_proxy_status_display()
    
    # 测试结果
    print("\n\n测试结果:")
    print("-" * 60)
    print(f"代理自动切换功能: {'成功' if auto_switch_success else '失败'}")
    print(f"代理状态显示功能: {'成功' if status_display_success else '失败'}")
    
    if auto_switch_success and status_display_success:
        print("\n所有测试通过！")
    else:
        print("\n部分测试失败，请查看日志获取详细信息。")
    
    input("\n按Enter键继续...")

if __name__ == "__main__":
    main()

