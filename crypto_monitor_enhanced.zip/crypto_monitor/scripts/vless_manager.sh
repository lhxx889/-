#!/bin/bash
# VLESS节点管理器

# 颜色输出
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置文件路径
NODES_FILE="$(dirname "$(dirname "$(readlink -f "$0")")")/config/vless_nodes.json"
CONFIG_DIR="$(dirname "$(dirname "$(readlink -f "$0")")")/config"
CONFIG_TEMPLATE="$CONFIG_DIR/proxy_template.json"
SING_BOX_CONFIG="/etc/sing-box/config.json"

# 测试端口 - 修改为1081，避免与现有服务冲突
TEST_SOCKS_PORT=1081
TEST_HTTP_PORT=7891

# 检查是否有root权限
if [ "$EUID" -ne 0 ]; then
  USE_SUDO="sudo"
else
  USE_SUDO=""
fi

# 确保配置目录存在
mkdir -p "$CONFIG_DIR"

# 如果节点文件不存在，创建一个空的JSON数组
if [ ! -f "$NODES_FILE" ]; then
  echo '[]' > "$NODES_FILE"
fi

# 如果配置模板不存在，创建一个基本模板
if [ ! -f "$CONFIG_TEMPLATE" ]; then
  cat > "$CONFIG_TEMPLATE" << 'EOF'
{
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "0.0.0.0",
      "listen_port": 1080
    },
    {
      "type": "http",
      "tag": "http-in",
      "listen": "0.0.0.0",
      "listen_port": 7890
    }
  ],
  "outbounds": [
    {
      "type": "vless",
      "tag": "vless-out",
      "server": "example.com",
      "server_port": 443,
      "uuid": "00000000-0000-0000-0000-000000000000",
      "flow": "xtls-rprx-vision",
      "tls": {
        "enabled": true,
        "server_name": "example.com",
        "utls": {
          "enabled": true,
          "fingerprint": "chrome"
        },
        "reality": {
          "enabled": true,
          "public_key": "publickey",
          "short_id": "shortid"
        }
      }
    }
  ]
}
EOF
fi

# 检查jq是否安装
check_jq() {
  if ! command -v jq &> /dev/null; then
    echo -e "${YELLOW}jq未安装，尝试安装...${NC}"
    $USE_SUDO apt-get update
    $USE_SUDO apt-get install -y jq
    if ! command -v jq &> /dev/null; then
      echo -e "${RED}jq安装失败，无法继续${NC}"
      exit 1
    fi
  fi
}

# 检查sing-box是否安装
check_sing_box() {
  if ! command -v sing-box &> /dev/null; then
    echo -e "${RED}sing-box未安装，请先运行install_proxy.sh安装${NC}"
    exit 1
  fi
}

# 从VLESS链接导入节点
import_from_link() {
  echo -e "${BLUE}=== 从VLESS链接导入节点 ===${NC}"
  
  read -p "请输入VLESS链接: " vless_link
  
  # 检查链接格式
  if [[ ! "$vless_link" =~ ^vless:// ]]; then
    echo -e "${RED}无效的VLESS链接格式${NC}"
    return
  fi
  
  # 解析链接
  # 格式: vless://UUID@SERVER:PORT/?参数列表#备注
  
  # 提取UUID和服务器信息
  uuid=$(echo "$vless_link" | sed -n 's/^vless:\/\/\([^@]*\)@.*/\1/p')
  server=$(echo "$vless_link" | sed -n 's/^vless:\/\/[^@]*@\([^:]*\):.*/\1/p')
  port=$(echo "$vless_link" | sed -n 's/^vless:\/\/[^@]*@[^:]*:\([0-9]*\)\/.*/\1/p')
  
  # 提取参数
  params=$(echo "$vless_link" | sed -n 's/^.*\/?\([^#]*\).*/\1/p')
  
  # 提取备注
  name=$(echo "$vless_link" | sed -n 's/^.*#\(.*\)$/\1/p')
  name=$(echo -e "$(printf "%b" "$(echo "$name" | sed 's/%/\\x/g')")")
  
  # 如果没有备注，使用服务器地址作为名称
  if [ -z "$name" ]; then
    name="$server:$port"
  fi
  
  # 解析参数
  flow=""
  sni=""
  public_key=""
  short_id=""
  
  # 分割参数
  IFS='&' read -ra PARAM_ARRAY <<< "$params"
  for param in "${PARAM_ARRAY[@]}"; do
    key=$(echo "$param" | cut -d= -f1)
    value=$(echo "$param" | cut -d= -f2-)
    
    case "$key" in
      "flow")
        flow="$value"
        ;;
      "sni")
        sni="$value"
        ;;
      "pbk")
        public_key="$value"
        ;;
      "sid")
        short_id="$value"
        ;;
    esac
  done
  
  # 显示解析结果
  echo -e "${YELLOW}解析结果:${NC}"
  echo "节点名称: $name"
  echo "服务器地址: $server"
  echo "服务器端口: $port"
  echo "UUID: $uuid"
  echo "流控类型: $flow"
  echo "SNI: $sni"
  echo "公钥: $public_key"
  echo "Short ID: $short_id"
  
  # 确认添加
  read -p "确认添加此节点? [y/N]: " confirm
  if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${YELLOW}已取消添加节点${NC}"
    return
  fi
  
  # 创建节点JSON
  node=$(cat <<EOF
{
  "name": "$name",
  "server": "$server",
  "port": $port,
  "uuid": "$uuid",
  "flow": "$flow",
  "sni": "$sni",
  "public_key": "$public_key",
  "short_id": "$short_id"
}
EOF
)
  
  # 添加到节点列表
  nodes=$(jq ". += [$node]" "$NODES_FILE")
  echo "$nodes" > "$NODES_FILE"
  
  echo -e "${GREEN}节点 '$name' 已添加${NC}"
}

# 添加节点
add_node() {
  echo -e "${BLUE}=== 添加新VLESS节点 ===${NC}"
  
  read -p "节点名称: " name
  read -p "服务器地址: " server
  read -p "服务器端口: " port
  read -p "UUID: " uuid
  read -p "流控类型 [xtls-rprx-vision]: " flow
  flow=${flow:-xtls-rprx-vision}
  read -p "SNI: " sni
  read -p "公钥: " public_key
  read -p "Short ID: " short_id
  
  # 创建节点JSON
  node=$(cat <<EOF
{
  "name": "$name",
  "server": "$server",
  "port": $port,
  "uuid": "$uuid",
  "flow": "$flow",
  "sni": "$sni",
  "public_key": "$public_key",
  "short_id": "$short_id"
}
EOF
)
  
  # 添加到节点列表
  nodes=$(jq ". += [$node]" "$NODES_FILE")
  echo "$nodes" > "$NODES_FILE"
  
  echo -e "${GREEN}节点 '$name' 已添加${NC}"
}

# 删除节点
delete_node() {
  echo -e "${BLUE}=== 删除VLESS节点 ===${NC}"
  
  # 显示所有节点
  list_nodes
  
  read -p "输入要删除的节点编号: " index
  
  # 检查输入是否有效
  if ! [[ "$index" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}无效的编号${NC}"
    return
  fi
  
  # 获取节点数量
  count=$(jq '. | length' "$NODES_FILE")
  
  if [ "$index" -ge 0 ] && [ "$index" -lt "$count" ]; then
    # 获取节点名称
    name=$(jq -r ".[$index].name" "$NODES_FILE")
    
    # 删除节点
    nodes=$(jq "del(.[$index])" "$NODES_FILE")
    echo "$nodes" > "$NODES_FILE"
    
    echo -e "${GREEN}节点 '$name' 已删除${NC}"
  else
    echo -e "${RED}无效的节点编号${NC}"
  fi
}

# 修改节点
edit_node() {
  echo -e "${BLUE}=== 修改VLESS节点 ===${NC}"
  
  # 显示所有节点
  list_nodes
  
  read -p "输入要修改的节点编号: " index
  
  # 检查输入是否有效
  if ! [[ "$index" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}无效的编号${NC}"
    return
  fi
  
  # 获取节点数量
  count=$(jq '. | length' "$NODES_FILE")
  
  if [ "$index" -ge 0 ] && [ "$index" -lt "$count" ]; then
    # 获取当前节点信息
    name=$(jq -r ".[$index].name" "$NODES_FILE")
    server=$(jq -r ".[$index].server" "$NODES_FILE")
    port=$(jq -r ".[$index].port" "$NODES_FILE")
    uuid=$(jq -r ".[$index].uuid" "$NODES_FILE")
    flow=$(jq -r ".[$index].flow" "$NODES_FILE")
    sni=$(jq -r ".[$index].sni" "$NODES_FILE")
    public_key=$(jq -r ".[$index].public_key" "$NODES_FILE")
    short_id=$(jq -r ".[$index].short_id" "$NODES_FILE")
    
    echo -e "${YELLOW}当前值显示在方括号中，直接按Enter保持不变${NC}"
    
    read -p "节点名称 [$name]: " new_name
    read -p "服务器地址 [$server]: " new_server
    read -p "服务器端口 [$port]: " new_port
    read -p "UUID [$uuid]: " new_uuid
    read -p "流控类型 [$flow]: " new_flow
    read -p "SNI [$sni]: " new_sni
    read -p "公钥 [$public_key]: " new_public_key
    read -p "Short ID [$short_id]: " new_short_id
    
    # 使用新值或保持原值
    new_name=${new_name:-$name}
    new_server=${new_server:-$server}
    new_port=${new_port:-$port}
    new_uuid=${new_uuid:-$uuid}
    new_flow=${new_flow:-$flow}
    new_sni=${new_sni:-$sni}
    new_public_key=${new_public_key:-$public_key}
    new_short_id=${new_short_id:-$short_id}
    
    # 更新节点
    node=$(cat <<EOF
{
  "name": "$new_name",
  "server": "$new_server",
  "port": $new_port,
  "uuid": "$new_uuid",
  "flow": "$new_flow",
  "sni": "$new_sni",
  "public_key": "$new_public_key",
  "short_id": "$new_short_id"
}
EOF
)
    
    nodes=$(jq ".[$index] = $node" "$NODES_FILE")
    echo "$nodes" > "$NODES_FILE"
    
    echo -e "${GREEN}节点 '$new_name' 已更新${NC}"
  else
    echo -e "${RED}无效的节点编号${NC}"
  fi
}

# 列出所有节点
list_nodes() {
  echo -e "${BLUE}=== VLESS节点列表 ===${NC}"
  
  # 获取节点数量
  count=$(jq '. | length' "$NODES_FILE")
  
  if [ "$count" -eq 0 ]; then
    echo -e "${YELLOW}没有保存的节点${NC}"
    return
  fi
  
  # 显示所有节点
  for i in $(seq 0 $(($count - 1))); do
    name=$(jq -r ".[$i].name" "$NODES_FILE")
    server=$(jq -r ".[$i].server" "$NODES_FILE")
    port=$(jq -r ".[$i].port" "$NODES_FILE")
    echo -e "${GREEN}[$i]${NC} $name - $server:$port"
  done
}

# 导出节点为VLESS链接
export_node() {
  echo -e "${BLUE}=== 导出VLESS节点链接 ===${NC}"
  
  # 显示所有节点
  list_nodes
  
  read -p "输入要导出的节点编号: " index
  
  # 检查输入是否有效
  if ! [[ "$index" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}无效的编号${NC}"
    return
  fi
  
  # 获取节点数量
  count=$(jq '. | length' "$NODES_FILE")
  
  if [ "$index" -ge 0 ] && [ "$index" -lt "$count" ]; then
    # 获取节点信息
    name=$(jq -r ".[$index].name" "$NODES_FILE")
    server=$(jq -r ".[$index].server" "$NODES_FILE")
    port=$(jq -r ".[$index].port" "$NODES_FILE")
    uuid=$(jq -r ".[$index].uuid" "$NODES_FILE")
    flow=$(jq -r ".[$index].flow" "$NODES_FILE")
    sni=$(jq -r ".[$index].sni" "$NODES_FILE")
    public_key=$(jq -r ".[$index].public_key" "$NODES_FILE")
    short_id=$(jq -r ".[$index].short_id" "$NODES_FILE")
    
    # URL编码节点名称
    encoded_name=$(echo -n "$name" | xxd -plain | tr -d '\n' | sed 's/\(..\)/%\1/g')
    
    # 构建VLESS链接
    vless_link="vless://$uuid@$server:$port/?type=tcp&encryption=none&flow=$flow&sni=$sni&fp=chrome&security=reality&pbk=$public_key"
    
    # 如果有short_id，添加到链接
    if [ -n "$short_id" ]; then
      vless_link="${vless_link}&sid=$short_id"
    fi
    
    # 添加备注
    vless_link="${vless_link}#$encoded_name"
    
    echo -e "${GREEN}VLESS链接:${NC}"
    echo "$vless_link"
    
    # 询问是否复制到剪贴板
    if command -v xclip &> /dev/null; then
      read -p "是否复制到剪贴板? [y/N]: " copy
      if [[ "$copy" == "y" || "$copy" == "Y" ]]; then
        echo -n "$vless_link" | xclip -selection clipboard
        echo -e "${GREEN}已复制到剪贴板${NC}"
      fi
    fi
  else
    echo -e "${RED}无效的节点编号${NC}"
  fi
}

# 测试节点连接
test_node() {
  echo -e "${BLUE}=== 测试节点连接 ===${NC}"
  
  # 显示所有节点
  list_nodes
  
  read -p "输入要测试的节点编号 (或输入'a'测试所有节点): " input
  
  if [ "$input" = "a" ]; then
    # 测试所有节点
    count=$(jq '. | length' "$NODES_FILE")
    
    for i in $(seq 0 $(($count - 1))); do
      name=$(jq -r ".[$i].name" "$NODES_FILE")
      server=$(jq -r ".[$i].server" "$NODES_FILE")
      
      echo -e "${YELLOW}测试节点 '$name' ($server)...${NC}"
      
      # 创建临时配置
      create_config_for_node "$i" "/tmp/sing-box-test-$i.json"
      
      # 测试连接
      timeout 10 sing-box run -c "/tmp/sing-box-test-$i.json" &
      pid=$!
      sleep 2
      
      # 尝试通过代理连接
      if curl --connect-timeout 5 -s -x socks5://127.0.0.1:$TEST_SOCKS_PORT https://www.google.com -o /dev/null; then
        echo -e "${GREEN}节点 '$name' 连接成功${NC}"
      else
        echo -e "${RED}节点 '$name' 连接失败${NC}"
      fi
      
      # 清理
      kill $pid 2>/dev/null
      wait $pid 2>/dev/null
      rm -f "/tmp/sing-box-test-$i.json"
    done
  elif [[ "$input" =~ ^[0-9]+$ ]]; then
    # 测试单个节点
    count=$(jq '. | length' "$NODES_FILE")
    
    if [ "$input" -ge 0 ] && [ "$input" -lt "$count" ]; then
      name=$(jq -r ".[$input].name" "$NODES_FILE")
      server=$(jq -r ".[$input].server" "$NODES_FILE")
      
      echo -e "${YELLOW}测试节点 '$name' ($server)...${NC}"
      
      # 创建临时配置
      create_config_for_node "$input" "/tmp/sing-box-test.json"
      
      # 测试连接
      timeout 10 sing-box run -c "/tmp/sing-box-test.json" &
      pid=$!
      sleep 2
      
      # 尝试通过代理连接
      if curl --connect-timeout 5 -s -x socks5://127.0.0.1:$TEST_SOCKS_PORT https://www.google.com -o /dev/null; then
        echo -e "${GREEN}节点 '$name' 连接成功${NC}"
      else
        echo -e "${RED}节点 '$name' 连接失败${NC}"
      fi
      
      # 清理
      kill $pid 2>/dev/null
      wait $pid 2>/dev/null
      rm -f "/tmp/sing-box-test.json"
    else
      echo -e "${RED}无效的节点编号${NC}"
    fi
  else
    echo -e "${RED}无效的输入${NC}"
  fi
}

# 为节点创建配置
create_config_for_node() {
  local index=$1
  local output_file=$2
  
  # 获取节点信息
  server=$(jq -r ".[$index].server" "$NODES_FILE")
  port=$(jq -r ".[$index].port" "$NODES_FILE")
  uuid=$(jq -r ".[$index].uuid" "$NODES_FILE")
  flow=$(jq -r ".[$index].flow" "$NODES_FILE")
  sni=$(jq -r ".[$index].sni" "$NODES_FILE")
  public_key=$(jq -r ".[$index].public_key" "$NODES_FILE")
  short_id=$(jq -r ".[$index].short_id" "$NODES_FILE")
  
  # 创建配置文件
  if [[ "$output_file" == *"test"* ]]; then
    # 测试配置使用不同的端口
    cat > "$output_file" << EOF
{
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": $TEST_SOCKS_PORT
    },
    {
      "type": "http",
      "tag": "http-in",
      "listen": "127.0.0.1",
      "listen_port": $TEST_HTTP_PORT
    }
  ],
  "outbounds": [
    {
      "type": "vless",
      "tag": "vless-out",
      "server": "$server",
      "server_port": $port,
      "uuid": "$uuid",
      "flow": "$flow",
      "tls": {
        "enabled": true,
        "server_name": "$sni",
        "utls": {
          "enabled": true,
          "fingerprint": "chrome"
        },
        "reality": {
          "enabled": true,
          "public_key": "$public_key",
          "short_id": "$short_id"
        }
      }
    }
  ]
}
EOF
  else
    # 正常配置使用标准端口
    cat > "$output_file" << EOF
{
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": 1080
    },
    {
      "type": "http",
      "tag": "http-in",
      "listen": "127.0.0.1",
      "listen_port": 7890
    }
  ],
  "outbounds": [
    {
      "type": "vless",
      "tag": "vless-out",
      "server": "$server",
      "server_port": $port,
      "uuid": "$uuid",
      "flow": "$flow",
      "tls": {
        "enabled": true,
        "server_name": "$sni",
        "utls": {
          "enabled": true,
          "fingerprint": "chrome"
        },
        "reality": {
          "enabled": true,
          "public_key": "$public_key",
          "short_id": "$short_id"
        }
      }
    }
  ]
}
EOF
  fi
}

# 应用节点配置
apply_node() {
  echo -e "${BLUE}=== 应用节点配置 ===${NC}"
  
  # 显示所有节点
  list_nodes
  
  read -p "输入要应用的节点编号: " index
  
  # 检查输入是否有效
  if ! [[ "$index" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}无效的编号${NC}"
    return
  fi
  
  # 获取节点数量
  count=$(jq '. | length' "$NODES_FILE")
  
  if [ "$index" -ge 0 ] && [ "$index" -lt "$count" ]; then
    # 获取节点名称
    name=$(jq -r ".[$index].name" "$NODES_FILE")
    
    # 创建配置文件
    create_config_for_node "$index" "$SING_BOX_CONFIG"
    
    # 重启服务
    if command -v systemctl &> /dev/null; then
      $USE_SUDO systemctl restart sing-box
      echo -e "${GREEN}已应用节点 '$name' 并重启服务${NC}"
    else
      echo -e "${YELLOW}无法自动重启服务，请手动重启sing-box${NC}"
    fi
  else
    echo -e "${RED}无效的节点编号${NC}"
  fi
}

# 主菜单
main_menu() {
  while true; do
    clear
    echo -e "${BLUE}==============================${NC}"
    echo -e "${BLUE}      VLESS节点管理器        ${NC}"
    echo -e "${BLUE}==============================${NC}"
    echo -e "${GREEN}1. 添加新节点${NC}"
    echo -e "${GREEN}2. 从VLESS链接导入节点${NC}"
    echo -e "${GREEN}3. 删除节点${NC}"
    echo -e "${GREEN}4. 修改节点${NC}"
    echo -e "${GREEN}5. 查看所有节点${NC}"
    echo -e "${GREEN}6. 导出节点为VLESS链接${NC}"
    echo -e "${GREEN}7. 测试节点连接${NC}"
    echo -e "${GREEN}8. 应用节点配置${NC}"
    echo -e "${GREEN}0. 退出${NC}"
    echo -e "${BLUE}==============================${NC}"
    
    read -p "请选择 [0-8]: " choice
    
    case $choice in
      1) add_node ;;
      2) import_from_link ;;
      3) delete_node ;;
      4) edit_node ;;
      5) list_nodes; read -p "按Enter键继续..." ;;
      6) export_node; read -p "按Enter键继续..." ;;
      7) test_node; read -p "按Enter键继续..." ;;
      8) apply_node ;;
      0) exit 0 ;;
      *) echo -e "${RED}无效的选择${NC}"; sleep 1 ;;
    esac
  done
}

# 检查依赖
check_jq
check_sing_box

# 启动主菜单
main_menu

