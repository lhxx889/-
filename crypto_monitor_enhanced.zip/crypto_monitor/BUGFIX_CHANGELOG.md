# 修复日志

## 2025-06-06 更新

### 1. 修复sing-box路径问题

- 修改了`install_proxy.sh`脚本，自动检测sing-box的实际安装路径
- 更新了systemd服务文件，使用正确的sing-box路径
- 添加了符号链接创建功能，确保在`/usr/bin`和`/usr/local/bin`都能找到sing-box

### 2. 增强代理管理器功能

- 修改了`proxy_manager.py`，增加了更强大的sing-box路径检测
- 添加了服务文件自动更新功能，确保使用正确的sing-box路径
- 改进了错误处理和日志记录

### 3. 添加VLESS节点管理功能

- 新增`vless_manager.sh`脚本，提供完整的VLESS节点管理功能
- 支持添加、删除、修改、查看、测试和应用VLESS节点
- 添加了`VLESS_MANAGER_GUIDE.md`使用指南文档

### 4. 新增VLESS链接导入/导出功能

- 添加了从VLESS链接直接导入节点的功能，支持解析标准VLESS链接格式
- 添加了将节点导出为VLESS链接的功能，方便分享节点配置
- 自动解析链接中的所有参数，包括UUID、服务器地址、端口、流控类型、SNI、公钥、短ID和备注

## 使用方法

### 修复sing-box路径问题

如果您遇到"sing-box.service: Failed with result 'exec'"错误，请运行以下命令：

```bash
./scripts/install_proxy.sh
```

这将自动检测sing-box的正确路径并更新服务配置。

### 使用VLESS节点管理器

```bash
# 确保脚本有执行权限
chmod +x ./scripts/vless_manager.sh

# 运行VLESS节点管理器
./scripts/vless_manager.sh
```

### 从VLESS链接导入节点

1. 运行VLESS节点管理器
2. 选择"2. 从VLESS链接导入节点"
3. 粘贴VLESS链接，例如：
   ```
   vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态
   ```
4. 确认添加节点

详细使用说明请参考`VLESS_MANAGER_GUIDE.md`文档。

