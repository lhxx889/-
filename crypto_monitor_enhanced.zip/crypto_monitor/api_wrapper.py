#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
API请求包装器
为加密货币监控程序提供API请求包装，支持自动切换代理功能
"""

import os
import sys
import json
import time
import logging
import requests
from functools import wraps

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入代理自动切换管理器
try:
    from proxy_auto_switch import ProxyAutoSwitchManager
    from proxy_manager import ProxyManager
except ImportError:
    ProxyAutoSwitchManager = None
    ProxyManager = None

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "api_wrapper.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("api_wrapper")

# 全局代理自动切换管理器实例
auto_switch_manager = None

def init_auto_switch_manager():
    """初始化代理自动切换管理器
    
    Returns:
        ProxyAutoSwitchManager: 代理自动切换管理器实例
    """
    global auto_switch_manager
    
    if auto_switch_manager is not None:
        return auto_switch_manager
    
    if ProxyAutoSwitchManager is None or ProxyManager is None:
        logger.warning("无法导入代理自动切换管理器或代理管理器")
        return None
    
    try:
        # 创建代理管理器
        proxy_manager = ProxyManager()
        
        # 创建代理自动切换管理器
        auto_switch_manager = ProxyAutoSwitchManager(proxy_manager)
        
        logger.info("代理自动切换管理器初始化成功")
        return auto_switch_manager
    except Exception as e:
        logger.error(f"初始化代理自动切换管理器失败: {e}")
        return None

def with_auto_proxy(func):
    """装饰器：为API请求函数添加自动切换代理功能
    
    Args:
        func: 原始API请求函数
        
    Returns:
        function: 包装后的函数
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 初始化代理自动切换管理器
        manager = init_auto_switch_manager()
        
        if manager is None:
            # 如果管理器初始化失败，直接调用原始函数
            return func(*args, **kwargs)
        
        # 获取配置
        config = kwargs.get('config', {})
        use_proxy = config.get('use_proxy', False)
        
        # 如果不使用代理，直接调用原始函数
        if not use_proxy:
            return func(*args, **kwargs)
        
        # 提取URL参数
        url = None
        if len(args) > 0:
            url = args[0]
        elif 'url' in kwargs:
            url = kwargs['url']
        
        if url is None:
            # 如果无法获取URL，直接调用原始函数
            return func(*args, **kwargs)
        
        # 使用代理自动切换管理器处理请求
        try:
            response = manager.handle_api_request(url, use_proxy=True)
            
            if response is not None:
                return response
            
            # 如果所有尝试都失败，调用原始函数
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"代理自动切换请求失败: {e}")
            # 出现异常时，调用原始函数
            return func(*args, **kwargs)
    
    return wrapper

def api_request(url, method='get', params=None, data=None, headers=None, timeout=10, use_proxy=None, max_retries=3):
    """统一的API请求函数，支持自动切换代理
    
    Args:
        url: API URL
        method: 请求方法，默认为get
        params: URL参数
        data: 请求数据
        headers: 请求头
        timeout: 超时时间，秒
        use_proxy: 是否使用代理，None表示自动判断
        max_retries: 最大重试次数
        
    Returns:
        response: 请求响应对象，如果所有尝试都失败则返回None
    """
    # 初始化代理自动切换管理器
    manager = init_auto_switch_manager()
    
    if manager is None or use_proxy is False:
        # 如果管理器初始化失败或明确不使用代理，直接发送请求
        try:
            if method.lower() == 'get':
                return requests.get(url, params=params, headers=headers, timeout=timeout)
            elif method.lower() == 'post':
                return requests.post(url, params=params, data=data, headers=headers, timeout=timeout)
            else:
                logger.warning(f"不支持的请求方法: {method}")
                return None
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求异常: {url}, 错误: {e}")
            return None
    
    # 使用代理自动切换管理器处理请求
    try:
        if method.lower() == 'get':
            return manager.handle_api_request(url, use_proxy=use_proxy, max_retries=max_retries)
        elif method.lower() == 'post':
            # 对于POST请求，需要自定义处理
            # 确定是否使用代理
            if use_proxy is None:
                use_proxy = not manager.proxy_status["direct_mode"]
            
            # 设置代理
            proxies = None
            if use_proxy:
                proxies = {
                    "http": "socks5://127.0.0.1:1080",
                    "https": "socks5://127.0.0.1:1080"
                }
            
            # 尝试请求
            for retry in range(max_retries):
                try:
                    response = requests.post(url, params=params, data=data, headers=headers, proxies=proxies, timeout=timeout)
                    
                    # 检查是否成功
                    if response.status_code == 200:
                        return response
                    
                    # 如果是代理问题（403、429等状态码），尝试切换代理
                    if use_proxy and response.status_code in [403, 429, 502, 503]:
                        logger.warning(f"API请求被拦截: {url}, 状态码: {response.status_code}, 尝试切换代理")
                        
                        # 记录失败的API
                        manager.proxy_status["failed_apis"].add(url)
                        
                        # 切换到下一个节点
                        manager.switch_to_next_node()
                        
                        # 更新代理设置
                        proxies = {
                            "http": "socks5://127.0.0.1:1080",
                            "https": "socks5://127.0.0.1:1080"
                        }
                    else:
                        # 其他错误，直接返回响应
                        return response
                
                except requests.exceptions.RequestException as e:
                    logger.error(f"API请求异常: {url}, 错误: {e}, 重试: {retry+1}/{max_retries}")
                    
                    # 如果是使用代理且连接错误，尝试切换代理
                    if use_proxy and isinstance(e, (requests.exceptions.ConnectionError, requests.exceptions.Timeout)):
                        logger.warning(f"代理连接错误，尝试切换代理")
                        
                        # 记录失败的API
                        manager.proxy_status["failed_apis"].add(url)
                        
                        # 切换到下一个节点
                        manager.switch_to_next_node()
                        
                        # 更新代理设置
                        proxies = {
                            "http": "socks5://127.0.0.1:1080",
                            "https": "socks5://127.0.0.1:1080"
                        }
                    
                    # 最后一次重试失败
                    if retry == max_retries - 1:
                        # 如果使用代理失败，尝试直连
                        if use_proxy:
                            logger.warning(f"所有代理节点都失败，尝试直连: {url}")
                            try:
                                response = requests.post(url, params=params, data=data, headers=headers, timeout=timeout)
                                
                                # 如果直连成功，切换到直连模式
                                if response.status_code == 200:
                                    logger.info(f"直连成功: {url}")
                                    manager.switch_to_direct()
                                    return response
                                else:
                                    logger.warning(f"直连失败: {url}, 状态码: {response.status_code}")
                            except requests.exceptions.RequestException as e2:
                                logger.error(f"直连异常: {url}, 错误: {e2}")
                        
                        return None
            
            return None
        else:
            logger.warning(f"不支持的请求方法: {method}")
            return None
    except Exception as e:
        logger.error(f"代理自动切换请求失败: {e}")
        return None

# 替换requests.get和requests.post函数
def patch_requests():
    """替换requests模块的get和post函数，添加自动切换代理功能"""
    original_get = requests.get
    original_post = requests.post
    
    @wraps(original_get)
    def patched_get(url, **kwargs):
        # 检查是否需要自动切换代理
        auto_proxy = kwargs.pop('auto_proxy', True)
        
        if not auto_proxy:
            return original_get(url, **kwargs)
        
        return api_request(url, method='get', **kwargs)
    
    @wraps(original_post)
    def patched_post(url, **kwargs):
        # 检查是否需要自动切换代理
        auto_proxy = kwargs.pop('auto_proxy', True)
        
        if not auto_proxy:
            return original_post(url, **kwargs)
        
        return api_request(url, method='post', **kwargs)
    
    # 替换函数
    requests.get = patched_get
    requests.post = patched_post
    
    logger.info("已替换requests.get和requests.post函数，添加自动切换代理功能")

# 如果直接运行此脚本，执行测试
if __name__ == "__main__":
    # 初始化代理自动切换管理器
    manager = init_auto_switch_manager()
    
    if manager is None:
        print("代理自动切换管理器初始化失败")
        sys.exit(1)
    
    # 测试API请求
    print("测试API请求...")
    
    # 测试URL列表
    test_urls = [
        "https://api.binance.us/api/v3/ping",
        "https://api.gateio.ws/api/v4/spot/currencies",
        "https://api.coingecko.com/api/v3/ping"
    ]
    
    for url in test_urls:
        print(f"测试URL: {url}")
        
        # 使用自动切换代理的API请求
        response = api_request(url, use_proxy=True)
        
        if response is not None:
            print(f"请求成功，状态码: {response.status_code}")
            print(f"响应内容: {response.text[:100]}...")
        else:
            print("请求失败")
    
    # 测试替换requests函数
    print("\n测试替换requests函数...")
    patch_requests()
    
    for url in test_urls:
        print(f"测试URL: {url}")
        
        # 使用替换后的requests.get函数
        try:
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                print(f"请求成功，状态码: {response.status_code}")
                print(f"响应内容: {response.text[:100]}...")
            else:
                print(f"请求失败，状态码: {response.status_code}")
        except Exception as e:
            print(f"请求异常: {e}")

