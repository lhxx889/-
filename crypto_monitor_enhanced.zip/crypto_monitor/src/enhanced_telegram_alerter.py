"""
Gate.io加密货币异动监控系统 - 增强版Telegram推送模块
负责将异常事件推送到Telegram，支持图表展示和防重复推送
"""

import logging
import time
import json
import requests
import os
from typing import Dict, List, Any, Optional, Set, Tuple
from datetime import datetime, timedelta
import hashlib

# 导入图表生成模块
from src.chart_generator import ChartGenerator

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("enhanced_telegram_alerter")

class EnhancedTelegramAlerter:
    """增强版Telegram警报推送类，支持图表展示和防重复推送"""
    
    def __init__(
        self, 
        token: str = None,
        chat_id: str = None,
        config_file: str = "telegram_config.json",
        max_retries: int = 3,
        retry_delay: int = 2,
        chart_dir: str = "charts",
        dedup_window: int = 3600  # 去重窗口（秒）
    ):
        """
        初始化增强版Telegram警报推送器
        
        Args:
            token: Telegram Bot API令牌
            chat_id: 目标聊天ID
            config_file: 配置文件路径
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
            chart_dir: 图表保存目录
            dedup_window: 去重窗口（秒）
        """
        self.token = token
        self.chat_id = chat_id
        self.config_file = config_file
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.chart_dir = chart_dir
        self.dedup_window = dedup_window
        
        # 初始化图表生成器
        self.chart_generator = ChartGenerator(chart_dir=chart_dir)
        
        # 初始化去重缓存
        self.alert_cache = {}  # 格式: {alert_hash: timestamp}
        self.alert_history_file = "alert_history.json"
        
        # 如果提供了配置文件，尝试从中加载配置
        if not (self.token and self.chat_id):
            self._load_config()
        
        # 加载历史警报记录
        self._load_alert_history()
        
        logger.info("增强版Telegram警报推送模块初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载Telegram配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.token = config.get("token", self.token)
                    self.chat_id = config.get("chat_id", self.chat_id)
                    logger.info("从配置文件加载Telegram配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def _load_alert_history(self) -> None:
        """加载历史警报记录"""
        try:
            if os.path.exists(self.alert_history_file):
                with open(self.alert_history_file, 'r') as f:
                    self.alert_cache = json.load(f)
                    
                    # 转换字符串时间戳为浮点数
                    self.alert_cache = {k: float(v) for k, v in self.alert_cache.items()}
                    
                    logger.info(f"成功加载{len(self.alert_cache)}条历史警报记录")
            else:
                logger.info("历史警报记录文件不存在，将创建新文件")
        except Exception as e:
            logger.error(f"加载历史警报记录失败: {str(e)}")
            self.alert_cache = {}
    
    def _save_alert_history(self) -> None:
        """保存历史警报记录"""
        try:
            # 清理过期记录
            self._clean_expired_alerts()
            
            with open(self.alert_history_file, 'w') as f:
                json.dump(self.alert_cache, f)
            
            logger.info(f"成功保存{len(self.alert_cache)}条历史警报记录")
        except Exception as e:
            logger.error(f"保存历史警报记录失败: {str(e)}")
    
    def _clean_expired_alerts(self) -> None:
        """清理过期的警报记录"""
        current_time = time.time()
        expired_keys = []
        
        for alert_hash, timestamp in self.alert_cache.items():
            if current_time - timestamp > self.dedup_window:
                expired_keys.append(alert_hash)
        
        for key in expired_keys:
            del self.alert_cache[key]
        
        if expired_keys:
            logger.info(f"已清理{len(expired_keys)}条过期警报记录")
    
    def _generate_alert_hash(self, anomaly: Dict) -> str:
        """
        生成警报哈希，用于去重
        
        Args:
            anomaly: 异常数据
            
        Returns:
            警报哈希
        """
        # 提取关键信息
        symbol = anomaly.get("symbol", "")
        anomaly_type = anomaly.get("type", "")
        
        if anomaly_type == "price":
            change_pct = anomaly.get("price_change_pct", 0)
            # 对价格变化进行分段，避免小幅度变化导致重复推送
            change_pct_rounded = round(change_pct / 5) * 5  # 按5%分段
            key_str = f"{symbol}_{anomaly_type}_{change_pct_rounded}_{int(time.time() / 3600)}"
        elif anomaly_type == "volume":
            change_pct = anomaly.get("volume_change_pct", 0)
            # 对交易量变化进行分段
            change_pct_rounded = round(change_pct / 20) * 20  # 按20%分段
            key_str = f"{symbol}_{anomaly_type}_{change_pct_rounded}_{int(time.time() / 3600)}"
        else:
            key_str = f"{symbol}_{anomaly_type}_{int(time.time() / 3600)}"
        
        # 生成哈希
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def is_duplicate_alert(self, anomaly: Dict) -> bool:
        """
        检查是否为重复警报
        
        Args:
            anomaly: 异常数据
            
        Returns:
            是否为重复警报
        """
        alert_hash = self._generate_alert_hash(anomaly)
        current_time = time.time()
        
        # 检查是否在缓存中且未过期
        if alert_hash in self.alert_cache:
            last_time = self.alert_cache[alert_hash]
            if current_time - last_time < self.dedup_window:
                logger.info(f"检测到重复警报: {anomaly.get('symbol')} {anomaly.get('type')}")
                return True
        
        # 更新缓存
        self.alert_cache[alert_hash] = current_time
        self._save_alert_history()
        
        return False
    
    def save_config(self, token: str, chat_id: str) -> bool:
        """
        保存Telegram配置到配置文件
        
        Args:
            token: Telegram Bot API令牌
            chat_id: 目标聊天ID
            
        Returns:
            保存是否成功
        """
        try:
            self.token = token
            self.chat_id = chat_id
            
            config = {
                "token": token,
                "chat_id": chat_id
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info("保存Telegram配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def is_configured(self) -> bool:
        """
        检查是否已配置Telegram
        
        Returns:
            是否已配置
        """
        return bool(self.token and self.chat_id)
    
    def test_connection(self) -> bool:
        """
        测试Telegram连接
        
        Returns:
            连接是否成功
        """
        if not self.is_configured():
            logger.error("Telegram未配置，无法测试连接")
            return False
        
        try:
            url = f"https://api.telegram.org/bot{self.token}/getMe"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get("ok"):
                logger.info(f"Telegram连接测试成功，Bot名称: {data.get('result', {}).get('username')}")
                return True
            else:
                logger.error(f"Telegram连接测试失败: {data.get('description')}")
                return False
        except Exception as e:
            logger.error(f"Telegram连接测试失败: {str(e)}")
            return False
    
    def format_alert_message(self, anomaly: Dict) -> str:
        """
        格式化警报消息
        
        Args:
            anomaly: 异常数据
            
        Returns:
            格式化后的消息
        """
        try:
            # 获取异常类型和币种
            anomaly_type = anomaly.get("type", "unknown")
            symbol = anomaly.get("symbol", "未知币种")
            
            # 构建消息标题
            if anomaly_type == "price":
                change_pct = anomaly.get("price_change_pct", 0)
                direction = "上涨" if change_pct > 0 else "下跌"
                title = f"🚨 价格异动警报: {symbol} {direction} {abs(change_pct):.2f}%"
            elif anomaly_type == "volume":
                change_pct = anomaly.get("volume_change_pct", 0)
                title = f"📊 交易量异动警报: {symbol} 增加 {change_pct:.2f}%"
            else:
                title = f"⚠️ 异常警报: {symbol}"
            
            # 构建消息内容
            message_parts = [title, ""]
            
            # 添加价格信息
            if anomaly_type == "price":
                current_price = anomaly.get("current_price", 0)
                reference_price = anomaly.get("reference_price", 0)
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"参考价格: {reference_price}")
                message_parts.append(f"变化幅度: {change_pct:.2f}%")
                
                # 添加交易量信息
                volume_24h = anomaly.get("volume_24h", 0)
                message_parts.append(f"24小时交易量: {volume_24h}")
            
            # 添加交易量信息
            elif anomaly_type == "volume":
                current_volume = anomaly.get("current_volume", 0)
                reference_volume = anomaly.get("reference_volume", 0)
                current_price = anomaly.get("current_price", 0)
                
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"当前交易量: {current_volume}")
                message_parts.append(f"参考交易量: {reference_volume}")
                message_parts.append(f"交易量增加: {change_pct:.2f}%")
            
            # 添加检测时间
            detected_at = anomaly.get("detected_at", datetime.now().isoformat())
            try:
                # 尝试将ISO格式转换为更易读的格式
                dt = datetime.fromisoformat(detected_at)
                formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                formatted_time = detected_at
            
            message_parts.append("")
            message_parts.append(f"检测时间: {formatted_time}")
            
            # 添加交易所链接
            message_parts.append("")
            message_parts.append(f"🔗 [在Gate.io上查看](https://www.gate.io/trade/{symbol})")
            
            # 合并消息
            return "\n".join(message_parts)
        
        except Exception as e:
            logger.error(f"格式化警报消息失败: {str(e)}")
            return f"异常警报: {anomaly.get('symbol', '未知币种')}"
    
    def send_message(self, message: str, parse_mode: str = "Markdown") -> bool:
        """
        发送Telegram消息
        
        Args:
            message: 消息内容
            parse_mode: 解析模式（Markdown或HTML）
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.error("Telegram未配置，无法发送消息")
            return False
        
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": parse_mode,
            "disable_web_page_preview": False
        }
        
        for attempt in range(self.max_retries):
            try:
                response = requests.post(url, json=payload, timeout=10)
                response.raise_for_status()
                data = response.json()
                
                if data.get("ok"):
                    logger.info("Telegram消息发送成功")
                    return True
                else:
                    logger.warning(f"Telegram消息发送失败: {data.get('description')}")
                    
                    # 如果是解析模式错误，尝试使用纯文本重新发送
                    if "parse_mode" in data.get("description", "").lower():
                        logger.info("尝试使用纯文本重新发送")
                        return self.send_message(message, parse_mode=None)
                    
                    if attempt < self.max_retries - 1:
                        time.sleep(self.retry_delay * (attempt + 1))
                    else:
                        return False
            
            except requests.exceptions.RequestException as e:
                logger.warning(f"Telegram消息发送失败 (尝试 {attempt+1}/{self.max_retries}): {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                else:
                    logger.error(f"Telegram消息发送最终失败: {str(e)}")
                    return False
        
        return False
    
    def send_photo(self, photo_path: str, caption: str = None, parse_mode: str = "Markdown") -> bool:
        """
        发送图片
        
        Args:
            photo_path: 图片路径
            caption: 图片说明
            parse_mode: 解析模式（Markdown或HTML）
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.error("Telegram未配置，无法发送图片")
            return False
        
        if not os.path.exists(photo_path):
            logger.error(f"图片文件不存在: {photo_path}")
            return False
        
        url = f"https://api.telegram.org/bot{self.token}/sendPhoto"
        
        for attempt in range(self.max_retries):
            try:
                with open(photo_path, 'rb') as photo:
                    files = {'photo': photo}
                    payload = {
                        "chat_id": self.chat_id
                    }
                    
                    if caption:
                        payload["caption"] = caption
                        if parse_mode:
                            payload["parse_mode"] = parse_mode
                    
                    response = requests.post(url, data=payload, files=files, timeout=30)
                    response.raise_for_status()
                    data = response.json()
                    
                    if data.get("ok"):
                        logger.info(f"Telegram图片发送成功: {photo_path}")
                        return True
                    else:
                        logger.warning(f"Telegram图片发送失败: {data.get('description')}")
                        
                        # 如果是解析模式错误，尝试使用纯文本重新发送
                        if caption and parse_mode and "parse_mode" in data.get("description", "").lower():
                            logger.info("尝试使用纯文本重新发送图片")
                            return self.send_photo(photo_path, caption, parse_mode=None)
                        
                        if attempt < self.max_retries - 1:
                            time.sleep(self.retry_delay * (attempt + 1))
                        else:
                            return False
            
            except Exception as e:
                logger.warning(f"Telegram图片发送失败 (尝试 {attempt+1}/{self.max_retries}): {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                else:
                    logger.error(f"Telegram图片发送最终失败: {str(e)}")
                    return False
        
        return False
    
    def send_anomaly_alert_with_chart(self, anomaly: Dict, price_data: List[Dict] = None) -> bool:
        """
        发送带图表的异常警报
        
        Args:
            anomaly: 异常数据
            price_data: 价格历史数据，用于生成图表
            
        Returns:
            发送是否成功
        """
        # 检查是否为重复警报
        if self.is_duplicate_alert(anomaly):
            logger.info(f"跳过重复警报: {anomaly.get('symbol')}")
            return False
        
        # 获取异常类型和币种
        anomaly_type = anomaly.get("type", "unknown")
        symbol = anomaly.get("symbol", "未知币种")
        
        # 格式化警报消息
        message = self.format_alert_message(anomaly)
        
        # 生成图表
        chart_path = None
        if anomaly_type == "price" and price_data:
            chart_path = self.chart_generator.generate_price_chart(symbol, price_data)
        elif anomaly_type == "price":
            chart_path = self.chart_generator.generate_price_change_chart(
                symbol,
                anomaly.get("current_price", 0),
                anomaly.get("reference_price", 0)
            )
        elif anomaly_type == "volume":
            chart_path = self.chart_generator.generate_volume_chart(
                symbol,
                anomaly.get("current_volume", 0),
                anomaly.get("reference_volume", 0)
            )
        
        # 发送警报
        if chart_path:
            # 如果有图表，发送图片消息
            return self.send_photo(chart_path, caption=message)
        else:
            # 如果没有图表，发送文本消息
            return self.send_message(message)
    
    def send_batch_alerts_with_charts(self, anomalies: List[Dict], price_data_dict: Dict = None, max_batch: int = 5) -> int:
        """
        批量发送带图表的异常警报
        
        Args:
            anomalies: 异常列表
            price_data_dict: 价格历史数据字典，格式为{symbol: price_data}
            max_batch: 最大批量发送数量
            
        Returns:
            成功发送的数量
        """
        if not anomalies:
            return 0
        
        # 过滤重复警报
        filtered_anomalies = []
        for anomaly in anomalies:
            if not self.is_duplicate_alert(anomaly):
                filtered_anomalies.append(anomaly)
        
        # 限制批量发送数量
        anomalies_to_send = filtered_anomalies[:max_batch]
        
        success_count = 0
        for anomaly in anomalies_to_send:
            symbol = anomaly.get("symbol")
            price_data = price_data_dict.get(symbol) if price_data_dict else None
            
            if self.send_anomaly_alert_with_chart(anomaly, price_data):
                success_count += 1
                # 添加短暂延迟，避免触发Telegram限流
                time.sleep(1)
        
        logger.info(f"批量发送异常警报完成，成功: {success_count}/{len(anomalies_to_send)}")
        return success_count


# 回调函数，用于与异常检测模块集成
def enhanced_telegram_alert_callback(anomalies: List[Dict], price_data_dict: Dict = None) -> None:
    """
    增强版Telegram警报回调函数
    
    Args:
        anomalies: 异常列表
        price_data_dict: 价格历史数据字典，格式为{symbol: price_data}
    """
    alerter = EnhancedTelegramAlerter()
    if not alerter.is_configured():
        logger.warning("Telegram未配置，无法发送警报")
        return
    
    success_count = alerter.send_batch_alerts_with_charts(anomalies, price_data_dict)
    logger.info(f"增强版Telegram警报回调完成，成功发送: {success_count}/{len(anomalies)}")


if __name__ == "__main__":
    # 测试代码
    
    # 创建增强版Telegram警报推送器
    alerter = EnhancedTelegramAlerter()
    
    # 提示用户配置Telegram
    print("请配置Telegram Bot:")
    token = input("请输入Bot Token: ")
    chat_id = input("请输入Chat ID: ")
    
    # 保存配置
    alerter.save_config(token, chat_id)
    
    # 测试连接
    print("\n测试Telegram连接...")
    if alerter.test_connection():
        print("连接测试成功!")
        
        # 发送测试消息
        print("\n发送测试消息...")
        test_message = "这是一条测试消息，来自Gate.io加密货币异动监控系统增强版。"
        if alerter.send_message(test_message):
            print("测试消息发送成功!")
        else:
            print("测试消息发送失败!")
        
        # 测试异常警报格式化
        print("\n测试异常警报格式化...")
        test_anomaly = {
            "type": "price",
            "symbol": "BTC_USDT",
            "current_price": 50000,
            "reference_price": 45000,
            "price_change_pct": 11.11,
            "volume_24h": 1000000,
            "detected_at": datetime.now().isoformat()
        }
        
        formatted_message = alerter.format_alert_message(test_anomaly)
        print("格式化后的消息:")
        print(formatted_message)
        
        # 生成测试数据
        print("\n生成测试价格数据...")
        now = datetime.now()
        test_data = []
        for i in range(24):
            timestamp = (now - timedelta(hours=24-i)).isoformat()
            price = 45000 + 5000 * (i / 24)
            volume = 1000000 + 500000 * (i / 24)
            test_data.append({
                "timestamp": timestamp,
                "price": price,
                "volume_24h": volume
            })
        
        # 发送测试异常警报（带图表）
        print("\n发送测试异常警报（带图表）...")
        if alerter.send_anomaly_alert_with_chart(test_anomaly, test_data):
            print("测试异常警报发送成功!")
        else:
            print("测试异常警报发送失败!")
        
        # 测试重复警报检测
        print("\n测试重复警报检测...")
        if alerter.is_duplicate_alert(test_anomaly):
            print("重复警报检测成功!")
        else:
            print("重复警报检测失败!")
    else:
        print("连接测试失败，请检查Token和Chat ID是否正确。")
    
    print("\n测试完成!")
