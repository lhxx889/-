"""
Gate.io加密货币异动监控系统 - 主程序
集成所有增强功能的入口点
"""

import logging
import time
import json
import os
import sys
import signal
import argparse
from datetime import datetime

# 导入自定义模块
from src.data_collector import GateioDataCollector, DataMonitor
from src.anomaly_detector import AnomalyDetector, AnomalyMonitor
from src.enhanced_telegram_alerter import EnhancedTelegramAlerter, enhanced_telegram_alert_callback
from src.enhanced_coin_info import EnhancedCoinInfo
from src.enhanced_reason_analyzer import EnhancedReasonAnalyzer
from src.chart_generator import ChartGenerator

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("main")

# 全局变量
config = {}
running = True

def load_config(config_file="config.json"):
    """加载配置文件"""
    global config
    
    try:
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
            logger.info(f"成功加载配置文件: {config_file}")
        else:
            # 使用默认配置
            config = {
                "db_path": "crypto_data.db",
                "check_interval": 50,
                "price_change_threshold": 30.0,
                "volume_change_threshold": 200.0,
                "enable_charts": True,
                "enable_enhanced_info": True,
                "max_alerts_per_batch": 5,
                "dedup_window": 3600
            }
            logger.warning(f"配置文件不存在，使用默认配置")
            
            # 保存默认配置
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=4)
            logger.info(f"已创建默认配置文件: {config_file}")
    except Exception as e:
        logger.error(f"加载配置文件失败: {str(e)}")
        # 使用默认配置
        config = {
            "db_path": "crypto_data.db",
            "check_interval": 50,
            "price_change_threshold": 30.0,
            "volume_change_threshold": 200.0,
            "enable_charts": True,
            "enable_enhanced_info": True,
            "max_alerts_per_batch": 5,
            "dedup_window": 3600
        }

def setup_telegram():
    """设置Telegram配置"""
    alerter = EnhancedTelegramAlerter()
    
    if alerter.is_configured():
        print("\nTelegram已配置。是否要重新配置？")
        choice = input("输入 'y' 重新配置，其他键跳过: ")
        if choice.lower() != 'y':
            return
    
    print("\n请按照以下步骤获取Telegram Bot Token和Chat ID:")
    print("1. 在Telegram中搜索 @BotFather 并开始对话")
    print("2. 发送 /newbot 命令创建新机器人")
    print("3. 按照提示设置机器人名称和用户名")
    print("4. 获取API Token")
    print("5. 将机器人添加到目标聊天中")
    print("6. 获取Chat ID (可以使用 @get_id_bot 或其他方法)")
    print("")
    
    token = input("请输入Telegram Bot Token: ")
    chat_id = input("请输入Chat ID: ")
    
    alerter.save_config(token, chat_id)
    
    # 测试连接
    print("\n测试Telegram连接...")
    if alerter.test_connection():
        print("连接测试成功!")
        
        # 发送测试消息
        print("\n发送测试消息...")
        test_message = "这是一条测试消息，来自Gate.io加密货币异动监控系统。"
        if alerter.send_message(test_message):
            print("测试消息发送成功!")
        else:
            print("测试消息发送失败!")
    else:
        print("连接测试失败，请检查Token和Chat ID是否正确。")

def setup_api():
    """设置API配置"""
    print("\n设置API配置 (可选)")
    print("以下API密钥是可选的，如果没有可以留空:")
    
    cryptocompare_key = input("请输入CryptoCompare API密钥 (可选): ")
    cmc_key = input("请输入CoinMarketCap API密钥 (可选): ")
    
    # 读取现有配置（如果存在）
    config_file = "api_config.json"
    api_config = {}
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                api_config = json.load(f)
        except:
            pass
    
    # 更新配置
    if cryptocompare_key:
        api_config["cryptocompare_api_key"] = cryptocompare_key
    if cmc_key:
        api_config["cmc_api_key"] = cmc_key
    
    # 保存配置
    try:
        with open(config_file, 'w') as f:
            json.dump(api_config, f, indent=4)
        print("API配置已保存")
    except Exception as e:
        print(f"保存API配置失败: {str(e)}")

def setup_monitor_params():
    """设置监控参数"""
    global config
    
    print("\n设置监控参数")
    
    # 显示当前配置
    print(f"当前配置:")
    print(f"- 检查间隔: {config.get('check_interval', 50)}秒")
    print(f"- 价格变化阈值: {config.get('price_change_threshold', 30.0)}%")
    print(f"- 交易量变化阈值: {config.get('volume_change_threshold', 200.0)}%")
    print("")
    
    # 获取新配置
    try:
        interval = input(f"请输入检查间隔(秒) [{config.get('check_interval', 50)}]: ")
        price_threshold = input(f"请输入价格变化阈值(%) [{config.get('price_change_threshold', 30.0)}]: ")
        volume_threshold = input(f"请输入交易量变化阈值(%) [{config.get('volume_change_threshold', 200.0)}]: ")
        
        # 使用默认值如果用户没有输入
        if interval:
            config["check_interval"] = int(interval)
        if price_threshold:
            config["price_change_threshold"] = float(price_threshold)
        if volume_threshold:
            config["volume_change_threshold"] = float(volume_threshold)
        
        # 保存配置
        with open("config.json", 'w') as f:
            json.dump(config, f, indent=4)
        
        print("监控参数已更新")
    except Exception as e:
        print(f"设置监控参数失败: {str(e)}")

def setup_wizard():
    """设置向导"""
    print("\n欢迎使用Gate.io加密货币异动监控系统设置向导")
    
    # 加载配置
    load_config()
    
    # 设置Telegram
    setup_telegram()
    
    # 设置API
    setup_api()
    
    # 设置监控参数
    setup_monitor_params()
    
    print("\n设置完成!")

def signal_handler(sig, frame):
    """信号处理函数"""
    global running
    logger.info("收到中断信号，准备停止...")
    running = False

def enhanced_anomaly_callback(anomalies):
    """增强版异常回调函数"""
    if not anomalies:
        return
    
    logger.info(f"检测到{len(anomalies)}个异常，准备处理...")
    
    try:
        # 初始化组件
        collector = GateioDataCollector(config.get("db_path", "crypto_data.db"))
        alerter = EnhancedTelegramAlerter(dedup_window=config.get("dedup_window", 3600))
        reason_analyzer = EnhancedReasonAnalyzer()
        
        # 获取价格历史数据
        price_data_dict = {}
        for anomaly in anomalies:
            symbol = anomaly.get("symbol")
            if symbol:
                price_data = collector.get_historical_price_data(symbol, 24)
                if price_data:
                    price_data_dict[symbol] = price_data
        
        # 处理每个异常
        for anomaly in anomalies:
            symbol = anomaly.get("symbol")
            
            # 跳过重复警报
            if alerter.is_duplicate_alert(anomaly):
                logger.info(f"跳过重复警报: {symbol}")
                continue
            
            # 发送异常警报（带图表）
            if config.get("enable_charts", True):
                price_data = price_data_dict.get(symbol, [])
                alerter.send_anomaly_alert_with_chart(anomaly, price_data)
            else:
                alerter.send_anomaly_alert(anomaly)
            
            # 分析异动原因
            if config.get("enable_enhanced_info", True):
                try:
                    price_data = price_data_dict.get(symbol, [])
                    analysis = reason_analyzer.analyze_anomaly_reasons(anomaly, price_data)
                    analysis_message = reason_analyzer.format_analysis_message(analysis)
                    
                    # 发送分析结果
                    alerter.send_message(analysis_message)
                except Exception as e:
                    logger.error(f"分析异动原因失败: {str(e)}")
            
            # 添加短暂延迟，避免触发Telegram限流
            time.sleep(1)
    
    except Exception as e:
        logger.error(f"处理异常回调时出错: {str(e)}")

def run_monitor():
    """运行监控"""
    global running
    
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 加载配置
    load_config()
    
    logger.info("初始化监控系统...")
    
    try:
        # 创建数据采集器
        collector = GateioDataCollector(config.get("db_path", "crypto_data.db"))
        
        # 创建异常检测器
        detector = AnomalyDetector(
            collector,
            price_change_threshold=config.get("price_change_threshold", 30.0),
            volume_change_threshold=config.get("volume_change_threshold", 200.0)
        )
        
        # 创建异常监控器
        anomaly_monitor = AnomalyMonitor(
            detector,
            check_interval=config.get("check_interval", 50)
        )
        
        # 注册增强版回调
        anomaly_monitor.register_alert_callback(enhanced_anomaly_callback)
        
        # 创建数据监控器
        data_monitor = DataMonitor(
            collector,
            interval=config.get("check_interval", 50)
        )
        
        # 保存PID
        with open("crypto_monitor.pid", "w") as f:
            f.write(str(os.getpid()))
        
        # 启动数据更新
        logger.info("启动数据更新...")
        collector.update_data()
        
        # 启动监控
        logger.info("启动监控...")
        running = True
        
        # 主循环
        while running:
            # 更新数据
            collector.update_data()
            
            # 检测异常
            anomalies = detector.detect_all_anomalies()
            
            # 处理异常
            if anomalies:
                enhanced_anomaly_callback(anomalies)
            
            # 等待下一次检查
            logger.info(f"等待{config.get('check_interval', 50)}秒后进行下一次检查")
            
            # 分段等待，以便能够及时响应中断
            wait_time = config.get("check_interval", 50)
            for _ in range(wait_time):
                if not running:
                    break
                time.sleep(1)
    
    except Exception as e:
        logger.error(f"监控过程中发生错误: {str(e)}")
    
    finally:
        # 清理PID文件
        if os.path.exists("crypto_monitor.pid"):
            os.remove("crypto_monitor.pid")
        
        logger.info("监控系统已停止")

def main():
    """主函数"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Gate.io加密货币异动监控系统")
    parser.add_argument("--setup", action="store_true", help="运行设置向导")
    args = parser.parse_args()
    
    # 如果指定了--setup参数，运行设置向导
    if args.setup:
        setup_wizard()
    else:
        # 否则运行监控
        run_monitor()

if __name__ == "__main__":
    main()
