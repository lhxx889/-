#!/bin/bash

# Gate.io加密货币异动监控系统一键安装脚本

echo "====================================================="
echo "  Gate.io加密货币异动监控系统一键安装脚本"
echo "====================================================="
echo ""

# 检查Python版本
echo "检查Python环境..."
if command -v python3 &>/dev/null; then
    PYTHON_CMD=python3
elif command -v python &>/dev/null; then
    PYTHON_CMD=python
else
    echo "错误: 未找到Python。请先安装Python 3.8或更高版本。"
    exit 1
fi

# 检查Python版本是否>=3.8
PYTHON_VERSION=$($PYTHON_CMD -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]); then
    echo "错误: Python版本必须是3.8或更高版本。当前版本: $PYTHON_VERSION"
    exit 1
fi

echo "Python版本检查通过: $PYTHON_VERSION"
echo ""

# 创建虚拟环境
echo "创建Python虚拟环境..."
$PYTHON_CMD -m venv venv
if [ $? -ne 0 ]; then
    echo "错误: 创建虚拟环境失败。请确保已安装venv模块。"
    exit 1
fi

# 激活虚拟环境
echo "激活虚拟环境..."
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
else
    echo "错误: 无法找到虚拟环境激活脚本。"
    exit 1
fi

# 安装依赖
echo "安装依赖库..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "错误: 安装依赖库失败。"
    exit 1
fi

echo "依赖库安装完成。"
echo ""

# 运行设置向导
echo "现在将运行设置向导，请按照提示配置系统..."
echo ""
python main.py --setup

# 创建启动脚本
echo "创建启动脚本..."
cat > start_monitor.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
else
    echo "错误: 无法找到虚拟环境激活脚本。"
    exit 1
fi

# 启动监控系统
python main.py
EOF

chmod +x start_monitor.sh

# 创建服务文件（如果是Linux系统）
if [ "$(uname)" == "Linux" ]; then
    echo "检测到Linux系统，创建systemd服务文件..."
    
    # 获取当前目录的绝对路径
    INSTALL_DIR=$(pwd)
    
    # 创建服务文件
    cat > crypto_monitor.service << EOF
[Unit]
Description=Gate.io Crypto Monitor Service
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/main.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    echo "服务文件已创建: $INSTALL_DIR/crypto_monitor.service"
    echo "要安装为系统服务，请运行:"
    echo "sudo cp $INSTALL_DIR/crypto_monitor.service /etc/systemd/system/"
    echo "sudo systemctl daemon-reload"
    echo "sudo systemctl enable crypto_monitor.service"
    echo "sudo systemctl start crypto_monitor.service"
    echo ""
fi

echo "====================================================="
echo "  安装完成！"
echo "====================================================="
echo ""
echo "要启动监控系统，请运行:"
echo "./start_monitor.sh"
echo ""
echo "如需帮助，请参阅README.md文件。"
echo ""
