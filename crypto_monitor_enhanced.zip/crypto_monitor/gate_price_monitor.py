#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 币种价格和涨跌幅监控脚本
"""

import requests
import json
import time
import logging
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("gate_monitor.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("gate_monitor")

# 配置参数
GATE_BASE_URL = "https://api.gateio.ws/api/v4"
TICKER_ENDPOINT = "/spot/tickers"
PRICE_CHANGE_THRESHOLD = 5.0  # 涨跌幅阈值，百分比
CHECK_INTERVAL = 300  # 检查间隔，秒

# 存储上次检查的价格，用于比较变化
last_prices = {}

def fetch_gate_tickers():
    """
    获取Gate.io所有交易对的价格和涨跌幅数据
    """
    try:
        url = f"{GATE_BASE_URL}{TICKER_ENDPOINT}"
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()  # 如果请求失败，抛出异常
        
        tickers = response.json()
        logger.info(f"成功获取Gate.io {len(tickers)} 个交易对数据")
        return tickers
    
    except requests.exceptions.RequestException as e:
        logger.error(f"获取Gate.io数据失败: {e}")
        return []

def process_gate_tickers(tickers):
    """
    处理Gate.io的ticker数据，识别超过阈值的价格变动
    """
    significant_changes = []
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    for ticker in tickers:
        symbol = ticker['currency_pair']
        price = float(ticker['last'])
        
        # Gate.io的API返回的change_percentage格式为"-8.91"（字符串）
        try:
            price_change_percent = float(ticker['change_percentage'])
        except (ValueError, KeyError):
            # 如果无法获取涨跌幅，则跳过
            continue
        
        # 检查是否超过阈值
        if abs(price_change_percent) >= PRICE_CHANGE_THRESHOLD:
            change_direction = "上涨" if price_change_percent > 0 else "下跌"
            significant_changes.append({
                "exchange": "Gate.io",
                "symbol": symbol,
                "price": price,
                "change_percent": price_change_percent,
                "direction": change_direction,
                "time": current_time
            })
            
            logger.info(f"Gate.io - {symbol} {change_direction} {abs(price_change_percent):.2f}%, 当前价格: {price}")
        
        # 更新上次价格记录
        last_prices[f"gate_{symbol}"] = price
    
    return significant_changes

def save_significant_changes(changes):
    """
    保存显著价格变动到文件
    """
    if not changes:
        return
    
    try:
        # 读取现有数据
        try:
            with open("significant_price_changes.json", "r") as f:
                existing_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing_data = []
        
        # 添加新数据
        existing_data.extend(changes)
        
        # 写回文件
        with open("significant_price_changes.json", "w") as f:
            json.dump(existing_data, f, indent=2)
        
        logger.info(f"已保存 {len(changes)} 条显著价格变动记录")
    
    except Exception as e:
        logger.error(f"保存价格变动记录失败: {e}")

def monitor_gate_prices():
    """
    监控Gate.io价格变动的主函数
    """
    logger.info("开始监控Gate.io价格变动...")
    
    try:
        # 获取ticker数据
        tickers = fetch_gate_tickers()
        
        # 处理数据
        if tickers:
            significant_changes = process_gate_tickers(tickers)
            
            # 保存显著变动
            save_significant_changes(significant_changes)
            
            return len(significant_changes)
    
    except Exception as e:
        logger.error(f"监控过程中发生错误: {e}")
        return 0

if __name__ == "__main__":
    try:
        while True:
            changes_count = monitor_gate_prices()
            logger.info(f"本次监控发现 {changes_count} 个显著价格变动")
            logger.info(f"等待 {CHECK_INTERVAL} 秒后进行下一次检查...")
            time.sleep(CHECK_INTERVAL)
    
    except KeyboardInterrupt:
        logger.info("监控程序被手动终止")
    except Exception as e:
        logger.error(f"程序异常终止: {e}")
