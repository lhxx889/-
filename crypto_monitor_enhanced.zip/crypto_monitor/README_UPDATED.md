# 加密货币监控系统

## 概述

这是一个功能强大的加密货币监控系统，可以监控Binance.US和Gate.io的加密货币价格变动，扫描交易所公告，并通过Telegram推送通知。系统还集成了代理功能，支持VLESS代理配置和管理。

## 主要功能

### 加密货币监控
- 监控Binance.US和Gate.io的加密货币价格变动
- 扫描交易所公告
- 支持Telegram推送通知
- 提供交互式配置菜单

### 代理管理
- 内置代理服务（基于sing-box）
- 支持VLESS代理协议
- 完整的VLESS节点管理功能
- 支持从VLESS链接导入节点
- 支持导出节点为VLESS链接

## 安装指南

### 系统要求
- Python 3.6+
- 必要的Python库：requests, beautifulsoup4
- Linux或macOS系统（推荐Ubuntu/Debian）

### 安装步骤

1. 安装必要的Python库：
```bash
apt update
apt install -y python3-requests python3-bs4
```

或者使用pip：
```bash
pip3 install requests beautifulsoup4
```

2. 解压安装包：
```bash
unzip crypto_monitor_with_vless_manager.zip
cd crypto_monitor
```

3. 确保脚本有执行权限：
```bash
chmod +x *.py scripts/*.sh scripts/*.py
```

## 使用指南

### 启动监控系统
```bash
python3 crypto_monitor_menu.py
```

### 菜单选项
1. **启动/停止监控** - 开始或停止监控服务
2. **配置Telegram推送** - 设置Telegram机器人通知
3. **设置价格监控参数** - 调整价格监控阈值和间隔
4. **设置公告扫描参数** - 配置公告扫描功能
5. **配置代理设置** - 设置网络代理
6. **快捷配置代理** - 一键配置代理服务
7. **查看当前配置** - 显示所有配置项
8. **查看监控日志** - 查看运行日志
9. **退出程序** - 退出监控系统

### 使用VLESS节点管理器
```bash
./scripts/vless_manager.sh
```

#### VLESS管理器菜单选项
1. **添加新节点** - 手动添加一个新的VLESS节点
2. **从VLESS链接导入节点** - 通过VLESS链接快速导入节点
3. **删除节点** - 删除一个现有节点
4. **修改节点** - 修改现有节点的配置
5. **查看所有节点** - 显示所有已保存的节点
6. **导出节点为VLESS链接** - 将节点导出为可分享的VLESS链接
7. **测试节点连接** - 测试节点是否可以正常连接
8. **应用节点配置** - 将选定节点的配置应用到系统
0. **退出** - 退出管理器

### 从VLESS链接导入节点
1. 运行VLESS节点管理器
2. 选择"2. 从VLESS链接导入节点"
3. 粘贴VLESS链接，例如：
   ```
   vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态
   ```
4. 确认添加节点

## 配置指南

### Telegram通知设置
要启用Telegram通知，需要：
1. 创建Telegram机器人并获取Token
2. 获取您的Telegram聊天ID
3. 在菜单中选择"2. 配置Telegram推送"
4. 输入Token和聊天ID
5. 启用Telegram推送功能

### 代理配置
如果需要使用代理，可以：
- 在菜单中选择"5. 配置代理设置"手动配置
- 或选择"6. 快捷配置代理"使用自动配置脚本
- 代理配置后，确保在主菜单中启用代理功能

## 常见问题解决

### 程序无法启动
- 确保Python和所需库已正确安装
- 检查脚本是否有执行权限

### API请求限制错误
- 增加价格检查间隔，至少设置为5分钟

### 代理连接问题
- 检查代理配置和网络连接
- 使用VLESS管理器测试节点连接

### Telegram推送失败
- 验证Token和聊天ID是否正确

### sing-box服务启动失败
如果遇到"sing-box.service: Failed with result 'exec'"错误，请运行：
```bash
./scripts/install_proxy.sh
```

## 更新日志

请参考 `BUGFIX_CHANGELOG.md` 文件了解最新更新和修复。

## 详细文档

- `VLESS_MANAGER_GUIDE.md` - VLESS节点管理器使用指南
- `INSTALLATION_GUIDE.md` - 详细安装指南
- `QUICK_PROXY_GUIDE.md` - 快速代理配置指南

## 技术支持

如有任何问题或需要帮助，请查看相关日志文件：
- `proxy_manager.log` - 代理管理器日志
- `crypto_monitor.log` - 监控系统日志

