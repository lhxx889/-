#!/bin/bash
# 安装内置代理组件

# 检测系统类型
OS=$(uname -s)
ARCH=$(uname -m)

# 颜色输出
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}开始安装内置代理组件...${NC}"

# 检查是否有root权限
if [ "$EUID" -ne 0 ]; then
  echo -e "${YELLOW}注意: 未使用root权限运行，可能需要sudo来完成安装${NC}"
  USE_SUDO="sudo"
else
  USE_SUDO=""
fi

# 创建临时目录
TEMP_DIR=$(mktemp -d)
cd $TEMP_DIR || exit 1

# 下载sing-box
echo "下载sing-box安装脚本..."
if command -v curl &> /dev/null; then
  curl -s -L https://sing-box.app/install.sh -o install.sh
elif command -v wget &> /dev/null; then
  wget -q -O install.sh https://sing-box.app/install.sh
else
  echo -e "${RED}错误: 未找到curl或wget，无法下载安装脚本${NC}"
  exit 1
fi

# 添加执行权限
chmod +x install.sh

# 执行安装脚本
echo "执行安装脚本..."
$USE_SUDO bash install.sh

# 检查安装结果
if [ $? -ne 0 ]; then
  echo -e "${RED}sing-box安装失败，尝试手动下载二进制文件...${NC}"
  
  # 确定架构
  case $ARCH in
    x86_64)
      SING_ARCH="amd64"
      ;;
    amd64)
      SING_ARCH="amd64"
      ;;
    arm64)
      SING_ARCH="arm64"
      ;;
    aarch64)
      SING_ARCH="arm64"
      ;;
    *)
      SING_ARCH="amd64"
      ;;
  esac
  
  # 确定系统
  case $OS in
    Linux)
      SING_OS="linux"
      ;;
    Darwin)
      SING_OS="darwin"
      ;;
    *)
      echo -e "${RED}不支持的操作系统: $OS${NC}"
      exit 1
      ;;
  esac
  
  # 下载预编译二进制文件
  VERSION="1.7.0"
  DOWNLOAD_URL="https://github.com/SagerNet/sing-box/releases/download/v${VERSION}/sing-box-${VERSION}-${SING_OS}-${SING_ARCH}.tar.gz"
  
  echo "从 $DOWNLOAD_URL 下载预编译文件..."
  if command -v curl &> /dev/null; then
    curl -s -L "$DOWNLOAD_URL" -o sing-box.tar.gz
  elif command -v wget &> /dev/null; then
    wget -q -O sing-box.tar.gz "$DOWNLOAD_URL"
  fi
  
  # 解压文件
  mkdir -p extract
  tar -xzf sing-box.tar.gz -C extract
  
  # 查找sing-box二进制文件
  BINARY_PATH=""
  for file in $(find extract -name "sing-box"); do
    BINARY_PATH=$file
    break
  done
  
  if [ -z "$BINARY_PATH" ]; then
    echo -e "${RED}未找到sing-box二进制文件${NC}"
    exit 1
  fi
  
  # 安装二进制文件
  echo "安装sing-box二进制文件..."
  $USE_SUDO mkdir -p /usr/local/bin
  $USE_SUDO cp "$BINARY_PATH" /usr/local/bin/sing-box
  $USE_SUDO chmod +x /usr/local/bin/sing-box
fi

# 创建配置目录
echo "创建配置目录..."
$USE_SUDO mkdir -p /etc/sing-box

# 创建配置文件
echo "创建配置文件..."
$USE_SUDO cat > /etc/sing-box/config.json << 'EOF'
{
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "0.0.0.0",
      "listen_port": 1080
    },
    {
      "type": "http",
      "tag": "http-in",
      "listen": "0.0.0.0",
      "listen_port": 7890
    }
  ],
  "outbounds": [
    {
      "type": "vless",
      "tag": "vless-out",
      "server": "ty.fk69.top",
      "server_port": 2026,
      "uuid": "aa05ee3d-ea0f-49e5-8692-4c4f69797110",
      "flow": "xtls-rprx-vision",
      "tls": {
        "enabled": true,
        "server_name": "www.cloudflare.com",
        "utls": {
          "enabled": true,
          "fingerprint": "chrome"
        },
        "reality": {
          "enabled": true,
          "public_key": "8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY",
          "short_id": ""
        }
      }
    }
  ]
}
EOF

# 创建服务文件
if [ "$OS" = "Linux" ]; then
  echo "创建systemd服务文件..."
  $USE_SUDO cat > /etc/systemd/system/sing-box.service << EOF
[Unit]
Description=sing-box service
Documentation=https://sing-box.app
After=network.target nss-lookup.target

[Service]
ExecStart=/usr/local/bin/sing-box run -c /etc/sing-box/config.json
Restart=on-failure
RestartPreventExitStatus=23
LimitNPROC=10000
LimitNOFILE=1000000

[Install]
WantedBy=multi-user.target
EOF

  # 重新加载systemd配置
  echo "重新加载systemd配置..."
  $USE_SUDO systemctl daemon-reload
  
  # 启用服务
  echo "启用sing-box服务..."
  $USE_SUDO systemctl enable sing-box
  
  # 启动服务
  echo "启动sing-box服务..."
  $USE_SUDO systemctl restart sing-box
  
  # 检查服务状态
  echo "检查服务状态..."
  $USE_SUDO systemctl status sing-box
else
  # 对于macOS，直接启动服务
  echo "启动sing-box服务..."
  nohup /usr/local/bin/sing-box run -c /etc/sing-box/config.json > /dev/null 2>&1 &
fi

# 清理临时文件
cd - > /dev/null
rm -rf "$TEMP_DIR"

echo -e "${GREEN}内置代理安装完成！${NC}"
echo "SOCKS5代理: 127.0.0.1:1080"
echo "HTTP代理: 127.0.0.1:7890"
