#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VLESS节点管理工具
此脚本提供了命令行界面，用于管理VLESS节点配置。
功能包括：添加、编辑、删除、列出、测试和使用VLESS节点。
"""

import os
import sys
import json
import base64
import urllib.parse
import argparse
import subprocess
import re
import time
from urllib.parse import urlparse, parse_qs

# 配置文件路径
CONFIG_DIR = os.path.expanduser("~/.config/vless_manager")
NODES_FILE = os.path.join(CONFIG_DIR, "nodes.json")
CONFIG_TEMPLATE_FILE = os.path.join(CONFIG_DIR, "config_template.json")
SING_BOX_CONFIG_FILE = "/etc/sing-box/config.json"

# 确保配置目录存在
os.makedirs(CONFIG_DIR, exist_ok=True)

# 默认配置模板
DEFAULT_CONFIG_TEMPLATE = {
    "inbounds": [
        {
            "type": "socks",
            "tag": "socks-in",
            "listen": "0.0.0.0",
            "listen_port": 1080
        },
        {
            "type": "http",
            "tag": "http-in",
            "listen": "0.0.0.0",
            "listen_port": 7890
        }
    ],
    "outbounds": [
        {
            "type": "vless",
            "tag": "vless-out",
            "server": "",
            "server_port": 0,
            "uuid": "",
            "flow": "",
            "tls": {
                "enabled": True,
                "server_name": "",
                "utls": {
                    "enabled": True,
                    "fingerprint": ""
                },
                "reality": {
                    "enabled": True,
                    "public_key": "",
                    "short_id": ""
                }
            }
        }
    ],
    "route": {
        "rules": [
            {
                "domain": [
                    "geosite:category-ads-all"
                ],
                "outbound": "block"
            },
            {
                "geoip": [
                    "private"
                ],
                "outbound": "direct"
            }
        ],
        "final": "vless-out"
    }
}

def load_nodes():
    """加载节点配置"""
    if not os.path.exists(NODES_FILE):
        return {}
    
    try:
        with open(NODES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        print("错误：节点配置文件格式不正确")
        return {}
    except Exception as e:
        print(f"错误：无法加载节点配置文件 - {e}")
        return {}

def save_nodes(nodes):
    """保存节点配置"""
    try:
        with open(NODES_FILE, 'w', encoding='utf-8') as f:
            json.dump(nodes, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"错误：无法保存节点配置文件 - {e}")
        return False

def load_config_template():
    """加载配置模板"""
    if not os.path.exists(CONFIG_TEMPLATE_FILE):
        # 创建默认配置模板
        with open(CONFIG_TEMPLATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(DEFAULT_CONFIG_TEMPLATE, f, ensure_ascii=False, indent=2)
        return DEFAULT_CONFIG_TEMPLATE
    
    try:
        with open(CONFIG_TEMPLATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"错误：无法加载配置模板 - {e}")
        return DEFAULT_CONFIG_TEMPLATE

def parse_vless_link(link):
    """解析VLESS链接"""
    if not link.startswith("vless://"):
        print("错误：不是有效的VLESS链接")
        return None
    
    try:
        # 移除协议前缀
        link = link[8:]
        
        # 分离用户信息和服务器信息
        if '@' not in link:
            print("错误：VLESS链接格式不正确")
            return None
        
        user_info, server_info = link.split('@', 1)
        
        # 分离服务器地址和端口
        if ':' not in server_info:
            print("错误：VLESS链接中没有指定端口")
            return None
        
        server_parts = server_info.split(':', 1)
        server = server_parts[0]
        
        # 分离端口和参数
        port_and_params = server_parts[1]
        if '/' in port_and_params:
            port, params = port_and_params.split('/', 1)
            params = '/' + params
        else:
            port = port_and_params
            params = ''
        
        # 解析参数
        query_params = {}
        if '?' in params:
            params_part = params.split('?', 1)[1]
            if '#' in params_part:
                params_part = params_part.split('#', 1)[0]
            
            for param in params_part.split('&'):
                if '=' in param:
                    key, value = param.split('=', 1)
                    query_params[key] = urllib.parse.unquote(value)
        
        # 解析备注
        remark = ""
        if '#' in link:
            remark = urllib.parse.unquote(link.split('#', 1)[1])
        
        # 创建节点配置
        node = {
            "uuid": user_info,
            "server": server,
            "server_port": int(port),
            "remark": remark,
            "type": query_params.get("type", "tcp"),
            "encryption": query_params.get("encryption", "none"),
            "flow": query_params.get("flow", ""),
            "sni": query_params.get("sni", ""),
            "fp": query_params.get("fp", ""),
            "security": query_params.get("security", ""),
            "pbk": query_params.get("pbk", ""),
            "sid": query_params.get("sid", "")
        }
        
        return node
    except Exception as e:
        print(f"错误：解析VLESS链接失败 - {e}")
        return None

def generate_vless_link(node):
    """生成VLESS链接"""
    try:
        # 构建基本链接
        link = f"vless://{node['uuid']}@{node['server']}:{node['server_port']}/"
        
        # 添加参数
        params = []
        if node.get("type"):
            params.append(f"type={node['type']}")
        if node.get("encryption"):
            params.append(f"encryption={node['encryption']}")
        if node.get("flow"):
            params.append(f"flow={node['flow']}")
        if node.get("sni"):
            params.append(f"sni={node['sni']}")
        if node.get("fp"):
            params.append(f"fp={node['fp']}")
        if node.get("security"):
            params.append(f"security={node['security']}")
        if node.get("pbk"):
            params.append(f"pbk={node['pbk']}")
        if node.get("sid"):
            params.append(f"sid={node['sid']}")
        
        if params:
            link += "?" + "&".join(params)
        
        # 添加备注
        if node.get("remark"):
            link += "#" + urllib.parse.quote(node["remark"])
        
        return link
    except Exception as e:
        print(f"错误：生成VLESS链接失败 - {e}")
        return None

def add_node(args):
    """添加节点"""
    nodes = load_nodes()
    
    if args.link:
        # 从链接添加节点
        node = parse_vless_link(args.link)
        if not node:
            return False
        
        # 使用提供的名称或备注作为节点名称
        node_name = args.name or node.get("remark") or f"节点_{len(nodes) + 1}"
    else:
        # 手动添加节点
        if not args.server or not args.port or not args.uuid:
            print("错误：添加节点需要指定服务器地址、端口和UUID")
            return False
        
        node_name = args.name or f"节点_{len(nodes) + 1}"
        node = {
            "uuid": args.uuid,
            "server": args.server,
            "server_port": args.port,
            "remark": args.remark or node_name,
            "type": args.type or "tcp",
            "encryption": args.encryption or "none",
            "flow": args.flow or "",
            "sni": args.sni or "",
            "fp": args.fp or "",
            "security": args.security or "",
            "pbk": args.pbk or "",
            "sid": args.sid or ""
        }
    
    # 检查节点名称是否已存在
    if node_name in nodes:
        print(f"错误：节点名称 '{node_name}' 已存在")
        return False
    
    # 添加节点
    nodes[node_name] = node
    
    # 保存节点配置
    if save_nodes(nodes):
        print(f"节点 '{node_name}' 添加成功")
        return True
    else:
        return False

def edit_node(args):
    """编辑节点"""
    nodes = load_nodes()
    
    if args.name not in nodes:
        print(f"错误：节点 '{args.name}' 不存在")
        return False
    
    node = nodes[args.name]
    
    if args.link:
        # 从链接更新节点
        new_node = parse_vless_link(args.link)
        if not new_node:
            return False
        
        # 保留原节点名称
        new_node["remark"] = args.remark or new_node.get("remark") or node.get("remark")
        nodes[args.name] = new_node
    else:
        # 手动更新节点
        if args.server:
            node["server"] = args.server
        if args.port:
            node["server_port"] = args.port
        if args.uuid:
            node["uuid"] = args.uuid
        if args.remark:
            node["remark"] = args.remark
        if args.type:
            node["type"] = args.type
        if args.encryption:
            node["encryption"] = args.encryption
        if args.flow:
            node["flow"] = args.flow
        if args.sni:
            node["sni"] = args.sni
        if args.fp:
            node["fp"] = args.fp
        if args.security:
            node["security"] = args.security
        if args.pbk:
            node["pbk"] = args.pbk
        if args.sid:
            node["sid"] = args.sid
    
    # 保存节点配置
    if save_nodes(nodes):
        print(f"节点 '{args.name}' 更新成功")
        return True
    else:
        return False

def delete_node(args):
    """删除节点"""
    nodes = load_nodes()
    
    if args.name not in nodes:
        print(f"错误：节点 '{args.name}' 不存在")
        return False
    
    # 删除节点
    del nodes[args.name]
    
    # 保存节点配置
    if save_nodes(nodes):
        print(f"节点 '{args.name}' 删除成功")
        return True
    else:
        return False

def list_nodes(args):
    """列出节点"""
    nodes = load_nodes()
    
    if not nodes:
        print("没有找到任何节点")
        return True
    
    print(f"找到 {len(nodes)} 个节点：")
    print("-" * 60)
    
    for name, node in nodes.items():
        print(f"名称: {name}")
        print(f"服务器: {node['server']}:{node['server_port']}")
        print(f"UUID: {node['uuid']}")
        if node.get("remark"):
            print(f"备注: {node['remark']}")
        if node.get("flow"):
            print(f"流控: {node['flow']}")
        if node.get("sni"):
            print(f"SNI: {node['sni']}")
        
        # 生成VLESS链接
        link = generate_vless_link(node)
        if link:
            print(f"链接: {link}")
        
        print("-" * 60)
    
    return True

def show_node(args):
    """显示节点详细信息"""
    nodes = load_nodes()
    
    if args.name not in nodes:
        print(f"错误：节点 '{args.name}' 不存在")
        return False
    
    node = nodes[args.name]
    
    print(f"节点名称: {args.name}")
    print(f"服务器: {node['server']}:{node['server_port']}")
    print(f"UUID: {node['uuid']}")
    print(f"类型: {node.get('type', 'tcp')}")
    print(f"加密: {node.get('encryption', 'none')}")
    
    if node.get("flow"):
        print(f"流控: {node['flow']}")
    if node.get("sni"):
        print(f"SNI: {node['sni']}")
    if node.get("fp"):
        print(f"指纹: {node['fp']}")
    if node.get("security"):
        print(f"安全: {node['security']}")
    if node.get("pbk"):
        print(f"公钥: {node['pbk']}")
    if node.get("sid"):
        print(f"短ID: {node['sid']}")
    if node.get("remark"):
        print(f"备注: {node['remark']}")
    
    # 生成VLESS链接
    link = generate_vless_link(node)
    if link:
        print(f"链接: {link}")
    
    return True

def use_node(args):
    """使用节点"""
    nodes = load_nodes()
    
    if args.name not in nodes:
        print(f"错误：节点 '{args.name}' 不存在")
        return False
    
    node = nodes[args.name]
    
    # 加载配置模板
    config = load_config_template()
    
    # 更新配置
    outbound = config["outbounds"][0]
    outbound["server"] = node["server"]
    outbound["server_port"] = node["server_port"]
    outbound["uuid"] = node["uuid"]
    outbound["flow"] = node.get("flow", "")
    
    if "tls" in outbound:
        outbound["tls"]["server_name"] = node.get("sni", "")
        
        if "utls" in outbound["tls"]:
            outbound["tls"]["utls"]["fingerprint"] = node.get("fp", "chrome")
        
        if "reality" in outbound["tls"] and node.get("security") == "reality":
            outbound["tls"]["reality"]["enabled"] = True
            outbound["tls"]["reality"]["public_key"] = node.get("pbk", "")
            outbound["tls"]["reality"]["short_id"] = node.get("sid", "")
    
    # 保存配置
    try:
        with open(SING_BOX_CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"已应用节点 '{args.name}' 的配置")
        
        # 重启sing-box服务
        try:
            subprocess.run(["systemctl", "restart", "sing-box"], check=True)
            print("sing-box服务已重启")
            return True
        except subprocess.CalledProcessError:
            print("警告：无法重启sing-box服务，请手动重启")
            return False
    except Exception as e:
        print(f"错误：无法保存配置 - {e}")
        return False

def test_node(args):
    """测试节点连接"""
    nodes = load_nodes()
    
    if args.name and args.name not in nodes:
        print(f"错误：节点 '{args.name}' 不存在")
        return False
    
    if args.name:
        # 测试指定节点
        node_names = [args.name]
    else:
        # 测试所有节点
        node_names = list(nodes.keys())
    
    for name in node_names:
        print(f"测试节点 '{name}'...")
        
        # 应用节点配置
        args.name = name
        if not use_node(args):
            print(f"节点 '{name}' 应用配置失败，跳过测试")
            continue
        
        # 等待服务启动
        time.sleep(2)
        
        # 测试连接
        try:
            start_time = time.time()
            result = subprocess.run(
                ["curl", "--socks5", "127.0.0.1:1080", "-o", "/dev/null", "-s", "-w", "%{http_code},%{time_total}", "https://www.google.com"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                status_code, time_total = result.stdout.split(",")
                print(f"节点 '{name}' 连接成功！状态码: {status_code}, 耗时: {time_total}秒")
            else:
                print(f"节点 '{name}' 连接失败: {result.stderr}")
        except subprocess.TimeoutExpired:
            print(f"节点 '{name}' 连接超时")
        except Exception as e:
            print(f"节点 '{name}' 测试出错: {e}")
    
    return True

def import_from_file(args):
    """从文件导入节点"""
    if not os.path.exists(args.file):
        print(f"错误：文件 '{args.file}' 不存在")
        return False
    
    try:
        with open(args.file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
        
        # 分割多个链接
        links = re.findall(r'vless://[^\s]+', content)
        
        if not links:
            print("错误：文件中没有找到有效的VLESS链接")
            return False
        
        nodes = load_nodes()
        imported_count = 0
        
        for link in links:
            node = parse_vless_link(link)
            if not node:
                continue
            
            # 使用备注或生成名称
            node_name = node.get("remark") or f"导入节点_{len(nodes) + 1}"
            
            # 确保名称唯一
            original_name = node_name
            counter = 1
            while node_name in nodes:
                node_name = f"{original_name}_{counter}"
                counter += 1
            
            nodes[node_name] = node
            imported_count += 1
        
        if imported_count > 0:
            if save_nodes(nodes):
                print(f"成功导入 {imported_count} 个节点")
                return True
        else:
            print("没有导入任何节点")
        
        return False
    except Exception as e:
        print(f"错误：导入节点失败 - {e}")
        return False

def export_to_file(args):
    """导出节点到文件"""
    nodes = load_nodes()
    
    if not nodes:
        print("没有找到任何节点可导出")
        return False
    
    try:
        links = []
        
        for name, node in nodes.items():
            link = generate_vless_link(node)
            if link:
                links.append(link)
        
        if not links:
            print("没有生成任何有效的VLESS链接")
            return False
        
        with open(args.file, 'w', encoding='utf-8') as f:
            f.write("\n".join(links))
        
        print(f"成功导出 {len(links)} 个节点到文件 '{args.file}'")
        return True
    except Exception as e:
        print(f"错误：导出节点失败 - {e}")
        return False

def rename_node(args):
    """重命名节点"""
    nodes = load_nodes()
    
    if args.old_name not in nodes:
        print(f"错误：节点 '{args.old_name}' 不存在")
        return False
    
    if args.new_name in nodes:
        print(f"错误：节点名称 '{args.new_name}' 已存在")
        return False
    
    # 重命名节点
    nodes[args.new_name] = nodes[args.old_name]
    del nodes[args.old_name]
    
    # 保存节点配置
    if save_nodes(nodes):
        print(f"节点 '{args.old_name}' 已重命名为 '{args.new_name}'")
        return True
    else:
        return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="VLESS节点管理工具")
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # 添加节点
    add_parser = subparsers.add_parser("add", help="添加节点")
    add_parser.add_argument("--name", help="节点名称")
    add_parser.add_argument("--link", help="VLESS链接")
    add_parser.add_argument("--server", help="服务器地址")
    add_parser.add_argument("--port", type=int, help="服务器端口")
    add_parser.add_argument("--uuid", help="UUID")
    add_parser.add_argument("--remark", help="备注")
    add_parser.add_argument("--type", help="连接类型")
    add_parser.add_argument("--encryption", help="加密方式")
    add_parser.add_argument("--flow", help="流控")
    add_parser.add_argument("--sni", help="SNI")
    add_parser.add_argument("--fp", help="指纹")
    add_parser.add_argument("--security", help="安全类型")
    add_parser.add_argument("--pbk", help="公钥")
    add_parser.add_argument("--sid", help="短ID")
    
    # 编辑节点
    edit_parser = subparsers.add_parser("edit", help="编辑节点")
    edit_parser.add_argument("name", help="节点名称")
    edit_parser.add_argument("--link", help="VLESS链接")
    edit_parser.add_argument("--server", help="服务器地址")
    edit_parser.add_argument("--port", type=int, help="服务器端口")
    edit_parser.add_argument("--uuid", help="UUID")
    edit_parser.add_argument("--remark", help="备注")
    edit_parser.add_argument("--type", help="连接类型")
    edit_parser.add_argument("--encryption", help="加密方式")
    edit_parser.add_argument("--flow", help="流控")
    edit_parser.add_argument("--sni", help="SNI")
    edit_parser.add_argument("--fp", help="指纹")
    edit_parser.add_argument("--security", help="安全类型")
    edit_parser.add_argument("--pbk", help="公钥")
    edit_parser.add_argument("--sid", help="短ID")
    
    # 删除节点
    delete_parser = subparsers.add_parser("delete", help="删除节点")
    delete_parser.add_argument("name", help="节点名称")
    
    # 列出节点
    list_parser = subparsers.add_parser("list", help="列出所有节点")
    
    # 显示节点详细信息
    show_parser = subparsers.add_parser("show", help="显示节点详细信息")
    show_parser.add_argument("name", help="节点名称")
    
    # 使用节点
    use_parser = subparsers.add_parser("use", help="使用节点")
    use_parser.add_argument("name", help="节点名称")
    
    # 测试节点
    test_parser = subparsers.add_parser("test", help="测试节点连接")
    test_parser.add_argument("--name", help="节点名称，不指定则测试所有节点")
    
    # 导入节点
    import_parser = subparsers.add_parser("import", help="从文件导入节点")
    import_parser.add_argument("file", help="文件路径")
    
    # 导出节点
    export_parser = subparsers.add_parser("export", help="导出节点到文件")
    export_parser.add_argument("file", help="文件路径")
    
    # 重命名节点
    rename_parser = subparsers.add_parser("rename", help="重命名节点")
    rename_parser.add_argument("old_name", help="原节点名称")
    rename_parser.add_argument("new_name", help="新节点名称")
    
    args = parser.parse_args()
    
    if args.command == "add":
        add_node(args)
    elif args.command == "edit":
        edit_node(args)
    elif args.command == "delete":
        delete_node(args)
    elif args.command == "list":
        list_nodes(args)
    elif args.command == "show":
        show_node(args)
    elif args.command == "use":
        use_node(args)
    elif args.command == "test":
        test_node(args)
    elif args.command == "import":
        import_from_file(args)
    elif args.command == "export":
        export_to_file(args)
    elif args.command == "rename":
        rename_node(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()

