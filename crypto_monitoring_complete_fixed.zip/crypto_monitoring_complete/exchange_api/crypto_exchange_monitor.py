#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加密货币交易所API监控脚本
用于监控多个交易所的价格、交易量和市场变化
"""

import os
import sys
import json
import time
import logging
import requests
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from websocket import create_connection
import threading
import schedule

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/api_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("crypto_exchange_monitor")

# 确保结果目录存在
os.makedirs("../results/binance_us", exist_ok=True)
os.makedirs("../results/combined", exist_ok=True)

class CryptoExchangeMonitor:
    """加密货币交易所监控类"""
    
    def __init__(self):
        """初始化监控器"""
        self.exchanges = {
            "binance": "https://api.binance.com",
            "binance_us": "https://api.binance.us",
            "gate_io": "https://api.gateio.ws/api/v4"
        }
        self.monitored_symbols = [
            "BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", 
            "ADA/USDT", "XRP/USDT", "DOT/USDT", "DOGE/USDT"
        ]
        self.price_data = {}
        self.volume_data = {}
        self.alert_thresholds = {
            "price_change_pct": 5.0,  # 5%
            "volume_spike_pct": 200.0  # 200%
        }
        
    def normalize_symbol(self, symbol, exchange):
        """根据交易所格式化交易对符号"""
        if exchange in ["binance", "binance_us"]:
            return symbol.replace("/", "")
        elif exchange == "gate_io":
            return symbol.replace("/", "_")
        return symbol
    
    def fetch_ticker(self, exchange, symbol):
        """获取指定交易所和交易对的行情数据"""
        normalized_symbol = self.normalize_symbol(symbol, exchange)
        
        try:
            if exchange in ["binance", "binance_us"]:
                url = f"{self.exchanges[exchange]}/api/v3/ticker/24hr?symbol={normalized_symbol}"
                response = requests.get(url, timeout=10)
                data = response.json()
                return {
                    "symbol": symbol,
                    "price": float(data["lastPrice"]),
                    "volume": float(data["volume"]),
                    "price_change_pct": float(data["priceChangePercent"]),
                    "high_24h": float(data["highPrice"]),
                    "low_24h": float(data["lowPrice"]),
                    "timestamp": datetime.now().isoformat()
                }
            elif exchange == "gate_io":
                url = f"{self.exchanges[exchange]}/spot/tickers"
                response = requests.get(url, timeout=10)
                data = response.json()
                for ticker in data:
                    if ticker["currency_pair"] == normalized_symbol:
                        return {
                            "symbol": symbol,
                            "price": float(ticker["last"]),
                            "volume": float(ticker["base_volume"]),
                            "price_change_pct": float(ticker["change_percentage"]),
                            "high_24h": float(ticker["high_24h"]),
                            "low_24h": float(ticker["low_24h"]),
                            "timestamp": datetime.now().isoformat()
                        }
        except Exception as e:
            logger.error(f"获取{exchange}的{symbol}行情数据失败: {e}")
        
        return None
    
    def monitor_exchanges(self):
        """监控所有交易所的所有交易对"""
        logger.info("开始监控交易所数据...")
        
        for exchange in self.exchanges:
            logger.info(f"正在获取{exchange}交易所数据...")
            exchange_data = []
            
            for symbol in self.monitored_symbols:
                ticker = self.fetch_ticker(exchange, symbol)
                if ticker:
                    exchange_data.append(ticker)
                    
                    # 存储价格和交易量数据用于分析
                    if exchange not in self.price_data:
                        self.price_data[exchange] = {}
                        self.volume_data[exchange] = {}
                    
                    if symbol not in self.price_data[exchange]:
                        self.price_data[exchange][symbol] = []
                        self.volume_data[exchange][symbol] = []
                    
                    self.price_data[exchange][symbol].append(ticker["price"])
                    self.volume_data[exchange][symbol].append(ticker["volume"])
                    
                    # 保持数据长度为24小时（假设每小时一次）
                    if len(self.price_data[exchange][symbol]) > 24:
                        self.price_data[exchange][symbol].pop(0)
                        self.volume_data[exchange][symbol].pop(0)
                    
                    # 检查价格变化和交易量异常
                    self.check_alerts(exchange, symbol, ticker)
                
                time.sleep(1)  # 避免API请求过于频繁
            
            # 保存交易所数据
            if exchange_data:
                df = pd.DataFrame(exchange_data)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                
                # 保存到CSV
                output_dir = f"../results/{exchange.replace('-', '_')}"
                os.makedirs(output_dir, exist_ok=True)
                df.to_csv(f"{output_dir}/{timestamp}_data.csv", index=False)
                
                # 更新最新数据文件
                df.to_csv(f"{output_dir}/latest_data.csv", index=False)
                
                logger.info(f"{exchange}交易所数据已保存")
        
        # 合并所有交易所数据进行比较
        self.combine_exchange_data()
    
    def check_alerts(self, exchange, symbol, ticker):
        """检查价格和交易量异常"""
        # 只有当有足够的历史数据时才检查
        if len(self.price_data[exchange][symbol]) < 2:
            return
        
        # 计算价格变化百分比
        price_now = ticker["price"]
        price_prev = self.price_data[exchange][symbol][-2]
        price_change_pct = abs((price_now - price_prev) / price_prev * 100)
        
        # 计算交易量变化百分比
        volume_now = ticker["volume"]
        volume_avg = np.mean(self.volume_data[exchange][symbol][:-1]) if len(self.volume_data[exchange][symbol]) > 1 else volume_now
        volume_change_pct = (volume_now / volume_avg * 100) - 100 if volume_avg > 0 else 0
        
        # 检查是否触发警报
        if price_change_pct > self.alert_thresholds["price_change_pct"]:
            direction = "上涨" if price_now > price_prev else "下跌"
            alert_msg = f"价格警报: {exchange}的{symbol}{direction}了{price_change_pct:.2f}%, 从{price_prev}到{price_now}"
            logger.warning(alert_msg)
            self.save_alert(alert_msg)
        
        if volume_change_pct > self.alert_thresholds["volume_spike_pct"]:
            alert_msg = f"交易量警报: {exchange}的{symbol}交易量激增{volume_change_pct:.2f}%, 当前交易量: {volume_now}"
            logger.warning(alert_msg)
            self.save_alert(alert_msg)
    
    def save_alert(self, alert_msg):
        """保存警报信息到文件"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open("../results/alerts.txt", "a") as f:
            f.write(f"[{timestamp}] {alert_msg}\n")
    
    def combine_exchange_data(self):
        """合并所有交易所的数据进行比较分析"""
        combined_data = []
        
        for symbol in self.monitored_symbols:
            symbol_data = {"symbol": symbol}
            
            for exchange in self.exchanges:
                if exchange in self.price_data and symbol in self.price_data[exchange] and self.price_data[exchange][symbol]:
                    symbol_data[f"{exchange}_price"] = self.price_data[exchange][symbol][-1]
                    symbol_data[f"{exchange}_volume"] = self.volume_data[exchange][symbol][-1] if self.volume_data[exchange][symbol] else 0
            
            if len(symbol_data) > 1:  # 确保不只有symbol字段
                combined_data.append(symbol_data)
        
        if combined_data:
            df = pd.DataFrame(combined_data)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # 保存到CSV
            df.to_csv(f"../results/combined/{timestamp}_combined.csv", index=False)
            df.to_csv(f"../results/combined/latest_combined.csv", index=False)
            
            logger.info("合并交易所数据已保存")
            
            # 生成价格比较图表
            self.generate_price_comparison_chart(df)
    
    def generate_price_comparison_chart(self, df):
        """生成价格比较图表"""
        try:
            plt.figure(figsize=(12, 8))
            
            for symbol in df["symbol"].unique():
                symbol_data = df[df["symbol"] == symbol]
                
                prices = []
                exchanges = []
                
                for exchange in self.exchanges:
                    price_col = f"{exchange}_price"
                    if price_col in symbol_data.columns and not pd.isna(symbol_data[price_col].values[0]):
                        prices.append(symbol_data[price_col].values[0])
                        exchanges.append(exchange)
                
                if prices:
                    plt.subplot(2, 4, self.monitored_symbols.index(symbol) + 1)
                    plt.bar(exchanges, prices)
                    plt.title(symbol)
                    plt.xticks(rotation=45)
                    plt.tight_layout()
            
            # 保存图表
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            plt.savefig(f"../results/combined/{timestamp}_price_comparison.png")
            plt.savefig(f"../results/combined/latest_price_comparison.png")
            plt.close()
            
            logger.info("价格比较图表已生成")
        except Exception as e:
            logger.error(f"生成价格比较图表失败: {e}")
    
    def run_scheduled(self):
        """按计划运行监控任务"""
        # 每小时运行一次
        schedule.every(1).hours.do(self.monitor_exchanges)
        
        # 立即运行一次
        self.monitor_exchanges()
        
        # 持续运行调度器
        while True:
            schedule.run_pending()
            time.sleep(60)

def main():
    """主函数"""
    try:
        # 创建日志目录
        os.makedirs("../logs", exist_ok=True)
        
        monitor = CryptoExchangeMonitor()
        monitor.run_scheduled()
    except KeyboardInterrupt:
        logger.info("监控程序已手动停止")
    except Exception as e:
        logger.error(f"监控程序发生错误: {e}")

if __name__ == "__main__":
    main()
