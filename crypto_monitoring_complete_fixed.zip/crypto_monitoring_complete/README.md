# 加密货币监控系统

## 项目概述

加密货币监控系统是一个综合性工具，用于实时监控多个加密货币交易所的价格、交易量变化和官方公告。系统通过API数据采集、网页爬虫和Telegram通知功能，为用户提供及时的市场动态和投资机会。

## 主要功能

- **交易所API监控**：实时跟踪多个交易所（Binance、Binance US、Gate.io等）的价格和交易量数据
- **价格异常波动警报**：当价格变化超过设定阈值时发出警报
- **交易量激增提醒**：监测交易量异常增长情况
- **交易所间价差分析**：对比不同交易所间的价格差异，发现套利机会
- **新币上线监控**：通过网页爬虫监控交易所官方公告，及时获取新币上线信息
- **Telegram实时通知**：将重要信息通过Telegram机器人推送给用户
- **每日市场摘要**：定期发送市场概况和重要公告摘要

## 系统架构

系统由三个主要模块组成：

1. **交易所API监控模块**（exchange_api目录）
   - 负责通过API获取价格和交易量数据
   - 分析价格波动和交易量变化
   - 生成价格比较图表和数据报告

2. **网页爬虫模块**（web_scraper目录）
   - 监控交易所官方公告页面
   - 提取与新币上线相关的公告
   - 生成公告报告和通知

3. **通知集成模块**（notification目录）
   - 整合API监控和网页爬虫的结果
   - 通过Telegram机器人发送通知
   - 提供交互式命令查询功能

## 目录结构

```
crypto_monitoring/
├── exchange_api/
│   └── crypto_exchange_monitor.py    # 交易所API监控脚本
├── web_scraper/
│   └── exchange_announcement_scraper_final.py    # 交易所公告爬虫脚本
├── notification/
│   ├── integrated_monitor.py    # 集成监控脚本
│   └── telegram_notifier.py    # Telegram通知脚本
├── results/
│   ├── announcements/    # 存储公告数据和报告
│   ├── binance_us/    # 存储Binance US数据
│   └── combined/    # 存储合并分析数据
├── logs/    # 日志文件目录
├── install.sh    # 安装脚本
├── requirements.txt    # Python依赖列表
├── start_monitoring.sh    # 启动脚本
├── stop_monitoring.sh    # 停止脚本
├── status_monitoring.sh    # 状态检查脚本
└── README.md    # 项目说明文档
```

## 安装指南

### 系统要求

- 操作系统：Ubuntu/Debian/CentOS/Fedora Linux
- Python 3.6+
- 至少1GB可用磁盘空间
- 互联网连接

### 安装步骤

1. 克隆或下载项目文件到本地

2. 设置执行权限
   ```bash
   chmod +x install.sh
   ```

3. 运行安装脚本
   ```bash
   sudo ./install.sh
   ```

4. 安装过程将自动执行以下操作：
   - 检查系统环境
   - 安装必要的系统依赖
   - 安装TA-Lib（技术分析库）
   - 创建项目目录结构
   - 复制所有必要的脚本文件
   - 安装Python依赖
   - 创建启动、停止和状态检查脚本

## 配置指南

### 获取Telegram Bot令牌

如果您计划使用Telegram推送通知功能，需要获取Telegram Bot API令牌：

1. 在Telegram中搜索 `@BotFather` 并开始对话
2. 发送 `/newbot` 命令创建新机器人
3. 按照提示设置机器人名称和用户名
4. 创建成功后，BotFather会提供一个API令牌

### 配置监控参数

可以通过修改 `notification/integrated_config.json` 文件来自定义监控参数：

```json
{
    "monitored_symbols": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT"],
    "price_alert_threshold": 5.0,
    "volume_alert_threshold": 200.0,
    "check_interval_minutes": 30,
    "telegram_chat_ids": []
}
```

- `monitored_symbols`: 要监控的交易对列表
- `price_alert_threshold`: 价格变化警报阈值（百分比）
- `volume_alert_threshold`: 交易量变化警报阈值（百分比）
- `check_interval_minutes`: 检查间隔（分钟）
- `telegram_chat_ids`: 已订阅的Telegram聊天ID列表

## 使用指南

### 启动监控系统

```bash
cd ~/crypto_monitoring
./start_monitoring.sh -t <your_telegram_bot_token> -m full -b
```

参数说明：
- `-t, --telegram-token`：Telegram Bot API令牌
- `-m, --mode`：运行模式，可选值：api, web, telegram, full
- `-b, --background`：在后台运行

### 查看系统状态

```bash
./status_monitoring.sh
```

### 停止监控系统

```bash
./stop_monitoring.sh
```

### Telegram机器人命令

- `/start` - 启动机器人
- `/help` - 显示帮助信息
- `/status` - 查看监控系统状态
- `/price` - 查看当前价格
- `/news` - 查看最新公告
- `/subscribe` - 订阅通知
- `/unsubscribe` - 取消订阅通知

## 常见问题

### 1. 安装过程中出现错误

如果安装过程中出现错误，请检查以下几点：

- 确保您有足够的磁盘空间
- 确保您的系统满足最低要求
- 检查网络连接是否正常
- 查看错误日志，通常位于安装目录下的`logs/`文件夹

### 2. 无法接收Telegram通知

如果您无法接收Telegram通知，请检查：

- 确保您已正确设置Telegram Bot令牌
- 确保您已在Telegram中与您的Bot进行了对话并发送了`/start`命令
- 检查`logs/telegram_notifier.log`文件中的错误信息

### 3. TA-Lib安装失败

TA-Lib是一个技术分析库，有时安装可能会失败。如果遇到问题，可以尝试：

```bash
# Ubuntu/Debian
sudo apt-get install build-essential
sudo apt-get install ta-lib

# CentOS/Fedora
sudo yum groupinstall "Development Tools"
sudo yum install ta-lib
```

然后重新运行安装脚本。

## 进阶使用

### 设置开机自启

您可以使用crontab设置开机自启：

```bash
crontab -e
```

添加以下行：

```
@reboot cd /path/to/crypto_monitoring && ./start_monitoring.sh -t <your_telegram_bot_token> -m full -b
```

### 自定义通知模板

如需自定义通知消息格式，可以修改`notification/telegram_notifier.py`文件中的相应方法。

### 添加新的交易所

如需添加新的交易所监控，可以修改`exchange_api/crypto_exchange_monitor.py`文件中的`exchanges`字典。

## 支持与反馈

如有任何问题或需要进一步的帮助，请参考日志文件或联系系统管理员。
