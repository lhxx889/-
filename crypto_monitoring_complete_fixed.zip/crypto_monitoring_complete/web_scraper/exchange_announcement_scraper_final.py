#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加密货币交易所公告爬虫脚本
用于监控多个交易所的官方公告，特别关注新币上线信息
"""

import os
import sys
import json
import time
import logging
import requests
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
import asyncio
from playwright.async_api import async_playwright
import re
import hashlib

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/web_scraper.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("exchange_announcement_scraper")

# 确保结果目录存在
os.makedirs("../results/announcements", exist_ok=True)

class ExchangeAnnouncementScraper:
    """交易所公告爬虫类"""
    
    def __init__(self):
        """初始化爬虫"""
        self.exchanges = {
            "binance": {
                "name": "Binance",
                "url": "https://www.binance.com/en/support/announcement/new-cryptocurrency-listing",
                "selector": ".css-1ej4hfo"
            },
            "coinbase": {
                "name": "Coinbase",
                "url": "https://blog.coinbase.com/",
                "selector": ".graf--h3"
            },
            "kucoin": {
                "name": "KuCoin",
                "url": "https://www.kucoin.com/news/categories/listing",
                "selector": ".news-content"
            }
        }
        self.keywords = [
            "listing", "list", "new", "addition", "added", "support", "trading", "launch",
            "上线", "新币", "新增", "支持", "交易"
        ]
        self.data_file = "../results/announcements/announcements_data.json"
        self.load_existing_data()
    
    def load_existing_data(self):
        """加载现有的公告数据"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    self.announcements = json.load(f)
                logger.info(f"已加载{len(self.announcements)}条现有公告数据")
            except Exception as e:
                logger.error(f"加载现有公告数据失败: {e}")
                self.announcements = []
        else:
            self.announcements = []
    
    def save_data(self):
        """保存公告数据到文件"""
        try:
            with open(self.data_file, "w", encoding="utf-8") as f:
                json.dump(self.announcements, f, ensure_ascii=False, indent=2)
            logger.info(f"已保存{len(self.announcements)}条公告数据")
        except Exception as e:
            logger.error(f"保存公告数据失败: {e}")
    
    def generate_announcement_id(self, title, url):
        """生成公告唯一ID"""
        content = f"{title}|{url}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def is_new_announcement(self, announcement_id):
        """检查是否为新公告"""
        for announcement in self.announcements:
            if announcement["id"] == announcement_id:
                return False
        return True
    
    def contains_keywords(self, text):
        """检查文本是否包含关键词"""
        text_lower = text.lower()
        for keyword in self.keywords:
            if keyword.lower() in text_lower:
                return True
        return False
    
    async def scrape_binance(self, page):
        """爬取Binance公告"""
        exchange = self.exchanges["binance"]
        logger.info(f"正在爬取{exchange['name']}公告...")
        
        try:
            await page.goto(exchange["url"], timeout=60000)
            await page.wait_for_selector(exchange["selector"], timeout=30000)
            
            # 滚动页面以加载更多内容
            for _ in range(3):
                await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                await asyncio.sleep(2)
            
            # 提取公告列表
            announcements = await page.query_selector_all(".css-1ej4hfo")
            
            new_count = 0
            for announcement in announcements:
                try:
                    title_element = await announcement.query_selector("h3")
                    link_element = await announcement.query_selector("a")
                    date_element = await announcement.query_selector(".css-1fobf8d")
                    
                    if title_element and link_element and date_element:
                        title = await title_element.inner_text()
                        relative_url = await link_element.get_attribute("href")
                        url = f"https://www.binance.com{relative_url}" if relative_url.startswith("/") else relative_url
                        date_str = await date_element.inner_text()
                        
                        # 只处理包含关键词的公告
                        if self.contains_keywords(title):
                            announcement_id = self.generate_announcement_id(title, url)
                            
                            if self.is_new_announcement(announcement_id):
                                new_count += 1
                                self.announcements.append({
                                    "id": announcement_id,
                                    "exchange": exchange["name"],
                                    "title": title,
                                    "url": url,
                                    "date": date_str,
                                    "timestamp": datetime.now().isoformat()
                                })
                except Exception as e:
                    logger.error(f"处理Binance公告项时出错: {e}")
            
            logger.info(f"从{exchange['name']}发现{new_count}条新公告")
        except Exception as e:
            logger.error(f"爬取{exchange['name']}公告失败: {e}")
    
    async def scrape_coinbase(self, page):
        """爬取Coinbase公告"""
        exchange = self.exchanges["coinbase"]
        logger.info(f"正在爬取{exchange['name']}公告...")
        
        try:
            await page.goto(exchange["url"], timeout=60000)
            await page.wait_for_selector(exchange["selector"], timeout=30000)
            
            # 滚动页面以加载更多内容
            for _ in range(3):
                await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                await asyncio.sleep(2)
            
            # 提取公告列表
            articles = await page.query_selector_all("article")
            
            new_count = 0
            for article in articles:
                try:
                    title_element = await article.query_selector("h3")
                    link_element = await article.query_selector("a[data-action='open-post']")
                    date_element = await article.query_selector("time")
                    
                    if title_element and link_element:
                        title = await title_element.inner_text()
                        url = await link_element.get_attribute("href")
                        date_str = await date_element.inner_text() if date_element else "Unknown Date"
                        
                        # 只处理包含关键词的公告
                        if self.contains_keywords(title):
                            announcement_id = self.generate_announcement_id(title, url)
                            
                            if self.is_new_announcement(announcement_id):
                                new_count += 1
                                self.announcements.append({
                                    "id": announcement_id,
                                    "exchange": exchange["name"],
                                    "title": title,
                                    "url": url,
                                    "date": date_str,
                                    "timestamp": datetime.now().isoformat()
                                })
                except Exception as e:
                    logger.error(f"处理Coinbase公告项时出错: {e}")
            
            logger.info(f"从{exchange['name']}发现{new_count}条新公告")
        except Exception as e:
            logger.error(f"爬取{exchange['name']}公告失败: {e}")
    
    async def scrape_kucoin(self, page):
        """爬取KuCoin公告"""
        exchange = self.exchanges["kucoin"]
        logger.info(f"正在爬取{exchange['name']}公告...")
        
        try:
            await page.goto(exchange["url"], timeout=60000)
            await page.wait_for_selector(exchange["selector"], timeout=30000)
            
            # 滚动页面以加载更多内容
            for _ in range(3):
                await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                await asyncio.sleep(2)
            
            # 提取公告列表
            news_items = await page.query_selector_all(".news-content")
            
            new_count = 0
            for item in news_items:
                try:
                    title_element = await item.query_selector("h3")
                    link_element = await item.query_selector("a")
                    date_element = await item.query_selector(".date")
                    
                    if title_element and link_element:
                        title = await title_element.inner_text()
                        url = await link_element.get_attribute("href")
                        date_str = await date_element.inner_text() if date_element else "Unknown Date"
                        
                        # 只处理包含关键词的公告
                        if self.contains_keywords(title):
                            announcement_id = self.generate_announcement_id(title, url)
                            
                            if self.is_new_announcement(announcement_id):
                                new_count += 1
                                self.announcements.append({
                                    "id": announcement_id,
                                    "exchange": exchange["name"],
                                    "title": title,
                                    "url": url,
                                    "date": date_str,
                                    "timestamp": datetime.now().isoformat()
                                })
                except Exception as e:
                    logger.error(f"处理KuCoin公告项时出错: {e}")
            
            logger.info(f"从{exchange['name']}发现{new_count}条新公告")
        except Exception as e:
            logger.error(f"爬取{exchange['name']}公告失败: {e}")
    
    async def scrape_all_exchanges(self):
        """爬取所有交易所的公告"""
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            )
            page = await context.new_page()
            
            # 爬取各交易所公告
            await self.scrape_binance(page)
            await self.scrape_coinbase(page)
            await self.scrape_kucoin(page)
            
            await browser.close()
        
        # 保存数据
        self.save_data()
        
        # 生成报告
        self.generate_report()
    
    def generate_report(self):
        """生成公告报告"""
        try:
            # 按时间戳排序，最新的在前
            sorted_announcements = sorted(
                self.announcements,
                key=lambda x: x.get("timestamp", ""),
                reverse=True
            )
            
            # 生成HTML报告
            html_content = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <title>加密货币交易所公告监控报告</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    h1 { color: #333; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    tr:nth-child(even) { background-color: #f9f9f9; }
                    .new { background-color: #e6ffe6; }
                </style>
            </head>
            <body>
                <h1>加密货币交易所公告监控报告</h1>
                <p>生成时间: %s</p>
                <table>
                    <tr>
                        <th>交易所</th>
                        <th>日期</th>
                        <th>标题</th>
                        <th>链接</th>
                    </tr>
            """ % datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # 最多显示100条记录
            for announcement in sorted_announcements[:100]:
                html_content += """
                    <tr>
                        <td>%s</td>
                        <td>%s</td>
                        <td>%s</td>
                        <td><a href="%s" target="_blank">查看详情</a></td>
                    </tr>
                """ % (
                    announcement.get("exchange", ""),
                    announcement.get("date", ""),
                    announcement.get("title", ""),
                    announcement.get("url", "")
                )
            
            html_content += """
                </table>
            </body>
            </html>
            """
            
            # 保存HTML报告
            report_file = "../results/announcements/announcement_report.html"
            with open(report_file, "w", encoding="utf-8") as f:
                f.write(html_content)
            
            logger.info(f"公告报告已生成: {report_file}")
            
            # 生成CSV报告
            df = pd.DataFrame(sorted_announcements)
            if not df.empty:
                csv_file = "../results/announcements/announcement_data.csv"
                df.to_csv(csv_file, index=False)
                logger.info(f"CSV数据已生成: {csv_file}")
        except Exception as e:
            logger.error(f"生成报告失败: {e}")
    
    def run(self):
        """运行爬虫"""
        try:
            # 创建日志目录
            os.makedirs("../logs", exist_ok=True)
            
            # 运行爬虫
            asyncio.run(self.scrape_all_exchanges())
        except Exception as e:
            logger.error(f"爬虫运行失败: {e}")

def main():
    """主函数"""
    try:
        scraper = ExchangeAnnouncementScraper()
        scraper.run()
    except KeyboardInterrupt:
        logger.info("爬虫程序已手动停止")
    except Exception as e:
        logger.error(f"爬虫程序发生错误: {e}")

if __name__ == "__main__":
    main()
