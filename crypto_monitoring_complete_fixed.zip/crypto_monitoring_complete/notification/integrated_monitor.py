#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加密货币监控系统集成监控脚本
整合API监控和网页爬虫结果，通过Telegram发送通知
"""

import os
import sys
import json
import time
import logging
import pandas as pd
import schedule
from datetime import datetime
import threading
import telegram
from telegram.ext import Application, CommandHandler, ContextTypes
import asyncio

# 导入Telegram通知模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from telegram_notifier import TelegramNotifier

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/integrated_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("integrated_monitor")

class IntegratedMonitor:
    """集成监控类"""
    
    def __init__(self, telegram_token):
        """初始化监控器"""
        self.telegram_token = telegram_token
        self.config_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "integrated_config.json")
        self.load_config()
        
        # 初始化Telegram通知器
        self.notifier = TelegramNotifier(telegram_token)
        
        # 记录已处理的警报和公告
        self.processed_alerts = set()
        self.processed_announcements = set()
    
    def load_config(self):
        """加载配置文件"""
        default_config = {
            "monitored_symbols": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT"],
            "price_alert_threshold": 5.0,
            "volume_alert_threshold": 200.0,
            "check_interval_minutes": 30,
            "telegram_chat_ids": []
        }
        
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    self.config = json.load(f)
                logger.info("已加载配置文件")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
                self.config = default_config
        else:
            logger.warning("配置文件不存在，使用默认配置")
            self.config = default_config
            self.save_config()
    
    def save_config(self):
        """保存配置到文件"""
        try:
            with open(self.config_file, "w") as f:
                json.dump(self.config, f, indent=4)
            logger.info("配置已保存")
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
    
    def check_api_alerts(self):
        """检查API监控警报"""
        alerts_file = "../results/alerts.txt"
        if not os.path.exists(alerts_file):
            logger.warning(f"警报文件不存在: {alerts_file}")
            return
        
        try:
            with open(alerts_file, "r") as f:
                alerts = f.readlines()
            
            new_alerts = []
            for alert in alerts:
                alert = alert.strip()
                if alert and alert not in self.processed_alerts:
                    new_alerts.append(alert)
                    self.processed_alerts.add(alert)
            
            if new_alerts:
                logger.info(f"发现{len(new_alerts)}条新警报")
                
                # 构建消息
                message = "🚨 *价格和交易量警报*\n\n"
                for alert in new_alerts:
                    message += f"• {alert}\n"
                
                # 发送Telegram通知
                asyncio.run(self.notifier.send_message(message))
            else:
                logger.info("没有新的警报")
        except Exception as e:
            logger.error(f"检查API警报失败: {e}")
    
    def check_price_comparison(self):
        """检查价格比较数据"""
        latest_data_file = "../results/combined/latest_combined.csv"
        if not os.path.exists(latest_data_file):
            logger.warning(f"最新价格比较数据文件不存在: {latest_data_file}")
            return
        
        try:
            df = pd.read_csv(latest_data_file)
            
            # 检查是否有价格差异超过阈值的交易对
            price_diff_alerts = []
            
            for _, row in df.iterrows():
                symbol = row["symbol"]
                
                # 收集所有交易所的价格
                prices = {}
                for col in row.index:
                    if col.endswith("_price") and not pd.isna(row[col]):
                        exchange = col.replace("_price", "")
                        prices[exchange] = row[col]
                
                # 如果至少有两个交易所的价格
                if len(prices) >= 2:
                    max_price = max(prices.values())
                    min_price = min(prices.values())
                    
                    # 计算最大价差百分比
                    if min_price > 0:
                        diff_pct = (max_price - min_price) / min_price * 100
                        
                        # 如果价差超过阈值
                        if diff_pct > self.config["price_alert_threshold"]:
                            # 找出最高和最低价格的交易所
                            max_exchange = [k for k, v in prices.items() if v == max_price][0]
                            min_exchange = [k for k, v in prices.items() if v == min_price][0]
                            
                            alert = f"{symbol}在不同交易所间价差达{diff_pct:.2f}%: {max_exchange}({max_price})vs{min_exchange}({min_price})"
                            price_diff_alerts.append(alert)
            
            if price_diff_alerts:
                logger.info(f"发现{len(price_diff_alerts)}条价格差异警报")
                
                # 构建消息
                message = "💹 *交易所价格差异警报*\n\n"
                for alert in price_diff_alerts:
                    message += f"• {alert}\n"
                
                # 发送Telegram通知
                asyncio.run(self.notifier.send_message(message))
            else:
                logger.info("没有显著的价格差异")
        except Exception as e:
            logger.error(f"检查价格比较数据失败: {e}")
    
    def check_new_announcements(self):
        """检查新的交易所公告"""
        announcements_file = "../results/announcements/announcements_data.json"
        if not os.path.exists(announcements_file):
            logger.warning(f"公告数据文件不存在: {announcements_file}")
            return
        
        try:
            with open(announcements_file, "r", encoding="utf-8") as f:
                announcements = json.load(f)
            
            # 按时间戳排序，最新的在前
            sorted_announcements = sorted(
                announcements,
                key=lambda x: x.get("timestamp", ""),
                reverse=True
            )
            
            # 检查新公告
            new_announcements = []
            for announcement in sorted_announcements[:10]:  # 只检查最新的10条
                announcement_id = announcement.get("id")
                if announcement_id and announcement_id not in self.processed_announcements:
                    new_announcements.append(announcement)
                    self.processed_announcements.add(announcement_id)
            
            if new_announcements:
                logger.info(f"发现{len(new_announcements)}条新公告")
                
                # 构建消息
                message = "📢 *交易所新公告*\n\n"
                for announcement in new_announcements:
                    exchange = announcement.get("exchange", "Unknown")
                    title = announcement.get("title", "No Title")
                    url = announcement.get("url", "#")
                    date = announcement.get("date", "Unknown Date")
                    
                    message += f"*{exchange}* - {date}\n"
                    message += f"*{title}*\n"
                    message += f"[查看详情]({url})\n\n"
                
                # 发送Telegram通知
                asyncio.run(self.notifier.send_message(message))
            else:
                logger.info("没有新的公告")
        except Exception as e:
            logger.error(f"检查新公告失败: {e}")
    
    def send_daily_summary(self):
        """发送每日摘要"""
        try:
            now = datetime.now()
            
            # 构建消息
            message = f"📊 *加密货币监控每日摘要* - {now.strftime('%Y-%m-%d')}\n\n"
            
            # 添加价格数据
            latest_data_file = "../results/combined/latest_combined.csv"
            if os.path.exists(latest_data_file):
                df = pd.read_csv(latest_data_file)
                
                message += "*当前价格*\n"
                for _, row in df.iterrows():
                    symbol = row["symbol"]
                    
                    # 查找该交易对在binance的价格
                    binance_price = None
                    for col in row.index:
                        if col == "binance_price" and not pd.isna(row[col]):
                            binance_price = row[col]
                            break
                    
                    if binance_price is not None:
                        message += f"• {symbol}: ${binance_price:.2f}\n"
                
                message += "\n"
            
            # 添加最新公告摘要
            announcements_file = "../results/announcements/announcements_data.json"
            if os.path.exists(announcements_file):
                with open(announcements_file, "r", encoding="utf-8") as f:
                    announcements = json.load(f)
                
                # 按时间戳排序，最新的在前
                sorted_announcements = sorted(
                    announcements,
                    key=lambda x: x.get("timestamp", ""),
                    reverse=True
                )
                
                message += "*最新公告*\n"
                for announcement in sorted_announcements[:5]:  # 只显示最新的5条
                    exchange = announcement.get("exchange", "Unknown")
                    title = announcement.get("title", "No Title")
                    
                    message += f"• {exchange}: {title}\n"
            
            # 发送Telegram通知
            asyncio.run(self.notifier.send_message(message))
            logger.info("已发送每日摘要")
        except Exception as e:
            logger.error(f"发送每日摘要失败: {e}")
    
    def run_scheduled_tasks(self):
        """运行计划任务"""
        # 设置检查间隔
        interval_minutes = self.config.get("check_interval_minutes", 30)
        
        # 每隔指定时间检查一次
        schedule.every(interval_minutes).minutes.do(self.check_api_alerts)
        schedule.every(interval_minutes).minutes.do(self.check_price_comparison)
        schedule.every(interval_minutes).minutes.do(self.check_new_announcements)
        
        # 每天早上9点发送每日摘要
        schedule.every().day.at("09:00").do(self.send_daily_summary)
        
        # 立即运行一次
        self.check_api_alerts()
        self.check_price_comparison()
        self.check_new_announcements()
        
        # 持续运行调度器
        while True:
            schedule.run_pending()
            time.sleep(60)
    
    async def start_bot(self):
        """启动Telegram机器人"""
        try:
            # 创建应用
            application = Application.builder().token(self.telegram_token).build()
            
            # 添加命令处理器
            application.add_handler(CommandHandler("start", self.cmd_start))
            application.add_handler(CommandHandler("help", self.cmd_help))
            application.add_handler(CommandHandler("status", self.cmd_status))
            application.add_handler(CommandHandler("price", self.cmd_price))
            application.add_handler(CommandHandler("news", self.cmd_news))
            application.add_handler(CommandHandler("subscribe", self.cmd_subscribe))
            
            # 启动机器人
            await application.run_polling()
        except Exception as e:
            logger.error(f"启动Telegram机器人失败: {e}")
    
    async def cmd_start(self, update, context):
        """处理/start命令"""
        chat_id = update.effective_chat.id
        await context.bot.send_message(
            chat_id=chat_id,
            text="👋 欢迎使用加密货币监控机器人！\n\n"
                 "使用 /help 查看可用命令\n"
                 "使用 /subscribe 订阅通知"
        )
    
    async def cmd_help(self, update, context):
        """处理/help命令"""
        chat_id = update.effective_chat.id
        await context.bot.send_message(
            chat_id=chat_id,
            text="📚 *可用命令*\n\n"
                 "/start - 启动机器人\n"
                 "/help - 显示帮助信息\n"
                 "/status - 查看监控系统状态\n"
                 "/price - 查看当前价格\n"
                 "/news - 查看最新公告\n"
                 "/subscribe - 订阅通知",
            parse_mode="Markdown"
        )
    
    async def cmd_status(self, update, context):
        """处理/status命令"""
        chat_id = update.effective_chat.id
        
        # 检查各组件状态
        api_status = "✅ 运行中" if os.path.exists("../.api_monitor.pid") else "❌ 未运行"
        web_status = "✅ 运行中" if os.path.exists("../.web_scraper.pid") else "❌ 未运行"
        
        await context.bot.send_message(
            chat_id=chat_id,
            text="🔍 *监控系统状态*\n\n"
                 f"API监控: {api_status}\n"
                 f"网页爬虫: {web_status}\n"
                 f"Telegram通知: ✅ 运行中\n\n"
                 f"监控交易对: {', '.join(self.config['monitored_symbols'])}\n"
                 f"价格警报阈值: {self.config['price_alert_threshold']}%\n"
                 f"交易量警报阈值: {self.config['volume_alert_threshold']}%\n"
                 f"检查间隔: {self.config['check_interval_minutes']}分钟",
            parse_mode="Markdown"
        )
    
    async def cmd_price(self, update, context):
        """处理/price命令"""
        chat_id = update.effective_chat.id
        
        latest_data_file = "../results/combined/latest_combined.csv"
        if not os.path.exists(latest_data_file):
            await context.bot.send_message(
                chat_id=chat_id,
                text="❌ 暂无价格数据"
            )
            return
        
        try:
            df = pd.read_csv(latest_data_file)
            
            message = "💰 *当前价格*\n\n"
            for _, row in df.iterrows():
                symbol = row["symbol"]
                
                # 收集所有交易所的价格
                prices = {}
                for col in row.index:
                    if col.endswith("_price") and not pd.isna(row[col]):
                        exchange = col.replace("_price", "")
                        prices[exchange] = row[col]
                
                if prices:
                    message += f"*{symbol}*\n"
                    for exchange, price in prices.items():
                        message += f"• {exchange}: ${price:.2f}\n"
                    message += "\n"
            
            await context.bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"处理价格命令失败: {e}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ 获取价格数据失败: {str(e)}"
            )
    
    async def cmd_news(self, update, context):
        """处理/news命令"""
        chat_id = update.effective_chat.id
        
        announcements_file = "../results/announcements/announcements_data.json"
        if not os.path.exists(announcements_file):
            await context.bot.send_message(
                chat_id=chat_id,
                text="❌ 暂无公告数据"
            )
            return
        
        try:
            with open(announcements_file, "r", encoding="utf-8") as f:
                announcements = json.load(f)
            
            # 按时间戳排序，最新的在前
            sorted_announcements = sorted(
                announcements,
                key=lambda x: x.get("timestamp", ""),
                reverse=True
            )
            
            message = "📰 *最新交易所公告*\n\n"
            for announcement in sorted_announcements[:5]:  # 只显示最新的5条
                exchange = announcement.get("exchange", "Unknown")
                title = announcement.get("title", "No Title")
                url = announcement.get("url", "#")
                date = announcement.get("date", "Unknown Date")
                
                message += f"*{exchange}* - {date}\n"
                message += f"*{title}*\n"
                message += f"[查看详情]({url})\n\n"
            
            await context.bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="Markdown",
                disable_web_page_preview=True
            )
        except Exception as e:
            logger.error(f"处理新闻命令失败: {e}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ 获取公告数据失败: {str(e)}"
            )
    
    async def cmd_subscribe(self, update, context):
        """处理/subscribe命令"""
        chat_id = update.effective_chat.id
        
        # 检查是否已订阅
        if chat_id in self.config["telegram_chat_ids"]:
            await context.bot.send_message(
                chat_id=chat_id,
                text="✅ 您已经订阅了通知"
            )
            return
        
        # 添加到订阅列表
        self.config["telegram_chat_ids"].append(chat_id)
        self.save_config()
        
        await context.bot.send_message(
            chat_id=chat_id,
            text="✅ 订阅成功！您将收到价格警报和新公告通知"
        )
    
    def run(self):
        """运行集成监控"""
        try:
            # 创建日志目录
            os.makedirs("../logs", exist_ok=True)
            
            # 创建默认配置文件（如果不存在）
            if not os.path.exists(self.config_file):
                self.save_config()
            
            # 启动Telegram机器人和计划任务
            bot_thread = threading.Thread(target=lambda: asyncio.run(self.start_bot()))
            bot_thread.daemon = True
            bot_thread.start()
            
            # 运行计划任务
            self.run_scheduled_tasks()
        except Exception as e:
            logger.error(f"集成监控运行失败: {e}")

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("使用方法: python integrated_monitor.py <telegram_bot_token>")
        sys.exit(1)
    
    telegram_token = sys.argv[1]
    
    try:
        monitor = IntegratedMonitor(telegram_token)
        monitor.run()
    except KeyboardInterrupt:
        logger.info("集成监控程序已手动停止")
    except Exception as e:
        logger.error(f"集成监控程序发生错误: {e}")

if __name__ == "__main__":
    main()
