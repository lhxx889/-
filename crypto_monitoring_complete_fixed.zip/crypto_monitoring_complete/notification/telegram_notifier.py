#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram通知模块
用于向Telegram发送加密货币监控通知
"""

import os
import sys
import json
import logging
import asyncio
from telegram import Bot
from telegram.error import TelegramError
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../logs/telegram_notifier.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("telegram_notifier")

class TelegramNotifier:
    """Telegram通知类"""
    
    def __init__(self, token):
        """初始化通知器"""
        self.token = token
        self.bot = Bot(token=token)
        self.config_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "integrated_config.json")
        self.load_config()
    
    def load_config(self):
        """加载配置文件"""
        default_config = {
            "telegram_chat_ids": [],
            "notification_level": "all",  # all, important, summary
            "daily_summary": True,
            "price_notifications": True,
            "announcement_notifications": True
        }
        
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    self.config = json.load(f)
                logger.info("已加载配置文件")
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
                self.config = default_config
        else:
            logger.warning("配置文件不存在，使用默认配置")
            self.config = default_config
            self.save_config()
    
    def save_config(self):
        """保存配置到文件"""
        try:
            with open(self.config_file, "w") as f:
                json.dump(self.config, f, indent=4)
            logger.info("配置已保存")
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
    
    async def send_message(self, message, parse_mode="Markdown", disable_web_page_preview=True):
        """发送消息到所有订阅的聊天"""
        if not self.config.get("telegram_chat_ids"):
            logger.warning("没有订阅的聊天ID，消息未发送")
            return False
        
        success = False
        for chat_id in self.config["telegram_chat_ids"]:
            try:
                await self.bot.send_message(
                    chat_id=chat_id,
                    text=message,
                    parse_mode=parse_mode,
                    disable_web_page_preview=disable_web_page_preview
                )
                success = True
                logger.info(f"消息已发送到聊天ID: {chat_id}")
            except TelegramError as e:
                logger.error(f"发送消息到聊天ID {chat_id} 失败: {e}")
        
        return success
    
    async def send_price_alert(self, symbol, exchange, price, change_pct, direction):
        """发送价格警报"""
        if not self.config.get("price_notifications", True):
            logger.info("价格通知已禁用")
            return False
        
        emoji = "🔺" if direction == "上涨" else "🔻"
        message = f"{emoji} *价格警报*\n\n"
        message += f"*{symbol}* 在 {exchange} {direction}了 *{change_pct:.2f}%*\n"
        message += f"当前价格: ${price:.2f}\n"
        message += f"\n时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        return await self.send_message(message)
    
    async def send_volume_alert(self, symbol, exchange, volume, change_pct):
        """发送交易量警报"""
        if not self.config.get("price_notifications", True):
            logger.info("价格通知已禁用")
            return False
        
        message = f"📊 *交易量警报*\n\n"
        message += f"*{symbol}* 在 {exchange} 交易量激增 *{change_pct:.2f}%*\n"
        message += f"当前交易量: {volume:.2f}\n"
        message += f"\n时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        return await self.send_message(message)
    
    async def send_announcement_notification(self, exchange, title, url, date):
        """发送公告通知"""
        if not self.config.get("announcement_notifications", True):
            logger.info("公告通知已禁用")
            return False
        
        message = f"📢 *新公告*\n\n"
        message += f"*{exchange}* - {date}\n"
        message += f"*{title}*\n"
        message += f"[查看详情]({url})"
        
        return await self.send_message(message)
    
    async def send_daily_summary(self, price_data, announcement_data):
        """发送每日摘要"""
        if not self.config.get("daily_summary", True):
            logger.info("每日摘要已禁用")
            return False
        
        message = f"📊 *加密货币监控每日摘要* - {datetime.now().strftime('%Y-%m-%d')}\n\n"
        
        # 添加价格数据
        if price_data:
            message += "*当前价格*\n"
            for symbol, price in price_data.items():
                message += f"• {symbol}: ${price:.2f}\n"
            message += "\n"
        
        # 添加公告数据
        if announcement_data:
            message += "*最新公告*\n"
            for announcement in announcement_data:
                exchange = announcement.get("exchange", "Unknown")
                title = announcement.get("title", "No Title")
                message += f"• {exchange}: {title}\n"
        
        return await self.send_message(message)
    
    async def add_subscriber(self, chat_id):
        """添加订阅者"""
        if chat_id not in self.config["telegram_chat_ids"]:
            self.config["telegram_chat_ids"].append(chat_id)
            self.save_config()
            await self.bot.send_message(
                chat_id=chat_id,
                text="✅ 订阅成功！您将收到价格警报和新公告通知"
            )
            logger.info(f"新订阅者已添加: {chat_id}")
            return True
        else:
            await self.bot.send_message(
                chat_id=chat_id,
                text="✅ 您已经订阅了通知"
            )
            return False
    
    async def remove_subscriber(self, chat_id):
        """移除订阅者"""
        if chat_id in self.config["telegram_chat_ids"]:
            self.config["telegram_chat_ids"].remove(chat_id)
            self.save_config()
            await self.bot.send_message(
                chat_id=chat_id,
                text="✅ 已取消订阅通知"
            )
            logger.info(f"订阅者已移除: {chat_id}")
            return True
        else:
            await self.bot.send_message(
                chat_id=chat_id,
                text="❌ 您尚未订阅通知"
            )
            return False
    
    async def send_welcome_message(self, chat_id):
        """发送欢迎消息"""
        message = (
            "👋 *欢迎使用加密货币监控机器人！*\n\n"
            "此机器人将为您提供：\n"
            "• 价格异常波动警报\n"
            "• 交易量激增提醒\n"
            "• 交易所新公告通知\n"
            "• 每日市场摘要\n\n"
            "使用 /help 查看可用命令\n"
            "使用 /subscribe 订阅通知"
        )
        
        try:
            await self.bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="Markdown"
            )
            return True
        except TelegramError as e:
            logger.error(f"发送欢迎消息失败: {e}")
            return False
    
    async def send_help_message(self, chat_id):
        """发送帮助消息"""
        message = (
            "📚 *可用命令*\n\n"
            "/start - 启动机器人\n"
            "/help - 显示帮助信息\n"
            "/status - 查看监控系统状态\n"
            "/price - 查看当前价格\n"
            "/news - 查看最新公告\n"
            "/subscribe - 订阅通知\n"
            "/unsubscribe - 取消订阅通知\n"
            "/settings - 通知设置"
        )
        
        try:
            await self.bot.send_message(
                chat_id=chat_id,
                text=message,
                parse_mode="Markdown"
            )
            return True
        except TelegramError as e:
            logger.error(f"发送帮助消息失败: {e}")
            return False

async def test_notifier(token, chat_id):
    """测试通知器"""
    notifier = TelegramNotifier(token)
    
    # 添加测试聊天ID
    if chat_id:
        notifier.config["telegram_chat_ids"] = [chat_id]
        notifier.save_config()
    
    # 发送测试消息
    await notifier.send_message("🧪 这是一条测试消息，如果您看到此消息，说明Telegram通知功能正常工作！")
    
    logger.info("测试消息已发送")

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("使用方法: python telegram_notifier.py <telegram_bot_token> [chat_id]")
        sys.exit(1)
    
    token = sys.argv[1]
    chat_id = sys.argv[2] if len(sys.argv) > 2 else None
    
    try:
        # 创建日志目录
        os.makedirs("../logs", exist_ok=True)
        
        # 运行测试
        asyncio.run(test_notifier(token, chat_id))
    except KeyboardInterrupt:
        logger.info("通知测试已手动停止")
    except Exception as e:
        logger.error(f"通知测试发生错误: {e}")

if __name__ == "__main__":
    main()
