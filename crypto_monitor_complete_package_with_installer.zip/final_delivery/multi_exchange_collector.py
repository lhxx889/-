"""
多交易所加密货币异动监控系统 - 多交易所数据采集器
负责从多个交易所获取数据并进行标准化处理和存储
"""

import requests
import time
import json
import sqlite3
import logging
import os
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
import numpy as np

# 导入交易所适配器
from binance_adapter import BinanceExchangeAPI

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("multi_exchange_collector")

class ExchangeAPI:
    """交易所API抽象基类，定义所有交易所必须实现的接口"""
    
    @property
    def exchange_name(self) -> str:
        """获取交易所名称"""
        raise NotImplementedError
    
    @property
    def exchange_id(self) -> str:
        """获取交易所唯一标识符"""
        raise NotImplementedError
    
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的ticker数据"""
        raise NotImplementedError
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取特定交易对的ticker数据"""
        raise NotImplementedError
    
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """获取所有可交易的交易对信息"""
        raise NotImplementedError
    
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """将交易所特定的ticker数据格式转换为标准格式"""
        raise NotImplementedError
    
    def get_exchange_url(self, symbol: str) -> str:
        """获取交易对在交易所的URL链接"""
        raise NotImplementedError

class GateioExchangeAPI(ExchangeAPI):
    """Gate.io交易所API适配器"""
    
    # Gate.io API基础URL
    BASE_URL = "https://api.gateio.ws/api/v4"
    
    # API端点
    ENDPOINTS = {
        "tickers": "/spot/tickers",
        "currency_pairs": "/spot/currency_pairs",
        "ticker": "/spot/tickers/{currency_pair}"
    }
    
    def __init__(self):
        """初始化Gate.io交易所API适配器"""
        logger.info("Gate.io交易所API适配器初始化")
    
    @property
    def exchange_name(self) -> str:
        """获取交易所名称"""
        return "Gate.io"
    
    @property
    def exchange_id(self) -> str:
        """获取交易所唯一标识符"""
        return "gateio"
    
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """
        获取所有交易对的ticker数据
        
        Returns:
            所有交易对的ticker数据列表
        """
        logger.info("获取Gate.io所有交易对的ticker数据")
        url = f"{self.BASE_URL}{self.ENDPOINTS['tickers']}"
        response = self._make_request(url)
        if response:
            logger.info(f"成功获取Gate.io {len(response)}个交易对的ticker数据")
            return response
        return []
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取特定交易对的ticker数据
        
        Args:
            symbol: 交易对符号，如"BTC_USDT"
            
        Returns:
            交易对的ticker数据或None（如果请求失败）
        """
        logger.info(f"获取Gate.io {symbol}的ticker数据")
        endpoint = self.ENDPOINTS["ticker"].format(currency_pair=symbol)
        url = f"{self.BASE_URL}{endpoint}"
        return self._make_request(url)
    
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """
        获取所有可交易的交易对信息
        
        Returns:
            所有可交易的交易对信息列表
        """
        logger.info("获取Gate.io所有可交易的交易对信息")
        url = f"{self.BASE_URL}{self.ENDPOINTS['currency_pairs']}"
        response = self._make_request(url)
        if response:
            logger.info(f"成功获取Gate.io {len(response)}个交易对信息")
            return response
        return []
    
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """
        将Gate.io特定的ticker数据格式转换为标准格式
        
        Args:
            ticker: Gate.io特定的ticker数据
            
        Returns:
            标准化的ticker数据
        """
        try:
            return {
                "exchange": self.exchange_id,
                "exchange_name": self.exchange_name,
                "symbol": ticker.get("currency_pair", ""),
                "original_symbol": ticker.get("currency_pair", ""),
                "price": float(ticker.get("last", 0)),
                "volume_24h": float(ticker.get("base_volume", 0)),
                "change_24h": float(ticker.get("change_percentage", 0)),
                "high_24h": float(ticker.get("high_24h", 0)),
                "low_24h": float(ticker.get("low_24h", 0)),
                "timestamp": ticker.get("timestamp", datetime.now().isoformat()),
                "original_data": ticker
            }
        except (ValueError, TypeError) as e:
            logger.warning(f"标准化Gate.io ticker数据失败: {str(e)}")
            return {
                "exchange": self.exchange_id,
                "exchange_name": self.exchange_name,
                "symbol": ticker.get("currency_pair", ""),
                "original_symbol": ticker.get("currency_pair", ""),
                "price": 0.0,
                "volume_24h": 0.0,
                "change_24h": 0.0,
                "high_24h": 0.0,
                "low_24h": 0.0,
                "timestamp": datetime.now().isoformat(),
                "original_data": ticker
            }
    
    def get_exchange_url(self, symbol: str) -> str:
        """
        获取交易对在Gate.io的URL链接
        
        Args:
            symbol: 交易对符号，如"BTC_USDT"
            
        Returns:
            交易对在Gate.io的URL链接
        """
        return f"https://www.gate.io/trade/{symbol}"
    
    def _make_request(self, url: str, params: Dict = None) -> Optional[Any]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API端点URL
            params: 请求参数
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"Gate.io API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"Gate.io API请求最终失败: {str(e)}")
                    return None
            except json.JSONDecodeError as e:
                logger.error(f"解析Gate.io API响应JSON失败: {str(e)}")
                return None

class ExchangeFactory:
    """交易所工厂类，负责创建和管理交易所实例"""
    
    def __init__(self):
        """初始化交易所工厂"""
        self.exchanges = {}
        self.register_default_exchanges()
        logger.info("交易所工厂初始化完成")
    
    def register_default_exchanges(self):
        """注册默认支持的交易所"""
        self.register_exchange("gateio", GateioExchangeAPI)
        self.register_exchange("binance", BinanceExchangeAPI)
        logger.info("已注册默认交易所: Gate.io, Binance")
    
    def register_exchange(self, exchange_id: str, exchange_class):
        """
        注册新的交易所
        
        Args:
            exchange_id: 交易所ID
            exchange_class: 交易所类
        """
        self.exchanges[exchange_id] = exchange_class
        logger.info(f"已注册交易所: {exchange_id}")
    
    def create_exchange(self, exchange_id: str) -> Optional[ExchangeAPI]:
        """
        创建交易所实例
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            交易所实例或None（如果交易所不存在）
        """
        if exchange_id in self.exchanges:
            return self.exchanges[exchange_id]()
        logger.warning(f"未找到交易所: {exchange_id}")
        return None
    
    def get_all_exchanges(self) -> List[ExchangeAPI]:
        """
        获取所有注册的交易所实例
        
        Returns:
            所有交易所实例列表
        """
        return [exchange_class() for exchange_class in self.exchanges.values()]
    
    def get_exchange_ids(self) -> List[str]:
        """
        获取所有注册的交易所ID
        
        Returns:
            所有交易所ID列表
        """
        return list(self.exchanges.keys())

class MultiExchangeDataCollector:
    """多交易所数据采集器，负责从多个交易所获取数据并进行标准化处理"""
    
    def __init__(self, db_path: str = "crypto_data.db", cache_duration: int = 3600):
        """
        初始化多交易所数据采集器
        
        Args:
            db_path: SQLite数据库路径
            cache_duration: 缓存有效期（秒）
        """
        self.db_path = db_path
        self.cache_duration = cache_duration
        self.memory_cache = {}
        self.last_update_time = {}
        
        # 初始化交易所工厂
        self.exchange_factory = ExchangeFactory()
        
        # 初始化数据库
        self._init_database()
        
        logger.info("多交易所数据采集模块初始化完成")
    
    def _init_database(self) -> None:
        """初始化SQLite数据库，创建必要的表"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 创建交易所信息表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS exchanges (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                last_updated TIMESTAMP
            )
            ''')
            
            # 创建币种信息表（添加exchange字段）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS coins (
                id TEXT,
                exchange TEXT,
                symbol TEXT NOT NULL,
                name TEXT,
                last_updated TIMESTAMP,
                PRIMARY KEY (exchange, symbol)
            )
            ''')
            
            # 创建价格历史表（添加exchange字段）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                volume_24h REAL,
                change_percentage_24h REAL,
                timestamp TIMESTAMP NOT NULL,
                FOREIGN KEY (exchange, symbol) REFERENCES coins(exchange, symbol)
            )
            ''')
            
            # 创建异常检测记录表（添加exchange字段）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS anomaly_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                old_price REAL NOT NULL,
                change_percentage REAL NOT NULL,
                volume_24h REAL,
                volume_change_percentage REAL,
                detected_at TIMESTAMP NOT NULL,
                is_notified BOOLEAN DEFAULT 0,
                FOREIGN KEY (exchange, symbol) REFERENCES coins(exchange, symbol)
            )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("数据库初始化成功")
        except Exception as e:
            logger.error(f"数据库初始化失败: {str(e)}")
            raise
    
    def get_exchange(self, exchange_id: str) -> Optional[ExchangeAPI]:
        """
        获取指定交易所的API实例
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            交易所API实例或None（如果交易所不存在）
        """
        return self.exchange_factory.create_exchange(exchange_id)
    
    def get_all_exchanges(self) -> List[ExchangeAPI]:
        """
        获取所有交易所的API实例
        
        Returns:
            所有交易所API实例列表
        """
        return self.exchange_factory.get_all_exchanges()
    
    def fetch_all_tickers_from_exchange(self, exchange_id: str) -> List[Dict]:
        """
        从指定交易所获取所有ticker数据
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            所有ticker数据列表
        """
        exchange = self.get_exchange(exchange_id)
        if not exchange:
            logger.error(f"未找到交易所: {exchange_id}")
            return []
        
        logger.info(f"从{exchange.exchange_name}获取所有ticker数据")
        tickers = exchange.fetch_all_tickers()
        
        # 标准化数据
        normalized_tickers = []
        for ticker in tickers:
            normalized_ticker = exchange.normalize_ticker_data(ticker)
            normalized_tickers.append(normalized_ticker)
        
        return normalized_tickers
    
    def fetch_all_tickers_from_all_exchanges(self) -> Dict[str, List[Dict]]:
        """
        从所有交易所获取ticker数据
        
        Returns:
            所有交易所的ticker数据字典，键为交易所ID，值为ticker数据列表
        """
        result = {}
        
        for exchange in self.get_all_exchanges():
            exchange_id = exchange.exchange_id
            tickers = self.fetch_all_tickers_from_exchange(exchange_id)
            result[exchange_id] = tickers
            
            # 更新缓存
            cache_key = f"{exchange_id}_tickers"
            self.memory_cache[cache_key] = tickers
            self.last_update_time[cache_key] = time.time()
        
        return result
    
    def save_ticker_data(self, exchange_id: str, tickers: List[Dict]) -> None:
        """
        将ticker数据保存到数据库
        
        Args:
            exchange_id: 交易所ID
            tickers: ticker数据列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            current_time = datetime.now().isoformat()
            
            # 更新交易所信息
            exchange = self.get_exchange(exchange_id)
            if exchange:
                cursor.execute(
                    "INSERT OR REPLACE INTO exchanges (id, name, last_updated) VALUES (?, ?, ?)",
                    (exchange_id, exchange.exchange_name, current_time)
                )
            
            for ticker in tickers:
                symbol = ticker.get("symbol")
                if not symbol:
                    continue
                
                # 更新或插入币种信息
                cursor.execute(
                    "INSERT OR REPLACE INTO coins (id, exchange, symbol, last_updated) VALUES (?, ?, ?, ?)",
                    (f"{exchange_id}_{symbol}", exchange_id, symbol, current_time)
                )
                
                # 插入价格历史
                try:
                    price = ticker.get("price", 0)
                    volume_24h = ticker.get("volume_24h", 0)
                    change_percentage_24h = ticker.get("change_24h", 0)
                    
                    cursor.execute(
                        """
                        INSERT INTO price_history 
                        (exchange, symbol, price, volume_24h, change_percentage_24h, timestamp) 
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (exchange_id, symbol, price, volume_24h, change_percentage_24h, current_time)
                    )
                except (ValueError, TypeError) as e:
                    logger.warning(f"处理{exchange_id}交易所币种{symbol}数据时出错: {str(e)}")
                    continue
            
            conn.commit()
            conn.close()
            logger.info(f"成功保存{exchange_id}交易所{len(tickers)}个币种的ticker数据到数据库")
        except Exception as e:
            logger.error(f"保存{exchange_id}交易所ticker数据到数据库失败: {str(e)}")
    
    def get_latest_price_data(self, exchange_id: str = None, symbol: str = None) -> Dict:
        """
        获取最新价格数据
        
        Args:
            exchange_id: 交易所ID，如果为None则返回所有交易所数据
            symbol: 币种符号，如果为None则返回所有币种数据
            
        Returns:
            最新价格数据字典
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query_conditions = []
            query_params = []
            
            if exchange_id:
                query_conditions.append("ph.exchange = ?")
                query_params.append(exchange_id)
            
            if symbol:
                query_conditions.append("ph.symbol = ?")
                query_params.append(symbol)
            
            where_clause = ""
            if query_conditions:
                where_clause = f"WHERE {' AND '.join(query_conditions)}"
            
            cursor.execute(
                f"""
                SELECT ph.exchange, ph.symbol, ph.price, ph.volume_24h, ph.change_percentage_24h, ph.timestamp
                FROM price_history ph
                JOIN (
                    SELECT exchange, symbol, MAX(timestamp) as max_time
                    FROM price_history
                    {where_clause}
                    GROUP BY exchange, symbol
                ) latest
                ON ph.exchange = latest.exchange AND ph.symbol = latest.symbol AND ph.timestamp = latest.max_time
                """,
                query_params
            )
            
            results = cursor.fetchall()
            conn.close()
            
            data = {}
            for row in results:
                exchange = row[0]
                symbol = row[1]
                
                if exchange not in data:
                    data[exchange] = {}
                
                data[exchange][symbol] = {
                    "price": row[2],
                    "volume_24h": row[3],
                    "change_percentage_24h": row[4],
                    "timestamp": row[5]
                }
            
            return data
        except Exception as e:
            logger.error(f"获取最新价格数据失败: {str(e)}")
            return {}
    
    def update_data(self, enabled_exchanges: List[str] = None) -> Dict[str, bool]:
        """
        更新所有交易所的数据
        
        Args:
            enabled_exchanges: 启用的交易所ID列表，如果为None则更新所有交易所
            
        Returns:
            更新结果字典，键为交易所ID，值为更新是否成功
        """
        results = {}
        
        # 如果未指定启用的交易所，则使用所有交易所
        if enabled_exchanges is None:
            enabled_exchanges = self.exchange_factory.get_exchange_ids()
        
        for exchange_id in enabled_exchanges:
            try:
                exchange = self.get_exchange(exchange_id)
                if not exchange:
                    logger.error(f"未找到交易所: {exchange_id}")
                    results[exchange_id] = False
                    continue
                
                tickers = self.fetch_all_tickers_from_exchange(exchange_id)
                if tickers:
                    self.save_ticker_data(exchange_id, tickers)
                    cache_key = f"{exchange_id}_tickers"
                    self.memory_cache[cache_key] = tickers
                    self.last_update_time[cache_key] = time.time()
                    results[exchange_id] = True
                else:
                    results[exchange_id] = False
            except Exception as e:
                logger.error(f"更新{exchange_id}交易所数据失败: {str(e)}")
                results[exchange_id] = False
        
        return results
    
    def get_cached_tickers(self, exchange_id: str) -> List[Dict]:
        """
        获取缓存的ticker数据，如果缓存过期则重新获取
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            ticker数据列表
        """
        cache_key = f"{exchange_id}_tickers"
        current_time = time.time()
        
        if (
            cache_key not in self.memory_cache or
            cache_key not in self.last_update_time or
            current_time - self.last_update_time[cache_key] > self.cache_duration
        ):
            logger.info(f"{exchange_id}交易所缓存过期，重新获取ticker数据")
            tickers = self.fetch_all_tickers_from_exchange(exchange_id)
            if tickers:
                self.memory_cache[cache_key] = tickers
                self.last_update_time[cache_key] = current_time
        
        return self.memory_cache.get(cache_key, [])
    
    def get_historical_price_data(self, exchange_id: str, symbol: str, hours: int = 24) -> List[Dict]:
        """
        获取历史价格数据
        
        Args:
            exchange_id: 交易所ID
            symbol: 币种符号
            hours: 获取过去多少小时的数据
            
        Returns:
            历史价格数据列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute(
                """
                SELECT exchange, symbol, price, volume_24h, change_percentage_24h, timestamp
                FROM price_history
                WHERE exchange = ? AND symbol = ? AND timestamp >= datetime('now', '-' || ? || ' hours')
                ORDER BY timestamp ASC
                """,
                (exchange_id, symbol, hours)
            )
            
            results = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in results]
        except Exception as e:
            logger.error(f"获取历史价格数据失败: {str(e)}")
            return []
    
    def clean_old_data(self, days: int = 7) -> None:
        """
        清理旧数据以节省空间
        
        Args:
            days: 保留最近多少天的数据
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(
                "DELETE FROM price_history WHERE timestamp < datetime('now', '-' || ? || ' days')",
                (days,)
            )
            
            deleted_rows = cursor.rowcount
            conn.commit()
            conn.close()
            
            logger.info(f"已清理{deleted_rows}条{days}天前的旧数据")
        except Exception as e:
            logger.error(f"清理旧数据失败: {str(e)}")


# 测试代码
if __name__ == "__main__":
    # 创建多交易所数据采集器实例
    collector = MultiExchangeDataCollector()
    
    # 测试获取所有交易所
    print("获取所有交易所...")
    exchanges = collector.get_all_exchanges()
    print(f"共获取到 {len(exchanges)} 个交易所")
    for exchange in exchanges:
        print(f"  - {exchange.exchange_name} ({exchange.exchange_id})")
    
    # 测试从所有交易所获取ticker数据
    print("\n从所有交易所获取ticker数据...")
    all_tickers = collector.fetch_all_tickers_from_all_exchanges()
    for exchange_id, tickers in all_tickers.items():
        print(f"  - {exchange_id}: 获取到 {len(tickers)} 个ticker数据")
    
    # 测试保存数据到数据库
    print("\n保存数据到数据库...")
    for exchange_id, tickers in all_tickers.items():
        collector.save_ticker_data(exchange_id, tickers)
    
    # 测试获取最新价格数据
    print("\n获取最新价格数据...")
    latest_data = collector.get_latest_price_data()
    for exchange_id, symbols in latest_data.items():
        print(f"  - {exchange_id}: 获取到 {len(symbols)} 个币种的最新价格数据")
    
    # 测试获取特定交易所和币种的最新价格数据
    print("\n获取特定交易所和币种的最新价格数据...")
    btc_data = collector.get_latest_price_data("binance", "BTC_USDT")
    if btc_data and "binance" in btc_data and "BTC_USDT" in btc_data["binance"]:
        print(f"  - 币安 BTC_USDT: 价格 {btc_data['binance']['BTC_USDT']['price']}, 24h成交量 {btc_data['binance']['BTC_USDT']['volume_24h']}")
    
    # 测试获取历史价格数据
    print("\n获取历史价格数据...")
    history = collector.get_historical_price_data("binance", "BTC_USDT", 24)
    print(f"  - 币安 BTC_USDT: 获取到 {len(history)} 条历史价格数据")
    
    print("\n测试完成!")
