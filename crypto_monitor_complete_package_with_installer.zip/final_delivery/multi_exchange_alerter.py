"""
多交易所加密货币异动监控系统 - 多交易所告警器
负责格式化和发送多交易所异常告警
"""

import logging
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import json
import os
import requests

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("multi_exchange_alerter")

class TelegramAlerter:
    """Telegram告警基类"""
    
    def __init__(self, config_file: str = "telegram_config.json"):
        """
        初始化Telegram告警器
        
        Args:
            config_file: Telegram配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.bot_token = self.config.get("bot_token", "")
        self.chat_id = self.config.get("chat_id", "")
        
        logger.info("Telegram告警器初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载Telegram配置
        
        Returns:
            配置字典
        """
        default_config = {
            "bot_token": "",
            "chat_id": ""
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    logger.info("从配置文件加载Telegram配置成功")
                    return config
            else:
                logger.warning(f"Telegram配置文件 {self.config_file} 不存在，使用默认配置")
                return default_config
        except Exception as e:
            logger.error(f"加载Telegram配置文件失败: {str(e)}")
            return default_config
    
    def is_configured(self) -> bool:
        """
        检查Telegram是否已配置
        
        Returns:
            是否已配置
        """
        return bool(self.bot_token and self.chat_id)
    
    def send_message(self, message: str) -> bool:
        """
        发送Telegram消息
        
        Args:
            message: 消息内容
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送消息")
            return False
        
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            data = {
                "chat_id": self.chat_id,
                "text": message,
                "parse_mode": "Markdown"
            }
            
            response = requests.post(url, data=data, timeout=10)
            response.raise_for_status()
            
            logger.info("Telegram消息发送成功")
            return True
        except Exception as e:
            logger.error(f"发送Telegram消息失败: {str(e)}")
            return False

class MultiExchangeAlerter:
    """多交易所告警类，负责格式化和发送多交易所异常告警"""
    
    def __init__(self, telegram_alerter: TelegramAlerter):
        """
        初始化多交易所告警器
        
        Args:
            telegram_alerter: Telegram告警器实例
        """
        self.telegram_alerter = telegram_alerter
        logger.info("多交易所告警模块初始化完成")
    
    def format_alert_message(self, anomaly: Dict) -> str:
        """
        格式化告警消息，区分不同交易所
        
        Args:
            anomaly: 异常数据
            
        Returns:
            格式化后的消息
        """
        try:
            # 获取异常类型、交易所和币种
            anomaly_type = anomaly.get("type", "unknown")
            exchange = anomaly.get("exchange", "unknown")
            exchange_name = anomaly.get("exchange_name", exchange)
            symbol = anomaly.get("symbol", "未知币种")
            
            # 构建消息标题（添加交易所标识）
            if anomaly_type == "price":
                change_pct = anomaly.get("price_change_pct", 0)
                direction = "上涨" if change_pct > 0 else "下跌"
                title = f"🚨 [{exchange_name}] 价格异动警报: {symbol} {direction} {abs(change_pct):.2f}%"
            elif anomaly_type == "volume":
                change_pct = anomaly.get("volume_change_pct", 0)
                title = f"📊 [{exchange_name}] 交易量异动警报: {symbol} 增加 {change_pct:.2f}%"
            else:
                title = f"⚠️ [{exchange_name}] 异常警报: {symbol}"
            
            # 构建消息内容
            message_parts = [title, ""]
            
            # 添加交易所信息
            message_parts.append(f"交易所: {exchange_name}")
            
            # 添加价格信息
            if anomaly_type == "price":
                current_price = anomaly.get("current_price", 0)
                reference_price = anomaly.get("reference_price", 0)
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"参考价格: {reference_price}")
                message_parts.append(f"变化幅度: {change_pct:.2f}%")
                
                # 添加交易量信息
                volume_24h = anomaly.get("volume_24h", 0)
                message_parts.append(f"24小时交易量: {volume_24h}")
            
            # 添加交易量信息
            elif anomaly_type == "volume":
                current_volume = anomaly.get("current_volume", 0)
                reference_volume = anomaly.get("reference_volume", 0)
                current_price = anomaly.get("current_price", 0)
                
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"当前交易量: {current_volume}")
                message_parts.append(f"参考交易量: {reference_volume}")
                message_parts.append(f"交易量增加: {change_pct:.2f}%")
            
            # 添加检测时间
            detected_at = anomaly.get("detected_at", datetime.now().isoformat())
            try:
                # 尝试将ISO格式转换为更易读的格式
                dt = datetime.fromisoformat(detected_at)
                formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                formatted_time = detected_at
            
            message_parts.append("")
            message_parts.append(f"检测时间: {formatted_time}")
            
            # 添加交易所链接
            exchange_url = anomaly.get("exchange_url", "")
            if exchange_url:
                message_parts.append("")
                message_parts.append(f"🔗 [在{exchange_name}上查看]({exchange_url})")
            
            # 合并消息
            return "\n".join(message_parts)
        
        except Exception as e:
            logger.error(f"格式化告警消息失败: {str(e)}")
            return f"[{anomaly.get('exchange_name', '未知交易所')}] 异常警报: {anomaly.get('symbol', '未知币种')}"
    
    def send_anomaly_alert(self, anomaly: Dict) -> bool:
        """
        发送异常告警
        
        Args:
            anomaly: 异常数据
            
        Returns:
            发送是否成功
        """
        message = self.format_alert_message(anomaly)
        return self.telegram_alerter.send_message(message)
    
    def send_batch_alerts(self, anomalies: List[Dict], max_batch: int = 5) -> int:
        """
        批量发送异常告警
        
        Args:
            anomalies: 异常列表
            max_batch: 最大批量发送数量
            
        Returns:
            成功发送的数量
        """
        if not anomalies:
            return 0
        
        # 限制批量发送数量
        anomalies_to_send = anomalies[:max_batch]
        
        success_count = 0
        for anomaly in anomalies_to_send:
            if self.send_anomaly_alert(anomaly):
                success_count += 1
                # 添加短暂延迟，避免触发Telegram限流
                time.sleep(1)
        
        logger.info(f"批量发送异常告警完成，成功: {success_count}/{len(anomalies_to_send)}")
        return success_count
    
    def send_system_status(self, enabled_exchanges: List[str], config: Dict) -> bool:
        """
        发送系统状态消息
        
        Args:
            enabled_exchanges: 启用的交易所ID列表
            config: 系统配置
            
        Returns:
            发送是否成功
        """
        try:
            # 获取交易所名称
            exchange_names = []
            for exchange_id in enabled_exchanges:
                if exchange_id == "gateio":
                    exchange_names.append("Gate.io")
                elif exchange_id == "binance":
                    exchange_names.append("Binance")
                else:
                    exchange_names.append(exchange_id)
            
            # 构建消息
            message = f"🚀 多交易所加密货币异动监控系统状态\n\n"
            message += f"🕒 当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            message += f"⚙️ 价格异动阈值: {config.get('price_threshold', 30.0)}%\n"
            message += f"⚙️ 交易量异动阈值: {config.get('volume_threshold', 200.0)}%\n"
            message += f"⚙️ 检查间隔: {config.get('check_interval', 60)}秒\n\n"
            
            # 添加启用的交易所信息
            message += f"📈 已启用交易所 ({len(exchange_names)}):\n"
            for name in exchange_names:
                message += f"  • {name}\n"
            
            return self.telegram_alerter.send_message(message)
        
        except Exception as e:
            logger.error(f"发送系统状态消息失败: {str(e)}")
            return False


# 测试代码
if __name__ == "__main__":
    # 创建Telegram告警器实例
    telegram_alerter = TelegramAlerter()
    
    # 创建多交易所告警器实例
    alerter = MultiExchangeAlerter(telegram_alerter)
    
    # 测试格式化告警消息
    print("测试格式化告警消息...")
    
    # 测试价格异常告警
    price_anomaly = {
        "exchange": "binance",
        "exchange_name": "Binance",
        "symbol": "BTC_USDT",
        "current_price": 50000.0,
        "reference_price": 45000.0,
        "price_change_pct": 11.11,
        "volume_24h": 1000000.0,
        "detected_at": datetime.now().isoformat(),
        "type": "price",
        "exchange_url": "https://www.binance.com/en/trade/BTCUSDT"
    }
    
    price_message = alerter.format_alert_message(price_anomaly)
    print("\n价格异常告警消息:")
    print(price_message)
    
    # 测试交易量异常告警
    volume_anomaly = {
        "exchange": "gateio",
        "exchange_name": "Gate.io",
        "symbol": "ETH_USDT",
        "current_volume": 500000.0,
        "reference_volume": 200000.0,
        "volume_change_pct": 150.0,
        "current_price": 3000.0,
        "detected_at": datetime.now().isoformat(),
        "type": "volume",
        "exchange_url": "https://www.gate.io/trade/ETH_USDT"
    }
    
    volume_message = alerter.format_alert_message(volume_anomaly)
    print("\n交易量异常告警消息:")
    print(volume_message)
    
    # 测试发送系统状态
    print("\n测试发送系统状态...")
    config = {
        "price_threshold": 30.0,
        "volume_threshold": 200.0,
        "check_interval": 60
    }
    enabled_exchanges = ["gateio", "binance"]
    
    status_message = alerter.send_system_status(enabled_exchanges, config)
    print(f"系统状态消息发送结果: {'成功' if status_message else '失败'}")
    
    # 如果Telegram已配置，测试发送告警
    if telegram_alerter.is_configured():
        print("\n测试发送告警...")
        result = alerter.send_anomaly_alert(price_anomaly)
        print(f"价格异常告警发送结果: {'成功' if result else '失败'}")
        
        time.sleep(2)  # 避免Telegram限流
        
        result = alerter.send_anomaly_alert(volume_anomaly)
        print(f"交易量异常告警发送结果: {'成功' if result else '失败'}")
    else:
        print("\nTelegram未配置，跳过发送测试")
    
    print("\n测试完成!")
