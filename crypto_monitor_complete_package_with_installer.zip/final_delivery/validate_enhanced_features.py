"""
多交易所加密货币监控系统 - 功能验证脚本
用于验证增强版币安适配器和CoinGecko备用数据源
"""

import os
import time
import logging
import json
from datetime import datetime

# 导入自定义模块
from enhanced_binance_adapter import BinanceExchangeAPI
from coingecko_adapter import CoinGeckoExchangeAPI
from updated_multi_exchange_collector import MultiExchangeDataCollector, GateioExchangeAPI

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("validation_enhanced.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("validation_enhanced")

def validate_enhanced_binance_adapter():
    """验证增强版币安适配器功能"""
    logger.info("=== 验证增强版币安适配器功能 ===")
    
    # 测试主网（可能会受到地理限制）
    logger.info("测试币安主网...")
    binance_main = BinanceExchangeAPI(use_testnet=False)
    main_pairs = binance_main.fetch_all_currency_pairs()
    logger.info(f"主网交易对数量: {len(main_pairs)}")
    
    # 测试测试网
    logger.info("\n测试币安测试网...")
    binance_test = BinanceExchangeAPI(use_testnet=True)
    test_pairs = binance_test.fetch_all_currency_pairs()
    logger.info(f"测试网交易对数量: {len(test_pairs)}")
    
    # 如果配置了代理，测试代理
    proxy_url = None  # 设置为您的代理URL，如 "http://10.10.1.10:3128"
    if proxy_url:
        logger.info("\n测试代理...")
        binance_proxy = BinanceExchangeAPI(proxy=proxy_url)
        proxy_pairs = binance_proxy.fetch_all_currency_pairs()
        logger.info(f"通过代理获取的交易对数量: {len(proxy_pairs)}")
    
    # 测试获取ticker数据
    logger.info("\n测试获取ticker数据...")
    if len(test_pairs) > 0:
        # 使用测试网
        test_symbol = test_pairs[0]["symbol"]
        logger.info(f"使用测试网获取{test_symbol}的ticker数据...")
        test_ticker = binance_test.fetch_ticker(test_symbol)
        if test_ticker:
            logger.info(f"测试网{test_symbol}的价格: {test_ticker.get('lastPrice', 'N/A')}")
            
            # 测试标准化
            normalized = binance_test.normalize_ticker_data(test_ticker)
            logger.info(f"标准化后的数据: {normalized['symbol']}, 价格: {normalized['price']}")
    
    logger.info("增强版币安适配器验证完成!")
    return True

def validate_coingecko_adapter():
    """验证CoinGecko适配器功能"""
    logger.info("\n=== 验证CoinGecko适配器功能 ===")
    
    # 创建CoinGecko API适配器实例
    coingecko = CoinGeckoExchangeAPI()
    
    # 测试获取所有币种列表
    logger.info("获取所有币种列表...")
    currency_pairs = coingecko.fetch_all_currency_pairs()
    logger.info(f"共获取到 {len(currency_pairs)} 个币种")
    if currency_pairs:
        logger.info("前5个币种:")
        for pair in currency_pairs[:5]:
            logger.info(f"  - {pair['symbol']}: ID={pair['id']}")
    
    # 测试获取市场数据
    logger.info("\n获取市场数据...")
    tickers = coingecko.fetch_all_tickers()
    logger.info(f"共获取到 {len(tickers)} 个币种的市场数据")
    if tickers:
        logger.info("前5个币种的市场数据:")
        for ticker in tickers[:5]:
            logger.info(f"  - {ticker['symbol'].upper()}: 价格=${ticker['current_price']}, 24h交易量=${ticker['total_volume']}")
    
    # 测试获取特定币种数据
    logger.info("\n获取特定币种数据...")
    btc_data = coingecko.fetch_ticker("BTC")
    if btc_data:
        logger.info(f"比特币(BTC)数据:")
        logger.info(f"  - 当前价格: ${btc_data['market_data']['current_price']['usd']}")
        logger.info(f"  - 24h交易量: ${btc_data['market_data']['total_volume']['usd']}")
        logger.info(f"  - 市值: ${btc_data['market_data']['market_cap']['usd']}")
    
    # 测试标准化数据
    logger.info("\n测试标准化数据...")
    if tickers:
        normalized = coingecko.normalize_ticker_data(tickers[0])
        logger.info("原始数据:")
        logger.info(f"  - {tickers[0]['name']} ({tickers[0]['symbol'].upper()})")
        logger.info("标准化数据:")
        logger.info(f"  - 交易所: {normalized['exchange_name']}")
        logger.info(f"  - 交易对: {normalized['symbol']}")
        logger.info(f"  - 价格: ${normalized['price']}")
        logger.info(f"  - 24h交易量: ${normalized['volume_24h']}")
        logger.info(f"  - 24h变化百分比: {normalized['change_24h']}%")
    
    logger.info("CoinGecko适配器验证完成!")
    return True

def validate_multi_exchange_collector():
    """验证更新版多交易所数据采集器功能"""
    logger.info("\n=== 验证更新版多交易所数据采集器功能 ===")
    
    # 创建配置
    config = {
        "use_binance_testnet": True,  # 使用币安测试网
        "proxy": None,  # 代理服务器URL
        "fallback_exchanges": {
            "binance": "coingecko"  # 币安的备用数据源为CoinGecko
        }
    }
    
    # 创建多交易所数据采集器实例
    collector = MultiExchangeDataCollector(db_path="validation_enhanced.db", config=config)
    
    # 测试获取所有交易所
    logger.info("获取所有交易所...")
    exchanges = collector.get_all_exchanges()
    logger.info(f"共获取到 {len(exchanges)} 个交易所")
    for exchange in exchanges:
        if exchange:
            logger.info(f"  - {exchange.exchange_name} ({exchange.exchange_id})")
    
    # 测试从币安获取数据（使用测试网）
    logger.info("\n从币安测试网获取数据...")
    binance_tickers = collector.fetch_all_tickers_from_exchange("binance")
    logger.info(f"币安测试网ticker数量: {len(binance_tickers)}")
    
    # 测试从Gate.io获取数据
    logger.info("\n从Gate.io获取数据...")
    gateio_tickers = collector.fetch_all_tickers_from_exchange("gateio")
    logger.info(f"Gate.io ticker数量: {len(gateio_tickers)}")
    
    # 测试从CoinGecko获取数据
    logger.info("\n从CoinGecko获取数据...")
    coingecko_tickers = collector.fetch_all_tickers_from_exchange("coingecko")
    logger.info(f"CoinGecko ticker数量: {len(coingecko_tickers)}")
    
    # 测试备用数据源功能
    logger.info("\n测试备用数据源功能...")
    # 临时修改配置，使币安API失败
    temp_config = config.copy()
    temp_config["use_binance_testnet"] = False  # 使用主网（可能会失败）
    collector.config = temp_config
    
    # 重新创建币安实例
    binance_with_fallback = collector.fetch_all_tickers_from_exchange("binance")
    logger.info(f"币安（带备用）ticker数量: {len(binance_with_fallback)}")
    
    # 检查是否使用了备用数据源
    if binance_with_fallback and len(binance_with_fallback) > 0:
        first_ticker = binance_with_fallback[0]
        logger.info(f"数据来源: {first_ticker['exchange_name']}")
    
    # 测试API状态
    logger.info("\n测试API状态...")
    api_status = collector.get_api_status()
    for exchange_id, status in api_status.items():
        logger.info(f"  - {exchange_id}: {status['status']}, 连续失败: {status['consecutive_failures']}")
    
    # 测试数据保存和检索
    logger.info("\n测试数据保存和检索...")
    
    # 保存数据
    logger.info("保存数据到数据库...")
    if gateio_tickers:
        collector.save_ticker_data("gateio", gateio_tickers[:10])  # 只保存前10个，避免数据库过大
    
    if coingecko_tickers:
        collector.save_ticker_data("coingecko", coingecko_tickers[:10])  # 只保存前10个，避免数据库过大
    
    # 获取最新价格数据
    logger.info("获取最新价格数据...")
    latest_data = collector.get_latest_price_data()
    logger.info(f"最新价格数据交易所数量: {len(latest_data)}")
    
    # 测试更新所有交易所数据
    logger.info("\n测试更新所有交易所数据...")
    update_results = collector.update_data(["gateio", "coingecko"])  # 只更新Gate.io和CoinGecko，避免币安API限制
    logger.info(f"更新结果: {update_results}")
    
    logger.info("更新版多交易所数据采集器验证完成!")
    return True

def validate_integration():
    """验证系统集成功能"""
    logger.info("\n=== 验证系统集成功能 ===")
    
    # 创建临时配置文件
    config = {
        "check_interval": 60,
        "price_threshold": 5.0,  # 使用较低的阈值以便于测试
        "volume_threshold": 50.0,
        "enabled_exchanges": ["gateio", "coingecko"],  # 只启用Gate.io和CoinGecko，避免币安API限制
        "excluded_symbols": [],
        "max_alerts_per_batch": 5,
        "data_retention_days": 7,
        "use_binance_testnet": True,
        "fallback_exchanges": {
            "binance": "coingecko"
        }
    }
    
    with open("validation_enhanced_config.json", "w") as f:
        json.dump(config, f, indent=4)
    
    logger.info("创建临时配置文件成功")
    
    # 测试配置加载
    logger.info("\n测试配置加载...")
    
    # 创建数据采集器
    collector = MultiExchangeDataCollector(db_path="validation_enhanced.db", config=config)
    
    # 测试更新数据
    logger.info("\n测试更新数据...")
    update_results = collector.update_data(config["enabled_exchanges"])
    logger.info(f"更新结果: {update_results}")
    
    # 测试获取最新价格数据
    logger.info("\n测试获取最新价格数据...")
    latest_data = collector.get_latest_price_data()
    logger.info(f"最新价格数据交易所数量: {len(latest_data)}")
    
    # 测试备用数据源
    logger.info("\n测试备用数据源...")
    # 尝试获取币安数据（应该会失败并切换到CoinGecko）
    if "binance" not in config["enabled_exchanges"]:
        logger.info("尝试获取币安数据（应该会切换到CoinGecko）...")
        binance_data = collector.fetch_all_tickers_from_exchange("binance")
        if binance_data and len(binance_data) > 0:
            logger.info(f"获取到 {len(binance_data)} 个币种数据")
            logger.info(f"数据来源: {binance_data[0]['exchange_name']}")
    
    # 清理临时文件
    if os.path.exists("validation_enhanced_config.json"):
        os.remove("validation_enhanced_config.json")
    
    logger.info("系统集成验证完成!")
    return True

def run_validation():
    """运行所有验证测试"""
    logger.info("开始增强版多交易所监控系统功能验证...")
    
    try:
        # 验证增强版币安适配器
        validate_enhanced_binance_adapter()
        
        # 验证CoinGecko适配器
        validate_coingecko_adapter()
        
        # 验证更新版多交易所数据采集器
        validate_multi_exchange_collector()
        
        # 验证系统集成
        validate_integration()
        
        logger.info("\n=== 所有验证测试通过! ===")
        return True
    except Exception as e:
        logger.error(f"验证测试失败: {str(e)}", exc_info=True)
        return False

if __name__ == "__main__":
    run_validation()
