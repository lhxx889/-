# 交易所监控系统使用说明 - 深度增强版

## 系统概述

交易所监控系统深度增强版是一个功能全面的加密货币监控工具，专为交易者和投资者设计，可以实时监控Binance.US和Gate.io交易所的币种价格变动和公告信息。本版本在原有基础上进行了全面升级，增加了持币人数、历史价格、社交媒体链接、官网和自动化涨跌原因分析等深度功能。

## 主要功能

1. **币种价格监控**：
   - 实时监控Binance.US和Gate.io所有币种的价格变动
   - 自定义涨跌幅阈值，超过阈值时记录并通知
   - 支持设置监控间隔时间

2. **公告扫描**：
   - 自动扫描两家交易所的公告页面
   - 智能识别新上币公告，优先提醒
   - 支持设置扫描间隔时间

3. **Telegram推送**：
   - 价格大幅波动时自动推送到Telegram
   - 新公告和新上币信息即时通知
   - 支持批量推送模式，减少消息打扰

4. **深度币种信息**：
   - 显示市值、24小时交易量、流通量等关键数据
   - 集成持币人数统计（链上数据）
   - 提供7天和30天历史价格变化
   - 自动分析可能的价格变动原因

5. **社交媒体链接**：
   - 集成Telegram群组链接
   - 提供X/Twitter官方账号
   - 显示项目官网
   - 集成Discord、Reddit等社区链接

6. **交互式主菜单**：
   - 一键启动/停止监控
   - 快速配置Telegram推送
   - 灵活调整监控参数
   - 币种详情查询功能

## 安装方法

### 基础安装

1. **解压下载的压缩包**：
   ```bash
   unzip crypto_monitor_advanced.zip -d crypto_monitor_advanced
   cd crypto_monitor_advanced
   ```

2. **安装必要的Python库**：
   ```bash
   pip install requests beautifulsoup4 pytz
   ```

3. **如需使用代理功能，还需安装socks支持**：
   ```bash
   pip install requests[socks]
   ```

4. **确保脚本有执行权限**：
   ```bash
   chmod +x crypto_monitor_advanced.py crypto_monitor_advanced_menu.py
   ```

### 不同系统的安装方法

#### Linux系统

1. **直接运行**：
   ```bash
   ./crypto_monitor_advanced_menu.py
   ```

2. **设置为系统服务（推荐）**：
   创建服务文件：
   ```bash
   sudo nano /etc/systemd/system/crypto-monitor.service
   ```

   添加以下内容：
   ```
   [Unit]
   Description=Cryptocurrency Exchange Monitor Advanced
   After=network.target

   [Service]
   ExecStart=/完整路径/crypto_monitor_advanced.py
   WorkingDirectory=/完整路径/到脚本目录
   User=你的用户名
   Restart=on-failure
   RestartSec=30s

   [Install]
   WantedBy=multi-user.target
   ```

   启用并启动服务：
   ```bash
   sudo systemctl enable crypto-monitor.service
   sudo systemctl start crypto-monitor.service
   ```

#### Windows系统

1. **直接运行**：
   - 打开命令提示符或PowerShell
   - 导航到脚本目录
   - 运行：`python crypto_monitor_advanced_menu.py`

2. **创建快捷方式**：
   - 右键点击桌面，选择"新建 -> 快捷方式"
   - 输入：`python 完整路径\crypto_monitor_advanced_menu.py`
   - 点击"下一步"，输入名称，点击"完成"

#### macOS系统

1. **直接运行**：
   ```bash
   ./crypto_monitor_advanced_menu.py
   ```

2. **创建启动项**：
   创建plist文件：
   ```bash
   nano ~/Library/LaunchAgents/com.user.cryptomonitor.plist
   ```

   添加以下内容：
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
   <plist version="1.0">
   <dict>
       <key>Label</key>
       <string>com.user.cryptomonitor</string>
       <key>ProgramArguments</key>
       <array>
           <string>/完整路径/crypto_monitor_advanced.py</string>
       </array>
       <key>RunAtLoad</key>
       <true/>
       <key>KeepAlive</key>
       <true/>
       <key>StandardOutPath</key>
       <string>/完整路径/crypto_monitor.log</string>
       <key>StandardErrorPath</key>
       <string>/完整路径/crypto_monitor.err</string>
   </dict>
   </plist>
   ```

   加载服务：
   ```bash
   launchctl load ~/Library/LaunchAgents/com.user.cryptomonitor.plist
   ```

## 使用方法

### 交互式主菜单

运行交互式主菜单脚本：
```bash
./crypto_monitor_advanced_menu.py
```

主菜单提供以下选项：
1. **启动/停止监控** - 控制监控系统的运行状态
2. **配置Telegram推送** - 设置Telegram机器人Token和聊天ID
3. **设置价格监控参数** - 调整涨跌幅阈值和检查间隔
4. **设置公告扫描参数** - 调整公告扫描间隔
5. **配置代理设置** - 启用/禁用代理，设置代理地址
6. **币种信息查询** - 搜索并查看币种详细信息
7. **高级功能设置** - 配置持币人数、社交链接和涨跌原因分析
8. **显示设置** - 配置上海时间和币种详情显示
9. **查看当前配置** - 显示所有配置参数

### 币种信息查询

在主菜单中选择"币种信息查询"，可以：
1. 输入币种名称、符号或ID进行搜索
2. 从搜索结果中选择币种查看详情
3. 查看币种的详细信息，包括：
   - 价格和市值数据
   - 历史价格变化
   - 持币人数（如果可用）
   - 社交媒体链接
   - 项目简介

### Telegram推送设置

在主菜单中选择"配置Telegram推送"，可以：
1. 启用/禁用Telegram推送
2. 设置机器人Token和聊天ID
3. 启用/禁用价格变动和公告推送
4. 设置价格推送阈值
5. 启用/禁用批量推送模式
6. 测试Telegram连接

#### 创建Telegram机器人

1. 在Telegram中搜索 @BotFather
2. 发送 /newbot 命令
3. 按照提示设置机器人名称和用户名
4. 获取API Token
5. 将机器人添加到您的聊天或群组中
6. 获取聊天ID（可通过 @userinfobot 获取）

### 推送内容示例

价格变动推送现在更加信息丰富：
```
🟢 Binance.US - BTCUSDT 上涨 12.34%
💰 当前价格: 65000.0
🏦 市值: $1,234,567,890
📊 24h交易量: $45,678,901,234
📈 7天变化: +5.67%
📉 30天变化: -2.34%
👥 持币人数: 1,234,567
🔄 流通量: 19,000,000 BTC

🔗 链接:
🌐 官网: https://bitcoin.org
📱 Telegram: https://t.me/bitcoin
🐦 X/Twitter: https://twitter.com/bitcoin

📝 可能原因: 交易量大幅增加、市值排名上升、有3条相关新闻

🕒 时间: 2025-06-05 13:04:22 CST+0800
```

## 高级功能说明

### 持币人数统计

系统会尝试从多个数据源获取持币人数：
1. CoinGecko API（如果可用）
2. Etherscan API（需要API密钥）
3. Ethplorer API（可使用免费密钥）

要启用此功能，请在高级功能设置中：
1. 启用持币人数显示
2. 设置Etherscan API密钥（可选）
3. 设置Ethplorer API密钥（可选，默认使用免费密钥）

### 社交媒体链接

系统会自动从CoinGecko获取以下社交媒体链接：
1. 官方网站
2. Telegram群组
3. X/Twitter账号
4. Discord服务器
5. Reddit社区

### 价格变动原因分析

系统会尝试分析价格变动的可能原因，基于：
1. 交易量变化
2. 市值排名变化
3. 相关新闻
4. 市场模式

## 常见问题

1. **如何获取Telegram聊天ID？**
   - 将 @userinfobot 添加到您的聊天中
   - 发送任意消息，机器人会回复您的ID

2. **为什么没有收到Telegram通知？**
   - 检查机器人Token和聊天ID是否正确
   - 确保已将机器人添加到聊天中
   - 检查价格推送阈值是否设置过高

3. **如何减少通知频率？**
   - 提高价格推送阈值
   - 启用批量推送模式
   - 增加批量推送间隔

4. **如何解决Gate.io的反爬虫限制？**
   - 启用代理功能
   - 设置有效的SOCKS5代理
   - 增加公告扫描间隔

5. **如何获取更准确的持币人数？**
   - 在高级功能设置中设置Etherscan API密钥
   - 可以从 https://etherscan.io/apis 获取免费API密钥

## 文件说明

- `crypto_monitor_advanced.py` - 核心监控脚本
- `crypto_monitor_advanced_menu.py` - 交互式主菜单
- `config_advanced.json` - 配置文件
- `data/` - 数据存储目录
  - `significant_price_changes.json` - 价格变动记录
  - `announcement_history.json` - 公告历史记录
  - `new_announcements.json` - 新公告记录
  - `news_cache.json` - 新闻缓存

## 更新日志

### 深度增强版 (2025-06-05)
- 新增持币人数统计功能
- 新增历史价格变化显示
- 新增社交媒体链接集成
- 新增官网链接显示
- 新增自动化涨跌原因分析
- 优化推送内容格式
- 增强交互式主菜单
- 新增币种详情查询功能
- 新增上海时间显示

### 增强版 (2025-06-04)
- 新增币种详细资料集成
- 新增上海时间显示
- 新增币种信息查询功能
- 优化交互式主菜单

### 基础版 (2025-06-03)
- 初始版本发布
- 基本价格监控功能
- 基本公告扫描功能
- Telegram推送功能
