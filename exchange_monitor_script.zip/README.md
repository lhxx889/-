# 交易所监控脚本部署与使用指南

## 1. 简介

本脚本旨在帮助用户监控主流加密货币交易所的价格波动，并及时获取最新的交易所公告和新币上架信息。通过集成免费AI分析服务，脚本还能对公告内容进行情感分析，并通过Telegram Bot将重要信息推送给用户。此外，脚本还提供了交互式主菜单，方便用户进行配置和控制。

## 2. 功能特性

- **价格监控:** 实时监控指定交易对的价格涨跌幅，当波动超过预设阈值时发出警报。
- **公告抓取:** 定时抓取主流交易所的最新公告，包括新币上架、交易对新增等。
- **AI分析:** 利用免费AI服务对公告内容进行情感分析，判断其对市场的影响（利好、利空、中性）。
- **Telegram推送:** 将价格警报、新币公告和AI分析结果通过Telegram Bot发送给用户。
- **交互式菜单:** 提供命令行界面，方便用户启动/暂停监控、配置Telegram信息、设置主/备用API以及配置监控阈值和涨幅百分比。
- **模块化设计:** 易于扩展和维护，方便添加新的交易所或功能。

## 3. 部署环境

- **操作系统:** Linux (推荐 Ubuntu 22.04)
- **Python:** Python 3.8+
- **依赖库:** `ccxt`, `python-telegram-bot`, ``requests`, `beautifulsoup4`, `APScheduler`

## 4. 部署步骤

### 4.1. 克隆代码库

```bash
git clone <repository_url> # 如果有代码库，替换为实际URL
cd <repository_directory>
```

### 4.2. 安装依赖

```bash
pip3 install ccxt python-telegram-bot requests beautifulsoup4 apscheduler
```

### 4.3. 配置 `config.json`

`config.json` 文件用于存储脚本的各项配置。您可以通过直接编辑此文件进行初始配置，也可以在脚本运行后通过交互式菜单进行配置。以下是配置项说明：

- `EXCHANGES`: 列表，包含您希望监控的交易所ID（例如：`"binance"`, `"gate"`）。
- `API_KEYS`: 字典，存储各交易所的主用和备用API Key和Secret。当主用API失效时，脚本将尝试使用备用API。
  - `primary_apiKey`: 主用API Key。
  - `primary_secret`: 主用Secret Key。
  - `backup_apiKey`: 备用API Key (可选)。
  - `backup_secret`: 备用Secret Key (可选)。
- `TELEGRAM_BOT_TOKEN`: 您的Telegram Bot的Token。请通过 `@BotFather` 创建Bot并获取Token。
- `TELEGRAM_CHAT_ID`: 您希望接收消息的Telegram用户或群组的Chat ID。可以通过向 `@userinfobot` 发送消息来获取您的用户ID，或者将Bot添加到群组后，通过 `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates` 获取群组ID（通常为负数）。
- `PRICE_CHANGE_THRESHOLD`: 价格涨跌幅阈值（百分比）。当24小时涨跌幅超过此值时触发警报。例如 `5.0` 表示5%。
- `ANNOUNCEMENT_FETCH_INTERVAL`: 公告抓取间隔（小时）。例如 `1` 表示每小时抓取一次。
- `AI_API_ENDPOINT`: 免费AI分析服务的API地址。目前脚本集成了Google Gemini API，默认地址为 `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=`。
- `AI_API_KEY`: 免费AI分析服务的API Key。对于Google Gemini API，您需要提供您的Google Gemini API Key。

**`config.json` 示例:**

```json
{
  "EXCHANGES": ["binance", "gate"],
  "API_KEYS": {
    "binance": {
      "primary_apiKey": "YOUR_BINANCE_PRIMARY_API_KEY",
      "primary_secret": "YOUR_BINANCE_PRIMARY_SECRET_KEY",
      "backup_apiKey": "YOUR_BINANCE_BACKUP_API_KEY",
      "backup_secret": "YOUR_BINANCE_BACKUP_SECRET_KEY"
    },
    "gate": {
      "primary_apiKey": "YOUR_GATE_PRIMARY_API_KEY",
      "primary_secret": "YOUR_GATE_PRIMARY_SECRET_KEY",
      "backup_apiKey": "YOUR_GATE_BACKUP_API_KEY",
      "backup_secret": "YOUR_GATE_BACKUP_SECRET_KEY"
    }
  },
  "TELEGRAM_BOT_TOKEN": "YOUR_TELEGRAM_BOT_TOKEN",
  "TELEGRAM_CHAT_ID": "YOUR_TELEGRAM_CHAT_ID",
  "PRICE_CHANGE_THRESHOLD": 5.0,
  "ANNOUNCEMENT_FETCH_INTERVAL": 1,
  "AI_API_ENDPOINT": "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=",
  "AI_API_KEY": "YOUR_GOOGLE_GEMINI_API_KEY"
}
```

### 4.4. 运行脚本

```bash
python3 main.py
```

脚本启动后，将显示主菜单，您可以根据提示进行操作，包括启动/暂停监控、配置各项参数等。

## 5. 注意事项

- **API安全:** 请妥善保管您的API密钥，不要泄露给他人。建议为API密钥设置最小权限。
- **交易所API限速:** 频繁的API请求可能会触发交易所的限速策略。脚本已内置 `enableRateLimit`，但仍需注意。
- **公告页面结构变化:** 交易所官网公告页面的HTML结构可能随时变化，这可能导致公告抓取功能失效。如果遇到问题，可能需要更新 `main.py` 中 `fetch_binance_announcements` 和 `fetch_gate_announcements` 函数内的 `BeautifulSoup` 选择器。
- **AI分析准确性:** 免费AI分析服务的准确性可能有限，分析结果仅供参考。
- **Telegram消息格式:** Telegram消息支持MarkdownV2格式，脚本中的消息已进行基本格式化。如果需要更复杂的格式，请参考Telegram Bot API文档。
- **错误处理和日志:** 脚本包含基本的错误处理和打印输出。建议在生产环境中添加更完善的日志记录机制。

## 6. 常见问题

- **如何获取Telegram Bot Token和Chat ID？**
  - **Bot Token:** 在Telegram中搜索 `@BotFather`，发送 `/newbot` 命令，按照提示创建Bot并获取Token。
  - **Chat ID:** 向您的Bot发送任意消息，然后访问 `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates` (将 `<YOUR_BOT_TOKEN>` 替换为您的Bot Token)，在返回的JSON中查找 `"chat": {"id": ...}` 字段，其后的数字即为Chat ID。如果是群组，请确保您的Bot已加入群组。

- **脚本无法启动或报错？**
  - 检查是否所有依赖库都已正确安装。
  - 检查 `config.json` 文件中的配置项是否填写正确，特别是API密钥和Token。
  - 查看控制台输出的错误信息，根据错误信息进行排查。

## 7. 许可证

本项目采用 MIT 许可证。


