
import ccxt
import json
import time
from datetime import datetime, timedelta
from telegram import Bot
from telegram.error import TelegramError
from apscheduler.schedulers.background import BackgroundScheduler
from bs4 import BeautifulSoup
import requests

# Load configuration
def load_config():
    with open("config.json", "r") as f:
        return json.load(f)

def save_config(config_data):
    with open("config.json", "w") as f:
        json.dump(config_data, f, indent=2)

config = load_config()

EXCHANGES = config["EXCHANGES"]
API_KEYS = config["API_KEYS"]
TELEGRAM_BOT_TOKEN = config["TELEGRAM_BOT_TOKEN"]
TELEGRAM_CHAT_ID = config["TELEGRAM_CHAT_ID"]
PRICE_CHANGE_THRESHOLD = config["PRICE_CHANGE_THRESHOLD"]
ANNOUNCEMENT_FETCH_INTERVAL = config["ANNOUNCEMENT_FETCH_INTERVAL"]
AI_API_ENDPOINT = config["AI_API_ENDPOINT"]
AI_API_KEY = config["AI_API_KEY"]

bot = Bot(token=TELEGRAM_BOT_TOKEN)

# Initialize exchanges
exchanges = {}
for exchange_id in EXCHANGES:
    exchange_class = getattr(ccxt, exchange_id)
    exchanges[exchange_id] = exchange_class({
        "apiKey": API_KEYS[exchange_id]["primary_apiKey"],
        "secret": API_KEYS[exchange_id]["primary_secret"],
        "enableRateLimit": True,
    })

async def send_telegram_message(message):
    try:
        await bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)
        print(f"Telegram message sent: {message}")
    except TelegramError as e:
        print(f"Error sending Telegram message: {e}")

async def analyze_sentiment_google_gemini(text):
    if not AI_API_ENDPOINT or not AI_API_KEY:
        print("Google Gemini API endpoint or key not configured.")
        return {"sentiment": 0, "score": 0.5} # Return neutral if not configured

    url = f"{AI_API_ENDPOINT}{AI_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {
        "contents": [{
            "parts": [{
                "text": f"请分析以下文本的情感倾向，并给出0到1之间的得分，0代表非常负面，1代表非常正面，0.5代表中性。只返回JSON格式，例如：{{\"sentiment\": \"正面\", \"score\": 0.8}}。文本内容：{text}"
            }]
        }]
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        
        # Parse the response from Gemini API
        # Assuming Gemini returns text in \'candidates[0].content.parts[0].text\'
        # And that text is a JSON string as requested in the prompt
        if "candidates" in result and len(result["candidates"]) > 0:
            gemini_response_text = result["candidates"][0]["content"]["parts"][0]["text"]
            try:
                sentiment_data = json.loads(gemini_response_text)
                sentiment_label = sentiment_data.get("sentiment", "中性")
                score = sentiment_data.get("score", 0.5)
                
                # Convert sentiment label to numeric for consistency with previous structure
                numeric_sentiment = 0
                if "正面" in sentiment_label:
                    numeric_sentiment = 1
                elif "负面" in sentiment_label:
                    numeric_sentiment = -1
                
                return {"sentiment": numeric_sentiment, "score": score}
            except json.JSONDecodeError:
                print(f"Failed to parse Gemini response as JSON: {gemini_response_text}")
                return {"sentiment": 0, "score": 0.5}
        else:
            print(f"No candidates found in Gemini response: {result}")
            return {"sentiment": 0, "score": 0.5}
    except requests.exceptions.RequestException as e:
        print(f"Error calling Google Gemini API: {e}")
        return {"sentiment": 0, "score": 0.5}
    except Exception as e:
        print(f"An unexpected error occurred during Google Gemini analysis: {e}")
        return {"sentiment": 0, "score": 0.5}

async def check_price_change():
    print("Checking price changes...")
    for exchange_id, exchange in exchanges.items():
        try:
            # Fetch markets to get all trading pairs
            markets = await exchange.load_markets()
            
            # Iterate over common trading pairs (e.g., USDT pairs)
            for symbol in markets:
                if "/USDT" in symbol:
                    try:
                        # Fetch ticker for 24h change
                        ticker = await exchange.fetch_ticker(symbol)
                        
                        # Calculate 1-hour change (requires fetching OHLCV data)
                        # For simplicity, we\\'ll use 24h change for now, and refine later if needed.
                        # Fetching 1-hour OHLCV for all pairs can be rate-limited.
                        
                        if "percentage" in ticker and ticker["percentage"] is not None:
                            change_24h = ticker["percentage"]
                            
                            if abs(change_24h) > PRICE_CHANGE_THRESHOLD:
                                message = (
                                    f"📈📉 **价格异常波动警报** 📈📉\n"
                                    f"交易所: {exchange_id.upper()}\n"
                                    f"交易对: {symbol}\n"
                                    f"24小时涨跌幅: {change_24h:.2f}%\n"
                                    f"最新价格: {ticker["last"]}\n"
                                    f"时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"
                                )
                                await send_telegram_message(message)

                    except ccxt.NetworkError as e:
                        print(f"Network error fetching ticker for {symbol} on {exchange_id}: {e}")
                    except ccxt.ExchangeError as e:
                        print(f"Exchange error fetching ticker for {symbol} on {exchange_id}: {e}")
                    except Exception as e:
                        print(f"An unexpected error occurred for {symbol} on {exchange_id}: {e}")

        except ccxt.NetworkError as e:
            print(f"Network error loading markets for {exchange_id}: {e}")
        except ccxt.ExchangeError as e:
            print(f"Exchange error loading markets for {exchange_id}: {e}")
        except Exception as e:
            print(f"An unexpected error occurred for {exchange_id}: {e}")

last_fetched_announcements = {}

async def fetch_announcement_content(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        # Find the main content area of the announcement
        # This selector might need adjustment based on the actual page structure
        content_div = soup.find("div", class_="css-1y1424s") # This class might change
        if content_div:
            return content_div.get_text(separator="\n", strip=True)
        else:
            print(f"Could not find content div for {url}")
            return ""
    except requests.exceptions.RequestException as e:
        print(f"Error fetching announcement content from {url}: {e}")
        return ""
    except Exception as e:
        print(f"An unexpected error occurred while parsing announcement content from {url}: {e}")
        return ""

async def fetch_binance_announcements():
    global last_fetched_announcements
    url = "https://www.binance.com/zh-CN/support/announcement/list/49" # Changed to \'最新动态\' for broader announcements
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception for HTTP errors
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Find all announcement items
        announcements = soup.find_all("a", class_="css-1ej4cbu") 
        
        current_announcements = {}
        for ann in announcements:
            title_div = ann.find("div", class_="css-1ej4cbu")
            if title_div:
                title = title_div.text.strip()
                link = "https://www.binance.com" + ann["href"]
                current_announcements[title] = link

        new_announcements = {}
        for title, link in current_announcements.items():
            if title not in last_fetched_announcements:
                new_announcements[title] = link
                print(f"New announcement found: {title}")
                
                # Fetch full content of the new announcement
                content = await fetch_announcement_content(link)
                
                # AI analysis
                ai_analysis_result = await analyze_sentiment_google_gemini(content) # Changed to Google Gemini
                sentiment_label = "中性"
                if ai_analysis_result["sentiment"] == 1:
                    sentiment_label = "利好"
                elif ai_analysis_result["sentiment"] == -1:
                    sentiment_label = "利空"
                
                # Check for new coin listings (simple keyword matching)
                if "上新" in title or "上线" in title or "新增交易对" in title:
                    message = (
                        f"✨ **新币/交易对上新警报** ✨\n"
                        f"交易所: 币安\n"
                        f"标题: {title}\n"
                        f"链接: {link}\n"
                        f"AI分析情感: {sentiment_label} (得分: {ai_analysis_result["score"]:.2f})\n"
                        f"时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"
                    )
                    await send_telegram_message(message)
                else:
                    # General announcement with AI analysis
                    message = (
                        f"📢 **币安最新公告** 📢\n"
                        f"标题: {title}\n"
                        f"链接: {link}\n"
                        f"AI分析情感: {sentiment_label} (得分: {ai_analysis_result["score"]:.2f})\n"
                        f"时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"
                    )
                    await send_telegram_message(message)
        
        last_fetched_announcements = current_announcements

    except requests.exceptions.RequestException as e:
        print(f"Error fetching Binance announcements: {e}")
    except Exception as e:
        print(f"An unexpected error occurred during Binance announcement parsing: {e}")

async def fetch_gate_announcements():
    global last_fetched_announcements
    urls = [
        "https://www.gate.io/zh/announcements/dau", # General announcements
        "https://www.gate.io/zh/announcements/newlisted" # New listings
    ]
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    current_announcements = {}
    for url in urls:
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "html.parser")

            # Find all <a> tags whose href starts with /zh/announcements/article/
            announcements = soup.find_all("a", href=lambda href: href and href.startswith("/zh/announcements/article/"))
            
            for ann in announcements:
                title = ann.get_text(strip=True)
                link = ann.get("href")
                if link and title:
                    if not link.startswith("http"): # Make sure it\\'s an absolute URL
                        link = "https://www.gate.io" + link
                    current_announcements[title] = link

        except requests.exceptions.RequestException as e:
            print(f"Error fetching Gate.io announcements from {url}: {e}")
        except Exception as e:
            print(f"An unexpected error occurred during Gate.io announcement parsing from {url}: {e}")

    new_announcements = {}
    for title, link in current_announcements.items():
        if title not in last_fetched_announcements:
            new_announcements[title] = link
            print(f"New Gate.io announcement found: {title}")
            
            content = await fetch_announcement_content(link)
            ai_analysis_result = await analyze_sentiment_google_gemini(content)
            sentiment_label = "中性"
            if ai_analysis_result["sentiment"] == 1:
                sentiment_label = "利好"
            elif ai_analysis_result["sentiment"] == -1:
                sentiment_label = "利空"
            
            if "上新" in title or "上线" in title or "新增交易对" in title or "首发" in title:
                message = (
                    f"✨ **Gate.io 新币/交易对上新警报** ✨\n"
                    f"标题: {title}\n"
                    f"链接: {link}\n"
                    f"AI分析情感: {sentiment_label} (得分: {ai_analysis_result["score"]:.2f})\n"
                    f"时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"
                )
                await send_telegram_message(message)
            else:
                message = (
                    f"📢 **Gate.io 最新公告** 📢\n"
                    f"标题: {title}\n"
                    f"链接: {link}\n"
                    f"AI分析情感: {sentiment_label} (得分: {ai_analysis_result["score"]:.2f})\n"
                    f"时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"
                )
                await send_telegram_message(message)
    
    last_fetched_announcements = current_announcements

async def fetch_announcements():
    print("Fetching announcements...")
    await fetch_binance_announcements()
    await fetch_gate_announcements() # Call Gate.io announcement fetching

# Global scheduler instance
scheduler = BackgroundScheduler()

def start_monitoring():
    global scheduler
    if scheduler.running:
        print("Monitoring is already running.")
        return
    scheduler.add_job(check_price_change, "interval", minutes=1, max_instances=1, id=\"price_check\")
    scheduler.add_job(fetch_announcements, "interval", hours=config["ANNOUNCEMENT_FETCH_INTERVAL"], max_instances=1, id=\"announcement_fetch\")
    scheduler.start()
    print("Monitoring started.")

def pause_monitoring():
    global scheduler
    if not scheduler.running:
        print("Monitoring is not running.")
        return
    scheduler.shutdown(wait=False)
    print("Monitoring paused.")

def display_main_menu():
    print("\n--- 主菜单 ---")
    print("1. 启动监控")
    print("2. 暂停监控")
    print("3. 配置 Telegram")
    print("4. 配置 API")
    print("5. 配置监控阈值")
    print("6. 退出")

def handle_telegram_config():
    global config, bot
    print("\n--- 配置 Telegram ---")
    new_token = input(f"请输入 Telegram Bot Token (当前: {config.get(\"TELEGRAM_BOT_TOKEN\", \"未设置\")}): ")
    if new_token:
        config["TELEGRAM_BOT_TOKEN"] = new_token
        try:
            bot = Bot(token=new_token) # Re-initialize bot with new token
            print("Telegram Bot Token 已更新。")
        except Exception as e:
            print(f"初始化 Telegram Bot 失败: {e}。请检查 Token 是否正确。")
            config["TELEGRAM_BOT_TOKEN"] = ""

    new_chat_id = input(f"请输入 Telegram Chat ID (当前: {config.get(\"TELEGRAM_CHAT_ID\", \"未设置\")}): ")
    if new_chat_id:
        config["TELEGRAM_CHAT_ID"] = new_chat_id
        print("Telegram Chat ID 已更新。")
    
    save_config(config)
    print("Telegram 配置已保存。")

def handle_api_config():
    global config, exchanges
    print("\n--- 配置 API ---")
    print("支持的交易所:")
    for i, ex_id in enumerate(EXCHANGES):
        print(f"{i+1}. {ex_id.upper()}")
    
    while True:
        try:
            choice = input("请选择要配置的交易所 (输入数字或 'q' 返回主菜单): ")
            if choice.lower() == 'q':
                break
            
            idx = int(choice) - 1
            if 0 <= idx < len(EXCHANGES):
                exchange_id = EXCHANGES[idx]
                print(f"\n--- 配置 {exchange_id.upper()} API ---")
                
                primary_api_key = input(f"请输入主用 API Key (当前: {config[\"API_KEYS\"][exchange_id].get(\"primary_apiKey\", \"未设置\")}): ")
                primary_secret = input(f"请输入主用 Secret Key (当前: {config[\"API_KEYS\"][exchange_id].get(\"primary_secret\", \"未设置\")}): ")
                backup_api_key = input(f"请输入备用 API Key (当前: {config[\"API_KEYS\"][exchange_id].get(\"backup_apiKey\", \"未设置\")}): ")
                backup_secret = input(f"请输入备用 Secret Key (当前: {config[\"API_KEYS\"][exchange_id].get(\"backup_secret\", \"未设置\")}): ")

                config["API_KEYS"][exchange_id]["primary_apiKey"] = primary_api_key if primary_api_key else config["API_KEYS"][exchange_id].get("primary_apiKey", "")
                config["API_KEYS"][exchange_id]["primary_secret"] = primary_secret if primary_secret else config["API_KEYS"][exchange_id].get("primary_secret", "")
                config["API_KEYS"][exchange_id]["backup_apiKey"] = backup_api_key if backup_api_key else config["API_KEYS"][exchange_id].get("backup_apiKey", "")
                config["API_KEYS"][exchange_id]["backup_secret"] = backup_secret if backup_secret else config["API_KEYS"][exchange_id].get("backup_secret", "")
                
                save_config(config)
                print(f"{exchange_id.upper()} API 配置已保存。")
                
                # Re-initialize the specific exchange instance
                exchange_class = getattr(ccxt, exchange_id)
                exchanges[exchange_id] = exchange_class({
                    "apiKey": config["API_KEYS"][exchange_id]["primary_apiKey"],
                    "secret": config["API_KEYS"][exchange_id]["primary_secret"],
                    "enableRateLimit": True,
                })

            else:
                print("无效的选择，请重新输入。")
        except ValueError:
            print("无效的输入，请输入数字。")

def handle_threshold_config():
    global config
    print("\n--- 配置监控阈值 ---")
    
    while True:
        try:
            new_price_threshold = input(f"请输入价格涨跌幅阈值 (当前: {config.get(\"PRICE_CHANGE_THRESHOLD\", 0.0)}%)：")
            if new_price_threshold:
                threshold_val = float(new_price_threshold)
                config["PRICE_CHANGE_THRESHOLD"] = threshold_val
                print("价格涨跌幅阈值已更新。")
                break
            else:
                break # User pressed enter without input, keep current value
        except ValueError:
            print("无效的输入，请输入数字。")

    while True:
        try:
            new_announcement_interval = input(f"请输入公告抓取间隔（小时）(当前: {config.get(\"ANNOUNCEMENT_FETCH_INTERVAL\", 1)}小时)：")
            if new_announcement_interval:
                interval_val = int(new_announcement_interval)
                if interval_val <= 0:
                    print("间隔时间必须大于0。")
                    continue
                config["ANNOUNCEMENT_FETCH_INTERVAL"] = interval_val
                print("公告抓取间隔已更新。")
                break
            else:
                break # User pressed enter without input, keep current value
        except ValueError:
            print("无效的输入，请输入整数。")

    save_config(config)
    print("监控阈值配置已保存。")

async def main():
    global scheduler
    print("欢迎使用交易所监控脚本！")
    
    # Initial check for essential configurations
    if not config.get("TELEGRAM_BOT_TOKEN") or not config.get("TELEGRAM_CHAT_ID"):
        print("Telegram 配置不完整，请先进行配置。")
        handle_telegram_config()
    
    for ex_id in EXCHANGES:
        if not config["API_KEYS"].get(ex_id) or not config["API_KEYS"][ex_id].get("primary_apiKey"):
            print(f"{ex_id.upper()} 的 API 配置不完整，请先进行配置。")
            handle_api_config()
            break # Only prompt for one missing API config at a time

    while True:
        display_main_menu()
        choice = input("请输入您的选择: ")

        if choice == '1':
            start_monitoring()
        elif choice == '2':
            pause_monitoring()
        elif choice == '3':
            handle_telegram_config()
        elif choice == '4':
            handle_api_config()
        elif choice == '5':
            handle_threshold_config()
        elif choice == '6':
            print("退出脚本。再见！")
            if scheduler.running:
                scheduler.shutdown()
            break
        else:
            print("无效的选择，请重新输入。")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())


