#!/bin/bash

# Gate.io加密货币异动监控系统 - 一键安装脚本
# 自动完成依赖安装、环境配置和初始化

echo "===== Gate.io加密货币异动监控系统一键安装 ====="
echo ""

# 检查Python版本
echo "检查Python环境..."
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
else
    echo "错误: 未找到Python。请先安装Python 3.6或更高版本。"
    exit 1
fi

# 检查Python版本是否满足要求
PYTHON_VERSION=$($PYTHON_CMD -c "import sys; print('{}.{}'.format(sys.version_info.major, sys.version_info.minor))")
echo "检测到Python版本: $PYTHON_VERSION"

# 检查系统依赖
echo ""
echo "检查系统依赖..."
if command -v apt-get &>/dev/null; then
    echo "检测到Debian/Ubuntu系统"
    echo "安装系统依赖..."
    sudo apt-get update
    sudo apt-get install -y build-essential libssl-dev libffi-dev python3-dev python3-pip python3-venv
elif command -v yum &>/dev/null; then
    echo "检测到CentOS/RHEL系统"
    echo "安装系统依赖..."
    sudo yum -y update
    sudo yum -y groupinstall "Development Tools"
    sudo yum -y install openssl-devel libffi-devel python3-devel python3-pip
elif command -v brew &>/dev/null; then
    echo "检测到macOS系统"
    echo "安装系统依赖..."
    brew update
    brew install openssl readline sqlite3 xz zlib
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    echo "检测到Windows系统"
    echo "Windows系统无需额外安装系统依赖"
else
    echo "警告: 无法识别的操作系统，跳过系统依赖安装"
    echo "如果后续安装失败，请手动安装所需的系统依赖"
fi

# 创建虚拟环境
echo ""
echo "创建虚拟环境..."
$PYTHON_CMD -m venv venv || {
    echo "创建虚拟环境失败，尝试使用virtualenv..."
    if ! command -v pip3 &>/dev/null; then
        echo "错误: 未找到pip。请先安装pip。"
        exit 1
    fi
    pip3 install virtualenv
    virtualenv venv || {
        echo "错误: 创建虚拟环境失败。"
        exit 1
    }
}

# 激活虚拟环境
echo "激活虚拟环境..."
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    source venv/Scripts/activate || {
        echo "错误: 激活虚拟环境失败。"
        exit 1
    }
else
    # Linux/Mac
    source venv/bin/activate || {
        echo "错误: 激活虚拟环境失败。"
        exit 1
    }
fi

# 升级pip
echo ""
echo "升级pip..."
pip install --upgrade pip

# 安装依赖
echo ""
echo "安装依赖..."
if [ -f "requirements.txt" ]; then
    echo "使用requirements.txt安装依赖..."
    pip install -r requirements.txt || {
        echo "错误: 安装依赖失败。"
        exit 1
    }
else
    echo "未找到requirements.txt，创建并安装基本依赖..."
    cat > requirements.txt << EOF
matplotlib>=3.4.3
pandas>=1.3.3
numpy>=1.21.2
requests>=2.25.1
python-telegram-bot>=13.7
pytz>=2021.1
beautifulsoup4>=4.9.3
lxml>=4.6.3
pillow>=8.3.1
plotly>=5.3.1
ccxt>=1.60.0
python-binance>=1.0.15
python-dateutil>=2.8.2
schedule>=1.1.0
cryptography>=3.4.8
aiohttp>=3.7.4
websocket-client>=1.2.1
colorama>=0.4.4
tabulate>=0.8.9
tqdm>=4.62.3
pyyaml>=6.0
EOF
    pip install -r requirements.txt || {
        echo "错误: 安装依赖失败。"
        exit 1
    }
fi

# 创建配置文件
echo ""
echo "创建配置文件..."
if [ ! -f "config.json" ]; then
    cat > config.json << EOF
{
    "check_interval": 50,
    "price_threshold": 30.0,
    "volume_threshold": 200.0,
    "api_key": "",
    "api_secret": "",
    "excluded_symbols": [],
    "use_custom_format": true
}
EOF
    echo "已创建默认配置文件。"
else
    echo "配置文件已存在，跳过创建。"
fi

# 创建目录
echo "创建必要目录..."
mkdir -p charts logs

# 运行设置向导
echo ""
echo "是否运行设置向导? (y/n)"
read -r run_setup
if [[ "$run_setup" == "y" || "$run_setup" == "Y" ]]; then
    $PYTHON_CMD main.py --setup
fi

# 创建启动脚本
echo ""
echo "创建启动脚本..."
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    cat > start.bat << EOF
@echo off
call venv\Scripts\activate
python main.py
pause
EOF
    chmod +x start.bat
    echo "已创建Windows启动脚本: start.bat"
else
    # Linux/Mac
    cat > start.sh << EOF
#!/bin/bash
source venv/bin/activate
python main.py
EOF
    chmod +x start.sh
    echo "已创建Linux/Mac启动脚本: start.sh"
fi

# 创建自定义格式启动脚本
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    cat > start_custom_format.bat << EOF
@echo off
call venv\Scripts\activate
python main.py --format custom
pause
EOF
    chmod +x start_custom_format.bat
    echo "已创建自定义格式Windows启动脚本: start_custom_format.bat"
else
    # Linux/Mac
    cat > start_custom_format.sh << EOF
#!/bin/bash
source venv/bin/activate
python main.py --format custom
EOF
    chmod +x start_custom_format.sh
    echo "已创建自定义格式Linux/Mac启动脚本: start_custom_format.sh"
fi

# 创建标准格式启动脚本
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    cat > start_standard_format.bat << EOF
@echo off
call venv\Scripts\activate
python main.py --format standard
pause
EOF
    chmod +x start_standard_format.bat
    echo "已创建标准格式Windows启动脚本: start_standard_format.bat"
else
    # Linux/Mac
    cat > start_standard_format.sh << EOF
#!/bin/bash
source venv/bin/activate
python main.py --format standard
EOF
    chmod +x start_standard_format.sh
    echo "已创建标准格式Linux/Mac启动脚本: start_standard_format.sh"
fi

# 验证安装
echo ""
echo "验证安装..."
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    source venv/Scripts/activate
else
    # Linux/Mac
    source venv/bin/activate
fi

# 检查关键依赖是否安装成功
$PYTHON_CMD -c "import matplotlib; import pandas; import numpy; import requests; import pytz; print('依赖验证成功!')" || {
    echo "警告: 部分核心依赖可能未正确安装，但程序仍可能正常运行。"
}

echo ""
echo "===== 安装完成 ====="
echo ""
echo "使用方法:"
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    echo "1. 双击 start.bat 启动监控系统（默认使用自定义格式）"
    echo "2. 双击 start_custom_format.bat 使用自定义推送格式启动"
    echo "3. 双击 start_standard_format.bat 使用标准推送格式启动"
else
    echo "1. 运行 ./start.sh 启动监控系统（默认使用自定义格式）"
    echo "2. 运行 ./start_custom_format.sh 使用自定义推送格式启动"
    echo "3. 运行 ./start_standard_format.sh 使用标准推送格式启动"
fi
echo ""
echo "如需重新配置，请运行:"
echo "$PYTHON_CMD main.py --setup"
echo ""
echo "感谢使用Gate.io加密货币异动监控系统！"
