"""
Gate.io加密货币异动监控系统 - 新上币公告扫描模块
扫描Gate.io新上币公告并推送通知
"""

import os
import json
import logging
import requests
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from bs4 import BeautifulSoup
import re

# 导入Telegram警报器
try:
    from src.enhanced_multi_telegram_alerter import EnhancedMultiTelegramAlerter
    enhanced_telegram_available = True
except ImportError:
    try:
        from src.telegram_alerter import TelegramAlerter
        enhanced_telegram_available = False
    except ImportError:
        enhanced_telegram_available = None

# 配置日志
logger = logging.getLogger("new_listings_scanner")

class NewListingsScanner:
    """新上币公告扫描类，负责扫描Gate.io新上币公告并推送通知"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化新上币公告扫描器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # 初始化Telegram警报器
        if enhanced_telegram_available is True:
            self.telegram_alerter = EnhancedMultiTelegramAlerter()
            logger.info("使用增强版多账号Telegram警报器")
        elif enhanced_telegram_available is False:
            self.telegram_alerter = TelegramAlerter()
            logger.info("使用标准Telegram警报器")
        else:
            self.telegram_alerter = None
            logger.warning("未找到Telegram警报器，无法发送通知")
        
        # 已扫描公告缓存文件
        self.cache_file = "new_listings_cache.json"
        self.scanned_announcements = self._load_cache()
        
        logger.info("新上币公告扫描模块初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        default_config = {
            "scan_new_listings": True,  # 是否扫描新上币公告
            "scan_interval": 3600,  # 扫描间隔（秒）
            "max_announcements": 10  # 最大公告数量
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # 合并默认配置和加载的配置
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    
                    logger.info(f"从配置文件加载配置成功")
                    return config
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，使用默认配置")
                return default_config
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
            return default_config
    
    def _load_cache(self) -> List[str]:
        """
        加载已扫描公告缓存
        
        Returns:
            已扫描公告ID列表
        """
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    cache = json.load(f)
                    return cache.get("scanned_announcements", [])
            else:
                return []
        except Exception as e:
            logger.error(f"加载缓存失败: {str(e)}")
            return []
    
    def _save_cache(self) -> bool:
        """
        保存已扫描公告缓存
        
        Returns:
            保存是否成功
        """
        try:
            with open(self.cache_file, 'w') as f:
                json.dump({"scanned_announcements": self.scanned_announcements}, f, indent=4)
            
            logger.info(f"保存缓存成功")
            return True
        except Exception as e:
            logger.error(f"保存缓存失败: {str(e)}")
            return False
    
    def scan_new_listings(self) -> List[Dict[str, Any]]:
        """
        扫描Gate.io新上币公告
        
        Returns:
            新上币公告列表
        """
        if not self.config.get("scan_new_listings", True):
            logger.info("新上币公告扫描已禁用")
            return []
        
        logger.info("开始扫描Gate.io新上币公告")
        
        try:
            # 获取Gate.io公告页面
            url = "https://www.gate.io/articlelist/ann"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 查找新上币公告
            announcements = []
            announcement_elements = soup.select(".article-list .article-item")
            
            for element in announcement_elements:
                try:
                    # 获取公告ID
                    link_element = element.select_one("a")
                    if not link_element:
                        continue
                    
                    link = link_element.get("href", "")
                    announcement_id = link.split("/")[-1] if link else ""
                    
                    if not announcement_id or announcement_id in self.scanned_announcements:
                        continue
                    
                    # 获取公告标题
                    title_element = element.select_one(".article-title")
                    title = title_element.text.strip() if title_element else ""
                    
                    # 检查是否为新上币公告
                    if not title or not self._is_new_listing_announcement(title):
                        continue
                    
                    # 获取公告时间
                    time_element = element.select_one(".article-time")
                    publish_time = time_element.text.strip() if time_element else ""
                    
                    # 获取公告链接
                    announcement_url = f"https://www.gate.io{link}" if link else ""
                    
                    # 添加到公告列表
                    announcements.append({
                        "id": announcement_id,
                        "title": title,
                        "publish_time": publish_time,
                        "url": announcement_url
                    })
                    
                    # 添加到已扫描公告列表
                    self.scanned_announcements.append(announcement_id)
                except Exception as e:
                    logger.error(f"解析公告元素失败: {str(e)}")
            
            # 保存缓存
            self._save_cache()
            
            # 限制公告数量
            max_announcements = self.config.get("max_announcements", 10)
            announcements = announcements[:max_announcements]
            
            logger.info(f"扫描完成，发现 {len(announcements)} 个新上币公告")
            return announcements
        except Exception as e:
            logger.error(f"扫描新上币公告失败: {str(e)}")
            return []
    
    def _is_new_listing_announcement(self, title: str) -> bool:
        """
        检查是否为新上币公告
        
        Args:
            title: 公告标题
            
        Returns:
            是否为新上币公告
        """
        # 新上币公告关键词
        keywords = [
            "上线", "上架", "listing", "list", "新币", "new coin", "new token",
            "will be available", "开放", "交易对", "trading pair"
        ]
        
        # 检查标题是否包含关键词
        title_lower = title.lower()
        for keyword in keywords:
            if keyword.lower() in title_lower:
                return True
        
        return False
    
    def send_notifications(self, announcements: List[Dict[str, Any]]) -> bool:
        """
        发送新上币公告通知
        
        Args:
            announcements: 新上币公告列表
            
        Returns:
            发送是否成功
        """
        if not announcements:
            logger.info("没有新上币公告，跳过通知")
            return True
        
        if not self.telegram_alerter or not self.telegram_alerter.is_configured():
            logger.warning("Telegram警报器未配置，无法发送通知")
            return False
        
        try:
            # 构建通知消息
            message = f"🔔 Gate.io新上币公告 🔔\n\n"
            message += f"发现 {len(announcements)} 个新上币公告：\n\n"
            
            for i, announcement in enumerate(announcements, 1):
                message += f"{i}. {announcement['title']}\n"
                message += f"   发布时间: {announcement['publish_time']}\n"
                message += f"   链接: {announcement['url']}\n\n"
            
            message += "⚠️ 注意：新上币通常会带来较大的价格波动，请谨慎交易！"
            
            # 发送通知
            self.telegram_alerter.send_message(message)
            
            logger.info(f"成功发送 {len(announcements)} 个新上币公告通知")
            return True
        except Exception as e:
            logger.error(f"发送新上币公告通知失败: {str(e)}")
            return False
    
    def run_scan(self) -> bool:
        """
        运行扫描并发送通知
        
        Returns:
            扫描是否成功
        """
        try:
            # 扫描新上币公告
            announcements = self.scan_new_listings()
            
            # 发送通知
            if announcements:
                self.send_notifications(announcements)
            
            return True
        except Exception as e:
            logger.error(f"运行扫描失败: {str(e)}")
            return False


def main():
    """主函数"""
    # 配置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("new_listings_scanner.log"),
            logging.StreamHandler()
        ]
    )
    
    print("===== Gate.io新上币公告扫描 =====")
    print("注意: 定时任务功能暂不可用，本工具仅提供手动扫描功能")
    print("如需定期扫描，请使用外部定时工具（如crontab、Windows任务计划程序等）")
    print("例如，使用crontab每小时运行一次：")
    print("0 * * * * cd /path/to/crypto_monitor && python scan_new_listings.py")
    print("")
    
    # 创建扫描器
    scanner = NewListingsScanner()
    
    # 运行扫描
    scanner.run_scan()
    
    print("\n扫描完成！")


if __name__ == "__main__":
    main()
