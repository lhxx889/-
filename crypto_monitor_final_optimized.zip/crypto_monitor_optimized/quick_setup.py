#!/usr/bin/env python3

"""
Gate.io加密货币异动监控系统 - 快捷设置启动脚本
用于快速配置系统参数
"""

import sys
import os

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入快捷设置模块
from src.quick_settings import QuickSettings

if __name__ == "__main__":
    # 创建快捷设置实例
    settings = QuickSettings()
    
    # 运行快捷设置向导
    settings.run_quick_setup()
