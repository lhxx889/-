# Nekobox 代理支持使用指南

## 概述

加密货币监控系统 v2.0 现已支持 Nekobox 代理！Nekobox 是一个基于 sing-box 的通用代理工具，广泛用于 Android 和 PC 平台。

## 🚀 快速开始

### 1. 启动 Nekobox
首先确保您的 Nekobox 客户端正在运行，并配置了代理服务器。

### 2. 配置系统使用 Nekobox
有两种方式配置 Nekobox 代理：

#### 方式一：Web界面配置（推荐）
1. 启动监控系统：`python main.py`
2. 访问 http://localhost:5000/settings
3. 在"交易所设置"部分：
   - 启用代理
   - 选择代理类型为"Nekobox"
   - 启用 Nekobox 代理
   - 开启自动检测（推荐）
4. 点击"检测 Nekobox"按钮
5. 保存设置

#### 方式二：配置文件
编辑 `config/config.json`：

```json
{
  "proxy": {
    "enabled": true,
    "type": "nekobox",
    "nekobox": {
      "enabled": true,
      "auto_detect": true,
      "manual_config": {
        "host": "127.0.0.1",
        "port": 7890,
        "protocol": "socks5"
      }
    }
  }
}
```

## 🔧 配置选项

### 自动检测模式（推荐）
系统会自动检测 Nekobox 在以下端口的代理服务：
- 7890 (混合端口)
- 7891 (SOCKS端口)
- 7892 (HTTP端口)
- 1080 (标准SOCKS端口)
- 8080, 10808, 10809 (其他常见端口)

### 手动配置模式
如果自动检测失败，可以手动指定：
- **主机**: 通常为 127.0.0.1
- **端口**: Nekobox 监听的端口
- **协议**: socks5 或 http

## 📋 支持的 Nekobox 配置

### sing-box 混合端口配置
```json
{
  "inbounds": [
    {
      "type": "mixed",
      "tag": "mixed-in",
      "listen": "127.0.0.1",
      "listen_port": 7890
    }
  ]
}
```

### 分离端口配置
```json
{
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": 7891
    },
    {
      "type": "http",
      "tag": "http-in", 
      "listen": "127.0.0.1",
      "listen_port": 7892
    }
  ]
}
```

## 🛠️ 命令行工具

### 检测 Nekobox 状态
```bash
python -c "
from app.core.nekobox_proxy import NekoboxProxyManager
manager = NekoboxProxyManager()
proxies = manager.detect_nekobox_proxies()
print(f'检测到 {len(proxies)} 个代理')
for p in proxies:
    print(f'  {p[\"type\"]}://{p[\"host\"]}:{p[\"port\"]}')
"
```

### 测试代理连接
```bash
python -c "
from app.core.nekobox_proxy import NekoboxProxyManager
manager = NekoboxProxyManager()
result = manager.test_proxy_connection('socks5://127.0.0.1:7890')
print('连接测试:', '成功' if result['success'] else '失败')
if result['success']:
    print('外部IP:', result['ip'])
"
```

## 🔍 故障排除

### 常见问题

#### 1. 检测不到 Nekobox 代理
**原因**: Nekobox 未运行或端口配置不正确
**解决方案**:
- 确认 Nekobox 正在运行
- 检查 Nekobox 的入站配置
- 确认端口未被其他程序占用

#### 2. 代理连接失败
**原因**: 代理服务器配置问题或网络连接问题
**解决方案**:
- 检查 Nekobox 的出站配置
- 确认代理服务器可用
- 检查防火墙设置

#### 3. 部分网站无法访问
**原因**: 代理规则配置或DNS问题
**解决方案**:
- 检查 Nekobox 的路由规则
- 配置正确的DNS服务器
- 尝试不同的代理协议

### 调试命令

#### 检查端口占用
```bash
netstat -tlnp | grep -E "(7890|7891|7892|1080)"
```

#### 测试端口连通性
```bash
telnet 127.0.0.1 7890
```

#### 查看系统日志
```bash
tail -f logs/crypto_monitor.log | grep -i proxy
```

## 📊 Web界面功能

### 代理状态监控
- 实时显示检测到的代理端口
- 显示当前使用的代理配置
- 提供连接测试功能

### 配置管理
- 启用/禁用 Nekobox 代理
- 切换自动检测/手动配置模式
- 实时保存配置更改

### API 接口
- `GET /api/nekobox/status` - 获取代理状态
- `POST /api/nekobox/detect` - 刷新代理检测
- `POST /api/nekobox/test` - 测试代理连接
- `POST /api/nekobox/config` - 更新代理配置

## 🔄 与其他代理的兼容性

系统支持多种代理配置方式：

1. **手动代理**: 传统的 SOCKS/HTTP 代理配置
2. **Nekobox**: 自动检测和配置 Nekobox 代理
3. **混合模式**: 可以在不同代理方式间切换

## 📝 最佳实践

### 1. 推荐配置
- 使用混合端口 (7890) 获得最佳兼容性
- 启用自动检测以简化配置
- 定期测试代理连接确保稳定性

### 2. 性能优化
- 选择地理位置较近的代理服务器
- 避免使用过载的代理节点
- 定期更新 Nekobox 到最新版本

### 3. 安全建议
- 使用可信的代理服务提供商
- 定期检查代理连接的安全性
- 避免在代理连接中传输敏感信息

## 🆕 版本更新

### v2.0 新增功能
- ✅ Nekobox 自动检测
- ✅ 多端口支持
- ✅ Web界面配置
- ✅ 实时状态监控
- ✅ 连接测试功能

### 未来计划
- 支持更多代理客户端
- 代理性能监控
- 自动故障切换
- 代理规则自定义

---

**技术支持**: 如有问题，请查看系统日志或联系技术支持  
**更新时间**: 2024-06-09  
**版本**: v2.0 with Nekobox Support

