# VLESS 和 Hysteria2 代理配置设计文档

## 概述

本文档详细设计了在加密货币监控应用中集成 VLESS 和 Hysteria2 代理协议的配置模型和实现方案。这些现代代理协议将为应用提供更强大的网络连接能力和更好的性能表现。

## 配置模型设计

### VLESS 配置模型

VLESS (Versatile Lightweight Stream Security) 是一个轻量级的传输协议，具有以下特点：
- 无状态协议设计
- 支持多种传输方式 (TCP, WebSocket, gRPC)
- 内置流量伪装能力
- 支持多种加密方式

VLESS 配置结构设计：

```json
{
  "vless": {
    "enabled": false,
    "servers": [
      {
        "id": "vless-server-1",
        "name": "VLESS 服务器 1",
        "address": "example.com",
        "port": 443,
        "uuid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
        "encryption": "none",
        "flow": "",
        "network": "tcp",
        "security": "tls",
        "sni": "example.com",
        "alpn": ["h2", "http/1.1"],
        "fingerprint": "chrome",
        "tcp_settings": {
          "header": {
            "type": "none"
          }
        },
        "ws_settings": {
          "path": "/",
          "headers": {
            "Host": "example.com"
          }
        },
        "grpc_settings": {
          "service_name": "grpc_service"
        },
        "tls_settings": {
          "server_name": "example.com",
          "allow_insecure": false,
          "certificates": []
        },
        "priority": 1,
        "active": true
      }
    ],
    "load_balancing": "round_robin",
    "health_check": {
      "enabled": true,
      "interval": 300,
      "timeout": 10,
      "url": "https://www.google.com/generate_204"
    }
  }
}
```

### Hysteria2 配置模型

Hysteria2 是基于 QUIC 协议的高性能代理协议，具有以下特点：
- 基于 UDP 的 QUIC 协议
- 内置拥塞控制算法
- 支持多路复用
- 优秀的弱网环境表现

Hysteria2 配置结构设计：

```json
{
  "hysteria2": {
    "enabled": false,
    "servers": [
      {
        "id": "hy2-server-1",
        "name": "Hysteria2 服务器 1",
        "server": "example.com:443",
        "auth": "password_or_uuid",
        "tls": {
          "sni": "example.com",
          "insecure": false,
          "pinSHA256": ""
        },
        "quic": {
          "initStreamReceiveWindow": 8388608,
          "maxStreamReceiveWindow": 8388608,
          "initConnReceiveWindow": 20971520,
          "maxConnReceiveWindow": 20971520,
          "maxIdleTimeout": "30s",
          "maxIncomingStreams": 1024,
          "disablePathMTUDiscovery": false
        },
        "bandwidth": {
          "up": "100 mbps",
          "down": "100 mbps"
        },
        "fastOpen": true,
        "lazy": false,
        "hopInterval": "30s",
        "priority": 1,
        "active": true
      }
    ],
    "load_balancing": "round_robin",
    "health_check": {
      "enabled": true,
      "interval": 300,
      "timeout": 10,
      "url": "https://www.google.com/generate_204"
    }
  }
}
```

## 配置文件更新

基于现有的配置文件结构，我们需要在 `proxy` 部分添加新的协议支持。更新后的配置文件结构如下：

```json
{
  "proxy": {
    "enabled": true,
    "type": "manual",
    "http": "socks5://127.0.0.1:1080",
    "https": "socks5://127.0.0.1:1080",
    "nekobox": {
      "enabled": true,
      "auto_detect": true,
      "manual_config": {
        "host": "127.0.0.1",
        "port": 7890,
        "protocol": "socks5"
      }
    },
    "vless": {
      "enabled": false,
      "servers": [],
      "load_balancing": "round_robin",
      "health_check": {
        "enabled": true,
        "interval": 300,
        "timeout": 10,
        "url": "https://www.google.com/generate_204"
      }
    },
    "hysteria2": {
      "enabled": false,
      "servers": [],
      "load_balancing": "round_robin",
      "health_check": {
        "enabled": true,
        "interval": 300,
        "timeout": 10,
        "url": "https://www.google.com/generate_204"
      }
    }
  }
}
```

## 数据库模型设计

为了支持服务器配置的持久化存储和管理，我们需要设计相应的数据库表结构。

### 代理服务器表 (proxy_servers)

```sql
CREATE TABLE proxy_servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    protocol TEXT NOT NULL,  -- 'vless', 'hysteria2'
    server_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    config TEXT NOT NULL,  -- JSON 格式的配置
    priority INTEGER DEFAULT 1,
    active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_health_check TIMESTAMP,
    health_status TEXT DEFAULT 'unknown'  -- 'healthy', 'unhealthy', 'unknown'
);
```

### 代理连接日志表 (proxy_connection_logs)

```sql
CREATE TABLE proxy_connection_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id TEXT NOT NULL,
    protocol TEXT NOT NULL,
    connection_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    response_time INTEGER,  -- 毫秒
    success BOOLEAN NOT NULL,
    error_message TEXT,
    external_ip TEXT
);
```

## API 接口设计

### VLESS 服务器管理 API

#### 获取 VLESS 服务器列表
```
GET /api/vless/servers
Response: {
  "success": true,
  "servers": [...]
}
```

#### 添加 VLESS 服务器
```
POST /api/vless/servers
Request: {
  "name": "服务器名称",
  "address": "example.com",
  "port": 443,
  "uuid": "...",
  "network": "tcp",
  "security": "tls",
  ...
}
Response: {
  "success": true,
  "server_id": "vless-server-1"
}
```

#### 更新 VLESS 服务器
```
PUT /api/vless/servers/{server_id}
Request: { ... }
Response: {
  "success": true,
  "message": "服务器配置已更新"
}
```

#### 删除 VLESS 服务器
```
DELETE /api/vless/servers/{server_id}
Response: {
  "success": true,
  "message": "服务器已删除"
}
```

#### 测试 VLESS 服务器连接
```
POST /api/vless/servers/{server_id}/test
Response: {
  "success": true,
  "response_time": 150,
  "external_ip": "1.2.3.4"
}
```

### Hysteria2 服务器管理 API

#### 获取 Hysteria2 服务器列表
```
GET /api/hysteria2/servers
Response: {
  "success": true,
  "servers": [...]
}
```

#### 添加 Hysteria2 服务器
```
POST /api/hysteria2/servers
Request: {
  "name": "服务器名称",
  "server": "example.com:443",
  "auth": "password",
  "bandwidth": {
    "up": "100 mbps",
    "down": "100 mbps"
  },
  ...
}
Response: {
  "success": true,
  "server_id": "hy2-server-1"
}
```

#### 更新 Hysteria2 服务器
```
PUT /api/hysteria2/servers/{server_id}
Request: { ... }
Response: {
  "success": true,
  "message": "服务器配置已更新"
}
```

#### 删除 Hysteria2 服务器
```
DELETE /api/hysteria2/servers/{server_id}
Response: {
  "success": true,
  "message": "服务器已删除"
}
```

#### 测试 Hysteria2 服务器连接
```
POST /api/hysteria2/servers/{server_id}/test
Response: {
  "success": true,
  "response_time": 80,
  "external_ip": "1.2.3.4"
}
```

### 通用代理管理 API

#### 获取代理状态
```
GET /api/proxy/status
Response: {
  "success": true,
  "current_proxy": {
    "protocol": "vless",
    "server_id": "vless-server-1",
    "name": "VLESS 服务器 1"
  },
  "health_status": "healthy"
}
```

#### 切换代理服务器
```
POST /api/proxy/switch
Request: {
  "protocol": "hysteria2",
  "server_id": "hy2-server-1"
}
Response: {
  "success": true,
  "message": "已切换到 Hysteria2 服务器 1"
}
```

#### 健康检查
```
POST /api/proxy/health-check
Response: {
  "success": true,
  "results": [
    {
      "server_id": "vless-server-1",
      "protocol": "vless",
      "healthy": true,
      "response_time": 150
    },
    ...
  ]
}
```

## 配置验证规则

### VLESS 配置验证

1. **必填字段验证**
   - address: 必须是有效的域名或 IP 地址
   - port: 必须是 1-65535 范围内的整数
   - uuid: 必须是有效的 UUID 格式

2. **网络类型验证**
   - network: 必须是 "tcp", "ws", "grpc" 中的一个
   - 根据网络类型验证相应的设置

3. **安全设置验证**
   - security: 必须是 "none", "tls" 中的一个
   - 如果是 tls，必须提供有效的 SNI

### Hysteria2 配置验证

1. **必填字段验证**
   - server: 必须是 "host:port" 格式
   - auth: 必须提供认证信息

2. **带宽设置验证**
   - 带宽值必须是有效的格式，如 "100 mbps", "1 gbps"

3. **QUIC 设置验证**
   - 各种窗口大小必须是正整数
   - 超时时间必须是有效的时间格式

## 错误处理机制

### 配置错误处理

1. **格式错误**
   - 返回详细的字段验证错误信息
   - 提供修正建议

2. **连接错误**
   - 记录连接失败的详细信息
   - 提供故障排除指导

3. **协议错误**
   - 检测不支持的协议版本
   - 提供升级建议

### 故障转移机制

1. **自动故障转移**
   - 当前代理服务器不可用时自动切换
   - 根据优先级选择备用服务器

2. **健康检查**
   - 定期检查所有配置的服务器
   - 更新服务器健康状态

3. **负载均衡**
   - 支持轮询、随机、最少连接等算法
   - 根据服务器性能动态调整

## 安全考虑

### 配置安全

1. **敏感信息保护**
   - UUID、密码等敏感信息加密存储
   - API 传输时使用 HTTPS

2. **访问控制**
   - 配置修改需要管理员权限
   - 记录所有配置变更操作

3. **输入验证**
   - 严格验证所有用户输入
   - 防止注入攻击

### 网络安全

1. **证书验证**
   - 默认启用 TLS 证书验证
   - 支持自定义 CA 证书

2. **流量伪装**
   - 支持 WebSocket 和 gRPC 传输
   - 可配置自定义 HTTP 头

3. **连接加密**
   - 所有代理连接使用强加密
   - 支持最新的加密算法

这个设计文档为 VLESS 和 Hysteria2 代理协议的集成提供了完整的技术框架，确保了功能的完整性、安全性和可扩展性。

