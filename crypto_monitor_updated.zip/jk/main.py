#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
加密货币监控系统 v2.0
现代化的加密货币价格监控和公告扫描系统

主要改进:
- 模块化架构设计
- SQLite数据库存储
- Web界面管理
- 更好的错误处理
- 配置文件管理
- 异步处理支持
- VLESS 和 Hysteria2 代理支持
"""

import os
import sys
import logging
from pathlib import Path

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.core.config import Config
from app.core.database import Database
from app.core.monitor import CryptoMonitor
from app.web.app import create_app

def setup_logging():
    """设置日志配置"""
    log_dir = PROJECT_ROOT / "logs"
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_dir / "crypto_monitor.log"),
            logging.StreamHandler()
        ]
    )

setup_logging()
logger = logging.getLogger(__name__)

# 初始化配置
config = Config()
logger.info("配置加载完成")

# 初始化数据库
db = Database(config.database_path)
db.init_database()
logger.info("数据库初始化完成")

# 创建监控器
monitor = CryptoMonitor(config, db)

# 启动监控
monitor.start_monitoring()
logger.info("监控线程已启动")

# 创建Web应用并赋值给全局变量 app，供 Gunicorn 调用
app = create_app(config, monitor)
logger.info("Web服务器已准备就绪。")


