import requests
import logging
import hashlib
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup

class BaseExchangeClient:
    """交易所客户端基类，定义通用接口和公告解析逻辑"""
    
    def __init__(self, config, exchange_name: str):
        self.config = config
        self.exchange_name = exchange_name
        self.logger = logging.getLogger(__name__)
        self.session = requests.Session()
        
        # 设置通用请求头
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json',
            'Accept-Language': 'en-US,en;q=0.9',
        })
        
        self.exchange_config = config.exchanges.get(exchange_name, {})
        self.api_base = self.exchange_config.get('api_base')
        self.ticker_endpoint = self.exchange_config.get('ticker_endpoint')
        self.announcement_url = self.exchange_config.get('announcement_url')
        self.announcement_parsing_rules = self.exchange_config.get('announcement_parsing_rules', {})

    def make_request(self, url: str, method: str = 'GET', **kwargs) -> Optional[requests.Response]:
        """发起HTTP请求"""
        try:
            response = self.session.request(method, url, timeout=15, **kwargs)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            self.logger.error(f"请求失败 {url}: {e}")
            return None

    def get_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的ticker数据，子类必须实现"""
        raise NotImplementedError

    def get_announcements(self) -> List[Dict[str, Any]]:
        """获取公告信息"""
        if not self.exchange_config.get('enabled', False):
            return []
        
        response = self.make_request(self.announcement_url)
        if not response:
            return []
        
        return self._parse_announcements(response.text)

    def _parse_announcements(self, html_content: str) -> List[Dict[str, Any]]:
        """通用公告页面解析方法，使用配置中的规则"""
        announcements = []
        rules = self.announcement_parsing_rules
        
        if not rules:
            self.logger.warning(f"交易所 {self.exchange_name} 未配置公告解析规则")
            return []

        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            article_selector = rules.get('article_selector')
            title_selector = rules.get('title_selector')
            link_selector = rules.get('link_selector')
            date_selector = rules.get('date_selector')
            base_url = rules.get('base_url', '')
            
            if not all([article_selector, title_selector, link_selector]):
                self.logger.error(f"交易所 {self.exchange_name} 公告解析规则不完整")
                return []

            articles = soup.select(article_selector)
            
            for article in articles:
                try:
                    title_element = article.select_one(title_selector)
                    link_element = article.select_one(link_selector)
                    date_element = article.select_one(date_selector) if date_selector else None
                    
                    if title_element and link_element:
                        title = title_element.text.strip()
                        link = link_element.get('href')
                        if not link.startswith('http'):
                            link = f"{base_url}{link}"
                        
                        date = date_element.text.strip() if date_element else "未知日期"
                        content_hash = hashlib.md5(f"{title}_{link}".encode()).hexdigest()
                        
                        is_new_listing = any(
                            keyword.lower() in title.lower() 
                            for keyword in self.config.new_listing_keywords
                        )
                        
                        announcements.append({
                            "exchange": self.exchange_name,
                            "title": title,
                            "url": link,
                            "date": date,
                            "content_hash": content_hash,
                            "is_new_listing": is_new_listing
                        })
                except Exception as e:
                    self.logger.error(f"解析 {self.exchange_name} 公告项目时出错: {e}")
            
            self.logger.info(f"成功解析 {self.exchange_name} {len(announcements)} 条公告")
        except Exception as e:
            self.logger.error(f"解析 {self.exchange_name} 公告页面失败: {e}")
        
        return announcements


