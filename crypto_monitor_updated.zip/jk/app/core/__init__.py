#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
核心模块
"""

import logging

# 导入其他核心模块
from .api_client import ExchangeAPIManager # Changed from APIClient
from .config import Config
from .database import Database
from .monitor import CryptoMonitor
from .notifications import NotificationManager

# 初始化日志
logger = logging.getLogger(__name__)

# 移除代理相关导入
# from .proxy_manager import ProxyManager
# from .vless_proxy import VLESSProxyManager
# from .hysteria2_proxy import Hysteria2ProxyManager
# from .nekobox_proxy import NekoboxProxyManager


