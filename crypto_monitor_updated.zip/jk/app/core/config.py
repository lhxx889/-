import json
import os
from pathlib import Path
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)

class Config:
    """配置管理类"""
    
    def __init__(self, config_file: str = None):
        self.project_root = Path(__file__).parent.parent.parent
        self.config_file = config_file or self.project_root / "config" / "config.json"
        self.config_data = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        default_config = {
            # 基础配置
            "debug_mode": False,
            "web_port": 5000,
            "database_path": str(self.project_root / "data" / "crypto_monitor.db"),
            
            # 监控配置
            "price_change_threshold": 5.0,
            "price_check_interval": 300,
            "announcement_scan_interval": 3600,
            
            # 交易所配置
            "exchanges": {
                "binance": {
                    "enabled": True,
                    "api_base": "https://api.binance.us",
                    "ticker_endpoint": "/api/v3/ticker/24hr",
                    "announcement_url": "https://support.binance.us/en/collections/10384537-announcements",
                    "announcement_parsing_rules": {
                        "article_selector": "article.article-list-item",
                        "title_selector": "h3.article-list-item-title",
                        "link_selector": "a",
                        "date_selector": "time",
                        "base_url": "https://support.binance.us"
                    }
                },
                "gate": {
                    "enabled": True,
                    "api_base": "https://api.gateio.ws/api/v4",
                    "ticker_endpoint": "/spot/tickers",
                    "announcement_url": "https://www.gate.io/announcements",
                    "announcement_parsing_rules": {
                        "article_selector": "div.article-item, div.announcement-item",
                        "title_selector": "h3, div.title",
                        "link_selector": "a",
                        "date_selector": "time, div.date",
                        "base_url": "https://www.gate.io"
                    }
                }
            },
            
            # 通知配置
            "notifications": {
                "telegram": {
                    "enabled": False,
                    "bot_token": "",
                    "chat_id": "",
                    "price_notify": True,
                    "announcement_notify": True,
                    "min_price_change": 10.0
                },
                "email": {
                    "enabled": False,
                    "smtp_server": "",
                    "smtp_port": 587,
                    "username": "",
                    "password": "",
                    "to_email": ""
                }
            },
            
            # 新上币关键词
            "new_listing_keywords": [
                "listing", "新上币", "new coin", "new token", 
                "will list", "上线", "launch", "debut"
            ]
        }
        
        logger.info("Default config loaded.")

        # 如果配置文件存在，加载并合并
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    file_config = json.load(f)
                    logger.info(f"Config file '{self.config_file}' loaded. Content: {file_config}")
                    
                    # 移除代理配置部分
                    if 'proxy' in file_config:
                        del file_config['proxy']
                        logger.info("Removed 'proxy' section from file config.")
                    
                    # 深度合并配置，特别是 exchanges 部分
                    for key, value in file_config.items():
                        if key == 'exchanges' and isinstance(value, dict) and 'exchanges' in default_config:
                            for exchange_name, exchange_settings in value.items():
                                if exchange_name in default_config['exchanges']:
                                    default_config['exchanges'][exchange_name].update(exchange_settings)
                                    logger.info(f"Merged settings for exchange '{exchange_name}'.")
                                else:
                                    default_config['exchanges'][exchange_name] = exchange_settings
                                    logger.info(f"Added new exchange '{exchange_name}'.")
                        else:
                            default_config[key] = value
                    logger.info("File config merged with default config.")

            except (json.JSONDecodeError, IOError) as e:
                logger.error(f"配置文件加载失败，使用默认配置: {e}")
        else:
            logger.warning(f"Config file '{self.config_file}' not found. Creating default config file.")
            # 创建默认配置文件
            self._save_config(default_config)
            
        logger.info(f"Final loaded config_data: {default_config}")
        return default_config
    
    def _save_config(self, config_data: Dict[str, Any]):
        """保存配置到文件"""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            logger.info(f"Config saved to '{self.config_file}'.")
        except IOError as e:
            logger.error(f"配置文件保存失败: {e}")
    
    def save(self):
        """保存当前配置"""
        self._save_config(self.config_data)
    
    def get(self, key: str, default=None):
        """获取配置值"""
        keys = key.split('.')
        value = self.config_data
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
    
    def set(self, key: str, value: Any):
        """设置配置值"""
        keys = key.split('.')
        config = self.config_data
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        config[keys[-1]] = value
    
    # 便捷属性访问
    @property
    def debug_mode(self) -> bool:
        return self.get('debug_mode', False)
    
    @property
    def web_port(self) -> int:
        return self.get('web_port', 5000)
    
    @property
    def database_path(self) -> str:
        return self.get('database_path')
    
    @property
    def price_change_threshold(self) -> float:
        return self.get('price_change_threshold', 5.0)
    
    @property
    def price_check_interval(self) -> int:
        return self.get('price_check_interval', 300)
    
    @property
    def announcement_scan_interval(self) -> int:
        return self.get('announcement_scan_interval', 3600)
    
    @property
    def exchanges(self) -> Dict[str, Any]:
        exchanges_data = self.get('exchanges', {})
        logger.info(f"Accessing 'exchanges' property. Current value: {exchanges_data}")
        return exchanges_data
    
    @property
    def new_listing_keywords(self) -> list:
        return self.get('new_listing_keywords', [])
    
    @property
    def telegram_config(self) -> Dict[str, Any]:
        telegram_data = self.get('notifications.telegram', {})
        logger.info(f"Accessing 'telegram_config' property. Current value: {telegram_data}")
        return telegram_data


