#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
数据库管理模块
使用SQLite存储监控数据
"""

import sqlite3
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

class Database:
    """数据库管理类"""
    
    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger(__name__)
        
    def get_connection(self) -> sqlite3.Connection:
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # 使结果可以按列名访问
        return conn
    
    def init_database(self):
        """初始化数据库表"""
        with self.get_connection() as conn:
            # 价格变动记录表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS price_changes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exchange TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    price REAL NOT NULL,
                    change_percent REAL NOT NULL,
                    direction TEXT NOT NULL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # 公告记录表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS announcements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exchange TEXT NOT NULL,
                    title TEXT NOT NULL,
                    url TEXT NOT NULL,
                    date TEXT,
                    content_hash TEXT UNIQUE NOT NULL,
                    is_new_listing BOOLEAN DEFAULT 0,
                    is_notified BOOLEAN DEFAULT 0,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # 监控状态表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS monitor_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    component TEXT NOT NULL,
                    status TEXT NOT NULL,
                    message TEXT,
                    last_run DATETIME,
                    next_run DATETIME,
                    error_count INTEGER DEFAULT 0,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # 配置表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # 创建索引
            conn.execute("CREATE INDEX IF NOT EXISTS idx_price_changes_symbol ON price_changes(symbol)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_price_changes_timestamp ON price_changes(timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_announcements_exchange ON announcements(exchange)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_announcements_timestamp ON announcements(timestamp)")
            
            conn.commit()
            self.logger.info("数据库表初始化完成")
    
    def save_price_change(self, exchange: str, symbol: str, price: float, 
                         change_percent: float, direction: str) -> int:
        """保存价格变动记录"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO price_changes (exchange, symbol, price, change_percent, direction)
                VALUES (?, ?, ?, ?, ?)
            """, (exchange, symbol, price, change_percent, direction))
            conn.commit()
            return cursor.lastrowid
    
    def save_announcement(self, exchange: str, title: str, url: str, 
                         date: str, content_hash: str, is_new_listing: bool = False) -> Optional[int]:
        """保存公告记录"""
        try:
            with self.get_connection() as conn:
                cursor = conn.execute("""
                    INSERT INTO announcements (exchange, title, url, date, content_hash, is_new_listing)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (exchange, title, url, date, content_hash, is_new_listing))
                conn.commit()
                return cursor.lastrowid
        except sqlite3.IntegrityError:
            # 公告已存在
            return None
    
    def get_recent_price_changes(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取最近的价格变动记录"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM price_changes 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_recent_announcements(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取最近的公告记录"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM announcements 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_new_listings(self, limit: int = 20) -> List[Dict[str, Any]]:
        """获取新上币公告"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM announcements 
                WHERE is_new_listing = 1 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_price_changes_by_symbol(self, symbol: str, limit: int = 50) -> List[Dict[str, Any]]:
        """获取特定交易对的价格变动历史"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM price_changes 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (symbol, limit))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self.get_connection() as conn:
            # 总记录数
            price_count = conn.execute("SELECT COUNT(*) FROM price_changes").fetchone()[0]
            announcement_count = conn.execute("SELECT COUNT(*) FROM announcements").fetchone()[0]
            new_listing_count = conn.execute("SELECT COUNT(*) FROM announcements WHERE is_new_listing = 1").fetchone()[0]
            
            # 今日记录数
            today = datetime.now().strftime("%Y-%m-%d")
            today_price_count = conn.execute(
                "SELECT COUNT(*) FROM price_changes WHERE DATE(timestamp) = ?", (today,)
            ).fetchone()[0]
            today_announcement_count = conn.execute(
                "SELECT COUNT(*) FROM announcements WHERE DATE(timestamp) = ?", (today,)
            ).fetchone()[0]
            
            # 活跃交易对
            active_symbols = conn.execute("""
                SELECT symbol, COUNT(*) as count 
                FROM price_changes 
                WHERE DATE(timestamp) = ? 
                GROUP BY symbol 
                ORDER BY count DESC 
                LIMIT 10
            """, (today,)).fetchall()
            
            return {
                "total_price_changes": price_count,
                "total_announcements": announcement_count,
                "total_new_listings": new_listing_count,
                "today_price_changes": today_price_count,
                "today_announcements": today_announcement_count,
                "active_symbols": [dict(row) for row in active_symbols]
            }
    
    def update_monitor_status(self, component: str, status: str, 
                            message: str = None, next_run: datetime = None):
        """更新监控组件状态"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO monitor_status 
                (component, status, message, last_run, next_run, updated_at)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP)
            """, (component, status, message, next_run))
            conn.commit()
    
    def get_monitor_status(self) -> List[Dict[str, Any]]:
        """获取所有监控组件状态"""
        with self.get_connection() as conn:
            cursor = conn.execute("SELECT * FROM monitor_status ORDER BY component")
            return [dict(row) for row in cursor.fetchall()]
    
    def cleanup_old_data(self, days: int = 30):
        """清理旧数据"""
        with self.get_connection() as conn:
            # 清理旧的价格变动记录
            conn.execute("""
                DELETE FROM price_changes 
                WHERE timestamp < datetime("now", "-{} days")
            """.format(days))
            
            # 清理旧的公告记录（保留新上币公告）
            conn.execute("""
                DELETE FROM announcements 
                WHERE timestamp < datetime("now", "-{} days") 
                AND is_new_listing = 0
            """.format(days))
            
            conn.commit()
            self.logger.info(f"清理了 {days} 天前的旧数据")
    
    def set_setting(self, key: str, value: Any):
        """设置配置项"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO settings (key, value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, (key, json.dumps(value)))
            conn.commit()
    
    def get_setting(self, key: str, default=None):
        """获取配置项"""
        with self.get_connection() as conn:
            cursor = conn.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
            return default


