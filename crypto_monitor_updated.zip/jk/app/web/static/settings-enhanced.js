// 设置页面增强版 JavaScript

// 全局变量
let currentEditingVLESS = null;
let currentEditingHysteria2 = null;
let vlessServers = [];
let hysteria2Servers = [];

// 页面加载时初始化
document.addEventListener("DOMContentLoaded", function() {
    initializePage();
    setupEventListeners();
});

function initializePage() {
    // 初始化协议标签切换
    setupProtocolTabs();
    
    // 初始化 VLESS 网络类型切换
    setupVLESSNetworkChange();
    
    // 加载服务器列表
    loadVLESSServers();
    loadHysteria2Servers();
}

function setupEventListeners() {
    // 监控参数表单提交
    document.getElementById("monitoringForm").addEventListener("submit", handleMonitoringFormSubmit);
    
    // Telegram 设置表单提交
    document.getElementById("notificationForm").addEventListener("submit", handleTelegramFormSubmit);
    
    // VLESS 网络类型切换
    document.getElementById("vlessNetwork").addEventListener("change", handleVLESSNetworkChange);
    document.getElementById("vlessSecurity").addEventListener("change", handleVLESSSecurityChange);

    // Telegram 测试连接按钮
    document.getElementById("testTelegramConnection").addEventListener("click", testTelegram);
}

function setupProtocolTabs() {
    const tabs = document.querySelectorAll(".protocol-tab");
    const contents = document.querySelectorAll(".protocol-content");
    
    tabs.forEach(tab => {
        tab.addEventListener("click", function() {
            const protocol = this.dataset.protocol;
            
            // 移除所有活跃状态
            tabs.forEach(t => t.classList.remove("active"));
            contents.forEach(c => c.classList.remove("active"));
            
            // 设置当前活跃状态
            this.classList.add("active");
            document.getElementById(protocol + "-content").classList.add("active");
        });
    });
}

// 监控参数表单处理
function handleMonitoringFormSubmit(e) {
    e.preventDefault();
    
    const data = {
        price_change_threshold: parseFloat(document.getElementById("priceThreshold").value),
        price_check_interval: parseInt(document.getElementById("priceInterval").value),
        announcement_scan_interval: parseInt(document.getElementById("announcementInterval").value)
    };
    
    fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert("监控参数已保存", "success");
        } else {
            showAlert("保存失败: " + result.message, "danger");
        }
    })
    .catch(error => {
        showAlert("请求失败: " + error.message, "danger");
    });
}

// Telegram 设置表单处理
function handleTelegramFormSubmit(e) {
    e.preventDefault();
    
    const data = {
        bot_token: document.getElementById("telegramBotToken").value,
        chat_id: document.getElementById("telegramChatId").value,
        enabled: document.getElementById("telegramEnabled").checked,
        price_notify: document.getElementById("telegramPriceNotify").checked,
        announcement_notify: document.getElementById("telegramAnnouncementNotify").checked,
        min_price_change: parseFloat(document.getElementById("telegramMinPriceChange").value) || 10
    };
    
    fetch("/api/telegram/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert("Telegram 设置已保存", "success");
        } else {
            showAlert("保存失败: " + result.message, "danger");
        }
    })
    .catch(error => {
        showAlert("请求失败: " + error.message, "danger");
    });
}

function testTelegram() {
    fetch("/api/telegram/test", { method: "POST" })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(`✅ Telegram 连接测试成功\\n外部IP: ${result.ip}`, "success");
            } else {
                showAlert(`❌ Telegram 连接测试失败: ${result.message}`, "danger");
            }
        })
        .catch(error => {
            showAlert(`❌ 测试失败: ${error.message}`, "danger");
        });
}

// VLESS 相关函数
function loadVLESSServers() {
    fetch("/api/vless/servers")
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                vlessServers = result.servers;
                renderVLESSServerList();
            } else {
                showAlert("加载 VLESS 服务器失败: " + result.message, "danger");
            }
        })
        .catch(error => {
            console.error("加载 VLESS 服务器失败:", error);
            showAlert("加载 VLESS 服务器失败: " + error.message, "danger");
        });
}

function renderVLESSServerList() {
    const container = document.getElementById("vlessServerList");
    
    if (vlessServers.length === 0) {
        container.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fas fa-inbox fa-2x mb-2"></i>
                <p>暂无 VLESS 服务器配置</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = vlessServers.map(server => `
        <div class="proxy-server-card p-3 ${server.active ? "active" : ""}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <span class="server-status ${getServerHealthStatus(server)}"></span>
                        ${server.name}
                        ${server.active ? "<span class=\"badge bg-success ms-2\">活跃</span>" : "<span class=\"badge bg-secondary ms-2\">禁用</span>"}
                    </h6>
                    <p class="text-muted mb-1">
                        <i class="fas fa-server me-1"></i>
                        ${server.address}:${server.port}
                    </p>
                    <p class="text-muted mb-0">
                        <i class="fas fa-network-wired me-1"></i>
                        ${server.network || "tcp"} / ${server.security || "none"}
                        <span class="ms-3">
                            <i class="fas fa-sort-numeric-up me-1"></i>
                            优先级: ${server.priority || 1}
                        </span>
                    </p>
                </div>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-success" onclick="testVLESSServer(\"${server.id}\")">
                        <i class="fas fa-vial"></i>
                    </button>
                    <button type="button" class="btn btn-outline-primary" onclick="editVLESSServer(\"${server.id}\")">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteVLESSServer(\"${server.id}\", \"${server.name}\")">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join("");
}

function showAddVLESSModal() {
    currentEditingVLESS = null;
    document.getElementById("vlessModalTitle").textContent = "添加 VLESS 服务器";
    document.getElementById("vlessForm").reset();
    document.getElementById("vlessServerId").value = "";
    document.getElementById("vlessPriority").value = "1";
    document.getElementById("vlessNetwork").value = "tcp";
    document.getElementById("vlessSecurity").value = "none";
    document.getElementById("vlessEncryption").value = "none";
    document.getElementById("vlessActive").checked = true;
    
    handleVLESSNetworkChange();
    handleVLESSSecurityChange();
    
    new bootstrap.Modal(document.getElementById("vlessModal")).show();
}

function editVLESSServer(serverId) {
    const server = vlessServers.find(s => s.id === serverId);
    if (!server) return;
    
    currentEditingVLESS = serverId;
    document.getElementById("vlessModalTitle").textContent = "编辑 VLESS 服务器";
    
    // 填充表单
    document.getElementById("vlessServerId").value = server.id;
    document.getElementById("vlessName").value = server.name;
    document.getElementById("vlessAddress").value = server.address;
    document.getElementById("vlessPort").value = server.port;
    document.getElementById("vlessUuid").value = server.uuid;
    document.getElementById("vlessNetwork").value = server.network || "tcp";
    document.getElementById("vlessSecurity").value = server.security || "none";
    document.getElementById("vlessEncryption").value = server.encryption || "none";
    document.getElementById("vlessPriority").value = server.priority || 1;
    document.getElementById("vlessActive").checked = server.active !== false;
    
    // TLS 设置
    if (server.tls_settings) {
        document.getElementById("vlessSni").value = server.tls_settings.server_name || "";
        document.getElementById("vlessAllowInsecure").checked = server.tls_settings.allow_insecure || false;
    }
    
    // WebSocket 设置
    if (server.ws_settings) {
        document.getElementById("vlessWsPath").value = server.ws_settings.path || "/";
        document.getElementById("vlessWsHost").value = server.ws_settings.headers?.Host || "";
    }
    
    // gRPC 设置
    if (server.grpc_settings) {
        document.getElementById("vlessGrpcService").value = server.grpc_settings.service_name || "";
    }
    
    handleVLESSNetworkChange();
    handleVLESSSecurityChange();
    
    new bootstrap.Modal(document.getElementById("vlessModal")).show();
}

function setupVLESSNetworkChange() {
    document.getElementById("vlessNetwork").addEventListener("change", handleVLESSNetworkChange);
    document.getElementById("vlessSecurity").addEventListener("change", handleVLESSSecurityChange);
}

function handleVLESSNetworkChange() {
    const network = document.getElementById("vlessNetwork").value;
    const wsSettings = document.getElementById("vlessWsSettings");
    const grpcSettings = document.getElementById("vlessGrpcSettings");
   
    if (network === "ws") {
        wsSettings.style.display = "block";
        grpcSettings.style.display = "none";
    } else if (network === "grpc") {
        wsSettings.style.display = "none";
        grpcSettings.style.display = "block";
    } else {
        wsSettings.style.display = "none";
        grpcSettings.style.display = "none";
    }
}

function handleVLESSSecurityChange() {
    const security = document.getElementById("vlessSecurity").value;
    const tlsSettings = document.getElementById("vlessTlsSettings");
    
    if (security === "tls") {
        tlsSettings.style.display = "block";
    } else {
        tlsSettings.style.display = "none";
    }
}

function saveVLESSServer() {
    const serverId = document.getElementById("vlessServerId").value || generateUniqueId();
    const name = document.getElementById("vlessName").value;
    const address = document.getElementById("vlessAddress").value;
    const port = parseInt(document.getElementById("vlessPort").value);
    const uuid = document.getElementById("vlessUuid").value;
    const network = document.getElementById("vlessNetwork").value;
    const security = document.getElementById("vlessSecurity").value;
    const encryption = document.getElementById("vlessEncryption").value;
    const priority = parseInt(document.getElementById("vlessPriority").value);
    const active = document.getElementById("vlessActive").checked;
    
    const tls_settings = security === "tls" ? {
        server_name: document.getElementById("vlessSni").value,
        allow_insecure: document.getElementById("vlessAllowInsecure").checked
    } : null;
    
    const ws_settings = network === "ws" ? {
        path: document.getElementById("vlessWsPath").value,
        headers: { Host: document.getElementById("vlessWsHost").value }
    } : null;
    
    const grpc_settings = network === "grpc" ? {
        service_name: document.getElementById("vlessGrpcService").value
    } : null;
    
    const serverData = {
        id: serverId,
        name, address, port, uuid, network, security, encryption, priority, active,
        tls_settings,
        ws_settings,
        grpc_settings
    };
    
    const url = currentEditingVLESS ? `/api/vless/servers/${serverId}` : 
                                      `/api/vless/servers`;
    const method = currentEditingVLESS ? "PUT" : "POST";
    
    fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(serverData)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert("VLESS 服务器已保存", "success");
            loadVLESSServers();
            bootstrap.Modal.getInstance(document.getElementById("vlessModal")).hide();
        } else {
            showAlert("保存失败: " + result.message, "danger");
        }
    })
    .catch(error => {
        showAlert("请求失败: " + error.message, "danger");
    });
}

function deleteVLESSServer(serverId, serverName) {
    if (!confirm(`确定要删除 VLESS 服务器 "${serverName}" 吗？`)) {
        return;
    }
    
    fetch(`/api/vless/servers/${serverId}`, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert("VLESS 服务器已删除", "success");
            loadVLESSServers();
        } else {
            showAlert("删除失败: " + result.message, "danger");
        }
    })
    .catch(error => {
        showAlert("请求失败: " + error.message, "danger");
    });
}

function testVLESSServer(serverId) {
    fetch(`/api/vless/servers/${serverId}/test`, { method: "POST" })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(`✅ VLESS 服务器测试成功\\n外部IP: ${result.ip}`, "success");
            } else {
                showAlert(`❌ VLESS 服务器测试失败: ${result.message}`, "danger");
            }
        })
        .catch(error => {
            showAlert(`❌ 测试失败: ${error.message}`, "danger");
        });
}

// Hysteria2 相关函数
function loadHysteria2Servers() {
    fetch("/api/hysteria2/servers")
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                hysteria2Servers = result.servers;
                renderHysteria2ServerList();
            } else {
                showAlert("加载 Hysteria2 服务器失败: " + result.message, "danger");
            }
        })
        .catch(error => {
            console.error("加载 Hysteria2 服务器失败:", error);
            showAlert("加载 Hysteria2 服务器失败: " + error.message, "danger");
        });
}

function renderHysteria2ServerList() {
    const container = document.getElementById("hysteria2ServerList");
    
    if (hysteria2Servers.length === 0) {
        container.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fas fa-inbox fa-2x mb-2"></i>
                <p>暂无 Hysteria2 服务器配置</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = hysteria2Servers.map(server => `
        <div class="proxy-server-card p-3 ${server.active ? "active" : ""}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <span class="server-status ${getServerHealthStatus(server)}"></span>
                        ${server.name}
                        ${server.active ? "<span class=\"badge bg-success ms-2\">活跃</span>" : "<span class=\"badge bg-secondary ms-2\">禁用</span>"}
                    </h6>
                    <p class="text-muted mb-1">
                        <i class="fas fa-server me-1"></i>
                        ${server.address}:${server.port}
                    </p>
                    <p class="text-muted mb-0">
                        <i class="fas fa-network-wired me-1"></i>
                        ${server.obfs || "none"}
                        <span class="ms-3">
                            <i class="fas fa-sort-numeric-up me-1"></i>
                            优先级: ${server.priority || 1}
                        </span>
                    </p>
                </div>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-success" onclick="testHysteria2Server(\"${server.id}\")">
                        <i class="fas fa-vial"></i>
                    </button>
                    <button type="button" class="btn btn-outline-primary" onclick="editHysteria2Server(\"${server.id}\")">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteHysteria2Server(\"${server.id}\", \"${server.name}\")">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join("");
}

function showAddHysteria2Modal() {
    currentEditingHysteria2 = null;
    document.getElementById("hysteria2ModalTitle").textContent = "添加 Hysteria2 服务器";
    document.getElementById("hysteria2Form").reset();
    document.getElementById("hysteria2ServerId").value = "";
    document.getElementById("hysteria2Priority").value = "1";
    document.getElementById("hysteria2Obfs").value = "none";
    document.getElementById("hysteria2Active").checked = true;
    
    new bootstrap.Modal(document.getElementById("hysteria2Modal")).show();
}

function editHysteria2Server(serverId) {
    const server = hysteria2Servers.find(s => s.id === serverId);
    if (!server) return;
    
    currentEditingHysteria2 = serverId;
    document.getElementById("hysteria2ModalTitle").textContent = "编辑 Hysteria2 服务器";
    
    // 填充表单
    document.getElementById("hysteria2ServerId").value = server.id;
    document.getElementById("hysteria2Name").value = server.name;
    document.getElementById("hysteria2Address").value = server.address;
    document.getElementById("hysteria2Port").value = server.port;
    document.getElementById("hysteria2Password").value = server.password;
    document.getElementById("hysteria2Obfs").value = server.obfs || "none";
    document.getElementById("hysteria2ObfsPassword").value = server.obfs_password || "";
    document.getElementById("hysteria2Priority").value = server.priority || 1;
    document.getElementById("hysteria2Active").checked = server.active !== false;
    
    new bootstrap.Modal(document.getElementById("hysteria2Modal")).show();
}

function saveHysteria2Server() {
    const serverId = document.getElementById("hysteria2ServerId").value || generateUniqueId();
    const name = document.getElementById("hysteria2Name").value;
    const address = document.getElementById("hysteria2Address").value;
    const port = parseInt(document.getElementById("hysteria2Port").value);
    const password = document.getElementById("hysteria2Password").value;
    const obfs = document.getElementById("hysteria2Obfs").value;
    const obfs_password = document.getElementById("hysteria2ObfsPassword").value;
    const priority = parseInt(document.getElementById("hysteria2Priority").value);
    const active = document.getElementById("hysteria2Active").checked;
    
    const serverData = {
        id: serverId,
        name, address, port, password, obfs, obfs_password, priority, active
    };
    
    const url = currentEditingHysteria2 ? `/api/hysteria2/servers/${serverId}` : 
                                        `/api/hysteria2/servers`;
    const method = currentEditingHysteria2 ? "PUT" : "POST";
    
    fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(serverData)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert("Hysteria2 服务器已保存", "success");
            loadHysteria2Servers();
            bootstrap.Modal.getInstance(document.getElementById("hysteria2Modal")).hide();
        } else {
            showAlert("保存失败: " + result.message, "danger");
        }
    })
    .catch(error => {
        showAlert("请求失败: " + error.message, "danger");
    });
}

function deleteHysteria2Server(serverId, serverName) {
    if (!confirm(`确定要删除 Hysteria2 服务器 "${serverName}" 吗？`)) {
        return;
    }
    
    fetch(`/api/hysteria2/servers/${serverId}`, {
        method: "DELETE"
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert("Hysteria2 服务器已删除", "success");
            loadHysteria2Servers();
        } else {
            showAlert("删除失败: " + result.message, "danger");
        }
    })
    .catch(error => {
        showAlert("请求失败: " + error.message, "danger");
    });
}

function testHysteria2Server(serverId) {
    fetch(`/api/hysteria2/servers/${serverId}/test`, { method: "POST" })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(`✅ Hysteria2 服务器测试成功\\n外部IP: ${result.ip}`, "success");
            } else {
                showAlert(`❌ Hysteria2 服务器测试失败: ${result.message}`, "danger");
            }
        })
        .catch(error => {
            showAlert(`❌ 测试失败: ${error.message}`, "danger");
        });
}

// 通用函数
function showAlert(message, type) {
    const alertPlaceholder = document.getElementById("alertPlaceholder");
    const wrapper = document.createElement("div");
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    alertPlaceholder.append(wrapper);
    setTimeout(() => wrapper.remove(), 5000); // 5秒后自动消失
}

function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function getServerHealthStatus(server) {
    if (server.last_test_success === true) {
        return "status-healthy";
    } else if (server.last_test_success === false) {
        return "status-unhealthy";
    } else {
        return "status-unknown";
    }
}


