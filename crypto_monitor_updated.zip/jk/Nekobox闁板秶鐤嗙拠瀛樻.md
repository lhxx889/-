# Nekobox 代理配置说明

## 问题分析

您提到在 Web 界面中没有找到 Nekobox 代理的手动配置选项。经过代码分析，我发现了问题所在：

## 当前状况

### 1. 代码层面支持手动配置
- 后端代码 (`nekobox_proxy.py`) 完全支持手动配置
- 配置文件 (`config.json`) 中已有手动配置的结构
- API 接口 (`/api/nekobox/config`) 支持更新手动配置

### 2. Web 界面缺失手动配置选项
当前的 Web 界面只提供了：
- ✅ 自动检测 Nekobox 端口
- ✅ 测试连接功能
- ❌ **缺少手动配置输入框**（主机、端口、协议类型）

## 配置方式

### 方式一：直接修改配置文件（推荐）

您可以直接编辑 `config/config.json` 文件中的 Nekobox 配置：

```json
{
  "proxy": {
    "nekobox": {
      "enabled": true,
      "auto_detect": false,
      "manual_config": {
        "host": "127.0.0.1",
        "port": 7890,
        "protocol": "socks5"
      }
    },
    "type": "nekobox"
  }
}
```

**配置参数说明：**
- `host`: 代理服务器地址（通常是 127.0.0.1）
- `port`: 代理端口（常见端口：7890, 7891, 1080, 8080）
- `protocol`: 协议类型（socks5 或 http）

### 方式二：使用 API 接口

您也可以通过 API 接口更新配置：

```bash
curl -X POST http://localhost:5000/api/nekobox/config \
  -H "Content-Type: application/json" \
  -d '{
    "enabled": true,
    "auto_detect": false,
    "manual_config": {
      "host": "127.0.0.1",
      "port": 7890,
      "protocol": "socks5"
    }
  }'
```

## 常见 Nekobox 端口

根据代码分析，系统会自动检测以下常见端口：
- 7890 (最常用)
- 7891
- 7892
- 1080
- 8080
- 10808
- 10809

## 建议的 Web 界面改进

为了完善用户体验，建议在 Web 界面的 Nekobox 设置区域添加以下手动配置选项：

1. **代理主机地址** 输入框
2. **代理端口** 输入框  
3. **协议类型** 下拉选择（SOCKS5/HTTP）
4. **启用手动配置** 开关

这样用户就可以在 Web 界面中直接配置自定义的 Nekobox 代理设置了。

## 当前解决方案

在 Web 界面改进之前，您可以：

1. **直接修改配置文件** - 最简单直接的方法
2. **使用自动检测功能** - 如果您的 Nekobox 使用标准端口
3. **重启应用** - 修改配置后需要重启应用使配置生效

