import requests
import logging
import hashlib
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup
from .base_exchange import BaseExchangeClient

class BinanceClient(BaseExchangeClient):
    """Binance.US API客户端"""
    
    def __init__(self, config):
        super().__init__(config, 'binance')
    
    def get_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的24小时价格变动数据，并标准化输出"""
        if not self.exchange_config.get("enabled", False):
            return []
        
        url = f"{self.api_base}{self.ticker_endpoint}"
        response = self.make_request(url)
        
        standardized_tickers = []
        if response:
            try:
                tickers = response.json()
                self.logger.info(f"成功获取Binance.US {len(tickers)} 个交易对数据")
                for ticker in tickers:
                    standardized_tickers.append({
                        "symbol": ticker["symbol"],
                        "price": float(ticker["lastPrice"]),
                        "change_percent": float(ticker["priceChangePercent"])
                    })
            except ValueError as e:
                self.logger.error(f"解析Binance.US响应失败: {e}")
        
        return standardized_tickers

class GateClient(BaseExchangeClient):
    """Gate.io API客户端"""
    
    def __init__(self, config):
        super().__init__(config, 'gate')
    
    def get_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的价格和涨跌幅数据，并标准化输出"""
        if not self.exchange_config.get("enabled", False):
            return []
        
        url = f"{self.api_base}{self.ticker_endpoint}"
        response = self.make_request(url)
        
        standardized_tickers = []
        if response:
            try:
                tickers = response.json()
                self.logger.info(f"成功获取Gate.io {len(tickers)} 个交易对数据")
                for ticker in tickers:
                    standardized_tickers.append({
                        "symbol": ticker["currency_pair"],
                        "price": float(ticker["last"]),
                        "change_percent": float(ticker.get("change_percentage", 0)) # Gate.io的百分比可能需要额外处理，这里假设直接可用
                    })
            except ValueError as e:
                self.logger.error(f"解析Gate.io响应失败: {e}")
        
        return standardized_tickers

class ExchangeAPIManager:
    """交易所API管理器"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # 动态加载交易所客户端
        self.clients = {}
        for exchange_name, exchange_conf in self.config.exchanges.items():
            if exchange_conf.get("enabled", False):
                try:
                    # 假设客户端类名是 ExchangeNameClient
                    class_name = f"{exchange_name.capitalize()}Client"
                    # 尝试从当前模块导入类
                    exchange_client_class = globals()[class_name]
                    self.clients[exchange_name] = exchange_client_class(config)
                    self.logger.info(f"成功加载交易所客户端: {exchange_name}")
                except KeyError:
                    self.logger.warning(f"未找到交易所 {exchange_name} 的客户端实现")
                except Exception as e:
                    self.logger.error(f"加载交易所 {exchange_name} 客户端失败: {e}")

    def get_all_tickers(self) -> Dict[str, List[Dict[str, Any]]]:
        """获取所有启用交易所的ticker数据"""
        all_tickers = {}
        
        for exchange, client in self.clients.items():
            tickers = client.get_tickers()
            all_tickers[exchange] = tickers
        
        return all_tickers
    
    def get_all_announcements(self) -> Dict[str, List[Dict[str, Any]]]:
        """获取所有启用交易所的公告数据"""
        all_announcements = {}
        
        for exchange, client in self.clients.items():
            announcements = client.get_announcements()
            all_announcements[exchange] = announcements
        
        return all_announcements


