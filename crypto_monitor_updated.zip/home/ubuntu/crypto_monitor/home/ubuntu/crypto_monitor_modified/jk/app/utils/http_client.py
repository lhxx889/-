import requests

class HttpClient:
    def get(self, url, timeout=5):
        return requests.get(url, timeout=timeout)

    def post(self, url, data=None, json=None, timeout=5):
        return requests.post(url, data=data, json=json, timeout=timeout)


