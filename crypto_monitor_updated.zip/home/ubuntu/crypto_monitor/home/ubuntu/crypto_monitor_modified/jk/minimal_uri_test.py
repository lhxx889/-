
import sys
from pathlib import Path
import base64
import json

# Add project root to Python path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.core.nekobox_proxy import NekoboxProxyManager
from app.core.config import Config
from app.core.database import Database

# Dummy classes for testing
class DummyConfig(Config):
    def __init__(self):
        super().__init__()
        self._config = {}

    def get(self, key, default=None):
        keys = key.split(".")
        val = self._config
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val

    def set(self, key, value):
        keys = key.split(".")
        val = self._config
        for i, k in enumerate(keys):
            if i == len(keys) - 1:
                val[k] = value
            else:
                if k not in val or not isinstance(val[k], dict):
                    val[k] = {}
                val = val[k]

    def save(self):
        pass # Dummy save

    @property
    def database_path(self):
        return "dummy_db.sqlite"

class DummyDatabase(Database):
    def __init__(self, db_path):
        super().__init__(db_path)
        self.proxy_servers = []

    def add_proxy_server(self, protocol, server_id, name, config, priority, active):
        self.proxy_servers.append({
            "protocol": protocol,
            "server_id": server_id,
            "name": name,
            "config": config,
            "priority": priority,
            "active": active
        })

    def get_proxy_servers(self, protocol=None):
        if protocol:
            return [s for s in self.proxy_servers if s["protocol"] == protocol]
        return self.proxy_servers


def test_parse_uri():
    print("测试 parse_uri 方法...")
    manager = NekoboxProxyManager(DummyConfig(), DummyDatabase("dummy.db"))

    # VLESS URI 示例
    vless_uri = "vless://uuid@example.com:443?encryption=none&security=tls&type=ws&path=%2Fws&host=example.com#VLESS-WS-TLS"
    parsed_vless = manager.parse_uri(vless_uri)
    print(f"VLESS URI 解析结果: {parsed_vless}")
    assert parsed_vless["config"].get("protocol") == "vless"
    assert parsed_vless["config"].get("host") == "example.com"
    assert parsed_vless["config"].get("port") == 443
    assert parsed_vless["config"].get("name") == "VLESS-WS-TLS"
    assert parsed_vless["config"]["advanced_params"].get("type") == "ws"
    assert parsed_vless["config"]["advanced_params"].get("path") == "/ws"

    # VMess URI 示例 (Base64 encoded JSON)
    # Example VMess config JSON: {"v":"2","ps":"VMess-WS-TLS","add":"example.com","port":"443","id":"uuid","aid":"0","net":"ws","type":"none","host":"example.com","path":"/ws","tls":"tls"}
    vmess_json = {"v":"2","ps":"VMess-WS-TLS","add":"example.com","port":"443","id":"uuid","aid":"0","net":"ws","type":"none","host":"example.com","path":"/ws","tls":"tls"}
    vmess_encoded = base64.b64encode(json.dumps(vmess_json).encode("utf-8")).decode("utf-8")
    vmess_uri = f"vmess://{vmess_encoded}"
    parsed_vmess = manager.parse_uri(vmess_uri)
    print(f"VMess URI 解析结果: {parsed_vmess}")
    assert parsed_vmess["config"].get("protocol") == "vmess"
    assert parsed_vmess["config"].get("host") == "example.com"
    assert parsed_vmess["config"].get("port") == "443"
    assert parsed_vmess["config"].get("name") == "VMess-WS-TLS"
    assert parsed_vmess["config"].get("network") == "ws"

    # Trojan URI 示例
    trojan_uri = "trojan://password@example.com:443#Trojan-TLS"
    parsed_trojan = manager.parse_uri(trojan_uri)
    print(f"Trojan URI 解析结果: {parsed_trojan}")
    assert parsed_trojan["config"].get("protocol") == "trojan"
    assert parsed_trojan["config"].get("host") == "example.com"
    assert parsed_trojan["config"].get("port") == 443
    assert parsed_trojan["config"].get("username") == "password"
    assert parsed_trojan["config"].get("name") == "Trojan-TLS"

    # Hysteria2 URI 示例
    hysteria2_uri = "hysteria2://password@example.com:443?obfs=none&obfsParam=none#Hysteria2-Direct"
    parsed_hysteria2 = manager.parse_uri(hysteria2_uri)
    print(f"Hysteria2 URI 解析结果: {parsed_hysteria2}")
    assert parsed_hysteria2["config"].get("protocol") == "hysteria2"
    assert parsed_hysteria2["config"].get("host") == "example.com"
    assert parsed_hysteria2["config"].get("port") == 443
    assert parsed_hysteria2["config"].get("username") == "password"
    assert parsed_hysteria2["config"].get("name") == "Hysteria2-Direct"

    print("所有 URI 解析测试通过！")

if __name__ == "__main__":
    test_parse_uri()


