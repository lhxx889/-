"""
Gate.io加密货币异动监控系统 - 主程序
集成所有模块，实现完整的监控系统功能
"""

import logging
import time
import json
import os
import sys
import signal
import threading
from datetime import datetime
from typing import Dict, List, Any, Optional

# 导入各模块
from src.data_collector import GateioDataCollector, DataMonitor
from src.anomaly_detector import AnomalyDetector, AnomalyMonitor
from src.telegram_alerter import TelegramAlerter
from src.deep_analyzer import DeepAnalyzer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("main")

class CryptoMonitorSystem:
    """加密货币异动监控系统主类，集成所有模块"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化监控系统
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # 初始化各模块
        self.data_collector = GateioDataCollector(
            db_path=self.config.get("db_path", "crypto_data.db")
        )
        
        self.anomaly_detector = AnomalyDetector(
            collector=self.data_collector,
            price_change_threshold=self.config.get("price_change_threshold", 30.0),
            volume_change_threshold=self.config.get("volume_change_threshold", 200.0)
        )
        
        self.telegram_alerter = TelegramAlerter(
            token=self.config.get("telegram_token"),
            chat_id=self.config.get("telegram_chat_id"),
            config_file=self.config.get("telegram_config_file", "telegram_config.json")
        )
        
        self.deep_analyzer = DeepAnalyzer()
        
        # 初始化监控器
        self.data_monitor = DataMonitor(
            collector=self.data_collector,
            interval=self.config.get("check_interval", 50)
        )
        
        self.anomaly_monitor = AnomalyMonitor(
            detector=self.anomaly_detector,
            check_interval=self.config.get("check_interval", 50)
        )
        
        # 注册警报回调
        self.anomaly_monitor.register_alert_callback(self.handle_anomaly_alert)
        
        # 线程控制
        self.running = False
        self.data_thread = None
        self.anomaly_thread = None
        
        logger.info("加密货币异动监控系统初始化完成")
    
    def _load_config(self) -> Dict:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        default_config = {
            "db_path": "crypto_data.db",
            "check_interval": 50,
            "price_change_threshold": 30.0,
            "volume_change_threshold": 200.0,
            "telegram_config_file": "telegram_config.json",
            "api_config_file": "api_config.json"
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    logger.info("从配置文件加载配置成功")
                    # 合并默认配置和加载的配置
                    return {**default_config, **config}
            else:
                logger.warning(f"配置文件{self.config_file}不存在，使用默认配置")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
        
        return default_config
    
    def save_config(self) -> bool:
        """
        保存配置到配置文件
        
        Returns:
            保存是否成功
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            
            logger.info("保存配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def configure_telegram(self, token: str, chat_id: str) -> bool:
        """
        配置Telegram
        
        Args:
            token: Telegram Bot API令牌
            chat_id: 目标聊天ID
            
        Returns:
            配置是否成功
        """
        # 更新配置
        self.config["telegram_token"] = token
        self.config["telegram_chat_id"] = chat_id
        
        # 更新Telegram警报推送器
        self.telegram_alerter.token = token
        self.telegram_alerter.chat_id = chat_id
        
        # 保存配置
        self.telegram_alerter.save_config(token, chat_id)
        return self.save_config()
    
    def test_telegram(self) -> bool:
        """
        测试Telegram连接
        
        Returns:
            测试是否成功
        """
        if not self.telegram_alerter.is_configured():
            logger.error("Telegram未配置，无法测试")
            return False
        
        # 测试连接
        if not self.telegram_alerter.test_connection():
            logger.error("Telegram连接测试失败")
            return False
        
        # 发送测试消息
        test_message = "这是一条测试消息，来自Gate.io加密货币异动监控系统。"
        if not self.telegram_alerter.send_message(test_message):
            logger.error("Telegram测试消息发送失败")
            return False
        
        logger.info("Telegram测试成功")
        return True
    
    def handle_anomaly_alert(self, anomalies: List[Dict]) -> None:
        """
        处理异常警报
        
        Args:
            anomalies: 异常列表
        """
        if not anomalies:
            return
        
        logger.info(f"处理{len(anomalies)}个异常警报")
        
        # 检查Telegram是否配置
        if not self.telegram_alerter.is_configured():
            logger.warning("Telegram未配置，无法发送警报")
            return
        
        # 处理每个异常
        for anomaly in anomalies:
            try:
                # 获取币种符号
                symbol = anomaly.get("symbol")
                if not symbol:
                    continue
                
                # 分析异动可能的原因
                analysis_result = self.deep_analyzer.analyze_possible_reasons(symbol, anomaly)
                
                # 发送异常警报
                if not self.telegram_alerter.send_anomaly_alert(anomaly):
                    logger.warning(f"发送{symbol}的异常警报失败")
                    continue
                
                # 等待一秒，避免消息发送过快
                time.sleep(1)
                
                # 发送分析结果
                analysis_message = self.deep_analyzer.format_analysis_message(analysis_result)
                if not self.telegram_alerter.send_message(analysis_message):
                    logger.warning(f"发送{symbol}的分析结果失败")
                
                logger.info(f"成功发送{symbol}的异常警报和分析结果")
            
            except Exception as e:
                logger.error(f"处理异常警报时出错: {str(e)}")
    
    def start(self) -> None:
        """启动监控系统"""
        if self.running:
            logger.warning("监控系统已经在运行")
            return
        
        logger.info("启动加密货币异动监控系统")
        self.running = True
        
        # 启动数据监控线程
        self.data_thread = threading.Thread(target=self.data_monitor.start)
        self.data_thread.daemon = True
        self.data_thread.start()
        
        # 启动异常监控线程
        self.anomaly_thread = threading.Thread(target=self.anomaly_monitor.start)
        self.anomaly_thread.daemon = True
        self.anomaly_thread.start()
        
        logger.info("监控系统启动成功")
        
        # 注册信号处理
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)
        
        try:
            # 主线程保持运行
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("收到中断信号，停止监控系统")
            self.stop()
    
    def stop(self) -> None:
        """停止监控系统"""
        if not self.running:
            logger.warning("监控系统已经停止")
            return
        
        logger.info("停止加密货币异动监控系统")
        
        # 停止监控器
        self.data_monitor.stop()
        self.anomaly_monitor.stop()
        
        # 等待线程结束
        if self.data_thread and self.data_thread.is_alive():
            self.data_thread.join(timeout=5)
        
        if self.anomaly_thread and self.anomaly_thread.is_alive():
            self.anomaly_thread.join(timeout=5)
        
        self.running = False
        logger.info("监控系统已停止")
    
    def handle_signal(self, signum, frame) -> None:
        """
        处理信号
        
        Args:
            signum: 信号编号
            frame: 当前帧
        """
        logger.info(f"收到信号 {signum}，停止监控系统")
        self.stop()


def setup_wizard() -> CryptoMonitorSystem:
    """
    设置向导，引导用户配置系统
    
    Returns:
        配置好的监控系统实例
    """
    print("=" * 50)
    print("Gate.io加密货币异动监控系统设置向导")
    print("=" * 50)
    
    # 创建监控系统实例
    system = CryptoMonitorSystem()
    
    # 配置Telegram
    print("\n配置Telegram Bot:")
    print("请创建一个Telegram Bot并获取Token和Chat ID")
    print("1. 在Telegram中搜索 @BotFather 并开始对话")
    print("2. 发送 /newbot 命令创建新机器人")
    print("3. 按照提示设置机器人名称和用户名")
    print("4. 获取API Token")
    print("5. 将机器人添加到目标聊天中")
    print("6. 获取Chat ID (可以使用 @get_id_bot 或其他方法)")
    
    token = input("\n请输入Bot Token: ")
    chat_id = input("请输入Chat ID: ")
    
    if token and chat_id:
        print("\n正在配置Telegram...")
        if system.configure_telegram(token, chat_id):
            print("Telegram配置成功!")
            
            print("\n正在测试Telegram连接...")
            if system.test_telegram():
                print("Telegram测试成功!")
            else:
                print("Telegram测试失败，请检查Token和Chat ID是否正确")
        else:
            print("Telegram配置失败")
    else:
        print("\n未提供Telegram配置，将使用配置文件中的设置（如果有）")
    
    # 配置监控参数
    print("\n配置监控参数:")
    
    try:
        check_interval = int(input("请输入检查间隔（秒，默认50）: ") or "50")
        system.config["check_interval"] = check_interval
        system.data_monitor.interval = check_interval
        system.anomaly_monitor.check_interval = check_interval
        
        price_threshold = float(input("请输入价格变化阈值（百分比，默认30）: ") or "30")
        system.config["price_change_threshold"] = price_threshold
        system.anomaly_detector.price_change_threshold = price_threshold
        
        volume_threshold = float(input("请输入交易量变化阈值（百分比，默认200）: ") or "200")
        system.config["volume_change_threshold"] = volume_threshold
        system.anomaly_detector.volume_change_threshold = volume_threshold
        
        # 保存配置
        system.save_config()
        print("\n监控参数配置成功!")
    except ValueError:
        print("输入无效，将使用默认值")
    
    print("\n设置完成!")
    print("=" * 50)
    print("使用说明:")
    print("1. 运行 python main.py 启动监控系统")
    print("2. 使用 Ctrl+C 停止监控系统")
    print("3. 配置文件保存在 config.json 中，可以手动编辑")
    print("=" * 50)
    
    return system


if __name__ == "__main__":
    # 检查命令行参数
    if len(sys.argv) > 1 and sys.argv[1] == "--setup":
        # 运行设置向导
        system = setup_wizard()
    else:
        # 直接启动系统
        system = CryptoMonitorSystem()
    
    # 启动系统
    try:
        system.start()
    except KeyboardInterrupt:
        print("\n收到中断信号，停止监控系统")
        system.stop()
