#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
代理管理器
统一管理 VLESS、Hysteria2 和 Nekobox 代理
"""

import logging
import json
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)

class ProxyManager:
    """统一代理管理器"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        self.current_proxy = None
        self.proxy_managers = {}
        
        # 初始化各种代理管理器
        self._init_proxy_managers()
    
    def _init_proxy_managers(self):
        """初始化各种代理管理器"""
        try:
            # 初始化 VLESS 管理器
            from .vless_proxy import VLESSProxyManager
            self.proxy_managers['vless'] = VLESSProxyManager(self.config, self.db)
            
            # 初始化 Hysteria2 管理器
            from .hysteria2_proxy import Hysteria2ProxyManager
            self.proxy_managers['hysteria2'] = Hysteria2ProxyManager(self.config, self.db)
            
            # 初始化 Nekobox 管理器
            from .nekobox_proxy import NekoboxProxyManager
            self.proxy_managers['nekobox'] = NekoboxProxyManager(self.config, self.db)
            
            logger.info("代理管理器初始化完成")
            
        except Exception as e:
            logger.error(f"代理管理器初始化失败: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """获取代理状态"""
        try:
            proxy_enabled = self.config.get('proxy.enabled', False)
            proxy_type = self.config.get('proxy.type', 'manual')
            
            status = {
                'enabled': proxy_enabled,
                'type': proxy_type,
                'current_proxy': None,
                'available_protocols': list(self.proxy_managers.keys())
            }
            
            if proxy_enabled and proxy_type in self.proxy_managers:
                manager = self.proxy_managers[proxy_type]
                current_server = manager.get_current_server()
                if current_server:
                    status['current_proxy'] = {
                        'protocol': proxy_type,
                        'server_id': current_server['id'],
                        'name': current_server['name'],
                        'active': current_server.get('active', True)
                    }
            
            return status
            
        except Exception as e:
            logger.error(f"获取代理状态失败: {e}")
            return {'enabled': False, 'error': str(e)}
    
    def switch_proxy(self, protocol: str, server_id: str) -> Dict[str, Any]:
        """切换代理服务器"""
        try:
            if protocol not in self.proxy_managers:
                return {'success': False, 'message': f'不支持的代理协议: {protocol}'}
            
            manager = self.proxy_managers[protocol]
            result = manager.set_current_server(server_id)
            
            if result['success']:
                # 更新配置
                self.config.set('proxy.enabled', True)
                self.config.set('proxy.type', protocol)
                self.config.save()
                
                # 更新当前代理
                self.current_proxy = {
                    'protocol': protocol,
                    'server_id': server_id,
                    'manager': manager
                }
                
                logger.info(f"已切换到 {protocol} 代理服务器: {server_id}")
            
            return result
            
        except Exception as e:
            logger.error(f"切换代理失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def disable_proxy(self) -> Dict[str, Any]:
        """禁用代理"""
        try:
            self.config.set('proxy.enabled', False)
            self.config.save()
            self.current_proxy = None
            
            logger.info("代理已禁用")
            return {'success': True, 'message': '代理已禁用'}
            
        except Exception as e:
            logger.error(f"禁用代理失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_proxy_config(self) -> Optional[Dict[str, str]]:
        """获取当前代理配置"""
        try:
            if not self.current_proxy:
                # 尝试从配置中恢复当前代理
                proxy_enabled = self.config.get('proxy.enabled', False)
                if not proxy_enabled:
                    return None
                
                proxy_type = self.config.get('proxy.type', 'manual')
                if proxy_type not in self.proxy_managers:
                    return None
                
                manager = self.proxy_managers[proxy_type]
                current_server = manager.get_current_server()
                if not current_server:
                    # 尝试获取最佳服务器
                    current_server = manager.get_best_server()
                    if current_server:
                        manager.set_current_server(current_server['id'])
                
                if current_server:
                    self.current_proxy = {
                        'protocol': proxy_type,
                        'server_id': current_server['id'],
                        'manager': manager
                    }
            
            if self.current_proxy:
                manager = self.current_proxy['manager']
                server_id = self.current_proxy['server_id']
                return manager.get_proxy_config(server_id)
            
            return None
            
        except Exception as e:
            logger.error(f"获取代理配置失败: {e}")
            return None
    
    def test_current_proxy(self) -> Dict[str, Any]:
        """测试当前代理连接"""
        try:
            if not self.current_proxy:
                return {'success': False, 'message': '未设置代理'}
            
            manager = self.current_proxy['manager']
            server_id = self.current_proxy['server_id']
            
            return manager.test_connection(server_id)
            
        except Exception as e:
            logger.error(f"测试代理连接失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def health_check_all(self) -> Dict[str, Any]:
        """健康检查所有代理服务器"""
        try:
            results = []
            
            for protocol, manager in self.proxy_managers.items():
                try:
                    result = manager.health_check()
                    results.append(result)
                except Exception as e:
                    logger.error(f"{protocol} 健康检查失败: {e}")
                    results.append({
                        'success': False,
                        'protocol': protocol,
                        'error': str(e)
                    })
            
            return {
                'success': True,
                'results': results,
                'timestamp': logger.info("代理健康检查完成")
            }
            
        except Exception as e:
            logger.error(f"代理健康检查失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_all_servers(self) -> Dict[str, List[Dict]]:
        """获取所有代理服务器"""
        try:
            all_servers = {}
            
            for protocol, manager in self.proxy_managers.items():
                try:
                    servers = manager.get_servers()
                    all_servers[protocol] = servers
                except Exception as e:
                    logger.error(f"获取 {protocol} 服务器列表失败: {e}")
                    all_servers[protocol] = []
            
            return all_servers
            
        except Exception as e:
            logger.error(f"获取服务器列表失败: {e}")
            return {}
    
    def get_manager(self, protocol: str):
        """获取指定协议的代理管理器"""
        return self.proxy_managers.get(protocol)
    
    def reload_config(self):
        """重新加载配置"""
        try:
            for manager in self.proxy_managers.values():
                if hasattr(manager, 'load_servers'):
                    manager.load_servers()
            
            logger.info("代理配置已重新加载")
            
        except Exception as e:
            logger.error(f"重新加载代理配置失败: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取代理统计信息"""
        try:
            stats = {
                'total_servers': 0,
                'active_servers': 0,
                'protocols': {},
                'current_proxy': self.get_status().get('current_proxy')
            }
            
            for protocol, manager in self.proxy_managers.items():
                try:
                    servers = manager.get_servers()
                    active_servers = [s for s in servers if s.get('active', True)]
                    
                    stats['protocols'][protocol] = {
                        'total': len(servers),
                        'active': len(active_servers),
                        'servers': servers
                    }
                    
                    stats['total_servers'] += len(servers)
                    stats['active_servers'] += len(active_servers)
                    
                except Exception as e:
                    logger.error(f"获取 {protocol} 统计信息失败: {e}")
                    stats['protocols'][protocol] = {
                        'total': 0,
                        'active': 0,
                        'error': str(e)
                    }
            
            return stats
            
        except Exception as e:
            logger.error(f"获取代理统计信息失败: {e}")
            return {'error': str(e)}

