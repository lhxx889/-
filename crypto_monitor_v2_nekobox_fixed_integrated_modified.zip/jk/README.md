# 加密货币监控系统 v2.0

现代化的加密货币价格监控和公告扫描系统，基于原有程序重新设计和开发，现已支持 **Nekobox 代理**！

## 🚀 主要特性

### 核心功能
- **多交易所支持**: 支持 Binance.US 和 Gate.io 交易所
- **实时价格监控**: 监控价格变动，可自定义阈值
- **公告扫描**: 自动扫描交易所公告，特别关注新上币信息
- **智能通知**: 支持 Telegram 和邮件通知
- **Web管理界面**: 现代化的Web界面，支持实时监控和配置管理
- **🆕 Nekobox代理支持**: 自动检测和配置 Nekobox 代理，支持多种代理协议

### 技术特性
- **模块化架构**: 清晰的代码结构，易于维护和扩展
- **SQLite数据库**: 可靠的数据存储，支持历史数据查询
- **RESTful API**: 完整的API接口，支持第三方集成
- **配置管理**: 灵活的配置系统，支持运行时修改
- **错误处理**: 完善的错误处理和日志记录
- **代理支持**: 支持传统SOCKS5代理和 Nekobox 自动检测

## 📦 安装和使用

### 系统要求
- Python 3.7 或更高版本
- 支持的操作系统: Linux, Windows, macOS

### 快速开始

1. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

2. **启动Web界面**
   ```bash
   python main.py
   ```
   
   然后访问 http://localhost:5000

3. **命令行使用**
   ```bash
   # 启动监控
   python cli.py start
   
   # 手动价格检查
   python cli.py price-check
   
   # 手动公告扫描
   python cli.py announcement-scan
   
   # 查看系统状态
   python cli.py status
   
   # 测试Telegram连接
   python cli.py test-telegram
   
   # 配置管理
   python cli.py config show
   python cli.py config set --key price_change_threshold --value 3.0
   ```

## 🎛️ 配置说明

系统配置文件位于 `config/config.json`，主要配置项包括：

### 基础配置
- `price_change_threshold`: 价格变动阈值（百分比）
- `price_check_interval`: 价格检查间隔（秒）
- `announcement_scan_interval`: 公告扫描间隔（秒）

### 交易所配置
```json
{
  "exchanges": {
    "binance": {
      "enabled": true,
      "api_base": "https://api.binance.us",
      "ticker_endpoint": "/api/v3/ticker/24hr",
      "announcement_url": "https://support.binance.us/en/collections/10384537-announcements"
    },
    "gate": {
      "enabled": true,
      "api_base": "https://api.gateio.ws/api/v4",
      "ticker_endpoint": "/spot/tickers",
      "announcement_url": "https://www.gate.io/announcements"
    }
  }
}
```

### 通知配置
```json
{
  "notifications": {
    "telegram": {
      "enabled": false,
      "bot_token": "YOUR_BOT_TOKEN",
      "chat_id": "YOUR_CHAT_ID",
      "price_notify": true,
      "announcement_notify": true,
      "min_price_change": 10.0
    }
  }
}
```

### 代理配置
```json
{
  "proxy": {
    "enabled": false,
    "http": "socks5://127.0.0.1:1080",
    "https": "socks5://127.0.0.1:1080"
  }
}
```

## 🌐 Web界面功能

### 主页
- 系统状态概览
- 监控组件状态
- 快速操作按钮
- 统计信息展示

### 仪表板
- 实时数据展示
- 价格变动历史
- 公告列表
- 新上币信息

### 设置页面
- 系统配置管理
- Telegram配置
- 交易所开关
- 参数调整

## 📊 API接口

系统提供完整的RESTful API接口：

### 监控控制
- `POST /api/monitor/start` - 启动监控
- `POST /api/monitor/stop` - 停止监控
- `POST /api/monitor/price-check` - 手动价格检查
- `POST /api/monitor/announcement-scan` - 手动公告扫描

### 数据查询
- `GET /api/status` - 获取系统状态
- `GET /api/statistics` - 获取统计信息
- `GET /api/price-changes` - 获取价格变动记录
- `GET /api/announcements` - 获取公告记录
- `GET /api/new-listings` - 获取新上币公告

### 配置管理
- `GET /api/config` - 获取配置信息
- `POST /api/config` - 更新配置
- `POST /api/telegram/config` - 更新Telegram配置
- `POST /api/telegram/test` - 测试Telegram连接

## 🗂️ 项目结构

```
crypto_monitor_v2/
├── main.py                 # 主程序入口
├── cli.py                  # 命令行工具
├── requirements.txt        # 依赖文件
├── README.md              # 说明文档
├── app/                   # 应用代码
│   ├── core/              # 核心模块
│   │   ├── config.py      # 配置管理
│   │   ├── database.py    # 数据库管理
│   │   ├── api_client.py  # API客户端
│   │   ├── monitor.py     # 监控核心
│   │   └── notifications.py # 通知管理
│   └── web/               # Web应用
│       └── app.py         # Flask应用
├── config/                # 配置文件
│   └── config.json        # 主配置文件
├── data/                  # 数据存储
│   └── crypto_monitor.db  # SQLite数据库
├── logs/                  # 日志文件
├── templates/             # HTML模板
│   ├── index.html         # 主页
│   ├── dashboard.html     # 仪表板
│   └── settings.html      # 设置页面
└── tests/                 # 测试文件
```

## 🔄 与原版本的改进

### 架构改进
- **模块化设计**: 将功能拆分为独立模块，提高代码可维护性
- **数据库存储**: 使用SQLite替代JSON文件，提供更好的数据管理
- **Web界面**: 提供现代化的Web管理界面
- **API接口**: 完整的RESTful API，支持第三方集成

### 功能增强
- **实时监控**: Web界面实时显示监控状态和数据
- **配置管理**: 支持在线配置修改，无需重启程序
- **错误处理**: 更完善的错误处理和恢复机制
- **日志系统**: 结构化的日志记录，便于问题排查

### 性能优化
- **异步处理**: 使用线程池处理并发任务
- **缓存机制**: 减少重复的API请求
- **数据库索引**: 优化数据查询性能

## 🛠️ 开发和扩展

### 添加新交易所
1. 在 `app/core/api_client.py` 中创建新的客户端类
2. 在配置文件中添加交易所配置
3. 在 `ExchangeAPIManager` 中注册新客户端

### 添加新通知方式
1. 在 `app/core/notifications.py` 中添加新的通知方法
2. 在配置文件中添加相关配置项
3. 在Web界面中添加配置选项

### 自定义监控逻辑
1. 修改 `app/core/monitor.py` 中的监控逻辑
2. 调整数据库表结构（如需要）
3. 更新Web界面显示

## 📝 更新日志

### v2.0 (2024-06-09)
- 🎉 全新架构设计，基于原程序重写
- ✨ 添加Web管理界面
- 🗄️ 使用SQLite数据库存储
- 🔧 模块化代码结构
- 📊 完整的API接口
- 🎛️ 在线配置管理
- 📱 响应式Web设计
- 🔍 实时数据监控
- 📈 数据可视化展示
- 🛡️ 增强的错误处理

## 📞 技术支持

如果您在使用过程中遇到问题，请：

1. 查看日志文件 `logs/crypto_monitor.log`
2. 检查配置文件是否正确
3. 确认网络连接和代理设置
4. 验证API密钥和权限设置

## 📄 许可证

本项目基于原有程序改进开发，保持开源协议。

---

**版本**: v2.0  
**发布日期**: 2024-06-09  
**基于**: crypto_monitor_enhanced_v1.2_final



## 🔧 Nekobox 代理配置

### 快速配置
1. 启动 Nekobox 客户端
2. 访问 Web 界面设置页面 (http://localhost:5000/settings)
3. 启用代理并选择"Nekobox"类型
4. 点击"检测 Nekobox"按钮
5. 保存设置

### 支持的端口
系统会自动检测以下端口的 Nekobox 代理：
- 7890 (混合端口，推荐)
- 7891, 7892 (SOCKS/HTTP端口)
- 1080, 8080, 10808, 10809

### 代理配置示例
```json
{
  "proxy": {
    "enabled": true,
    "type": "nekobox",
    "nekobox": {
      "enabled": true,
      "auto_detect": true,
      "manual_config": {
        "host": "127.0.0.1",
        "port": 7890,
        "protocol": "socks5"
      }
    }
  }
}
```

详细配置请参考 [Nekobox 使用指南](NEKOBOX_GUIDE.md)

## 🆕 v2.0 更新内容

### 新增功能
- ✅ **Nekobox 代理支持**: 自动检测和配置 Nekobox 代理
- ✅ **多端口检测**: 支持常见的代理端口自动检测
- ✅ **Web界面配置**: 在线配置代理设置，无需重启
- ✅ **代理状态监控**: 实时显示代理连接状态
- ✅ **连接测试**: 一键测试代理连接可用性

### 架构改进
- 🔄 **模块化重构**: 更清晰的代码结构
- 🔄 **配置系统升级**: 支持更灵活的配置管理
- 🔄 **错误处理增强**: 更完善的异常处理机制
- 🔄 **API接口扩展**: 新增 Nekobox 相关 API 接口

### 兼容性
- ✅ 保持与原版本的配置兼容性
- ✅ 支持传统 SOCKS5/HTTP 代理
- ✅ 可在不同代理方式间无缝切换

