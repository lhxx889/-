#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Nekobox代理管理模块
提供Nekobox代理检测和配置功能
"""

import socket
import requests
import logging
from typing import Dict, Optional, List, Tuple

logger = logging.getLogger(__name__)

class NekoboxProxyManager:
    """Nekobox代理管理器"""
    
    # 常见的Nekobox端口
    COMMON_PORTS = [7890, 7891, 7892, 1080, 8080, 10808, 10809]
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        self.detected_proxies = []
        self.current_proxy = None
        
    def is_port_open(self, host: str, port: int, timeout: float = 3.0) -> bool:
        """检测端口是否开放"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                result = sock.connect_ex((host, port))
                return result == 0
        except Exception as e:
            logger.debug(f"端口检测失败 {host}:{port} - {e}")
            return False
    
    def detect_proxy_type(self, host: str, port: int) -> Optional[str]:
        """检测代理类型"""
        # 测试SOCKS5代理
        try:
            proxies = {
                'http': f'socks5://{host}:{port}',
                'https': f'socks5://{host}:{port}'
            }
            response = requests.get(
                'http://httpbin.org/ip', 
                proxies=proxies, 
                timeout=5
            )
            if response.status_code == 200:
                return 'socks5'
        except:
            pass
        
        # 测试HTTP代理
        try:
            proxies = {
                'http': f'http://{host}:{port}',
                'https': f'http://{host}:{port}'
            }
            response = requests.get(
                'http://httpbin.org/ip', 
                proxies=proxies, 
                timeout=5
            )
            if response.status_code == 200:
                return 'http'
        except:
            pass
        
        return None
    
    def detect_nekobox_proxies(self) -> List[Dict]:
        """检测Nekobox代理端口"""
        detected = []
        
        for port in self.COMMON_PORTS:
            if self.is_port_open('127.0.0.1', port):
                proxy_type = self.detect_proxy_type('127.0.0.1', port)
                if proxy_type:
                    proxy_info = {
                        'host': '127.0.0.1',
                        'port': port,
                        'type': proxy_type,
                        'url': f'{proxy_type}://127.0.0.1:{port}',
                        'status': 'active'
                    }
                    detected.append(proxy_info)
                    logger.info(f"检测到Nekobox代理: {proxy_type}://127.0.0.1:{port}")
        
        self.detected_proxies = detected
        return detected
    
    def test_proxy_connection(self, proxy_url: str) -> Dict:
        """测试代理连接"""
        try:
            proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
            
            # 测试连接
            response = requests.get(
                'http://httpbin.org/ip', 
                proxies=proxies, 
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'ip': data.get('origin', 'Unknown'),
                    'message': '代理连接成功'
                }
            else:
                return {
                    'success': False,
                    'message': f'HTTP错误: {response.status_code}'
                }
                
        except requests.exceptions.ProxyError as e:
            return {
                'success': False,
                'message': f'代理连接失败: {str(e)}'
            }
        except requests.exceptions.Timeout:
            return {
                'success': False,
                'message': '连接超时'
            }
        except Exception as e:
            return {
                'success': False,
                'message': f'未知错误: {str(e)}'
            }
    
    def get_proxy_config(self, auto_detect: bool = True, manual_config: Optional[Dict] = None) -> Optional[Dict]:
        """获取代理配置"""
        if auto_detect:
            # 自动检测模式
            proxies = self.detect_nekobox_proxies()
            if proxies:
                # 优先使用SOCKS5代理
                socks5_proxies = [p for p in proxies if p['type'] == 'socks5']
                if socks5_proxies:
                    best_proxy = socks5_proxies[0]
                else:
                    best_proxy = proxies[0]
                
                self.current_proxy = best_proxy
                return {
                    'http': best_proxy['url'],
                    'https': best_proxy['url']
                }
        
        elif manual_config:
            # 手动配置模式
            host = manual_config.get('host', '127.0.0.1')
            port = manual_config.get('port', 7890)
            protocol = manual_config.get('protocol', 'socks5')
            
            proxy_url = f"{protocol}://{host}:{port}"
            
            # 测试手动配置的代理
            test_result = self.test_proxy_connection(proxy_url)
            if test_result['success']:
                self.current_proxy = {
                    'host': host,
                    'port': port,
                    'type': protocol,
                    'url': proxy_url,
                    'status': 'active'
                }
                return {
                    'http': proxy_url,
                    'https': proxy_url
                }
            else:
                logger.warning(f"手动配置的代理测试失败: {test_result['message']}")
        
        return None
    
    def get_status(self) -> Dict:
        """获取Nekobox代理状态"""
        return {
            'detected_proxies': self.detected_proxies,
            'current_proxy': self.current_proxy,
            'total_detected': len(self.detected_proxies)
        }
    
    def refresh_detection(self) -> Dict:
        """刷新代理检测"""
        logger.info("刷新Nekobox代理检测...")
        proxies = self.detect_nekobox_proxies()
        return {
            'success': True,
            'detected_count': len(proxies),
            'proxies': proxies
        }

    def save_config(self, config: Dict) -> Dict:
        """保存Nekobox配置"""
        try:
            import json
            import uuid
            
            # 生成配置ID
            if 'id' not in config:
                config['id'] = f"nekobox-{uuid.uuid4().hex[:8]}"
            
            # 设置默认值
            config.setdefault('name', f"Nekobox 配置 {len(self.get_saved_configs()) + 1}")
            config.setdefault('priority', 1)
            config.setdefault('active', True)
            
            # 验证配置
            if not self.validate_nekobox_config(config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 保存到数据库
            self.db.add_proxy_server(
                protocol='nekobox',
                server_id=config['id'],
                name=config['name'],
                config=json.dumps(config),
                priority=config['priority'],
                active=config['active']
            )
            
            logger.info(f"已保存 Nekobox 配置: {config['name']}")
            
            return {
                'success': True,
                'config_id': config['id'],
                'message': f"Nekobox 配置 '{config['name']}' 保存成功"
            }
            
        except Exception as e:
            logger.error(f"保存 Nekobox 配置失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_saved_configs(self) -> List[Dict]:
        """获取已保存的配置列表"""
        try:
            import json
            db_configs = self.db.get_proxy_servers('nekobox')
            configs = []
            
            for db_config in db_configs:
                try:
                    config = json.loads(db_config['config'])
                    config['id'] = db_config['server_id']
                    config['name'] = db_config['name']
                    config['priority'] = db_config['priority']
                    config['active'] = db_config['active']
                    configs.append(config)
                except json.JSONDecodeError as e:
                    logger.error(f"解析配置失败: {e}")
                    continue
            
            return configs
            
        except Exception as e:
            logger.error(f"获取配置列表失败: {e}")
            return []
    
    def validate_nekobox_config(self, config: Dict) -> bool:
        """验证Nekobox配置"""
        try:
            # 检查必需字段
            required_fields = ['host', 'port', 'protocol']
            for field in required_fields:
                if field not in config:
                    logger.error(f"缺少必需字段: {field}")
                    return False
            
            # 验证主机地址
            host = config['host']
            if not host or not isinstance(host, str):
                logger.error("主机地址无效")
                return False
            
            # 验证端口
            port = config['port']
            if not isinstance(port, int) or port < 1 or port > 65535:
                logger.error("端口号无效")
                return False
            
            # 验证协议
            protocol = config['protocol']
            valid_protocols = ['socks5', 'http', 'https']
            if protocol not in valid_protocols:
                logger.error(f"不支持的协议: {protocol}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Nekobox 配置验证失败: {e}")
            return False
    
    def parse_uri(self, uri: str) -> Dict:
        """解析各种代理URI并返回配置信息"""
        try:
            from urllib.parse import urlparse, parse_qs, unquote
            
            # 支持的协议
            supported_protocols = ['socks5', 'http', 'https', 'vless', 'vmess', 'trojan', 'hysteria2']
            
            # 检查URI格式
            parsed = urlparse(uri)
            protocol = parsed.scheme.lower()
            
            if protocol not in supported_protocols:
                return {'success': False, 'message': f'不支持的协议: {protocol}'}
            
            # 提取基本信息
            if not parsed.hostname:
                return {'success': False, 'message': 'URI 格式错误：缺少主机名'}
            
            # 尝试从 netloc 中提取端口，处理可能存在的斜杠
            port_str = parsed.netloc.split(':')[-1].split('/')[0] if ':' in parsed.netloc else None
            port = None
            if port_str:
                try:
                    port = int(port_str)
                except ValueError:
                    pass # 端口号无效，将使用默认端口

            if not port:
                # 设置默认端口
                default_ports = {
                    'http': 80,
                    'https': 443,
                    'socks5': 1080,
                    'vless': 443,
                    'vmess': 443,
                    'trojan': 443,
                    'hysteria2': 443
                }
                port = default_ports.get(protocol, 1080)
            
            # 构建基本配置
            config = {
                'name': unquote(parsed.fragment) if parsed.fragment else f"{protocol.upper()} 代理 {len(self.get_saved_configs()) + 1}",
                'host': parsed.hostname,
                'port': port,
                'protocol': 'socks5' if protocol in ['vless', 'vmess', 'trojan', 'hysteria2'] else protocol,
                'original_protocol': protocol,
                'priority': 1,
                'active': True
            }
            
            # 添加认证信息
            if parsed.username:
                config['username'] = parsed.username
            if parsed.password:
                config['password'] = parsed.password
            
            # 解析查询参数（用于高级配置）
            if parsed.query:
                query_params = parse_qs(parsed.query)
                config['advanced_params'] = {}
                
                for key, values in query_params.items():
                    if values:
                        config['advanced_params'][key] = values[0]
            
            # 保存原始URI
            config['original_uri'] = uri
            
            # 验证解析后的配置
            if not self.validate_nekobox_config(config):
                return {'success': False, 'message': '解析后的配置验证失败'}
            
            return {
                'success': True,
                'config': config,
                'message': f'{protocol.upper()} URI 解析成功: {config["name"]}'
            }
            
        except Exception as e:
            logger.error(f"解析 URI 失败: {e}")
            return {'success': False, 'message': f'解析失败: {str(e)}'}
    
    def import_from_uri(self, uri: str) -> Dict:
        """从URI导入配置"""
        try:
            # 解析URI
            parse_result = self.parse_uri(uri)
            if not parse_result['success']:
                return parse_result
            
            config = parse_result['config']
            
            # 检查是否已存在相同的配置
            existing_configs = self.get_saved_configs()
            for existing_config in existing_configs:
                if (existing_config.get('host') == config['host'] and 
                    existing_config.get('port') == config['port'] and
                    existing_config.get('protocol') == config['protocol']):
                    return {
                        'success': False, 
                        'message': f'配置已存在: {existing_config.get("name", "未命名")}'
                    }
            
            # 保存配置
            save_result = self.save_config(config)
            if save_result['success']:
                return {
                    'success': True,
                    'config_id': save_result['config_id'],
                    'config': config,
                    'message': f'从 URI 成功导入配置: {config["name"]}'
                }
            else:
                return save_result
                
        except Exception as e:
            logger.error(f"从 URI 导入配置失败: {e}")
            return {'success': False, 'message': f'导入失败: {str(e)}'}
    
    def export_to_uri(self, config_id: str) -> Dict:
        """将配置导出为URI"""
        try:
            from urllib.parse import quote
            
            # 获取配置
            configs = self.get_saved_configs()
            config = None
            for c in configs:
                if c.get('id') == config_id:
                    config = c
                    break
            
            if not config:
                return {'success': False, 'message': '配置不存在'}
            
            # 如果有原始URI，直接返回
            if config.get('original_uri'):
                return {
                    'success': True,
                    'uri': config['original_uri'],
                    'message': f'成功导出配置 URI: {config["name"]}'
                }
            
            # 构建基本URI
            protocol = config.get('original_protocol', config.get('protocol', 'socks5'))
            host = config.get('host', '')
            port = config.get('port', 1080)
            name = config.get('name', '')
            
            if not host:
                return {'success': False, 'message': '主机地址不能为空'}
            
            # 构建URI
            uri = f"{protocol}://"
            
            # 添加认证信息
            if config.get('username') or config.get('password'):
                username = config.get('username', '')
                password = config.get('password', '')
                uri += f"{username}:{password}@"
            
            uri += f"{host}:{port}"
            
            # 添加查询参数
            advanced_params = config.get('advanced_params', {})
            if advanced_params:
                params = []
                for key, value in advanced_params.items():
                    params.append(f"{key}={quote(str(value))}")
                if params:
                    uri += "?" + "&".join(params)
            
            # 添加名称
            if name:
                uri += f"#{quote(name)}"
            
            return {
                'success': True,
                'uri': uri,
                'message': f'成功导出配置 URI: {name}'
            }
            
        except Exception as e:
            logger.error(f"导出 URI 失败: {e}")
            return {'success': False, 'message': f'导出失败: {str(e)}'}


