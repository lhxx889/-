"""
Gate.io加密货币异动监控系统 - 自定义格式集成示例
演示如何将自定义格式化模块集成到现有监控系统中
"""

import logging
import time
from typing import Dict, Any
from datetime import datetime

# 导入自定义格式化模块
from src.custom_formatter import custom_formatter

# 导入现有模块
from src.enhanced_telegram_alerter import EnhancedTelegramAlerter
from src.enhanced_multi_telegram_alerter import EnhancedMultiTelegramAlerter

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("integration_example")

def process_anomaly_with_custom_format(anomaly: Dict[str, Any]) -> None:
    """
    使用自定义格式处理异常
    
    Args:
        anomaly: 异常数据
    """
    try:
        logger.info(f"处理异常: {anomaly.get('symbol', '')}")
        
        # 使用自定义格式化器生成消息
        message = custom_formatter.format_custom_message(anomaly)
        
        # 创建Telegram警报器
        try:
            # 尝试使用增强版多账号警报器
            alerter = EnhancedMultiTelegramAlerter()
        except:
            # 如果失败，使用标准增强版警报器
            alerter = EnhancedTelegramAlerter()
        
        # 发送消息
        if alerter.is_configured():
            alerter.send_message(message)
            logger.info("消息已发送")
        else:
            logger.warning("Telegram未配置，无法发送消息")
            # 打印消息以便测试
            print("\n--- 自定义格式消息 ---")
            print(message)
            print("--- 消息结束 ---\n")
    except Exception as e:
        logger.error(f"处理异常失败: {str(e)}")

def test_custom_format() -> None:
    """测试自定义格式"""
    # 创建测试异常数据
    anomaly = {
        "symbol": "Hermy_USDT",
        "type": "price",
        "current_price": 0.00123456,
        "reference_price": 0.00100000,
        "price_change_pct": 23.456,
        "volume_24h": 13000,
        "detected_at": datetime.now().isoformat()
    }
    
    # 处理异常
    process_anomaly_with_custom_format(anomaly)

if __name__ == "__main__":
    # 测试自定义格式
    test_custom_format()
