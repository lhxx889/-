"""
Gate.io加密货币异动监控系统 - 异常检测模块
负责分析价格和交易量变化，识别异常波动
"""

import logging
import time
import sqlite3
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import pandas as pd
from collections import defaultdict

# 导入数据采集模块
from src.data_collector import GateioDataCollector

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("anomaly_detector")

class AnomalyDetector:
    """异常检测类，负责检测价格和交易量的异常波动"""
    
    def __init__(
        self, 
        collector: GateioDataCollector,
        price_change_threshold: float = 30.0,  # 价格变化阈值（百分比）
        volume_change_threshold: float = 200.0,  # 交易量变化阈值（百分比）
        min_price: float = 0.00001,  # 最小价格阈值，过滤低价值币种
        min_volume: float = 1000.0,  # 最小交易量阈值，过滤低流动性币种
        reference_period: int = 24  # 参考周期（小时）
    ):
        """
        初始化异常检测器
        
        Args:
            collector: 数据采集器实例
            price_change_threshold: 价格变化阈值（百分比）
            volume_change_threshold: 交易量变化阈值（百分比）
            min_price: 最小价格阈值
            min_volume: 最小交易量阈值
            reference_period: 参考周期（小时）
        """
        self.collector = collector
        self.price_change_threshold = price_change_threshold
        self.volume_change_threshold = volume_change_threshold
        self.min_price = min_price
        self.min_volume = min_volume
        self.reference_period = reference_period
        self.detected_anomalies = defaultdict(list)  # 用于存储已检测到的异常
        
        logger.info(f"异常检测模块初始化完成，价格变化阈值: {price_change_threshold}%，交易量变化阈值: {volume_change_threshold}%")
    
    def detect_price_anomalies(self) -> List[Dict]:
        """
        检测价格异常
        
        Returns:
            异常列表，每个异常包含币种、价格变化等信息
        """
        logger.info("开始检测价格异常")
        anomalies = []
        
        try:
            # 获取最新价格数据
            latest_data = self.collector.get_latest_price_data()
            if not latest_data:
                logger.warning("无法获取最新价格数据")
                return anomalies
            
            # 获取所有币种的ticker数据
            tickers = self.collector.get_cached_tickers()
            if not tickers:
                logger.warning("无法获取缓存的ticker数据")
                return anomalies
            
            # 处理每个币种
            for ticker in tickers:
                symbol = ticker.get("currency_pair")
                if not symbol:
                    continue
                
                try:
                    # 获取当前价格
                    current_price = float(ticker.get("last", 0))
                    if current_price < self.min_price:
                        continue  # 忽略低价值币种
                    
                    # 获取24小时前价格
                    historical_data = self.collector.get_historical_price_data(symbol, self.reference_period)
                    if not historical_data:
                        continue  # 没有历史数据，跳过
                    
                    # 找到最早的价格记录作为参考
                    reference_price = None
                    for data in historical_data:
                        if data["price"] > 0:
                            reference_price = data["price"]
                            break
                    
                    if not reference_price:
                        continue  # 没有有效的参考价格，跳过
                    
                    # 计算价格变化百分比
                    price_change_pct = ((current_price - reference_price) / reference_price) * 100
                    
                    # 检查是否超过阈值
                    if abs(price_change_pct) >= self.price_change_threshold:
                        # 检查是否已经报告过这个异常
                        if self._is_already_reported(symbol, "price", price_change_pct):
                            continue
                        
                        # 记录异常
                        anomaly = {
                            "symbol": symbol,
                            "current_price": current_price,
                            "reference_price": reference_price,
                            "price_change_pct": price_change_pct,
                            "volume_24h": float(ticker.get("base_volume", 0)),
                            "detected_at": datetime.now().isoformat(),
                            "type": "price"
                        }
                        
                        anomalies.append(anomaly)
                        self._record_anomaly(symbol, "price", price_change_pct)
                        logger.info(f"检测到价格异常: {symbol}, 变化: {price_change_pct:.2f}%")
                
                except (ValueError, TypeError, KeyError) as e:
                    logger.warning(f"处理币种{symbol}时出错: {str(e)}")
                    continue
            
            logger.info(f"价格异常检测完成，发现{len(anomalies)}个异常")
            return anomalies
        
        except Exception as e:
            logger.error(f"价格异常检测过程中发生错误: {str(e)}")
            return anomalies
    
    def detect_volume_anomalies(self) -> List[Dict]:
        """
        检测交易量异常
        
        Returns:
            异常列表，每个异常包含币种、交易量变化等信息
        """
        logger.info("开始检测交易量异常")
        anomalies = []
        
        try:
            # 获取最新价格数据
            latest_data = self.collector.get_latest_price_data()
            if not latest_data:
                logger.warning("无法获取最新价格数据")
                return anomalies
            
            # 获取所有币种的ticker数据
            tickers = self.collector.get_cached_tickers()
            if not tickers:
                logger.warning("无法获取缓存的ticker数据")
                return anomalies
            
            # 处理每个币种
            for ticker in tickers:
                symbol = ticker.get("currency_pair")
                if not symbol:
                    continue
                
                try:
                    # 获取当前交易量
                    current_volume = float(ticker.get("base_volume", 0))
                    if current_volume < self.min_volume:
                        continue  # 忽略低流动性币种
                    
                    # 获取历史交易量数据
                    historical_data = self.collector.get_historical_price_data(symbol, self.reference_period)
                    if not historical_data or len(historical_data) < 2:
                        continue  # 没有足够的历史数据，跳过
                    
                    # 计算平均交易量作为参考
                    volumes = [data["volume_24h"] for data in historical_data if data["volume_24h"] > 0]
                    if not volumes:
                        continue
                    
                    # 使用移动平均线作为参考
                    reference_volume = np.mean(volumes)
                    if reference_volume <= 0:
                        continue
                    
                    # 计算交易量变化百分比
                    volume_change_pct = ((current_volume - reference_volume) / reference_volume) * 100
                    
                    # 检查是否超过阈值
                    if volume_change_pct >= self.volume_change_threshold:
                        # 检查是否已经报告过这个异常
                        if self._is_already_reported(symbol, "volume", volume_change_pct):
                            continue
                        
                        # 记录异常
                        anomaly = {
                            "symbol": symbol,
                            "current_volume": current_volume,
                            "reference_volume": reference_volume,
                            "volume_change_pct": volume_change_pct,
                            "current_price": float(ticker.get("last", 0)),
                            "detected_at": datetime.now().isoformat(),
                            "type": "volume"
                        }
                        
                        anomalies.append(anomaly)
                        self._record_anomaly(symbol, "volume", volume_change_pct)
                        logger.info(f"检测到交易量异常: {symbol}, 变化: {volume_change_pct:.2f}%")
                
                except (ValueError, TypeError, KeyError) as e:
                    logger.warning(f"处理币种{symbol}时出错: {str(e)}")
                    continue
            
            logger.info(f"交易量异常检测完成，发现{len(anomalies)}个异常")
            return anomalies
        
        except Exception as e:
            logger.error(f"交易量异常检测过程中发生错误: {str(e)}")
            return anomalies
    
    def detect_all_anomalies(self) -> List[Dict]:
        """
        检测所有类型的异常
        
        Returns:
            所有异常的列表
        """
        price_anomalies = self.detect_price_anomalies()
        volume_anomalies = self.detect_volume_anomalies()
        
        all_anomalies = price_anomalies + volume_anomalies
        
        # 按检测时间排序
        all_anomalies.sort(key=lambda x: x["detected_at"], reverse=True)
        
        return all_anomalies
    
    def save_anomalies_to_db(self, anomalies: List[Dict]) -> None:
        """
        将异常保存到数据库
        
        Args:
            anomalies: 异常列表
        """
        if not anomalies:
            return
        
        try:
            conn = sqlite3.connect(self.collector.db_path)
            cursor = conn.cursor()
            
            for anomaly in anomalies:
                if anomaly["type"] == "price":
                    cursor.execute(
                        """
                        INSERT INTO anomaly_records 
                        (symbol, price, old_price, change_percentage, volume_24h, detected_at) 
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (
                            anomaly["symbol"],
                            anomaly["current_price"],
                            anomaly["reference_price"],
                            anomaly["price_change_pct"],
                            anomaly["volume_24h"],
                            anomaly["detected_at"]
                        )
                    )
                elif anomaly["type"] == "volume":
                    cursor.execute(
                        """
                        INSERT INTO anomaly_records 
                        (symbol, price, old_price, change_percentage, volume_24h, volume_change_percentage, detected_at) 
                        VALUES (?, ?, ?, 0, ?, ?, ?)
                        """,
                        (
                            anomaly["symbol"],
                            anomaly["current_price"],
                            anomaly["current_price"],
                            anomaly["current_volume"],
                            anomaly["volume_change_pct"],
                            anomaly["detected_at"]
                        )
                    )
            
            conn.commit()
            conn.close()
            logger.info(f"成功保存{len(anomalies)}个异常到数据库")
        except Exception as e:
            logger.error(f"保存异常到数据库失败: {str(e)}")
    
    def filter_and_prioritize_alerts(self, anomalies: List[Dict], max_alerts: int = 10) -> List[Dict]:
        """
        过滤和排序异常事件，确定优先级
        
        Args:
            anomalies: 异常列表
            max_alerts: 最大警报数量
            
        Returns:
            过滤和排序后的异常列表
        """
        if not anomalies:
            return []
        
        # 按重要性排序（价格变化幅度和交易量变化幅度）
        def importance_score(anomaly):
            if anomaly["type"] == "price":
                return abs(anomaly["price_change_pct"])
            elif anomaly["type"] == "volume":
                return anomaly["volume_change_pct"] / 10  # 降低交易量变化的权重
            return 0
        
        sorted_anomalies = sorted(anomalies, key=importance_score, reverse=True)
        
        # 限制警报数量
        return sorted_anomalies[:max_alerts]
    
    def _is_already_reported(self, symbol: str, anomaly_type: str, change_pct: float) -> bool:
        """
        检查异常是否已经报告过
        
        Args:
            symbol: 币种符号
            anomaly_type: 异常类型（"price"或"volume"）
            change_pct: 变化百分比
            
        Returns:
            是否已经报告过
        """
        key = f"{symbol}_{anomaly_type}"
        
        # 检查是否已经报告过类似的异常
        for reported_change in self.detected_anomalies[key]:
            # 如果变化方向相同且差异不大，认为是同一个异常
            if (change_pct > 0 and reported_change > 0) or (change_pct < 0 and reported_change < 0):
                if abs(abs(change_pct) - abs(reported_change)) < self.price_change_threshold / 2:
                    return True
        
        return False
    
    def _record_anomaly(self, symbol: str, anomaly_type: str, change_pct: float) -> None:
        """
        记录已检测到的异常
        
        Args:
            symbol: 币种符号
            anomaly_type: 异常类型（"price"或"volume"）
            change_pct: 变化百分比
        """
        key = f"{symbol}_{anomaly_type}"
        self.detected_anomalies[key].append(change_pct)
        
        # 限制记录数量，避免内存泄漏
        if len(self.detected_anomalies[key]) > 10:
            self.detected_anomalies[key] = self.detected_anomalies[key][-10:]


class AnomalyMonitor:
    """异常监控类，负责定期检测异常并触发警报"""
    
    def __init__(
        self, 
        detector: AnomalyDetector,
        check_interval: int = 50  # 检查间隔（秒）
    ):
        """
        初始化异常监控器
        
        Args:
            detector: 异常检测器实例
            check_interval: 检查间隔（秒）
        """
        self.detector = detector
        self.check_interval = check_interval
        self.running = False
        self.alert_callbacks = []
        
        logger.info(f"异常监控器初始化完成，检查间隔: {check_interval}秒")
    
    def register_alert_callback(self, callback):
        """
        注册警报回调函数
        
        Args:
            callback: 回调函数，接收异常列表作为参数
        """
        self.alert_callbacks.append(callback)
        logger.info(f"已注册警报回调函数: {callback.__name__}")
    
    def start(self):
        """启动监控"""
        self.running = True
        logger.info("异常监控启动")
        
        try:
            while self.running:
                logger.info(f"执行异常检测，当前时间: {datetime.now().isoformat()}")
                
                # 检测异常
                anomalies = self.detector.detect_all_anomalies()
                
                # 保存异常到数据库
                self.detector.save_anomalies_to_db(anomalies)
                
                # 如果有异常，触发警报
                if anomalies:
                    # 过滤和排序异常
                    prioritized_anomalies = self.detector.filter_and_prioritize_alerts(anomalies)
                    
                    # 触发警报回调
                    for callback in self.alert_callbacks:
                        try:
                            callback(prioritized_anomalies)
                        except Exception as e:
                            logger.error(f"执行警报回调函数时出错: {str(e)}")
                
                # 等待下一次检查
                logger.info(f"等待{self.check_interval}秒后进行下一次检查")
                time.sleep(self.check_interval)
        
        except KeyboardInterrupt:
            logger.info("收到中断信号，停止监控")
            self.stop()
        except Exception as e:
            logger.error(f"监控过程中发生错误: {str(e)}")
            self.stop()
    
    def stop(self):
        """停止监控"""
        self.running = False
        logger.info("异常监控已停止")


if __name__ == "__main__":
    # 测试代码
    from src.data_collector import GateioDataCollector
    
    # 初始化数据采集器
    collector = GateioDataCollector()
    
    # 确保有一些数据
    print("获取初始数据...")
    collector.update_data()
    
    # 初始化异常检测器
    detector = AnomalyDetector(
        collector,
        price_change_threshold=30.0,
        volume_change_threshold=200.0
    )
    
    # 测试异常检测
    print("\n检测价格异常...")
    price_anomalies = detector.detect_price_anomalies()
    print(f"检测到 {len(price_anomalies)} 个价格异常")
    for anomaly in price_anomalies[:5]:
        print(f"  - {anomaly['symbol']}: 价格从 {anomaly['reference_price']} 变为 {anomaly['current_price']}, 变化 {anomaly['price_change_pct']:.2f}%")
    
    print("\n检测交易量异常...")
    volume_anomalies = detector.detect_volume_anomalies()
    print(f"检测到 {len(volume_anomalies)} 个交易量异常")
    for anomaly in volume_anomalies[:5]:
        print(f"  - {anomaly['symbol']}: 交易量从 {anomaly['reference_volume']} 变为 {anomaly['current_volume']}, 变化 {anomaly['volume_change_pct']:.2f}%")
    
    print("\n保存异常到数据库...")
    all_anomalies = price_anomalies + volume_anomalies
    detector.save_anomalies_to_db(all_anomalies)
    
    print("\n过滤和排序异常...")
    prioritized_anomalies = detector.filter_and_prioritize_alerts(all_anomalies)
    print(f"优先级排序后的前 {len(prioritized_anomalies)} 个异常:")
    for anomaly in prioritized_anomalies:
        if anomaly["type"] == "price":
            print(f"  - {anomaly['symbol']}: 价格变化 {anomaly['price_change_pct']:.2f}%")
        else:
            print(f"  - {anomaly['symbol']}: 交易量变化 {anomaly['volume_change_pct']:.2f}%")
    
    print("\n测试完成，可以通过以下命令启动异常监控:")
    print("  monitor = AnomalyMonitor(detector)")
    print("  monitor.start()")
