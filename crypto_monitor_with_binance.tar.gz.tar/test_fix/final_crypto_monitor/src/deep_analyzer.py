"""
Gate.io加密货币异动监控系统 - 深度分析和信息查询模块
负责分析异动可能的原因和获取币种详细信息
"""

import logging
import time
import json
import requests
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import os
import re

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("deep_analyzer")

class NewsAnalyzer:
    """新闻分析类，负责获取和分析加密货币相关新闻"""
    
    # CryptoCompare News API
    CRYPTOCOMPARE_API_URL = "https://min-api.cryptocompare.com/data/v2/news/"
    
    # CoinGecko News API (通过搜索实现)
    COINGECKO_SEARCH_URL = "https://api.coingecko.com/api/v3/search"
    COINGECKO_COIN_URL = "https://api.coingecko.com/api/v3/coins/{id}"
    
    def __init__(self, api_key: str = None, config_file: str = "api_config.json"):
        """
        初始化新闻分析器
        
        Args:
            api_key: CryptoCompare API密钥（可选）
            config_file: 配置文件路径
        """
        self.api_key = api_key
        self.config_file = config_file
        self.cache = {}
        self.cache_expiry = {}
        self.cache_duration = 3600  # 缓存有效期（秒）
        
        # 如果提供了配置文件，尝试从中加载API密钥
        if not self.api_key:
            self._load_config()
        
        logger.info("新闻分析模块初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载API配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.api_key = config.get("cryptocompare_api_key", self.api_key)
                    logger.info("从配置文件加载API配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def save_config(self, api_key: str) -> bool:
        """
        保存API配置到配置文件
        
        Args:
            api_key: CryptoCompare API密钥
            
        Returns:
            保存是否成功
        """
        try:
            self.api_key = api_key
            
            # 读取现有配置（如果存在）
            config = {}
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            
            # 更新配置
            config["cryptocompare_api_key"] = api_key
            
            # 保存配置
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info("保存API配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def _make_request(self, url: str, params: Dict = None, headers: Dict = None) -> Optional[Dict]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API URL
            params: 请求参数
            headers: 请求头
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, headers=headers, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
    
    def get_crypto_news(self, categories: str = None, limit: int = 10) -> List[Dict]:
        """
        获取加密货币新闻
        
        Args:
            categories: 新闻类别，逗号分隔
            limit: 返回的新闻数量
            
        Returns:
            新闻列表
        """
        # 检查缓存
        cache_key = f"crypto_news_{categories}_{limit}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取加密货币新闻")
            return self.cache[cache_key]
        
        logger.info(f"获取加密货币新闻，类别: {categories}, 数量: {limit}")
        
        params = {"limit": limit}
        headers = {}
        
        if categories:
            params["categories"] = categories
        
        if self.api_key:
            headers["authorization"] = f"Apikey {self.api_key}"
        
        data = self._make_request(self.CRYPTOCOMPARE_API_URL, params, headers)
        
        if data and data.get("Response") == "Success":
            news = data.get("Data", [])
            logger.info(f"成功获取{len(news)}条加密货币新闻")
            
            # 更新缓存
            self.cache[cache_key] = news
            self.cache_expiry[cache_key] = time.time()
            
            return news
        
        logger.warning("获取加密货币新闻失败")
        return []
    
    def get_coin_news(self, symbol: str, limit: int = 5) -> List[Dict]:
        """
        获取特定币种的新闻
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            limit: 返回的新闻数量
            
        Returns:
            新闻列表
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"coin_news_{coin_name}_{limit}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{coin_name}的新闻")
            return self.cache[cache_key]
        
        logger.info(f"获取{coin_name}的新闻，数量: {limit}")
        
        # 获取所有新闻
        all_news = self.get_crypto_news(limit=50)
        
        # 过滤与币种相关的新闻
        coin_news = []
        for news in all_news:
            title = news.get("title", "").lower()
            body = news.get("body", "").lower()
            categories = news.get("categories", "").lower()
            
            # 检查新闻标题、内容和类别是否包含币种名称
            if (
                coin_name.lower() in title or
                coin_name.lower() in body or
                coin_name.lower() in categories
            ):
                coin_news.append(news)
                
                # 如果已经找到足够的新闻，停止搜索
                if len(coin_news) >= limit:
                    break
        
        logger.info(f"成功获取{len(coin_news)}条{coin_name}的新闻")
        
        # 更新缓存
        self.cache[cache_key] = coin_news
        self.cache_expiry[cache_key] = time.time()
        
        return coin_news
    
    def get_coin_id_from_coingecko(self, symbol: str) -> Optional[str]:
        """
        从CoinGecko获取币种ID
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种ID或None（如果未找到）
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"coingecko_id_{coin_name}"
        if cache_key in self.cache:
            logger.info(f"从缓存获取{coin_name}的CoinGecko ID")
            return self.cache[cache_key]
        
        logger.info(f"从CoinGecko获取{coin_name}的ID")
        
        params = {"query": coin_name}
        data = self._make_request(self.COINGECKO_SEARCH_URL, params)
        
        if data and "coins" in data:
            coins = data["coins"]
            if coins:
                # 尝试找到最匹配的币种
                for coin in coins:
                    if (
                        coin["symbol"].lower() == coin_name.lower() or
                        coin["name"].lower() == coin_name.lower()
                    ):
                        coin_id = coin["id"]
                        logger.info(f"成功获取{coin_name}的CoinGecko ID: {coin_id}")
                        
                        # 更新缓存
                        self.cache[cache_key] = coin_id
                        
                        return coin_id
                
                # 如果没有找到完全匹配的，使用第一个结果
                coin_id = coins[0]["id"]
                logger.info(f"未找到完全匹配的{coin_name}，使用第一个结果: {coin_id}")
                
                # 更新缓存
                self.cache[cache_key] = coin_id
                
                return coin_id
        
        logger.warning(f"未找到{coin_name}的CoinGecko ID")
        
        # 更新缓存（避免重复请求）
        self.cache[cache_key] = None
        
        return None
    
    def get_coin_info_from_coingecko(self, symbol: str) -> Optional[Dict]:
        """
        从CoinGecko获取币种信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种信息或None（如果未找到）
        """
        # 检查缓存
        cache_key = f"coingecko_info_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{symbol}的CoinGecko信息")
            return self.cache[cache_key]
        
        logger.info(f"从CoinGecko获取{symbol}的信息")
        
        # 获取币种ID
        coin_id = self.get_coin_id_from_coingecko(symbol)
        if not coin_id:
            return None
        
        # 获取币种信息
        url = self.COINGECKO_COIN_URL.format(id=coin_id)
        data = self._make_request(url)
        
        if data:
            logger.info(f"成功获取{symbol}的CoinGecko信息")
            
            # 更新缓存
            self.cache[cache_key] = data
            self.cache_expiry[cache_key] = time.time()
            
            return data
        
        logger.warning(f"获取{symbol}的CoinGecko信息失败")
        return None
    
    def analyze_news_sentiment(self, news: List[Dict]) -> Dict:
        """
        分析新闻情感
        
        Args:
            news: 新闻列表
            
        Returns:
            情感分析结果
        """
        if not news:
            return {
                "sentiment": "neutral",
                "score": 0,
                "positive_count": 0,
                "negative_count": 0,
                "neutral_count": 0
            }
        
        # 简单的情感分析，基于关键词
        positive_keywords = [
            "bullish", "surge", "soar", "rally", "gain", "rise", "up", "high", "positive",
            "good", "great", "excellent", "amazing", "fantastic", "wonderful", "success",
            "breakthrough", "innovation", "partnership", "collaboration", "adoption",
            "launch", "release", "update", "upgrade", "improvement", "enhance", "boost"
        ]
        
        negative_keywords = [
            "bearish", "crash", "plunge", "drop", "fall", "down", "low", "negative",
            "bad", "poor", "terrible", "awful", "horrible", "disaster", "failure",
            "problem", "issue", "concern", "worry", "fear", "risk", "threat", "danger",
            "hack", "scam", "fraud", "investigation", "regulation", "ban", "restrict"
        ]
        
        positive_count = 0
        negative_count = 0
        neutral_count = 0
        
        for item in news:
            title = item.get("title", "").lower()
            body = item.get("body", "").lower()
            
            # 计算正面和负面关键词出现次数
            positive_matches = sum(1 for keyword in positive_keywords if keyword in title or keyword in body)
            negative_matches = sum(1 for keyword in negative_keywords if keyword in title or keyword in body)
            
            # 确定情感
            if positive_matches > negative_matches:
                positive_count += 1
            elif negative_matches > positive_matches:
                negative_count += 1
            else:
                neutral_count += 1
        
        # 计算总体情感得分（-1到1之间）
        total = positive_count + negative_count + neutral_count
        if total > 0:
            score = (positive_count - negative_count) / total
        else:
            score = 0
        
        # 确定总体情感
        if score > 0.2:
            sentiment = "positive"
        elif score < -0.2:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return {
            "sentiment": sentiment,
            "score": score,
            "positive_count": positive_count,
            "negative_count": negative_count,
            "neutral_count": neutral_count
        }


class SocialMediaAnalyzer:
    """社交媒体分析类，负责获取和分析社交媒体上的讨论"""
    
    # Twitter API（通过第三方服务）
    TWITTER_SEARCH_URL = "https://api.twitter.com/2/tweets/search/recent"
    
    # Reddit API
    REDDIT_SEARCH_URL = "https://www.reddit.com/search.json"
    
    def __init__(self, config_file: str = "api_config.json"):
        """
        初始化社交媒体分析器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.twitter_bearer_token = None
        self.reddit_client_id = None
        self.reddit_client_secret = None
        self.cache = {}
        self.cache_expiry = {}
        self.cache_duration = 1800  # 缓存有效期（秒）
        
        # 尝试从配置文件加载API密钥
        self._load_config()
        
        logger.info("社交媒体分析模块初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载API配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.twitter_bearer_token = config.get("twitter_bearer_token")
                    self.reddit_client_id = config.get("reddit_client_id")
                    self.reddit_client_secret = config.get("reddit_client_secret")
                    logger.info("从配置文件加载社交媒体API配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def save_config(self, twitter_token: str = None, reddit_id: str = None, reddit_secret: str = None) -> bool:
        """
        保存API配置到配置文件
        
        Args:
            twitter_token: Twitter Bearer Token
            reddit_id: Reddit Client ID
            reddit_secret: Reddit Client Secret
            
        Returns:
            保存是否成功
        """
        try:
            # 读取现有配置（如果存在）
            config = {}
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            
            # 更新配置
            if twitter_token:
                self.twitter_bearer_token = twitter_token
                config["twitter_bearer_token"] = twitter_token
            
            if reddit_id:
                self.reddit_client_id = reddit_id
                config["reddit_client_id"] = reddit_id
            
            if reddit_secret:
                self.reddit_client_secret = reddit_secret
                config["reddit_client_secret"] = reddit_secret
            
            # 保存配置
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info("保存社交媒体API配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def _make_request(self, url: str, params: Dict = None, headers: Dict = None) -> Optional[Dict]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API URL
            params: 请求参数
            headers: 请求头
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, headers=headers, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
    
    def search_twitter(self, query: str, max_results: int = 10) -> List[Dict]:
        """
        搜索Twitter
        
        Args:
            query: 搜索查询
            max_results: 最大结果数
            
        Returns:
            推文列表
        """
        # 检查是否配置了Twitter API
        if not self.twitter_bearer_token:
            logger.warning("未配置Twitter API，无法搜索Twitter")
            return []
        
        # 检查缓存
        cache_key = f"twitter_{query}_{max_results}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取Twitter搜索结果: {query}")
            return self.cache[cache_key]
        
        logger.info(f"搜索Twitter: {query}, 最大结果数: {max_results}")
        
        params = {
            "query": query,
            "max_results": max_results,
            "tweet.fields": "created_at,public_metrics"
        }
        
        headers = {
            "Authorization": f"Bearer {self.twitter_bearer_token}"
        }
        
        data = self._make_request(self.TWITTER_SEARCH_URL, params, headers)
        
        if data and "data" in data:
            tweets = data["data"]
            logger.info(f"成功获取{len(tweets)}条Twitter搜索结果")
            
            # 更新缓存
            self.cache[cache_key] = tweets
            self.cache_expiry[cache_key] = time.time()
            
            return tweets
        
        logger.warning(f"搜索Twitter失败: {query}")
        return []
    
    def search_reddit(self, query: str, limit: int = 10) -> List[Dict]:
        """
        搜索Reddit
        
        Args:
            query: 搜索查询
            limit: 结果数量限制
            
        Returns:
            帖子列表
        """
        # 检查缓存
        cache_key = f"reddit_{query}_{limit}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取Reddit搜索结果: {query}")
            return self.cache[cache_key]
        
        logger.info(f"搜索Reddit: {query}, 限制: {limit}")
        
        params = {
            "q": query,
            "limit": limit,
            "sort": "new",
            "t": "day"  # 过去24小时
        }
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        
        # 如果配置了Reddit API，添加认证
        if self.reddit_client_id and self.reddit_client_secret:
            auth = requests.auth.HTTPBasicAuth(self.reddit_client_id, self.reddit_client_secret)
            response = requests.get(self.REDDIT_SEARCH_URL, params=params, headers=headers, auth=auth, timeout=10)
        else:
            # 使用公共API（有限制）
            response = requests.get(self.REDDIT_SEARCH_URL, params=params, headers=headers, timeout=10)
        
        try:
            response.raise_for_status()
            data = response.json()
            
            if "data" in data and "children" in data["data"]:
                posts = [post["data"] for post in data["data"]["children"]]
                logger.info(f"成功获取{len(posts)}条Reddit搜索结果")
                
                # 更新缓存
                self.cache[cache_key] = posts
                self.cache_expiry[cache_key] = time.time()
                
                return posts
        except Exception as e:
            logger.error(f"搜索Reddit失败: {str(e)}")
        
        return []
    
    def analyze_social_media(self, symbol: str) -> Dict:
        """
        分析社交媒体上关于特定币种的讨论
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            分析结果
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"social_analysis_{coin_name}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{coin_name}的社交媒体分析")
            return self.cache[cache_key]
        
        logger.info(f"分析{coin_name}的社交媒体讨论")
        
        # 搜索Twitter
        twitter_query = f"#{coin_name} OR ${coin_name} crypto"
        tweets = self.search_twitter(twitter_query, 20)
        
        # 搜索Reddit
        reddit_query = f"{coin_name} crypto"
        reddit_posts = self.search_reddit(reddit_query, 20)
        
        # 分析Twitter讨论量
        twitter_discussion_count = len(tweets)
        
        # 分析Reddit讨论量
        reddit_discussion_count = len(reddit_posts)
        
        # 分析Twitter情感
        twitter_sentiment = self._analyze_text_sentiment([tweet.get("text", "") for tweet in tweets])
        
        # 分析Reddit情感
        reddit_sentiment = self._analyze_text_sentiment([
            post.get("title", "") + " " + post.get("selftext", "")
            for post in reddit_posts
        ])
        
        # 计算总体社交媒体热度（0-10）
        total_discussions = twitter_discussion_count + reddit_discussion_count
        if total_discussions >= 30:
            social_heat = 10
        elif total_discussions >= 20:
            social_heat = 8
        elif total_discussions >= 10:
            social_heat = 6
        elif total_discussions >= 5:
            social_heat = 4
        elif total_discussions > 0:
            social_heat = 2
        else:
            social_heat = 0
        
        # 计算总体情感得分（-1到1之间）
        if twitter_discussion_count + reddit_discussion_count > 0:
            overall_sentiment_score = (
                twitter_sentiment["score"] * twitter_discussion_count +
                reddit_sentiment["score"] * reddit_discussion_count
            ) / (twitter_discussion_count + reddit_discussion_count)
        else:
            overall_sentiment_score = 0
        
        # 确定总体情感
        if overall_sentiment_score > 0.2:
            overall_sentiment = "positive"
        elif overall_sentiment_score < -0.2:
            overall_sentiment = "negative"
        else:
            overall_sentiment = "neutral"
        
        result = {
            "twitter_discussion_count": twitter_discussion_count,
            "reddit_discussion_count": reddit_discussion_count,
            "twitter_sentiment": twitter_sentiment,
            "reddit_sentiment": reddit_sentiment,
            "social_heat": social_heat,
            "overall_sentiment": overall_sentiment,
            "overall_sentiment_score": overall_sentiment_score
        }
        
        # 更新缓存
        self.cache[cache_key] = result
        self.cache_expiry[cache_key] = time.time()
        
        return result
    
    def _analyze_text_sentiment(self, texts: List[str]) -> Dict:
        """
        分析文本情感
        
        Args:
            texts: 文本列表
            
        Returns:
            情感分析结果
        """
        if not texts:
            return {
                "sentiment": "neutral",
                "score": 0,
                "positive_count": 0,
                "negative_count": 0,
                "neutral_count": 0
            }
        
        # 简单的情感分析，基于关键词
        positive_keywords = [
            "bullish", "moon", "lambo", "hodl", "buy", "long", "up", "high", "positive",
            "good", "great", "excellent", "amazing", "fantastic", "wonderful", "success",
            "breakthrough", "innovation", "partnership", "collaboration", "adoption",
            "launch", "release", "update", "upgrade", "improvement", "enhance", "boost"
        ]
        
        negative_keywords = [
            "bearish", "crash", "dump", "sell", "short", "down", "low", "negative",
            "bad", "poor", "terrible", "awful", "horrible", "disaster", "failure",
            "problem", "issue", "concern", "worry", "fear", "risk", "threat", "danger",
            "hack", "scam", "fraud", "investigation", "regulation", "ban", "restrict"
        ]
        
        positive_count = 0
        negative_count = 0
        neutral_count = 0
        
        for text in texts:
            if not text:
                continue
                
            text = text.lower()
            
            # 计算正面和负面关键词出现次数
            positive_matches = sum(1 for keyword in positive_keywords if keyword in text)
            negative_matches = sum(1 for keyword in negative_keywords if keyword in text)
            
            # 确定情感
            if positive_matches > negative_matches:
                positive_count += 1
            elif negative_matches > positive_matches:
                negative_count += 1
            else:
                neutral_count += 1
        
        # 计算总体情感得分（-1到1之间）
        total = positive_count + negative_count + neutral_count
        if total > 0:
            score = (positive_count - negative_count) / total
        else:
            score = 0
        
        # 确定总体情感
        if score > 0.2:
            sentiment = "positive"
        elif score < -0.2:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return {
            "sentiment": sentiment,
            "score": score,
            "positive_count": positive_count,
            "negative_count": negative_count,
            "neutral_count": neutral_count
        }


class CoinInfoFetcher:
    """币种信息获取类，负责获取币种的详细信息"""
    
    # CoinGecko API
    COINGECKO_SEARCH_URL = "https://api.coingecko.com/api/v3/search"
    COINGECKO_COIN_URL = "https://api.coingecko.com/api/v3/coins/{id}"
    
    # Gate.io API
    GATEIO_CURRENCY_URL = "https://api.gateio.ws/api/v4/spot/currencies/{currency}"
    
    def __init__(self):
        """初始化币种信息获取器"""
        self.cache = {}
        self.cache_expiry = {}
        self.cache_duration = 3600  # 缓存有效期（秒）
        
        logger.info("币种信息获取模块初始化完成")
    
    def _make_request(self, url: str, params: Dict = None) -> Optional[Dict]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API URL
            params: 请求参数
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
    
    def get_coin_id_from_coingecko(self, symbol: str) -> Optional[str]:
        """
        从CoinGecko获取币种ID
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种ID或None（如果未找到）
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"coingecko_id_{coin_name}"
        if cache_key in self.cache:
            logger.info(f"从缓存获取{coin_name}的CoinGecko ID")
            return self.cache[cache_key]
        
        logger.info(f"从CoinGecko获取{coin_name}的ID")
        
        params = {"query": coin_name}
        data = self._make_request(self.COINGECKO_SEARCH_URL, params)
        
        if data and "coins" in data:
            coins = data["coins"]
            if coins:
                # 尝试找到最匹配的币种
                for coin in coins:
                    if (
                        coin["symbol"].lower() == coin_name.lower() or
                        coin["name"].lower() == coin_name.lower()
                    ):
                        coin_id = coin["id"]
                        logger.info(f"成功获取{coin_name}的CoinGecko ID: {coin_id}")
                        
                        # 更新缓存
                        self.cache[cache_key] = coin_id
                        
                        return coin_id
                
                # 如果没有找到完全匹配的，使用第一个结果
                coin_id = coins[0]["id"]
                logger.info(f"未找到完全匹配的{coin_name}，使用第一个结果: {coin_id}")
                
                # 更新缓存
                self.cache[cache_key] = coin_id
                
                return coin_id
        
        logger.warning(f"未找到{coin_name}的CoinGecko ID")
        
        # 更新缓存（避免重复请求）
        self.cache[cache_key] = None
        
        return None
    
    def get_coin_info_from_coingecko(self, symbol: str) -> Optional[Dict]:
        """
        从CoinGecko获取币种信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种信息或None（如果未找到）
        """
        # 检查缓存
        cache_key = f"coingecko_info_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{symbol}的CoinGecko信息")
            return self.cache[cache_key]
        
        logger.info(f"从CoinGecko获取{symbol}的信息")
        
        # 获取币种ID
        coin_id = self.get_coin_id_from_coingecko(symbol)
        if not coin_id:
            return None
        
        # 获取币种信息
        url = self.COINGECKO_COIN_URL.format(id=coin_id)
        data = self._make_request(url)
        
        if data:
            logger.info(f"成功获取{symbol}的CoinGecko信息")
            
            # 更新缓存
            self.cache[cache_key] = data
            self.cache_expiry[cache_key] = time.time()
            
            return data
        
        logger.warning(f"获取{symbol}的CoinGecko信息失败")
        return None
    
    def get_coin_info_from_gateio(self, symbol: str) -> Optional[Dict]:
        """
        从Gate.io获取币种信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种信息或None（如果未找到）
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"gateio_info_{coin_name}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{coin_name}的Gate.io信息")
            return self.cache[cache_key]
        
        logger.info(f"从Gate.io获取{coin_name}的信息")
        
        # 获取币种信息
        url = self.GATEIO_CURRENCY_URL.format(currency=coin_name)
        data = self._make_request(url)
        
        if data:
            logger.info(f"成功获取{coin_name}的Gate.io信息")
            
            # 更新缓存
            self.cache[cache_key] = data
            self.cache_expiry[cache_key] = time.time()
            
            return data
        
        logger.warning(f"获取{coin_name}的Gate.io信息失败")
        return None
    
    def get_coin_info(self, symbol: str) -> Dict:
        """
        获取币种的综合信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种综合信息
        """
        # 检查缓存
        cache_key = f"combined_info_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{symbol}的综合信息")
            return self.cache[cache_key]
        
        logger.info(f"获取{symbol}的综合信息")
        
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 从CoinGecko获取信息
        coingecko_info = self.get_coin_info_from_coingecko(symbol)
        
        # 从Gate.io获取信息
        gateio_info = self.get_coin_info_from_gateio(coin_name)
        
        # 整合信息
        result = {
            "symbol": symbol,
            "name": coin_name,
            "market_data": {},
            "social_data": {},
            "description": "",
            "links": {}
        }
        
        # 添加CoinGecko信息
        if coingecko_info:
            # 基本信息
            result["name"] = coingecko_info.get("name", result["name"])
            result["description"] = coingecko_info.get("description", {}).get("en", "")
            
            # 市场数据
            market_data = coingecko_info.get("market_data", {})
            result["market_data"] = {
                "current_price_usd": market_data.get("current_price", {}).get("usd"),
                "market_cap_usd": market_data.get("market_cap", {}).get("usd"),
                "total_volume_usd": market_data.get("total_volume", {}).get("usd"),
                "circulating_supply": market_data.get("circulating_supply"),
                "total_supply": market_data.get("total_supply"),
                "max_supply": market_data.get("max_supply"),
                "price_change_percentage_24h": market_data.get("price_change_percentage_24h"),
                "price_change_percentage_7d": market_data.get("price_change_percentage_7d"),
                "price_change_percentage_30d": market_data.get("price_change_percentage_30d")
            }
            
            # 社交数据
            community_data = coingecko_info.get("community_data", {})
            result["social_data"] = {
                "twitter_followers": community_data.get("twitter_followers"),
                "reddit_subscribers": community_data.get("reddit_subscribers"),
                "telegram_channel_user_count": community_data.get("telegram_channel_user_count")
            }
            
            # 链接
            links = coingecko_info.get("links", {})
            result["links"] = {
                "homepage": links.get("homepage", [""])[0] if links.get("homepage") else "",
                "blockchain_site": links.get("blockchain_site", [""])[0] if links.get("blockchain_site") else "",
                "official_forum_url": links.get("official_forum_url", [""])[0] if links.get("official_forum_url") else "",
                "chat_url": links.get("chat_url", [""])[0] if links.get("chat_url") else "",
                "announcement_url": links.get("announcement_url", [""])[0] if links.get("announcement_url") else "",
                "twitter_screen_name": links.get("twitter_screen_name", ""),
                "telegram_channel_identifier": links.get("telegram_channel_identifier", ""),
                "subreddit_url": links.get("subreddit_url", "")
            }
        
        # 添加Gate.io信息
        if gateio_info:
            # 如果CoinGecko没有提供某些信息，使用Gate.io的信息
            if not result["name"]:
                result["name"] = gateio_info.get("name", result["name"])
            
            # 添加Gate.io特有的信息
            result["gateio_data"] = {
                "delisted": gateio_info.get("delisted", False),
                "withdraw_disabled": gateio_info.get("withdraw_disabled", False),
                "withdraw_delayed": gateio_info.get("withdraw_delayed", False),
                "deposit_disabled": gateio_info.get("deposit_disabled", False)
            }
        
        # 更新缓存
        self.cache[cache_key] = result
        self.cache_expiry[cache_key] = time.time()
        
        return result


class DeepAnalyzer:
    """深度分析类，负责分析异动可能的原因"""
    
    def __init__(self):
        """初始化深度分析器"""
        self.news_analyzer = NewsAnalyzer()
        self.social_analyzer = SocialMediaAnalyzer()
        self.coin_info_fetcher = CoinInfoFetcher()
        self.cache = {}
        self.cache_expiry = {}
        self.cache_duration = 1800  # 缓存有效期（秒）
        
        logger.info("深度分析模块初始化完成")
    
    def analyze_possible_reasons(self, symbol: str, anomaly_data: Dict) -> Dict:
        """
        分析异动可能的原因
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            anomaly_data: 异常数据
            
        Returns:
            分析结果
        """
        # 检查缓存
        cache_key = f"analysis_{symbol}_{anomaly_data.get('type')}_{int(time.time() / 1800)}"  # 每30分钟更新一次
        if cache_key in self.cache:
            logger.info(f"从缓存获取{symbol}的异动分析")
            return self.cache[cache_key]
        
        logger.info(f"分析{symbol}的异动可能原因")
        
        # 获取新闻
        news = self.news_analyzer.get_coin_news(symbol)
        
        # 分析新闻情感
        news_sentiment = self.news_analyzer.analyze_news_sentiment(news)
        
        # 分析社交媒体
        social_analysis = self.social_analyzer.analyze_social_media(symbol)
        
        # 获取币种信息
        coin_info = self.coin_info_fetcher.get_coin_info(symbol)
        
        # 分析异动类型
        anomaly_type = anomaly_data.get("type", "unknown")
        
        # 分析价格变化方向
        if anomaly_type == "price":
            price_change_pct = anomaly_data.get("price_change_pct", 0)
            price_direction = "上涨" if price_change_pct > 0 else "下跌"
        else:
            price_direction = "未知"
        
        # 分析可能的原因
        reasons = []
        
        # 基于新闻的原因分析
        if news:
            # 提取最近的新闻标题
            recent_news_titles = [news_item.get("title", "") for news_item in news[:3]]
            
            # 添加新闻相关原因
            if news_sentiment["sentiment"] == "positive" and price_direction == "上涨":
                reasons.append("积极新闻推动价格上涨")
                for title in recent_news_titles:
                    reasons.append(f"相关新闻: {title}")
            elif news_sentiment["sentiment"] == "negative" and price_direction == "下跌":
                reasons.append("负面新闻导致价格下跌")
                for title in recent_news_titles:
                    reasons.append(f"相关新闻: {title}")
            else:
                reasons.append("市场对相关新闻反应")
                for title in recent_news_titles:
                    reasons.append(f"相关新闻: {title}")
        
        # 基于社交媒体的原因分析
        if social_analysis["social_heat"] >= 6:
            if social_analysis["overall_sentiment"] == "positive" and price_direction == "上涨":
                reasons.append("社交媒体上的积极讨论推动价格上涨")
            elif social_analysis["overall_sentiment"] == "negative" and price_direction == "下跌":
                reasons.append("社交媒体上的负面讨论导致价格下跌")
            else:
                reasons.append("社交媒体上的热烈讨论影响价格波动")
        
        # 基于交易量的原因分析
        if anomaly_type == "volume":
            volume_change_pct = anomaly_data.get("volume_change_pct", 0)
            if volume_change_pct > 200:
                reasons.append("交易量大幅增加，可能是大额买入或卖出操作")
            else:
                reasons.append("交易量明显增加，市场关注度提高")
        
        # 如果没有找到明确原因，提供一般性分析
        if not reasons:
            if anomaly_type == "price":
                if price_direction == "上涨":
                    reasons.append("可能是市场情绪改善或技术面突破")
                else:
                    reasons.append("可能是获利了结或技术面支撑失效")
            else:
                reasons.append("可能是市场关注度变化或大户操作")
        
        # 整合分析结果
        result = {
            "symbol": symbol,
            "anomaly_type": anomaly_type,
            "price_direction": price_direction,
            "possible_reasons": reasons,
            "news_sentiment": news_sentiment,
            "social_analysis": social_analysis,
            "recent_news": news[:3] if news else [],
            "coin_info": coin_info
        }
        
        # 更新缓存
        self.cache[cache_key] = result
        
        return result
    
    def format_analysis_message(self, analysis_result: Dict) -> str:
        """
        格式化分析结果为消息
        
        Args:
            analysis_result: 分析结果
            
        Returns:
            格式化后的消息
        """
        symbol = analysis_result.get("symbol", "未知币种")
        anomaly_type = analysis_result.get("anomaly_type", "unknown")
        price_direction = analysis_result.get("price_direction", "未知")
        possible_reasons = analysis_result.get("possible_reasons", [])
        
        # 构建消息标题
        if anomaly_type == "price":
            title = f"📊 {symbol} 价格{price_direction}分析"
        elif anomaly_type == "volume":
            title = f"📈 {symbol} 交易量异动分析"
        else:
            title = f"🔍 {symbol} 异动分析"
        
        # 构建消息内容
        message_parts = [title, ""]
        
        # 添加可能原因
        message_parts.append("📝 可能原因:")
        for reason in possible_reasons:
            message_parts.append(f"- {reason}")
        
        # 添加币种信息
        coin_info = analysis_result.get("coin_info", {})
        if coin_info:
            message_parts.append("")
            message_parts.append("💰 币种信息:")
            
            # 名称和描述
            name = coin_info.get("name", "")
            if name:
                message_parts.append(f"名称: {name}")
            
            # 市场数据
            market_data = coin_info.get("market_data", {})
            if market_data:
                current_price = market_data.get("current_price_usd")
                if current_price:
                    message_parts.append(f"当前价格: ${current_price}")
                
                market_cap = market_data.get("market_cap_usd")
                if market_cap:
                    message_parts.append(f"市值: ${market_cap:,.0f}")
                
                circulating_supply = market_data.get("circulating_supply")
                if circulating_supply:
                    message_parts.append(f"流通量: {circulating_supply:,.0f}")
            
            # 社交数据
            social_data = coin_info.get("social_data", {})
            if social_data:
                twitter_followers = social_data.get("twitter_followers")
                if twitter_followers:
                    message_parts.append(f"Twitter关注者: {twitter_followers:,}")
                
                reddit_subscribers = social_data.get("reddit_subscribers")
                if reddit_subscribers:
                    message_parts.append(f"Reddit订阅者: {reddit_subscribers:,}")
            
            # 链接
            links = coin_info.get("links", {})
            if links:
                message_parts.append("")
                message_parts.append("🔗 相关链接:")
                
                homepage = links.get("homepage")
                if homepage:
                    message_parts.append(f"官网: {homepage}")
                
                twitter = links.get("twitter_screen_name")
                if twitter:
                    message_parts.append(f"Twitter: https://twitter.com/{twitter}")
                
                telegram = links.get("telegram_channel_identifier")
                if telegram:
                    message_parts.append(f"Telegram: https://t.me/{telegram}")
        
        # 合并消息
        return "\n".join(message_parts)


if __name__ == "__main__":
    # 测试代码
    
    # 测试新闻分析
    print("测试新闻分析...")
    news_analyzer = NewsAnalyzer()
    news = news_analyzer.get_coin_news("BTC_USDT", 3)
    print(f"获取到 {len(news)} 条比特币相关新闻")
    for item in news:
        print(f"- {item.get('title')}")
    
    # 测试社交媒体分析
    print("\n测试社交媒体分析...")
    social_analyzer = SocialMediaAnalyzer()
    social_analysis = social_analyzer.analyze_social_media("BTC_USDT")
    print(f"社交媒体热度: {social_analysis.get('social_heat')}/10")
    print(f"总体情感: {social_analysis.get('overall_sentiment')}")
    
    # 测试币种信息获取
    print("\n测试币种信息获取...")
    coin_info_fetcher = CoinInfoFetcher()
    coin_info = coin_info_fetcher.get_coin_info("BTC_USDT")
    print(f"币种名称: {coin_info.get('name')}")
    print(f"市值: ${coin_info.get('market_data', {}).get('market_cap_usd', 0):,.0f}")
    
    # 测试深度分析
    print("\n测试深度分析...")
    deep_analyzer = DeepAnalyzer()
    
    # 模拟异常数据
    anomaly_data = {
        "type": "price",
        "price_change_pct": 15.5
    }
    
    analysis_result = deep_analyzer.analyze_possible_reasons("BTC_USDT", anomaly_data)
    print("可能原因:")
    for reason in analysis_result.get("possible_reasons", []):
        print(f"- {reason}")
    
    # 测试消息格式化
    print("\n测试消息格式化...")
    formatted_message = deep_analyzer.format_analysis_message(analysis_result)
    print(formatted_message)
    
    print("\n测试完成!")
