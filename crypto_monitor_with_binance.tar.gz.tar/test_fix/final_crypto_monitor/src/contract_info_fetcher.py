"""
Gate.io加密货币异动监控系统 - 合约信息获取模块
获取币种的合约交易相关信息，包括资金费率、未平仓合约和多空比
"""

import logging
import requests
import time
from typing import Dict, Any, Optional, List

# 配置日志
logger = logging.getLogger("contract_info_fetcher")

class ContractInfoFetcher:
    """合约信息获取器，用于获取币种的合约交易相关信息"""
    
    def __init__(self, base_url: str = "https://api.gateio.ws/api/v4"):
        """
        初始化合约信息获取器
        
        Args:
            base_url: Gate.io API基础URL
        """
        self.base_url = base_url
        logger.info("合约信息获取模块初始化完成")
    
    def get_contract_info(self, symbol: str) -> Dict[str, Any]:
        """
        获取币种的合约信息
        
        Args:
            symbol: 币种符号，如 BTC_USDT
            
        Returns:
            合约信息字典，包含资金费率、未平仓合约和多空比等
        """
        logger.info(f"获取 {symbol} 的合约信息")
        
        # 初始化结果
        result = {
            "symbol": symbol,
            "funding_rate": None,
            "open_interest": None,
            "long_short_ratio": None,
            "mark_price": None,
            "index_price": None,
            "last_price": None
        }
        
        try:
            # 转换符号格式（如 BTC_USDT -> BTC_USDT）
            contract_symbol = symbol
            
            # 获取合约基本信息
            contract_info = self._get_contract_detail(contract_symbol)
            if contract_info:
                result["mark_price"] = float(contract_info.get("mark_price", 0))
                result["index_price"] = float(contract_info.get("index_price", 0))
                result["last_price"] = float(contract_info.get("last_price", 0))
                result["funding_rate"] = float(contract_info.get("funding_rate", 0)) * 100  # 转换为百分比
            
            # 获取未平仓合约
            open_interest = self._get_open_interest(contract_symbol)
            if open_interest:
                result["open_interest"] = float(open_interest.get("total", 0))
                result["long_short_ratio"] = float(open_interest.get("long_short_ratio", 1))
            
            logger.info(f"成功获取 {symbol} 的合约信息")
            return result
        except Exception as e:
            logger.error(f"获取 {symbol} 的合约信息失败: {str(e)}")
            return result
    
    def _get_contract_detail(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取合约详情
        
        Args:
            symbol: 合约符号
            
        Returns:
            合约详情字典
        """
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取合约详情失败: {str(e)}")
            return None
    
    def _get_open_interest(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取未平仓合约信息
        
        Args:
            symbol: 合约符号
            
        Returns:
            未平仓合约信息字典
        """
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}/open_interest"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取未平仓合约信息失败: {str(e)}")
            return None
    
    def get_funding_history(self, symbol: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        获取资金费率历史
        
        Args:
            symbol: 合约符号
            limit: 返回记录数量限制
            
        Returns:
            资金费率历史列表
        """
        try:
            url = f"{self.base_url}/futures/usdt/funding_rate"
            params = {
                "contract": symbol,
                "limit": limit
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取资金费率历史失败: {str(e)}")
            return []
    
    def get_contract_stats(self, symbol: str) -> Dict[str, Any]:
        """
        获取合约统计信息
        
        Args:
            symbol: 合约符号
            
        Returns:
            合约统计信息字典
        """
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}/stats"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取合约统计信息失败: {str(e)}")
            return {}
    
    def get_top_long_short_accounts(self, symbol: str) -> Dict[str, Any]:
        """
        获取大户多空比例
        
        Args:
            symbol: 合约符号
            
        Returns:
            大户多空比例信息字典
        """
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}/top_long_short_account_ratio"
            params = {
                "period": 5  # 5分钟
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取大户多空比例失败: {str(e)}")
            return {}

# 创建全局实例
contract_info_fetcher = ContractInfoFetcher()

if __name__ == "__main__":
    # 测试代码
    logging.basicConfig(level=logging.INFO)
    
    # 测试获取合约信息
    symbol = "BTC_USDT"
    contract_info = contract_info_fetcher.get_contract_info(symbol)
    print(f"{symbol} 合约信息:")
    print(f"资金费率: {contract_info.get('funding_rate')}%")
    print(f"未平仓合约: {contract_info.get('open_interest')}")
    print(f"多空比: {contract_info.get('long_short_ratio')}")
    
    # 测试获取资金费率历史
    funding_history = contract_info_fetcher.get_funding_history(symbol, 5)
    print(f"\n{symbol} 资金费率历史:")
    for item in funding_history:
        print(f"时间: {item.get('t')}, 费率: {float(item.get('r', 0)) * 100:.6f}%")
