"""
Gate.io加密货币异动监控系统 - 增强版Telegram推送模块（修复版）
支持图表展示、防重复推送和限流处理
"""

import logging
import time
import json
import os
import requests
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import random
import threading
from collections import deque

# 导入时区工具
try:
    from src.timezone_utils import format_time, get_current_time, localize_time, parse_time
    timezone_utils_available = True
except ImportError:
    timezone_utils_available = False

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("enhanced_telegram_alerter")

# 导入图表生成模块
try:
    from src.chart_generator import ChartGenerator
    chart_generator_available = True
except ImportError:
    logger.warning("图表生成模块导入失败，将禁用图表功能")
    chart_generator_available = False

class RateLimiter:
    """API速率限制器，用于控制API请求频率"""
    
    def __init__(self, max_requests: int = 20, time_window: int = 60):
        """
        初始化速率限制器
        
        Args:
            max_requests: 时间窗口内允许的最大请求数
            time_window: 时间窗口大小（秒）
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.request_timestamps = deque()
        self.lock = threading.Lock()
    
    def can_make_request(self) -> bool:
        """
        检查是否可以发送请求
        
        Returns:
            是否可以发送请求
        """
        with self.lock:
            # 清理过期的时间戳
            current_time = time.time()
            while self.request_timestamps and self.request_timestamps[0] < current_time - self.time_window:
                self.request_timestamps.popleft()
            
            # 检查是否超过限制
            return len(self.request_timestamps) < self.max_requests
    
    def record_request(self) -> None:
        """记录一次请求"""
        with self.lock:
            self.request_timestamps.append(time.time())
    
    def wait_if_needed(self) -> float:
        """
        如果需要，等待直到可以发送请求
        
        Returns:
            等待时间（秒）
        """
        with self.lock:
            if not self.request_timestamps:
                return 0
            
            current_time = time.time()
            # 清理过期的时间戳
            while self.request_timestamps and self.request_timestamps[0] < current_time - self.time_window:
                self.request_timestamps.popleft()
            
            # 如果请求数未达到限制，无需等待
            if len(self.request_timestamps) < self.max_requests:
                return 0
            
            # 计算需要等待的时间
            oldest_timestamp = self.request_timestamps[0]
            wait_time = oldest_timestamp + self.time_window - current_time
            
            # 添加一点随机抖动，避免多个客户端同时发送请求
            wait_time += random.uniform(0.1, 1.0)
            
            return max(0, wait_time)

class MessageBatcher:
    """消息批处理器，用于合并多条消息"""
    
    def __init__(self, max_batch_size: int = 5, max_wait_time: int = 10):
        """
        初始化消息批处理器
        
        Args:
            max_batch_size: 最大批处理大小
            max_wait_time: 最大等待时间（秒）
        """
        self.max_batch_size = max_batch_size
        self.max_wait_time = max_wait_time
        self.messages = []
        self.lock = threading.Lock()
        self.last_flush_time = time.time()
        self.timer = None
    
    def add_message(self, message: str) -> None:
        """
        添加消息到批处理队列
        
        Args:
            message: 消息内容
        """
        with self.lock:
            self.messages.append(message)
            
            # 如果这是第一条消息，启动定时器
            if len(self.messages) == 1:
                self.start_timer()
    
    def start_timer(self) -> None:
        """启动定时器"""
        if self.timer:
            self.timer.cancel()
        
        self.timer = threading.Timer(self.max_wait_time, self.flush_due_to_timeout)
        self.timer.daemon = True
        self.timer.start()
    
    def flush_due_to_timeout(self) -> List[str]:
        """
        由于超时而刷新消息队列
        
        Returns:
            消息列表
        """
        with self.lock:
            if self.messages:
                logger.info(f"由于超时刷新消息队列，消息数: {len(self.messages)}")
                self.last_flush_time = time.time()
                messages_to_flush = self.messages.copy()
                self.messages.clear()
                
                # 返回消息以便发送
                return messages_to_flush
            
            return []
    
    def get_batch_if_ready(self) -> List[str]:
        """
        如果批处理就绪，获取消息批次
        
        Returns:
            消息列表，如果未就绪则为空列表
        """
        with self.lock:
            # 如果达到最大批处理大小，刷新队列
            if len(self.messages) >= self.max_batch_size:
                logger.info(f"达到最大批处理大小，刷新消息队列，消息数: {len(self.messages)}")
                self.last_flush_time = time.time()
                
                # 取消定时器
                if self.timer:
                    self.timer.cancel()
                    self.timer = None
                
                messages_to_flush = self.messages.copy()
                self.messages.clear()
                return messages_to_flush
            
            # 如果超过最大等待时间，刷新队列
            current_time = time.time()
            if self.messages and current_time - self.last_flush_time >= self.max_wait_time:
                logger.info(f"超过最大等待时间，刷新消息队列，消息数: {len(self.messages)}")
                self.last_flush_time = current_time
                
                # 取消定时器
                if self.timer:
                    self.timer.cancel()
                    self.timer = None
                
                messages_to_flush = self.messages.copy()
                self.messages.clear()
                return messages_to_flush
            
            return []
    
    def combine_messages(self, messages: List[str]) -> str:
        """
        合并多条消息
        
        Args:
            messages: 消息列表
            
        Returns:
            合并后的消息
        """
        if not messages:
            return ""
        
        if len(messages) == 1:
            return messages[0]
        
        # 添加批处理标题
        combined = f"📊 批量异动警报 ({len(messages)}条)\n\n"
        
        # 添加分隔线和消息内容
        for i, message in enumerate(messages, 1):
            # 移除每条消息中可能的重复标题
            lines = message.split("\n")
            if lines and "异动警报" in lines[0]:
                message = "\n".join(lines[1:])
            
            combined += f"--- 警报 {i} ---\n{message}\n\n"
        
        return combined.strip()

class EnhancedTelegramAlerter:
    """增强版Telegram警报器，支持图表展示、防重复推送和限流处理"""
    
    def __init__(self, config_file: str = "telegram_config.json", dedup_window: int = 3600):
        """
        初始化增强版Telegram警报器
        
        Args:
            config_file: 配置文件路径
            dedup_window: 去重窗口时间（秒）
        """
        self.config_file = config_file
        self.token = None
        self.chat_id = None
        self.dedup_window = dedup_window
        self.alert_history = {}
        
        # 初始化图表生成器
        self.chart_generator = ChartGenerator() if chart_generator_available else None
        
        # 初始化速率限制器（每分钟最多20条消息）
        self.rate_limiter = RateLimiter(max_requests=20, time_window=60)
        
        # 初始化消息批处理器
        self.message_batcher = MessageBatcher(max_batch_size=5, max_wait_time=10)
        
        # 启动消息处理线程
        self.running = True
        self.message_thread = threading.Thread(target=self._message_processing_thread)
        self.message_thread.daemon = True
        self.message_thread.start()
        
        # 加载配置
        self._load_config()
        
        logger.info("增强版Telegram警报器初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载Telegram配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.token = config.get("token")
                    self.chat_id = config.get("chat_id")
                    logger.info("从配置文件加载Telegram配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def save_config(self, token: str, chat_id: str) -> bool:
        """
        保存Telegram配置到配置文件
        
        Args:
            token: Telegram Bot Token
            chat_id: Telegram Chat ID
            
        Returns:
            保存是否成功
        """
        try:
            self.token = token
            self.chat_id = chat_id
            
            with open(self.config_file, 'w') as f:
                json.dump({"token": token, "chat_id": chat_id}, f, indent=4)
            
            logger.info("保存Telegram配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def is_configured(self) -> bool:
        """
        检查Telegram是否已配置
        
        Returns:
            是否已配置
        """
        return self.token is not None and self.chat_id is not None
    
    def test_connection(self) -> bool:
        """
        测试Telegram连接
        
        Returns:
            连接是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法测试连接")
            return False
        
        try:
            url = f"https://api.telegram.org/bot{self.token}/getMe"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get("ok"):
                logger.info(f"Telegram连接测试成功，机器人名称: {data.get('result', {}).get('username')}")
                return True
            else:
                logger.warning(f"Telegram连接测试失败: {data.get('description')}")
                return False
        except Exception as e:
            logger.error(f"Telegram连接测试失败: {str(e)}")
            return False
    
    def _message_processing_thread(self) -> None:
        """消息处理线程，定期检查并发送批处理消息"""
        logger.info("消息处理线程已启动")
        
        while self.running:
            try:
                # 检查是否有就绪的批次
                batch = self.message_batcher.get_batch_if_ready()
                if batch:
                    logger.info(f"发现就绪批次，消息数: {len(batch)}")
                    combined_message = self.message_batcher.combine_messages(batch)
                    self._send_message_with_rate_limit(combined_message)
                
                # 检查定时器触发的批次
                batch = self.message_batcher.flush_due_to_timeout()
                if batch:
                    logger.info(f"定时器触发批次，消息数: {len(batch)}")
                    combined_message = self.message_batcher.combine_messages(batch)
                    self._send_message_with_rate_limit(combined_message)
                
                # 短暂休眠，避免CPU占用过高
                time.sleep(1)
            except Exception as e:
                logger.error(f"消息处理线程异常: {str(e)}")
                time.sleep(5)  # 出错后等待一段时间再继续
    
    def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram消息
        
        Args:
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送消息")
            return False
        
        # 添加到批处理队列
        logger.info(f"添加消息到批处理队列: {text[:50]}...")
        self.message_batcher.add_message(text)
        return True
    
    def _send_message_with_rate_limit(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram消息（带速率限制）
        
        Args:
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送消息")
            return False
        
        # 检查速率限制
        wait_time = self.rate_limiter.wait_if_needed()
        if wait_time > 0:
            logger.info(f"达到速率限制，等待 {wait_time:.2f} 秒")
            time.sleep(wait_time)
        
        # 记录请求
        self.rate_limiter.record_request()
        
        # 发送消息
        return self._send_message_with_retry(text, parse_mode)
    
    def _send_message_with_retry(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram消息（带重试）
        
        Args:
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送消息")
            return False
        
        logger.info(f"准备发送Telegram消息: {text[:50]}...")
        
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        data = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": parse_mode
        }
        
        max_retries = 5
        base_delay = 5  # 初始延迟5秒
        
        for attempt in range(max_retries):
            try:
                logger.info(f"发送Telegram消息，尝试 {attempt+1}/{max_retries}")
                response = requests.post(url, data=data, timeout=30)
                response.raise_for_status()
                logger.info("Telegram消息发送成功")
                return True
            except requests.exceptions.RequestException as e:
                # 计算指数退避延迟
                delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                
                # 如果是429错误（Too Many Requests），从响应中获取推荐的等待时间
                if hasattr(e, 'response') and e.response is not None and e.response.status_code == 429:
                    try:
                        retry_after = e.response.json().get('parameters', {}).get('retry_after', delay)
                        delay = max(delay, retry_after + random.uniform(1, 3))
                    except:
                        pass
                
                logger.warning(f"Telegram消息发送失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                
                if attempt < max_retries - 1:
                    logger.info(f"等待 {delay:.2f} 秒后重试...")
                    time.sleep(delay)
                else:
                    logger.error(f"Telegram消息发送最终失败: {str(e)}")
                    return False
    
    def send_photo(self, photo_path: str, caption: str = None, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram图片
        
        Args:
            photo_path: 图片文件路径
            caption: 图片说明
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送图片")
            return False
        
        # 检查速率限制
        wait_time = self.rate_limiter.wait_if_needed()
        if wait_time > 0:
            logger.info(f"达到速率限制，等待 {wait_time:.2f} 秒")
            time.sleep(wait_time)
        
        # 记录请求
        self.rate_limiter.record_request()
        
        # 发送图片
        return self._send_photo_with_retry(photo_path, caption, parse_mode)
    
    def _send_photo_with_retry(self, photo_path: str, caption: str = None, parse_mode: str = "HTML") -> bool:
        """
        发送Telegram图片（带重试）
        
        Args:
            photo_path: 图片文件路径
            caption: 图片说明
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.warning("Telegram未配置，无法发送图片")
            return False
        
        if not os.path.exists(photo_path):
            logger.warning(f"图片文件不存在: {photo_path}")
            return False
        
        logger.info(f"准备发送Telegram图片: {photo_path}")
        
        url = f"https://api.telegram.org/bot{self.token}/sendPhoto"
        data = {
            "chat_id": self.chat_id
        }
        
        if caption:
            data["caption"] = caption
            data["parse_mode"] = parse_mode
        
        max_retries = 5
        base_delay = 5  # 初始延迟5秒
        
        for attempt in range(max_retries):
            try:
                logger.info(f"发送Telegram图片，尝试 {attempt+1}/{max_retries}")
                with open(photo_path, 'rb') as photo:
                    files = {'photo': photo}
                    response = requests.post(url, data=data, files=files, timeout=60)
                    response.raise_for_status()
                
                logger.info("Telegram图片发送成功")
                return True
            except requests.exceptions.RequestException as e:
                # 计算指数退避延迟
                delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                
                # 如果是429错误（Too Many Requests），从响应中获取推荐的等待时间
                if hasattr(e, 'response') and e.response is not None and e.response.status_code == 429:
                    try:
                        retry_after = e.response.json().get('parameters', {}).get('retry_after', delay)
                        delay = max(delay, retry_after + random.uniform(1, 3))
                    except:
                        pass
                
                logger.warning(f"Telegram图片发送失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                
                if attempt < max_retries - 1:
                    logger.info(f"等待 {delay:.2f} 秒后重试...")
                    time.sleep(delay)
                else:
                    logger.error(f"Telegram图片发送最终失败: {str(e)}")
                    return False
    
    def is_duplicate_alert(self, anomaly: Dict) -> bool:
        """
        检查是否为重复警报
        
        Args:
            anomaly: 异常数据
            
        Returns:
            是否为重复警报
        """
        # 提取关键信息
        symbol = anomaly.get("symbol", "")
        anomaly_type = anomaly.get("type", "")
        
        # 构建唯一标识
        key = f"{symbol}_{anomaly_type}"
        
        # 获取当前时间
        now = datetime.now() if not timezone_utils_available else get_current_time()
        
        # 检查是否在去重窗口内
        if key in self.alert_history:
            last_alert_time = self.alert_history[key]
            time_diff = (now - last_alert_time).total_seconds()
            
            if time_diff < self.dedup_window:
                logger.info(f"检测到重复警报: {key}，距上次警报 {time_diff:.2f} 秒")
                return True
        
        # 更新警报历史
        self.alert_history[key] = now
        
        # 清理过期的警报历史
        self._clean_alert_history()
        
        return False
    
    def _clean_alert_history(self) -> None:
        """清理过期的警报历史"""
        now = datetime.now() if not timezone_utils_available else get_current_time()
        keys_to_remove = []
        
        for key, alert_time in self.alert_history.items():
            time_diff = (now - alert_time).total_seconds()
            if time_diff > self.dedup_window:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.alert_history[key]
    
    def format_anomaly_message(self, anomaly: Dict) -> str:
        """
        格式化异常消息
        
        Args:
            anomaly: 异常数据
            
        Returns:
            格式化后的消息
        """
        # 提取信息
        symbol = anomaly.get("symbol", "")
        anomaly_type = anomaly.get("type", "")
        current_price = anomaly.get("current_price", 0)
        reference_price = anomaly.get("reference_price", 0)
        price_change_pct = anomaly.get("price_change_pct", 0)
        volume_24h = anomaly.get("volume_24h", 0)
        detected_at = anomaly.get("detected_at", datetime.now().isoformat())
        
        # 尝试解析时间
        try:
            if timezone_utils_available:
                # 使用时区工具解析时间
                if isinstance(detected_at, str):
                    detected_time = parse_time(detected_at)
                    time_str = format_time(detected_time)
                else:
                    time_str = format_time(detected_at)
            else:
                # 不使用时区工具
                if isinstance(detected_at, str):
                    detected_time = datetime.fromisoformat(detected_at)
                    time_str = detected_time.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    time_str = detected_at.strftime("%Y-%m-%d %H:%M:%S")
        except:
            # 如果解析失败，使用当前时间
            if timezone_utils_available:
                time_str = format_time()
            else:
                time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 构建消息
        if anomaly_type == "price":
            # 价格异常
            direction = "上涨" if price_change_pct > 0 else "下跌"
            message = f"🚨 价格异动警报 🚨\n\n"
            message += f"币种: {symbol}\n"
            message += f"当前价格: {current_price:.8f}\n"
            message += f"参考价格: {reference_price:.8f}\n"
            message += f"变化幅度: {abs(price_change_pct):.2f}% ({direction})\n"
            message += f"24小时交易量: {volume_24h:.2f}\n"
            message += f"检测时间: {time_str}"
        elif anomaly_type == "volume":
            # 交易量异常
            message = f"🚨 交易量异动警报 🚨\n\n"
            message += f"币种: {symbol}\n"
            message += f"当前价格: {current_price:.8f}\n"
            message += f"24小时交易量: {volume_24h:.2f}\n"
            message += f"交易量异常增加\n"
            message += f"检测时间: {time_str}"
        else:
            # 其他异常
            message = f"🚨 异动警报 🚨\n\n"
            message += f"币种: {symbol}\n"
            message += f"当前价格: {current_price:.8f}\n"
            message += f"24小时交易量: {volume_24h:.2f}\n"
            message += f"检测时间: {time_str}"
        
        return message
    
    def send_anomaly_alert(self, anomaly: Dict) -> bool:
        """
        发送异常警报
        
        Args:
            anomaly: 异常数据
            
        Returns:
            发送是否成功
        """
        # 检查是否为重复警报
        if self.is_duplicate_alert(anomaly):
            return False
        
        # 格式化消息
        message = self.format_anomaly_message(anomaly)
        
        # 发送消息
        return self.send_message(message)
    
    def send_anomaly_alert_with_chart(self, anomaly: Dict, price_data: List[Dict] = None) -> bool:
        """
        发送带图表的异常警报
        
        Args:
            anomaly: 异常数据
            price_data: 价格历史数据
            
        Returns:
            发送是否成功
        """
        # 检查是否为重复警报
        if self.is_duplicate_alert(anomaly):
            return False
        
        # 检查图表生成器是否可用
        if not self.chart_generator or not price_data:
            # 如果图表生成器不可用或没有价格数据，退回到普通警报
            return self.send_anomaly_alert(anomaly)
        
        try:
            # 提取信息
            symbol = anomaly.get("symbol", "")
            anomaly_type = anomaly.get("type", "")
            
            # 生成图表
            chart_path = self.chart_generator.generate_price_chart(
                symbol=symbol,
                price_data=price_data,
                highlight_anomaly=True,
                anomaly_type=anomaly_type
            )
            
            if not chart_path or not os.path.exists(chart_path):
                # 如果图表生成失败，退回到普通警报
                logger.warning(f"图表生成失败，退回到普通警报")
                return self.send_anomaly_alert(anomaly)
            
            # 格式化消息
            caption = self.format_anomaly_message(anomaly)
            
            # 发送图片
            result = self.send_photo(chart_path, caption)
            
            # 清理临时文件
            try:
                os.remove(chart_path)
            except:
                pass
            
            return result
        except Exception as e:
            logger.error(f"发送带图表的异常警报失败: {str(e)}")
            # 退回到普通警报
            return self.send_anomaly_alert(anomaly)
    
    def shutdown(self):
        """关闭警报器，停止所有线程"""
        logger.info("关闭增强版Telegram警报器")
        self.running = False
        if self.message_thread.is_alive():
            self.message_thread.join(timeout=5)

# 回调函数，用于集成到异常监控器
def enhanced_telegram_alert_callback(anomalies: List[Dict]) -> None:
    """
    增强版Telegram警报回调函数
    
    Args:
        anomalies: 异常数据列表
    """
    if not anomalies:
        return
    
    try:
        # 创建警报器
        alerter = EnhancedTelegramAlerter()
        
        # 发送警报
        for anomaly in anomalies:
            alerter.send_anomaly_alert(anomaly)
    except Exception as e:
        logger.error(f"Telegram警报回调失败: {str(e)}")


if __name__ == "__main__":
    # 测试代码
    
    # 创建警报器
    alerter = EnhancedTelegramAlerter()
    
    # 检查是否已配置
    if not alerter.is_configured():
        print("Telegram未配置，请先配置")
        token = input("请输入Telegram Bot Token: ")
        chat_id = input("请输入Chat ID: ")
        alerter.save_config(token, chat_id)
    
    # 测试连接
    print("\n测试Telegram连接...")
    if alerter.test_connection():
        print("连接测试成功!")
        
        # 发送测试消息
        print("\n发送测试消息...")
        test_message = "这是一条测试消息，来自Gate.io加密货币异动监控系统。"
        if alerter.send_message(test_message):
            print("测试消息已加入队列!")
            
            # 等待消息发送
            print("等待消息发送...")
            time.sleep(15)
            print("测试完成!")
        else:
            print("测试消息加入队列失败!")
    else:
        print("连接测试失败，请检查Token和Chat ID是否正确。")
    
    # 关闭警报器
    alerter.shutdown()
