"""
Gate.io和币安加密货币异动监控系统 - 交易所管理器
负责管理多个交易所实例，实现负载均衡和数据合并
"""

import logging
import time
import random
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

# 配置日志
logger = logging.getLogger("exchange_manager")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

class ExchangeManager:
    """
    交易所管理器，负责管理多个交易所实例，实现负载均衡和数据合并
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化交易所管理器
        
        Args:
            config: 配置字典，包含负载均衡策略等
        """
        self.config = config or {}
        self.exchanges = {}  # 交易所实例字典
        self.weights = {}    # 交易所权重字典
        self.last_used = {}  # 交易所上次使用时间
        self.cache = {}      # 数据缓存
        self.cache_time = {} # 缓存时间
        
        # 负载均衡配置
        self.load_balancing = self.config.get("load_balancing", {})
        self.strategy = self.load_balancing.get("strategy", "response_time")
        self.health_check_interval = self.load_balancing.get("health_check_interval", 60)
        self.min_health_score = self.load_balancing.get("min_health_score", 50)
        self.auto_adjust_weights = self.load_balancing.get("auto_adjust_weights", True)
        
        # 数据标准化配置
        self.data_standardization = self.config.get("data_standardization", {})
        self.symbol_format = self.data_standardization.get("symbol_format", "gateio")
        self.merge_strategy = self.data_standardization.get("merge_strategy", "prefer_higher_volume")
        
        # 上次权重更新时间
        self.last_weight_update = time.time()
        
        logger.info("交易所管理器初始化完成")
    
    def register_exchange(self, exchange, weight: float = 1.0) -> None:
        """
        注册交易所实例
        
        Args:
            exchange: 实现了ExchangeInterface的交易所实例
            weight: 初始权重
        """
        exchange_name = exchange.exchange_name
        self.exchanges[exchange_name] = exchange
        self.weights[exchange_name] = weight
        self.last_used[exchange_name] = 0
        
        logger.info(f"注册交易所: {exchange_name}, 初始权重: {weight}")
    
    def _select_exchange(self, required_exchanges: List[str] = None) -> str:
        """
        根据负载均衡策略选择交易所
        
        Args:
            required_exchanges: 必须从中选择的交易所列表
            
        Returns:
            选中的交易所名称
        """
        # 如果指定了必须使用的交易所，则从中选择
        available_exchanges = required_exchanges if required_exchanges else list(self.exchanges.keys())
        
        # 如果没有可用交易所，返回None
        if not available_exchanges:
            return None
        
        # 如果只有一个交易所，直接返回
        if len(available_exchanges) == 1:
            return available_exchanges[0]
        
        # 根据策略选择交易所
        if self.strategy == "round_robin":
            # 轮询策略：选择上次使用时间最早的交易所
            return min(available_exchanges, key=lambda x: self.last_used.get(x, 0))
        
        elif self.strategy == "weighted_random":
            # 加权随机策略：根据权重随机选择
            total_weight = sum(self.weights[e] for e in available_exchanges)
            r = random.uniform(0, total_weight)
            upto = 0
            for e in available_exchanges:
                upto += self.weights[e]
                if upto >= r:
                    return e
            return available_exchanges[-1]
        
        elif self.strategy == "health_score":
            # 健康度评分策略：选择健康度最高的交易所
            return max(available_exchanges, key=lambda x: self.exchanges[x].health_score)
        
        else:
            # 默认响应时间策略：选择权重最高的交易所
            return max(available_exchanges, key=lambda x: self.weights.get(x, 0))
    
    def _update_weights(self) -> None:
        """更新交易所权重"""
        # 检查是否需要更新权重
        current_time = time.time()
        if current_time - self.last_weight_update < self.health_check_interval:
            return
        
        # 更新权重
        if self.auto_adjust_weights:
            for name, exchange in self.exchanges.items():
                metrics = exchange.get_health_metrics()
                
                # 根据健康度评分调整权重
                health_score = metrics["health_score"]
                avg_response_time = metrics["avg_response_time"]
                
                if health_score < self.min_health_score:
                    # 健康度过低，大幅降低权重
                    self.weights[name] = max(0.1, self.weights[name] * 0.5)
                else:
                    # 根据响应时间调整权重
                    if avg_response_time > 0:
                        # 响应时间越短，权重越高
                        self.weights[name] = 10.0 / (1.0 + avg_response_time * 5)
            
            logger.info(f"更新交易所权重: {self.weights}")
        
        self.last_weight_update = current_time
    
    def fetch_all_tickers(self) -> List[Dict]:
        """
        获取所有币种的ticker数据
        
        Returns:
            标准化的ticker数据列表
        """
        # 更新权重
        self._update_weights()
        
        # 选择交易所
        exchange_name = self._select_exchange()
        if not exchange_name:
            logger.error("没有可用的交易所")
            return []
        
        # 获取数据
        exchange = self.exchanges[exchange_name]
        try:
            start_time = time.time()
            tickers = exchange.fetch_all_tickers()
            response_time = time.time() - start_time
            
            # 更新健康度
            exchange.update_health_score(response_time, True)
            
            # 更新最后使用时间
            self.last_used[exchange_name] = time.time()
            
            logger.info(f"从{exchange_name}获取了{len(tickers)}个ticker数据")
            return tickers
        
        except Exception as e:
            # 更新健康度
            exchange.update_health_score(10.0, False)
            
            logger.error(f"从{exchange_name}获取ticker数据失败: {str(e)}")
            
            # 尝试使用其他交易所
            for name, ex in self.exchanges.items():
                if name != exchange_name:
                    try:
                        start_time = time.time()
                        tickers = ex.fetch_all_tickers()
                        response_time = time.time() - start_time
                        
                        # 更新健康度
                        ex.update_health_score(response_time, True)
                        
                        # 更新最后使用时间
                        self.last_used[name] = time.time()
                        
                        logger.info(f"从{name}获取了{len(tickers)}个ticker数据")
                        return tickers
                    except:
                        ex.update_health_score(10.0, False)
            
            return []
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict]:
        """
        获取特定币种的ticker数据
        
        Args:
            symbol: 标准化的币种符号（如"BTC_USDT"）
            
        Returns:
            标准化的ticker数据
        """
        # 检查缓存
        cache_key = f"ticker_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_time.get(cache_key, 0) < 60:
            return self.cache[cache_key]
        
        # 更新权重
        self._update_weights()
        
        # 选择交易所
        exchange_name = self._select_exchange()
        if not exchange_name:
            logger.error("没有可用的交易所")
            return None
        
        # 获取数据
        exchange = self.exchanges[exchange_name]
        try:
            start_time = time.time()
            ticker = exchange.fetch_ticker(symbol)
            response_time = time.time() - start_time
            
            # 更新健康度
            exchange.update_health_score(response_time, True)
            
            # 更新最后使用时间
            self.last_used[exchange_name] = time.time()
            
            # 更新缓存
            if ticker:
                self.cache[cache_key] = ticker
                self.cache_time[cache_key] = time.time()
            
            logger.info(f"从{exchange_name}获取了{symbol}的ticker数据")
            return ticker
        
        except Exception as e:
            # 更新健康度
            exchange.update_health_score(10.0, False)
            
            logger.warning(f"从{exchange_name}获取{symbol}的ticker数据失败: {str(e)}")
            
            # 尝试使用其他交易所
            for name, ex in self.exchanges.items():
                if name != exchange_name:
                    try:
                        start_time = time.time()
                        ticker = ex.fetch_ticker(symbol)
                        response_time = time.time() - start_time
                        
                        # 更新健康度
                        ex.update_health_score(response_time, True)
                        
                        # 更新最后使用时间
                        self.last_used[name] = time.time()
                        
                        # 更新缓存
                        if ticker:
                            self.cache[cache_key] = ticker
                            self.cache_time[cache_key] = time.time()
                        
                        logger.info(f"从{name}获取了{symbol}的ticker数据")
                        return ticker
                    except:
                        ex.update_health_score(10.0, False)
            
            return None
    
    def fetch_historical_data(self, symbol: str, interval: str, limit: int) -> List[Dict]:
        """
        获取历史K线数据
        
        Args:
            symbol: 标准化的币种符号（如"BTC_USDT"）
            interval: 时间间隔（如"1h", "1d"）
            limit: 获取数量限制
            
        Returns:
            标准化的历史数据列表
        """
        # 检查缓存
        cache_key = f"history_{symbol}_{interval}_{limit}"
        if cache_key in self.cache and time.time() - self.cache_time.get(cache_key, 0) < 300:
            return self.cache[cache_key]
        
        # 更新权重
        self._update_weights()
        
        # 选择交易所
        exchange_name = self._select_exchange()
        if not exchange_name:
            logger.error("没有可用的交易所")
            return []
        
        # 获取数据
        exchange = self.exchanges[exchange_name]
        try:
            start_time = time.time()
            data = exchange.fetch_historical_data(symbol, interval, limit)
            response_time = time.time() - start_time
            
            # 更新健康度
            exchange.update_health_score(response_time, True)
            
            # 更新最后使用时间
            self.last_used[exchange_name] = time.time()
            
            # 更新缓存
            if data:
                self.cache[cache_key] = data
                self.cache_time[cache_key] = time.time()
            
            logger.info(f"从{exchange_name}获取了{symbol}的{len(data)}条历史数据")
            return data
        
        except Exception as e:
            # 更新健康度
            exchange.update_health_score(10.0, False)
            
            logger.warning(f"从{exchange_name}获取{symbol}的历史数据失败: {str(e)}")
            
            # 尝试使用其他交易所
            for name, ex in self.exchanges.items():
                if name != exchange_name:
                    try:
                        start_time = time.time()
                        data = ex.fetch_historical_data(symbol, interval, limit)
                        response_time = time.time() - start_time
                        
                        # 更新健康度
                        ex.update_health_score(response_time, True)
                        
                        # 更新最后使用时间
                        self.last_used[name] = time.time()
                        
                        # 更新缓存
                        if data:
                            self.cache[cache_key] = data
                            self.cache_time[cache_key] = time.time()
                        
                        logger.info(f"从{name}获取了{symbol}的{len(data)}条历史数据")
                        return data
                    except:
                        ex.update_health_score(10.0, False)
            
            return []
    
    def get_exchange_stats(self) -> Dict[str, Dict]:
        """
        获取所有交易所的统计信息
        
        Returns:
            交易所统计信息字典
        """
        stats = {}
        for name, exchange in self.exchanges.items():
            stats[name] = {
                "health_metrics": exchange.get_health_metrics(),
                "weight": self.weights.get(name, 0),
                "last_used": self.last_used.get(name, 0)
            }
        return stats
    
    def clear_cache(self) -> None:
        """清除缓存"""
        self.cache = {}
        self.cache_time = {}
