"""
Gate.io和币安加密货币异动监控系统 - 交易所配置管理模块
负责管理多交易所配置和负载均衡策略
"""

import logging
import json
import os
from typing import Dict, Any, Optional

# 配置日志
logger = logging.getLogger("exchange_config")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

class ExchangeConfigManager:
    """交易所配置管理器，负责管理多交易所配置和负载均衡策略"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化配置管理器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # 确保配置中包含必要的部分
        self._ensure_config_structure()
        
        logger.info("交易所配置管理模块初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        从文件加载配置
        
        Returns:
            配置字典
        """
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                logger.info("从配置文件加载交易所配置成功")
                return config
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，使用默认配置")
                return self._get_default_config()
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}，使用默认配置")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        获取默认配置
        
        Returns:
            默认配置字典
        """
        return {
            "check_interval": 60,
            "price_threshold": 5.0,
            "volume_threshold": 100.0,
            "excluded_symbols": ["USDT_USD"],
            "exchanges": {
                "gateio": {
                    "enabled": True,
                    "api_key": "",
                    "api_secret": "",
                    "weight": 1.0
                },
                "binance": {
                    "enabled": False,
                    "api_key": "",
                    "api_secret": "",
                    "weight": 1.0
                }
            },
            "load_balancing": {
                "strategy": "response_time",
                "health_check_interval": 60,
                "min_health_score": 50,
                "auto_adjust_weights": True
            },
            "data_standardization": {
                "symbol_format": "gateio",
                "merge_strategy": "prefer_higher_volume"
            },
            "telegram": {
                "token": "",
                "chat_id": ""
            }
        }
    
    def _ensure_config_structure(self) -> None:
        """确保配置中包含必要的部分"""
        # 确保exchanges部分存在
        if "exchanges" not in self.config:
            self.config["exchanges"] = self._get_default_config()["exchanges"]
        
        # 确保每个交易所配置完整
        for exchange in ["gateio", "binance"]:
            if exchange not in self.config["exchanges"]:
                self.config["exchanges"][exchange] = self._get_default_config()["exchanges"][exchange]
            
            exchange_config = self.config["exchanges"][exchange]
            if "enabled" not in exchange_config:
                exchange_config["enabled"] = exchange == "gateio"  # 默认只启用Gate.io
            if "api_key" not in exchange_config:
                exchange_config["api_key"] = ""
            if "api_secret" not in exchange_config:
                exchange_config["api_secret"] = ""
            if "weight" not in exchange_config:
                exchange_config["weight"] = 1.0
        
        # 确保load_balancing部分存在
        if "load_balancing" not in self.config:
            self.config["load_balancing"] = self._get_default_config()["load_balancing"]
        
        # 确保data_standardization部分存在
        if "data_standardization" not in self.config:
            self.config["data_standardization"] = self._get_default_config()["data_standardization"]
    
    def save_config(self) -> bool:
        """
        保存配置到文件
        
        Returns:
            是否保存成功
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info("保存交易所配置到文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def get_exchange_config(self, exchange_name: str) -> Optional[Dict[str, Any]]:
        """
        获取特定交易所的配置
        
        Args:
            exchange_name: 交易所名称
            
        Returns:
            交易所配置字典
        """
        return self.config.get("exchanges", {}).get(exchange_name)
    
    def update_exchange_config(self, exchange_name: str, config: Dict[str, Any]) -> bool:
        """
        更新特定交易所的配置
        
        Args:
            exchange_name: 交易所名称
            config: 新的配置字典
            
        Returns:
            是否更新成功
        """
        try:
            if "exchanges" not in self.config:
                self.config["exchanges"] = {}
            
            self.config["exchanges"][exchange_name] = config
            logger.info(f"更新交易所 {exchange_name} 配置成功")
            return True
        except Exception as e:
            logger.error(f"更新交易所配置失败: {str(e)}")
            return False
    
    def get_load_balancing_config(self) -> Dict[str, Any]:
        """
        获取负载均衡配置
        
        Returns:
            负载均衡配置字典
        """
        return self.config.get("load_balancing", {})
    
    def update_load_balancing_config(self, config: Dict[str, Any]) -> bool:
        """
        更新负载均衡配置
        
        Args:
            config: 新的配置字典
            
        Returns:
            是否更新成功
        """
        try:
            self.config["load_balancing"] = config
            logger.info("更新负载均衡配置成功")
            return True
        except Exception as e:
            logger.error(f"更新负载均衡配置失败: {str(e)}")
            return False
    
    def get_data_standardization_config(self) -> Dict[str, Any]:
        """
        获取数据标准化配置
        
        Returns:
            数据标准化配置字典
        """
        return self.config.get("data_standardization", {})
    
    def update_data_standardization_config(self, config: Dict[str, Any]) -> bool:
        """
        更新数据标准化配置
        
        Args:
            config: 新的配置字典
            
        Returns:
            是否更新成功
        """
        try:
            self.config["data_standardization"] = config
            logger.info("更新数据标准化配置成功")
            return True
        except Exception as e:
            logger.error(f"更新数据标准化配置失败: {str(e)}")
            return False
