"""
Gate.io和币安加密货币异动监控系统 - 交易所接口抽象层
定义统一的交易所接口，实现多交易所支持和负载均衡
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import time

class ExchangeInterface(ABC):
    """
    交易所接口抽象基类，定义所有交易所实现必须提供的方法
    """
    
    def __init__(self, api_key: str = "", api_secret: str = "", cache_duration: int = 3600):
        """
        初始化交易所接口
        
        Args:
            api_key: API密钥
            api_secret: API密钥
            cache_duration: 缓存有效期（秒）
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.cache_duration = cache_duration
        self.last_request_time = {}
        self.request_counts = {}
        self.response_times = []
        self.error_counts = 0
        self.success_counts = 0
        
        # 健康度指标，满分100
        self.health_score = 100
        
        # 最后更新时间
        self.last_health_check = time.time()
    
    @property
    @abstractmethod
    def exchange_name(self) -> str:
        """获取交易所名称"""
        pass
    
    @property
    @abstractmethod
    def rate_limits(self) -> Dict[str, Any]:
        """获取API速率限制信息"""
        pass
    
    @abstractmethod
    def fetch_all_tickers(self) -> List[Dict]:
        """
        获取所有币种的ticker数据
        
        Returns:
            标准化的ticker数据列表
        """
        pass
    
    @abstractmethod
    def fetch_ticker(self, symbol: str) -> Optional[Dict]:
        """
        获取特定币种的ticker数据
        
        Args:
            symbol: 标准化的币种符号（如"BTC_USDT"）
            
        Returns:
            标准化的ticker数据
        """
        pass
    
    @abstractmethod
    def fetch_historical_data(self, symbol: str, interval: str, limit: int) -> List[Dict]:
        """
        获取历史K线数据
        
        Args:
            symbol: 标准化的币种符号（如"BTC_USDT"）
            interval: 时间间隔（如"1h", "1d"）
            limit: 获取数量限制
            
        Returns:
            标准化的历史数据列表
        """
        pass
    
    @abstractmethod
    def convert_to_standard_symbol(self, exchange_symbol: str) -> str:
        """
        将交易所特定的币种符号转换为标准格式
        
        Args:
            exchange_symbol: 交易所特定的币种符号
            
        Returns:
            标准化的币种符号（如"BTC_USDT"）
        """
        pass
    
    @abstractmethod
    def convert_from_standard_symbol(self, standard_symbol: str) -> str:
        """
        将标准格式的币种符号转换为交易所特定格式
        
        Args:
            standard_symbol: 标准化的币种符号（如"BTC_USDT"）
            
        Returns:
            交易所特定的币种符号
        """
        pass
    
    def update_health_score(self, response_time: float, success: bool) -> None:
        """
        更新交易所健康度评分
        
        Args:
            response_time: API响应时间（秒）
            success: 请求是否成功
        """
        # 记录响应时间
        self.response_times.append(response_time)
        if len(self.response_times) > 100:
            self.response_times = self.response_times[-100:]
        
        # 更新成功/失败计数
        if success:
            self.success_counts += 1
        else:
            self.error_counts += 1
        
        # 限制计数器大小
        max_counts = 1000
        if self.success_counts + self.error_counts > max_counts:
            ratio = self.success_counts / (self.success_counts + self.error_counts)
            self.success_counts = int(ratio * max_counts)
            self.error_counts = max_counts - self.success_counts
        
        # 计算健康度评分
        current_time = time.time()
        if current_time - self.last_health_check >= 60:  # 每分钟更新一次
            self._calculate_health_score()
            self.last_health_check = current_time
    
    def _calculate_health_score(self) -> None:
        """计算健康度评分"""
        # 计算平均响应时间（秒）
        avg_response_time = sum(self.response_times) / len(self.response_times) if self.response_times else 0
        
        # 计算成功率
        total_requests = self.success_counts + self.error_counts
        success_rate = self.success_counts / total_requests if total_requests > 0 else 1.0
        
        # 响应时间评分（0-40分）
        # 响应时间越短越好，超过2秒开始扣分
        time_score = 40
        if avg_response_time > 0.1:
            time_score = max(0, 40 - int((avg_response_time - 0.1) * 20))
        
        # 成功率评分（0-60分）
        success_score = int(success_rate * 60)
        
        # 总评分
        self.health_score = time_score + success_score
    
    def get_health_metrics(self) -> Dict[str, Any]:
        """
        获取健康度指标
        
        Returns:
            健康度指标字典
        """
        avg_response_time = sum(self.response_times) / len(self.response_times) if self.response_times else 0
        total_requests = self.success_counts + self.error_counts
        success_rate = self.success_counts / total_requests if total_requests > 0 else 1.0
        
        return {
            "exchange": self.exchange_name,
            "health_score": self.health_score,
            "avg_response_time": avg_response_time,
            "success_rate": success_rate,
            "total_requests": total_requests,
            "last_check": self.last_health_check
        }
    
    def standardize_ticker_data(self, raw_ticker: Dict) -> Dict:
        """
        将原始ticker数据标准化为统一格式
        
        Args:
            raw_ticker: 原始ticker数据
            
        Returns:
            标准化的ticker数据
        """
        # 子类应该重写此方法以实现特定的标准化逻辑
        return raw_ticker
