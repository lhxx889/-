"""
Gate.io和币安加密货币异动监控系统 - 币安数据采集模块
负责从币安API获取数据并进行标准化处理
"""

import logging
import time
import json
import requests
import hmac
import hashlib
from typing import Dict, List, Any, Optional
from datetime import datetime
import urllib.parse

# 导入交易所接口
from src.exchanges.exchange_interface import ExchangeInterface

# 配置日志
logger = logging.getLogger("binance_collector")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

class BinanceDataCollector(ExchangeInterface):
    """币安数据采集模块，实现交易所接口"""
    
    def __init__(self, api_key: str = "", api_secret: str = "", cache_duration: int = 300):
        """
        初始化币安数据采集器
        
        Args:
            api_key: API密钥
            api_secret: API密钥
            cache_duration: 缓存有效期（秒）
        """
        super().__init__(api_key, api_secret, cache_duration)
        
        self.base_url = "https://api.binance.com"
        self.cache = {}
        self.cache_time = {}
        
        # 币种信息缓存
        self.symbols_info = {}
        self._init_symbols_info()
        
        logger.info("币安数据采集模块初始化完成")
    
    @property
    def exchange_name(self) -> str:
        """获取交易所名称"""
        return "Binance"
    
    @property
    def rate_limits(self) -> Dict[str, Any]:
        """获取API速率限制信息"""
        return {
            "weight_per_minute": 1200,
            "orders_per_second": 10,
            "orders_per_day": 100000
        }
    
    def _init_symbols_info(self) -> None:
        """初始化币种信息"""
        try:
            # 获取交易所信息
            exchange_info = self._make_request("/api/v3/exchangeInfo")
            
            # 解析币种信息
            if exchange_info and "symbols" in exchange_info:
                for symbol_info in exchange_info["symbols"]:
                    symbol = symbol_info["symbol"]
                    base_asset = symbol_info["baseAsset"]
                    quote_asset = symbol_info["quoteAsset"]
                    
                    # 保存币种信息
                    self.symbols_info[symbol] = {
                        "baseAsset": base_asset,
                        "quoteAsset": quote_asset,
                        "standard_symbol": f"{base_asset}_{quote_asset}"
                    }
                
                logger.info(f"初始化币种信息成功，共{len(self.symbols_info)}个币种")
            else:
                logger.warning("初始化币种信息失败，无法获取交易所信息")
        except Exception as e:
            logger.warning(f"初始化币种信息失败，无法获取交易所信息: {str(e)}")
    
    def _make_request(self, endpoint: str, params: Dict = None, signed: bool = False) -> Any:
        """
        发送请求到币安API
        
        Args:
            endpoint: API端点
            params: 请求参数
            signed: 是否需要签名
            
        Returns:
            API响应数据
        """
        url = self.base_url + endpoint
        headers = {"X-MBX-APIKEY": self.api_key} if self.api_key else {}
        
        # 添加时间戳和签名
        if signed and self.api_key and self.api_secret:
            if params is None:
                params = {}
            
            params["timestamp"] = int(time.time() * 1000)
            query_string = urllib.parse.urlencode(params)
            signature = hmac.new(
                self.api_secret.encode("utf-8"),
                query_string.encode("utf-8"),
                hashlib.sha256
            ).hexdigest()
            params["signature"] = signature
        
        # 发送请求
        try:
            response = requests.get(url, params=params, headers=headers, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"请求币安API失败: {str(e)}")
            return None
    
    def convert_to_standard_symbol(self, exchange_symbol: str) -> str:
        """
        将币安特定的币种符号转换为标准格式
        
        Args:
            exchange_symbol: 币安特定的币种符号（如"BTCUSDT"）
            
        Returns:
            标准化的币种符号（如"BTC_USDT"）
        """
        # 检查缓存
        if exchange_symbol in self.symbols_info:
            return self.symbols_info[exchange_symbol]["standard_symbol"]
        
        # 尝试解析
        for base in ["BTC", "ETH", "BNB", "USDT", "BUSD", "USDC"]:
            if exchange_symbol.endswith(base):
                quote = exchange_symbol[:-len(base)]
                return f"{quote}_{base}"
        
        # 默认处理
        if "USDT" in exchange_symbol:
            parts = exchange_symbol.split("USDT")
            return f"{parts[0]}_USDT"
        
        return exchange_symbol
    
    def convert_from_standard_symbol(self, standard_symbol: str) -> str:
        """
        将标准格式的币种符号转换为币安特定格式
        
        Args:
            standard_symbol: 标准化的币种符号（如"BTC_USDT"）
            
        Returns:
            币安特定的币种符号（如"BTCUSDT"）
        """
        # 查找匹配的币种
        for symbol, info in self.symbols_info.items():
            if info["standard_symbol"] == standard_symbol:
                return symbol
        
        # 默认处理
        if "_" in standard_symbol:
            parts = standard_symbol.split("_")
            return f"{parts[0]}{parts[1]}"
        
        return standard_symbol
    
    def standardize_ticker_data(self, raw_ticker: Dict) -> Dict:
        """
        将币安原始ticker数据标准化为统一格式
        
        Args:
            raw_ticker: 币安原始ticker数据
            
        Returns:
            标准化的ticker数据
        """
        try:
            symbol = raw_ticker.get("symbol", "")
            standard_symbol = self.convert_to_standard_symbol(symbol)
            
            return {
                "symbol": standard_symbol,
                "exchange": self.exchange_name,
                "price": float(raw_ticker.get("lastPrice", 0)),
                "volume_24h": float(raw_ticker.get("volume", 0)),
                "change_24h": float(raw_ticker.get("priceChange", 0)),
                "change_percentage_24h": float(raw_ticker.get("priceChangePercent", 0)),
                "high_24h": float(raw_ticker.get("highPrice", 0)),
                "low_24h": float(raw_ticker.get("lowPrice", 0)),
                "timestamp": int(time.time() * 1000),
                "raw_data": raw_ticker
            }
        except Exception as e:
            logger.error(f"标准化ticker数据时出错: {str(e)}")
            return {}
    
    def standardize_historical_data(self, raw_data: List, symbol: str) -> List[Dict]:
        """
        将币安原始历史数据标准化为统一格式
        
        Args:
            raw_data: 币安原始历史数据
            symbol: 币种符号
            
        Returns:
            标准化的历史数据列表
        """
        standard_data = []
        
        try:
            standard_symbol = self.convert_to_standard_symbol(symbol) if not "_" in symbol else symbol
            
            for item in raw_data:
                # 币安K线数据格式：
                # [开盘时间, 开盘价, 最高价, 最低价, 收盘价, 成交量, 收盘时间, 成交额, 成交笔数, 主动买入成交量, 主动买入成交额, 忽略]
                standard_item = {
                    "symbol": standard_symbol,
                    "exchange": self.exchange_name,
                    "timestamp": item[0],
                    "datetime": datetime.fromtimestamp(item[0] / 1000).isoformat(),
                    "open": float(item[1]),
                    "high": float(item[2]),
                    "low": float(item[3]),
                    "close": float(item[4]),
                    "volume": float(item[5]),
                    "trades": item[8],
                    "raw_data": item
                }
                standard_data.append(standard_item)
            
            return standard_data
        except Exception as e:
            logger.error(f"标准化历史数据时出错: {str(e)}")
            return []
    
    def fetch_all_tickers(self) -> List[Dict]:
        """
        获取所有币种的ticker数据
        
        Returns:
            标准化的ticker数据列表
        """
        # 检查缓存
        cache_key = "all_tickers"
        if cache_key in self.cache and time.time() - self.cache_time.get(cache_key, 0) < self.cache_duration:
            return self.cache[cache_key]
        
        logger.info("获取所有币种ticker数据")
        
        # 获取数据
        raw_tickers = self._make_request("/api/v3/ticker/24hr")
        
        if not raw_tickers:
            logger.error("获取ticker数据失败")
            return []
        
        # 标准化数据
        standard_tickers = []
        for raw_ticker in raw_tickers:
            standard_ticker = self.standardize_ticker_data(raw_ticker)
            if standard_ticker:
                standard_tickers.append(standard_ticker)
        
        # 更新缓存
        self.cache[cache_key] = standard_tickers
        self.cache_time[cache_key] = time.time()
        
        logger.info(f"成功获取{len(standard_tickers)}个币种的ticker数据")
        return standard_tickers
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict]:
        """
        获取特定币种的ticker数据
        
        Args:
            symbol: 标准化的币种符号（如"BTC_USDT"）
            
        Returns:
            标准化的ticker数据
        """
        # 检查缓存
        cache_key = f"ticker_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_time.get(cache_key, 0) < self.cache_duration:
            logger.info(f"使用缓存的{symbol}ticker数据")
            return self.cache[cache_key]
        
        logger.info(f"获取{symbol}的ticker数据")
        
        # 转换为币安格式
        binance_symbol = self.convert_from_standard_symbol(symbol)
        
        # 获取数据
        raw_ticker = self._make_request("/api/v3/ticker/24hr", {"symbol": binance_symbol})
        
        if not raw_ticker:
            logger.error(f"获取{symbol}的ticker数据失败")
            return None
        
        try:
            # 标准化数据
            standard_ticker = self.standardize_ticker_data(raw_ticker)
            
            # 更新缓存
            if standard_ticker:
                self.cache[cache_key] = standard_ticker
                self.cache_time[cache_key] = time.time()
            
            logger.info(f"成功获取{symbol}的ticker数据")
            return standard_ticker
        except Exception as e:
            logger.error(f"标准化{symbol}的ticker数据时出错: {str(e)}")
            return None
    
    def fetch_historical_data(self, symbol: str, interval: str, limit: int) -> List[Dict]:
        """
        获取历史K线数据
        
        Args:
            symbol: 标准化的币种符号（如"BTC_USDT"）
            interval: 时间间隔（如"1h", "1d"）
            limit: 获取数量限制
            
        Returns:
            标准化的历史数据列表
        """
        # 检查缓存
        cache_key = f"history_{symbol}_{interval}_{limit}"
        if cache_key in self.cache and time.time() - self.cache_time.get(cache_key, 0) < self.cache_duration:
            return self.cache[cache_key]
        
        logger.info(f"获取{symbol}的历史数据，间隔:{interval}，数量:{limit}")
        
        # 转换为币安格式
        binance_symbol = self.convert_from_standard_symbol(symbol)
        
        # 转换时间间隔
        interval_map = {
            "1m": "1m",
            "5m": "5m",
            "15m": "15m",
            "30m": "30m",
            "1h": "1h",
            "4h": "4h",
            "1d": "1d",
            "1w": "1w"
        }
        binance_interval = interval_map.get(interval, "1h")
        
        # 获取数据
        params = {
            "symbol": binance_symbol,
            "interval": binance_interval,
            "limit": limit
        }
        raw_data = self._make_request("/api/v3/klines", params)
        
        if not raw_data:
            logger.error(f"获取{symbol}的历史数据失败")
            return []
        
        # 标准化数据
        standard_data = self.standardize_historical_data(raw_data, binance_symbol)
        
        # 更新缓存
        if standard_data:
            self.cache[cache_key] = standard_data
            self.cache_time[cache_key] = time.time()
        
        logger.info(f"成功获取{symbol}的{len(standard_data)}条历史数据")
        return standard_data
