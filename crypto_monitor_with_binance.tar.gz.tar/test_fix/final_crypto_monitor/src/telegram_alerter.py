"""
Gate.io加密货币异动监控系统 - Telegram推送模块
负责将异常事件推送到Telegram
"""

import logging
import time
import json
import requests
from typing import Dict, List, Any, Optional
from datetime import datetime
import os

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("telegram_alerter")

class TelegramAlerter:
    """Telegram警报推送类，负责将异常事件推送到Telegram"""
    
    def __init__(
        self, 
        token: str = None,
        chat_id: str = None,
        config_file: str = "telegram_config.json",
        max_retries: int = 3,
        retry_delay: int = 2
    ):
        """
        初始化Telegram警报推送器
        
        Args:
            token: Telegram Bot API令牌
            chat_id: 目标聊天ID
            config_file: 配置文件路径
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
        """
        self.token = token
        self.chat_id = chat_id
        self.config_file = config_file
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        
        # 如果提供了配置文件，尝试从中加载配置
        if not (self.token and self.chat_id):
            self._load_config()
        
        logger.info("Telegram警报推送模块初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载Telegram配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.token = config.get("token", self.token)
                    self.chat_id = config.get("chat_id", self.chat_id)
                    logger.info("从配置文件加载Telegram配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def save_config(self, token: str, chat_id: str) -> bool:
        """
        保存Telegram配置到配置文件
        
        Args:
            token: Telegram Bot API令牌
            chat_id: 目标聊天ID
            
        Returns:
            保存是否成功
        """
        try:
            self.token = token
            self.chat_id = chat_id
            
            config = {
                "token": token,
                "chat_id": chat_id
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info("保存Telegram配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def is_configured(self) -> bool:
        """
        检查是否已配置Telegram
        
        Returns:
            是否已配置
        """
        return bool(self.token and self.chat_id)
    
    def test_connection(self) -> bool:
        """
        测试Telegram连接
        
        Returns:
            连接是否成功
        """
        if not self.is_configured():
            logger.error("Telegram未配置，无法测试连接")
            return False
        
        try:
            url = f"https://api.telegram.org/bot{self.token}/getMe"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get("ok"):
                logger.info(f"Telegram连接测试成功，Bot名称: {data.get('result', {}).get('username')}")
                return True
            else:
                logger.error(f"Telegram连接测试失败: {data.get('description')}")
                return False
        except Exception as e:
            logger.error(f"Telegram连接测试失败: {str(e)}")
            return False
    
    def format_alert_message(self, anomaly: Dict) -> str:
        """
        格式化警报消息
        
        Args:
            anomaly: 异常数据
            
        Returns:
            格式化后的消息
        """
        try:
            # 获取异常类型和币种
            anomaly_type = anomaly.get("type", "unknown")
            symbol = anomaly.get("symbol", "未知币种")
            
            # 构建消息标题
            if anomaly_type == "price":
                change_pct = anomaly.get("price_change_pct", 0)
                direction = "上涨" if change_pct > 0 else "下跌"
                title = f"🚨 价格异动警报: {symbol} {direction} {abs(change_pct):.2f}%"
            elif anomaly_type == "volume":
                change_pct = anomaly.get("volume_change_pct", 0)
                title = f"📊 交易量异动警报: {symbol} 增加 {change_pct:.2f}%"
            else:
                title = f"⚠️ 异常警报: {symbol}"
            
            # 构建消息内容
            message_parts = [title, ""]
            
            # 添加价格信息
            if anomaly_type == "price":
                current_price = anomaly.get("current_price", 0)
                reference_price = anomaly.get("reference_price", 0)
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"参考价格: {reference_price}")
                message_parts.append(f"变化幅度: {change_pct:.2f}%")
                
                # 添加交易量信息
                volume_24h = anomaly.get("volume_24h", 0)
                message_parts.append(f"24小时交易量: {volume_24h}")
            
            # 添加交易量信息
            elif anomaly_type == "volume":
                current_volume = anomaly.get("current_volume", 0)
                reference_volume = anomaly.get("reference_volume", 0)
                current_price = anomaly.get("current_price", 0)
                
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"当前交易量: {current_volume}")
                message_parts.append(f"参考交易量: {reference_volume}")
                message_parts.append(f"交易量增加: {change_pct:.2f}%")
            
            # 添加检测时间
            detected_at = anomaly.get("detected_at", datetime.now().isoformat())
            try:
                # 尝试将ISO格式转换为更易读的格式
                dt = datetime.fromisoformat(detected_at)
                formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                formatted_time = detected_at
            
            message_parts.append("")
            message_parts.append(f"检测时间: {formatted_time}")
            
            # 添加交易所链接
            message_parts.append("")
            message_parts.append(f"🔗 [在Gate.io上查看](https://www.gate.io/trade/{symbol})")
            
            # 合并消息
            return "\n".join(message_parts)
        
        except Exception as e:
            logger.error(f"格式化警报消息失败: {str(e)}")
            return f"异常警报: {anomaly.get('symbol', '未知币种')}"
    
    def send_message(self, message: str, parse_mode: str = "Markdown") -> bool:
        """
        发送Telegram消息
        
        Args:
            message: 消息内容
            parse_mode: 解析模式（Markdown或HTML）
            
        Returns:
            发送是否成功
        """
        if not self.is_configured():
            logger.error("Telegram未配置，无法发送消息")
            return False
        
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": parse_mode,
            "disable_web_page_preview": False
        }
        
        for attempt in range(self.max_retries):
            try:
                response = requests.post(url, json=payload, timeout=10)
                response.raise_for_status()
                data = response.json()
                
                if data.get("ok"):
                    logger.info("Telegram消息发送成功")
                    return True
                else:
                    logger.warning(f"Telegram消息发送失败: {data.get('description')}")
                    
                    # 如果是解析模式错误，尝试使用纯文本重新发送
                    if "parse_mode" in data.get("description", "").lower():
                        logger.info("尝试使用纯文本重新发送")
                        return self.send_message(message, parse_mode=None)
                    
                    if attempt < self.max_retries - 1:
                        time.sleep(self.retry_delay * (attempt + 1))
                    else:
                        return False
            
            except requests.exceptions.RequestException as e:
                logger.warning(f"Telegram消息发送失败 (尝试 {attempt+1}/{self.max_retries}): {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                else:
                    logger.error(f"Telegram消息发送最终失败: {str(e)}")
                    return False
        
        return False
    
    def send_anomaly_alert(self, anomaly: Dict) -> bool:
        """
        发送异常警报
        
        Args:
            anomaly: 异常数据
            
        Returns:
            发送是否成功
        """
        message = self.format_alert_message(anomaly)
        return self.send_message(message)
    
    def send_batch_alerts(self, anomalies: List[Dict], max_batch: int = 5) -> int:
        """
        批量发送异常警报
        
        Args:
            anomalies: 异常列表
            max_batch: 最大批量发送数量
            
        Returns:
            成功发送的数量
        """
        if not anomalies:
            return 0
        
        # 限制批量发送数量
        anomalies_to_send = anomalies[:max_batch]
        
        success_count = 0
        for anomaly in anomalies_to_send:
            if self.send_anomaly_alert(anomaly):
                success_count += 1
                # 添加短暂延迟，避免触发Telegram限流
                time.sleep(1)
        
        logger.info(f"批量发送异常警报完成，成功: {success_count}/{len(anomalies_to_send)}")
        return success_count
    
    def handle_send_failure(self, anomaly: Dict) -> None:
        """
        处理发送失败情况
        
        Args:
            anomaly: 异常数据
        """
        logger.warning(f"处理发送失败的异常警报: {anomaly.get('symbol')}")
        
        # 可以实现重试队列或其他恢复机制
        # 这里简单记录到文件
        try:
            with open("failed_alerts.json", "a") as f:
                f.write(json.dumps(anomaly) + "\n")
            logger.info(f"已将发送失败的警报保存到failed_alerts.json")
        except Exception as e:
            logger.error(f"保存发送失败的警报时出错: {str(e)}")


# 回调函数，用于与异常检测模块集成
def telegram_alert_callback(anomalies: List[Dict]) -> None:
    """
    Telegram警报回调函数
    
    Args:
        anomalies: 异常列表
    """
    alerter = TelegramAlerter()
    if not alerter.is_configured():
        logger.warning("Telegram未配置，无法发送警报")
        return
    
    success_count = alerter.send_batch_alerts(anomalies)
    logger.info(f"Telegram警报回调完成，成功发送: {success_count}/{len(anomalies)}")


if __name__ == "__main__":
    # 测试代码
    
    # 创建Telegram警报推送器
    alerter = TelegramAlerter()
    
    # 提示用户配置Telegram
    print("请配置Telegram Bot:")
    token = input("请输入Bot Token: ")
    chat_id = input("请输入Chat ID: ")
    
    # 保存配置
    alerter.save_config(token, chat_id)
    
    # 测试连接
    print("\n测试Telegram连接...")
    if alerter.test_connection():
        print("连接测试成功!")
        
        # 发送测试消息
        print("\n发送测试消息...")
        test_message = "这是一条测试消息，来自Gate.io加密货币异动监控系统。"
        if alerter.send_message(test_message):
            print("测试消息发送成功!")
        else:
            print("测试消息发送失败!")
        
        # 测试异常警报格式化
        print("\n测试异常警报格式化...")
        test_anomaly = {
            "type": "price",
            "symbol": "BTC_USDT",
            "current_price": 50000,
            "reference_price": 45000,
            "price_change_pct": 11.11,
            "volume_24h": 1000000,
            "detected_at": datetime.now().isoformat()
        }
        
        formatted_message = alerter.format_alert_message(test_anomaly)
        print("格式化后的消息:")
        print(formatted_message)
        
        # 发送测试异常警报
        print("\n发送测试异常警报...")
        if alerter.send_anomaly_alert(test_anomaly):
            print("测试异常警报发送成功!")
        else:
            print("测试异常警报发送失败!")
    else:
        print("连接测试失败，请检查Token和Chat ID是否正确。")
    
    print("\n测试完成!")
