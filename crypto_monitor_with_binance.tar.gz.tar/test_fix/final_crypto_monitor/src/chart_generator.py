"""
Gate.io加密货币异动监控系统 - 图表生成模块
生成价格和交易量变化图表
"""

import logging
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter
import numpy as np
import os
from datetime import datetime
from typing import List, Any, Optional

# 配置日志
logger = logging.getLogger("chart_generator")

class ChartGenerator:
    """图表生成器，用于生成价格和交易量变化图表"""
    
    def __init__(self, style: str = "dark_background"):
        """
        初始化图表生成器
        
        Args:
            style: 图表样式，可选值: dark_background, ggplot, seaborn, etc.
        """
        self.style = style
        plt.style.use(style)
        logger.info("图表生成模块初始化完成")
    
    def generate_price_volume_chart(self, symbol: str, timestamps: List[Any], prices: List[float], 
                                   volumes: List[float], save_path: str) -> bool:
        """
        生成价格和交易量变化图表
        
        Args:
            symbol: 币种符号
            timestamps: 时间戳列表
            prices: 价格列表
            volumes: 交易量列表
            save_path: 保存路径
            
        Returns:
            生成是否成功
        """
        logger.info(f"生成 {symbol} 的价格和交易量变化图表")
        
        try:
            # 创建图表
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), gridspec_kw={'height_ratios': [3, 1]})
            fig.suptitle(f"{symbol} 价格和交易量变化", fontsize=16)
            
            # 转换时间戳为日期时间
            dates = []
            for ts in timestamps:
                if isinstance(ts, (int, float)):
                    dates.append(datetime.fromtimestamp(ts))
                else:
                    dates.append(ts)
            
            # 绘制价格曲线
            ax1.plot(dates, prices, 'g-', linewidth=2)
            ax1.set_ylabel('价格 (USDT)', fontsize=12)
            ax1.set_title(f"当前价格: {prices[-1]:.8f} USDT", fontsize=14)
            ax1.grid(True, alpha=0.3)
            
            # 计算价格变化百分比
            price_change = ((prices[-1] - prices[0]) / prices[0]) * 100
            color = 'green' if price_change >= 0 else 'red'
            ax1.text(0.02, 0.95, f"变化: {price_change:.2f}%", transform=ax1.transAxes, 
                    fontsize=12, color=color, verticalalignment='top')
            
            # 绘制交易量柱状图
            ax2.bar(dates, volumes, color='blue', alpha=0.6)
            ax2.set_ylabel('交易量', fontsize=12)
            ax2.grid(True, alpha=0.3)
            
            # 格式化x轴日期
            fig.autofmt_xdate()
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表
            plt.savefig(save_path, dpi=100)
            plt.close()
            
            logger.info(f"图表已保存到: {save_path}")
            return True
        except Exception as e:
            logger.error(f"生成图表失败: {str(e)}")
            return False
    
    def generate_price_change_chart(self, symbol: str, timestamps: List[Any], prices: List[float], 
                                   save_path: str) -> bool:
        """
        生成价格变化图表
        
        Args:
            symbol: 币种符号
            timestamps: 时间戳列表
            prices: 价格列表
            save_path: 保存路径
            
        Returns:
            生成是否成功
        """
        logger.info(f"生成 {symbol} 的价格变化图表")
        
        try:
            # 创建图表
            plt.figure(figsize=(10, 6))
            plt.title(f"{symbol} 价格变化", fontsize=16)
            
            # 转换时间戳为日期时间
            dates = []
            for ts in timestamps:
                if isinstance(ts, (int, float)):
                    dates.append(datetime.fromtimestamp(ts))
                else:
                    dates.append(ts)
            
            # 绘制价格曲线
            plt.plot(dates, prices, 'g-', linewidth=2)
            plt.ylabel('价格 (USDT)', fontsize=12)
            plt.grid(True, alpha=0.3)
            
            # 计算价格变化百分比
            price_change = ((prices[-1] - prices[0]) / prices[0]) * 100
            color = 'green' if price_change >= 0 else 'red'
            plt.text(0.02, 0.95, f"变化: {price_change:.2f}%", transform=plt.gca().transAxes, 
                    fontsize=12, color=color, verticalalignment='top')
            
            # 格式化x轴日期
            plt.gcf().autofmt_xdate()
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表
            plt.savefig(save_path, dpi=100)
            plt.close()
            
            logger.info(f"图表已保存到: {save_path}")
            return True
        except Exception as e:
            logger.error(f"生成图表失败: {str(e)}")
            return False
    
    def generate_volume_chart(self, symbol: str, timestamps: List[Any], volumes: List[float], 
                             save_path: str) -> bool:
        """
        生成交易量变化图表
        
        Args:
            symbol: 币种符号
            timestamps: 时间戳列表
            volumes: 交易量列表
            save_path: 保存路径
            
        Returns:
            生成是否成功
        """
        logger.info(f"生成 {symbol} 的交易量变化图表")
        
        try:
            # 创建图表
            plt.figure(figsize=(10, 6))
            plt.title(f"{symbol} 交易量变化", fontsize=16)
            
            # 转换时间戳为日期时间
            dates = []
            for ts in timestamps:
                if isinstance(ts, (int, float)):
                    dates.append(datetime.fromtimestamp(ts))
                else:
                    dates.append(ts)
            
            # 绘制交易量柱状图
            plt.bar(dates, volumes, color='blue', alpha=0.6)
            plt.ylabel('交易量', fontsize=12)
            plt.grid(True, alpha=0.3)
            
            # 计算交易量变化百分比
            volume_change = ((volumes[-1] - volumes[0]) / volumes[0]) * 100
            color = 'green' if volume_change >= 0 else 'red'
            plt.text(0.02, 0.95, f"变化: {volume_change:.2f}%", transform=plt.gca().transAxes, 
                    fontsize=12, color=color, verticalalignment='top')
            
            # 格式化x轴日期
            plt.gcf().autofmt_xdate()
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表
            plt.savefig(save_path, dpi=100)
            plt.close()
            
            logger.info(f"图表已保存到: {save_path}")
            return True
        except Exception as e:
            logger.error(f"生成图表失败: {str(e)}")
            return False

# 创建全局实例
chart_generator = ChartGenerator()

if __name__ == "__main__":
    # 测试代码
    logging.basicConfig(level=logging.INFO)
    
    # 创建测试数据
    timestamps = [datetime.now().timestamp() - i * 3600 for i in range(24, 0, -1)]
    prices = [10000 + i * 100 + np.random.normal(0, 200) for i in range(24)]
    volumes = [1000000 + i * 10000 + np.random.normal(0, 50000) for i in range(24)]
    
    # 确保保存目录存在
    os.makedirs("charts", exist_ok=True)
    
    # 测试生成价格和交易量变化图表
    chart_generator.generate_price_volume_chart(
        symbol="BTC_USDT",
        timestamps=timestamps,
        prices=prices,
        volumes=volumes,
        save_path="charts/btc_price_volume_chart.png"
    )
    
    # 测试生成价格变化图表
    chart_generator.generate_price_change_chart(
        symbol="BTC_USDT",
        timestamps=timestamps,
        prices=prices,
        save_path="charts/btc_price_chart.png"
    )
    
    # 测试生成交易量变化图表
    chart_generator.generate_volume_chart(
        symbol="BTC_USDT",
        timestamps=timestamps,
        volumes=volumes,
        save_path="charts/btc_volume_chart.png"
    )
