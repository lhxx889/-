"""
Gate.io和币安加密货币异动监控系统 - 单元测试
测试多交易所支持模块的功能
"""

import unittest
import os
import sys
import json
from unittest.mock import MagicMock, patch

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# 导入测试目标模块
from src.exchanges.exchange_interface import ExchangeInterface
from src.exchanges.exchange_manager import ExchangeManager
from src.exchanges.exchange_config import ExchangeConfigManager
from src.exchanges.gateio_adapter import GateioAdapter
from src.exchanges.binance_data_collector import BinanceDataCollector

class TestExchangeInterface(unittest.TestCase):
    """测试交易所接口基类"""
    
    def test_interface_methods(self):
        """测试接口方法是否存在"""
        # 创建模拟实现而不是直接实例化抽象类
        mock_interface = MagicMock(spec=ExchangeInterface)
        
        # 测试必要的方法是否存在
        self.assertTrue(hasattr(mock_interface, 'fetch_all_tickers'))
        self.assertTrue(hasattr(mock_interface, 'fetch_ticker'))
        self.assertTrue(hasattr(mock_interface, 'fetch_historical_data'))
        self.assertTrue(hasattr(mock_interface, 'convert_to_standard_symbol'))
        self.assertTrue(hasattr(mock_interface, 'convert_from_standard_symbol'))
        
        # 测试属性是否存在
        self.assertTrue(hasattr(mock_interface, 'exchange_name'))
        self.assertTrue(hasattr(mock_interface, 'rate_limits'))
        self.assertTrue(hasattr(mock_interface, 'health_metrics'))

class TestExchangeManager(unittest.TestCase):
    """测试交易所管理器"""
    
    def setUp(self):
        """测试前准备"""
        # 创建模拟配置
        self.config = {
            "exchanges": {
                "gateio": {
                    "enabled": True,
                    "api_key": "test_key",
                    "api_secret": "test_secret",
                    "weight": 1.0
                },
                "binance": {
                    "enabled": True,
                    "api_key": "test_key",
                    "api_secret": "test_secret",
                    "weight": 1.0
                }
            },
            "load_balancing": {
                "strategy": "response_time",
                "health_check_interval": 60,
                "min_health_score": 50,
                "auto_adjust_weights": True
            }
        }
        
        # 创建交易所管理器
        self.manager = ExchangeManager(self.config)
        
        # 创建模拟交易所
        self.gateio_mock = MagicMock(spec=GateioAdapter)
        self.gateio_mock.exchange_name = "Gate.io"
        self.gateio_mock.health_metrics = {"health_score": 90, "avg_response_time": 0.2, "success_rate": 0.98}
        
        self.binance_mock = MagicMock(spec=BinanceDataCollector)
        self.binance_mock.exchange_name = "Binance"
        self.binance_mock.health_metrics = {"health_score": 85, "avg_response_time": 0.3, "success_rate": 0.95}
    
    def test_register_exchange(self):
        """测试注册交易所"""
        # 注册模拟交易所
        self.manager.register_exchange(self.gateio_mock, 1.0)
        self.manager.register_exchange(self.binance_mock, 1.0)
        
        # 验证交易所是否已注册
        self.assertEqual(len(self.manager.exchanges), 2)
        self.assertIn("Gate.io", self.manager.exchanges)
        self.assertIn("Binance", self.manager.exchanges)
    
    def test_get_exchange_stats(self):
        """测试获取交易所统计信息"""
        # 注册模拟交易所
        self.manager.register_exchange(self.gateio_mock, 1.0)
        self.manager.register_exchange(self.binance_mock, 1.0)
        
        # 获取统计信息
        stats = self.manager.get_exchange_stats()
        
        # 验证统计信息
        self.assertIn("Gate.io", stats)
        self.assertIn("Binance", stats)
        self.assertIn("health_metrics", stats["Gate.io"])
        self.assertIn("health_metrics", stats["Binance"])
    
    @patch('time.time')
    def test_select_exchange(self, mock_time):
        """测试选择交易所"""
        # 设置模拟时间
        mock_time.return_value = 1000.0
        
        # 注册模拟交易所
        self.manager.register_exchange(self.gateio_mock, 1.0)
        self.manager.register_exchange(self.binance_mock, 1.0)
        
        # 测试响应时间策略
        self.manager.load_balancing_strategy = "response_time"
        exchange = self.manager._select_exchange()
        self.assertIsNotNone(exchange)
        
        # 测试轮询策略
        self.manager.load_balancing_strategy = "round_robin"
        exchange1 = self.manager._select_exchange()
        exchange2 = self.manager._select_exchange()
        self.assertIsNotNone(exchange1)
        self.assertIsNotNone(exchange2)
        
        # 测试健康度评分策略
        self.manager.load_balancing_strategy = "health_score"
        exchange = self.manager._select_exchange()
        self.assertIsNotNone(exchange)

class TestBinanceDataCollector(unittest.TestCase):
    """测试币安数据采集器"""
    
    def setUp(self):
        """测试前准备"""
        self.collector = BinanceDataCollector()
    
    def test_convert_symbol_format(self):
        """测试币种符号格式转换"""
        # 测试币安格式到标准格式的转换
        standard_symbol = self.collector.convert_to_standard_symbol("BTCUSDT")
        self.assertEqual(standard_symbol, "BTC_USDT")
        
        # 测试标准格式到币安格式的转换
        binance_symbol = self.collector.convert_from_standard_symbol("ETH_USDT")
        self.assertEqual(binance_symbol, "ETHUSDT")

class TestGateioAdapter(unittest.TestCase):
    """测试Gate.io适配器"""
    
    @patch('src.data_collector.GateioDataCollector')
    def setUp(self, mock_data_collector):
        """测试前准备"""
        # 创建模拟的原始数据采集器
        self.mock_collector = mock_data_collector.return_value
        
        # 创建Gate.io适配器
        with patch('src.exchanges.gateio_adapter.DataCollector', mock_data_collector):
            self.adapter = GateioAdapter()
    
    def test_convert_symbol_format(self):
        """测试币种符号格式转换"""
        # 测试Gate.io格式到标准格式的转换（应该保持不变）
        standard_symbol = self.adapter.convert_to_standard_symbol("BTC_USDT")
        self.assertEqual(standard_symbol, "BTC_USDT")
        
        # 测试标准格式到Gate.io格式的转换（应该保持不变）
        gateio_symbol = self.adapter.convert_from_standard_symbol("ETH_USDT")
        self.assertEqual(gateio_symbol, "ETH_USDT")

if __name__ == '__main__':
    unittest.main()
