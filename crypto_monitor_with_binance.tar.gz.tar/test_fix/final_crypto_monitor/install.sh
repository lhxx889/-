#!/bin/bash

# Gate.io和币安加密货币异动监控系统 - 一键安装脚本
# 支持多交易所API轮询切换功能

echo "===== Gate.io和币安加密货币异动监控系统安装程序 ====="
echo "此脚本将安装所有必要的依赖并配置系统"

# 检查Python版本
echo -n "检查Python版本... "
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
    echo "找到Python 3"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
    echo "找到Python"
else
    echo "未找到Python，请先安装Python 3.6+"
    exit 1
fi

# 检查Python版本是否>=3.6
$PYTHON_CMD -c "import sys; sys.exit(0) if sys.version_info >= (3, 6) else sys.exit(1)" || {
    echo "Python版本必须>=3.6"
    exit 1
}

# 创建虚拟环境
echo -n "创建Python虚拟环境... "
if [ -d "venv" ]; then
    echo "虚拟环境已存在"
else
    $PYTHON_CMD -m venv venv
    echo "完成"
fi

# 激活虚拟环境
echo -n "激活虚拟环境... "
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo "完成"
else
    echo "无法找到虚拟环境激活脚本"
    exit 1
fi

# 安装核心依赖
echo "安装核心依赖..."
pip install -r requirements-core.txt || {
    echo "安装核心依赖失败"
    exit 1
}

# 安装增强功能依赖
echo "安装增强功能依赖..."
pip install -r requirements-enhanced.txt || {
    echo "警告: 安装增强功能依赖失败，部分功能可能不可用"
}

# 创建配置文件
echo -n "创建配置文件... "
if [ ! -f "config.json" ] && [ -f "config.example.json" ]; then
    cp config.example.json config.json
    echo "完成"
elif [ -f "config.json" ]; then
    echo "配置文件已存在"
else
    echo "无法找到配置模板文件"
    exit 1
fi

# 创建启动脚本
echo -n "创建启动脚本... "
cat > start.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境并启动监控系统
source venv/bin/activate
python main.py "$@"
EOF
chmod +x start.sh
echo "完成"

# 创建配置脚本
echo -n "创建配置脚本... "
cat > setup.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境并运行设置向导
source venv/bin/activate
python main.py --setup
EOF
chmod +x setup.sh
echo "完成"

# 创建交易所统计脚本
echo -n "创建交易所统计脚本... "
cat > exchange_stats.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境并显示交易所统计信息
source venv/bin/activate
python main.py --exchange-stats
EOF
chmod +x exchange_stats.sh
echo "完成"

echo ""
echo "===== 安装完成 ====="
echo "请按照以下步骤操作："
echo "1. 运行 './setup.sh' 配置系统"
echo "2. 运行 './start.sh' 启动监控系统"
echo "3. 运行 './exchange_stats.sh' 查看交易所统计信息"
echo ""
echo "提示：您可以使用 Ctrl+C 停止监控系统"
echo "      可以使用 './start.sh &' 在后台运行系统"
echo ""
echo "祝您使用愉快！"
