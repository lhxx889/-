# Gate.io 监控系统使用说明

## 项目概述

Gate.io 监控系统是一个全面的加密货币监控解决方案，专为监控 Gate.io 交易所的价格变动、公告和新上币信息而设计。系统采用模块化架构，支持多种高级功能，包括代理IP轮换、Telegram推送和自动化配置等。

## 系统架构

系统由以下核心模块组成：

1. **代理管理模块** (`proxy_manager.py`)
   - 支持VLESS URI格式代理配置
   - 支持代理轮换和负载均衡
   - 集成本地sing-box/v2ray客户端配置
   - 提供HTTP/SOCKS代理接口

2. **安装与设置工具** (`setup.py`)
   - 自动解析VLESS URI
   - 自动安装sing-box/v2ray客户端
   - 自动生成代理配置
   - 自动启动代理服务
   - 自动验证代理连接
   - 自动配置Telegram Bot

3. **监控主控模块** (`gate_monitor.py`)
   - 集成代理管理、币种信息采集、公告监控和Telegram推送
   - 支持多种代理类型和轮换策略
   - 提供统一配置管理和命令行接口
   - 实现完整的Gate.io监控功能

4. **配置生成工具** (`create_config.py`)
   - 交互式生成配置文件
   - 支持多种配置类型
   - 提供默认配置模板

5. **一键安装脚本** (`setup.sh`)
   - 提供交互式菜单
   - 支持一键安装所有依赖
   - 支持一键配置代理和Telegram
   - 支持一键启动监控

## 安装指南

### 系统要求

- Python 3.8+
- 网络连接
- sing-box或v2ray代理服务（可选，用于反爬虫）
- Telegram Bot API Token（用于推送通知）

### 依赖安装

使用一键安装脚本：

```bash
chmod +x setup.sh
./setup.sh
```

在菜单中选择"1. 安装依赖"，或者手动安装：

```bash
pip3 install requests python-telegram-bot beautifulsoup4 fake-useragent
```

### 初始配置

1. 使用配置生成工具：

```bash
python3 create_config.py --all
```

2. 编辑生成的配置文件：
   - `config.json`: 主配置文件
   - `telegram_config.json`: Telegram推送配置
   - `config_vless.json`: 代理服务配置

## 使用指南

### 设置代理

使用一键安装脚本：

```bash
./setup.sh
```

在菜单中选择"2. 设置VLESS代理"，或者手动设置：

```bash
python3 setup.py --vless "vless://your-vless-uri" --proxy_type "sing-box"
```

### 设置Telegram Bot

使用一键安装脚本：

```bash
./setup.sh
```

在菜单中选择"3. 设置Telegram Bot"，或者手动设置：

```bash
python3 setup.py --bot_token "your-bot-token" --chat_id "your-chat-id"
```

### 启动监控

使用一键安装脚本：

```bash
./setup.sh
```

在菜单中选择"4. 启动监控"，或者手动启动：

```bash
# 持续监控
python3 gate_monitor.py

# 执行一次监控
python3 gate_monitor.py --once
```

### 全部设置

使用一键安装脚本：

```bash
./setup.sh
```

在菜单中选择"5. 全部设置"，将依次执行安装依赖、设置代理、设置Telegram Bot和启动监控。

## 配置详解

### 主配置文件 (config.json)

```json
{
  "monitor": {
    "interval": 3600,
    "coins": ["BTC", "ETH", "USDT"],
    "price_change_threshold": 5.0,
    "volume_change_threshold": 50.0,
    "announcement_keywords": ["上线", "上架", "listing", "新币", "new coin"]
  },
  "telegram": {
    "enabled": true,
    "config_file": "telegram_config.json"
  },
  "proxy": {
    "enabled": true,
    "config_file": "config_vless.json"
  }
}
```

### 代理配置文件 (config_vless.json)

```json
{
  "proxy": {
    "enabled": true,
    "type": "vless",
    "vless_uris": [
      "vless://your-vless-uri"
    ],
    "use_sing_box": true,
    "use_local_v2ray": false,
    "sing_box_bin": "sing-box",
    "v2ray_bin": "v2ray",
    "local_port_start": 10800,
    "rotation_interval": 10,
    "retry_times": 3,
    "timeout": 10,
    "test_url": "https://api.ipify.org?format=json",
    "blacklist_time": 300
  },
  "user_agent": {
    "enabled": true,
    "rotation": "random",
    "custom_agents": [
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
    ]
  },
  "cookie": {
    "enabled": true,
    "save_path": "cookies.txt",
    "domains": ["gate.io", "www.gate.io"],
    "expire_days": 7
  },
  "behavior": {
    "enabled": true,
    "random_delay": {
      "min": 1,
      "max": 3
    },
    "visit_patterns": {
      "enabled": true,
      "entry_pages": [
        "https://www.gate.io/",
        "https://www.gate.io/trade/BTC_USDT"
      ],
      "random_pages": [
        "https://www.gate.io/trade/ETH_USDT",
        "https://www.gate.io/marketlist"
      ],
      "probability": 0.3
    }
  }
}
```

### Telegram配置文件 (telegram_config.json)

```json
{
  "bot_token": "your-bot-token",
  "chat_id": "your-chat-id"
}
```

## 注意事项

1. 首次运行时会记录当前状态作为基准，不会产生预警
2. 所有数据均直接从Gate.io官方API和网站获取，不使用第三方数据源
3. 在测试过程中发现Gate.io公告页面可能会返回403错误，这可能是由于网站的反爬虫机制，实际部署时可能需要调整请求头或使用代理
4. 使用sing-box或v2ray代理服务需要确保服务已正确配置并运行
5. Telegram推送功能需要有效的Bot Token和Chat ID

## 故障排除

### 常见问题

1. **无法获取公告**
   - 检查网络连接
   - 确认代理配置是否正确
   - 尝试调整请求头或使用不同的代理

2. **Telegram推送失败**
   - 验证Bot Token和Chat ID是否正确
   - 确认Bot是否已被启动
   - 检查网络连接和代理设置

3. **预警不触发**
   - 检查预警规则配置
   - 确认监控的币种是否正确
   - 首次运行不会触发预警，需要至少两次运行才能比较变化

### 日志文件

系统会生成以下日志文件，可用于故障排查：

- `gate_monitor.log`: 主程序日志
- `proxy_manager.log`: 代理管理日志

## 文件结构

```
gate_monitor_integrated/
├── proxy_manager.py     # 代理管理模块
├── setup.py            # 安装与设置工具
├── gate_monitor.py     # 监控主控模块
├── create_config.py    # 配置生成工具
├── setup.sh           # 一键安装脚本
├── config.json        # 主配置文件
├── telegram_config.json # Telegram配置文件
└── config_vless.json  # 代理配置文件
```
