#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 监控系统主控模块
功能：
1. 集成代理管理、币种信息采集、公告监控和Telegram推送
2. 支持多种代理类型和轮换策略
3. 提供统一配置管理和命令行接口
4. 实现完整的Gate.io监控功能
"""

import os
import sys
import json
import time
import logging
import argparse
import requests
from datetime import datetime

# 导入自定义模块
from proxy_manager import ProxyManager, VLESSProxy

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("gate_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("gate_monitor")

class GateMonitor:
    """Gate.io监控系统主类"""
    
    def __init__(self, config_file="config.json"):
        """初始化监控系统
        
        Args:
            config_file: 配置文件路径
        """
        # 默认配置
        self.config = {
            "monitor": {
                "interval": 3600,  # 监控间隔（秒）
                "coins": ["BTC", "ETH", "USDT"],  # 监控的币种
                "price_change_threshold": 5.0,  # 价格变动阈值（百分比）
                "volume_change_threshold": 50.0,  # 交易量变动阈值（百分比）
                "announcement_keywords": ["上线", "上架", "listing", "新币", "new coin"]  # 公告关键词
            },
            "telegram": {
                "enabled": True,
                "config_file": "telegram_config.json"  # Telegram配置文件
            },
            "proxy": {
                "enabled": True,
                "config_file": "config_vless.json"  # 代理配置文件
            }
        }
        
        # 加载配置
        self.load_config(config_file)
        
        # 初始化代理管理器
        self.proxy_manager = None
        if self.config["proxy"]["enabled"]:
            self.init_proxy_manager()
        
        # 初始化Telegram推送
        self.telegram_bot_token = None
        self.telegram_chat_id = None
        if self.config["telegram"]["enabled"]:
            self.init_telegram()
        
        # 初始化状态
        self.last_prices = {}
        self.last_volumes = {}
        self.last_announcements = []
    
    def load_config(self, config_file):
        """加载配置文件
        
        Args:
            config_file: 配置文件路径
        """
        try:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                
                # 更新配置
                for section, values in user_config.items():
                    if section in self.config:
                        self.config[section].update(values)
                    else:
                        self.config[section] = values
                
                logger.info(f"已加载配置文件: {config_file}")
            else:
                logger.warning(f"配置文件不存在: {config_file}，使用默认配置")
                
                # 保存默认配置
                with open(config_file, 'w') as f:
                    json.dump(self.config, f, indent=2)
                
                logger.info(f"已保存默认配置到: {config_file}")
        
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
    
    def init_proxy_manager(self):
        """初始化代理管理器"""
        try:
            proxy_config_file = self.config["proxy"]["config_file"]
            
            if os.path.exists(proxy_config_file):
                self.proxy_manager = ProxyManager(config_file=proxy_config_file)
                logger.info("代理管理器初始化成功")
            else:
                logger.warning(f"代理配置文件不存在: {proxy_config_file}")
                self.proxy_manager = ProxyManager()
                logger.info("使用默认配置初始化代理管理器")
        
        except Exception as e:
            logger.error(f"初始化代理管理器失败: {e}")
            self.proxy_manager = None
    
    def init_telegram(self):
        """初始化Telegram推送"""
        try:
            telegram_config_file = self.config["telegram"]["config_file"]
            
            if os.path.exists(telegram_config_file):
                with open(telegram_config_file, 'r') as f:
                    telegram_config = json.load(f)
                
                self.telegram_bot_token = telegram_config.get("bot_token")
                self.telegram_chat_id = telegram_config.get("chat_id")
                
                if self.telegram_bot_token and self.telegram_chat_id:
                    logger.info("Telegram推送初始化成功")
                else:
                    logger.warning("Telegram配置不完整")
            else:
                logger.warning(f"Telegram配置文件不存在: {telegram_config_file}")
        
        except Exception as e:
            logger.error(f"初始化Telegram推送失败: {e}")
    
    def get_coin_price(self, symbol):
        """获取币种价格
        
        Args:
            symbol: 币种符号
            
        Returns:
            float: 币种价格
        """
        try:
            # 构建API URL
            url = f"https://api.gateio.ws/api/v4/spot/tickers?currency_pair={symbol}_USDT"
            
            # 发送请求
            if self.proxy_manager:
                response = self.proxy_manager.get(url)
            else:
                response = requests.get(url)
            
            # 解析响应
            if response.status_code == 200:
                data = response.json()
                
                if data and isinstance(data, list) and len(data) > 0:
                    return float(data[0]["last"])
                else:
                    logger.warning(f"获取{symbol}价格失败，响应数据为空")
                    return None
            else:
                logger.warning(f"获取{symbol}价格失败，状态码: {response.status_code}")
                return None
        
        except Exception as e:
            logger.error(f"获取{symbol}价格异常: {e}")
            return None
    
    def get_coin_volume(self, symbol):
        """获取币种24小时交易量
        
        Args:
            symbol: 币种符号
            
        Returns:
            float: 币种24小时交易量
        """
        try:
            # 构建API URL
            url = f"https://api.gateio.ws/api/v4/spot/tickers?currency_pair={symbol}_USDT"
            
            # 发送请求
            if self.proxy_manager:
                response = self.proxy_manager.get(url)
            else:
                response = requests.get(url)
            
            # 解析响应
            if response.status_code == 200:
                data = response.json()
                
                if data and isinstance(data, list) and len(data) > 0:
                    return float(data[0]["quote_volume"])
                else:
                    logger.warning(f"获取{symbol}交易量失败，响应数据为空")
                    return None
            else:
                logger.warning(f"获取{symbol}交易量失败，状态码: {response.status_code}")
                return None
        
        except Exception as e:
            logger.error(f"获取{symbol}交易量异常: {e}")
            return None
    
    def get_announcements(self):
        """获取Gate.io公告
        
        Returns:
            list: 公告列表
        """
        try:
            # 构建API URL
            url = "https://www.gate.io/articlelist/ann"
            
            # 发送请求
            if self.proxy_manager:
                response = self.proxy_manager.get(url)
            else:
                response = requests.get(url)
            
            # 解析响应
            if response.status_code == 200:
                # 提取公告
                import re
                from bs4 import BeautifulSoup
                
                soup = BeautifulSoup(response.text, 'html.parser')
                announcements = []
                
                # 查找公告列表
                items = soup.select('.article-list .article-item')
                
                for item in items:
                    title_elem = item.select_one('.article-title')
                    date_elem = item.select_one('.article-date')
                    
                    if title_elem and date_elem:
                        title = title_elem.text.strip()
                        date = date_elem.text.strip()
                        
                        announcements.append({
                            "title": title,
                            "date": date
                        })
                
                return announcements
            else:
                logger.warning(f"获取公告失败，状态码: {response.status_code}")
                return []
        
        except Exception as e:
            logger.error(f"获取公告异常: {e}")
            return []
    
    def check_price_changes(self):
        """检查价格变动"""
        for symbol in self.config["monitor"]["coins"]:
            # 获取当前价格
            current_price = self.get_coin_price(symbol)
            
            if current_price is None:
                continue
            
            # 检查是否有历史价格
            if symbol in self.last_prices:
                last_price = self.last_prices[symbol]
                
                # 计算价格变动百分比
                price_change = (current_price - last_price) / last_price * 100
                
                # 检查是否超过阈值
                if abs(price_change) >= self.config["monitor"]["price_change_threshold"]:
                    message = f"⚠️ {symbol} 价格变动: {price_change:.2f}%\n"
                    message += f"当前价格: {current_price:.4f} USDT\n"
                    message += f"之前价格: {last_price:.4f} USDT"
                    
                    # 发送Telegram通知
                    self.send_telegram_message(message)
            
            # 更新历史价格
            self.last_prices[symbol] = current_price
    
    def check_volume_changes(self):
        """检查交易量变动"""
        for symbol in self.config["monitor"]["coins"]:
            # 获取当前交易量
            current_volume = self.get_coin_volume(symbol)
            
            if current_volume is None:
                continue
            
            # 检查是否有历史交易量
            if symbol in self.last_volumes:
                last_volume = self.last_volumes[symbol]
                
                # 计算交易量变动百分比
                volume_change = (current_volume - last_volume) / last_volume * 100
                
                # 检查是否超过阈值
                if volume_change >= self.config["monitor"]["volume_change_threshold"]:
                    message = f"📈 {symbol} 交易量突增: {volume_change:.2f}%\n"
                    message += f"当前交易量: {current_volume:.2f} USDT\n"
                    message += f"之前交易量: {last_volume:.2f} USDT"
                    
                    # 发送Telegram通知
                    self.send_telegram_message(message)
            
            # 更新历史交易量
            self.last_volumes[symbol] = current_volume
    
    def check_new_announcements(self):
        """检查新公告"""
        # 获取当前公告
        current_announcements = self.get_announcements()
        
        # 检查是否有历史公告
        if self.last_announcements:
            # 查找新公告
            new_announcements = []
            
            for announcement in current_announcements:
                if announcement not in self.last_announcements:
                    new_announcements.append(announcement)
            
            # 检查新公告是否包含关键词
            for announcement in new_announcements:
                title = announcement["title"]
                date = announcement["date"]
                
                # 检查是否包含关键词
                for keyword in self.config["monitor"]["announcement_keywords"]:
                    if keyword in title:
                        message = f"📢 Gate.io 新公告\n"
                        message += f"标题: {title}\n"
                        message += f"日期: {date}\n"
                        message += f"关键词: {keyword}"
                        
                        # 发送Telegram通知
                        self.send_telegram_message(message)
                        break
        
        # 更新历史公告
        self.last_announcements = current_announcements
    
    def send_telegram_message(self, message):
        """发送Telegram消息
        
        Args:
            message: 消息内容
        """
        if not self.config["telegram"]["enabled"] or not self.telegram_bot_token or not self.telegram_chat_id:
            logger.warning("Telegram推送未启用或配置不完整")
            return
        
        try:
            # 构建API URL
            url = f"https://api.telegram.org/bot{self.telegram_bot_token}/sendMessage"
            
            # 构建参数
            params = {
                "chat_id": self.telegram_chat_id,
                "text": message,
                "parse_mode": "Markdown"
            }
            
            # 发送请求
            if self.proxy_manager:
                response = self.proxy_manager.post(url, json=params)
            else:
                response = requests.post(url, json=params)
            
            # 检查响应
            if response.status_code == 200:
                logger.info("Telegram消息发送成功")
            else:
                logger.warning(f"Telegram消息发送失败，状态码: {response.status_code}")
        
        except Exception as e:
            logger.error(f"发送Telegram消息异常: {e}")
    
    def run_once(self):
        """执行一次监控"""
        logger.info("开始执行监控...")
        
        # 检查价格变动
        self.check_price_changes()
        
        # 检查交易量变动
        self.check_volume_changes()
        
        # 检查新公告
        self.check_new_announcements()
        
        logger.info("监控执行完成")
    
    def run(self):
        """持续执行监控"""
        logger.info("开始持续监控...")
        
        try:
            while True:
                # 执行一次监控
                self.run_once()
                
                # 等待下一次监控
                interval = self.config["monitor"]["interval"]
                logger.info(f"等待 {interval} 秒后执行下一次监控...")
                time.sleep(interval)
        
        except KeyboardInterrupt:
            logger.info("监控已停止")
        
        except Exception as e:
            logger.error(f"监控异常: {e}")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 监控系统")
    parser.add_argument("--config", default="config.json", help="配置文件路径")
    parser.add_argument("--once", action="store_true", help="执行一次监控")
    args = parser.parse_args()
    
    # 创建监控实例
    monitor = GateMonitor(config_file=args.config)
    
    # 执行监控
    if args.once:
        monitor.run_once()
    else:
        monitor.run()

if __name__ == "__main__":
    main()
