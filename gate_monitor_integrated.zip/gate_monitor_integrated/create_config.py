#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 监控系统配置生成工具
功能：
1. 交互式生成配置文件
2. 支持多种配置类型
3. 提供默认配置模板
"""

import os
import json
import argparse
import getpass
import sys

def print_color(text, color):
    """打印彩色文本"""
    colors = {
        "red": "\033[0;31m",
        "green": "\033[0;32m",
        "yellow": "\033[0;33m",
        "blue": "\033[0;34m",
        "nc": "\033[0m"  # No Color
    }
    
    print(f"{colors.get(color, colors['nc'])}{text}{colors['nc']}")

def print_info(message):
    """打印信息"""
    print_color(f"[INFO] {message}", "blue")

def print_success(message):
    """打印成功信息"""
    print_color(f"[SUCCESS] {message}", "green")

def print_warning(message):
    """打印警告信息"""
    print_color(f"[WARNING] {message}", "yellow")

def print_error(message):
    """打印错误信息"""
    print_color(f"[ERROR] {message}", "red")

def create_main_config():
    """创建主配置文件"""
    config = {
        "monitor": {
            "interval": 3600,  # 监控间隔（秒）
            "coins": ["BTC", "ETH", "USDT"],  # 监控的币种
            "price_change_threshold": 5.0,  # 价格变动阈值（百分比）
            "volume_change_threshold": 50.0,  # 交易量变动阈值（百分比）
            "announcement_keywords": ["上线", "上架", "listing", "新币", "new coin"]  # 公告关键词
        },
        "telegram": {
            "enabled": True,
            "config_file": "telegram_config.json"  # Telegram配置文件
        },
        "proxy": {
            "enabled": True,
            "config_file": "config_vless.json"  # 代理配置文件
        }
    }
    
    # 交互式配置
    print_info("创建主配置文件")
    
    # 监控间隔
    try:
        interval = input("请输入监控间隔（秒，默认3600）: ").strip()
        if interval:
            config["monitor"]["interval"] = int(interval)
    except ValueError:
        print_warning("无效的监控间隔，使用默认值")
    
    # 监控币种
    coins = input("请输入监控币种（用逗号分隔，默认BTC,ETH,USDT）: ").strip()
    if coins:
        config["monitor"]["coins"] = [coin.strip() for coin in coins.split(",")]
    
    # 价格变动阈值
    try:
        price_threshold = input("请输入价格变动阈值（百分比，默认5.0）: ").strip()
        if price_threshold:
            config["monitor"]["price_change_threshold"] = float(price_threshold)
    except ValueError:
        print_warning("无效的价格变动阈值，使用默认值")
    
    # 交易量变动阈值
    try:
        volume_threshold = input("请输入交易量变动阈值（百分比，默认50.0）: ").strip()
        if volume_threshold:
            config["monitor"]["volume_change_threshold"] = float(volume_threshold)
    except ValueError:
        print_warning("无效的交易量变动阈值，使用默认值")
    
    # 公告关键词
    keywords = input("请输入公告关键词（用逗号分隔，默认上线,上架,listing,新币,new coin）: ").strip()
    if keywords:
        config["monitor"]["announcement_keywords"] = [keyword.strip() for keyword in keywords.split(",")]
    
    # 启用Telegram
    telegram_enabled = input("是否启用Telegram推送（y/n，默认y）: ").strip().lower()
    config["telegram"]["enabled"] = telegram_enabled != "n"
    
    # 启用代理
    proxy_enabled = input("是否启用代理（y/n，默认y）: ").strip().lower()
    config["proxy"]["enabled"] = proxy_enabled != "n"
    
    # 保存配置
    with open("config.json", "w") as f:
        json.dump(config, f, indent=2)
    
    print_success("主配置文件已保存到 config.json")

def create_telegram_config():
    """创建Telegram配置文件"""
    config = {
        "bot_token": "",
        "chat_id": ""
    }
    
    # 交互式配置
    print_info("创建Telegram配置文件")
    
    # Bot Token
    bot_token = input("请输入Telegram Bot Token: ").strip()
    if bot_token:
        config["bot_token"] = bot_token
    else:
        print_warning("Bot Token为空，请稍后通过setup.py设置")
    
    # Chat ID
    chat_id = input("请输入Telegram Chat ID: ").strip()
    if chat_id:
        config["chat_id"] = chat_id
    else:
        print_warning("Chat ID为空，请稍后通过setup.py设置")
    
    # 保存配置
    with open("telegram_config.json", "w") as f:
        json.dump(config, f, indent=2)
    
    print_success("Telegram配置文件已保存到 telegram_config.json")

def create_vless_config():
    """创建VLESS代理配置文件"""
    config = {
        "proxy": {
            "enabled": True,
            "type": "vless",
            "vless_uris": [],
            "use_sing_box": True,
            "use_local_v2ray": False,
            "sing_box_bin": "sing-box",
            "v2ray_bin": "v2ray",
            "local_port_start": 10800,
            "rotation_interval": 10,
            "retry_times": 3,
            "timeout": 10,
            "test_url": "https://api.ipify.org?format=json",
            "blacklist_time": 300
        },
        "user_agent": {
            "enabled": True,
            "rotation": "random",
            "custom_agents": [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
            ]
        },
        "cookie": {
            "enabled": True,
            "save_path": "cookies.txt",
            "domains": ["gate.io", "www.gate.io"],
            "expire_days": 7
        },
        "behavior": {
            "enabled": True,
            "random_delay": {
                "min": 1,
                "max": 3
            },
            "visit_patterns": {
                "enabled": True,
                "entry_pages": [
                    "https://www.gate.io/",
                    "https://www.gate.io/trade/BTC_USDT"
                ],
                "random_pages": [
                    "https://www.gate.io/trade/ETH_USDT",
                    "https://www.gate.io/marketlist"
                ],
                "probability": 0.3
            }
        }
    }
    
    # 交互式配置
    print_info("创建VLESS代理配置文件")
    
    # VLESS URI
    vless_uri = input("请输入VLESS URI（可选，稍后可通过setup.py设置）: ").strip()
    if vless_uri:
        config["proxy"]["vless_uris"].append(vless_uri)
    
    # 代理客户端
    proxy_client = input("请选择代理客户端（1: sing-box, 2: v2ray，默认1）: ").strip()
    if proxy_client == "2":
        config["proxy"]["use_sing_box"] = False
        config["proxy"]["use_local_v2ray"] = True
    
    # 代理轮换间隔
    try:
        rotation_interval = input("请输入代理轮换间隔（请求次数，默认10）: ").strip()
        if rotation_interval:
            config["proxy"]["rotation_interval"] = int(rotation_interval)
    except ValueError:
        print_warning("无效的代理轮换间隔，使用默认值")
    
    # 保存配置
    with open("config_vless.json", "w") as f:
        json.dump(config, f, indent=2)
    
    print_success("VLESS代理配置文件已保存到 config_vless.json")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 监控系统配置生成工具")
    parser.add_argument("--main", action="store_true", help="创建主配置文件")
    parser.add_argument("--telegram", action="store_true", help="创建Telegram配置文件")
    parser.add_argument("--vless", action="store_true", help="创建VLESS代理配置文件")
    parser.add_argument("--all", action="store_true", help="创建所有配置文件")
    args = parser.parse_args()
    
    # 如果没有指定参数，则创建所有配置文件
    if not (args.main or args.telegram or args.vless or args.all):
        args.all = True
    
    print("======================================================")
    print("      Gate.io 监控系统配置生成工具                  ")
    print("======================================================")
    
    # 创建配置文件
    if args.main or args.all:
        create_main_config()
    
    if args.telegram or args.all:
        create_telegram_config()
    
    if args.vless or args.all:
        create_vless_config()
    
    print("======================================================")
    print_success("配置文件生成完成！")
    print("======================================================")

if __name__ == "__main__":
    main()
