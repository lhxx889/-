#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的信息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否安装了sing-box
check_sing_box() {
    if command -v sing-box &> /dev/null; then
        return 0
    else
        return 1
    fi
}

# 检查是否安装了v2ray
check_v2ray() {
    if command -v v2ray &> /dev/null; then
        return 0
    else
        return 1
    fi
}

# 安装sing-box
install_sing_box() {
    print_info "正在安装sing-box..."
    
    # 下载安装脚本
    curl -fsSL https://sing-box.app/install.sh -o install-sing-box.sh
    
    # 设置执行权限
    chmod +x install-sing-box.sh
    
    # 执行安装脚本
    bash install-sing-box.sh
    
    if [ $? -eq 0 ]; then
        print_success "sing-box安装完成"
        return 0
    else
        print_error "sing-box安装失败"
        return 1
    fi
}

# 安装v2ray
install_v2ray() {
    print_info "正在安装v2ray..."
    
    # 下载安装脚本
    curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh -o install-v2ray.sh
    
    # 设置执行权限
    chmod +x install-v2ray.sh
    
    # 执行安装脚本
    bash install-v2ray.sh
    
    if [ $? -eq 0 ]; then
        print_success "v2ray安装完成"
        return 0
    else
        print_error "v2ray安装失败"
        return 1
    fi
}

# 安装Python依赖
install_python_deps() {
    print_info "正在安装Python依赖..."
    
    # 检查是否安装了pip
    if ! command -v pip3 &> /dev/null; then
        print_warning "pip3未安装，正在安装..."
        apt-get update && apt-get install -y python3-pip
    fi
    
    # 安装依赖
    pip3 install requests python-telegram-bot beautifulsoup4 fake-useragent
    
    if [ $? -eq 0 ]; then
        print_success "Python依赖安装完成"
        return 0
    else
        print_error "Python依赖安装失败"
        return 1
    fi
}

# 设置VLESS代理
setup_vless() {
    print_info "开始设置VLESS代理..."
    
    # 获取VLESS URI
    read -p "请输入VLESS URI: " vless_uri
    
    if [ -z "$vless_uri" ]; then
        print_error "VLESS URI不能为空"
        return 1
    fi
    
    # 选择代理类型
    echo "请选择代理类型:"
    echo "1. sing-box"
    echo "2. v2ray"
    read -p "请选择 [1-2]: " proxy_type_choice
    
    case $proxy_type_choice in
        1)
            proxy_type="sing-box"
            # 检查是否安装了sing-box
            if ! check_sing_box; then
                print_warning "sing-box未安装，正在安装..."
                if ! install_sing_box; then
                    print_error "sing-box安装失败，无法继续设置VLESS代理"
                    return 1
                fi
            fi
            ;;
        2)
            proxy_type="v2ray"
            # 检查是否安装了v2ray
            if ! check_v2ray; then
                print_warning "v2ray未安装，正在安装..."
                if ! install_v2ray; then
                    print_error "v2ray安装失败，无法继续设置VLESS代理"
                    return 1
                fi
            fi
            ;;
        *)
            print_error "无效的选择"
            return 1
            ;;
    esac
    
    # 运行Python设置脚本
    python3 setup.py --vless "$vless_uri" --proxy_type "$proxy_type"
    
    if [ $? -eq 0 ]; then
        print_success "VLESS代理设置完成"
    else
        print_error "VLESS代理设置失败"
        return 1
    fi
}

# 设置Telegram Bot
setup_telegram() {
    print_info "开始设置Telegram Bot..."
    
    # 获取Bot Token和Chat ID
    read -p "请输入Telegram Bot Token: " bot_token
    read -p "请输入Telegram Chat ID: " chat_id
    
    if [ -z "$bot_token" ] || [ -z "$chat_id" ]; then
        print_error "Bot Token和Chat ID不能为空"
        return 1
    fi
    
    # 运行Python设置脚本
    python3 setup.py --bot_token "$bot_token" --chat_id "$chat_id"
    
    if [ $? -eq 0 ]; then
        print_success "Telegram Bot设置完成"
    else
        print_error "Telegram Bot设置失败"
        return 1
    fi
}

# 启动监控
start_monitor() {
    print_info "启动Gate.io监控系统..."
    
    # 检查配置文件
    if [ ! -f "config.json" ]; then
        print_warning "配置文件不存在，将使用默认配置"
    fi
    
    # 选择监控模式
    echo "请选择监控模式:"
    echo "1. 持续监控"
    echo "2. 执行一次"
    read -p "请选择 [1-2]: " monitor_mode
    
    case $monitor_mode in
        1)
            # 持续监控
            python3 gate_monitor.py &
            
            if [ $? -eq 0 ]; then
                print_success "Gate.io监控系统已启动"
                echo "监控日志保存在 gate_monitor.log"
            else
                print_error "Gate.io监控系统启动失败"
                return 1
            fi
            ;;
        2)
            # 执行一次
            python3 gate_monitor.py --once
            
            if [ $? -eq 0 ]; then
                print_success "Gate.io监控系统执行完成"
            else
                print_error "Gate.io监控系统执行失败"
                return 1
            fi
            ;;
        *)
            print_error "无效的选择"
            return 1
            ;;
    esac
}

# 主菜单
main_menu() {
    while true; do
        echo ""
        echo "========================================================"
        echo "      Gate.io 监控系统一键设置                        "
        echo "========================================================"
        echo "1. 安装依赖"
        echo "2. 设置VLESS代理"
        echo "3. 设置Telegram Bot"
        echo "4. 启动监控"
        echo "5. 全部设置"
        echo "6. 退出"
        echo "========================================================"
        
        read -p "请选择操作 [1-6]: " choice
        
        case $choice in
            1)
                install_python_deps
                ;;
            2)
                setup_vless
                ;;
            3)
                setup_telegram
                ;;
            4)
                start_monitor
                ;;
            5)
                install_python_deps && setup_vless && setup_telegram && start_monitor
                ;;
            6)
                print_info "退出设置"
                exit 0
                ;;
            *)
                print_error "无效的选择，请重新输入"
                ;;
        esac
    done
}

# 执行主菜单
main_menu
