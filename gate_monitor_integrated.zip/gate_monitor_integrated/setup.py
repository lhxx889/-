#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gate.io 监控系统安装与设置工具
功能：
1. 自动解析VLESS URI
2. 自动安装sing-box/v2ray客户端
3. 自动生成代理配置
4. 自动启动代理服务
5. 自动验证代理连接
6. 自动配置Telegram Bot
"""

import os
import sys
import json
import time
import subprocess
import argparse
import requests
import re
import base64
import urllib.parse
import getpass
from urllib.parse import urlparse, parse_qs

# 颜色定义
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[0;33m'
BLUE = '\033[0;34m'
NC = '\033[0m'  # No Color

def print_info(message):
    """打印信息"""
    print(f"{BLUE}[INFO]{NC} {message}")

def print_success(message):
    """打印成功信息"""
    print(f"{GREEN}[SUCCESS]{NC} {message}")

def print_warning(message):
    """打印警告信息"""
    print(f"{YELLOW}[WARNING]{NC} {message}")

def print_error(message):
    """打印错误信息"""
    print(f"{RED}[ERROR]{NC} {message}")

def run_command(command, shell=False):
    """运行命令并返回结果"""
    try:
        if shell:
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        stdout, stderr = process.communicate()
        return {
            "success": process.returncode == 0,
            "stdout": stdout.decode('utf-8', errors='ignore'),
            "stderr": stderr.decode('utf-8', errors='ignore'),
            "returncode": process.returncode
        }
    except Exception as e:
        return {
            "success": False,
            "stdout": "",
            "stderr": str(e),
            "returncode": -1
        }

def check_root():
    """检查是否为root用户"""
    return os.geteuid() == 0

def check_sing_box():
    """检查sing-box是否已安装"""
    result = run_command(["which", "sing-box"])
    return result["success"]

def check_v2ray():
    """检查v2ray是否已安装"""
    result = run_command(["which", "v2ray"])
    return result["success"]

def install_sing_box():
    """安装sing-box"""
    print_info("正在安装sing-box...")
    
    # 下载安装脚本
    download_result = run_command("curl -fsSL https://sing-box.app/install.sh -o install-sing-box.sh", shell=True)
    
    if not download_result["success"]:
        print_error(f"下载sing-box安装脚本失败: {download_result['stderr']}")
        return False
    
    # 设置执行权限
    chmod_result = run_command("chmod +x install-sing-box.sh", shell=True)
    
    if not chmod_result["success"]:
        print_error(f"设置sing-box安装脚本执行权限失败: {chmod_result['stderr']}")
        return False
    
    # 执行安装脚本
    install_result = run_command("bash install-sing-box.sh", shell=True)
    
    if not install_result["success"]:
        print_error(f"安装sing-box失败: {install_result['stderr']}")
        return False
    
    print_success("sing-box安装完成")
    return True

def install_v2ray():
    """安装v2ray"""
    print_info("正在安装v2ray...")
    
    # 下载安装脚本
    download_result = run_command("curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh -o install-v2ray.sh", shell=True)
    
    if not download_result["success"]:
        print_error(f"下载v2ray安装脚本失败: {download_result['stderr']}")
        return False
    
    # 设置执行权限
    chmod_result = run_command("chmod +x install-v2ray.sh", shell=True)
    
    if not chmod_result["success"]:
        print_error(f"设置v2ray安装脚本执行权限失败: {chmod_result['stderr']}")
        return False
    
    # 执行安装脚本
    install_result = run_command("bash install-v2ray.sh", shell=True)
    
    if not install_result["success"]:
        print_error(f"安装v2ray失败: {install_result['stderr']}")
        return False
    
    print_success("v2ray安装完成")
    return True

class ProxySetup:
    """代理设置基类"""
    
    def __init__(self, proxy_type="sing-box"):
        """初始化
        
        Args:
            proxy_type: 代理类型，sing-box或v2ray
        """
        self.protocol = "vless"
        self.user_id = ""
        self.address = ""
        self.port = 443
        self.params = {}
        self.tag = ""
        self.local_port = 10808
        self.proxy_type = proxy_type
        
        if proxy_type == "sing-box":
            self.config_file = "/usr/local/etc/sing-box/config.json"
            self.service_name = "sing-box"
        else:  # v2ray
            self.config_file = "/usr/local/etc/v2ray/config.json"
            self.service_name = "v2ray"
    
    def parse_uri(self, uri):
        """解析VLESS URI
        
        Args:
            uri: VLESS URI格式的代理配置
            
        Example:
            vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态
        """
        try:
            # 检查URI格式
            if not uri.startswith("vless://"):
                print_error("不是有效的VLESS URI")
                return False
            
            # 移除协议前缀
            uri = uri[8:]
            
            # 分离标签部分
            if "#" in uri:
                uri, tag = uri.split("#", 1)
                self.tag = urllib.parse.unquote(tag)
            
            # 分离用户ID和服务器地址
            if "@" in uri:
                user_id, server = uri.split("@", 1)
                self.user_id = user_id
            else:
                server = uri
            
            # 分离服务器地址和参数
            if "/?" in server:
                server, params_str = server.split("/?", 1)
                # 解析参数
                self.params = dict(urllib.parse.parse_qsl(params_str))
            
            # 分离地址和端口
            if ":" in server:
                address, port = server.split(":", 1)
                self.address = address
                self.port = int(port)
            else:
                self.address = server
            
            print_success(f"成功解析VLESS URI: {self.address}:{self.port}, 标签: {self.tag}")
            return True
        
        except Exception as e:
            print_error(f"解析VLESS URI失败: {e}")
            return False
    
    def generate_config(self):
        """生成代理配置"""
        if self.proxy_type == "sing-box":
            return self.generate_sing_box_config()
        else:  # v2ray
            return self.generate_v2ray_config()
    
    def generate_sing_box_config(self):
        """生成sing-box配置"""
        config = {
            "log": {
                "level": "info",
                "timestamp": True
            },
            "inbounds": [
                {
                    "type": "socks",
                    "tag": "socks-in",
                    "listen": "127.0.0.1",
                    "listen_port": self.local_port,
                    "users": [],
                    "udp": True
                },
                {
                    "type": "http",
                    "tag": "http-in",
                    "listen": "127.0.0.1",
                    "listen_port": self.local_port + 1,
                    "users": []
                }
            ],
            "outbounds": [
                {
                    "type": "vless",
                    "tag": "vless-out",
                    "server": self.address,
                    "server_port": self.port,
                    "uuid": self.user_id,
                    "flow": self.params.get("flow", ""),
                    "network": self.params.get("type", "tcp"),
                    "packet_encoding": "",
                    "tls": {}
                },
                {
                    "type": "direct",
                    "tag": "direct"
                },
                {
                    "type": "block",
                    "tag": "block"
                }
            ],
            "route": {
                "rules": [
                    {
                        "geoip": ["private"],
                        "outbound": "direct"
                    },
                    {
                        "geosite": ["category-ads-all"],
                        "outbound": "block"
                    }
                ],
                "final": "vless-out"
            }
        }
        
        # 添加TLS配置
        if self.params.get("security") == "tls" or self.params.get("security") == "reality":
            config["outbounds"][0]["tls"] = {
                "enabled": True,
                "server_name": self.params.get("sni", ""),
                "utls": {
                    "enabled": True,
                    "fingerprint": self.params.get("fp", "chrome")
                }
            }
        
        # 添加Reality配置
        if self.params.get("security") == "reality":
            config["outbounds"][0]["tls"]["reality"] = {
                "enabled": True,
                "public_key": self.params.get("pbk", ""),
                "short_id": self.params.get("sid", "")
            }
            if "spx" in self.params:
                config["outbounds"][0]["tls"]["reality"]["spider_x"] = self.params.get("spx", "")
        
        # 添加传输配置
        network = self.params.get("type", "tcp")
        if network == "ws":
            config["outbounds"][0]["transport"] = {
                "type": "ws",
                "path": self.params.get("path", "/"),
                "headers": {
                    "Host": self.params.get("host", self.address)
                }
            }
        elif network == "grpc":
            config["outbounds"][0]["transport"] = {
                "type": "grpc",
                "service_name": self.params.get("serviceName", "")
            }
        
        return config
    
    def generate_v2ray_config(self):
        """生成v2ray配置"""
        config = {
            "log": {
                "loglevel": "warning"
            },
            "inbounds": [
                {
                    "port": self.local_port,
                    "listen": "127.0.0.1",
                    "protocol": "socks",
                    "settings": {
                        "udp": True
                    }
                },
                {
                    "port": self.local_port + 1,
                    "listen": "127.0.0.1",
                    "protocol": "http"
                }
            ],
            "outbounds": [
                {
                    "protocol": "vless",
                    "settings": {
                        "vnext": [
                            {
                                "address": self.address,
                                "port": self.port,
                                "users": [
                                    {
                                        "id": self.user_id,
                                        "encryption": self.params.get("encryption", "none"),
                                        "flow": self.params.get("flow", "")
                                    }
                                ]
                            }
                        ]
                    },
                    "streamSettings": {
                        "network": self.params.get("type", "tcp"),
                        "security": self.params.get("security", "none")
                    },
                    "tag": "proxy"
                },
                {
                    "protocol": "freedom",
                    "settings": {},
                    "tag": "direct"
                }
            ],
            "routing": {
                "rules": [
                    {
                        "type": "field",
                        "ip": ["geoip:private"],
                        "outboundTag": "direct"
                    },
                    {
                        "type": "field",
                        "outboundTag": "proxy"
                    }
                ]
            }
        }
        
        # 添加TLS配置
        if self.params.get("security") == "tls" or self.params.get("security") == "reality":
            config["outbounds"][0]["streamSettings"]["tlsSettings"] = {
                "serverName": self.params.get("sni", ""),
                "fingerprint": self.params.get("fp", "chrome")
            }
        
        # 添加Reality配置
        if self.params.get("security") == "reality":
            config["outbounds"][0]["streamSettings"]["realitySettings"] = {
                "show": False,
                "publicKey": self.params.get("pbk", ""),
                "shortId": self.params.get("sid", ""),
                "spiderX": self.params.get("spx", "")
            }
        
        # 添加传输配置
        network = self.params.get("type", "tcp")
        if network == "ws":
            config["outbounds"][0]["streamSettings"]["wsSettings"] = {
                "path": self.params.get("path", "/"),
                "headers": {
                    "Host": self.params.get("host", self.address)
                }
            }
        elif network == "grpc":
            config["outbounds"][0]["streamSettings"]["grpcSettings"] = {
                "serviceName": self.params.get("serviceName", "")
            }
        
        return config
    
    def save_config(self, config):
        """保存代理配置"""
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            # 保存配置
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print_success(f"配置已保存到: {self.config_file}")
            return True
        
        except Exception as e:
            print_error(f"保存配置失败: {e}")
            return False
    
    def restart_service(self):
        """重启代理服务"""
        print_info(f"重启{self.service_name}服务...")
        
        # 停止服务
        stop_result = run_command(f"systemctl stop {self.service_name}", shell=True)
        
        if not stop_result["success"]:
            print_warning(f"停止服务失败: {stop_result['stderr']}")
        
        # 启动服务
        start_result = run_command(f"systemctl start {self.service_name}", shell=True)
        
        if not start_result["success"]:
            print_error(f"启动服务失败: {start_result['stderr']}")
            return False
        
        # 检查服务状态
        status_result = run_command(f"systemctl status {self.service_name}", shell=True)
        
        if "Active: active (running)" in status_result["stdout"]:
            print_success(f"{self.service_name}服务已启动")
            return True
        else:
            print_error(f"{self.service_name}服务启动失败")
            return False
    
    def test_proxy(self):
        """测试代理连接"""
        print_info("测试代理连接...")
        
        # 等待服务启动
        time.sleep(2)
        
        # 设置代理
        proxies = {
            "http": f"socks5://127.0.0.1:{self.local_port}",
            "https": f"socks5://127.0.0.1:{self.local_port}"
        }
        
        try:
            # 测试连接
            response = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=10)
            
            if response.status_code == 200:
                ip = response.json().get("ip", "未知")
                print_success(f"代理连接成功，当前IP: {ip}")
                return True
            else:
                print_error(f"代理连接失败，状态码: {response.status_code}")
                return False
        
        except Exception as e:
            print_error(f"代理连接测试失败: {e}")
            return False
    
    def save_to_config_vless(self):
        """保存到config_vless.json"""
        config_file = "config_vless.json"
        
        try:
            # 读取现有配置
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    config = json.load(f)
            else:
                config = {
                    "proxy": {
                        "enabled": True,
                        "type": "vless",
                        "vless_uris": [],
                        "use_sing_box": self.proxy_type == "sing-box",
                        "use_local_v2ray": self.proxy_type == "v2ray",
                        "sing_box_bin": "sing-box",
                        "v2ray_bin": "v2ray",
                        "local_port_start": 10800,
                        "rotation_interval": 10,
                        "retry_times": 3,
                        "timeout": 10,
                        "test_url": "https://api.ipify.org?format=json",
                        "blacklist_time": 300
                    },
                    "user_agent": {
                        "enabled": True,
                        "rotation": "random",
                        "custom_agents": [
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
                        ]
                    },
                    "cookie": {
                        "enabled": True,
                        "save_path": "cookies.txt",
                        "domains": ["gate.io", "www.gate.io"],
                        "expire_days": 7
                    },
                    "behavior": {
                        "enabled": True,
                        "random_delay": {
                            "min": 1,
                            "max": 3
                        },
                        "visit_patterns": {
                            "enabled": True,
                            "entry_pages": [
                                "https://www.gate.io/",
                                "https://www.gate.io/trade/BTC_USDT"
                            ],
                            "random_pages": [
                                "https://www.gate.io/trade/ETH_USDT",
                                "https://www.gate.io/marketlist"
                            ],
                            "probability": 0.3
                        }
                    }
                }
            
            # 构建VLESS URI
            vless_uri = f"vless://{self.user_id}@{self.address}:{self.port}/?"
            
            # 添加参数
            params = []
            for key, value in self.params.items():
                params.append(f"{key}={value}")
            
            vless_uri += "&".join(params)
            
            # 添加标签
            if self.tag:
                vless_uri += f"#{urllib.parse.quote(self.tag)}"
            
            # 更新配置
            if vless_uri not in config["proxy"]["vless_uris"]:
                config["proxy"]["vless_uris"].insert(0, vless_uri)
            
            # 确保使用正确的代理客户端
            if self.proxy_type == "sing-box":
                config["proxy"]["use_sing_box"] = True
                config["proxy"]["use_local_v2ray"] = False
            else:  # v2ray
                config["proxy"]["use_sing_box"] = False
                config["proxy"]["use_local_v2ray"] = True
            
            # 保存配置
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print_success(f"VLESS URI已保存到: {config_file}")
            return True
        
        except Exception as e:
            print_error(f"保存到config_vless.json失败: {e}")
            return False

class TelegramSetup:
    """Telegram设置类"""
    
    def __init__(self):
        """初始化"""
        self.bot_token = ""
        self.chat_id = ""
        self.config_file = "telegram_config.json"
    
    def input_credentials(self):
        """输入Telegram凭据"""
        print_info("请输入Telegram Bot凭据")
        print_info("您可以通过 @BotFather 创建Bot并获取Token")
        print_info("您可以通过 @userinfobot 获取您的Chat ID")
        
        self.bot_token = input("Bot Token: ").strip()
        self.chat_id = input("Chat ID: ").strip()
        
        return bool(self.bot_token and self.chat_id)
    
    def verify_credentials(self):
        """验证Telegram Bot凭据"""
        print_info("正在验证Telegram Bot凭据...")
        
        if not self.bot_token or not self.chat_id:
            print_error("Bot Token和Chat ID不能为空")
            return False
        
        try:
            # 构建API URL
            url = f"https://api.telegram.org/bot{self.bot_token}/getMe"
            
            # 发送请求
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("ok"):
                    bot_name = data.get("result", {}).get("username", "未知")
                    print_success(f"Bot Token验证成功，Bot名称: @{bot_name}")
                    
                    # 验证Chat ID
                    return self.verify_chat_id()
                else:
                    print_error(f"Bot Token验证失败: {data.get('description', '未知错误')}")
                    return False
            else:
                print_error(f"Bot Token验证失败，状态码: {response.status_code}")
                return False
        
        except Exception as e:
            print_error(f"验证失败: {e}")
            return False
    
    def verify_chat_id(self):
        """验证Chat ID"""
        print_info("正在验证Chat ID...")
        
        try:
            # 构建API URL
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            
            # 构建参数
            params = {
                "chat_id": self.chat_id,
                "text": "Gate.io监控系统: Telegram Bot验证成功！"
            }
            
            # 发送请求
            response = requests.post(url, json=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("ok"):
                    print_success("Chat ID验证成功，已发送测试消息")
                    return True
                else:
                    print_error(f"Chat ID验证失败: {data.get('description', '未知错误')}")
                    return False
            else:
                print_error(f"Chat ID验证失败，状态码: {response.status_code}")
                return False
        
        except Exception as e:
            print_error(f"验证失败: {e}")
            return False
    
    def save_config(self):
        """保存Telegram配置"""
        try:
            # 构建配置
            config = {
                "bot_token": self.bot_token,
                "chat_id": self.chat_id
            }
            
            # 保存配置
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print_success(f"Telegram配置已保存到: {self.config_file}")
            return True
        
        except Exception as e:
            print_error(f"保存Telegram配置失败: {e}")
            return False

def setup_proxy(vless_uri=None, proxy_type="sing-box"):
    """设置代理"""
    print_info(f"开始设置{proxy_type}代理...")
    
    # 获取VLESS URI
    if not vless_uri:
        vless_uri = input("请输入VLESS URI: ").strip()
    
    if not vless_uri:
        print_error("VLESS URI不能为空")
        return False
    
    # 检查是否为root用户
    if not check_root():
        print_warning("当前非root用户，部分功能可能受限")
        print_warning(f"建议使用 sudo python setup.py 运行此脚本")
    
    # 检查代理客户端是否已安装
    if proxy_type == "sing-box":
        if not check_sing_box():
            print_warning("sing-box未安装")
            
            # 安装sing-box
            if not install_sing_box():
                print_error("sing-box安装失败，请手动安装")
                return False
    else:  # v2ray
        if not check_v2ray():
            print_warning("v2ray未安装")
            
            # 安装v2ray
            if not install_v2ray():
                print_error("v2ray安装失败，请手动安装")
                return False
    
    # 创建代理设置实例
    proxy_setup = ProxySetup(proxy_type)
    
    # 解析URI
    if not proxy_setup.parse_uri(vless_uri):
        return False
    
    # 生成配置
    config = proxy_setup.generate_config()
    
    # 保存配置
    if not proxy_setup.save_config(config):
        return False
    
    # 重启服务
    if not proxy_setup.restart_service():
        return False
    
    # 测试代理
    if not proxy_setup.test_proxy():
        return False
    
    # 保存到config_vless.json
    proxy_setup.save_to_config_vless()
    
    print_success(f"{proxy_type}代理设置完成")
    return True

def setup_telegram(bot_token=None, chat_id=None):
    """设置Telegram Bot"""
    print_info("开始设置Telegram Bot...")
    
    # 创建Telegram设置实例
    telegram_setup = TelegramSetup()
    
    # 设置凭据
    if bot_token and chat_id:
        telegram_setup.bot_token = bot_token
        telegram_setup.chat_id = chat_id
    else:
        if not telegram_setup.input_credentials():
            print_error("Telegram凭据输入失败")
            return False
    
    # 验证凭据
    if not telegram_setup.verify_credentials():
        print_error("Telegram凭据验证失败")
        return False
    
    # 保存配置
    if not telegram_setup.save_config():
        return False
    
    print_success("Telegram Bot设置完成")
    return True

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io 监控系统安装与设置工具")
    parser.add_argument("--vless", help="VLESS URI")
    parser.add_argument("--proxy_type", choices=["sing-box", "v2ray"], default="sing-box", help="代理类型: sing-box或v2ray")
    parser.add_argument("--bot_token", help="Telegram Bot Token")
    parser.add_argument("--chat_id", help="Telegram Chat ID")
    parser.add_argument("--all", action="store_true", help="全部设置")
    args = parser.parse_args()
    
    print("======================================================")
    print("      Gate.io 监控系统安装与设置工具                  ")
    print("======================================================")
    
    # 设置代理
    if args.vless or args.all:
        if not setup_proxy(args.vless, args.proxy_type):
            return
    
    # 设置Telegram Bot
    if args.bot_token and args.chat_id or args.all:
        if not setup_telegram(args.bot_token, args.chat_id):
            return
    
    print("======================================================")
    print_success("Gate.io 监控系统安装与设置完成！")
    print("======================================================")

if __name__ == "__main__":
    main()
