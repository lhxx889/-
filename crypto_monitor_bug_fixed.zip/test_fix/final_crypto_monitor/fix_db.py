"""
Gate.io加密货币异动监控系统 - 数据库修复脚本
修复"无法获取最新价格数据"问题
"""

import sqlite3
import os
import json
import time
import requests
from datetime import datetime, timedelta
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("fix_db.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("fix_db")

# 数据库路径
DB_PATH = "crypto_data.db"

def check_db_exists():
    """检查数据库是否存在，不存在则创建"""
    if not os.path.exists(DB_PATH):
        logger.info(f"数据库文件 {DB_PATH} 不存在，将创建新数据库")
        create_database()
        return False
    return True

def create_database():
    """创建数据库和必要的表"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # 创建币种信息表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS coins (
            id TEXT PRIMARY KEY,
            symbol TEXT NOT NULL,
            name TEXT,
            last_updated TIMESTAMP
        )
        ''')
        
        # 创建价格历史表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            price REAL NOT NULL,
            volume_24h REAL,
            change_percentage_24h REAL,
            timestamp TIMESTAMP NOT NULL,
            FOREIGN KEY (symbol) REFERENCES coins(symbol)
        )
        ''')
        
        # 创建异常检测记录表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS anomaly_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            price REAL NOT NULL,
            old_price REAL NOT NULL,
            change_percentage REAL NOT NULL,
            volume_24h REAL,
            volume_change_percentage REAL,
            detected_at TIMESTAMP NOT NULL,
            is_notified BOOLEAN DEFAULT 0,
            FOREIGN KEY (symbol) REFERENCES coins(symbol)
        )
        ''')
        
        conn.commit()
        conn.close()
        logger.info("数据库创建成功")
    except Exception as e:
        logger.error(f"创建数据库失败: {str(e)}")
        raise

def check_table_structure():
    """检查表结构是否正确"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # 获取所有表
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        logger.info(f"数据库中的表: {table_names}")
        
        # 检查必要的表是否存在
        required_tables = ['coins', 'price_history', 'anomaly_records']
        for table in required_tables:
            if table not in table_names:
                logger.warning(f"表 {table} 不存在，将创建")
                if table == 'coins':
                    cursor.execute('''
                    CREATE TABLE coins (
                        id TEXT PRIMARY KEY,
                        symbol TEXT NOT NULL,
                        name TEXT,
                        last_updated TIMESTAMP
                    )
                    ''')
                elif table == 'price_history':
                    cursor.execute('''
                    CREATE TABLE price_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        symbol TEXT NOT NULL,
                        price REAL NOT NULL,
                        volume_24h REAL,
                        change_percentage_24h REAL,
                        timestamp TIMESTAMP NOT NULL,
                        FOREIGN KEY (symbol) REFERENCES coins(symbol)
                    )
                    ''')
                elif table == 'anomaly_records':
                    cursor.execute('''
                    CREATE TABLE anomaly_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        symbol TEXT NOT NULL,
                        price REAL NOT NULL,
                        old_price REAL NOT NULL,
                        change_percentage REAL NOT NULL,
                        volume_24h REAL,
                        volume_change_percentage REAL,
                        detected_at TIMESTAMP NOT NULL,
                        is_notified BOOLEAN DEFAULT 0,
                        FOREIGN KEY (symbol) REFERENCES coins(symbol)
                    )
                    ''')
        
        # 检查price_history表的timestamp字段格式
        cursor.execute("PRAGMA table_info(price_history);")
        columns = cursor.fetchall()
        timestamp_column = None
        for column in columns:
            if column[1] == 'timestamp':
                timestamp_column = column
                break
        
        if timestamp_column:
            logger.info(f"timestamp字段信息: {timestamp_column}")
        else:
            logger.error("price_history表中没有timestamp字段")
        
        conn.commit()
        conn.close()
        logger.info("表结构检查完成")
    except Exception as e:
        logger.error(f"检查表结构失败: {str(e)}")
        raise

def check_existing_data():
    """检查现有数据"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # 检查coins表数据
        cursor.execute("SELECT COUNT(*) FROM coins")
        coins_count = cursor.fetchone()[0]
        logger.info(f"coins表中有 {coins_count} 条记录")
        
        # 检查price_history表数据
        cursor.execute("SELECT COUNT(*) FROM price_history")
        price_history_count = cursor.fetchone()[0]
        logger.info(f"price_history表中有 {price_history_count} 条记录")
        
        # 检查最近的价格历史记录
        if price_history_count > 0:
            cursor.execute("SELECT symbol, price, volume_24h, timestamp FROM price_history ORDER BY id DESC LIMIT 5")
            recent_records = cursor.fetchall()
            logger.info("最近的价格历史记录:")
            for record in recent_records:
                logger.info(f"  - {record}")
        
        conn.close()
        return coins_count, price_history_count
    except Exception as e:
        logger.error(f"检查现有数据失败: {str(e)}")
        return 0, 0

def fix_timestamp_format():
    """修复timestamp字段格式问题"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # 检查timestamp字段的格式
        cursor.execute("SELECT id, timestamp FROM price_history LIMIT 10")
        records = cursor.fetchall()
        
        if not records:
            logger.info("price_history表中没有数据，无需修复timestamp格式")
            conn.close()
            return
        
        logger.info("检查timestamp格式...")
        sample_timestamps = [record[1] for record in records]
        logger.info(f"样本timestamp值: {sample_timestamps}")
        
        # 检查是否需要修复
        needs_fix = False
        for ts in sample_timestamps:
            # 检查是否为ISO格式字符串
            if isinstance(ts, str) and 'T' in ts:
                needs_fix = True
                break
        
        if needs_fix:
            logger.info("检测到timestamp格式问题，开始修复...")
            
            # 获取所有记录
            cursor.execute("SELECT id, timestamp FROM price_history")
            all_records = cursor.fetchall()
            
            # 修复每条记录
            for record in all_records:
                record_id = record[0]
                timestamp = record[1]
                
                # 如果是ISO格式字符串，转换为SQLite datetime格式
                if isinstance(timestamp, str) and 'T' in timestamp:
                    try:
                        # 解析ISO格式
                        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                        # 转换为SQLite datetime格式
                        sqlite_timestamp = dt.strftime('%Y-%m-%d %H:%M:%S')
                        
                        # 更新记录
                        cursor.execute(
                            "UPDATE price_history SET timestamp = ? WHERE id = ?",
                            (sqlite_timestamp, record_id)
                        )
                    except Exception as e:
                        logger.warning(f"修复记录ID {record_id} 的timestamp失败: {str(e)}")
            
            conn.commit()
            logger.info("timestamp格式修复完成")
        else:
            logger.info("timestamp格式正常，无需修复")
        
        conn.close()
    except Exception as e:
        logger.error(f"修复timestamp格式失败: {str(e)}")

def fetch_gate_io_data():
    """从Gate.io API获取最新数据"""
    try:
        logger.info("从Gate.io API获取最新数据...")
        response = requests.get("https://api.gateio.ws/api/v4/spot/tickers")
        if response.status_code == 200:
            tickers = response.json()
            logger.info(f"成功获取 {len(tickers)} 个币种的ticker数据")
            return tickers
        else:
            logger.error(f"获取数据失败，状态码: {response.status_code}")
            return []
    except Exception as e:
        logger.error(f"获取Gate.io数据失败: {str(e)}")
        return []

def populate_historical_data(tickers, hours_back=48):
    """填充历史数据"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # 获取当前时间
        now = datetime.now()
        
        # 清空现有数据（可选）
        # cursor.execute("DELETE FROM price_history")
        # cursor.execute("DELETE FROM coins")
        # logger.info("已清空现有数据")
        
        # 限制处理的币种数量，避免数据库过大
        max_coins = 100
        processed_tickers = tickers[:max_coins] if len(tickers) > max_coins else tickers
        
        # 添加币种信息
        for ticker in processed_tickers:
            symbol = ticker.get("currency_pair")
            if not symbol:
                continue
            
            cursor.execute(
                "INSERT OR REPLACE INTO coins (id, symbol, last_updated) VALUES (?, ?, ?)",
                (symbol, symbol, now.strftime('%Y-%m-%d %H:%M:%S'))
            )
        
        # 为每个币种添加历史数据点
        total_records = 0
        for ticker in processed_tickers:
            symbol = ticker.get("currency_pair")
            if not symbol:
                continue
            
            try:
                current_price = float(ticker.get("last", 0))
                current_volume = float(ticker.get("base_volume", 0))
                
                # 跳过价格为0的币种
                if current_price <= 0:
                    continue
                
                # 生成历史数据点
                for hour in range(hours_back, 0, -1):
                    # 计算时间点
                    timestamp = now - timedelta(hours=hour)
                    sqlite_timestamp = timestamp.strftime('%Y-%m-%d %H:%M:%S')
                    
                    # 生成略有变化的历史价格和交易量
                    # 价格随时间略微上升
                    price_factor = 0.98 + (hour / hours_back) * 0.04
                    historical_price = current_price * price_factor
                    
                    # 交易量随时间略微上升
                    volume_factor = 0.9 + (hour / hours_back) * 0.2
                    historical_volume = current_volume * volume_factor
                    
                    # 插入历史数据
                    cursor.execute(
                        """
                        INSERT OR IGNORE INTO price_history 
                        (symbol, price, volume_24h, change_percentage_24h, timestamp) 
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (symbol, historical_price, historical_volume, 0, sqlite_timestamp)
                    )
                    total_records += 1
                
                # 添加当前数据点
                cursor.execute(
                    """
                    INSERT OR IGNORE INTO price_history 
                    (symbol, price, volume_24h, change_percentage_24h, timestamp) 
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (symbol, current_price, current_volume, 0, now.strftime('%Y-%m-%d %H:%M:%S'))
                )
                total_records += 1
                
            except (ValueError, TypeError) as e:
                logger.warning(f"处理币种 {symbol} 时出错: {str(e)}")
                continue
        
        conn.commit()
        conn.close()
        logger.info(f"成功添加 {total_records} 条历史数据记录")
    except Exception as e:
        logger.error(f"填充历史数据失败: {str(e)}")

def test_historical_data_query():
    """测试历史数据查询"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # 获取一个样本币种
        cursor.execute("SELECT symbol FROM coins LIMIT 1")
        result = cursor.fetchone()
        if not result:
            logger.warning("没有找到任何币种")
            conn.close()
            return False
        
        sample_symbol = result[0]
        logger.info(f"测试币种: {sample_symbol}")
        
        # 测试历史数据查询
        cursor.execute(
            """
            SELECT symbol, price, volume_24h, timestamp
            FROM price_history
            WHERE symbol = ? AND timestamp >= datetime('now', '-24 hours')
            ORDER BY timestamp ASC
            """,
            (sample_symbol,)
        )
        
        results = cursor.fetchall()
        logger.info(f"过去24小时内找到 {len(results)} 条 {sample_symbol} 的历史记录")
        
        if results:
            logger.info("样本数据:")
            for row in results[:5]:
                logger.info(f"  - {dict(row)}")
            
            conn.close()
            return True
        else:
            logger.warning(f"未找到 {sample_symbol} 的历史数据")
            conn.close()
            return False
    except Exception as e:
        logger.error(f"测试历史数据查询失败: {str(e)}")
        return False

def main():
    """主函数"""
    logger.info("开始修复数据库...")
    
    # 检查数据库是否存在
    db_exists = check_db_exists()
    
    # 检查表结构
    check_table_structure()
    
    # 检查现有数据
    coins_count, price_history_count = check_existing_data()
    
    # 修复timestamp格式
    fix_timestamp_format()
    
    # 如果数据不足，获取并填充数据
    if price_history_count < 100:
        logger.info("历史价格数据不足，将获取并填充数据")
        tickers = fetch_gate_io_data()
        if tickers:
            populate_historical_data(tickers)
    
    # 测试历史数据查询
    query_success = test_historical_data_query()
    
    if query_success:
        logger.info("数据库修复成功，历史数据查询正常")
    else:
        logger.warning("数据库可能仍有问题，历史数据查询失败")
    
    logger.info("数据库修复完成")

if __name__ == "__main__":
    main()
