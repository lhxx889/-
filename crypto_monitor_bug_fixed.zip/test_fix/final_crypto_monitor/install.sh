#!/bin/bash

# Gate.io加密货币异动监控系统增强版安装脚本

echo "====================================================="
echo "  Gate.io加密货币异动监控系统增强版安装脚本"
echo "====================================================="
echo ""

# 设置错误处理
set -e
trap 'echo "安装过程中出现错误，请查看上面的错误信息。"; exit 1' ERR

# 检查Python版本
echo "检查Python环境..."
if command -v python3 &>/dev/null; then
    PYTHON_CMD=python3
elif command -v python &>/dev/null; then
    PYTHON_CMD=python
else
    echo "错误: 未找到Python。请先安装Python 3.8或更高版本。"
    exit 1
fi

# 检查Python版本是否>=3.8
PYTHON_VERSION=$($PYTHON_CMD -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]); then
    echo "错误: Python版本必须是3.8或更高版本。当前版本: $PYTHON_VERSION"
    exit 1
fi

echo "Python版本检查通过: $PYTHON_VERSION"
echo ""

# 检测操作系统类型并安装系统依赖
echo "检查系统依赖..."
OS_TYPE="unknown"

if [ -f /etc/debian_version ]; then
    OS_TYPE="debian"
    echo "检测到Debian/Ubuntu系统，安装系统依赖..."
    sudo apt-get update
    sudo apt-get install -y python3-dev python3-pip python3-venv build-essential libssl-dev libffi-dev libfreetype6-dev libpng-dev
elif [ -f /etc/redhat-release ]; then
    OS_TYPE="redhat"
    echo "检测到CentOS/RHEL系统，安装系统依赖..."
    sudo yum install -y python3-devel python3-pip gcc openssl-devel libffi-devel freetype-devel libpng-devel
elif [ "$(uname)" == "Darwin" ]; then
    OS_TYPE="macos"
    echo "检测到macOS系统，安装系统依赖..."
    if ! command -v brew &>/dev/null; then
        echo "警告: 未找到Homebrew。请先安装Homebrew: https://brew.sh/"
    else
        brew install openssl freetype libpng
    fi
else
    echo "警告: 无法确定系统类型，跳过系统依赖安装。如果后续安装失败，请手动安装所需依赖。"
fi

echo "系统类型: $OS_TYPE"
echo ""

# 创建必要的目录
echo "创建必要的目录..."
mkdir -p charts
mkdir -p logs
mkdir -p config

# 询问是否使用虚拟环境
USE_VENV=true
read -p "是否使用Python虚拟环境? (推荐) [Y/n]: " use_venv_input
if [[ "$use_venv_input" =~ ^[Nn]$ ]]; then
    USE_VENV=false
    echo "将直接安装到系统Python环境。"
else
    echo "将使用Python虚拟环境。"
fi

# 创建并激活虚拟环境
if [ "$USE_VENV" = true ]; then
    echo "创建Python虚拟环境..."
    $PYTHON_CMD -m venv venv
    if [ $? -ne 0 ]; then
        echo "错误: 创建虚拟环境失败。请确保已安装venv模块。"
        echo "尝试安装venv模块..."
        if [ "$OS_TYPE" = "debian" ]; then
            sudo apt-get install -y python3-venv
        elif [ "$OS_TYPE" = "redhat" ]; then
            sudo yum install -y python3-venv
        fi
        # 重试创建虚拟环境
        $PYTHON_CMD -m venv venv
        if [ $? -ne 0 ]; then
            echo "错误: 创建虚拟环境仍然失败。请手动安装venv模块。"
            exit 1
        fi
    fi

    # 激活虚拟环境
    echo "激活虚拟环境..."
    if [ -f "venv/bin/activate" ]; then
        source venv/bin/activate
    elif [ -f "venv/Scripts/activate" ]; then
        source venv/Scripts/activate
    else
        echo "错误: 无法找到虚拟环境激活脚本。"
        exit 1
    fi

    # 验证虚拟环境
    if [[ "$VIRTUAL_ENV" == "" ]]; then
        echo "警告: 虚拟环境可能未正确激活。继续安装，但可能安装到系统Python环境。"
    else
        echo "虚拟环境已激活: $VIRTUAL_ENV"
    fi
fi

# 升级pip
echo "升级pip..."
pip install --upgrade pip

# 分步安装依赖
echo "开始分步安装依赖..."

# 安装核心依赖
echo "1. 安装核心依赖..."
if [ -f "requirements-core.txt" ]; then
    pip install -r requirements-core.txt
    if [ $? -ne 0 ]; then
        echo "警告: 批量安装核心依赖失败，尝试逐个安装..."
        while IFS= read -r line || [[ -n "$line" ]]; do
            # 跳过空行和注释
            if [[ -z "$line" || "$line" =~ ^# ]]; then
                continue
            fi
            echo "安装: $line"
            pip install "$line"
            if [ $? -ne 0 ]; then
                echo "警告: 安装 $line 失败，继续安装其他依赖..."
            fi
        done < requirements-core.txt
    fi
else
    echo "警告: 未找到requirements-core.txt，跳过核心依赖安装。"
fi

# 安装增强功能依赖
echo "2. 安装增强功能依赖..."
if [ -f "requirements-enhanced.txt" ]; then
    pip install -r requirements-enhanced.txt
    if [ $? -ne 0 ]; then
        echo "警告: 批量安装增强功能依赖失败，尝试逐个安装..."
        while IFS= read -r line || [[ -n "$line" ]]; do
            # 跳过空行和注释
            if [[ -z "$line" || "$line" =~ ^# ]]; then
                continue
            fi
            echo "安装: $line"
            pip install "$line"
            if [ $? -ne 0 ]; then
                echo "警告: 安装 $line 失败，继续安装其他依赖..."
            fi
        done < requirements-enhanced.txt
    fi
else
    echo "警告: 未找到requirements-enhanced.txt，跳过增强功能依赖安装。"
fi

# 安装开发和测试依赖
echo "3. 安装开发和测试依赖..."
if [ -f "requirements-dev.txt" ]; then
    pip install -r requirements-dev.txt
    if [ $? -ne 0 ]; then
        echo "警告: 批量安装开发和测试依赖失败，尝试逐个安装..."
        while IFS= read -r line || [[ -n "$line" ]]; do
            # 跳过空行和注释
            if [[ -z "$line" || "$line" =~ ^# ]]; then
                continue
            fi
            echo "安装: $line"
            pip install "$line"
            if [ $? -ne 0 ]; then
                echo "警告: 安装 $line 失败，继续安装其他依赖..."
            fi
        done < requirements-dev.txt
    fi
else
    echo "警告: 未找到requirements-dev.txt，跳过开发和测试依赖安装。"
fi

# 检查依赖冲突
echo "检查依赖冲突..."
pip check
if [ $? -ne 0 ]; then
    echo "警告: 检测到依赖冲突，尝试解决..."
    pip install --upgrade -r requirements.txt
    pip check
    if [ $? -ne 0 ]; then
        echo "警告: 依赖冲突仍然存在，但将继续安装过程。系统可能无法正常工作。"
    else
        echo "依赖冲突已解决。"
    fi
else
    echo "依赖检查通过，未发现冲突。"
fi

echo "依赖库安装完成。"
echo ""

# 运行简化版设置向导
echo "运行设置向导..."

# 创建必要的目录
mkdir -p config

# 配置Telegram（简化版，直接写入文件）
echo "===== Telegram配置 ====="
echo "1. 添加新的Telegram账号"
echo "2. 跳过Telegram配置"
read -p "请选择: " choice

if [ "$choice" == "1" ]; then
    read -p "账号名称: " name
    read -p "Telegram Bot Token: " token
    read -p "Telegram Chat ID: " chat_id
    
    # 直接创建Telegram配置文件，避免Python子进程
    cat > telegram_accounts.json << EOF
{
  "accounts": {
    "$name": {
      "token": "$token",
      "chat_id": "$chat_id",
      "is_active": true,
      "consecutive_errors": 0
    }
  },
  "current": "$name"
}
EOF
    echo "Telegram账号已添加"
fi

# 配置异动阈值（简化版，直接写入文件）
echo "===== 异动阈值配置 ====="
read -p "价格异动阈值 (百分比，默认: 30): " price_threshold
price_threshold=${price_threshold:-30}

read -p "交易量异动阈值 (百分比，默认: 200): " volume_threshold
volume_threshold=${volume_threshold:-200}

# 创建配置文件
cat > config.json << EOF
{
  "price_threshold": $price_threshold,
  "volume_threshold": $volume_threshold,
  "check_interval": 50,
  "excluded_symbols": [],
  "api_key": "",
  "api_secret": ""
}
EOF
echo "异动阈值已配置"

# 配置时区（简化版，直接写入文件）
cat > timezone_config.json << EOF
{
  "timezone": "Asia/Shanghai"
}
EOF
echo "时区已设置为: Asia/Shanghai"

# 创建启动脚本
echo "创建启动脚本..."
cat > start_monitor.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "venv/Scripts/activate" ]; then
    source venv/Scripts/activate
fi

# 启动监控系统
python main.py
EOF

chmod +x start_monitor.sh

# 创建服务文件（如果是Linux系统）
if [ "$(uname)" == "Linux" ]; then
    echo "检测到Linux系统，创建systemd服务文件..."
    
    # 获取当前目录的绝对路径
    INSTALL_DIR=$(pwd)
    
    # 创建服务文件
    cat > crypto_monitor.service << EOF
[Unit]
Description=Gate.io Crypto Monitor Service
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/main.py
Restart=on-failure
RestartSec=10
StandardOutput=append:$INSTALL_DIR/logs/service.log
StandardError=append:$INSTALL_DIR/logs/service_error.log

[Install]
WantedBy=multi-user.target
EOF

    echo "服务文件已创建: $INSTALL_DIR/crypto_monitor.service"
    echo "要安装为系统服务，请运行:"
    echo "sudo cp $INSTALL_DIR/crypto_monitor.service /etc/systemd/system/"
    echo "sudo systemctl daemon-reload"
    echo "sudo systemctl enable crypto_monitor.service"
    echo "sudo systemctl start crypto_monitor.service"
    echo ""
fi

# 确保快捷启动脚本可执行
chmod +x crypto_monitor.sh

echo "====================================================="
echo "  安装完成！"
echo "====================================================="
echo ""
echo "您可以使用以下命令启动监控系统:"
echo "  ./crypto_monitor.sh start"
echo ""
echo "查看系统状态:"
echo "  ./crypto_monitor.sh status"
echo ""
echo "查看日志:"
echo "  ./crypto_monitor.sh logs"
echo ""
echo "注意: Gate.io API是可选的，系统可以在不提供API密钥的情况下正常工作"
echo "如需配置API，请编辑config.json文件添加api_key和api_secret"
echo ""
echo "祝您使用愉快！"
echo "====================================================="
