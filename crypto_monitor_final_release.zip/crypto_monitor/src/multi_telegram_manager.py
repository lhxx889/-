"""
Gate.io加密货币异动监控系统 - 多Telegram账号管理器
支持多个Telegram账号轮换发送消息，避免API限制
"""

import logging
import time
import json
import os
import requests
import random
import threading
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from collections import deque

# 配置日志
logger = logging.getLogger("multi_telegram_manager")

class TelegramAccount:
    """单个Telegram账号的配置和状态"""
    
    def __init__(self, name: str, token: str, chat_id: str):
        """
        初始化Telegram账号
        
        Args:
            name: 账号名称
            token: Telegram Bot Token
            chat_id: Telegram Chat ID
        """
        self.name = name
        self.token = token
        self.chat_id = chat_id
        self.last_used_time = 0
        self.consecutive_errors = 0
        self.is_active = True
        self.request_timestamps = deque()
        self.lock = threading.Lock()
    
    def can_make_request(self, max_requests: int = 20, time_window: int = 60) -> bool:
        """
        检查是否可以发送请求
        
        Args:
            max_requests: 时间窗口内允许的最大请求数
            time_window: 时间窗口大小（秒）
            
        Returns:
            是否可以发送请求
        """
        with self.lock:
            # 如果账号不活跃，不能发送请求
            if not self.is_active:
                return False
            
            # 清理过期的时间戳
            current_time = time.time()
            while self.request_timestamps and self.request_timestamps[0] < current_time - time_window:
                self.request_timestamps.popleft()
            
            # 检查是否超过限制
            return len(self.request_timestamps) < max_requests
    
    def record_request(self) -> None:
        """记录一次请求"""
        with self.lock:
            self.request_timestamps.append(time.time())
            self.last_used_time = time.time()
    
    def record_error(self) -> None:
        """记录一次错误"""
        with self.lock:
            self.consecutive_errors += 1
            
            # 如果连续错误过多，暂时禁用账号
            if self.consecutive_errors >= 5:
                logger.warning(f"Telegram账号 {self.name} 连续错误过多，暂时禁用")
                self.is_active = False
    
    def record_success(self) -> None:
        """记录一次成功"""
        with self.lock:
            self.consecutive_errors = 0
            
            # 如果账号被禁用但成功发送，重新启用
            if not self.is_active:
                logger.info(f"Telegram账号 {self.name} 恢复正常，重新启用")
                self.is_active = True
    
    def get_cooldown_time(self, max_requests: int = 20, time_window: int = 60) -> float:
        """
        获取冷却时间
        
        Args:
            max_requests: 时间窗口内允许的最大请求数
            time_window: 时间窗口大小（秒）
            
        Returns:
            冷却时间（秒）
        """
        with self.lock:
            if not self.request_timestamps:
                return 0
            
            current_time = time.time()
            # 清理过期的时间戳
            while self.request_timestamps and self.request_timestamps[0] < current_time - time_window:
                self.request_timestamps.popleft()
            
            # 如果请求数未达到限制，无需冷却
            if len(self.request_timestamps) < max_requests:
                return 0
            
            # 计算需要冷却的时间
            oldest_timestamp = self.request_timestamps[0]
            cooldown_time = oldest_timestamp + time_window - current_time
            
            return max(0, cooldown_time)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典
        
        Returns:
            字典表示
        """
        return {
            "name": self.name,
            "token": self.token,
            "chat_id": self.chat_id,
            "is_active": self.is_active,
            "consecutive_errors": self.consecutive_errors
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TelegramAccount':
        """
        从字典创建账号
        
        Args:
            data: 字典数据
            
        Returns:
            Telegram账号
        """
        account = cls(
            name=data.get("name", "未命名"),
            token=data.get("token", ""),
            chat_id=data.get("chat_id", "")
        )
        account.is_active = data.get("is_active", True)
        account.consecutive_errors = data.get("consecutive_errors", 0)
        return account

class MultiTelegramManager:
    """多Telegram账号管理器"""
    
    def __init__(self, config_file: str = "telegram_accounts.json"):
        """
        初始化多Telegram账号管理器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.accounts: Dict[str, TelegramAccount] = {}
        self.lock = threading.Lock()
        
        # 加载配置
        self._load_config()
        
        logger.info(f"多Telegram账号管理器初始化完成，加载了 {len(self.accounts)} 个账号")
    
    def _load_config(self) -> None:
        """从配置文件加载账号配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # 加载账号
                    for account_data in config.get("accounts", []):
                        account = TelegramAccount.from_dict(account_data)
                        self.accounts[account.name] = account
                    
                    logger.info(f"从配置文件加载了 {len(self.accounts)} 个Telegram账号")
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，将创建默认配置")
                self._create_default_config()
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
            self._create_default_config()
    
    def _create_default_config(self) -> None:
        """创建默认配置"""
        # 检查是否有旧的单账号配置
        old_config_file = "telegram_config.json"
        if os.path.exists(old_config_file):
            try:
                with open(old_config_file, 'r') as f:
                    old_config = json.load(f)
                    token = old_config.get("token")
                    chat_id = old_config.get("chat_id")
                    
                    if token and chat_id:
                        # 创建默认账号
                        account = TelegramAccount(
                            name="default",
                            token=token,
                            chat_id=chat_id
                        )
                        self.accounts["default"] = account
                        logger.info("从旧配置创建了默认Telegram账号")
                        
                        # 保存新配置
                        self.save_config()
                        return
            except Exception as e:
                logger.error(f"读取旧配置失败: {str(e)}")
        
        # 如果没有旧配置，创建空配置
        self.save_config()
    
    def save_config(self) -> bool:
        """
        保存配置到文件
        
        Returns:
            保存是否成功
        """
        try:
            with self.lock:
                # 转换账号为字典
                accounts_data = [account.to_dict() for account in self.accounts.values()]
                
                # 创建配置
                config = {
                    "accounts": accounts_data
                }
                
                # 保存到文件
                with open(self.config_file, 'w') as f:
                    json.dump(config, f, indent=4)
                
                logger.info(f"保存了 {len(self.accounts)} 个Telegram账号到配置文件")
                return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def add_account(self, name: str, token: str, chat_id: str) -> bool:
        """
        添加Telegram账号
        
        Args:
            name: 账号名称
            token: Telegram Bot Token
            chat_id: Telegram Chat ID
            
        Returns:
            添加是否成功
        """
        with self.lock:
            # 检查账号是否已存在
            if name in self.accounts:
                logger.warning(f"Telegram账号 {name} 已存在，将更新")
            
            # 创建账号
            account = TelegramAccount(name=name, token=token, chat_id=chat_id)
            self.accounts[name] = account
            
            # 保存配置
            success = self.save_config()
            
            if success:
                logger.info(f"添加Telegram账号 {name} 成功")
            else:
                logger.error(f"添加Telegram账号 {name} 失败")
            
            return success
    
    def remove_account(self, name: str) -> bool:
        """
        删除Telegram账号
        
        Args:
            name: 账号名称
            
        Returns:
            删除是否成功
        """
        with self.lock:
            # 检查账号是否存在
            if name not in self.accounts:
                logger.warning(f"Telegram账号 {name} 不存在，无法删除")
                return False
            
            # 删除账号
            del self.accounts[name]
            
            # 保存配置
            success = self.save_config()
            
            if success:
                logger.info(f"删除Telegram账号 {name} 成功")
            else:
                logger.error(f"删除Telegram账号 {name} 失败")
            
            return success
    
    def get_account(self, name: str) -> Optional[TelegramAccount]:
        """
        获取指定名称的账号
        
        Args:
            name: 账号名称
            
        Returns:
            Telegram账号，如果不存在则为None
        """
        return self.accounts.get(name)
    
    def get_best_account(self) -> Optional[TelegramAccount]:
        """
        获取最佳可用账号
        
        Returns:
            最佳可用账号，如果没有可用账号则为None
        """
        with self.lock:
            if not self.accounts:
                logger.warning("没有配置Telegram账号")
                return None
            
            # 筛选活跃账号
            active_accounts = [account for account in self.accounts.values() if account.is_active]
            if not active_accounts:
                logger.warning("没有活跃的Telegram账号")
                return None
            
            # 按冷却时间和上次使用时间排序
            sorted_accounts = sorted(
                active_accounts,
                key=lambda a: (a.get_cooldown_time(), a.last_used_time)
            )
            
            # 返回冷却时间最短且最久未使用的账号
            best_account = sorted_accounts[0]
            
            # 如果最佳账号仍在冷却，记录日志
            cooldown_time = best_account.get_cooldown_time()
            if cooldown_time > 0:
                logger.info(f"最佳账号 {best_account.name} 仍在冷却，剩余 {cooldown_time:.2f} 秒")
            
            return best_account
    
    def test_account(self, name: str) -> bool:
        """
        测试账号连接
        
        Args:
            name: 账号名称
            
        Returns:
            测试是否成功
        """
        account = self.get_account(name)
        if not account:
            logger.warning(f"Telegram账号 {name} 不存在，无法测试")
            return False
        
        try:
            url = f"https://api.telegram.org/bot{account.token}/getMe"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get("ok"):
                logger.info(f"Telegram账号 {name} 连接测试成功，机器人名称: {data.get('result', {}).get('username')}")
                account.record_success()
                return True
            else:
                logger.warning(f"Telegram账号 {name} 连接测试失败: {data.get('description')}")
                account.record_error()
                return False
        except Exception as e:
            logger.error(f"Telegram账号 {name} 连接测试失败: {str(e)}")
            account.record_error()
            return False
    
    def test_all_accounts(self) -> Dict[str, bool]:
        """
        测试所有账号连接
        
        Returns:
            账号名称到测试结果的映射
        """
        results = {}
        for name in self.accounts:
            results[name] = self.test_account(name)
        return results
    
    def send_message(self, text: str, parse_mode: str = "HTML", specific_account: str = None) -> Tuple[bool, str]:
        """
        发送消息，自动选择最佳账号
        
        Args:
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            specific_account: 指定使用的账号名称，如果为None则自动选择
            
        Returns:
            (发送是否成功, 使用的账号名称)
        """
        # 如果指定了账号，使用指定账号
        if specific_account:
            account = self.get_account(specific_account)
            if not account:
                logger.warning(f"指定的Telegram账号 {specific_account} 不存在")
                return False, ""
            
            success = self._send_message_with_account(account, text, parse_mode)
            return success, account.name
        
        # 尝试最多3次，每次选择最佳账号
        max_attempts = 3
        for attempt in range(max_attempts):
            account = self.get_best_account()
            if not account:
                logger.warning("没有可用的Telegram账号")
                return False, ""
            
            # 检查账号是否需要冷却
            cooldown_time = account.get_cooldown_time()
            if cooldown_time > 0:
                logger.info(f"账号 {account.name} 需要冷却 {cooldown_time:.2f} 秒")
                time.sleep(cooldown_time)
            
            # 发送消息
            success = self._send_message_with_account(account, text, parse_mode)
            if success:
                return True, account.name
            
            # 如果失败，等待一段时间再尝试下一个账号
            if attempt < max_attempts - 1:
                wait_time = 2 ** attempt  # 指数退避
                logger.info(f"等待 {wait_time} 秒后尝试下一个账号")
                time.sleep(wait_time)
        
        logger.error(f"所有尝试都失败，无法发送消息")
        return False, ""
    
    def _send_message_with_account(self, account: TelegramAccount, text: str, parse_mode: str = "HTML") -> bool:
        """
        使用指定账号发送消息
        
        Args:
            account: Telegram账号
            text: 消息文本
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not account.is_active:
            logger.warning(f"Telegram账号 {account.name} 不活跃，无法发送消息")
            return False
        
        logger.info(f"使用账号 {account.name} 发送消息: {text[:50]}...")
        
        url = f"https://api.telegram.org/bot{account.token}/sendMessage"
        data = {
            "chat_id": account.chat_id,
            "text": text,
            "parse_mode": parse_mode
        }
        
        max_retries = 3
        base_delay = 2  # 初始延迟2秒
        
        for retry in range(max_retries):
            try:
                # 记录请求
                account.record_request()
                
                # 发送请求
                response = requests.post(url, data=data, timeout=30)
                response.raise_for_status()
                
                # 记录成功
                account.record_success()
                logger.info(f"使用账号 {account.name} 发送消息成功")
                return True
            except requests.exceptions.RequestException as e:
                # 记录错误
                account.record_error()
                
                # 计算指数退避延迟
                delay = base_delay * (2 ** retry) + random.uniform(0, 1)
                
                # 如果是429错误（Too Many Requests），从响应中获取推荐的等待时间
                if hasattr(e, 'response') and e.response is not None and e.response.status_code == 429:
                    try:
                        retry_after = e.response.json().get('parameters', {}).get('retry_after', delay)
                        delay = max(delay, retry_after + random.uniform(1, 3))
                    except:
                        pass
                
                logger.warning(f"使用账号 {account.name} 发送消息失败 (尝试 {retry+1}/{max_retries}): {str(e)}")
                
                if retry < max_retries - 1:
                    logger.info(f"等待 {delay:.2f} 秒后重试...")
                    time.sleep(delay)
        
        logger.error(f"使用账号 {account.name} 发送消息最终失败")
        return False
    
    def send_photo(self, photo_path: str, caption: str = None, parse_mode: str = "HTML", specific_account: str = None) -> Tuple[bool, str]:
        """
        发送图片，自动选择最佳账号
        
        Args:
            photo_path: 图片文件路径
            caption: 图片说明
            parse_mode: 解析模式，可选值: HTML, Markdown
            specific_account: 指定使用的账号名称，如果为None则自动选择
            
        Returns:
            (发送是否成功, 使用的账号名称)
        """
        # 检查图片是否存在
        if not os.path.exists(photo_path):
            logger.warning(f"图片文件不存在: {photo_path}")
            return False, ""
        
        # 如果指定了账号，使用指定账号
        if specific_account:
            account = self.get_account(specific_account)
            if not account:
                logger.warning(f"指定的Telegram账号 {specific_account} 不存在")
                return False, ""
            
            success = self._send_photo_with_account(account, photo_path, caption, parse_mode)
            return success, account.name
        
        # 尝试最多3次，每次选择最佳账号
        max_attempts = 3
        for attempt in range(max_attempts):
            account = self.get_best_account()
            if not account:
                logger.warning("没有可用的Telegram账号")
                return False, ""
            
            # 检查账号是否需要冷却
            cooldown_time = account.get_cooldown_time()
            if cooldown_time > 0:
                logger.info(f"账号 {account.name} 需要冷却 {cooldown_time:.2f} 秒")
                time.sleep(cooldown_time)
            
            # 发送图片
            success = self._send_photo_with_account(account, photo_path, caption, parse_mode)
            if success:
                return True, account.name
            
            # 如果失败，等待一段时间再尝试下一个账号
            if attempt < max_attempts - 1:
                wait_time = 2 ** attempt  # 指数退避
                logger.info(f"等待 {wait_time} 秒后尝试下一个账号")
                time.sleep(wait_time)
        
        logger.error(f"所有尝试都失败，无法发送图片")
        return False, ""
    
    def _send_photo_with_account(self, account: TelegramAccount, photo_path: str, caption: str = None, parse_mode: str = "HTML") -> bool:
        """
        使用指定账号发送图片
        
        Args:
            account: Telegram账号
            photo_path: 图片文件路径
            caption: 图片说明
            parse_mode: 解析模式，可选值: HTML, Markdown
            
        Returns:
            发送是否成功
        """
        if not account.is_active:
            logger.warning(f"Telegram账号 {account.name} 不活跃，无法发送图片")
            return False
        
        logger.info(f"使用账号 {account.name} 发送图片: {photo_path}")
        
        url = f"https://api.telegram.org/bot{account.token}/sendPhoto"
        
        # 准备数据
        data = {
            "chat_id": account.chat_id
        }
        if caption:
            data["caption"] = caption
            data["parse_mode"] = parse_mode
        
        max_retries = 3
        base_delay = 2  # 初始延迟2秒
        
        for retry in range(max_retries):
            try:
                # 记录请求
                account.record_request()
                
                # 发送请求
                with open(photo_path, 'rb') as photo_file:
                    files = {
                        "photo": photo_file
                    }
                    response = requests.post(url, data=data, files=files, timeout=60)
                    response.raise_for_status()
                
                # 记录成功
                account.record_success()
                logger.info(f"使用账号 {account.name} 发送图片成功")
                return True
            except requests.exceptions.RequestException as e:
                # 记录错误
                account.record_error()
                
                # 计算指数退避延迟
                delay = base_delay * (2 ** retry) + random.uniform(0, 1)
                
                # 如果是429错误（Too Many Requests），从响应中获取推荐的等待时间
                if hasattr(e, 'response') and e.response is not None and e.response.status_code == 429:
                    try:
                        retry_after = e.response.json().get('parameters', {}).get('retry_after', delay)
                        delay = max(delay, retry_after + random.uniform(1, 3))
                    except:
                        pass
                
                logger.warning(f"使用账号 {account.name} 发送图片失败 (尝试 {retry+1}/{max_retries}): {str(e)}")
                
                if retry < max_retries - 1:
                    logger.info(f"等待 {delay:.2f} 秒后重试...")
                    time.sleep(delay)
        
        logger.error(f"使用账号 {account.name} 发送图片最终失败")
        return False
    
    def get_account_count(self) -> int:
        """
        获取账号数量
        
        Returns:
            账号数量
        """
        return len(self.accounts)
    
    def get_active_account_count(self) -> int:
        """
        获取活跃账号数量
        
        Returns:
            活跃账号数量
        """
        return sum(1 for account in self.accounts.values() if account.is_active)
    
    def get_account_names(self) -> List[str]:
        """
        获取所有账号名称
        
        Returns:
            账号名称列表
        """
        return list(self.accounts.keys())
    
    def get_account_status(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有账号状态
        
        Returns:
            账号名称到状态的映射
        """
        status = {}
        for name, account in self.accounts.items():
            status[name] = {
                "is_active": account.is_active,
                "consecutive_errors": account.consecutive_errors,
                "cooldown_time": account.get_cooldown_time(),
                "last_used_time": account.last_used_time
            }
        return status

# 创建全局实例
telegram_manager = MultiTelegramManager()

if __name__ == "__main__":
    # 测试代码
    logging.basicConfig(level=logging.INFO)
    
    # 添加测试账号
    telegram_manager.add_account("test1", "test_token1", "test_chat_id1")
    telegram_manager.add_account("test2", "test_token2", "test_chat_id2")
    
    # 测试账号
    telegram_manager.test_all_accounts()
    
    # 获取账号状态
    print(telegram_manager.get_account_status())
