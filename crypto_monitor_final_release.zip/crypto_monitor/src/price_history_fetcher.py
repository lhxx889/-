"""
Gate.io加密货币异动监控系统 - 历史价格数据获取模块
获取币种的历史价格数据，用于图表生成和价格分析
"""

import logging
import requests
import time
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

# 配置日志
logger = logging.getLogger("price_history_fetcher")

class PriceHistoryFetcher:
    """历史价格数据获取器，用于获取币种的历史价格数据"""
    
    def __init__(self, base_url: str = "https://api.gateio.ws/api/v4"):
        """
        初始化历史价格数据获取器
        
        Args:
            base_url: Gate.io API基础URL
        """
        self.base_url = base_url
        logger.info("历史价格数据获取模块初始化完成")
    
    def get_price_history(self, symbol: str, interval: str = "1h", limit: int = 24) -> List[Dict[str, Any]]:
        """
        获取币种的历史价格数据
        
        Args:
            symbol: 币种符号，如 BTC_USDT
            interval: 时间间隔，可选值: 1m, 5m, 15m, 30m, 1h, 4h, 8h, 1d, 7d
            limit: 返回记录数量限制，最大1000
            
        Returns:
            历史价格数据列表，每项包含 timestamp, open, high, low, close, volume 等字段
        """
        logger.info(f"获取 {symbol} 的历史价格数据，间隔: {interval}，数量: {limit}")
        
        try:
            # 构建请求URL
            url = f"{self.base_url}/spot/candlesticks"
            
            # 构建请求参数
            params = {
                "currency_pair": symbol,
                "interval": interval,
                "limit": limit
            }
            
            # 发送请求
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            # 处理响应数据
            result = []
            for item in data:
                # Gate.io API返回的数据格式: [timestamp, volume, close, high, low, open]
                timestamp = int(item[0])
                volume = float(item[1])
                close = float(item[2])
                high = float(item[3])
                low = float(item[4])
                open_price = float(item[5])
                
                # 转换为标准格式
                result.append({
                    "timestamp": timestamp,
                    "datetime": datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S"),
                    "open": open_price,
                    "high": high,
                    "low": low,
                    "close": close,
                    "price": close,  # 使用收盘价作为当前价格
                    "volume": volume
                })
            
            # 按时间排序
            result.sort(key=lambda x: x["timestamp"])
            
            logger.info(f"成功获取 {symbol} 的历史价格数据，共 {len(result)} 条记录")
            return result
        except Exception as e:
            logger.error(f"获取 {symbol} 的历史价格数据失败: {str(e)}")
            return []
    
    def get_price_change(self, symbol: str, hours: int = 24) -> Dict[str, Any]:
        """
        获取币种在指定时间段内的价格变化
        
        Args:
            symbol: 币种符号，如 BTC_USDT
            hours: 时间段（小时）
            
        Returns:
            价格变化信息字典，包含起始价格、当前价格、变化百分比等
        """
        logger.info(f"获取 {symbol} 在过去 {hours} 小时内的价格变化")
        
        # 初始化结果
        result = {
            "symbol": symbol,
            "start_price": None,
            "current_price": None,
            "change_percent": None,
            "highest_price": None,
            "lowest_price": None,
            "volume": None
        }
        
        try:
            # 获取历史价格数据
            interval = "1h"  # 使用1小时间隔
            if hours > 48:
                interval = "4h"  # 如果时间段较长，使用4小时间隔
            if hours > 168:
                interval = "1d"  # 如果时间段超过一周，使用1天间隔
            
            # 计算需要获取的记录数量
            limit = hours
            if interval == "4h":
                limit = (hours + 3) // 4
            if interval == "1d":
                limit = (hours + 23) // 24
            
            # 获取历史价格数据
            history = self.get_price_history(symbol, interval, limit)
            
            if history:
                # 获取起始价格和当前价格
                start_price = history[0]["price"]
                current_price = history[-1]["price"]
                
                # 计算价格变化百分比
                change_percent = ((current_price - start_price) / start_price) * 100
                
                # 获取最高价和最低价
                highest_price = max(item["high"] for item in history)
                lowest_price = min(item["low"] for item in history)
                
                # 计算总交易量
                volume = sum(item["volume"] for item in history)
                
                # 更新结果
                result["start_price"] = start_price
                result["current_price"] = current_price
                result["change_percent"] = change_percent
                result["highest_price"] = highest_price
                result["lowest_price"] = lowest_price
                result["volume"] = volume
                
                logger.info(f"{symbol} 在过去 {hours} 小时内的价格变化: {change_percent:.2f}%")
            else:
                logger.warning(f"无法获取 {symbol} 的历史价格数据")
            
            return result
        except Exception as e:
            logger.error(f"获取 {symbol} 的价格变化失败: {str(e)}")
            return result
    
    def get_price_volatility(self, symbol: str, days: int = 7) -> float:
        """
        计算币种在指定天数内的价格波动率
        
        Args:
            symbol: 币种符号，如 BTC_USDT
            days: 天数
            
        Returns:
            价格波动率（百分比）
        """
        logger.info(f"计算 {symbol} 在过去 {days} 天内的价格波动率")
        
        try:
            # 获取历史价格数据
            history = self.get_price_history(symbol, "1d", days)
            
            if not history:
                logger.warning(f"无法获取 {symbol} 的历史价格数据")
                return 0.0
            
            # 计算每日收益率
            returns = []
            for i in range(1, len(history)):
                prev_price = history[i-1]["close"]
                curr_price = history[i]["close"]
                daily_return = (curr_price - prev_price) / prev_price
                returns.append(daily_return)
            
            # 计算标准差
            if not returns:
                return 0.0
            
            mean = sum(returns) / len(returns)
            variance = sum((r - mean) ** 2 for r in returns) / len(returns)
            std_dev = variance ** 0.5
            
            # 转换为年化波动率（假设一年有252个交易日）
            annualized_volatility = std_dev * (252 ** 0.5)
            
            # 转换为百分比
            volatility_percent = annualized_volatility * 100
            
            logger.info(f"{symbol} 在过去 {days} 天内的价格波动率: {volatility_percent:.2f}%")
            return volatility_percent
        except Exception as e:
            logger.error(f"计算 {symbol} 的价格波动率失败: {str(e)}")
            return 0.0

# 创建全局实例
price_history_fetcher = PriceHistoryFetcher()

if __name__ == "__main__":
    # 测试代码
    logging.basicConfig(level=logging.INFO)
    
    # 测试获取历史价格数据
    symbol = "BTC_USDT"
    history = price_history_fetcher.get_price_history(symbol, "1h", 24)
    print(f"{symbol} 24小时历史价格数据:")
    for item in history[-5:]:  # 只显示最近5条记录
        print(f"时间: {item['datetime']}, 价格: {item['price']}, 交易量: {item['volume']}")
    
    # 测试获取价格变化
    price_change = price_history_fetcher.get_price_change(symbol, 24)
    print(f"\n{symbol} 24小时价格变化:")
    print(f"起始价格: {price_change['start_price']}")
    print(f"当前价格: {price_change['current_price']}")
    print(f"变化百分比: {price_change['change_percent']:.2f}%")
    print(f"最高价: {price_change['highest_price']}")
    print(f"最低价: {price_change['lowest_price']}")
    print(f"总交易量: {price_change['volume']}")
    
    # 测试计算价格波动率
    volatility = price_history_fetcher.get_price_volatility(symbol, 7)
    print(f"\n{symbol} 7天价格波动率: {volatility:.2f}%")
