# 主程序入口
# main.py

import os
import sys
import logging
import time
import signal
import json
from datetime import datetime

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("crypto_monitor")

# 导入模块
try:
    from price_monitor import PriceMonitor
    from announcement_monitor import AnnouncementMonitor
    from coin_detail_enricher import CoinDetailEnricher
    from telegram_bot import TelegramBot
    from quick_settings import ConfigManager
except ImportError as e:
    logger.error(f"导入模块失败: {e}")
    logger.error("请确保已安装所有依赖，运行: pip install -r requirements.txt")
    sys.exit(1)

class CryptoMonitor:
    """加密货币监控系统主类"""
    
    def __init__(self, config_file="config.json"):
        """初始化监控系统
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.running = False
        self.config_manager = None
        self.price_monitor = None
        self.announcement_monitor = None
        self.coin_enricher = None
        self.telegram_bot = None
        
        # 注册信号处理
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        # 初始化组件
        self._init_components()
    
    def _init_components(self):
        """初始化各个组件"""
        try:
            logger.info("初始化配置管理器...")
            self.config_manager = ConfigManager(self.config_file)
            
            # 验证配置
            issues = self.config_manager.validate_config()
            if issues:
                logger.warning("配置验证发现以下问题:")
                for issue in issues:
                    logger.warning(f"- {issue}")
                logger.warning("请使用快速设置向导完成配置: python -m quick_settings")
            
            # 初始化各模块
            logger.info("初始化价格监控模块...")
            self.price_monitor = PriceMonitor(self.config_manager)
            
            logger.info("初始化公告监控模块...")
            self.announcement_monitor = AnnouncementMonitor(self.config_manager)
            
            logger.info("初始化币种详情模块...")
            self.coin_enricher = CoinDetailEnricher(self.config_manager)
            
            logger.info("初始化Telegram机器人...")
            self.telegram_bot = TelegramBot(
                self.config_manager,
                self.price_monitor,
                self.announcement_monitor,
                self.coin_enricher
            )
            
            logger.info("所有组件初始化完成")
        except Exception as e:
            logger.error(f"初始化组件失败: {e}")
            raise
    
    def start(self):
        """启动监控系统"""
        if self.running:
            logger.warning("监控系统已在运行中")
            return
        
        try:
            logger.info("启动监控系统...")
            self.running = True
            
            # 启动Telegram机器人
            self.telegram_bot.start()
            
            # 启动价格监控
            self.price_monitor.start()
            
            # 启动公告监控
            self.announcement_monitor.start()
            
            logger.info("监控系统已启动")
            
            # 保持主线程运行
            while self.running:
                time.sleep(1)
        except Exception as e:
            logger.error(f"启动监控系统失败: {e}")
            self.stop()
    
    def stop(self):
        """停止监控系统"""
        if not self.running:
            return
        
        logger.info("停止监控系统...")
        self.running = False
        
        # 停止各组件
        if self.telegram_bot:
            self.telegram_bot.stop()
        
        if self.price_monitor:
            self.price_monitor.stop()
        
        if self.announcement_monitor:
            self.announcement_monitor.stop()
        
        logger.info("监控系统已停止")
    
    def _signal_handler(self, sig, frame):
        """处理信号"""
        logger.info(f"接收到信号 {sig}，准备停止...")
        self.stop()
        sys.exit(0)


def main():
    """主函数"""
    print("=" * 50)
    print("    加密货币监控系统    ")
    print("=" * 50)
    print(f"启动时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)
    
    # 检查配置文件
    config_file = "config.json"
    if not os.path.exists(config_file):
        print(f"配置文件 {config_file} 不存在，将创建默认配置")
        try:
            config_manager = ConfigManager(config_file)
            config_manager.save_config()
            print("已创建默认配置文件，请使用快速设置向导完成配置")
            print("运行: python -m quick_settings")
            return
        except Exception as e:
            print(f"创建配置文件失败: {e}")
            return
    
    # 创建并启动监控系统
    try:
        monitor = CryptoMonitor(config_file)
        monitor.start()
    except KeyboardInterrupt:
        print("\n接收到退出信号，正在停止...")
    except Exception as e:
        logger.error(f"运行失败: {e}")
        print(f"运行失败: {e}")


if __name__ == "__main__":
    main()
