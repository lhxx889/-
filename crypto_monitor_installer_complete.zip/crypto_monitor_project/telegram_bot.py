# Telegram机器人模块
# telegram_bot.py

import logging
import time
import threading
import json
import traceback
import re
from datetime import datetime
from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext, CallbackQueryHandler
import matplotlib.pyplot as plt
import io

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("telegram_bot")

class TelegramBot:
    """Telegram机器人模块，负责与用户交互和发送通知"""
    
    def __init__(self, config_manager, price_monitor, announcement_monitor, coin_enricher):
        """初始化Telegram机器人模块
        
        Args:
            config_manager: ConfigManager实例
            price_monitor: PriceMonitor实例
            announcement_monitor: AnnouncementMonitor实例
            coin_enricher: CoinDetailEnricher实例
        """
        self.config_manager = config_manager
        self.config = config_manager.get_config()
        self.price_monitor = price_monitor
        self.announcement_monitor = announcement_monitor
        self.coin_enricher = coin_enricher
        self.running = False
        self.updater = None
        self.bots = {}
        self.default_bot_token = None
        
        # 初始化机器人
        self._init_bots()
        
        # 注册价格监控回调
        self.price_monitor._trigger_alert = self._send_price_alert
        self.price_monitor._trigger_custom_alert = self._send_custom_alert
        
        # 注册公告监控回调
        self.announcement_monitor._trigger_announcement_notification = self._send_announcement_notification
        self.announcement_monitor._trigger_new_listing_notification = self._send_new_listing_notification
    
    def _init_bots(self):
        """初始化Telegram机器人"""
        try:
            telegram_config = self.config.get("telegram", {})
            bots_config = telegram_config.get("bots", [])
            self.default_bot_token = telegram_config.get("default_bot_token")
            
            if not bots_config:
                logger.warning("未配置Telegram机器人，无法发送通知")
                return
            
            for bot_config in bots_config:
                bot_name = bot_config.get("name", "")
                token_path = f"bots.{bot_name}.token"
                token = self.config_manager.get_sensitive_value("telegram", token_path)
                if token:
                    try:
                        bot = Bot(token=token)
                        self.bots[token] = {
                            "bot": bot,
                            "name": bot_name,
                            "chat_ids": bot_config.get("chat_ids", []),
                            "is_default": token == self.default_bot_token
                        }
                        logger.info(f"Telegram机器人 {bot_name} 初始化成功")
                    except Exception as e:
                        logger.error(f"初始化Telegram机器人 {bot_name} 失败: {e}")
                else:
                    logger.warning(f"机器人 {bot_name} 的Token未配置")
            
            if not self.default_bot_token and self.bots:
                # 如果没有设置默认机器人，使用第一个
                self.default_bot_token = list(self.bots.keys())[0]
                self.bots[self.default_bot_token]["is_default"] = True
                logger.warning(f"未设置默认机器人，将使用 {self.bots[self.default_bot_token]['name']} 作为默认机器人")
            
            if self.default_bot_token:
                # 初始化Updater
                self.updater = Updater(token=self.default_bot_token, use_context=True)
                dispatcher = self.updater.dispatcher
                
                # 注册命令处理器
                self._register_command_handlers(dispatcher)
                
                logger.info("Telegram命令处理器初始化完成")
            else:
                logger.warning("没有可用的默认机器人，无法处理命令")
        except Exception as e:
            logger.error(f"初始化Telegram机器人失败: {e}")
    
    def _register_command_handlers(self, dispatcher):
        """注册Telegram命令处理器"""
        try:
            # 导入命令处理模块
            from telegram_commands import TelegramCommands
            
            # 创建命令处理器实例
            self.command_handler = TelegramCommands(
                self.config_manager,
                self.price_monitor,
                self.announcement_monitor,
                self.coin_enricher,
                self
            )
            
            # 注册命令
            commands = self.command_handler.get_commands()
            for command, handler in commands.items():
                dispatcher.add_handler(CommandHandler(command, handler))
            
            # 注册回调查询处理器
            dispatcher.add_handler(CallbackQueryHandler(self.command_handler.handle_callback_query))
            
            # 注册未知命令处理器
            dispatcher.add_handler(MessageHandler(Filters.command, self._unknown_command))
            
            logger.info("Telegram命令处理器注册完成")
        except ImportError:
            logger.error("未找到telegram_commands.py模块，无法注册命令")
        except Exception as e:
            logger.error(f"注册Telegram命令处理器失败: {e}")
    
    def start(self):
        """启动Telegram机器人"""
        if self.running:
            logger.warning("Telegram机器人已在运行中")
            return
        
        if not self.updater:
            logger.warning("没有可用的默认机器人，无法启动命令处理")
            return
        
        try:
            self.running = True
            self.updater.start_polling()
            logger.info("Telegram机器人已启动")
        except Exception as e:
            logger.error(f"启动Telegram机器人失败: {e}")
            self.running = False
    
    def stop(self):
        """停止Telegram机器人"""
        if not self.running:
            return
        
        try:
            self.running = False
            if self.updater:
                self.updater.stop()
            logger.info("Telegram机器人已停止")
        except Exception as e:
            logger.error(f"停止Telegram机器人失败: {e}")
    
    def _unknown_command(self, update: Update, context: CallbackContext):
        """处理未知命令"""
        context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="抱歉，我不认识这个命令。请使用 /help 查看可用命令。"
        )
    
    def send_message(self, message, chat_id=None, bot_token=None, parse_mode="MarkdownV2"):
        """发送消息到Telegram
        
        Args:
            message: 消息内容
            chat_id: 目标聊天ID，如果为None则发送到所有默认机器人的配置聊天室
            bot_token: 使用的机器人Token，如果为None则使用默认机器人
            parse_mode: 消息格式
        
        Returns:
            bool: 是否发送成功
        """
        try:
            target_bot_token = bot_token or self.default_bot_token
            if not target_bot_token or target_bot_token not in self.bots:
                logger.error("没有可用的机器人或指定的机器人不存在")
                return False
            
            bot_info = self.bots[target_bot_token]
            bot = bot_info["bot"]
            target_chat_ids = [chat_id] if chat_id else bot_info["chat_ids"]
            
            if not target_chat_ids:
                logger.warning(f"机器人 {bot_info['name']} 没有配置聊天ID")
                return False
            
            success = True
            for cid in target_chat_ids:
                try:
                    # 处理长消息
                    max_length = 4096
                    if len(message) > max_length:
                        parts = []
                        while len(message) > max_length:
                            split_pos = message.rfind("\n", 0, max_length)
                            if split_pos == -1:
                                split_pos = max_length
                            parts.append(message[:split_pos])
                            message = message[split_pos:]
                        parts.append(message)
                        
                        for i, part in enumerate(parts):
                            part_message = f"(Part {i+1}/{len(parts)})\n{part}"
                            bot.send_message(
                                chat_id=cid,
                                text=part_message,
                                parse_mode=parse_mode
                            )
                            time.sleep(0.5) # 防止发送过快
                    else:
                        bot.send_message(
                            chat_id=cid,
                            text=message,
                            parse_mode=parse_mode
                        )
                except Exception as e:
                    logger.error(f"发送消息到 {cid} 失败: {e}")
                    success = False
            
            return success
        except Exception as e:
            logger.error(f"发送消息失败: {e}")
            return False
    
    def send_photo(self, photo, caption="", chat_id=None, bot_token=None):
        """发送图片到Telegram
        
        Args:
            photo: 图片文件路径或文件对象
            caption: 图片说明
            chat_id: 目标聊天ID
            bot_token: 使用的机器人Token
        
        Returns:
            bool: 是否发送成功
        """
        try:
            target_bot_token = bot_token or self.default_bot_token
            if not target_bot_token or target_bot_token not in self.bots:
                logger.error("没有可用的机器人或指定的机器人不存在")
                return False
            
            bot_info = self.bots[target_bot_token]
            bot = bot_info["bot"]
            target_chat_ids = [chat_id] if chat_id else bot_info["chat_ids"]
            
            if not target_chat_ids:
                logger.warning(f"机器人 {bot_info['name']} 没有配置聊天ID")
                return False
            
            success = True
            for cid in target_chat_ids:
                try:
                    if isinstance(photo, str):
                        with open(photo, "rb") as f:
                            bot.send_photo(
                                chat_id=cid,
                                photo=f,
                                caption=caption
                            )
                    else:
                        bot.send_photo(
                            chat_id=cid,
                            photo=photo,
                            caption=caption
                        )
                except Exception as e:
                    logger.error(f"发送图片到 {cid} 失败: {e}")
                    success = False
            
            return success
        except Exception as e:
            logger.error(f"发送图片失败: {e}")
            return False
    
    def _send_price_alert(self, symbol, exchange, period, change, data):
        """发送价格预警通知
        
        Args:
            symbol: 币种符号
            exchange: 交易所名称
            period: 时间周期
            change: 变动百分比
            data: 价格数据
        """
        try:
            # 获取币种详情
            details = self.coin_enricher.get_coin_details(symbol)
            analysis = self.coin_enricher.get_market_analysis(symbol)
            
            # 格式化消息
            direction = "上涨📈" if change > 0 else "下跌📉"
            price = data.get("price", 0)
            
            message = f"🚨 *价格预警: {symbol} 价格 {direction} {abs(change):.2f}%* \({period}\)\n\n"
            message += f"*交易所:* `{exchange.capitalize()}`\n"
            message += f"*当前价格:* `{price:.4f}` USD\n"
            
            if details:
                message += f"*市值排名:* `{details.get('market_data', {}).get('market_cap_rank', 'N/A')}`\n"
                message += f"*24h交易量:* `${details.get('market_data', {}).get('total_volume', 0):,.0f}`\n"
            
            if analysis:
                message += f"\n*价格分析:* {analysis.get('price_analysis', {}).get('summary', 'N/A')}\n"
                message += f"*原因分析:* {analysis.get('price_analysis', {}).get('reason', 'N/A')}\n"
                message += f"*市场情绪:* {analysis.get('market_sentiment', {}).get('summary', 'N/A')}\n"
            
            # 添加链接
            if details and details.get("links"):
                links = details["links"]
                message += "\n*相关链接:*\n"
                if links.get("homepage"): message += f"[官网]({links['homepage']}) "
                if links.get("twitter_screen_name"): message += f"[Twitter](https://twitter.com/{links['twitter_screen_name']}) "
                if links.get("telegram_channel_identifier"): message += f"[Telegram](https://t.me/{links['telegram_channel_identifier']}) "
                if links.get("blockchain_site"): message += f"[区块浏览器]({links['blockchain_site']}) "
            
            # 发送消息
            self.send_message(self._escape_markdown(message))
            
            # 发送图表
            self._send_price_chart(symbol, exchange)
        except Exception as e:
            logger.error(f"发送价格预警失败: {e}")
            logger.error(traceback.format_exc())
    
    def _send_custom_alert(self, user_id, alert, price):
        """发送自定义预警通知
        
        Args:
            user_id: 用户ID
            alert: 预警配置
            price: 当前价格
        """
        try:
            symbol = alert["symbol"]
            condition = alert["condition"]
            value = alert["value"]
            
            message = f"🔔 *自定义预警触发: {symbol}*\n\n"
            message += f"*条件:* 价格 `{condition} {value}`\n"
            message += f"*当前价格:* `{price:.4f}` USD\n"
            
            # 获取用户配置的聊天ID
            chat_id = self._get_user_chat_id(user_id)
            if chat_id:
                self.send_message(self._escape_markdown(message), chat_id=chat_id)
            else:
                logger.warning(f"未找到用户 {user_id} 的聊天ID，无法发送自定义预警")
        except Exception as e:
            logger.error(f"发送自定义预警失败: {e}")
    
    def _send_announcement_notification(self, exchange, announcements):
        """发送公告通知
        
        Args:
            exchange: 交易所名称
            announcements: 公告列表
        """
        try:
            for announcement in announcements:
                message = f"📢 *{exchange.capitalize()}新公告*\n\n"
                message += f"*标题:* {announcement['title']}\n"
                message += f"*日期:* {announcement['date']}\n"
                message += f"*链接:* [点击查看]({announcement['url']})"
                
                self.send_message(self._escape_markdown(message))
        except Exception as e:
            logger.error(f"发送公告通知失败: {e}")
    
    def _send_new_listing_notification(self, exchange, listings):
        """发送新上币通知
        
        Args:
            exchange: 交易所名称
            listings: 新上币公告列表
        """
        try:
            for listing in listings:
                message = f"🚀 *{exchange.capitalize()}新上币公告*\n\n"
                message += f"*标题:* {listing['title']}\n"
                message += f"*日期:* {listing['date']}\n"
                message += f"*链接:* [点击查看]({listing['url']})"
                
                # 尝试提取币种名称
                match = re.search(r"list\s+([A-Z]+)", listing["title"], re.IGNORECASE)
                if match:
                    symbol = match.group(1)
                    message += f"\n\n*可能涉及币种:* `{symbol}`"
                
                self.send_message(self._escape_markdown(message))
        except Exception as e:
            logger.error(f"发送新上币通知失败: {e}")
    
    def _send_price_chart(self, symbol, exchange):
        """发送价格图表
        
        Args:
            symbol: 币种符号
            exchange: 交易所名称
        """
        try:
            # 获取历史数据
            historical_data = self.price_monitor.fetch_historical_data(symbol, timeframe="1h", limit=24)
            if not historical_data:
                return
            
            # 准备数据
            timestamps = [d[0] / 1000 for d in historical_data]
            prices = [d[4] for d in historical_data] # 收盘价
            dates = [datetime.fromtimestamp(ts) for ts in timestamps]
            
            # 绘制图表
            plt.figure(figsize=(10, 5))
            plt.plot(dates, prices, marker=".")
            plt.title(f"{symbol} 24小时价格走势 ({exchange.capitalize()})")
            plt.xlabel("时间")
            plt.ylabel("价格 (USD)")
            plt.grid(True)
            plt.xticks(rotation=45)
            plt.tight_layout()
            
            # 保存图表到内存
            buf = io.BytesIO()
            plt.savefig(buf, format="png")
            buf.seek(0)
            plt.close()
            
            # 发送图片
            caption = f"{symbol} 24小时价格走势图"
            self.send_photo(buf, caption=caption)
        except Exception as e:
            logger.error(f"发送价格图表失败: {e}")
            logger.error(traceback.format_exc())
    
    def _get_user_chat_id(self, user_id):
        """获取用户的聊天ID
        
        Args:
            user_id: 用户ID
        
        Returns:
            str: 聊天ID，如果未找到则返回None
        """
        # 在实际实现中，需要存储用户ID和聊天ID的映射关系
        # 这里假设用户ID就是聊天ID
        return str(user_id)
    
    def _escape_markdown(self, text):
        """转义MarkdownV2特殊字符
        
        Args:
            text: 原始文本
        
        Returns:
            str: 转义后的文本
        """
        escape_chars = r'_*[]()~`>#+-=|{}.!'
        return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', text)
    
    def get_bot_info(self, bot_token=None):
        """获取机器人信息
        
        Args:
            bot_token: 机器人Token，如果为None则获取默认机器人信息
        
        Returns:
            dict: 机器人信息
        """
        target_token = bot_token or self.default_bot_token
        if target_token and target_token in self.bots:
            return self.bots[target_token]["bot"].get_me()
        return None
    
    def get_configured_bots(self):
        """获取所有配置的机器人信息
        
        Returns:
            list: 机器人信息列表
        """
        return [
            {
                "name": info["name"],
                "token": token,
                "chat_ids": info["chat_ids"],
                "is_default": info["is_default"]
            }
            for token, info in self.bots.items()
        ]
