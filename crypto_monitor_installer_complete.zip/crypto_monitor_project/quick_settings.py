# quick_settings.py

import json
import os
import getpass
import re
import time
import logging
from pathlib import Path
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('quick_settings')

class ConfigManager:
    """配置管理器，负责读取、验证、更新和保存配置信息"""
    
    def __init__(self, config_file='config.json', encryption_key=None):
        """初始化配置管理器
        
        Args:
            config_file: 配置文件路径
            encryption_key: 用于加密敏感信息的密钥，如果为None则生成新密钥
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.encryption_key = encryption_key or self._generate_encryption_key()
        
    def _generate_encryption_key(self):
        """生成加密密钥"""
        try:
            key_file = '.encryption_key'
            if os.path.exists(key_file):
                with open(key_file, 'rb') as f:
                    return f.read()
            else:
                # 生成新密钥
                key = Fernet.generate_key()
                # 保存密钥到文件
                with open(key_file, 'wb') as f:
                    f.write(key)
                # 设置文件权限为仅所有者可读写
                os.chmod(key_file, 0o600)
                return key
        except Exception as e:
            logger.error(f"生成加密密钥失败: {e}")
            # 返回一个临时密钥，但不保存
            return Fernet.generate_key()
    
    def _encrypt_value(self, value):
        """加密敏感值"""
        if not value:
            return value
        try:
            cipher = Fernet(self.encryption_key)
            return base64.b64encode(cipher.encrypt(value.encode())).decode()
        except Exception as e:
            logger.error(f"加密失败: {e}")
            return value
    
    def _decrypt_value(self, encrypted_value):
        """解密敏感值"""
        if not encrypted_value or not encrypted_value.startswith('b\'') or not encrypted_value.endswith('\''):
            return encrypted_value
        try:
            cipher = Fernet(self.encryption_key)
            return cipher.decrypt(base64.b64decode(encrypted_value[2:-1])).decode()
        except Exception as e:
            logger.error(f"解密失败: {e}")
            return encrypted_value
    
    def _load_config(self):
        """从文件加载配置，如果不存在则创建默认配置"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"配置文件 {self.config_file} 格式错误，将使用默认配置")
                return self._create_default_config()
            except Exception as e:
                logger.error(f"加载配置文件失败: {e}")
                return self._create_default_config()
        else:
            logger.info(f"配置文件 {self.config_file} 不存在，将创建默认配置")
            return self._create_default_config()
    
    def _create_default_config(self):
        """创建默认配置"""
        return {
            "telegram": {
                "bots": []
            },
            "exchanges": {
                "binance": {
                    "api_key": "",
                    "api_secret": "",
                    "enabled": False
                },
                "gate": {
                    "api_key": "",
                    "api_secret": "",
                    "enabled": False
                }
            },
            "thresholds": {
                "price": {
                    "5m": 3.0,
                    "15m": 5.0,
                    "1h": 8.0,
                    "24h": 15.0
                },
                "volume": {
                    "1h": 200.0,
                    "24h": 500.0
                }
            },
            "monitoring": {
                "price_check_interval": 60,
                "announcement_check_interval": 3600,
                "max_symbols_per_request": 100,
                "retry_interval": 10,
                "max_retries": 3
            },
            "user_settings": {}
        }
    
    def save_config(self):
        """将配置保存到文件"""
        try:
            # 创建备份
            if os.path.exists(self.config_file):
                backup_file = f"{self.config_file}.bak"
                with open(self.config_file, 'r') as src, open(backup_file, 'w') as dst:
                    dst.write(src.read())
            
            # 保存新配置
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            
            # 设置文件权限为仅所有者可读写
            os.chmod(self.config_file, 0o600)
            logger.info(f"配置已保存到 {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
            return False
    
    def get_config(self, section=None):
        """获取配置或特定部分的配置"""
        if section:
            return self.config.get(section, {})
        return self.config
    
    def update_config(self, section, key, value, is_sensitive=False):
        """更新配置
        
        Args:
            section: 配置部分
            key: 配置键
            value: 配置值
            is_sensitive: 是否为敏感信息（需要加密）
        """
        if section not in self.config:
            self.config[section] = {}
        
        # 处理嵌套键，如 "exchanges.binance.api_key"
        if '.' in key:
            parts = key.split('.')
            current = self.config[section]
            for part in parts[:-1]:
                if part not in current:
                    current[part] = {}
                current = current[part]
            
            if is_sensitive:
                current[parts[-1]] = self._encrypt_value(value)
            else:
                current[parts[-1]] = value
        else:
            if is_sensitive:
                self.config[section][key] = self._encrypt_value(value)
            else:
                self.config[section][key] = value
        
        return True
    
    def get_sensitive_value(self, section, key):
        """获取敏感值（解密后）"""
        # 处理嵌套键
        if '.' in key:
            parts = key.split('.')
            current = self.config.get(section, {})
            for part in parts[:-1]:
                current = current.get(part, {})
            encrypted_value = current.get(parts[-1], "")
        else:
            encrypted_value = self.config.get(section, {}).get(key, "")
        
        return self._decrypt_value(encrypted_value)
    
    def validate_config(self):
        """验证配置的完整性和有效性"""
        issues = []
        
        # 检查Telegram配置
        telegram_config = self.config.get("telegram", {})
        bots = telegram_config.get("bots", [])
        if not bots:
            issues.append("未配置Telegram机器人")
        else:
            for i, bot in enumerate(bots):
                if not bot.get("token"):
                    issues.append(f"Telegram机器人 #{i+1} 缺少token")
                if not bot.get("chat_ids"):
                    issues.append(f"Telegram机器人 #{i+1} 缺少chat_ids")
        
        # 检查交易所配置
        exchanges_config = self.config.get("exchanges", {})
        enabled_exchanges = 0
        for exchange, config in exchanges_config.items():
            if config.get("enabled", False):
                enabled_exchanges += 1
                if not config.get("api_key"):
                    issues.append(f"{exchange} 交易所缺少API Key")
                if not config.get("api_secret"):
                    issues.append(f"{exchange} 交易所缺少API Secret")
        
        if enabled_exchanges == 0:
            issues.append("未启用任何交易所")
        
        # 检查阈值配置
        thresholds_config = self.config.get("thresholds", {})
        price_thresholds = thresholds_config.get("price", {})
        if not price_thresholds:
            issues.append("未配置价格阈值")
        
        # 检查监控频率配置
        monitoring_config = self.config.get("monitoring", {})
        if not monitoring_config.get("price_check_interval"):
            issues.append("未配置价格检查间隔")
        if not monitoring_config.get("announcement_check_interval"):
            issues.append("未配置公告检查间隔")
        
        return issues


class SetupWizard:
    """交互式设置向导，引导用户完成配置"""
    
    def __init__(self, config_manager):
        """初始化设置向导
        
        Args:
            config_manager: ConfigManager实例
        """
        self.config_manager = config_manager
    
    def start_wizard(self):
        """启动设置向导"""
        print("\n欢迎使用加密货币监控系统设置向导!\n")
        
        self._setup_telegram()
        self._setup_exchanges()
        self._setup_thresholds()
        self._setup_monitoring_frequency()
        
        if self.config_manager.save_config():
            print(f"\n设置完成！配置已保存到 {self.config_manager.config_file}")
            
            # 验证配置
            issues = self.config_manager.validate_config()
            if issues:
                print("\n⚠️ 配置验证发现以下问题:")
                for issue in issues:
                    print(f"  - {issue}")
                print("\n您可以稍后使用设置向导或编辑配置文件解决这些问题。")
            else:
                print("\n✅ 配置验证通过，系统已准备就绪！")
        else:
            print("\n❌ 保存配置失败，请检查文件权限或磁盘空间。")
    
    def _setup_telegram(self):
        """引导用户设置Telegram账号"""
        print("\n===== Telegram设置 =====")
        
        telegram_config = self.config_manager.get_config("telegram")
        bots = telegram_config.get("bots", [])
        
        while True:
            print("\n请设置Telegram机器人:")
            bot_name = input("机器人名称 (例如: 主要机器人): ").strip()
            bot_token = input("Bot Token (从BotFather获取): ").strip()
            
            if not bot_token:
                print("❌ Bot Token不能为空")
                continue
            
            chat_ids = []
            while True:
                chat_id = input("Chat ID (用户或群组ID): ").strip()
                if chat_id:
                    chat_ids.append(chat_id)
                    add_more = input("是否添加更多Chat ID? (y/n): ").strip().lower()
                    if add_more != 'y':
                        break
                else:
                    print("❌ Chat ID不能为空")
            
            if not chat_ids:
                print("❌ 至少需要一个Chat ID")
                continue
            
            is_default = True if not bots else input("是否设为默认机器人? (y/n): ").strip().lower() == 'y'
            
            # 如果设为默认，将其他机器人设为非默认
            if is_default:
                for bot in bots:
                    bot["is_default"] = False
            
            # 添加新机器人
            bots.append({
                "name": bot_name,
                "token": bot_token,
                "chat_ids": chat_ids,
                "is_default": is_default
            })
            
            add_more = input("是否添加更多Telegram机器人? (y/n): ").strip().lower()
            if add_more != 'y':
                break
        
        # 更新配置
        self.config_manager.config["telegram"]["bots"] = bots
    
    def _setup_exchanges(self):
        """引导用户设置交易所API"""
        print("\n===== 交易所API设置 =====")
        
        exchanges = ["binance", "gate"]
        for exchange in exchanges:
            print(f"\n设置{exchange.capitalize()}交易所API:")
            setup = input(f"是否配置{exchange.capitalize()}? (y/n): ").strip().lower()
            if setup == 'y':
                api_key = input("API Key: ").strip()
                api_secret = getpass.getpass("API Secret: ").strip()
                
                if api_key and api_secret:
                    self.config_manager.update_config("exchanges", f"{exchange}.api_key", api_key, is_sensitive=True)
                    self.config_manager.update_config("exchanges", f"{exchange}.api_secret", api_secret, is_sensitive=True)
                    self.config_manager.update_config("exchanges", f"{exchange}.enabled", True)
                    print(f"✅ {exchange.capitalize()}交易所API设置成功")
                else:
                    print(f"❌ API Key和Secret不能为空，{exchange.capitalize()}将被禁用")
                    self.config_manager.update_config("exchanges", f"{exchange}.enabled", False)
            else:
                self.config_manager.update_config("exchanges", f"{exchange}.enabled", False)
    
    def _setup_thresholds(self):
        """引导用户设置涨跌幅阈值"""
        print("\n===== 涨跌幅阈值设置 =====")
        
        # 价格阈值
        print("\n价格涨跌幅阈值设置:")
        thresholds = {
            "5m": 3.0,
            "15m": 5.0,
            "1h": 8.0,
            "24h": 15.0
        }
        
        for period, default_value in thresholds.items():
            while True:
                value_input = input(f"设置{period}涨跌幅阈值 (默认: {default_value}%): ").strip()
                if not value_input:
                    value = default_value
                    break
                try:
                    value = float(value_input)
                    if value <= 0:
                        print("❌ 阈值必须大于0")
                    else:
                        break
                except ValueError:
                    print("❌ 请输入有效的数字")
            
            self.config_manager.update_config("thresholds", f"price.{period}", value)
        
        # 交易量阈值
        print("\n交易量变化阈值设置:")
        volume_thresholds = {
            "1h": 200.0,
            "24h": 500.0
        }
        
        for period, default_value in volume_thresholds.items():
            while True:
                value_input = input(f"设置{period}交易量变化阈值 (默认: {default_value}%): ").strip()
                if not value_input:
                    value = default_value
                    break
                try:
                    value = float(value_input)
                    if value <= 0:
                        print("❌ 阈值必须大于0")
                    else:
                        break
                except ValueError:
                    print("❌ 请输入有效的数字")
            
            self.config_manager.update_config("thresholds", f"volume.{period}", value)
    
    def _setup_monitoring_frequency(self):
        """引导用户设置监控频率"""
        print("\n===== 监控频率设置 =====")
        
        # 价格检查间隔
        while True:
            interval_input = input("设置价格检查间隔 (秒, 默认: 60): ").strip()
            if not interval_input:
                interval = 60
                break
            try:
                interval = int(interval_input)
                if interval < 10:
                    print("❌ 间隔不能小于10秒")
                else:
                    break
            except ValueError:
                print("❌ 请输入有效的整数")
        
        self.config_manager.update_config("monitoring", "price_check_interval", interval)
        
        # 公告检查间隔
        while True:
            interval_input = input("设置公告检查间隔 (秒, 默认: 3600): ").strip()
            if not interval_input:
                interval = 3600
                break
            try:
                interval = int(interval_input)
                if interval < 60:
                    print("❌ 间隔不能小于60秒")
                else:
                    break
            except ValueError:
                print("❌ 请输入有效的整数")
        
        self.config_manager.update_config("monitoring", "announcement_check_interval", interval)
        
        # 其他参数
        self.config_manager.update_config("monitoring", "max_symbols_per_request", 100)
        self.config_manager.update_config("monitoring", "retry_interval", 10)
        self.config_manager.update_config("monitoring", "max_retries", 3)


class TelegramSettingsCommands:
    """扩展Telegram命令处理器，添加设置相关命令"""
    
    def __init__(self, command_handler, config_manager):
        """初始化Telegram设置命令
        
        Args:
            command_handler: TelegramCommandHandler实例
            config_manager: ConfigManager实例
        """
        self.command_handler = command_handler
        self.config_manager = config_manager
        self._register_commands()
    
    def _register_commands(self):
        """注册设置相关命令"""
        # 注册命令处理函数
        self.command_handler.command_handlers.update({
            "setapi": self.handle_set_api,
            "settelegram": self.handle_set_telegram,
            "setthreshold": self.handle_set_threshold,
            "setfrequency": self.handle_set_frequency,
            "showconfig": self.handle_show_config,
            "quicksetup": self.handle_quick_setup
        })
        
        # 注册命令快捷方式
        self.command_handler.command_shortcuts.update({
            "sa": "setapi",
            "st": "settelegram",
            "sth": "setthreshold",
            "sf": "setfrequency",
            "sc": "showconfig",
            "qs": "quicksetup"
        })
    
    def _is_admin(self, user_id):
        """检查用户是否为管理员"""
        user_settings = self.config_manager.get_config("user_settings")
        return user_settings.get(user_id, {}).get("role") == "admin"
    
    def handle_set_api(self, args, user_id, chat_id):
        """处理设置API的命令
        
        格式: /setapi <exchange> <api_key> <api_secret>
        例如: /setapi binance YOUR_API_KEY YOUR_API_SECRET
        """
        # 检查权限
        if not self._is_admin(user_id):
            return "❌ 只有管理员可以设置API"
        
        if len(args) < 3:
            return "❌ 参数不足。使用格式: /setapi <exchange> <api_key> <api_secret>"
        
        exchange = args[0].lower()
        api_key = args[1]
        api_secret = args[2]
        
        valid_exchanges = ["binance", "gate"]
        if exchange not in valid_exchanges:
            return f"❌ 无效的交易所。支持的交易所: {', '.join(valid_exchanges)}"
        
        try:
            self.config_manager.update_config("exchanges", f"{exchange}.api_key", api_key, is_sensitive=True)
            self.config_manager.update_config("exchanges", f"{exchange}.api_secret", api_secret, is_sensitive=True)
            self.config_manager.update_config("exchanges", f"{exchange}.enabled", True)
            self.config_manager.save_config()
            return f"✅ {exchange.capitalize()}交易所API设置成功"
        except Exception as e:
            logger.error(f"设置API失败: {e}")
            return f"❌ 设置API失败: {str(e)}"
    
    def handle_set_telegram(self, args, user_id, chat_id):
        """处理设置Telegram的命令
        
        格式: /settelegram <action> [params...]
        例如: /settelegram add BOT_TOKEN CHAT_ID
              /settelegram remove 1
              /settelegram default 2
        """
        # 检查权限
        if not self._is_admin(user_id):
            return "❌ 只有管理员可以设置Telegram"
        
        if not args:
            return "❌ 参数不足。使用格式: /settelegram <action> [params...]"
        
        action = args[0].lower()
        
        if action == "add":
            if len(args) < 3:
                return "❌ 参数不足。使用格式: /settelegram add <bot_token> <chat_id>"
            
            bot_token = args[1]
            chat_id = args[2]
            
            # 获取现有机器人列表
            telegram_config = self.config_manager.get_config("telegram")
            bots = telegram_config.get("bots", [])
            
            # 检查是否已存在相同token的机器人
            for bot in bots:
                if bot.get("token") == bot_token:
                    # 如果已存在，添加chat_id
                    if chat_id not in bot.get("chat_ids", []):
                        bot["chat_ids"].append(chat_id)
                        self.config_manager.save_config()
                        return f"✅ 已将Chat ID添加到现有机器人"
                    else:
                        return f"ℹ️ 该Chat ID已存在于机器人配置中"
            
            # 添加新机器人
            is_default = not bots  # 如果是第一个机器人，则设为默认
            if is_default:
                bot_name = "主要机器人"
            else:
                bot_name = f"机器人 #{len(bots) + 1}"
            
            bots.append({
                "name": bot_name,
                "token": bot_token,
                "chat_ids": [chat_id],
                "is_default": is_default
            })
            
            self.config_manager.config["telegram"]["bots"] = bots
            self.config_manager.save_config()
            return f"✅ 已添加新的Telegram机器人"
        
        elif action == "remove":
            if len(args) < 2:
                return "❌ 参数不足。使用格式: /settelegram remove <index>"
            
            try:
                index = int(args[1]) - 1
                telegram_config = self.config_manager.get_config("telegram")
                bots = telegram_config.get("bots", [])
                
                if index < 0 or index >= len(bots):
                    return f"❌ 无效的索引。有效范围: 1-{len(bots)}"
                
                removed_bot = bots.pop(index)
                
                # 如果删除的是默认机器人，且还有其他机器人，则将第一个设为默认
                if removed_bot.get("is_default", False) and bots:
                    bots[0]["is_default"] = True
                
                self.config_manager.config["telegram"]["bots"] = bots
                self.config_manager.save_config()
                return f"✅ 已移除机器人 #{index + 1}"
            except ValueError:
                return "❌ 索引必须是数字"
            except Exception as e:
                logger.error(f"移除机器人失败: {e}")
                return f"❌ 移除机器人失败: {str(e)}"
        
        elif action == "default":
            if len(args) < 2:
                return "❌ 参数不足。使用格式: /settelegram default <index>"
            
            try:
                index = int(args[1]) - 1
                telegram_config = self.config_manager.get_config("telegram")
                bots = telegram_config.get("bots", [])
                
                if index < 0 or index >= len(bots):
                    return f"❌ 无效的索引。有效范围: 1-{len(bots)}"
                
                # 将所有机器人设为非默认
                for bot in bots:
                    bot["is_default"] = False
                
                # 将指定机器人设为默认
                bots[index]["is_default"] = True
                
                self.config_manager.config["telegram"]["bots"] = bots
                self.config_manager.save_config()
                return f"✅ 已将机器人 #{index + 1} 设为默认"
            except ValueError:
                return "❌ 索引必须是数字"
            except Exception as e:
                logger.error(f"设置默认机器人失败: {e}")
                return f"❌ 设置默认机器人失败: {str(e)}"
        
        else:
            return "❌ 无效的操作。有效操作: add, remove, default"
    
    def handle_set_threshold(self, args, user_id, chat_id):
        """处理设置阈值的命令
        
        格式: /setthreshold <type> <period> <value>
        例如: /setthreshold price 1h 10
              /setthreshold volume 24h 500
        """
        # 检查权限
        if not self._is_admin(user_id):
            return "❌ 只有管理员可以设置全局阈值"
        
        if len(args) < 3:
            return "❌ 参数不足。使用格式: /setthreshold <type> <period> <value>"
        
        threshold_type = args[0].lower()
        period = args[1].lower()
        
        try:
            value = float(args[2])
            if value <= 0:
                return "❌ 阈值必须大于0"
        except ValueError:
            return "❌ 阈值必须是数字"
        
        valid_types = ["price", "volume"]
        if threshold_type not in valid_types:
            return f"❌ 无效的阈值类型。有效类型: {', '.join(valid_types)}"
        
        valid_periods = {
            "price": ["5m", "15m", "1h", "24h"],
            "volume": ["1h", "24h"]
        }
        
        if period not in valid_periods.get(threshold_type, []):
            return f"❌ 无效的时间周期。{threshold_type}的有效周期: {', '.join(valid_periods.get(threshold_type, []))}"
        
        try:
            self.config_manager.update_config("thresholds", f"{threshold_type}.{period}", value)
            self.config_manager.save_config()
            return f"✅ 已设置{threshold_type} {period}阈值为{value}%"
        except Exception as e:
            logger.error(f"设置阈值失败: {e}")
            return f"❌ 设置阈值失败: {str(e)}"
    
    def handle_set_frequency(self, args, user_id, chat_id):
        """处理设置频率的命令
        
        格式: /setfrequency <type> <seconds>
        例如: /setfrequency price 30
              /setfrequency announcement 1800
        """
        # 检查权限
        if not self._is_admin(user_id):
            return "❌ 只有管理员可以设置监控频率"
        
        if len(args) < 2:
            return "❌ 参数不足。使用格式: /setfrequency <type> <seconds>"
        
        freq_type = args[0].lower()
        
        try:
            seconds = int(args[1])
        except ValueError:
            return "❌ 秒数必须是整数"
        
        valid_types = {
            "price": {"min": 10, "param": "price_check_interval"},
            "announcement": {"min": 60, "param": "announcement_check_interval"}
        }
        
        if freq_type not in valid_types:
            return f"❌ 无效的类型。有效类型: {', '.join(valid_types.keys())}"
        
        type_info = valid_types[freq_type]
        if seconds < type_info["min"]:
            return f"❌ {freq_type}检查间隔不能小于{type_info['min']}秒"
        
        try:
            self.config_manager.update_config("monitoring", type_info["param"], seconds)
            self.config_manager.save_config()
            return f"✅ 已设置{freq_type}检查间隔为{seconds}秒"
        except Exception as e:
            logger.error(f"设置监控频率失败: {e}")
            return f"❌ 设置监控频率失败: {str(e)}"
    
    def handle_show_config(self, args, user_id, chat_id):
        """处理显示配置的命令"""
        # 检查权限
        if not self._is_admin(user_id):
            return "❌ 只有管理员可以查看完整配置"
        
        try:
            config = self.config_manager.get_config()
            
            # Telegram配置
            telegram_config = config.get("telegram", {})
            bots = telegram_config.get("bots", [])
            telegram_info = f"*Telegram配置:* {len(bots)}个机器人\n"
            for i, bot in enumerate(bots):
                name = bot.get("name", f"机器人 #{i+1}")
                is_default = bot.get("is_default", False)
                chat_ids = bot.get("chat_ids", [])
                telegram_info += f"  {i+1}. {name} {'(默认)' if is_default else ''}: {len(chat_ids)}个聊天ID\n"
            
            # 交易所配置
            exchanges_config = config.get("exchanges", {})
            exchanges_info = "*交易所配置:*\n"
            for exchange, ex_config in exchanges_config.items():
                enabled = ex_config.get("enabled", False)
                has_api = bool(ex_config.get("api_key")) and bool(ex_config.get("api_secret"))
                exchanges_info += f"  {exchange.capitalize()}: {'已启用' if enabled else '未启用'}, API: {'已配置' if has_api else '未配置'}\n"
            
            # 阈值配置
            thresholds_config = config.get("thresholds", {})
            price_thresholds = thresholds_config.get("price", {})
            volume_thresholds = thresholds_config.get("volume", {})
            
            thresholds_info = "*阈值配置:*\n"
            thresholds_info += "  价格阈值:\n"
            for period, value in price_thresholds.items():
                thresholds_info += f"    {period}: {value}%\n"
            
            thresholds_info += "  交易量阈值:\n"
            for period, value in volume_thresholds.items():
                thresholds_info += f"    {period}: {value}%\n"
            
            # 监控频率配置
            monitoring_config = config.get("monitoring", {})
            monitoring_info = "*监控频率配置:*\n"
            monitoring_info += f"  价格检查间隔: {monitoring_config.get('price_check_interval', 60)}秒\n"
            monitoring_info += f"  公告检查间隔: {monitoring_config.get('announcement_check_interval', 3600)}秒\n"
            
            # 组合所有信息
            response = "📝 *系统配置*\n\n"
            response += telegram_info + "\n"
            response += exchanges_info + "\n"
            response += thresholds_info + "\n"
            response += monitoring_info
            
            return response
        except Exception as e:
            logger.error(f"获取配置失败: {e}")
            return f"❌ 获取配置失败: {str(e)}"
    
    def handle_quick_setup(self, args, user_id, chat_id):
        """处理快速设置的命令
        
        这个命令会启动一个交互式设置向导，通过一系列消息引导用户完成设置
        由于Telegram的交互限制，这里只返回一个说明，实际的交互需要在实现中处理
        """
        # 检查权限
        if not self._is_admin(user_id):
            return "❌ 只有管理员可以使用快速设置"
        
        # 这里只返回一个说明，实际的交互需要在实现中处理
        response = "🔧 *快速设置向导*\n\n"
        response += "由于Telegram的交互限制，快速设置需要通过单独的命令完成。请使用以下命令设置系统：\n\n"
        response += "1. 设置Telegram:\n"
        response += "   `/settelegram add BOT_TOKEN CHAT_ID` - 添加Telegram机器人\n"
        response += "   `/settelegram remove INDEX` - 移除Telegram机器人\n"
        response += "   `/settelegram default INDEX` - 设置默认机器人\n\n"
        response += "2. 设置交易所API:\n"
        response += "   `/setapi binance API_KEY API_SECRET` - 设置币安API\n"
        response += "   `/setapi gate API_KEY API_SECRET` - 设置Gate API\n\n"
        response += "3. 设置阈值:\n"
        response += "   `/setthreshold price 1h 10` - 设置1小时价格阈值为10%\n"
        response += "   `/setthreshold volume 24h 500` - 设置24小时交易量阈值为500%\n\n"
        response += "4. 设置监控频率:\n"
        response += "   `/setfrequency price 30` - 设置价格检查间隔为30秒\n"
        response += "   `/setfrequency announcement 1800` - 设置公告检查间隔为1800秒\n\n"
        response += "5. 查看当前配置:\n"
        response += "   `/showconfig` - 显示当前系统配置\n\n"
        response += "您可以使用这些命令逐步完成系统设置。"
        
        return response


# 主函数，用于命令行运行设置向导
def main():
    print("加密货币监控系统 - 快速设置工具")
    
    # 获取配置文件路径
    config_file = input("请输入配置文件路径 (默认: config.json): ").strip()
    if not config_file:
        config_file = "config.json"
    
    # 创建配置管理器
    config_manager = ConfigManager(config_file)
    
    # 创建设置向导
    wizard = SetupWizard(config_manager)
    
    # 启动向导
    wizard.start_wizard()


if __name__ == "__main__":
    main()
