# 增强版Telegram多账号推送模块设计

## 功能概述

根据您的需求，我们对原有的Telegram多账号推送模块进行了全面升级，使其能够高效地推送丰富的币种信息和分析内容。主要增强功能包括：

1. 长消息处理与分割推送
2. 富文本格式优化
3. 图表和图片支持
4. 丰富币种信息的格式化与推送
5. 多账号下的消息分发策略优化

## 模块设计

### 增强版多账号Telegram推送模块

```python
# 增强版Telegram多账号推送模块伪代码
class EnhancedTelegramNotifier:
    def __init__(self, config):
        self.config = config
        self.accounts = self._setup_accounts(config.get("accounts", []))
        self.default_account = config.get("default_account", "main")
        self.message_routing = config.get("message_routing", {})
        self.last_notification_time = {}
        self.account_status = {}
        self.max_message_length = config.get("max_message_length", 4096)  # Telegram消息最大长度
        self.message_templates = self._load_message_templates()
        
    def _setup_accounts(self, accounts_config):
        """设置多个Telegram账号"""
        # 与原版相同，设置多个账号
        accounts = {}
        
        for account in accounts_config:
            name = account.get("name", "unnamed")
            token = account.get("token", "")
            chat_id = account.get("chat_id", "")
            
            if token and chat_id:
                try:
                    bot = telegram.Bot(token=token)
                    accounts[name] = {
                        "bot": bot,
                        "chat_id": chat_id,
                        "token": token,
                        "priority": account.get("priority", 0)
                    }
                    self.account_status[name] = {
                        "active": True,
                        "last_check": time.time(),
                        "error_count": 0
                    }
                    logger.info(f"Telegram账号 {name} 设置成功")
                except Exception as e:
                    logger.error(f"Telegram账号 {name} 设置失败: {e}")
                    
        return accounts
        
    def _load_message_templates(self):
        """加载消息模板"""
        template_file = self.config.get("template_file")
        templates = {}
        
        if template_file and os.path.exists(template_file):
            try:
                with open(template_file, 'r', encoding='utf-8') as f:
                    templates = json.load(f)
                logger.info(f"已从{template_file}加载{len(templates)}个消息模板")
            except Exception as e:
                logger.error(f"加载消息模板失败: {e}")
                
        # 如果没有加载到模板或加载失败，使用默认模板
        if not templates:
            templates = {
                "price_alert": self._get_default_price_alert_template(),
                "enriched_price_alert": self._get_default_enriched_price_alert_template(),
                "announcement": self._get_default_announcement_template(),
                "new_listing": self._get_default_new_listing_template(),
                "system_message": self._get_default_system_message_template()
            }
            
        return templates
        
    def _get_default_price_alert_template(self):
        """获取默认价格预警模板"""
        return "{emoji} *价格预警* {emoji}\n\n" + \
               "交易所: `{exchange}`\n" + \
               "币种: `{symbol}`\n" + \
               "{direction}: `{change}%`\n" + \
               "当前价格: `{price}`"
               
    def _get_default_enriched_price_alert_template(self):
        """获取默认丰富价格预警模板"""
        return "{emoji} *价格预警* {emoji}\n\n" + \
               "交易所: `{exchange}`\n" + \
               "币种: `{symbol}`\n" + \
               "{direction}: `{change}%`\n" + \
               "当前价格: `{price}`\n\n" + \
               "*市场数据*\n" + \
               "24小时交易量: `${volume_24h}`\n" + \
               "市值: `${market_cap}`\n" + \
               "市值排名: `#{rank}`\n" + \
               "流通供应量: `{circulating_supply} {base_symbol}`\n\n" + \
               "*币种简介*\n" + \
               "{description}\n\n" + \
               "*价格分析*\n" + \
               "{price_analysis_summary}\n\n" + \
               "*相关链接*\n" + \
               "{links}"
               
    def _get_default_announcement_template(self):
        """获取默认公告模板"""
        return "📢 *{exchange}最新公告* 📢\n\n" + \
               "*{title}*\n\n" + \
               "发布时间: `{date}`\n\n" + \
               "[查看详情]({url})"
               
    def _get_default_new_listing_template(self):
        """获取默认新上币公告模板"""
        return "🔥 *{exchange}新币上线* 🔥\n\n" + \
               "*{title}*\n\n" + \
               "发布时间: `{date}`\n\n" + \
               "[查看详情]({url})"
               
    def _get_default_system_message_template(self):
        """获取默认系统消息模板"""
        return "{emoji} *系统消息* {emoji}\n\n{message}"
        
    def get_account_for_message(self, message_type):
        """根据消息类型获取应使用的账号"""
        # 与原版相同，根据消息类型选择账号
        # 检查消息路由配置
        if message_type in self.message_routing:
            account_name = self.message_routing[message_type]
            if account_name in self.accounts:
                if self.account_status[account_name]["active"]:
                    return account_name
                else:
                    logger.warning(f"账号 {account_name} 不活跃，使用默认账号")
                    
        # 使用默认账号
        if self.default_account in self.accounts and self.account_status[self.default_account]["active"]:
            return self.default_account
            
        # 如果默认账号不可用，使用优先级最高的活跃账号
        active_accounts = [(name, data["priority"]) 
                          for name, data in self.accounts.items() 
                          if self.account_status[name]["active"]]
        
        if active_accounts:
            # 按优先级排序，选择最高优先级
            active_accounts.sort(key=lambda x: x[1], reverse=True)
            return active_accounts[0][0]
            
        # 如果没有活跃账号，尝试使用任何可用账号
        if self.accounts:
            return list(self.accounts.keys())[0]
            
        logger.error("没有可用的Telegram账号")
        return None
        
    def split_long_message(self, message, max_length=None):
        """将长消息分割成多个部分"""
        if max_length is None:
            max_length = self.max_message_length
            
        if len(message) <= max_length:
            return [message]
            
        # 尝试在段落处分割
        parts = []
        current_part = ""
        paragraphs = message.split("\n\n")
        
        for paragraph in paragraphs:
            # 如果段落本身超过最大长度，需要进一步分割
            if len(paragraph) > max_length:
                if current_part:
                    parts.append(current_part)
                    current_part = ""
                    
                # 按行分割长段落
                lines = paragraph.split("\n")
                sub_part = ""
                
                for line in lines:
                    if len(sub_part) + len(line) + 1 <= max_length:
                        if sub_part:
                            sub_part += "\n" + line
                        else:
                            sub_part = line
                    else:
                        parts.append(sub_part)
                        sub_part = line
                        
                if sub_part:
                    current_part = sub_part
            else:
                # 检查添加这个段落是否会超过最大长度
                if len(current_part) + len(paragraph) + 2 <= max_length:
                    if current_part:
                        current_part += "\n\n" + paragraph
                    else:
                        current_part = paragraph
                else:
                    parts.append(current_part)
                    current_part = paragraph
                    
        if current_part:
            parts.append(current_part)
            
        # 添加部分指示器
        for i in range(len(parts)):
            parts[i] += f"\n\n[第{i+1}部分，共{len(parts)}部分]"
            
        return parts
        
    def send_message(self, message, message_type="general", parse_mode="Markdown", accounts=None, split_long=True):
        """发送消息到Telegram，支持长消息分割"""
        if not self.accounts:
            logger.error("没有配置Telegram账号")
            return False
            
        # 确定要发送到哪些账号
        target_accounts = []
        
        if accounts == "all":
            # 发送到所有账号
            target_accounts = list(self.accounts.keys())
        elif accounts and isinstance(accounts, list):
            # 发送到指定账号列表
            target_accounts = [acc for acc in accounts if acc in self.accounts]
        else:
            # 根据消息类型选择账号
            account = self.get_account_for_message(message_type)
            if account:
                target_accounts = [account]
                
        if not target_accounts:
            logger.error("没有目标账号可发送消息")
            return False
            
        # 处理长消息
        message_parts = [message]
        if split_long and len(message) > self.max_message_length:
            message_parts = self.split_long_message(message)
            
        # 发送消息到所有目标账号
        success = False
        for account_name in target_accounts:
            try:
                account = self.accounts[account_name]
                
                # 发送所有消息部分
                for part in message_parts:
                    account["bot"].send_message(
                        chat_id=account["chat_id"],
                        text=part,
                        parse_mode=parse_mode
                    )
                    # 如果有多个部分，添加短暂延迟避免API限制
                    if len(message_parts) > 1:
                        time.sleep(0.5)
                
                # 更新账号状态
                self.account_status[account_name]["active"] = True
                self.account_status[account_name]["last_check"] = time.time()
                self.account_status[account_name]["error_count"] = 0
                
                success = True
                logger.info(f"消息已发送到账号 {account_name}，共{len(message_parts)}个部分")
            except Exception as e:
                # 更新账号状态
                self.account_status[account_name]["error_count"] += 1
                if self.account_status[account_name]["error_count"] >= 3:
                    self.account_status[account_name]["active"] = False
                    
                logger.error(f"发送消息到账号 {account_name} 失败: {e}")
                
        return success
        
    def send_photo(self, photo_path, caption=None, message_type="photo", accounts=None):
        """发送图片到Telegram"""
        if not self.accounts:
            logger.error("没有配置Telegram账号")
            return False
            
        # 确定要发送到哪些账号
        target_accounts = []
        
        if accounts == "all":
            # 发送到所有账号
            target_accounts = list(self.accounts.keys())
        elif accounts and isinstance(accounts, list):
            # 发送到指定账号列表
            target_accounts = [acc for acc in accounts if acc in self.accounts]
        else:
            # 根据消息类型选择账号
            account = self.get_account_for_message(message_type)
            if account:
                target_accounts = [account]
                
        if not target_accounts:
            logger.error("没有目标账号可发送图片")
            return False
            
        # 检查图片是否存在
        if not os.path.exists(photo_path):
            logger.error(f"图片不存在: {photo_path}")
            return False
            
        # 发送图片到所有目标账号
        success = False
        for account_name in target_accounts:
            try:
                account = self.accounts[account_name]
                
                with open(photo_path, 'rb') as photo:
                    account["bot"].send_photo(
                        chat_id=account["chat_id"],
                        photo=photo,
                        caption=caption,
                        parse_mode="Markdown" if caption else None
                    )
                
                # 更新账号状态
                self.account_status[account_name]["active"] = True
                self.account_status[account_name]["last_check"] = time.time()
                self.account_status[account_name]["error_count"] = 0
                
                success = True
                logger.info(f"图片已发送到账号 {account_name}")
            except Exception as e:
                # 更新账号状态
                self.account_status[account_name]["error_count"] += 1
                if self.account_status[account_name]["error_count"] >= 3:
                    self.account_status[account_name]["active"] = False
                    
                logger.error(f"发送图片到账号 {account_name} 失败: {e}")
                
        return success
        
    def check_accounts_status(self):
        """检查所有账号状态"""
        # 与原版相同，检查账号状态
        for name, account in self.accounts.items():
            try:
                # 发送测试消息或获取bot信息
                bot_info = account["bot"].get_me()
                
                # 更新账号状态
                self.account_status[name]["active"] = True
                self.account_status[name]["last_check"] = time.time()
                self.account_status[name]["error_count"] = 0
                
                logger.info(f"账号 {name} 状态正常: {bot_info.first_name}")
            except Exception as e:
                self.account_status[name]["error_count"] += 1
                if self.account_status[name]["error_count"] >= 3:
                    self.account_status[name]["active"] = False
                    
                logger.error(f"账号 {name} 状态检查失败: {e}")
                
        # 返回活跃账号数量
        active_count = sum(1 for status in self.account_status.values() if status["active"])
        return active_count
        
    def format_enriched_price_alert(self, enriched_alert):
        """格式化丰富的价格预警消息"""
        # 准备基础数据
        exchange = enriched_alert["exchange"].capitalize()
        symbol = enriched_alert["symbol"]
        price = enriched_alert["price"]
        change = enriched_alert["change"]
        base_symbol = symbol.split('/')[0]
        
        # 设置方向和表情
        if change > 0:
            direction = "上涨"
            emoji = "🚀"
        else:
            direction = "下跌"
            emoji = "📉"
            
        # 准备格式化数据
        format_data = {
            "emoji": emoji,
            "exchange": exchange,
            "symbol": symbol,
            "base_symbol": base_symbol,
            "price": price,
            "change": abs(change),
            "direction": direction,
            "volume_24h": self._format_number(enriched_alert.get("volume_24h", 0)),
            "market_cap": self._format_number(enriched_alert.get("market_cap", 0)),
            "rank": enriched_alert.get("rank", "N/A"),
            "circulating_supply": self._format_number(enriched_alert.get("circulating_supply", 0))
        }
        
        # 添加币种信息
        if "coin_info" in enriched_alert and enriched_alert["coin_info"]:
            coin_info = enriched_alert["coin_info"]
            format_data["name"] = coin_info.get("name", base_symbol)
            format_data["description"] = coin_info.get("description", "暂无描述")
            format_data["categories"] = ", ".join(coin_info.get("categories", []))
            format_data["launch_date"] = coin_info.get("launch_date", "未知")
        else:
            format_data["name"] = base_symbol
            format_data["description"] = "暂无描述"
            format_data["categories"] = ""
            format_data["launch_date"] = "未知"
            
        # 添加合约信息
        if "contract_info" in enriched_alert and enriched_alert["contract_info"]:
            contract_info = enriched_alert["contract_info"]
            if contract_info.get("platform") and contract_info.get("contract_address"):
                format_data["contract_info"] = f"平台: `{contract_info['platform']}`\n合约地址: `{contract_info['contract_address']}`"
            else:
                format_data["contract_info"] = "暂无合约信息"
        else:
            format_data["contract_info"] = "暂无合约信息"
            
        # 添加价格分析
        if "price_analysis" in enriched_alert and enriched_alert["price_analysis"]:
            analysis = enriched_alert["price_analysis"]
            format_data["price_analysis_summary"] = analysis.get("summary", "暂无分析")
            
            # 添加分析因素
            factors = analysis.get("factors", [])
            if factors:
                format_data["price_analysis_factors"] = "\n".join([f"- {factor}" for factor in factors])
            else:
                format_data["price_analysis_factors"] = "暂无具体因素"
                
            # 添加技术指标
            if "technical_indicators" in analysis:
                indicators = []
                for name, value in analysis["technical_indicators"].items():
                    indicators.append(f"{name.upper()}: {value}")
                format_data["technical_indicators"] = "\n".join(indicators)
            else:
                format_data["technical_indicators"] = "暂无技术指标"
        else:
            format_data["price_analysis_summary"] = "暂无分析"
            format_data["price_analysis_factors"] = "暂无具体因素"
            format_data["technical_indicators"] = "暂无技术指标"
            
        # 添加外部分析
        if "external_analysis" in enriched_alert:
            ext = enriched_alert["external_analysis"]
            
            # 添加新闻
            news_items = ext.get("news", [])
            if news_items:
                news_text = []
                for news in news_items[:3]:  # 最多显示3条
                    news_text.append(f"- [{news['title']}]({news['url']})")
                format_data["news"] = "\n".join(news_text)
            else:
                format_data["news"] = "暂无相关新闻"
                
            # 添加社交情绪
            if ext.get("social_sentiment") and ext["social_sentiment"].get("overall"):
                format_data["social_sentiment"] = ext["social_sentiment"]["overall"]
            else:
                format_data["social_sentiment"] = "暂无数据"
                
            # 添加分析师观点
            opinions = ext.get("analyst_opinions", [])
            if opinions:
                opinion_text = []
                for opinion in opinions[:2]:  # 最多显示2条
                    opinion_text.append(f"- {opinion['analyst']} ({opinion['source']}): {opinion['opinion']}, {opinion['target_price']}")
                format_data["analyst_opinions"] = "\n".join(opinion_text)
            else:
                format_data["analyst_opinions"] = "暂无分析师观点"
        else:
            format_data["news"] = "暂无相关新闻"
            format_data["social_sentiment"] = "暂无数据"
            format_data["analyst_opinions"] = "暂无分析师观点"
            
        # 添加相关链接
        if "links" in enriched_alert:
            links = enriched_alert["links"]
            link_parts = []
            
            if links.get("website"):
                link_parts.append(f"[官网]({links['website']})")
            if links.get("twitter"):
                link_parts.append(f"[Twitter]({links['twitter']})")
            if links.get("telegram"):
                link_parts.append(f"[Telegram]({links['telegram']})")
            if links.get("github"):
                link_parts.append(f"[GitHub]({links['github']})")
            if links.get("explorer"):
                link_parts.append(f"[区块浏览器]({links['explorer']})")
                
            format_data["links"] = " | ".join(link_parts) if link_parts else "暂无相关链接"
        else:
            format_data["links"] = "暂无相关链接"
            
        # 使用模板格式化消息
        try:
            template = self.message_templates.get("enriched_price_alert")
            message = template.format(**format_data)
        except Exception as e:
            logger.error(f"格式化丰富价格预警消息失败: {e}")
            # 使用简单格式作为后备
            message = self._format_simple_price_alert(enriched_alert)
            
        return message
        
    def _format_simple_price_alert(self, alert):
        """格式化简单价格预警消息（作为后备）"""
        exchange = alert["exchange"].capitalize()
        symbol = alert["symbol"]
        price = alert["price"]
        change = alert["change"]
        
        if change > 0:
            direction = "上涨"
            emoji = "🚀"
        else:
            direction = "下跌"
            emoji = "📉"
            
        message = f"{emoji} *价格预警* {emoji}\n\n"
        message += f"交易所: `{exchange}`\n"
        message += f"币种: `{symbol}`\n"
        message += f"{direction}: `{abs(change)}%`\n"
        message += f"当前价格: `{price}`"
        
        return message
        
    def _format_number(self, number):
        """格式化数字"""
        if number is None or number == 0:
            return "N/A"
            
        if number >= 1_000_000_000:
            return f"{number / 1_000_000_000:.2f}B"
        elif number >= 1_000_000:
            return f"{number / 1_000_000:.2f}M"
        elif number >= 1_000:
            return f"{number / 1_000:.2f}K"
        else:
            return f"{number:.2f}"
            
    def generate_price_chart(self, symbol, historical_data, output_dir="/tmp"):
        """生成价格图表"""
        try:
            # 确保输出目录存在
            os.makedirs(output_dir, exist_ok=True)
            
            # 准备数据
            timestamps = [entry[0] for entry in historical_data]
            prices = [entry[1] for entry in historical_data]
            
            # 转换时间戳为可读时间
            dates = [datetime.fromtimestamp(ts / 1000).strftime('%m-%d %H:%M') for ts in timestamps]
            
            # 创建图表
            plt.figure(figsize=(10, 6))
            plt.plot(dates, prices, 'b-')
            plt.title(f"{symbol} 价格走势")
            plt.xlabel("日期")
            plt.ylabel("价格 (USDT)")
            plt.xticks(rotation=45)
            plt.grid(True)
            plt.tight_layout()
            
            # 保存图表
            chart_path = os.path.join(output_dir, f"{symbol.replace('/', '_')}_chart.png")
            plt.savefig(chart_path)
            plt.close()
            
            return chart_path
        except Exception as e:
            logger.error(f"生成价格图表失败: {e}")
            return None
            
    def notify_enriched_price_alert(self, enriched_alert, include_chart=True):
        """发送丰富的价格预警通知"""
        # 检查是否需要限流
        symbol = enriched_alert["symbol"]
        alert_type = enriched_alert["type"]
        key = f"{symbol}_{alert_type}"
        
        current_time = time.time()
        if key in self.last_notification_time:
            time_diff = current_time - self.last_notification_time[key]
            min_interval = self.config.get("min_alert_interval", 300)  # 默认5分钟
            
            if time_diff < min_interval:
                logger.info(f"跳过{symbol}的{alert_type}预警，距离上次通知仅{time_diff}秒")
                return False
                
        # 格式化消息
        message = self.format_enriched_price_alert(enriched_alert)
        
        # 确定发送账号
        if alert_type == "24h_change" and abs(enriched_alert["change"]) > 20:
            # 大幅波动，发送到所有账号
            target_accounts = "all"
            message_type = "major_price_alert"
        else:
            # 普通波动，使用默认路由
            target_accounts = None
            message_type = "price_alert"
            
        # 发送消息
        result = self.send_message(message, message_type=message_type, accounts=target_accounts)
        
        # 如果包含历史数据，生成并发送价格图表
        if include_chart and "historical_data" in enriched_alert and enriched_alert["historical_data"]:
            chart_path = self.generate_price_chart(symbol, enriched_alert["historical_data"])
            if chart_path:
                caption = f"{symbol} 价格走势图"
                self.send_photo(chart_path, caption=caption, message_type=message_type, accounts=target_accounts)
                
                # 清理临时文件
                try:
                    os.remove(chart_path)
                except:
                    pass
                    
        if result:
            self.last_notification_time[key] = current_time
            
        return result
        
    def format_announcement(self, announcement):
        """格式化公告消息"""
        # 准备格式化数据
        format_data = {
            "title": announcement["title"],
            "url": announcement.get("url", ""),
            "date": announcement.get("date", ""),
            "exchange": announcement.get("exchange", "").capitalize()
        }
        
        # 使用模板格式化消息
        try:
            template = self.message_templates.get("announcement")
            message = template.format(**format_data)
        except Exception as e:
            logger.error(f"格式化公告消息失败: {e}")
            # 使用简单格式作为后备
            message = f"📢 *{format_data['exchange']}最新公告* 📢\n\n"
            message += f"*{format_data['title']}*\n\n"
            if format_data["date"]:
                message += f"发布时间: `{format_data['date']}`\n\n"
            if format_data["url"]:
                message += f"[查看详情]({format_data['url']})"
                
        return message
        
    def format_new_listing(self, listing):
        """格式化新上币公告消息"""
        # 准备格式化数据
        format_data = {
            "title": listing["title"],
            "url": listing.get("url", ""),
            "date": listing.get("date", ""),
            "exchange": listing.get("exchange", "").capitalize()
        }
        
        # 使用模板格式化消息
        try:
            template = self.message_templates.get("new_listing")
            message = template.format(**format_data)
        except Exception as e:
            logger.error(f"格式化新上币公告消息失败: {e}")
            # 使用简单格式作为后备
            message = f"🔥 *{format_data['exchange']}新币上线* 🔥\n\n"
            message += f"*{format_data['title']}*\n\n"
            if format_data["date"]:
                message += f"发布时间: `{format_data['date']}`\n\n"
            if format_data["url"]:
                message += f"[查看详情]({format_data['url']})"
                
        return message
        
    def notify_announcement(self, announcement):
        """发送公告通知"""
        message = self.format_announcement(announcement)
        return self.send_message(message, message_type="announcement")
        
    def notify_new_listing(self, listing):
        """发送新上币通知"""
        message = self.format_new_listing(listing)
        # 新上币是高优先级消息，发送到所有账号
        return self.send_message(message, message_type="new_listing", accounts="all")
        
    def send_system_message(self, message, level="info"):
        """发送系统消息"""
        if level == "error":
            emoji = "❌"
            message_type = "system_error"
        elif level == "warning":
            emoji = "⚠️"
            message_type = "system_warning"
        else:
            emoji = "ℹ️"
            message_type = "system_info"
            
        # 准备格式化数据
        format_data = {
            "emoji": emoji,
            "message": message
        }
        
        # 使用模板格式化消息
        try:
            template = self.message_templates.get("system_message")
            formatted_message = template.format(**format_data)
        except Exception as e:
            logger.error(f"格式化系统消息失败: {e}")
            # 使用简单格式作为后备
            formatted_message = f"{emoji} *系统消息* {emoji}\n\n{message}"
            
        # 系统错误消息发送到所有账号
        if level == "error":
            return self.send_message(formatted_message, message_type=message_type, accounts="all")
        else:
            return self.send_message(formatted_message, message_type=message_type)
```

### 与币种详情聚合模块的集成

```python
# 与币种详情聚合模块集成伪代码
class CryptoMonitor:
    def __init__(self, config_file):
        self.config = self._load_config(config_file)
        self.api_manager = ApiPollingManager(self.config.get("api_polling", {}))
        self.price_monitor = PriceMonitor(self.config["price_monitor"], self.api_manager)
        self.announcement_monitor = DualExchangeAnnouncementMonitor(self.config["announcement_monitor"], self.api_manager)
        self.coin_enricher = CoinDetailEnricher(self.config["coin_enricher"], self.api_manager)
        self.telegram_notifier = EnhancedTelegramNotifier(self.config["telegram"])
        self.running = False
        self.last_announcement_check = 0
        
    # ... 其他方法 ...
    
    def check_prices(self):
        """检查价格并发送预警"""
        try:
            prices = self.price_monitor.fetch_prices()
            if not prices:
                logger.info("没有获取到价格数据")
                return 0
                
            # 计算市场波动性，用于调整轮询间隔
            market_volatility = self.price_monitor.calculate_market_volatility(prices)
            next_interval = self.api_manager.calculate_adaptive_interval(market_volatility)
            logger.info(f"市场波动性: {market_volatility:.2f}%, 下次轮询间隔: {next_interval}秒")
            
            # 检查价格预警
            alerts = self.price_monitor.check_price_alerts(prices)
            
            alert_count = 0
            for alert in alerts:
                # 丰富预警信息
                enriched_alert = self.coin_enricher.enrich_alert(alert)
                
                # 获取历史价格数据用于生成图表
                try:
                    symbol = alert["symbol"].replace("/", "")
                    exchange = alert["exchange"].lower()
                    
                    if exchange == "binance":
                        historical_data = self.price_monitor.fetch_binance_historical_data(symbol, "1h", limit=24)
                    elif exchange == "gate":
                        historical_data = self.price_monitor.fetch_gate_historical_data(symbol, "1h", limit=24)
                    else:
                        historical_data = None
                        
                    if historical_data:
                        enriched_alert["historical_data"] = historical_data
                except Exception as e:
                    logger.error(f"获取{symbol}历史数据失败: {e}")
                    enriched_alert["historical_data"] = None
                
                # 发送丰富的预警通知
                if self.telegram_notifier.notify_enriched_price_alert(enriched_alert):
                    alert_count += 1
                    
            return alert_count
        except Exception as e:
            logger.error(f"价格检查失败: {e}")
            self.telegram_notifier.send_system_message(f"价格监控失败: {str(e)}", level="error")
            return 0
```

## 配置示例

```python
enhanced_telegram_config = {
    "accounts": [
        {
            "name": "main",
            "token": "YOUR_MAIN_BOT_TOKEN",
            "chat_id": "YOUR_MAIN_CHAT_ID",
            "priority": 10
        },
        {
            "name": "backup",
            "token": "YOUR_BACKUP_BOT_TOKEN",
            "chat_id": "YOUR_BACKUP_CHAT_ID",
            "priority": 5
        },
        {
            "name": "alerts",
            "token": "YOUR_ALERTS_BOT_TOKEN",
            "chat_id": "YOUR_ALERTS_CHAT_ID",
            "priority": 8
        }
    ],
    "default_account": "main",
    "message_routing": {
        "price_alert": "alerts",
        "major_price_alert": "main",
        "announcement": "main",
        "new_listing": "main",
        "system_info": "backup",
        "system_warning": "backup",
        "system_error": "main"
    },
    "min_alert_interval": 300,  # 同一币种同类型预警的最小间隔（秒）
    "max_daily_alerts": 20,     # 每日最大预警次数
    "max_message_length": 4096, # Telegram消息最大长度
    "template_file": "message_templates.json", # 消息模板文件
    "enable_charts": true,      # 是否启用价格图表
    "chart_timeframes": ["1h", "24h"], # 图表时间周期
    "split_long_messages": true # 是否分割长消息
}
```

## 实现细节与注意事项

### 1. 长消息处理

Telegram消息有长度限制（约4096个字符），丰富的币种信息可能超过这个限制。我们实现了智能消息分割功能：

- **段落级分割**：优先在段落边界分割消息
- **行级分割**：如果段落过长，在行边界分割
- **部分指示器**：为每个分割部分添加指示器（如"第1部分，共3部分"）
- **发送延迟**：在发送多个部分时添加短暂延迟，避免API限制

### 2. 富文本格式优化

为了提高消息可读性，我们优化了富文本格式：

- **Markdown支持**：使用Markdown格式美化消息
- **代码块**：使用代码块格式化数字和技术数据
- **链接格式**：优化链接显示，使用简洁的文本描述
- **表情符号**：使用适当的表情符号增强视觉效果
- **分段组织**：将不同类型的信息分段组织，提高可读性

### 3. 图表和图片支持

为了更直观地展示价格走势，我们添加了图表支持：

- **价格图表生成**：使用matplotlib生成价格走势图
- **多时间周期**：支持不同时间周期的图表（如1小时、24小时）
- **图片发送**：使用Telegram的图片发送API发送图表
- **临时文件管理**：生成图表后自动清理临时文件

### 4. 消息模板系统

为了提高灵活性，我们实现了消息模板系统：

- **模板文件**：支持从JSON文件加载自定义模板
- **默认模板**：提供默认模板作为后备
- **动态替换**：使用Python的字符串格式化功能动态替换模板中的变量
- **错误处理**：当模板格式化失败时，使用简单格式作为后备

### 5. 多账号消息分发策略优化

我们优化了多账号下的消息分发策略：

- **消息类型路由**：根据消息类型选择目标账号
- **重要性分级**：根据消息重要性决定发送范围
- **账号状态感知**：自动检测账号状态并切换
- **错误恢复**：当发送失败时，尝试使用备用账号

## 与币种详情聚合模块的集成

增强版Telegram推送模块与币种详情聚合模块无缝集成，确保丰富的币种信息能够高效地推送给用户：

1. **数据流转**：
   - 价格监控模块检测到价格异常
   - 币种详情聚合模块收集并整合丰富信息
   - 推送模块格式化并发送完整信息

2. **格式化处理**：
   - 推送模块负责将复杂的币种信息转换为易读的格式
   - 处理不同类型的数据（文本、数字、链接等）
   - 确保格式一致性和可读性

3. **图表集成**：
   - 获取历史价格数据
   - 生成价格走势图
   - 与文本消息一起发送

## 扩展功能

### 1. 交互式按钮

可以添加交互式按钮，提高用户体验：

```python
def send_message_with_buttons(self, message, buttons, message_type="general", accounts=None):
    """发送带按钮的消息"""
    if not self.accounts:
        logger.error("没有配置Telegram账号")
        return False
        
    # 确定目标账号
    target_accounts = self._get_target_accounts(message_type, accounts)
    if not target_accounts:
        return False
        
    # 创建按钮标记
    markup = InlineKeyboardMarkup(buttons)
    
    # 发送消息
    success = False
    for account_name in target_accounts:
        try:
            account = self.accounts[account_name]
            account["bot"].send_message(
                chat_id=account["chat_id"],
                text=message,
                parse_mode="Markdown",
                reply_markup=markup
            )
            
            # 更新账号状态
            self._update_account_status(account_name, True)
            
            success = True
            logger.info(f"带按钮的消息已发送到账号 {account_name}")
        except Exception as e:
            logger.error(f"发送带按钮的消息到账号 {account_name} 失败: {e}")
            self._update_account_status(account_name, False)
            
    return success
```

### 2. 消息优先级队列

可以实现消息优先级队列，确保重要消息优先发送：

```python
def add_to_message_queue(self, message, message_type, priority=1, accounts=None):
    """添加消息到优先级队列"""
    self.message_queue.put((priority, {
        "message": message,
        "message_type": message_type,
        "accounts": accounts,
        "timestamp": time.time()
    }))
    
def process_message_queue(self):
    """处理消息队列"""
    processed_count = 0
    
    while not self.message_queue.empty() and processed_count < self.max_batch_size:
        try:
            priority, message_data = self.message_queue.get()
            
            # 检查消息是否过期
            if time.time() - message_data["timestamp"] > self.message_expiry:
                logger.warning(f"消息已过期，跳过发送: {message_data['message'][:30]}...")
                continue
                
            # 发送消息
            self.send_message(
                message_data["message"],
                message_type=message_data["message_type"],
                accounts=message_data["accounts"]
            )
            
            processed_count += 1
            
            # 短暂延迟，避免API限制
            time.sleep(0.5)
        except Exception as e:
            logger.error(f"处理消息队列项失败: {e}")
            
    return processed_count
```

### 3. 多语言支持

可以添加多语言支持，适应不同用户的需求：

```python
def _load_language_templates(self):
    """加载多语言模板"""
    languages = self.config.get("languages", ["zh"])
    templates = {}
    
    for lang in languages:
        template_file = f"message_templates_{lang}.json"
        if os.path.exists(template_file):
            try:
                with open(template_file, 'r', encoding='utf-8') as f:
                    templates[lang] = json.load(f)
                logger.info(f"已加载{lang}语言模板")
            except Exception as e:
                logger.error(f"加载{lang}语言模板失败: {e}")
                
    return templates
    
def format_message(self, template_key, data, language="zh"):
    """使用指定语言格式化消息"""
    if language in self.language_templates and template_key in self.language_templates[language]:
        template = self.language_templates[language][template_key]
    else:
        template = self.message_templates.get(template_key)
        
    try:
        return template.format(**data)
    except Exception as e:
        logger.error(f"格式化消息失败: {e}")
        return str(data)
```

## 总结

增强版Telegram多账号推送模块提供了一个全面的解决方案，能够高效地推送丰富的币种信息和分析内容。该模块具有以下优势：

1. **长消息处理**：智能分割长消息，确保完整信息传递
2. **富文本格式**：优化消息格式，提高可读性
3. **图表支持**：生成并发送价格走势图，提供直观展示
4. **模板系统**：支持自定义消息模板，提高灵活性
5. **多账号管理**：优化多账号下的消息分发策略
6. **与币种详情聚合模块无缝集成**：确保丰富信息高效推送

该模块与币种详情聚合模块协同工作，为用户提供全面、直观、易读的加密货币监控信息，帮助用户及时了解市场动态并做出明智决策。
