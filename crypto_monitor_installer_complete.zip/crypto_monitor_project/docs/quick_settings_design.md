# 快速设置模块设计

## 功能概述

快速设置模块旨在提供一个简单、直观的界面，让用户能够快速配置加密货币监控系统的核心参数，包括Telegram账号、交易所API、涨幅阈值和监控频率。该模块将通过命令行界面和配置文件相结合的方式实现，确保用户可以方便地进行初始设置和后续调整。

## 设计目标

1. **简化配置流程**：减少用户配置系统的时间和复杂度
2. **集中管理设置**：将所有关键配置集中在一个模块中管理
3. **提供交互式界面**：通过命令行交互式界面引导用户完成配置
4. **支持多账号管理**：允许配置多个Telegram账号和交易所API
5. **灵活的监控参数**：支持自定义涨跌幅阈值和监控频率

## 模块结构

### 1. 配置管理器 (ConfigManager)

负责读取、验证、更新和保存配置信息。

```python
class ConfigManager:
    def __init__(self, config_file):
        self.config_file = config_file
        self.config = self._load_config()
    
    def _load_config(self):
        # 从文件加载配置，如果不存在则创建默认配置
        pass
    
    def save_config(self):
        # 将配置保存到文件
        pass
    
    def get_config(self, section=None):
        # 获取配置或特定部分的配置
        pass
    
    def update_config(self, section, key, value):
        # 更新配置
        pass
    
    def validate_config(self):
        # 验证配置的完整性和有效性
        pass
```

### 2. 交互式设置向导 (SetupWizard)

提供命令行交互式界面，引导用户完成配置。

```python
class SetupWizard:
    def __init__(self, config_manager):
        self.config_manager = config_manager
    
    def start_wizard(self):
        # 启动设置向导
        print("欢迎使用加密货币监控系统设置向导")
        self._setup_telegram()
        self._setup_exchanges()
        self._setup_thresholds()
        self._setup_monitoring_frequency()
        self.config_manager.save_config()
        print("设置完成！")
    
    def _setup_telegram(self):
        # 引导用户设置Telegram账号
        pass
    
    def _setup_exchanges(self):
        # 引导用户设置交易所API
        pass
    
    def _setup_thresholds(self):
        # 引导用户设置涨跌幅阈值
        pass
    
    def _setup_monitoring_frequency(self):
        # 引导用户设置监控频率
        pass
```

### 3. Telegram命令扩展 (TelegramSettingsCommands)

扩展Telegram命令处理器，添加设置相关命令。

```python
class TelegramSettingsCommands:
    def __init__(self, command_handler, config_manager):
        self.command_handler = command_handler
        self.config_manager = config_manager
        self._register_commands()
    
    def _register_commands(self):
        # 注册设置相关命令
        self.command_handler.command_handlers.update({
            "setapi": self.handle_set_api,
            "settelegram": self.handle_set_telegram,
            "setthreshold": self.handle_set_threshold,
            "setfrequency": self.handle_set_frequency,
            "showconfig": self.handle_show_config,
            "quicksetup": self.handle_quick_setup
        })
        
        # 注册命令快捷方式
        self.command_handler.command_shortcuts.update({
            "sa": "setapi",
            "st": "settelegram",
            "sth": "setthreshold",
            "sf": "setfrequency",
            "sc": "showconfig",
            "qs": "quicksetup"
        })
    
    def handle_set_api(self, args, user_id, chat_id):
        # 处理设置API的命令
        pass
    
    def handle_set_telegram(self, args, user_id, chat_id):
        # 处理设置Telegram的命令
        pass
    
    def handle_set_threshold(self, args, user_id, chat_id):
        # 处理设置阈值的命令
        pass
    
    def handle_set_frequency(self, args, user_id, chat_id):
        # 处理设置频率的命令
        pass
    
    def handle_show_config(self, args, user_id, chat_id):
        # 处理显示配置的命令
        pass
    
    def handle_quick_setup(self, args, user_id, chat_id):
        # 处理快速设置的命令
        pass
```

## 配置文件结构

配置文件采用JSON格式，结构如下：

```json
{
  "telegram": {
    "bots": [
      {
        "name": "主要机器人",
        "token": "YOUR_BOT_TOKEN",
        "chat_ids": ["123456789", "987654321"],
        "is_default": true
      },
      {
        "name": "备用机器人",
        "token": "BACKUP_BOT_TOKEN",
        "chat_ids": ["123456789"],
        "is_default": false
      }
    ],
    "message_templates": {
      "price_alert": "🚨 价格预警: {symbol} 价格 {direction} {percentage}%\n当前价格: {price}\n24小时变化: {change_24h}%",
      "announcement_alert": "📢 新公告: {exchange} - {title}\n{url}"
    }
  },
  "exchanges": {
    "binance": {
      "api_key": "YOUR_BINANCE_API_KEY",
      "api_secret": "YOUR_BINANCE_API_SECRET",
      "enabled": true
    },
    "gate": {
      "api_key": "YOUR_GATE_API_KEY",
      "api_secret": "YOUR_GATE_API_SECRET",
      "enabled": true
    }
  },
  "thresholds": {
    "price": {
      "5m": 3.0,
      "15m": 5.0,
      "1h": 8.0,
      "24h": 15.0
    },
    "volume": {
      "1h": 200.0,
      "24h": 500.0
    }
  },
  "monitoring": {
    "price_check_interval": 60,
    "announcement_check_interval": 3600,
    "max_symbols_per_request": 100,
    "retry_interval": 10,
    "max_retries": 3
  },
  "user_settings": {
    "123456789": {
      "role": "admin",
      "notifications_paused": false,
      "custom_thresholds": {
        "price": {
          "1h": 10.0
        }
      },
      "watchlist": ["BTC/USDT", "ETH/USDT"]
    }
  }
}
```

## 快速设置流程

### 初始设置流程

1. 用户运行设置向导：`python setup_wizard.py`
2. 向导引导用户输入Telegram Bot Token和Chat ID
3. 向导引导用户输入交易所API密钥
4. 向导引导用户设置涨跌幅阈值
5. 向导引导用户设置监控频率
6. 配置保存到文件，系统准备就绪

### Telegram命令设置流程

1. 用户发送 `/quicksetup` 命令启动快速设置
2. 机器人引导用户通过一系列消息完成设置
3. 用户可以使用单独的命令设置特定参数：
   - `/setapi binance YOUR_API_KEY YOUR_API_SECRET` - 设置交易所API
   - `/settelegram add BOT_TOKEN CHAT_ID` - 添加Telegram账号
   - `/setthreshold 1h 10` - 设置1小时涨跌幅阈值为10%
   - `/setfrequency price 30` - 设置价格检查间隔为30秒

## 安全考虑

1. **API密钥保护**：
   - 配置文件权限设置为仅所有者可读写
   - API密钥在存储前进行加密
   - 提供选项使用环境变量而非配置文件存储敏感信息

2. **权限控制**：
   - 设置命令仅对管理员角色开放
   - 验证用户身份后才允许修改关键配置

3. **输入验证**：
   - 所有用户输入经过严格验证
   - 防止注入攻击和格式错误

## 用户体验优化

1. **引导式设置**：
   - 每个设置步骤提供清晰说明
   - 对每个参数提供默认值和建议范围

2. **配置验证**：
   - 实时验证API密钥有效性
   - 检查Telegram Bot是否可访问

3. **设置反馈**：
   - 每完成一项设置提供确认信息
   - 设置完成后显示摘要信息

4. **错误处理**：
   - 友好的错误提示
   - 提供问题解决建议

## 实现示例

### 命令行设置向导示例

```
欢迎使用加密货币监控系统设置向导!

===== Telegram设置 =====
请输入您的Telegram Bot Token (从BotFather获取): 1234567890:ABCDEF...
请输入您的Telegram Chat ID: 123456789
是否添加更多Telegram账号? (y/n): n

===== 交易所API设置 =====
设置币安API:
API Key: YOUR_BINANCE_API_KEY
API Secret: YOUR_BINANCE_API_SECRET
设置Gate API:
API Key: YOUR_GATE_API_KEY
API Secret: YOUR_GATE_API_SECRET

===== 涨跌幅阈值设置 =====
设置5分钟涨跌幅阈值 (默认: 3.0%): 2.5
设置15分钟涨跌幅阈值 (默认: 5.0%): 
设置1小时涨跌幅阈值 (默认: 8.0%): 10
设置24小时涨跌幅阈值 (默认: 15.0%): 20

===== 监控频率设置 =====
设置价格检查间隔 (秒, 默认: 60): 30
设置公告检查间隔 (秒, 默认: 3600): 

设置完成！配置已保存到 config.json
```

### Telegram命令设置示例

```
用户: /quicksetup
机器人: 欢迎使用快速设置向导！请选择要设置的项目:
1. Telegram账号
2. 交易所API
3. 涨跌幅阈值
4. 监控频率
5. 全部设置
请回复数字选择:

用户: 2
机器人: 请选择要设置的交易所:
1. 币安 (Binance)
2. Gate
请回复数字选择:

用户: 1
机器人: 请输入币安API Key:

用户: YOUR_BINANCE_API_KEY
机器人: 请输入币安API Secret:

用户: YOUR_BINANCE_API_SECRET
机器人: ✅ 币安API设置成功！

用户: /setthreshold 1h 10
机器人: ✅ 已设置1小时涨跌幅阈值为10%

用户: /showconfig
机器人: 📝 当前配置:
Telegram: 1个账号已配置
交易所: 币安(已启用), Gate(未配置)
涨跌幅阈值: 5m(3.0%), 15m(5.0%), 1h(10.0%), 24h(15.0%)
监控频率: 价格(30秒), 公告(3600秒)
```

## 与现有系统集成

快速设置模块将与现有的监控系统无缝集成，主要通过以下方式：

1. **配置文件共享**：所有模块使用同一个配置文件
2. **事件通知**：配置更改时通知其他模块
3. **命令扩展**：将设置命令添加到现有的Telegram命令处理器
4. **接口统一**：提供统一的配置访问接口

## 总结

快速设置模块将大大简化加密货币监控系统的配置过程，使用户能够快速上手并根据需要调整系统参数。通过命令行向导和Telegram命令两种方式，用户可以灵活地完成初始设置和后续调整，提高系统的易用性和用户体验。
