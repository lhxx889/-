# 公告监控模块
# announcement_monitor.py

import logging
import time
import threading
import json
import requests
from datetime import datetime
import traceback
from bs4 import BeautifulSoup

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("announcement_monitor")

class AnnouncementMonitor:
    """公告监控模块，负责监控交易所的公告和新上币信息"""
    
    def __init__(self, config_manager):
        """初始化公告监控模块
        
        Args:
            config_manager: ConfigManager实例
        """
        self.config_manager = config_manager
        self.config = config_manager.get_config()
        self.running = False
        self.thread = None
        self.last_check_time = 0
        self.announcements = {
            "binance": [],
            "gate": []
        }
        self.new_listings = {
            "binance": [],
            "gate": []
        }
        
        # 加载历史公告
        self._load_history()
    
    def _load_history(self):
        """加载历史公告"""
        try:
            # 尝试从文件加载历史公告
            try:
                with open("binance_announcements.json", "r", encoding="utf-8") as f:
                    self.announcements["binance"] = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                logger.info("未找到币安历史公告文件或文件格式错误，将创建新文件")
            
            try:
                with open("gate_announcements.json", "r", encoding="utf-8") as f:
                    self.announcements["gate"] = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                logger.info("未找到Gate历史公告文件或文件格式错误，将创建新文件")
            
            try:
                with open("binance_listings.json", "r", encoding="utf-8") as f:
                    self.new_listings["binance"] = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                logger.info("未找到币安新上币文件或文件格式错误，将创建新文件")
            
            try:
                with open("gate_listings.json", "r", encoding="utf-8") as f:
                    self.new_listings["gate"] = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                logger.info("未找到Gate新上币文件或文件格式错误，将创建新文件")
        except Exception as e:
            logger.error(f"加载历史公告失败: {e}")
    
    def _save_history(self):
        """保存历史公告"""
        try:
            with open("binance_announcements.json", "w", encoding="utf-8") as f:
                json.dump(self.announcements["binance"], f, ensure_ascii=False, indent=2)
            
            with open("gate_announcements.json", "w", encoding="utf-8") as f:
                json.dump(self.announcements["gate"], f, ensure_ascii=False, indent=2)
            
            with open("binance_listings.json", "w", encoding="utf-8") as f:
                json.dump(self.new_listings["binance"], f, ensure_ascii=False, indent=2)
            
            with open("gate_listings.json", "w", encoding="utf-8") as f:
                json.dump(self.new_listings["gate"], f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存历史公告失败: {e}")
    
    def start(self):
        """启动公告监控"""
        if self.running:
            logger.warning("公告监控已在运行中")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop)
        self.thread.daemon = True
        self.thread.start()
        logger.info("公告监控已启动")
    
    def stop(self):
        """停止公告监控"""
        if not self.running:
            return
        
        self.running = False
        if self.thread:
            self.thread.join(timeout=5.0)
        
        # 保存历史公告
        self._save_history()
        
        logger.info("公告监控已停止")
    
    def _monitor_loop(self):
        """监控循环"""
        while self.running:
            try:
                # 获取监控间隔
                interval = self.config.get("monitoring", {}).get("announcement_check_interval", 3600)
                
                # 检查公告
                self._check_announcements()
                
                # 更新最后检查时间
                self.last_check_time = time.time()
                
                # 保存历史公告
                self._save_history()
                
                # 等待下一次检查
                time.sleep(interval)
            except Exception as e:
                logger.error(f"公告监控异常: {e}")
                logger.error(traceback.format_exc())
                time.sleep(60)  # 出错后等待一段时间再重试
    
    def _check_announcements(self):
        """检查公告"""
        # 检查币安公告
        self._check_binance_announcements()
        
        # 检查Gate公告
        self._check_gate_announcements()
    
    def _check_binance_announcements(self):
        """检查币安公告"""
        try:
            # 获取币安公告
            announcements = self._fetch_binance_announcements()
            
            # 检查新公告
            new_announcements = []
            for announcement in announcements:
                # 检查是否已存在
                if not any(a["id"] == announcement["id"] for a in self.announcements["binance"]):
                    new_announcements.append(announcement)
                    self.announcements["binance"].append(announcement)
            
            # 检查新上币
            new_listings = []
            for announcement in new_announcements:
                if self._is_new_listing(announcement):
                    new_listings.append(announcement)
                    self.new_listings["binance"].append(announcement)
            
            # 触发通知
            if new_announcements:
                self._trigger_announcement_notification("binance", new_announcements)
            
            if new_listings:
                self._trigger_new_listing_notification("binance", new_listings)
        except Exception as e:
            logger.error(f"检查币安公告失败: {e}")
    
    def _check_gate_announcements(self):
        """检查Gate公告"""
        try:
            # 获取Gate公告
            announcements = self._fetch_gate_announcements()
            
            # 检查新公告
            new_announcements = []
            for announcement in announcements:
                # 检查是否已存在
                if not any(a["id"] == announcement["id"] for a in self.announcements["gate"]):
                    new_announcements.append(announcement)
                    self.announcements["gate"].append(announcement)
            
            # 检查新上币
            new_listings = []
            for announcement in new_announcements:
                if self._is_new_listing(announcement):
                    new_listings.append(announcement)
                    self.new_listings["gate"].append(announcement)
            
            # 触发通知
            if new_announcements:
                self._trigger_announcement_notification("gate", new_announcements)
            
            if new_listings:
                self._trigger_new_listing_notification("gate", new_listings)
        except Exception as e:
            logger.error(f"检查Gate公告失败: {e}")
    
    def _fetch_binance_announcements(self):
        """获取币安公告
        
        Returns:
            list: 公告列表
        """
        try:
            # 币安公告API
            url = "https://www.binance.com/bapi/composite/v1/public/cms/article/catalog/list/query"
            params = {
                "catalogId": "48",
                "pageNo": 1,
                "pageSize": 20,
                "rnd": str(int(time.time() * 1000))
            }
            
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            if data["success"] and "data" in data and "articles" in data["data"]:
                articles = data["data"]["articles"]
                
                announcements = []
                for article in articles:
                    announcement = {
                        "id": article["id"],
                        "title": article["title"],
                        "url": f"https://www.binance.com/en/support/announcement/{article['code']}",
                        "date": article["releaseDate"],
                        "summary": article.get("description", ""),
                        "exchange": "binance"
                    }
                    announcements.append(announcement)
                
                return announcements
            
            return []
        except Exception as e:
            logger.error(f"获取币安公告失败: {e}")
            return []
    
    def _fetch_gate_announcements(self):
        """获取Gate公告
        
        Returns:
            list: 公告列表
        """
        try:
            # Gate公告页面
            url = "https://www.gate.io/articlelist/ann"
            
            response = requests.get(url, timeout=10)
            soup = BeautifulSoup(response.text, "html.parser")
            
            announcements = []
            articles = soup.select(".article-list .article-item")
            
            for article in articles:
                try:
                    title_elem = article.select_one(".article-title")
                    date_elem = article.select_one(".article-date")
                    
                    if title_elem and date_elem:
                        title = title_elem.text.strip()
                        url = "https://www.gate.io" + title_elem["href"] if title_elem.has_attr("href") else ""
                        date = date_elem.text.strip()
                        
                        # 提取ID
                        article_id = url.split("/")[-1] if url else f"gate_{int(time.time())}"
                        
                        announcement = {
                            "id": article_id,
                            "title": title,
                            "url": url,
                            "date": date,
                            "summary": "",
                            "exchange": "gate"
                        }
                        announcements.append(announcement)
                except Exception as e:
                    logger.error(f"解析Gate公告项失败: {e}")
            
            return announcements
        except Exception as e:
            logger.error(f"获取Gate公告失败: {e}")
            return []
    
    def _is_new_listing(self, announcement):
        """检查是否为新上币公告
        
        Args:
            announcement: 公告信息
        
        Returns:
            bool: 是否为新上币公告
        """
        title = announcement["title"].lower()
        keywords = ["list", "listing", "新增", "上线", "上架", "新币", "will list"]
        
        return any(keyword in title for keyword in keywords)
    
    def _trigger_announcement_notification(self, exchange, announcements):
        """触发公告通知
        
        Args:
            exchange: 交易所名称
            announcements: 公告列表
        """
        # 这里应该将通知发送到Telegram
        # 在实际实现中，应该调用Telegram机器人发送消息
        logger.info(f"检测到{exchange.capitalize()}新公告: {len(announcements)}条")
        
        for announcement in announcements:
            message = f"📢 {exchange.capitalize()}新公告\n"
            message += f"标题: {announcement['title']}\n"
            message += f"日期: {announcement['date']}\n"
            message += f"链接: {announcement['url']}"
            
            logger.info(message)
    
    def _trigger_new_listing_notification(self, exchange, listings):
        """触发新上币通知
        
        Args:
            exchange: 交易所名称
            listings: 新上币公告列表
        """
        # 这里应该将通知发送到Telegram
        # 在实际实现中，应该调用Telegram机器人发送消息
        logger.info(f"检测到{exchange.capitalize()}新上币公告: {len(listings)}条")
        
        for listing in listings:
            message = f"🚀 {exchange.capitalize()}新上币公告\n"
            message += f"标题: {listing['title']}\n"
            message += f"日期: {listing['date']}\n"
            message += f"链接: {listing['url']}"
            
            logger.info(message)
    
    def get_latest_announcements(self, exchange=None, limit=5):
        """获取最新公告
        
        Args:
            exchange: 交易所名称，如果为None则获取所有交易所
            limit: 数量限制
        
        Returns:
            list: 公告列表
        """
        try:
            if exchange:
                # 获取指定交易所的公告
                if exchange in self.announcements:
                    announcements = sorted(
                        self.announcements[exchange],
                        key=lambda x: x["date"],
                        reverse=True
                    )
                    return announcements[:limit]
                return []
            
            # 获取所有交易所的公告
            all_announcements = []
            for ex, announcements in self.announcements.items():
                all_announcements.extend(announcements)
            
            # 按日期排序
            all_announcements = sorted(
                all_announcements,
                key=lambda x: x["date"],
                reverse=True
            )
            
            return all_announcements[:limit]
        except Exception as e:
            logger.error(f"获取最新公告失败: {e}")
            return []
    
    def get_latest_listings(self, exchange=None, limit=5):
        """获取最新上币公告
        
        Args:
            exchange: 交易所名称，如果为None则获取所有交易所
            limit: 数量限制
        
        Returns:
            list: 公告列表
        """
        try:
            if exchange:
                # 获取指定交易所的新上币公告
                if exchange in self.new_listings:
                    listings = sorted(
                        self.new_listings[exchange],
                        key=lambda x: x["date"],
                        reverse=True
                    )
                    return listings[:limit]
                return []
            
            # 获取所有交易所的新上币公告
            all_listings = []
            for ex, listings in self.new_listings.items():
                all_listings.extend(listings)
            
            # 按日期排序
            all_listings = sorted(
                all_listings,
                key=lambda x: x["date"],
                reverse=True
            )
            
            return all_listings[:limit]
        except Exception as e:
            logger.error(f"获取最新上币公告失败: {e}")
            return []
    
    def get_last_check_time(self):
        """获取最后检查时间
        
        Returns:
            float: 时间戳
        """
        return self.last_check_time
    
    def force_check(self):
        """强制检查公告
        
        Returns:
            tuple: (新公告数量, 新上币公告数量)
        """
        try:
            # 检查公告
            old_binance_count = len(self.announcements["binance"])
            old_gate_count = len(self.announcements["gate"])
            old_binance_listings_count = len(self.new_listings["binance"])
            old_gate_listings_count = len(self.new_listings["gate"])
            
            self._check_announcements()
            
            # 计算新增数量
            new_announcements_count = (
                len(self.announcements["binance"]) - old_binance_count +
                len(self.announcements["gate"]) - old_gate_count
            )
            
            new_listings_count = (
                len(self.new_listings["binance"]) - old_binance_listings_count +
                len(self.new_listings["gate"]) - old_gate_listings_count
            )
            
            return (new_announcements_count, new_listings_count)
        except Exception as e:
            logger.error(f"强制检查公告失败: {e}")
            return (0, 0)
    
    def search_announcements(self, keyword, exchange=None, limit=10):
        """搜索公告
        
        Args:
            keyword: 关键词
            exchange: 交易所名称，如果为None则搜索所有交易所
            limit: 数量限制
        
        Returns:
            list: 公告列表
        """
        try:
            keyword = keyword.lower()
            results = []
            
            if exchange:
                # 搜索指定交易所的公告
                if exchange in self.announcements:
                    for announcement in self.announcements[exchange]:
                        if keyword in announcement["title"].lower() or keyword in announcement.get("summary", "").lower():
                            results.append(announcement)
            else:
                # 搜索所有交易所的公告
                for ex, announcements in self.announcements.items():
                    for announcement in announcements:
                        if keyword in announcement["title"].lower() or keyword in announcement.get("summary", "").lower():
                            results.append(announcement)
            
            # 按日期排序
            results = sorted(
                results,
                key=lambda x: x["date"],
                reverse=True
            )
            
            return results[:limit]
        except Exception as e:
            logger.error(f"搜索公告失败: {e}")
            return []
