# 加密货币监控系统

## 项目简介

这是一个功能完善的加密货币交易所监控系统，可以监控币安和Gate交易所的价格波动、公告和新上币信息，并将监控到的信息推送到Telegram。

## 主要功能

- **价格监控**：监控币安和Gate交易所的价格涨跌幅
- **公告监控**：每小时检查币安和Gate的最新公告和新上币信息
- **币种详情**：收集并整合丰富的币种信息和分析内容
- **Telegram推送**：将监控信息推送到多个Telegram账号
- **快捷命令**：通过Telegram命令快速查询和控制系统
- **快速设置**：便捷配置Telegram账号、交易所API、阈值和监控频率

## 安装说明

### 方法一：一键安装（推荐）

#### Linux/macOS

1. 解压下载的安装包
2. 进入项目目录
3. 运行安装脚本：
   ```bash
   chmod +x install.sh
   ./install.sh
   ```
4. 按照提示完成配置

#### Windows

1. 解压下载的安装包
2. 进入项目目录
3. 双击运行`install.bat`
4. 按照提示完成配置

### 方法二：使用pip安装

```bash
pip install -e .
```

## 使用说明

### 首次运行

首次运行前，请使用快速设置向导配置系统：

```bash
# Linux/macOS
source venv/bin/activate
python -c "from quick_settings import ConfigManager, SetupWizard; SetupWizard(ConfigManager('config.json')).start_wizard()"

# Windows
call venv\Scripts\activate.bat
python -c "from quick_settings import ConfigManager, SetupWizard; SetupWizard(ConfigManager('config.json')).start_wizard()"
```

### 启动系统

```bash
# Linux/macOS
./start.sh

# Windows
start.bat
```

### Telegram命令

系统支持多种Telegram命令，包括：

- `/price <币种>` - 查询币种价格
- `/chart <币种> [时间周期]` - 获取价格图表
- `/watch <币种>` - 添加币种到监控列表
- `/info <币种>` - 获取币种详细信息
- `/announcements [数量]` - 获取最新公告

更多命令请参考`telegram_shortcut_commands.md`文档。

## 配置说明

系统配置存储在`config.json`文件中，包括：

- Telegram账号配置
- 交易所API配置
- 涨跌幅阈值配置
- 监控频率配置

您可以通过快速设置向导或Telegram命令修改配置。

## 项目结构

```
crypto_monitor_project/
├── main.py                      # 主程序入口
├── price_monitor.py             # 价格监控模块
├── announcement_monitor.py      # 公告监控模块
├── coin_detail_enricher.py      # 币种详情模块
├── telegram_bot.py              # Telegram机器人主模块
├── telegram_commands.py         # Telegram命令处理模块
├── quick_settings.py            # 快速设置模块
├── config.json                  # 配置文件
├── requirements.txt             # 依赖包列表
├── install.sh                   # Linux/macOS安装脚本
├── install.bat                  # Windows安装脚本
├── setup.py                     # Python安装脚本
└── docs/                        # 文档目录
    ├── quick_settings_design.md
    ├── telegram_shortcut_commands.md
    ├── dual_exchange_announcement_monitor.md
    ├── enhanced_telegram_push.md
    └── coin_detail_enrichment_module.md
```

## 系统要求

- Python 3.6+
- 互联网连接
- Telegram Bot Token
- 交易所API密钥（可选）

## 许可证

MIT License
