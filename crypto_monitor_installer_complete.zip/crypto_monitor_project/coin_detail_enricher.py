# 币种详情与市场信息聚合模块
# coin_detail_enricher.py

import logging
import time
import threading
import json
import requests
from datetime import datetime
import traceback
from bs4 import BeautifulSoup
import re

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("coin_detail_enricher")

class CoinDetailEnricher:
    """币种详情与市场信息聚合模块，负责收集币种的详细信息和市场分析"""
    
    def __init__(self, config_manager):
        """初始化币种详情模块
        
        Args:
            config_manager: ConfigManager实例
        """
        self.config_manager = config_manager
        self.config = config_manager.get_config()
        self.cache = {}  # 币种 -> 详情数据
        self.cache_time = {}  # 币种 -> 缓存时间
        self.cache_duration = 3600  # 缓存有效期（秒）
        
        # 初始化API客户端
        self._init_api_clients()
    
    def _init_api_clients(self):
        """初始化API客户端"""
        try:
            # 这里是示例代码，实际实现需要根据具体的API
            self.api_clients = {}
            
            # 初始化CoinGecko API客户端
            try:
                self.api_clients["coingecko"] = {
                    "base_url": "https://api.coingecko.com/api/v3",
                    "rate_limit": 50,  # 每分钟请求数
                    "last_request": 0
                }
                logger.info("CoinGecko API客户端初始化成功")
            except Exception as e:
                logger.error(f"初始化CoinGecko API客户端失败: {e}")
            
            # 初始化CoinMarketCap API客户端
            try:
                api_key = self.config_manager.get_sensitive_value("api_keys", "coinmarketcap")
                if api_key:
                    self.api_clients["coinmarketcap"] = {
                        "base_url": "https://pro-api.coinmarketcap.com/v1",
                        "headers": {
                            "X-CMC_PRO_API_KEY": api_key
                        },
                        "rate_limit": 30,  # 每分钟请求数
                        "last_request": 0
                    }
                    logger.info("CoinMarketCap API客户端初始化成功")
                else:
                    logger.warning("CoinMarketCap API密钥未配置")
            except Exception as e:
                logger.error(f"初始化CoinMarketCap API客户端失败: {e}")
            
            if not self.api_clients:
                logger.warning("未初始化任何API客户端，将使用模拟数据")
                # 使用模拟API客户端
                self.api_clients["mock"] = {
                    "base_url": "mock://api.example.com",
                    "rate_limit": 1000,
                    "last_request": 0
                }
        except Exception as e:
            logger.error(f"初始化API客户端失败: {e}")
            # 使用模拟API客户端作为后备
            self.api_clients["mock"] = {
                "base_url": "mock://api.example.com",
                "rate_limit": 1000,
                "last_request": 0
            }
    
    def get_coin_details(self, symbol, force_refresh=False):
        """获取币种详细信息
        
        Args:
            symbol: 币种符号
            force_refresh: 是否强制刷新缓存
        
        Returns:
            dict: 币种详细信息
        """
        try:
            # 检查缓存
            if not force_refresh and symbol in self.cache:
                cache_time = self.cache_time.get(symbol, 0)
                if time.time() - cache_time < self.cache_duration:
                    logger.info(f"使用缓存的{symbol}详情数据")
                    return self.cache[symbol]
            
            # 获取详细信息
            details = self._fetch_coin_details(symbol)
            
            if details:
                # 更新缓存
                self.cache[symbol] = details
                self.cache_time[symbol] = time.time()
                return details
            
            # 如果获取失败但有缓存，返回缓存数据
            if symbol in self.cache:
                logger.warning(f"获取{symbol}详情失败，使用缓存数据")
                return self.cache[symbol]
            
            return None
        except Exception as e:
            logger.error(f"获取{symbol}详情失败: {e}")
            logger.error(traceback.format_exc())
            
            # 如果有缓存，返回缓存数据
            if symbol in self.cache:
                return self.cache[symbol]
            
            return None
    
    def _fetch_coin_details(self, symbol):
        """获取币种详细信息
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 币种详细信息
        """
        # 标准化符号
        symbol = self._normalize_symbol(symbol)
        
        # 尝试从不同API获取数据
        details = None
        
        # 尝试从CoinGecko获取
        if "coingecko" in self.api_clients:
            try:
                details = self._fetch_from_coingecko(symbol)
                if details:
                    return details
            except Exception as e:
                logger.error(f"从CoinGecko获取{symbol}详情失败: {e}")
        
        # 尝试从CoinMarketCap获取
        if "coinmarketcap" in self.api_clients:
            try:
                details = self._fetch_from_coinmarketcap(symbol)
                if details:
                    return details
            except Exception as e:
                logger.error(f"从CoinMarketCap获取{symbol}详情失败: {e}")
        
        # 如果都失败了，使用模拟数据
        if "mock" in self.api_clients:
            try:
                details = self._generate_mock_details(symbol)
                if details:
                    return details
            except Exception as e:
                logger.error(f"生成{symbol}模拟详情失败: {e}")
        
        return None
    
    def _normalize_symbol(self, symbol):
        """标准化币种符号
        
        Args:
            symbol: 币种符号
        
        Returns:
            str: 标准化后的符号
        """
        # 移除交易对后缀
        symbol = symbol.split("/")[0] if "/" in symbol else symbol
        
        # 转换为小写
        return symbol.lower()
    
    def _fetch_from_coingecko(self, symbol):
        """从CoinGecko获取币种详情
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 币种详情
        """
        try:
            # 币种ID映射
            symbol_to_id = {
                "btc": "bitcoin",
                "eth": "ethereum",
                "bnb": "binancecoin",
                "sol": "solana",
                "ada": "cardano",
                "xrp": "ripple",
                "doge": "dogecoin",
                "dot": "polkadot",
                "avax": "avalanche-2",
                "shib": "shiba-inu"
            }
            
            # 获取币种ID
            coin_id = symbol_to_id.get(symbol.lower())
            if not coin_id:
                # 尝试搜索币种
                client = self.api_clients["coingecko"]
                search_url = f"{client['base_url']}/search?query={symbol}"
                
                # 限制请求频率
                self._respect_rate_limit("coingecko")
                
                response = requests.get(search_url, timeout=10)
                data = response.json()
                
                if "coins" in data and data["coins"]:
                    coin_id = data["coins"][0]["id"]
                else:
                    return None
            
            # 获取币种详情
            client = self.api_clients["coingecko"]
            url = f"{client['base_url']}/coins/{coin_id}?localization=false&tickers=false&market_data=true&community_data=true&developer_data=false&sparkline=false"
            
            # 限制请求频率
            self._respect_rate_limit("coingecko")
            
            response = requests.get(url, timeout=10)
            data = response.json()
            
            # 解析数据
            details = {
                "name": data.get("name", ""),
                "symbol": data.get("symbol", "").upper(),
                "description": data.get("description", {}).get("en", ""),
                "market_data": {
                    "current_price": data.get("market_data", {}).get("current_price", {}).get("usd", 0),
                    "market_cap": data.get("market_data", {}).get("market_cap", {}).get("usd", 0),
                    "market_cap_rank": data.get("market_data", {}).get("market_cap_rank", 0),
                    "total_volume": data.get("market_data", {}).get("total_volume", {}).get("usd", 0),
                    "high_24h": data.get("market_data", {}).get("high_24h", {}).get("usd", 0),
                    "low_24h": data.get("market_data", {}).get("low_24h", {}).get("usd", 0),
                    "price_change_24h": data.get("market_data", {}).get("price_change_percentage_24h", 0),
                    "price_change_7d": data.get("market_data", {}).get("price_change_percentage_7d", 0),
                    "price_change_30d": data.get("market_data", {}).get("price_change_percentage_30d", 0)
                },
                "links": {
                    "homepage": data.get("links", {}).get("homepage", [""])[0],
                    "blockchain_site": data.get("links", {}).get("blockchain_site", [""])[0],
                    "official_forum_url": data.get("links", {}).get("official_forum_url", [""])[0],
                    "chat_url": data.get("links", {}).get("chat_url", [""])[0],
                    "twitter_screen_name": data.get("links", {}).get("twitter_screen_name", ""),
                    "telegram_channel_identifier": data.get("links", {}).get("telegram_channel_identifier", ""),
                    "subreddit_url": data.get("links", {}).get("subreddit_url", "")
                },
                "image": {
                    "thumb": data.get("image", {}).get("thumb", ""),
                    "small": data.get("image", {}).get("small", ""),
                    "large": data.get("image", {}).get("large", "")
                },
                "contract_address": data.get("contract_address", ""),
                "categories": data.get("categories", []),
                "source": "coingecko"
            }
            
            return details
        except Exception as e:
            logger.error(f"从CoinGecko获取{symbol}详情失败: {e}")
            return None
    
    def _fetch_from_coinmarketcap(self, symbol):
        """从CoinMarketCap获取币种详情
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 币种详情
        """
        try:
            # 获取币种ID
            client = self.api_clients["coinmarketcap"]
            url = f"{client['base_url']}/cryptocurrency/quotes/latest"
            params = {
                "symbol": symbol.upper()
            }
            
            # 限制请求频率
            self._respect_rate_limit("coinmarketcap")
            
            response = requests.get(
                url,
                params=params,
                headers=client["headers"],
                timeout=10
            )
            data = response.json()
            
            if "data" in data and symbol.upper() in data["data"]:
                coin_data = data["data"][symbol.upper()]
                
                # 解析数据
                details = {
                    "name": coin_data.get("name", ""),
                    "symbol": coin_data.get("symbol", ""),
                    "description": "",  # CoinMarketCap API不提供描述
                    "market_data": {
                        "current_price": coin_data.get("quote", {}).get("USD", {}).get("price", 0),
                        "market_cap": coin_data.get("quote", {}).get("USD", {}).get("market_cap", 0),
                        "market_cap_rank": coin_data.get("cmc_rank", 0),
                        "total_volume": coin_data.get("quote", {}).get("USD", {}).get("volume_24h", 0),
                        "high_24h": 0,  # CoinMarketCap API不提供24小时最高价
                        "low_24h": 0,  # CoinMarketCap API不提供24小时最低价
                        "price_change_24h": coin_data.get("quote", {}).get("USD", {}).get("percent_change_24h", 0),
                        "price_change_7d": coin_data.get("quote", {}).get("USD", {}).get("percent_change_7d", 0),
                        "price_change_30d": coin_data.get("quote", {}).get("USD", {}).get("percent_change_30d", 0)
                    },
                    "links": {
                        "homepage": "",
                        "blockchain_site": "",
                        "official_forum_url": "",
                        "chat_url": "",
                        "twitter_screen_name": "",
                        "telegram_channel_identifier": "",
                        "subreddit_url": ""
                    },
                    "image": {
                        "thumb": f"https://s2.coinmarketcap.com/static/img/coins/64x64/{coin_data.get('id', 1)}.png",
                        "small": f"https://s2.coinmarketcap.com/static/img/coins/128x128/{coin_data.get('id', 1)}.png",
                        "large": f"https://s2.coinmarketcap.com/static/img/coins/200x200/{coin_data.get('id', 1)}.png"
                    },
                    "contract_address": "",
                    "categories": coin_data.get("tags", []),
                    "source": "coinmarketcap"
                }
                
                # 获取更多详情
                try:
                    # 限制请求频率
                    self._respect_rate_limit("coinmarketcap")
                    
                    meta_url = f"{client['base_url']}/cryptocurrency/info"
                    meta_params = {
                        "id": coin_data.get("id")
                    }
                    
                    meta_response = requests.get(
                        meta_url,
                        params=meta_params,
                        headers=client["headers"],
                        timeout=10
                    )
                    meta_data = meta_response.json()
                    
                    if "data" in meta_data and str(coin_data.get("id")) in meta_data["data"]:
                        meta = meta_data["data"][str(coin_data.get("id"))]
                        
                        details["description"] = meta.get("description", "")
                        details["links"]["homepage"] = meta.get("urls", {}).get("website", [""])[0]
                        details["links"]["blockchain_site"] = meta.get("urls", {}).get("explorer", [""])[0]
                        details["links"]["official_forum_url"] = meta.get("urls", {}).get("message_board", [""])[0]
                        details["links"]["chat_url"] = meta.get("urls", {}).get("chat", [""])[0]
                        details["links"]["twitter_screen_name"] = meta.get("urls", {}).get("twitter", [""])[0].replace("https://twitter.com/", "")
                        details["links"]["telegram_channel_identifier"] = meta.get("urls", {}).get("telegram", [""])[0].replace("https://t.me/", "")
                        details["links"]["subreddit_url"] = meta.get("urls", {}).get("reddit", [""])[0]
                        
                        if meta.get("contract_address"):
                            details["contract_address"] = meta.get("contract_address")
                except Exception as e:
                    logger.error(f"从CoinMarketCap获取{symbol}元数据失败: {e}")
                
                return details
            
            return None
        except Exception as e:
            logger.error(f"从CoinMarketCap获取{symbol}详情失败: {e}")
            return None
    
    def _generate_mock_details(self, symbol):
        """生成模拟币种详情
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 币种详情
        """
        # 模拟数据
        mock_data = {
            "btc": {
                "name": "Bitcoin",
                "symbol": "BTC",
                "description": "Bitcoin is a decentralized digital currency, without a central bank or single administrator, that can be sent from user to user on the peer-to-peer bitcoin network without the need for intermediaries.",
                "market_data": {
                    "current_price": 50000,
                    "market_cap": 950000000000,
                    "market_cap_rank": 1,
                    "total_volume": 30000000000,
                    "high_24h": 51000,
                    "low_24h": 49000,
                    "price_change_24h": 2.5,
                    "price_change_7d": 5.2,
                    "price_change_30d": 10.8
                },
                "links": {
                    "homepage": "https://bitcoin.org/",
                    "blockchain_site": "https://blockchain.info/",
                    "official_forum_url": "https://bitcointalk.org/",
                    "chat_url": "",
                    "twitter_screen_name": "bitcoin",
                    "telegram_channel_identifier": "",
                    "subreddit_url": "https://www.reddit.com/r/Bitcoin/"
                },
                "image": {
                    "thumb": "https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png",
                    "small": "https://assets.coingecko.com/coins/images/1/small/bitcoin.png",
                    "large": "https://assets.coingecko.com/coins/images/1/large/bitcoin.png"
                },
                "contract_address": "",
                "categories": ["Cryptocurrency", "Layer 1"],
                "source": "mock"
            },
            "eth": {
                "name": "Ethereum",
                "symbol": "ETH",
                "description": "Ethereum is a decentralized, open-source blockchain with smart contract functionality. Ether is the native cryptocurrency of the platform.",
                "market_data": {
                    "current_price": 3000,
                    "market_cap": 350000000000,
                    "market_cap_rank": 2,
                    "total_volume": 15000000000,
                    "high_24h": 3100,
                    "low_24h": 2900,
                    "price_change_24h": 1.8,
                    "price_change_7d": 3.5,
                    "price_change_30d": 7.2
                },
                "links": {
                    "homepage": "https://ethereum.org/",
                    "blockchain_site": "https://etherscan.io/",
                    "official_forum_url": "https://ethereum.org/en/community/",
                    "chat_url": "https://discord.com/invite/CetY6Y4",
                    "twitter_screen_name": "ethereum",
                    "telegram_channel_identifier": "",
                    "subreddit_url": "https://www.reddit.com/r/ethereum/"
                },
                "image": {
                    "thumb": "https://assets.coingecko.com/coins/images/279/thumb/ethereum.png",
                    "small": "https://assets.coingecko.com/coins/images/279/small/ethereum.png",
                    "large": "https://assets.coingecko.com/coins/images/279/large/ethereum.png"
                },
                "contract_address": "",
                "categories": ["Cryptocurrency", "Layer 1", "Smart Contract Platform"],
                "source": "mock"
            }
        }
        
        # 返回模拟数据
        if symbol.lower() in mock_data:
            return mock_data[symbol.lower()]
        
        # 生成随机数据
        import random
        
        # 生成随机价格
        price = random.uniform(0.1, 1000.0)
        
        return {
            "name": f"{symbol.upper()} Coin",
            "symbol": symbol.upper(),
            "description": f"{symbol.upper()} is a digital asset and cryptocurrency.",
            "market_data": {
                "current_price": price,
                "market_cap": price * random.uniform(1000000, 10000000000),
                "market_cap_rank": random.randint(10, 1000),
                "total_volume": price * random.uniform(100000, 1000000000),
                "high_24h": price * (1 + random.uniform(0.01, 0.1)),
                "low_24h": price * (1 - random.uniform(0.01, 0.1)),
                "price_change_24h": random.uniform(-10.0, 10.0),
                "price_change_7d": random.uniform(-20.0, 20.0),
                "price_change_30d": random.uniform(-30.0, 30.0)
            },
            "links": {
                "homepage": f"https://{symbol.lower()}.org/",
                "blockchain_site": f"https://{symbol.lower()}scan.io/",
                "official_forum_url": f"https://forum.{symbol.lower()}.org/",
                "chat_url": f"https://discord.com/invite/{symbol.lower()}",
                "twitter_screen_name": symbol.lower(),
                "telegram_channel_identifier": symbol.lower(),
                "subreddit_url": f"https://www.reddit.com/r/{symbol.lower()}/"
            },
            "image": {
                "thumb": f"https://assets.example.com/coins/images/{symbol.lower()}_thumb.png",
                "small": f"https://assets.example.com/coins/images/{symbol.lower()}_small.png",
                "large": f"https://assets.example.com/coins/images/{symbol.lower()}_large.png"
            },
            "contract_address": "0x" + "".join([random.choice("0123456789abcdef") for _ in range(40)]),
            "categories": ["Cryptocurrency"],
            "source": "mock"
        }
    
    def _respect_rate_limit(self, api_name):
        """尊重API速率限制
        
        Args:
            api_name: API名称
        """
        if api_name in self.api_clients:
            client = self.api_clients[api_name]
            
            # 计算需要等待的时间
            elapsed = time.time() - client["last_request"]
            wait_time = 60.0 / client["rate_limit"] - elapsed
            
            if wait_time > 0:
                time.sleep(wait_time)
            
            # 更新最后请求时间
            self.api_clients[api_name]["last_request"] = time.time()
    
    def get_market_analysis(self, symbol):
        """获取市场分析
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 市场分析
        """
        try:
            # 获取币种详情
            details = self.get_coin_details(symbol)
            if not details:
                return None
            
            # 获取市场数据
            market_data = details.get("market_data", {})
            
            # 生成市场分析
            analysis = {
                "price_analysis": self._analyze_price(market_data),
                "volume_analysis": self._analyze_volume(market_data),
                "market_sentiment": self._analyze_sentiment(symbol, market_data),
                "technical_indicators": self._generate_technical_indicators(symbol),
                "news_sentiment": self._analyze_news_sentiment(symbol),
                "source": "analysis"
            }
            
            return analysis
        except Exception as e:
            logger.error(f"获取{symbol}市场分析失败: {e}")
            logger.error(traceback.format_exc())
            return None
    
    def _analyze_price(self, market_data):
        """分析价格
        
        Args:
            market_data: 市场数据
        
        Returns:
            dict: 价格分析
        """
        try:
            # 获取价格数据
            current_price = market_data.get("current_price", 0)
            price_change_24h = market_data.get("price_change_24h", 0)
            price_change_7d = market_data.get("price_change_7d", 0)
            price_change_30d = market_data.get("price_change_30d", 0)
            
            # 分析价格趋势
            trend = "稳定"
            if price_change_24h > 5:
                trend = "强势上涨"
            elif price_change_24h > 2:
                trend = "上涨"
            elif price_change_24h < -5:
                trend = "强势下跌"
            elif price_change_24h < -2:
                trend = "下跌"
            
            # 分析长期趋势
            long_term_trend = "稳定"
            if price_change_30d > 20:
                long_term_trend = "强势上涨"
            elif price_change_30d > 10:
                long_term_trend = "上涨"
            elif price_change_30d < -20:
                long_term_trend = "强势下跌"
            elif price_change_30d < -10:
                long_term_trend = "下跌"
            
            # 生成价格分析
            analysis = {
                "trend": trend,
                "long_term_trend": long_term_trend,
                "volatility": "高" if abs(price_change_24h) > 10 else ("中" if abs(price_change_24h) > 5 else "低"),
                "summary": f"价格在过去24小时{trend}，30天内{long_term_trend}。"
            }
            
            # 添加价格变动原因分析
            if price_change_24h > 5:
                analysis["reason"] = "可能受到市场积极情绪、重大合作公告或技术突破的推动。"
            elif price_change_24h > 2:
                analysis["reason"] = "可能受到整体市场上涨或项目进展的影响。"
            elif price_change_24h < -5:
                analysis["reason"] = "可能受到负面消息、市场恐慌或大规模抛售的影响。"
            elif price_change_24h < -2:
                analysis["reason"] = "可能受到整体市场下跌或短期获利回吐的影响。"
            else:
                analysis["reason"] = "市场相对平稳，没有明显的价格驱动因素。"
            
            return analysis
        except Exception as e:
            logger.error(f"分析价格失败: {e}")
            return {
                "trend": "未知",
                "long_term_trend": "未知",
                "volatility": "未知",
                "summary": "无法分析价格趋势。",
                "reason": "数据不足以进行分析。"
            }
    
    def _analyze_volume(self, market_data):
        """分析交易量
        
        Args:
            market_data: 市场数据
        
        Returns:
            dict: 交易量分析
        """
        try:
            # 获取交易量数据
            total_volume = market_data.get("total_volume", 0)
            market_cap = market_data.get("market_cap", 0)
            
            # 计算交易量/市值比率
            volume_to_mcap = total_volume / market_cap if market_cap > 0 else 0
            
            # 分析交易量
            if volume_to_mcap > 0.2:
                volume_level = "非常高"
                summary = "交易量非常活跃，表明市场兴趣高涨。"
            elif volume_to_mcap > 0.1:
                volume_level = "高"
                summary = "交易量较高，市场参与度良好。"
            elif volume_to_mcap > 0.05:
                volume_level = "中等"
                summary = "交易量处于正常水平。"
            elif volume_to_mcap > 0.02:
                volume_level = "低"
                summary = "交易量较低，市场参与度有限。"
            else:
                volume_level = "非常低"
                summary = "交易量非常低，流动性可能受限。"
            
            # 生成交易量分析
            analysis = {
                "volume_level": volume_level,
                "volume_to_mcap": volume_to_mcap,
                "summary": summary
            }
            
            return analysis
        except Exception as e:
            logger.error(f"分析交易量失败: {e}")
            return {
                "volume_level": "未知",
                "volume_to_mcap": 0,
                "summary": "无法分析交易量。"
            }
    
    def _analyze_sentiment(self, symbol, market_data):
        """分析市场情绪
        
        Args:
            symbol: 币种符号
            market_data: 市场数据
        
        Returns:
            dict: 市场情绪分析
        """
        try:
            # 获取价格变动数据
            price_change_24h = market_data.get("price_change_24h", 0)
            
            # 模拟社交媒体情绪分析
            # 在实际实现中，应该从社交媒体API获取数据
            import random
            
            # 根据价格变动调整情绪基准
            sentiment_base = 50 + price_change_24h
            
            # 生成情绪数据
            twitter_sentiment = min(100, max(0, sentiment_base + random.uniform(-20, 20)))
            reddit_sentiment = min(100, max(0, sentiment_base + random.uniform(-20, 20)))
            telegram_sentiment = min(100, max(0, sentiment_base + random.uniform(-20, 20)))
            
            # 计算平均情绪
            avg_sentiment = (twitter_sentiment + reddit_sentiment + telegram_sentiment) / 3
            
            # 分析情绪
            if avg_sentiment > 75:
                sentiment = "非常乐观"
                summary = "市场情绪非常乐观，社交媒体讨论积极。"
            elif avg_sentiment > 60:
                sentiment = "乐观"
                summary = "市场情绪乐观，社交媒体讨论偏向积极。"
            elif avg_sentiment > 40:
                sentiment = "中性"
                summary = "市场情绪中性，社交媒体讨论平衡。"
            elif avg_sentiment > 25:
                sentiment = "悲观"
                summary = "市场情绪悲观，社交媒体讨论偏向消极。"
            else:
                sentiment = "非常悲观"
                summary = "市场情绪非常悲观，社交媒体讨论消极。"
            
            # 生成市场情绪分析
            analysis = {
                "sentiment": sentiment,
                "twitter_sentiment": twitter_sentiment,
                "reddit_sentiment": reddit_sentiment,
                "telegram_sentiment": telegram_sentiment,
                "summary": summary
            }
            
            return analysis
        except Exception as e:
            logger.error(f"分析市场情绪失败: {e}")
            return {
                "sentiment": "未知",
                "twitter_sentiment": 50,
                "reddit_sentiment": 50,
                "telegram_sentiment": 50,
                "summary": "无法分析市场情绪。"
            }
    
    def _generate_technical_indicators(self, symbol):
        """生成技术指标
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 技术指标
        """
        try:
            # 在实际实现中，应该从交易所API获取K线数据并计算指标
            # 这里使用模拟数据
            import random
            
            # 生成RSI
            rsi = random.uniform(0, 100)
            
            # 生成MACD
            macd = random.uniform(-10, 10)
            
            # 生成布林带
            bollinger_upper = random.uniform(105, 120)
            bollinger_lower = random.uniform(80, 95)
            
            # 分析技术指标
            if rsi > 70:
                rsi_signal = "超买"
            elif rsi < 30:
                rsi_signal = "超卖"
            else:
                rsi_signal = "中性"
            
            if macd > 2:
                macd_signal = "强烈看涨"
            elif macd > 0:
                macd_signal = "看涨"
            elif macd > -2:
                macd_signal = "看跌"
            else:
                macd_signal = "强烈看跌"
            
            # 生成技术指标分析
            analysis = {
                "rsi": {
                    "value": rsi,
                    "signal": rsi_signal
                },
                "macd": {
                    "value": macd,
                    "signal": macd_signal
                },
                "bollinger_bands": {
                    "upper": bollinger_upper,
                    "lower": bollinger_lower
                },
                "summary": f"RSI显示{rsi_signal}，MACD信号{macd_signal}。"
            }
            
            return analysis
        except Exception as e:
            logger.error(f"生成技术指标失败: {e}")
            return {
                "rsi": {
                    "value": 50,
                    "signal": "未知"
                },
                "macd": {
                    "value": 0,
                    "signal": "未知"
                },
                "bollinger_bands": {
                    "upper": 100,
                    "lower": 100
                },
                "summary": "无法生成技术指标。"
            }
    
    def _analyze_news_sentiment(self, symbol):
        """分析新闻情绪
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 新闻情绪分析
        """
        try:
            # 在实际实现中，应该从新闻API获取数据
            # 这里使用模拟数据
            import random
            
            # 生成新闻情绪
            sentiment_score = random.uniform(0, 100)
            
            # 分析新闻情绪
            if sentiment_score > 75:
                sentiment = "非常积极"
                summary = "最近的新闻报道非常积极，可能对价格产生正面影响。"
            elif sentiment_score > 60:
                sentiment = "积极"
                summary = "最近的新闻报道偏向积极，可能对价格有一定支撑。"
            elif sentiment_score > 40:
                sentiment = "中性"
                summary = "最近的新闻报道中性，对价格影响有限。"
            elif sentiment_score > 25:
                sentiment = "消极"
                summary = "最近的新闻报道偏向消极，可能对价格产生一定压力。"
            else:
                sentiment = "非常消极"
                summary = "最近的新闻报道非常消极，可能对价格产生负面影响。"
            
            # 生成模拟新闻
            recent_news = []
            for i in range(3):
                if sentiment_score > 60:
                    title = f"{symbol.upper()}价格上涨，分析师看好未来发展"
                elif sentiment_score > 40:
                    title = f"{symbol.upper()}市场稳定，项目持续发展"
                else:
                    title = f"{symbol.upper()}面临挑战，市场表现低迷"
                
                recent_news.append({
                    "title": title,
                    "url": f"https://example.com/news/{symbol.lower()}/{i}",
                    "date": datetime.now().strftime("%Y-%m-%d"),
                    "source": "Example News"
                })
            
            # 生成新闻情绪分析
            analysis = {
                "sentiment": sentiment,
                "sentiment_score": sentiment_score,
                "recent_news": recent_news,
                "summary": summary
            }
            
            return analysis
        except Exception as e:
            logger.error(f"分析新闻情绪失败: {e}")
            return {
                "sentiment": "未知",
                "sentiment_score": 50,
                "recent_news": [],
                "summary": "无法分析新闻情绪。"
            }
    
    def get_social_links(self, symbol):
        """获取社交媒体链接
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 社交媒体链接
        """
        try:
            # 获取币种详情
            details = self.get_coin_details(symbol)
            if not details:
                return None
            
            # 获取链接
            links = details.get("links", {})
            
            # 格式化链接
            social_links = {
                "website": links.get("homepage", ""),
                "twitter": f"https://twitter.com/{links.get('twitter_screen_name', '')}" if links.get("twitter_screen_name") else "",
                "telegram": f"https://t.me/{links.get('telegram_channel_identifier', '')}" if links.get("telegram_channel_identifier") else "",
                "reddit": links.get("subreddit_url", ""),
                "github": "",  # 币种详情中可能没有GitHub链接
                "explorer": links.get("blockchain_site", "")
            }
            
            return social_links
        except Exception as e:
            logger.error(f"获取{symbol}社交媒体链接失败: {e}")
            return None
    
    def get_contract_info(self, symbol):
        """获取合约信息
        
        Args:
            symbol: 币种符号
        
        Returns:
            dict: 合约信息
        """
        try:
            # 获取币种详情
            details = self.get_coin_details(symbol)
            if not details:
                return None
            
            # 获取合约地址
            contract_address = details.get("contract_address", "")
            
            if not contract_address:
                return {
                    "is_token": False,
                    "message": "这是一个原生币，没有合约地址。"
                }
            
            # 在实际实现中，应该从区块链浏览器API获取更多合约信息
            # 这里使用模拟数据
            contract_info = {
                "is_token": True,
                "address": contract_address,
                "blockchain": "Ethereum",  # 假设是以太坊代币
                "token_standard": "ERC-20",
                "explorer_url": f"https://etherscan.io/token/{contract_address}"
            }
            
            return contract_info
        except Exception as e:
            logger.error(f"获取{symbol}合约信息失败: {e}")
            return None
    
    def search_coin(self, query):
        """搜索币种
        
        Args:
            query: 搜索关键词
        
        Returns:
            list: 搜索结果
        """
        try:
            results = []
            
            # 尝试从CoinGecko搜索
            if "coingecko" in self.api_clients:
                try:
                    client = self.api_clients["coingecko"]
                    search_url = f"{client['base_url']}/search?query={query}"
                    
                    # 限制请求频率
                    self._respect_rate_limit("coingecko")
                    
                    response = requests.get(search_url, timeout=10)
                    data = response.json()
                    
                    if "coins" in data:
                        for coin in data["coins"][:5]:  # 限制结果数量
                            results.append({
                                "id": coin.get("id", ""),
                                "name": coin.get("name", ""),
                                "symbol": coin.get("symbol", "").upper(),
                                "market_cap_rank": coin.get("market_cap_rank", 0),
                                "thumb": coin.get("thumb", ""),
                                "source": "coingecko"
                            })
                except Exception as e:
                    logger.error(f"从CoinGecko搜索币种失败: {e}")
            
            # 如果没有结果，使用模拟数据
            if not results:
                # 模拟搜索结果
                if query.lower() in ["btc", "bitcoin"]:
                    results.append({
                        "id": "bitcoin",
                        "name": "Bitcoin",
                        "symbol": "BTC",
                        "market_cap_rank": 1,
                        "thumb": "https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png",
                        "source": "mock"
                    })
                elif query.lower() in ["eth", "ethereum"]:
                    results.append({
                        "id": "ethereum",
                        "name": "Ethereum",
                        "symbol": "ETH",
                        "market_cap_rank": 2,
                        "thumb": "https://assets.coingecko.com/coins/images/279/thumb/ethereum.png",
                        "source": "mock"
                    })
            
            return results
        except Exception as e:
            logger.error(f"搜索币种失败: {e}")
            return []
    
    def get_price_change_reason(self, symbol, period="24h"):
        """获取价格变动原因
        
        Args:
            symbol: 币种符号
            period: 时间周期
        
        Returns:
            str: 价格变动原因
        """
        try:
            # 获取币种详情
            details = self.get_coin_details(symbol)
            if not details:
                return "无法获取币种详情，无法分析价格变动原因。"
            
            # 获取市场数据
            market_data = details.get("market_data", {})
            
            # 获取价格变动
            price_change = 0
            if period == "24h":
                price_change = market_data.get("price_change_24h", 0)
            elif period == "7d":
                price_change = market_data.get("price_change_7d", 0)
            elif period == "30d":
                price_change = market_data.get("price_change_30d", 0)
            
            # 分析价格变动原因
            if price_change > 20:
                return "价格大幅上涨可能是由于重大利好消息、重要合作伙伴关系公告、技术突破或整体市场强劲上涨。建议查看最近的项目公告和新闻。"
            elif price_change > 10:
                return "价格明显上涨可能是由于积极的市场情绪、项目进展或投资者兴趣增加。"
            elif price_change > 5:
                return "价格小幅上涨可能是由于整体市场上涨或短期投资者兴趣。"
            elif price_change > -5:
                return "价格相对稳定，没有明显的价格驱动因素。"
            elif price_change > -10:
                return "价格小幅下跌可能是由于短期获利回吐或整体市场下跌。"
            elif price_change > -20:
                return "价格明显下跌可能是由于市场情绪转变、竞争加剧或投资者兴趣减弱。"
            else:
                return "价格大幅下跌可能是由于负面消息、项目问题、监管担忧或整体市场崩盘。建议查看最近的项目公告和新闻。"
        except Exception as e:
            logger.error(f"获取{symbol}价格变动原因失败: {e}")
            return "无法分析价格变动原因。"
    
    def clear_cache(self, symbol=None):
        """清除缓存
        
        Args:
            symbol: 币种符号，如果为None则清除所有缓存
        
        Returns:
            bool: 是否成功
        """
        try:
            if symbol:
                # 清除指定币种的缓存
                if symbol in self.cache:
                    del self.cache[symbol]
                if symbol in self.cache_time:
                    del self.cache_time[symbol]
            else:
                # 清除所有缓存
                self.cache = {}
                self.cache_time = {}
            
            return True
        except Exception as e:
            logger.error(f"清除缓存失败: {e}")
            return False
