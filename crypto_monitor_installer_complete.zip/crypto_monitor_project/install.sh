#!/bin/bash

# 加密货币监控系统安装脚本 - Linux/macOS版本
# 此脚本将安装所有依赖并设置初始配置

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_message() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查Python版本
check_python() {
    print_message "检查Python版本..."
    
    if command -v python3 &>/dev/null; then
        python_cmd="python3"
    elif command -v python &>/dev/null; then
        python_cmd="python"
    else
        print_error "未找到Python。请安装Python 3.6+后重试。"
        exit 1
    fi
    
    python_version=$($python_cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    print_message "检测到Python版本: $python_version"
    
    # 检查Python版本是否>=3.6
    if [[ $(echo "$python_version >= 3.6" | bc) -eq 1 ]]; then
        print_success "Python版本符合要求"
    else
        print_error "Python版本过低。需要Python 3.6+，请升级后重试。"
        exit 1
    fi
}

# 检查pip
check_pip() {
    print_message "检查pip..."
    
    if ! $python_cmd -m pip --version &>/dev/null; then
        print_warning "未找到pip，尝试安装..."
        
        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            $python_cmd -m ensurepip --upgrade || {
                print_error "pip安装失败。请手动安装pip后重试。"
                exit 1
            }
        else
            # Linux
            if command -v apt-get &>/dev/null; then
                sudo apt-get update
                sudo apt-get install -y python3-pip || {
                    print_error "pip安装失败。请手动安装pip后重试。"
                    exit 1
                }
            elif command -v yum &>/dev/null; then
                sudo yum install -y python3-pip || {
                    print_error "pip安装失败。请手动安装pip后重试。"
                    exit 1
                }
            else
                print_error "无法自动安装pip。请手动安装pip后重试。"
                exit 1
            fi
        fi
    fi
    
    print_success "pip检查通过"
}

# 创建虚拟环境
create_venv() {
    print_message "创建Python虚拟环境..."
    
    # 检查venv模块
    if ! $python_cmd -c "import venv" &>/dev/null; then
        print_warning "未找到venv模块，尝试安装..."
        
        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            brew install python3-venv || {
                print_error "venv安装失败。请手动安装venv后重试。"
                exit 1
            }
        else
            # Linux
            if command -v apt-get &>/dev/null; then
                sudo apt-get update
                sudo apt-get install -y python3-venv || {
                    print_error "venv安装失败。请手动安装venv后重试。"
                    exit 1
                }
            elif command -v yum &>/dev/null; then
                sudo yum install -y python3-venv || {
                    print_error "venv安装失败。请手动安装venv后重试。"
                    exit 1
                }
            else
                print_error "无法自动安装venv。请手动安装venv后重试。"
                exit 1
            fi
        fi
    fi
    
    # 创建虚拟环境
    $python_cmd -m venv venv || {
        print_error "创建虚拟环境失败。"
        exit 1
    }
    
    print_success "虚拟环境创建成功"
}

# 安装依赖
install_dependencies() {
    print_message "安装依赖..."
    
    # 激活虚拟环境
    if [[ "$OSTYPE" == "darwin"* ]] || [[ "$OSTYPE" == "linux-gnu"* ]]; then
        source venv/bin/activate || {
            print_error "激活虚拟环境失败。"
            exit 1
        }
    else
        print_error "不支持的操作系统。"
        exit 1
    fi
    
    # 升级pip
    pip install --upgrade pip || {
        print_warning "升级pip失败，继续安装依赖..."
    }
    
    # 安装依赖
    pip install -r requirements.txt || {
        print_error "安装依赖失败。"
        exit 1
    }
    
    print_success "依赖安装成功"
}

# 创建配置文件
create_config() {
    print_message "创建初始配置文件..."
    
    if [ -f "config.json" ]; then
        print_warning "配置文件已存在，跳过创建。"
    else
        # 激活虚拟环境
        if [[ "$OSTYPE" == "darwin"* ]] || [[ "$OSTYPE" == "linux-gnu"* ]]; then
            source venv/bin/activate || {
                print_error "激活虚拟环境失败。"
                exit 1
            }
        fi
        
        # 运行快速设置向导
        $python_cmd -c "from quick_settings import ConfigManager; ConfigManager('config.json').save_config()" || {
            print_error "创建配置文件失败。"
            exit 1
        }
        
        print_success "初始配置文件创建成功"
    fi
}

# 创建启动脚本
create_startup_script() {
    print_message "创建启动脚本..."
    
    cat > start.sh << 'EOF'
#!/bin/bash
# 激活虚拟环境并启动监控系统
source venv/bin/activate
python main.py
EOF
    
    chmod +x start.sh
    
    print_success "启动脚本创建成功"
}

# 主函数
main() {
    echo "=================================================="
    echo "    加密货币监控系统安装脚本 - Linux/macOS版本    "
    echo "=================================================="
    echo ""
    
    # 检查当前目录
    if [ ! -f "requirements.txt" ]; then
        print_error "未找到requirements.txt。请在项目根目录运行此脚本。"
        exit 1
    fi
    
    # 执行安装步骤
    check_python
    check_pip
    create_venv
    install_dependencies
    create_config
    create_startup_script
    
    echo ""
    echo "=================================================="
    print_success "安装完成！"
    echo ""
    echo "使用以下命令启动系统:"
    echo "  ./start.sh"
    echo ""
    echo "或者手动启动:"
    echo "  source venv/bin/activate"
    echo "  python main.py"
    echo ""
    echo "首次运行前，请使用快速设置向导配置系统:"
    echo "  source venv/bin/activate"
    echo "  python -c \"from quick_settings import ConfigManager, SetupWizard; SetupWizard(ConfigManager('config.json')).start_wizard()\""
    echo "=================================================="
}

# 执行主函数
main
