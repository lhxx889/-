#!/bin/bash

# 加密货币监控程序启动脚本
# 用于启动主程序并自动检查依赖项

# 获取脚本所在目录的绝对路径
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# 定义主程序路径和配置文件路径
PROGRAM_DIR="$1"
if [ -z "$PROGRAM_DIR" ]; then
  echo "错误: 未提供程序目录路径"
  echo "用法: $0 /path/to/crypto_monitor_directory"
  exit 1
fi

MAIN_PROGRAM="$PROGRAM_DIR/crypto_monitor_menu_enhanced.py"
CONFIG_FILE="$PROGRAM_DIR/config.json"

# 检查主程序是否存在
if [ ! -f "$MAIN_PROGRAM" ]; then
  echo "错误: 主程序不存在: $MAIN_PROGRAM"
  exit 1
fi

# 检查配置文件是否存在
if [ ! -f "$CONFIG_FILE" ]; then
  echo "警告: 配置文件不存在: $CONFIG_FILE"
fi

# 运行依赖检查脚本
echo "正在检查依赖项..."
python3 "$SCRIPT_DIR/check_dependencies.py" "$MAIN_PROGRAM" "$CONFIG_FILE"

# 脚本结束
echo "启动脚本执行完毕"

