# 加密货币监控程序 - 依赖管理包

这个包提供了加密货币监控程序所需的依赖项和工具，特别是解决了`python-telegram-bot`库的安装问题。

## 包内容

- `vendor/`: 包含所有依赖库的安装文件
  - `python_telegram_bot-13.7-py3-none-any.whl`: python-telegram-bot库
  - 其他依赖库的安装文件
- `check_dependencies.py`: 依赖检查和安装脚本
- `run_crypto_monitor.sh`: 启动脚本

## 使用方法

### 1. 设置执行权限

```bash
chmod +x run_crypto_monitor.sh
```

### 2. 运行启动脚本

```bash
./run_crypto_monitor.sh /path/to/crypto_monitor_directory
```

例如：

```bash
./run_crypto_monitor.sh /root/crypto_monitor_fixed/crypto_monitor/crypto_monitor
```

### 3. 脚本功能

启动脚本会自动：

1. 检查所有依赖项是否已安装
2. 如果有缺失的依赖项，提示从vendor目录安装
3. 检查配置文件是否正确
4. 询问是否运行主程序

## 手动使用依赖检查脚本

如果需要单独运行依赖检查脚本，可以使用以下命令：

```bash
python3 check_dependencies.py /path/to/crypto_monitor_menu_enhanced.py [/path/to/config.json]
```

配置文件路径是可选的，如果不提供，脚本会在主程序所在目录中查找`config.json`文件。

## 注意事项

- 这个包使用`--user`选项安装依赖项，不需要系统管理员权限
- 如果您的系统使用了Debian/Ubuntu的Python环境管理策略，这个包可以避免"externally-managed-environment"错误
- 包中的`python-telegram-bot`库版本为13.7，与程序兼容
- 如果您不需要Telegram功能，可以在程序中禁用它

