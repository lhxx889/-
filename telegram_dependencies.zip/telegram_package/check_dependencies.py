#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
依赖检查和安装脚本
用于检查和安装加密货币监控程序所需的依赖项
"""

import os
import sys
import subprocess
import importlib.util
import pkg_resources
import json
import argparse

# 定义所需的依赖项
REQUIRED_PACKAGES = {
    "requests": "requests",
    "beautifulsoup4": "bs4",
    "python-telegram-bot": "telegram"
}

# 定义vendor目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
VENDOR_DIR = os.path.join(SCRIPT_DIR, "vendor")

def check_package(package_name, import_name):
    """检查包是否已安装"""
    try:
        # 尝试导入模块
        spec = importlib.util.find_spec(import_name)
        if spec is not None:
            # 如果能够导入，检查版本
            if package_name == "python-telegram-bot":
                try:
                    version = pkg_resources.get_distribution(package_name).version
                    print(f"✅ {package_name} 已安装 (版本: {version})")
                    if version.startswith("13."):
                        return True
                    else:
                        print(f"⚠️  警告: {package_name} 版本 {version} 可能与程序不兼容，推荐版本: 13.7")
                        return False
                except pkg_resources.DistributionNotFound:
                    print(f"⚠️  警告: 找到 {import_name} 模块，但无法确定 {package_name} 的版本")
                    return False
            else:
                try:
                    version = pkg_resources.get_distribution(package_name).version
                    print(f"✅ {package_name} 已安装 (版本: {version})")
                except pkg_resources.DistributionNotFound:
                    print(f"✅ {package_name} 已安装 (版本未知)")
                return True
        else:
            print(f"❌ {package_name} 未安装")
            return False
    except Exception as e:
        print(f"❌ 检查 {package_name} 时出错: {e}")
        return False

def install_package_from_vendor(package_name):
    """从vendor目录安装包"""
    # 查找包文件
    package_files = [f for f in os.listdir(VENDOR_DIR) if f.startswith(package_name.replace("-", "_"))]
    if not package_files:
        print(f"❌ 在vendor目录中未找到 {package_name} 的安装文件")
        return False
    
    # 安装包
    package_path = os.path.join(VENDOR_DIR, package_files[0])
    try:
        print(f"正在安装 {package_name}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", package_path])
        print(f"✅ {package_name} 安装成功")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 安装 {package_name} 失败: {e}")
        return False

def install_dependencies_from_vendor():
    """从vendor目录安装所有依赖项"""
    # 获取vendor目录中的所有文件
    if not os.path.exists(VENDOR_DIR):
        print(f"❌ vendor目录不存在: {VENDOR_DIR}")
        return False
    
    vendor_files = os.listdir(VENDOR_DIR)
    if not vendor_files:
        print("❌ vendor目录为空")
        return False
    
    print(f"在vendor目录中找到 {len(vendor_files)} 个文件")
    
    # 安装所有.whl文件
    success = True
    for file in vendor_files:
        if file.endswith(".whl"):
            file_path = os.path.join(VENDOR_DIR, file)
            try:
                print(f"正在安装 {file}...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", file_path])
                print(f"✅ {file} 安装成功")
            except subprocess.CalledProcessError as e:
                print(f"❌ 安装 {file} 失败: {e}")
                success = False
    
    return success

def check_config_file(config_path):
    """检查配置文件"""
    if not os.path.exists(config_path):
        print(f"❌ 配置文件不存在: {config_path}")
        return False
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # 检查Telegram配置
        if config.get("telegram_enabled", False):
            if not config.get("telegram_bot_token") or not config.get("telegram_chat_id"):
                print("⚠️  警告: Telegram功能已启用，但未配置Bot Token或Chat ID")
                return False
            print("✅ Telegram配置正确")
        else:
            print("ℹ️  Telegram功能已禁用")
        
        return True
    except Exception as e:
        print(f"❌ 检查配置文件时出错: {e}")
        return False

def run_main_program(program_path):
    """运行主程序"""
    if not os.path.exists(program_path):
        print(f"❌ 主程序不存在: {program_path}")
        return False
    
    try:
        print(f"正在启动主程序: {program_path}")
        subprocess.Popen([sys.executable, program_path])
        print("✅ 主程序已启动")
        return True
    except Exception as e:
        print(f"❌ 启动主程序时出错: {e}")
        return False

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="依赖检查和安装工具")
    parser.add_argument("program_path", help="主程序路径")
    parser.add_argument("config_path", nargs="?", help="配置文件路径")
    parser.add_argument("--non-interactive", action="store_true", help="非交互模式")
    return parser.parse_args()

def main():
    """主函数"""
    print("=" * 60)
    print("加密货币监控程序 - 依赖检查和安装工具")
    print("=" * 60)
    
    # 解析命令行参数
    args = parse_arguments()
    program_path = args.program_path
    config_path = args.config_path or os.path.join(os.path.dirname(program_path), "config.json")
    non_interactive = args.non_interactive or os.environ.get("TEST_MODE") == "1"
    
    print(f"主程序路径: {program_path}")
    print(f"配置文件路径: {config_path}")
    print(f"非交互模式: {'是' if non_interactive else '否'}")
    print("-" * 60)
    
    # 检查依赖项
    print("正在检查依赖项...")
    missing_packages = []
    for package_name, import_name in REQUIRED_PACKAGES.items():
        if not check_package(package_name, import_name):
            missing_packages.append(package_name)
    
    # 如果有缺失的依赖项，尝试安装
    if missing_packages:
        print("-" * 60)
        print(f"发现 {len(missing_packages)} 个缺失的依赖项")
        
        # 询问用户是否安装
        install_deps = True
        if not non_interactive:
            choice = input("是否从vendor目录安装缺失的依赖项? (y/n): ")
            install_deps = choice.lower() == 'y'
        
        if install_deps:
            print("-" * 60)
            print("正在安装依赖项...")
            install_dependencies_from_vendor()
        else:
            print("跳过安装依赖项")
    else:
        print("所有依赖项已安装")
    
    # 检查配置文件
    print("-" * 60)
    print("正在检查配置文件...")
    check_config_file(config_path)
    
    # 询问用户是否运行主程序
    print("-" * 60)
    run_program = False
    if not non_interactive:
        choice = input("是否运行主程序? (y/n): ")
        run_program = choice.lower() == 'y'
    
    if run_program:
        run_main_program(program_path)
    else:
        print("跳过运行主程序")
    
    print("-" * 60)
    print("依赖检查和安装完成")
    print("=" * 60)

if __name__ == "__main__":
    main()

