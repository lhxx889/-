#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试脚本
用于测试依赖检查和安装脚本是否正常工作
"""

import os
import sys
import subprocess
import importlib.util

def test_import_telegram():
    """测试导入telegram模块"""
    print("测试导入telegram模块...")
    try:
        import telegram
        print(f"✅ 成功导入telegram模块 (版本: {telegram.__version__})")
        return True
    except ImportError:
        print("❌ 导入telegram模块失败")
        return False

def test_check_dependencies_script(script_path):
    """测试依赖检查脚本"""
    print("测试依赖检查脚本...")
    if not os.path.exists(script_path):
        print(f"❌ 脚本不存在: {script_path}")
        return False
    
    try:
        # 创建一个临时的主程序文件
        temp_program = os.path.join(os.path.dirname(script_path), "temp_program.py")
        with open(temp_program, 'w') as f:
            f.write("print('Hello, World!')")
        
        # 运行依赖检查脚本（非交互模式）
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["TEST_MODE"] = "1"  # 设置测试模式环境变量
        
        result = subprocess.run([sys.executable, script_path, temp_program, "--non-interactive"], 
                               capture_output=True, text=True, env=env)
        
        # 删除临时文件
        os.remove(temp_program)
        
        # 检查输出
        if "正在检查依赖项" in result.stdout:
            print("✅ 依赖检查脚本运行成功")
            print(f"输出: {result.stdout[:200]}...")  # 只显示前200个字符
            return True
        else:
            print(f"❌ 依赖检查脚本运行失败: {result.stdout[:200]}...")
            return False
    except Exception as e:
        print(f"❌ 测试依赖检查脚本时出错: {e}")
        return False

def test_install_from_vendor(script_path):
    """测试从vendor目录安装库"""
    print("测试从vendor目录安装库...")
    
    # 检查vendor目录
    vendor_dir = os.path.join(os.path.dirname(script_path), "vendor")
    if not os.path.exists(vendor_dir):
        print(f"❌ vendor目录不存在: {vendor_dir}")
        return False
    
    # 检查vendor目录中的文件
    vendor_files = os.listdir(vendor_dir)
    if not vendor_files:
        print("❌ vendor目录为空")
        return False
    
    print(f"✅ vendor目录中有 {len(vendor_files)} 个文件")
    
    # 检查python-telegram-bot库文件
    telegram_files = [f for f in vendor_files if "python_telegram_bot" in f]
    if not telegram_files:
        print("❌ 未找到python-telegram-bot库文件")
        return False
    
    print(f"✅ 找到python-telegram-bot库文件: {telegram_files[0]}")
    
    return True

def main():
    """主函数"""
    print("=" * 60)
    print("测试脚本")
    print("=" * 60)
    
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 测试导入telegram模块
    test_import_telegram()
    
    # 测试依赖检查脚本
    check_dependencies_script = os.path.join(script_dir, "check_dependencies.py")
    test_check_dependencies_script(check_dependencies_script)
    
    # 测试从vendor目录安装库
    test_install_from_vendor(check_dependencies_script)
    
    print("=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == "__main__":
    main()

