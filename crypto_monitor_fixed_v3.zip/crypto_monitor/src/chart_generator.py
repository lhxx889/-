"""
Gate.io加密货币异动监控系统 - 图表生成模块
负责生成价格和交易量变化的图表
"""

import logging
import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import numpy as np
from typing import List, Dict, Optional, Tuple
import pandas as pd
from matplotlib.figure import Figure
import io
import base64

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("chart_generator")

class ChartGenerator:
    """图表生成类，负责生成价格和交易量变化的图表"""
    
    def __init__(self, chart_dir: str = "charts"):
        """
        初始化图表生成器
        
        Args:
            chart_dir: 图表保存目录
        """
        self.chart_dir = chart_dir
        
        # 创建图表保存目录
        os.makedirs(chart_dir, exist_ok=True)
        
        # 设置中文字体支持
        plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
        
        logger.info("图表生成模块初始化完成")
    
    def generate_price_chart(
        self, 
        symbol: str, 
        price_data: List[Dict],
        save_path: Optional[str] = None,
        show_volume: bool = True,
        hours: int = 24
    ) -> Optional[str]:
        """
        生成价格图表
        
        Args:
            symbol: 币种符号
            price_data: 价格数据列表，每个元素包含timestamp、price和volume_24h
            save_path: 图表保存路径，如果为None则自动生成
            show_volume: 是否显示交易量
            hours: 图表显示的小时数
            
        Returns:
            图表保存路径或None（如果生成失败）
        """
        try:
            if not price_data:
                logger.warning(f"无法生成{symbol}的价格图表：没有数据")
                return None
            
            # 转换数据为DataFrame
            df = pd.DataFrame(price_data)
            
            # 转换时间戳为datetime对象
            df['datetime'] = pd.to_datetime(df['timestamp'])
            
            # 按时间排序
            df = df.sort_values('datetime')
            
            # 创建图表
            fig, ax1 = plt.subplots(figsize=(10, 6))
            
            # 设置标题和标签
            plt.title(f"{symbol} 价格走势图 (过去{hours}小时)", fontsize=16)
            ax1.set_xlabel('时间', fontsize=12)
            ax1.set_ylabel('价格', color='tab:blue', fontsize=12)
            
            # 绘制价格曲线
            ax1.plot(df['datetime'], df['price'], 'b-', linewidth=2)
            ax1.tick_params(axis='y', labelcolor='tab:blue')
            
            # 设置x轴时间格式
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
            plt.xticks(rotation=45)
            
            # 如果需要显示交易量
            if show_volume and 'volume_24h' in df.columns:
                # 创建第二个y轴
                ax2 = ax1.twinx()
                ax2.set_ylabel('交易量', color='tab:red', fontsize=12)
                
                # 绘制交易量柱状图
                ax2.bar(df['datetime'], df['volume_24h'], alpha=0.3, color='tab:red')
                ax2.tick_params(axis='y', labelcolor='tab:red')
            
            # 添加网格
            ax1.grid(True, linestyle='--', alpha=0.7)
            
            # 自动调整布局
            plt.tight_layout()
            
            # 保存图表
            if save_path is None:
                os.makedirs(self.chart_dir, exist_ok=True)
                save_path = os.path.join(self.chart_dir, f"{symbol}_price_{datetime.now().strftime('%Y%m%d%H%M%S')}.png")
            
            plt.savefig(save_path)
            plt.close(fig)
            
            logger.info(f"成功生成{symbol}的价格图表，保存至{save_path}")
            return save_path
        
        except Exception as e:
            logger.error(f"生成{symbol}的价格图表失败: {str(e)}")
            return None
    
    def generate_price_change_chart(
        self, 
        symbol: str, 
        current_price: float,
        reference_price: float,
        price_data: List[Dict] = None,
        save_path: Optional[str] = None
    ) -> Optional[str]:
        """
        生成价格变化图表
        
        Args:
            symbol: 币种符号
            current_price: 当前价格
            reference_price: 参考价格
            price_data: 价格数据列表，如果提供则绘制历史价格曲线
            save_path: 图表保存路径，如果为None则自动生成
            
        Returns:
            图表保存路径或None（如果生成失败）
        """
        try:
            # 计算价格变化百分比
            change_pct = ((current_price - reference_price) / reference_price) * 100
            change_direction = "上涨" if change_pct > 0 else "下跌"
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # 设置标题和标签
            plt.title(f"{symbol} 价格{change_direction}图", fontsize=16)
            ax.set_ylabel('价格', fontsize=12)
            
            # 如果有历史数据，绘制价格曲线
            if price_data and len(price_data) > 1:
                # 转换数据为DataFrame
                df = pd.DataFrame(price_data)
                
                # 转换时间戳为datetime对象
                df['datetime'] = pd.to_datetime(df['timestamp'])
                
                # 按时间排序
                df = df.sort_values('datetime')
                
                # 绘制价格曲线
                ax.plot(df['datetime'], df['price'], 'b-', linewidth=2)
                
                # 设置x轴标签
                ax.set_xlabel('时间', fontsize=12)
                
                # 设置x轴时间格式
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
                plt.xticks(rotation=45)
            else:
                # 如果没有历史数据，绘制简单的前后对比图
                labels = ['参考价格', '当前价格']
                values = [reference_price, current_price]
                
                # 设置柱状图颜色
                colors = ['gray', 'green' if change_pct > 0 else 'red']
                
                # 绘制柱状图
                ax.bar(labels, values, color=colors)
                
                # 在柱状图上添加价格标签
                for i, v in enumerate(values):
                    ax.text(i, v * 1.01, f'{v:.4f}', ha='center')
                
                # 添加变化百分比标注
                plt.figtext(
                    0.5, 0.01, 
                    f"价格{change_direction}: {abs(change_pct):.2f}%", 
                    ha='center', 
                    fontsize=12, 
                    bbox={'facecolor': 'green' if change_pct > 0 else 'red', 'alpha': 0.2, 'pad': 5}
                )
            
            # 添加网格
            ax.grid(True, linestyle='--', alpha=0.7)
            
            # 自动调整布局
            plt.tight_layout()
            
            # 保存图表
            if save_path is None:
                os.makedirs(self.chart_dir, exist_ok=True)
                save_path = os.path.join(self.chart_dir, f"{symbol}_change_{datetime.now().strftime('%Y%m%d%H%M%S')}.png")
            
            plt.savefig(save_path)
            plt.close(fig)
            
            logger.info(f"成功生成{symbol}的价格变化图表，保存至{save_path}")
            return save_path
        
        except Exception as e:
            logger.error(f"生成{symbol}的价格变化图表失败: {str(e)}")
            return None
    
    def generate_volume_chart(
        self, 
        symbol: str, 
        current_volume: float,
        reference_volume: float,
        volume_data: List[Dict] = None,
        save_path: Optional[str] = None
    ) -> Optional[str]:
        """
        生成交易量变化图表
        
        Args:
            symbol: 币种符号
            current_volume: 当前交易量
            reference_volume: 参考交易量
            volume_data: 交易量数据列表，如果提供则绘制历史交易量曲线
            save_path: 图表保存路径，如果为None则自动生成
            
        Returns:
            图表保存路径或None（如果生成失败）
        """
        try:
            # 计算交易量变化百分比
            change_pct = ((current_volume - reference_volume) / reference_volume) * 100
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # 设置标题和标签
            plt.title(f"{symbol} 交易量变化图", fontsize=16)
            ax.set_ylabel('交易量', fontsize=12)
            
            # 如果有历史数据，绘制交易量曲线
            if volume_data and len(volume_data) > 1:
                # 转换数据为DataFrame
                df = pd.DataFrame(volume_data)
                
                # 转换时间戳为datetime对象
                df['datetime'] = pd.to_datetime(df['timestamp'])
                
                # 按时间排序
                df = df.sort_values('datetime')
                
                # 绘制交易量柱状图
                ax.bar(df['datetime'], df['volume_24h'], alpha=0.7, color='tab:red')
                
                # 设置x轴标签
                ax.set_xlabel('时间', fontsize=12)
                
                # 设置x轴时间格式
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
                plt.xticks(rotation=45)
            else:
                # 如果没有历史数据，绘制简单的前后对比图
                labels = ['参考交易量', '当前交易量']
                values = [reference_volume, current_volume]
                
                # 绘制柱状图
                ax.bar(labels, values, color=['gray', 'red'])
                
                # 在柱状图上添加交易量标签
                for i, v in enumerate(values):
                    ax.text(i, v * 1.01, f'{v:.2f}', ha='center')
                
                # 添加变化百分比标注
                plt.figtext(
                    0.5, 0.01, 
                    f"交易量增加: {change_pct:.2f}%", 
                    ha='center', 
                    fontsize=12, 
                    bbox={'facecolor': 'red', 'alpha': 0.2, 'pad': 5}
                )
            
            # 添加网格
            ax.grid(True, linestyle='--', alpha=0.7)
            
            # 自动调整布局
            plt.tight_layout()
            
            # 保存图表
            if save_path is None:
                os.makedirs(self.chart_dir, exist_ok=True)
                save_path = os.path.join(self.chart_dir, f"{symbol}_volume_{datetime.now().strftime('%Y%m%d%H%M%S')}.png")
            
            plt.savefig(save_path)
            plt.close(fig)
            
            logger.info(f"成功生成{symbol}的交易量变化图表，保存至{save_path}")
            return save_path
        
        except Exception as e:
            logger.error(f"生成{symbol}的交易量变化图表失败: {str(e)}")
            return None
    
    def generate_chart_as_base64(self, fig: Figure) -> Optional[str]:
        """
        将图表转换为Base64编码的字符串，用于在Telegram消息中嵌入图片
        
        Args:
            fig: Matplotlib图表对象
            
        Returns:
            Base64编码的图表字符串或None（如果转换失败）
        """
        try:
            # 将图表保存到内存中
            buf = io.BytesIO()
            fig.savefig(buf, format='png')
            buf.seek(0)
            
            # 转换为Base64编码
            img_str = base64.b64encode(buf.read()).decode('utf-8')
            
            return img_str
        except Exception as e:
            logger.error(f"将图表转换为Base64编码失败: {str(e)}")
            return None


if __name__ == "__main__":
    # 测试代码
    
    # 创建图表生成器
    chart_gen = ChartGenerator()
    
    # 生成测试数据
    now = datetime.now()
    test_data = []
    for i in range(24):
        timestamp = (now - timedelta(hours=24-i)).isoformat()
        price = 50000 + 5000 * np.sin(i / 4)
        volume = 1000000 + 500000 * np.random.random()
        test_data.append({
            "timestamp": timestamp,
            "price": price,
            "volume_24h": volume
        })
    
    # 测试价格图表生成
    print("测试价格图表生成...")
    price_chart = chart_gen.generate_price_chart("BTC_USDT", test_data)
    if price_chart:
        print(f"价格图表已保存至: {price_chart}")
    
    # 测试价格变化图表生成
    print("\n测试价格变化图表生成...")
    price_change_chart = chart_gen.generate_price_change_chart(
        "BTC_USDT", 
        current_price=55000, 
        reference_price=50000,
        price_data=test_data
    )
    if price_change_chart:
        print(f"价格变化图表已保存至: {price_change_chart}")
    
    # 测试交易量图表生成
    print("\n测试交易量图表生成...")
    volume_chart = chart_gen.generate_volume_chart(
        "BTC_USDT", 
        current_volume=1500000, 
        reference_volume=1000000,
        volume_data=test_data
    )
    if volume_chart:
        print(f"交易量图表已保存至: {volume_chart}")
    
    print("\n测试完成!")
