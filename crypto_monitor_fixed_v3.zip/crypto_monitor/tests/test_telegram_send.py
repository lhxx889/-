"""
Gate.io加密货币异动监控系统 - Telegram发送逻辑测试
"""

import logging
import time
import sys
import os
import random
from datetime import datetime

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入增强版Telegram推送模块
from src.enhanced_telegram_alerter import EnhancedTelegramAlerter

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("telegram_send_test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("telegram_send_test")

def test_direct_send():
    """测试直接发送消息"""
    logger.info("=== 测试直接发送消息 ===")
    
    # 创建警报器
    alerter = EnhancedTelegramAlerter()
    
    # 检查是否已配置
    if not alerter.is_configured():
        logger.error("Telegram未配置，无法进行测试")
        return False
    
    # 测试连接
    logger.info("测试Telegram连接...")
    if not alerter.test_connection():
        logger.error("Telegram连接测试失败，请检查配置")
        return False
    
    # 发送测试消息
    test_message = f"这是一条直接发送的测试消息 - 时间: {datetime.now().strftime('%H:%M:%S')}"
    logger.info(f"发送测试消息: {test_message}")
    
    # 直接调用内部发送方法，绕过批处理
    result = alerter._send_message_with_rate_limit(test_message)
    
    if result:
        logger.info("测试消息发送成功!")
    else:
        logger.error("测试消息发送失败!")
    
    return result

def test_batch_send():
    """测试批量发送消息"""
    logger.info("=== 测试批量发送消息 ===")
    
    # 创建警报器
    alerter = EnhancedTelegramAlerter()
    
    # 检查是否已配置
    if not alerter.is_configured():
        logger.error("Telegram未配置，无法进行测试")
        return False
    
    # 发送多条消息
    for i in range(3):
        message = f"批量测试消息 {i+1} - 时间: {datetime.now().strftime('%H:%M:%S')}"
        logger.info(f"添加消息到队列: {message}")
        
        result = alerter.send_message(message)
        if result:
            logger.info(f"消息 {i+1} 已加入队列")
        else:
            logger.warning(f"消息 {i+1} 加入队列失败")
        
        # 短暂等待
        time.sleep(1)
    
    # 等待消息处理
    logger.info("等待消息处理...")
    time.sleep(15)
    
    logger.info("批量发送测试完成")
    return True

def main():
    """主函数"""
    logger.info("开始Telegram发送逻辑测试")
    
    # 测试直接发送
    direct_result = test_direct_send()
    
    # 如果直接发送成功，测试批量发送
    if direct_result:
        batch_result = test_batch_send()
    else:
        logger.error("直接发送测试失败，跳过批量发送测试")
        batch_result = False
    
    # 输出总结
    logger.info("测试结果总结:")
    logger.info(f"- 直接发送测试: {'成功' if direct_result else '失败'}")
    logger.info(f"- 批量发送测试: {'成功' if batch_result else '失败'}")
    
    logger.info("所有测试完成")

if __name__ == "__main__":
    main()
