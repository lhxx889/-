"""
加密货币监控系统API路由 - 异常检测和系统配置
"""

from flask import Blueprint, jsonify, request
from src.models.crypto import db, Anomaly, Coin, SystemConfig
from datetime import datetime, timedelta
import json

anomaly_bp = Blueprint('anomaly', __name__)
config_bp = Blueprint('config', __name__)

# ===== 异常检测相关路由 =====

@anomaly_bp.route('/', methods=['GET'])
def get_all_anomalies():
    """获取所有异常记录"""
    # 支持按交易所、币种和时间范围过滤
    exchange_id = request.args.get('exchange_id')
    symbol = request.args.get('symbol')
    hours = request.args.get('hours', type=int)
    days = request.args.get('days', type=int)
    limit = request.args.get('limit', 100, type=int)
    
    # 构建查询
    query = db.session.query(Anomaly).join(Coin, Anomaly.coin_id == Coin.id)
    
    # 应用过滤条件
    if exchange_id:
        query = query.filter(Coin.exchange_id == exchange_id)
    if symbol:
        query = query.filter(Coin.symbol == symbol)
    
    # 应用时间过滤
    if hours:
        start_time = datetime.now() - timedelta(hours=hours)
        query = query.filter(Anomaly.detected_at >= start_time)
    elif days:
        start_time = datetime.now() - timedelta(days=days)
        query = query.filter(Anomaly.detected_at >= start_time)
    
    # 按时间倒序排序并限制结果数量
    query = query.order_by(Anomaly.detected_at.desc()).limit(limit)
    
    # 执行查询
    anomalies = query.all()
    
    return jsonify({
        "success": True,
        "data": [anomaly.to_dict() for anomaly in anomalies]
    }), 200

@anomaly_bp.route('/<int:anomaly_id>', methods=['GET'])
def get_anomaly(anomaly_id):
    """获取特定异常记录"""
    anomaly = Anomaly.query.get(anomaly_id)
    if not anomaly:
        return jsonify({
            "success": False,
            "message": f"异常ID {anomaly_id} 不存在"
        }), 404
    
    return jsonify({
        "success": True,
        "data": anomaly.to_dict()
    }), 200

@anomaly_bp.route('/', methods=['POST'])
def create_anomaly():
    """创建新异常记录"""
    data = request.json
    
    # 验证必要字段
    if not data or not data.get('coin_id') or not data.get('type') or 'current_price' not in data:
        return jsonify({
            "success": False,
            "message": "缺少必要字段: coin_id, type, current_price"
        }), 400
    
    # 检查币种是否存在
    coin = Coin.query.get(data['coin_id'])
    if not coin:
        return jsonify({
            "success": False,
            "message": f"币种ID {data['coin_id']} 不存在"
        }), 404
    
    # 创建异常记录
    new_anomaly = Anomaly(
        coin_id=data['coin_id'],
        type=data['type'],
        current_price=data['current_price'],
        reference_price=data.get('reference_price'),
        price_change_pct=data.get('price_change_pct'),
        volume_24h=data.get('volume_24h'),
        volume_change_pct=data.get('volume_change_pct'),
        confidence_score=data.get('confidence_score', 1.0),
        algorithm=data.get('algorithm'),
        detected_at=datetime.now(),
        is_notified=data.get('is_notified', False)
    )
    
    try:
        db.session.add(new_anomaly)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "异常记录创建成功",
            "data": new_anomaly.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"创建异常记录失败: {str(e)}"
        }), 500

@anomaly_bp.route('/<int:anomaly_id>', methods=['PUT'])
def update_anomaly(anomaly_id):
    """更新异常记录"""
    anomaly = Anomaly.query.get(anomaly_id)
    if not anomaly:
        return jsonify({
            "success": False,
            "message": f"异常ID {anomaly_id} 不存在"
        }), 404
    
    data = request.json
    if not data:
        return jsonify({
            "success": False,
            "message": "未提供更新数据"
        }), 400
    
    # 更新字段
    if 'is_notified' in data:
        anomaly.is_notified = data['is_notified']
    if 'confidence_score' in data:
        anomaly.confidence_score = data['confidence_score']
    if 'algorithm' in data:
        anomaly.algorithm = data['algorithm']
    
    try:
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "异常记录更新成功",
            "data": anomaly.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"更新异常记录失败: {str(e)}"
        }), 500

@anomaly_bp.route('/stats', methods=['GET'])
def get_anomaly_stats():
    """获取异常统计信息"""
    # 支持按时间范围过滤
    days = request.args.get('days', 7, type=int)
    
    start_time = datetime.now() - timedelta(days=days)
    
    # 按交易所统计异常数量
    exchange_stats = db.session.query(
        Coin.exchange_id,
        db.func.count(Anomaly.id).label('count')
    ).join(
        Anomaly, Anomaly.coin_id == Coin.id
    ).filter(
        Anomaly.detected_at >= start_time
    ).group_by(
        Coin.exchange_id
    ).all()
    
    # 按异常类型统计数量
    type_stats = db.session.query(
        Anomaly.type,
        db.func.count(Anomaly.id).label('count')
    ).filter(
        Anomaly.detected_at >= start_time
    ).group_by(
        Anomaly.type
    ).all()
    
    # 按日期统计异常数量
    date_stats = db.session.query(
        db.func.date(Anomaly.detected_at).label('date'),
        db.func.count(Anomaly.id).label('count')
    ).filter(
        Anomaly.detected_at >= start_time
    ).group_by(
        db.func.date(Anomaly.detected_at)
    ).all()
    
    # 格式化结果
    exchange_data = {item[0]: item[1] for item in exchange_stats}
    type_data = {item[0]: item[1] for item in type_stats}
    date_data = {str(item[0]): item[1] for item in date_stats}
    
    return jsonify({
        "success": True,
        "data": {
            "by_exchange": exchange_data,
            "by_type": type_data,
            "by_date": date_data,
            "total": sum(exchange_data.values())
        }
    }), 200

@anomaly_bp.route('/batch', methods=['POST'])
def create_batch_anomalies():
    """批量创建异常记录"""
    data = request.json
    
    if not data or not isinstance(data, list) or len(data) == 0:
        return jsonify({
            "success": False,
            "message": "请提供有效的异常记录列表"
        }), 400
    
    success_count = 0
    failed_items = []
    
    for item in data:
        # 验证必要字段
        if not item.get('coin_id') or not item.get('type') or 'current_price' not in item:
            failed_items.append({
                "item": item,
                "reason": "缺少必要字段: coin_id, type, current_price"
            })
            continue
        
        # 检查币种是否存在
        coin = Coin.query.get(item['coin_id'])
        if not coin:
            failed_items.append({
                "item": item,
                "reason": f"币种ID {item['coin_id']} 不存在"
            })
            continue
        
        # 创建异常记录
        new_anomaly = Anomaly(
            coin_id=item['coin_id'],
            type=item['type'],
            current_price=item['current_price'],
            reference_price=item.get('reference_price'),
            price_change_pct=item.get('price_change_pct'),
            volume_24h=item.get('volume_24h'),
            volume_change_pct=item.get('volume_change_pct'),
            confidence_score=item.get('confidence_score', 1.0),
            algorithm=item.get('algorithm'),
            detected_at=datetime.now(),
            is_notified=item.get('is_notified', False)
        )
        
        try:
            db.session.add(new_anomaly)
            success_count += 1
        except Exception as e:
            failed_items.append({
                "item": item,
                "reason": str(e)
            })
    
    # 提交事务
    try:
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"成功创建 {success_count} 条异常记录，失败 {len(failed_items)} 条",
            "failed_items": failed_items
        }), 201 if success_count > 0 else 400
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"批量创建异常记录失败: {str(e)}"
        }), 500

# ===== 系统配置相关路由 =====

@config_bp.route('/', methods=['GET'])
def get_all_configs():
    """获取所有系统配置"""
    configs = SystemConfig.query.all()
    return jsonify({
        "success": True,
        "data": [config.to_dict() for config in configs]
    }), 200

@config_bp.route('/<key>', methods=['GET'])
def get_config(key):
    """获取特定配置项"""
    config = SystemConfig.query.filter_by(key=key).first()
    if not config:
        return jsonify({
            "success": False,
            "message": f"配置项 {key} 不存在"
        }), 404
    
    return jsonify({
        "success": True,
        "data": config.to_dict()
    }), 200

@config_bp.route('/', methods=['POST'])
def create_config():
    """创建新配置项"""
    data = request.json
    
    # 验证必要字段
    if not data or not data.get('key') or 'value' not in data:
        return jsonify({
            "success": False,
            "message": "缺少必要字段: key, value"
        }), 400
    
    # 检查配置项是否已存在
    existing_config = SystemConfig.query.filter_by(key=data['key']).first()
    if existing_config:
        return jsonify({
            "success": False,
            "message": f"配置项 {data['key']} 已存在"
        }), 409
    
    # 创建新配置项
    new_config = SystemConfig(
        key=data['key'],
        value=data['value'],
        description=data.get('description', '')
    )
    
    try:
        db.session.add(new_config)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "配置项创建成功",
            "data": new_config.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"创建配置项失败: {str(e)}"
        }), 500

@config_bp.route('/<key>', methods=['PUT'])
def update_config(key):
    """更新配置项"""
    config = SystemConfig.query.filter_by(key=key).first()
    if not config:
        return jsonify({
            "success": False,
            "message": f"配置项 {key} 不存在"
        }), 404
    
    data = request.json
    if not data:
        return jsonify({
            "success": False,
            "message": "未提供更新数据"
        }), 400
    
    # 更新字段
    if 'value' in data:
        config.value = data['value']
    if 'description' in data:
        config.description = data['description']
    
    try:
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "配置项更新成功",
            "data": config.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"更新配置项失败: {str(e)}"
        }), 500

@config_bp.route('/<key>', methods=['DELETE'])
def delete_config(key):
    """删除配置项"""
    config = SystemConfig.query.filter_by(key=key).first()
    if not config:
        return jsonify({
            "success": False,
            "message": f"配置项 {key} 不存在"
        }), 404
    
    try:
        db.session.delete(config)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": f"配置项 {key} 已删除"
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"删除配置项失败: {str(e)}"
        }), 500

@config_bp.route('/batch', methods=['POST'])
def update_batch_configs():
    """批量更新配置项"""
    data = request.json
    
    if not data or not isinstance(data, dict) or len(data) == 0:
        return jsonify({
            "success": False,
            "message": "请提供有效的配置项字典"
        }), 400
    
    success_count = 0
    failed_items = []
    
    for key, value in data.items():
        # 查找配置项
        config = SystemConfig.query.filter_by(key=key).first()
        
        if not config:
            # 如果配置项不存在，创建新配置项
            new_config = SystemConfig(
                key=key,
                value=value if isinstance(value, str) else json.dumps(value),
                description=f"自动创建于 {datetime.now().isoformat()}"
            )
            
            try:
                db.session.add(new_config)
                success_count += 1
            except Exception as e:
                failed_items.append({
                    "key": key,
                    "value": value,
                    "reason": str(e)
                })
        else:
            # 如果配置项存在，更新值
            try:
                config.value = value if isinstance(value, str) else json.dumps(value)
                success_count += 1
            except Exception as e:
                failed_items.append({
                    "key": key,
                    "value": value,
                    "reason": str(e)
                })
    
    # 提交事务
    try:
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"成功更新 {success_count} 个配置项，失败 {len(failed_items)} 个",
            "failed_items": failed_items
        }), 200 if success_count > 0 else 400
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"批量更新配置项失败: {str(e)}"
        }), 500
