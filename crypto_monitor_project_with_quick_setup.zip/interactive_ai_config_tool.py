import json
import os

def interactive_config_tool():
    config_path = os.path.join(os.path.dirname(__file__), 'ai_config.json')
    config = {}

    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config = json.load(f)
    
    print("\n--- Gemini AI Analysis Module Configuration ---")
    print("Please provide the following information. Press Enter to keep current value if available.")

    # Gemini API Key
    current_gemini_key = config.get('gemini_api_key', '')
    gemini_api_key = input(f"Enter your Gemini API Key (current: {current_gemini_key}): ")
    if gemini_api_key:
        config['gemini_api_key'] = gemini_api_key
    elif not current_gemini_key:
        print("Gemini API Key is required.")
        return

    # Telegram Bot Token
    telegram_config = config.get('telegram', {})
    current_bot_token = telegram_config.get('bot_token', '')
    bot_token = input(f"Enter your Telegram Bot Token (current: {current_bot_token}): ")
    if bot_token:
        telegram_config['bot_token'] = bot_token
    config['telegram'] = telegram_config

    # Telegram Chat ID
    current_chat_id = telegram_config.get('chat_id', '')
    chat_id = input(f"Enter your Telegram Chat ID (current: {current_chat_id}): ")
    if chat_id:
        telegram_config['chat_id'] = chat_id
    config['telegram'] = telegram_config

    # Analysis Settings (optional, keep defaults for now)
    if 'analysis_settings' not in config:
        config['analysis_settings'] = {
            "monitored_coins": [
                {
                    "symbol": "BTC",
                    "lookback_days": 7
                },
                {
                    "symbol": "ETH",
                    "lookback_days": 7
                }
            ],
            "analysis_interval_seconds": 3600
        }

    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    
    print(f"\nConfiguration saved to {config_path}")
    print("You can now run the AI analysis module.")

if __name__ == '__main__':
    interactive_config_tool()


