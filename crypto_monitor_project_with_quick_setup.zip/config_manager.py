import json
import os

def load_config(config_file=\'config.json\'):
    if not os.path.exists(config_file):
        return {}
    try:
        with open(config_file, \'r\', encoding=\'utf-8\') as f:
            config = json.load(f)
        return config
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON in \'{config_file}\'")
        return {}

def save_config(config, config_file=\'config.json\'):
    try:
        with open(config_file, \'w\', encoding=\'utf-8\') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        print(f"Configuration saved to \'{config_file}\'")
        return True
    except IOError as e:
        print(f"Error saving configuration to \'{config_file}\': {e}")
        return False

# Example default configuration (no longer used directly for initial setup in this module)
default_config = {
    "telegram": {
        "bot_token": "YOUR_TELEGRAM_BOT_TOKEN",
        "chat_id": "YOUR_TELEGRAM_CHAT_ID"
    },
    "monitor": {
        "refresh_interval": 60,
        "monitored_coins": [
            {
                "symbol": "BTC",
                "threshold_price": 70000,
                "threshold_percent": None
            },
            {
                "symbol": "ETH",
                "threshold_price": None,
                "threshold_percent": 5
            }
        ]
    },
    "coinmarketcap": {
        "api_keys": ["YOUR_PRIMARY_CMC_API_KEY", "YOUR_SECONDARY_CMC_API_KEY"]
    },
    "announcement_monitor": {
        "binance_announcement_url": "https://www.binance.com/en/support/announcement/list/48",
        "keywords": ["listing", "new", "airdrop"]
    }
}


