# 加密货币监控脚本用户手册

## 1. 简介

本脚本是一个功能丰富的加密货币监控工具，旨在帮助用户实时追踪加密货币价格、接收自定义告警、监控交易所公告和新币上市信息，并通过Telegram进行推送。脚本支持多数据源，并提供数据可视化功能。

## 2. 功能特性

- **多币种监控**: 支持监控多种加密货币的价格。
- **自定义告警**: 可根据固定价格或涨跌幅百分比设置告警阈值。
- **灵活刷新频率**: 用户可自定义数据刷新频率。
- **Telegram推送**: 告警信息、交易所公告和新币信息将通过Telegram机器人推送。
- **数据可视化**: 提供价格趋势图表，帮助用户直观了解市场动态。
- **交易所公告监控**: 自动抓取并分析主流交易所的公告，特别是新币上市信息。
- **API主备切换**: 支持配置多个CoinMarketCap API Key，实现主备切换，提高数据获取的稳定性。
- **历史数据存储**: 自动将监控到的价格数据存储到本地SQLite数据库，方便查询和可视化。
- **情绪分析**: 集成预训练模型，对文本信息进行情绪分析，提供市场情绪洞察。
- **日志记录**: 详细记录脚本运行状态、错误信息和告警触发情况，方便排查问题。
- **Linux环境部署**: 提供便捷的Linux部署脚本。
- **Docker部署**: 支持Docker容器化部署，简化环境配置和管理。

## 3. 系统要求

- 操作系统: Linux (推荐 Ubuntu 20.04 LTS 或更高版本)
- Python: 3.8 或更高版本
- Docker (如果选择Docker部署)
- 互联网连接
- Telegram 账号及创建好的Telegram Bot Token和Chat ID

## 4. 快速开始

### 4.1. 获取脚本

请从项目仓库下载最新版本的脚本文件。

### 4.2. 配置Telegram Bot

1. 在Telegram中搜索 `@BotFather` 并与其对话。
2. 发送 `/newbot` 命令，按照提示创建新的机器人，并获取 `Bot Token`。
3. 搜索 `@userinfobot` 或其他类似机器人，发送 `/start` 命令，获取您的 `Chat ID`。

### 4.3. 安装与部署

#### 4.3.1. Linux环境部署

1. 将所有脚本文件（`api_module.py`, `monitor_module.py`, `telegram_notifier.py`, `visualizer_module.py`, `config_manager.py`, `main.py`, `deploy.sh`, `config.json`, `database_module.py`, `sentiment_analyzer.py`, `logger_config.py`, `requirements.txt`, `interactive_config_tool.py`）上传到您的Linux服务器。
2. 打开终端，进入脚本文件所在的目录。
3. 运行安装脚本：
   ```bash
   sudo chmod +x deploy.sh
   sudo ./deploy.sh install
   ```
   此命令将安装必要的系统依赖、设置Python虚拟环境、安装Python库，并将脚本文件复制到 `/opt/crypto_monitor` 目录。

#### 4.3.2. Docker环境部署

1. 确保您的系统已安装Docker。
2. 将所有脚本文件（`api_module.py`, `monitor_module.py`, `telegram_notifier.py`, `visualizer_module.py`, `config_manager.py`, `main.py`, `Dockerfile`, `config.json`, `database_module.py`, `sentiment_analyzer.py`, `logger_config.py`, `requirements.txt`, `interactive_config_tool.py`）上传到您的Linux服务器。
3. 打开终端，进入脚本文件所在的目录。
4. 构建Docker镜像：
   ```bash
   docker build -t crypto-monitor .
   ```
5. 运行Docker容器：
   ```bash
   docker run -d --name my-crypto-monitor -v /path/to/your/config.json:/app/config.json crypto-monitor
   ```
   请将 `/path/to/your/config.json` 替换为您本地 `config.json` 文件的实际路径。

### 4.4. 快捷设置（推荐）

脚本提供了一个交互式命令行工具，帮助您快速配置 `config.json` 文件。在完成安装后，您可以在 `/opt/crypto_monitor` 目录下运行此工具：

```bash
cd /opt/crypto_monitor/
source venv/bin/activate
python interactive_config_tool.py
deactivate
```

按照提示输入您的配置信息，工具将自动生成或更新 `config.json` 文件。

### 4.5. 手动配置脚本（可选）

如果您更喜欢手动编辑配置文件，可以按照以下步骤操作：

1. 编辑位于 `/opt/crypto_monitor/config.json` (Linux部署) 或您映射到Docker容器内的 `config.json` 文件：
   ```json
   {
       "telegram": {
           "bot_token": "YOUR_TELEGRAM_BOT_TOKEN",
           "chat_id": "YOUR_TELEGRAM_CHAT_ID"
       },
       "monitor": {
           "refresh_interval": 60,
           "monitored_coins": [
               {
                   "symbol": "BTC",
                   "threshold_price": 70000,
                   "threshold_percent": null
               },
               {
                   "symbol": "ETH",
                   "threshold_price": null,
                   "threshold_percent": 5
               }
           ]
       },
       "coinmarketcap": {
           "api_keys": ["YOUR_PRIMARY_CMC_API_KEY", "YOUR_SECONDARY_CMC_API_KEY"] 
       },
       "announcement_monitor": {
           "binance_announcement_url": "https://www.binance.com/en/support/announcement/list/48",
           "keywords": ["listing", "new", "airdrop"]
       }
   }
   ```
   - 将 `YOUR_TELEGRAM_BOT_TOKEN` 和 `YOUR_TELEGRAM_CHAT_ID` 替换为您在 `4.2` 步骤中获取的值。
   - `refresh_interval`: 设置数据刷新频率，单位为秒。
   - `monitored_coins`: 配置您希望监控的币种。您可以设置 `threshold_price` (固定价格告警) 或 `threshold_percent` (涨跌幅百分比告警)。
   - `coinmarketcap.api_keys`: 配置一个或多个CoinMarketCap API Key，脚本将自动进行主备切换。如果您不需要CoinMarketCap数据源，可以留空。
   - `announcement_monitor`: 配置币安公告监控的URL和关键词。

### 4.6. 运行脚本

#### 4.6.1. Linux环境运行

1. 启动监控脚本：
   ```bash
   sudo /opt/crypto_monitor/deploy.sh start
   ```
   脚本将在后台运行，并将日志输出到 `/opt/crypto_monitor/monitor.log`。

2. 停止监控脚本：
   ```bash
   sudo /opt/crypto_monitor/deploy.sh stop
   ```

3. 重启监控脚本：
   ```bash
   sudo /opt/crypto_monitor/deploy.sh restart
   ```

#### 4.6.2. Docker环境运行

1. 启动Docker容器（如果尚未运行）：
   ```bash
   docker start my-crypto-monitor
   ```
2. 停止Docker容器：
   ```bash
   docker stop my-crypto-monitor
   ```
3. 查看日志：
   ```bash
   docker logs my-crypto-monitor
   ```

## 5. 数据可视化

脚本会自动生成价格趋势图（例如 `btc_price_trend.png`），您可以在脚本运行目录下找到这些图片。未来版本可能会提供更丰富的可视化界面。

## 6. 常见问题与故障排除

- **Telegram消息未收到**: 
  - 检查 `config.json` 中的 `bot_token` 和 `chat_id` 是否正确。
  - 确保您的机器人没有被禁用或删除。
  - 检查服务器的网络连接。
- **价格数据获取失败**: 
  - 检查网络连接。
  - 检查API Key是否正确或过期。
  - 检查交易所API是否正常运行。
- **脚本未运行**: 
  - 检查 `monitor.log` 文件（Linux部署）或Docker容器日志（Docker部署），查看是否有错误信息。
  - 确保已正确执行安装步骤。

## 7. 联系与支持

如果您在使用过程中遇到任何问题，请联系我们获取支持。




