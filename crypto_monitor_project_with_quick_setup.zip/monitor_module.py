import time
from api_module import CryptoAPI
from telegram_notifier import TelegramNotifier

class CryptoMonitor:
    def __init__(self, api_key=None, telegram_bot_token=None, telegram_chat_id=None):
        self.crypto_api = CryptoAPI(api_key)
        self.monitored_coins = {}
        self.refresh_interval = 60  # Default to 60 seconds
        self.telegram_notifier = None
        if telegram_bot_token and telegram_chat_id:
            self.telegram_notifier = TelegramNotifier(telegram_bot_token, telegram_chat_id)

    def add_coin_to_monitor(self, symbol, threshold_price=None, threshold_percent=None):
        self.monitored_coins[symbol.upper()] = {
            'threshold_price': threshold_price,
            'threshold_percent': threshold_percent,
            'last_price': None
        }
        print(f"Added {symbol.upper()} to monitoring list.")

    def set_refresh_interval(self, interval_seconds):
        if interval_seconds > 0:
            self.refresh_interval = interval_seconds
            print(f"Refresh interval set to {interval_seconds} seconds.")
        else:
            print("Refresh interval must be a positive number.")

    def check_price_and_alert(self, symbol, current_price):
        coin_data = self.monitored_coins.get(symbol)
        if not coin_data:
            return

        last_price = coin_data['last_price']
        alert_message = []

        if last_price is not None:
            # Check price threshold
            if coin_data['threshold_price'] is not None:
                if current_price >= coin_data['threshold_price']:
                    alert_message.append(f"{symbol} price ({current_price:.2f}) reached or exceeded threshold ({coin_data['threshold_price']:.2f}).")
                elif current_price <= coin_data['threshold_price'] and current_price < last_price:
                    # Optional: alert for price dropping below threshold if desired
                    pass

            # Check percentage threshold
            if coin_data['threshold_percent'] is not None:
                price_change = ((current_price - last_price) / last_price) * 100
                if abs(price_change) >= coin_data['threshold_percent']:
                    alert_message.append(f"{symbol} price changed by {price_change:.2f}% (current: {current_price:.2f}, last: {last_price:.2f}), exceeding {coin_data['threshold_percent']:.2f}% threshold.")
        
        coin_data['last_price'] = current_price
        return alert_message

    def start_monitoring(self):
        print(f"Starting cryptocurrency monitoring with {self.refresh_interval} seconds refresh interval...")
        while True:
            for symbol in list(self.monitored_coins.keys()):
                print(f"Fetching price for {symbol}...")
                price = self.crypto_api.get_binance_price(symbol) # Using Binance for now
                if price:
                    print(f"{symbol} Current Price: {price:.2f}")
                    alerts = self.check_price_and_alert(symbol, price)
                    for alert in alerts:
                        print(f"ALERT: {alert}")
                        if self.telegram_notifier:
                            self.telegram_notifier.send_message(alert)
                else:
                    print(f"Could not fetch price for {symbol}.")
            time.sleep(self.refresh_interval)

# Example Usage (for testing purposes)
if __name__ == '__main__':
    # Replace with your actual Telegram Bot Token and Chat ID
    # telegram_bot_token = "YOUR_TELEGRAM_BOT_TOKEN"
    # telegram_chat_id = "YOUR_TELEGRAM_CHAT_ID"
    
    # monitor = CryptoMonitor(telegram_bot_token=telegram_bot_token, telegram_chat_id=telegram_chat_id)
    monitor = CryptoMonitor() # For testing without Telegram

    monitor.add_coin_to_monitor('BTC', threshold_price=70000)
    monitor.add_coin_to_monitor('ETH', threshold_percent=5)
    monitor.set_refresh_interval(10) # Refresh every 10 seconds for testing
    monitor.start_monitoring()


