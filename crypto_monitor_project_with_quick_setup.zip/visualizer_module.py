import matplotlib.pyplot as plt
import pandas as pd

class CryptoVisualizer:
    def __init__(self):
        plt.style.use("seaborn-v0_8-darkgrid")
        plt.rcParams["font.sans-serif"] = ["SimHei"]  # For Chinese characters
        plt.rcParams["axes.unicode_minus"] = False  # To display minus sign correctly

    def plot_price_trend(self, symbol, prices, timestamps, filename="price_trend.png"):
        if not prices or not timestamps:
            print("No data to plot.")
            return

        df = pd.DataFrame({"Price": prices, "Timestamp": pd.to_datetime(timestamps)})
        df = df.set_index("Timestamp")

        plt.figure(figsize=(10, 6))
        plt.plot(df.index, df["Price"], marker=".", linestyle="-", color="skyblue")
        plt.title(f"{symbol} 价格趋势", fontsize=16)
        plt.xlabel("时间", fontsize=12)
        plt.ylabel("价格 (USDT)", fontsize=12)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(filename)
        print(f"Price trend plot saved to {filename}")

# Example Usage (for testing purposes)
if __name__ == '__main__':
    visualizer = CryptoVisualizer()
    
    # Sample data
    sample_prices = [60000, 60500, 60200, 61000, 60800, 61500, 61200]
    sample_timestamps = [
        "2025-06-16 10:00:00",
        "2025-06-16 10:05:00",
        "2025-06-16 10:10:00",
        "2025-06-16 10:15:00",
        "2025-06-16 10:20:00",
        "2025-06-16 10:25:00",
        "2025-06-16 10:30:00"
    ]
    
    visualizer.plot_price_trend("BTC", sample_prices, sample_timestamps, "btc_price_trend.png")


