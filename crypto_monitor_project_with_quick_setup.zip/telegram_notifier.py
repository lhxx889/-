import requests

class TelegramNotifier:
    def __init__(self, bot_token, chat_id):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{bot_token}"

    def send_message(self, message):
        url = f"{self.base_url}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "Markdown"
        }
        try:
            response = requests.post(url, json=payload)
            response.raise_for_status()
            print("Telegram message sent successfully.")
            return True
        except requests.exceptions.RequestException as e:
            print(f"Error sending Telegram message: {e}")
            return False

# Example Usage (for testing purposes, will be removed in final script)
if __name__ == '__main__':
    # Replace with your actual bot token and chat ID
    # bot_token = "YOUR_TELEGRAM_BOT_TOKEN"
    # chat_id = "YOUR_TELEGRAM_CHAT_ID"
    # notifier = TelegramNotifier(bot_token, chat_id)
    # notifier.send_message("Hello from Crypto Monitor!")
    print("Telegram Notifier module created. Please configure bot_token and chat_id for actual use.")


