from transformers import pipeline

class SentimentAnalyzer:
    def __init__(self):
        # Use a pre-trained sentiment analysis model from Hugging Face
        # You might need to specify a model that supports Chinese if needed
        # For English, 'distilbert-base-uncased-finetuned-sst-2-english' is a good general choice
        # For Chinese, you might need to search for specific models like 'uer/roberta-base-finetuned-jd-binary-chinese'
        try:
            self.sentiment_pipeline = pipeline("sentiment-analysis")
        except Exception as e:
            print(f"Error loading sentiment analysis model: {e}")
            print("Attempting to load a specific Chinese model (if available).")
            try:
                # Example for a Chinese model, replace with an actual available model if needed
                self.sentiment_pipeline = pipeline("sentiment-analysis", model="uer/roberta-base-finetuned-jd-binary-chinese")
            except Exception as e_chinese:
                print(f"Error loading Chinese sentiment analysis model: {e_chinese}")
                self.sentiment_pipeline = None

    def analyze_sentiment(self, text):
        if self.sentiment_pipeline:
            try:
                result = self.sentiment_pipeline(text)
                return result[0] # Returns a dictionary like {'label': 'POSITIVE', 'score': 0.9998}
            except Exception as e:
                print(f"Error analyzing sentiment for text: {text}. Error: {e}")
                return None
        else:
            print("Sentiment analysis pipeline not loaded.")
            return None

# Example Usage
if __name__ == '__main__':
    analyzer = SentimentAnalyzer()
    
    text1 = "This is a great project!"
    sentiment1 = analyzer.analyze_sentiment(text1)
    if sentiment1:
        print(f"Text: \"{text1}\" -> Sentiment: {sentiment1['label']}, Score: {sentiment1['score']:.4f}")

    text2 = "I am very disappointed with the market."
    sentiment2 = analyzer.analyze_sentiment(text2)
    if sentiment2:
        print(f"Text: \"{text2}\" -> Sentiment: {sentiment2['label']}, Score: {sentiment2['score']:.4f}")

    text3 = "今天天气真好，心情愉悦。"
    sentiment3 = analyzer.analyze_sentiment(text3)
    if sentiment3:
        print(f"Text: \"{text3}\" -> Sentiment: {sentiment3['label']}, Score: {sentiment3['score']:.4f}")
    else:
        print(f"Could not analyze sentiment for: \"{text3}\"")


