import sqlite3
import time

class CryptoDB:
    def __init__(self, db_name=\'crypto_data.db\'):
        self.db_name = db_name
        self.conn = None
        self.cursor = None
        self._connect()
        self._create_table()

    def _connect(self):
        try:
            self.conn = sqlite3.connect(self.db_name)
            self.cursor = self.conn.cursor()
            print(f"Connected to database: {self.db_name}")
        except sqlite3.Error as e:
            print(f"Error connecting to database: {e}")

    def _create_table(self):
        try:
            self.cursor.execute("\"\"\"CREATE TABLE IF NOT EXISTS prices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                timestamp INTEGER NOT NULL
            )\"\"\")
            self.conn.commit()
            print("Table \'prices\' ensured to exist.")
        except sqlite3.Error as e:
            print(f"Error creating table: {e}")

    def save_price(self, symbol, price, timestamp=None):
        if timestamp is None:
            timestamp = int(time.time())
        try:
            self.cursor.execute("INSERT INTO prices (symbol, price, timestamp) VALUES (?, ?, ?)",
                                (symbol.upper(), price, timestamp))
            self.conn.commit()
            # print(f"Saved {symbol}: {price} at {timestamp}")
        except sqlite3.Error as e:
            print(f"Error saving price: {e}")

    def get_prices(self, symbol, start_time=0, end_time=int(time.time())):
        try:
            self.cursor.execute("SELECT price, timestamp FROM prices WHERE symbol = ? AND timestamp BETWEEN ? AND ? ORDER BY timestamp ASC",
                                (symbol.upper(), start_time, end_time))
            rows = self.cursor.fetchall()
            prices = [row[0] for row in rows]
            timestamps = [row[1] for row in rows]
            return prices, timestamps
        except sqlite3.Error as e:
            print(f"Error retrieving prices: {e}")
            return [], []

    def close(self):
        if self.conn:
            self.conn.close()
            print("Database connection closed.")

# Example Usage (for testing purposes)
if __name__ == \'__main__\':
    db = CryptoDB()

    # Save some dummy data
    db.save_price(\'BTC\', 65000.50)
    time.sleep(1)
    db.save_price(\'BTC\', 65100.25)
    time.sleep(1)
    db.save_price(\'ETH\', 3500.75)

    # Get data
    btc_prices, btc_timestamps = db.get_prices(\'BTC\')
    print(f"BTC Prices: {btc_prices}")
    print(f"BTC Timestamps: {btc_timestamps}")

    eth_prices, eth_timestamps = db.get_prices(\'ETH\')
    print(f"ETH Prices: {eth_prices}")
    print(f"ETH Timestamps: {eth_timestamps}")

    db.close()


