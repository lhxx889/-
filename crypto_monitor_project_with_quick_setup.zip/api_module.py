import requests
import json

class CryptoAPI:
    def __init__(self, cmc_api_keys=None):
        self.cmc_api_keys = cmc_api_keys if cmc_api_keys else []
        self.current_cmc_api_key_index = 0
        self.base_urls = {
            'binance': 'https://api.binance.com/api/v3',
            'coinmarketcap': 'https://pro-api.coinmarketcap.com/v1'
        }

    def _get_current_cmc_api_key(self):
        if not self.cmc_api_keys:
            return None
        return self.cmc_api_keys[self.current_cmc_api_key_index]

    def _switch_cmc_api_key(self):
        if self.cmc_api_keys:
            self.current_cmc_api_key_index = (self.current_cmc_api_key_index + 1) % len(self.cmc_api_keys)
            print(f"Switched to CoinMarketCap API key index: {self.current_cmc_api_key_index}")
        else:
            print("No CoinMarketCap API keys available to switch.")

    def get_binance_price(self, symbol):
        url = f"{self.base_urls['binance']}/ticker/price?symbol={symbol.upper()}USDT"
        try:
            response = requests.get(url)
            response.raise_for_status()  # Raise an exception for HTTP errors
            data = response.json()
            return float(data['price'])
        except requests.exceptions.RequestException as e:
            print(f"Error fetching Binance price for {symbol}: {e}")
            return None

    def get_coinmarketcap_price(self, symbol):
        api_key = self._get_current_cmc_api_key()
        if not api_key:
            print("CoinMarketCap API key is not set or available.")
            return None

        headers = {
            'Accepts': 'application/json',
            'X-CMC_PRO_API_KEY': api_key,
        }
        parameters = {
            'symbol': symbol.upper(),
            'convert': 'USDT'
        }
        url = f"{self.base_urls['coinmarketcap']}/cryptocurrency/quotes/latest"
        
        for _ in range(len(self.cmc_api_keys) if self.cmc_api_keys else 1): # Try all available keys
            try:
                response = requests.get(url, headers=headers, params=parameters)
                response.raise_for_status()
                data = response.json()
                return float(data['data'][symbol.upper()]['quote']['USDT']['price'])
            except requests.exceptions.RequestException as e:
                print(f"Error fetching CoinMarketCap price for {symbol} with current API key: {e}")
                self._switch_cmc_api_key()
                api_key = self._get_current_cmc_api_key() # Get the new key after switching
                headers['X-CMC_PRO_API_KEY'] = api_key # Update header with new key
            except KeyError:
                print(f"Could not find price for {symbol} on CoinMarketCap or invalid API response.")
                return None
        print("All CoinMarketCap API keys failed.")
        return None

# Example Usage (for testing purposes, will be removed in final script)
if __name__ == '__main__':
    # Example with multiple CoinMarketCap API keys
    cmc_keys = ["YOUR_PRIMARY_CMC_API_KEY", "YOUR_SECONDARY_CMC_API_KEY"]
    crypto_api = CryptoAPI(cmc_api_keys=cmc_keys)

    # Test Binance
    btc_price_binance = crypto_api.get_binance_price('BTC')
    if btc_price_binance:
        print(f"Binance BTC Price: {btc_price_binance}")

    # Test CoinMarketCap with key switching
    btc_price_cmc = crypto_api.get_coinmarketcap_price('BTC')
    if btc_price_cmc:
        print(f"CoinMarketCap BTC Price: {btc_price_cmc}")


