import json
from config_manager import load_config, save_config

CONFIG_FILE_PATH = 

def interactive_configure(config_file_path=
    config = load_config(config_file_path)

    print("\n--- 加密货币监控脚本配置工具 ---")
    print("欢迎使用本工具，它将引导您完成脚本的基本配置。")
    print("请准备好您的Telegram Bot Token/Chat ID 和 CoinMarketCap API Key（如果需要）。")

    # Telegram Configuration
    configure_telegram = input("\n是否配置 Telegram 推送？(y/n): ").lower()
    if configure_telegram == 'y':
        telegram_config = config.get("telegram", {})
        telegram_config["bot_token"] = input(f"请输入 Telegram Bot Token (当前: {telegram_config.get("bot_token", "无")}): ") or telegram_config.get("bot_token")
        telegram_config["chat_id"] = input(f"请输入 Telegram Chat ID (当前: {telegram_config.get("chat_id", "无")}): ") or telegram_config.get("chat_id")
        config["telegram"] = telegram_config

    # CoinMarketCap API Configuration
    configure_cmc = input("\n是否配置 CoinMarketCap API？(y/n): ").lower()
    if configure_cmc == 'y':
        cmc_config = config.get("coinmarketcap", {})
        api_keys = []
        primary_key = input(f"请输入主 CoinMarketCap API Key (当前: {cmc_config.get("api_keys", ["无"])[0] if cmc_config.get("api_keys") else "无"}): ") or (cmc_config.get("api_keys")[0] if cmc_config.get("api_keys") else None)
        if primary_key: 
            api_keys.append(primary_key)
        
        add_secondary_key = input("是否添加备用 API Key？(y/n): ").lower()
        if add_secondary_key == 'y':
            secondary_key = input(f"请输入备用 CoinMarketCap API Key (当前: {cmc_config.get("api_keys", ["无", "无"])[1] if len(cmc_config.get("api_keys", [])) > 1 else "无"}): ") or (cmc_config.get("api_keys")[1] if len(cmc_config.get("api_keys", [])) > 1 else None)
            if secondary_key: 
                api_keys.append(secondary_key)
        config["coinmarketcap"] = {"api_keys": api_keys}

    # Monitor Basic Settings
    monitor_config = config.get("monitor", {})
    refresh_interval = input(f"\n请输入数据刷新频率（秒，默认 60）(当前: {monitor_config.get("refresh_interval", 60)}): ") or str(monitor_config.get("refresh_interval", 60))
    monitor_config["refresh_interval"] = int(refresh_interval)
    config["monitor"] = monitor_config

    # Monitored Coins Configuration
    monitored_coins = monitor_config.get("monitored_coins", [])
    add_coins = input("\n是否添加监控币种？(y/n): ").lower()
    if add_coins == 'y':
        while True:
            symbol = input("请输入币种符号（如 BTC, ETH）: ").upper()
            if not symbol: break

            threshold_type = input("告警阈值类型：1. 固定价格 2. 涨跌幅百分比 (1/2): ")
            threshold_price = None
            threshold_percent = None

            if threshold_type == '1':
                threshold_price = float(input("请输入固定价格告警阈值: "))
            elif threshold_type == '2':
                threshold_percent = float(input("请输入涨跌幅百分比告警阈值: "))
            else:
                print("无效的阈值类型，请重新输入。")
                continue

            monitored_coins.append({
                "symbol": symbol,
                "threshold_price": threshold_price,
                "threshold_percent": threshold_percent
            })
            if input("是否继续添加更多币种？(y/n): ").lower() != 'y':
                break
    monitor_config["monitored_coins"] = monitored_coins
    config["monitor"] = monitor_config

    # Announcement Monitor Configuration
    announcement_monitor_config = config.get("announcement_monitor", {})
    configure_announcement = input("\n是否配置交易所公告监控？(y/n): ").lower()
    if configure_announcement == 'y':
        announcement_monitor_config["binance_announcement_url"] = input(f"请输入币安公告URL (默认 https://www.binance.com/en/support/announcement/list/48): ") or "https://www.binance.com/en/support/announcement/list/48"
        keywords_str = input(f"请输入关键词（逗号分隔，默认 listing,new,airdrop）(当前: {",".join(announcement_monitor_config.get("keywords", ["listing", "new", "airdrop"]))}): ") or ",".join(announcement_monitor_config.get("keywords", ["listing", "new", "airdrop"]))
        announcement_monitor_config["keywords"] = [k.strip() for k in keywords_str.split(",")]
        config["announcement_monitor"] = announcement_monitor_config

    print("\n--- 配置摘要 ---")
    print(json.dumps(config, indent=4))

    save_confirm = input("\n是否保存以上配置到 config.json？(y/n): ").lower()
    if save_confirm == 'y':
        save_config(config, config_file_path)
        print("配置已保存到 config.json。")
    else:
        print("配置未保存。")

if __name__ == '__main__':
    interactive_configure("/opt/crypto_monitor/config.json")


