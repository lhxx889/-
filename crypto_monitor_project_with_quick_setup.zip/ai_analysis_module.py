import google.generativeai as genai
import json
import os
import time
from datetime import datetime, timedelta

from database_module import CryptoDB
from telegram_notifier import TelegramNotifier

class AIAnalysisModule:
    def __init__(self, config_path='ai_config.json'):
        self.config = self._load_config(config_path)
        self.db = CryptoDB()
        self.telegram_notifier = None
        if self.config.get('telegram', {}).get('bot_token') and self.config.get("telegram", {}).get("chat_id"):
            self.telegram_notifier = TelegramNotifier(
                self.config["telegram"]["bot_token"],
                self.config["telegram"]["chat_id"]
            )
        
        gemini_api_key = self.config.get('gemini_api_key')
        if not gemini_api_key:
            print("Error: Gemini API key not found in config.")
            return
        genai.configure(api_key=gemini_api_key)
        self.model = genai.GenerativeModel('gemini-pro')

    def _load_config(self, config_path):
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                return json.load(f)
        else:
            print(f"Error: Config file not found at {config_path}")
            return {}

    def _get_historical_data(self, symbol, lookback_days):
        end_time = int(time.time())
        start_time = int(time.time() - timedelta(days=lookback_days).total_seconds())
        prices, timestamps = self.db.get_prices(symbol, start_time, end_time)
        return prices, timestamps

    def _prepare_data_for_gemini(self, symbol, prices, timestamps):
        if not prices or not timestamps:
            return f"No historical data available for {symbol}."

        data_points = []
        for i in range(len(prices)):
            dt_object = datetime.fromtimestamp(timestamps[i])
            data_points.append(f'Time: {dt_object.isoformat()}, Price: {prices[i]:.2f}')       
        prompt = f"""Analyze the following historical price data for {symbol} and provide: 
1. A summary of the price trend (e.g., increasing, decreasing, stable, volatile).
2. Any significant price movements or anomalies.
3. A short-term prediction (e.g., next 24 hours) based on the trend.

Historical Data for {symbol}:
"""
        prompt += "\n".join(data_points)
        return prompt

    def analyze_crypto(self, symbol, lookback_days):
        print(f"Analyzing {symbol} for the past {lookback_days} days...")
        prices, timestamps = self._get_historical_data(symbol, lookback_days)
        
        if not prices:
            message = f"No historical data found for {symbol} in the last {lookback_days} days."
            print(message)
            if self.telegram_notifier:
                self.telegram_notifier.send_message(message)
            return

        prompt = self._prepare_data_for_gemini(symbol, prices, timestamps)
        
        try:
            response = self.model.generate_content(prompt)
            analysis_result = response.text
            print(f"AI Analysis for {symbol}:\n{analysis_result}")
            if self.telegram_notifier:
                self.telegram_notifier.send_message(f"AI Analysis for {symbol}:\n{analysis_result}")
        except Exception as e:
            error_message = f"Error during AI analysis for {symbol}: {e}"
            print(error_message)
            if self.telegram_notifier:
                self.telegram_notifier.send_message(error_message)

    def start_analysis_loop(self):
        print("Starting AI analysis loop...")
        while True:
            for coin_setting in self.config.get("analysis_settings", {}).get("monitored_coins", []):
                symbol = coin_setting.get("symbol")
                lookback_days = coin_setting.get("lookback_days", 7)
                if symbol:
                    self.analyze_crypto(symbol, lookback_days)
            
            interval = self.config.get("analysis_settings", {}).get("analysis_interval_seconds", 3600)
            print(f"Waiting for {interval} seconds before next analysis...")
            time.sleep(interval)

if __name__ == '__main__':
    # This part is for testing the AIAnalysisModule independently.
    # In a real scenario, you would run this script as a separate process.
    # Make sure you have ai_config.json configured with your Gemini API key and Telegram details.
    
    # Example: Populate some dummy data for testing
    db_test = CryptoDB()
    current_time = int(time.time())
    for i in range(7):
        # Simulate 7 days of data
        day_timestamp = current_time - (6 - i) * 24 * 3600
        db_test.save_price("BTC", 60000 + i * 100 + (i % 2) * 50, day_timestamp) # Example BTC price
        db_test.save_price("ETH", 3000 + i * 20 + (i % 3) * 10, day_timestamp) # Example ETH price
    db_test.close()

    ai_module = AIAnalysisModule()
    ai_module.start_analysis_loop()


