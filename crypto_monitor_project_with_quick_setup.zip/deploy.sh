#!/bin/bash

# Script for deploying and running the cryptocurrency monitor on Linux

# --- Configuration ---
INSTALL_DIR="/opt/crypto_monitor"
PYTHON_ENV_DIR="${INSTALL_DIR}/venv"
CONFIG_FILE="${INSTALL_DIR}/config.json"
MAIN_SCRIPT="${INSTALL_DIR}/main.py"
LOG_FILE="${INSTALL_DIR}/monitor.log"
PID_FILE="${INSTALL_DIR}/monitor.pid"

# --- Functions ---
log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERROR] $1"
}

install_dependencies() {
    log_info "Installing system dependencies..."
    sudo apt update
    sudo apt install -y python3 python3-pip python3-venv
    if [ $? -ne 0 ]; then
        log_error "Failed to install system dependencies."
        exit 1
    fi
    log_info "System dependencies installed."
}

setup_python_environment() {
    log_info "Setting up Python virtual environment..."
    python3 -m venv "${PYTHON_ENV_DIR}"
    if [ $? -ne 0 ]; then
        log_error "Failed to create virtual environment."
        exit 1
    fi
    source "${PYTHON_ENV_DIR}/bin/activate"
    pip install --no-cache-dir -r "${INSTALL_DIR}/requirements.txt"
    if [ $? -ne 0 ]; then
        log_error "Failed to install Python packages from requirements.txt."
        exit 1
    fi
    deactivate
    log_info "Python virtual environment set up."
}

copy_files() {
    log_info "Copying application files to ${INSTALL_DIR}..."
    sudo mkdir -p "${INSTALL_DIR}"
    sudo cp api_module.py "${INSTALL_DIR}/"
    sudo cp monitor_module.py "${INSTALL_DIR}/"
    sudo cp telegram_notifier.py "${INSTALL_DIR}/"
    sudo cp visualizer_module.py "${INSTALL_DIR}/"
    sudo cp config_manager.py "${INSTALL_DIR}/"
    sudo cp main.py "${INSTALL_DIR}/"
    sudo cp config.json "${INSTALL_DIR}/"
    sudo cp database_module.py "${INSTALL_DIR}/"
    sudo cp sentiment_analyzer.py "${INSTALL_DIR}/"
    sudo cp logger_config.py "${INSTALL_DIR}/"
    sudo cp requirements.txt "${INSTALL_DIR}/"
    # Set ownership to ubuntu user for files in INSTALL_DIR
    sudo chown -R ubuntu:ubuntu "${INSTALL_DIR}"
    if [ $? -ne 0 ]; then
        log_error "Failed to copy application files or set ownership."
        exit 1
    fi
    log_info "Application files copied and ownership set."
}

run_monitor() {
    log_info "Running cryptocurrency monitor..."
    # Run the script as the ubuntu user using su -c
    su - ubuntu -c "source \"${PYTHON_ENV_DIR}/bin/activate\" && nohup python \"${MAIN_SCRIPT}\" > \"${LOG_FILE}\" 2>&1 & echo \"$!\" > \"${PID_FILE}\""
    if [ $? -ne 0 ]; then
        log_error "Failed to start monitor."
        exit 1
    fi
    log_info "Monitor started in background. Check ${LOG_FILE} for output."
}

stop_monitor() {
    log_info "Stopping cryptocurrency monitor..."
    if [ -f "${PID_FILE}" ]; then
        PID=$(cat "${PID_FILE}")
        # Kill the process as the ubuntu user using su -c
        su - ubuntu -c "kill \"${PID}\" && rm \"${PID_FILE}\""
        log_info "Monitor stopped."
    else
        log_info "Monitor is not running or PID file not found."
    fi
}

# --- Main Logic ---
case "$1" in
    install)
        install_dependencies
        copy_files
        setup_python_environment
        log_info "Installation complete. You can now run \'sudo ./deploy.sh start\'."
        ;;
    start)
        run_monitor
        ;;
    stop)
        stop_monitor
        ;;
    restart)
        stop_monitor
        run_monitor
        ;;
    *)
        echo "Usage: $0 {install|start|stop|restart}"
        exit 1
        ;;
esac


