import logging
import os

def setup_logging(log_file=\"crypto_monitor.log\", level=logging.INFO):
    # Create logger
    logger = logging.getLogger(\"crypto_monitor\")
    logger.setLevel(level)

    # Create handlers
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)

    # File handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(level)

    # Create formatters and add them to handlers
    formatter = logging.Formatter(\"%(asctime)s - %(name)s - %(levelname)s - %(message)s\")
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    # Add handlers to the logger
    # Ensure handlers are not duplicated if setup_logging is called multiple times
    if not logger.handlers:
        logger.addHandler(console_handler)
        logger.addHandler(file_handler)

    return logger

# Example Usage
if __name__ == \"__main__\":
    logger = setup_logging()
    logger.info(\"This is an info message.\")
    logger.warning(\"This is a warning message.\")
    logger.error(\"This is an error message.\")

    # Test with a different level
    debug_logger = setup_logging(log_file=\"debug.log\", level=logging.DEBUG)
    debug_logger.debug(\"This is a debug message.\")
    debug_logger.info(\"This is an info message from debug logger.\")


