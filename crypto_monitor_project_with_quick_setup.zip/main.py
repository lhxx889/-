from config_manager import load_config
from monitor_module import CryptoMonitor

def main():
    config = load_config()
    if not config:
        print("Failed to load configuration. Exiting.")
        return

    telegram_config = config.get("telegram", {})
    monitor_config = config.get("monitor", {})
    coinmarketcap_config = config.get("coinmarketcap", {})

    monitor = CryptoMonitor(
        api_key=coinmarketcap_config.get("api_key"),
        telegram_bot_token=telegram_config.get("bot_token"),
        telegram_chat_id=telegram_config.get("chat_id")
    )

    monitor.set_refresh_interval(monitor_config.get("refresh_interval", 60))

    for coin in monitor_config.get("monitored_coins", []):
        monitor.add_coin_to_monitor(
            coin.get("symbol"),
            coin.get("threshold_price"),
            coin.get("threshold_percent")
        )

    monitor.start_monitoring()

if __name__ == '__main__':
    main()


