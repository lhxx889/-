import time
print("📈 模拟监控中... 每 50 秒运行一次检查（略）")
while True:
    time.sleep(50)
