import sqlite3

conn = sqlite3.connect("gateio.db")
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS price_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT,
    price_change REAL,
    volume_change REAL,
    reason TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)''')

conn.commit()
conn.close()
print("✅ 数据库初始化完成")
