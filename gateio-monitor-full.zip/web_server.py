from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import sqlite3
import os

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    conn = sqlite3.connect("gateio.db")
    c = conn.cursor()
    c.execute("SELECT symbol, price_change, volume_change, reason, timestamp FROM price_events ORDER BY timestamp DESC LIMIT 20")
    rows = c.fetchall()
    conn.close()
    return templates.TemplateResponse("dashboard.html", {"request": request, "events": rows})

@app.get("/config", response_class=HTMLResponse)
def config_page(request: Request):
    return templates.TemplateResponse("config.html", {"request": request})

@app.post("/save_config")
def save_config(token: str = Form(...), chat_id: str = Form(...)):
    with open("telegram_config.txt", "w") as f:
        f.write(f"{token.strip()}
{chat_id.strip()}")
    return {"status": "success"}
