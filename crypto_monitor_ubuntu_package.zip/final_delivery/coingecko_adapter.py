"""
CoinGecko API适配器 - 作为币安的备用数据源
"""

import requests
import time
import logging
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("coingecko_adapter")

class CoinGeckoExchangeAPI:
    """CoinGecko API适配器，作为币安的备用数据源"""
    
    # CoinGecko API基础URL
    BASE_URL = "https://api.coingecko.com/api/v3"
    
    # API端点
    ENDPOINTS = {
        "coins_list": "/coins/list",
        "coins_markets": "/coins/markets",
        "coin_data": "/coins/{id}",
        "simple_price": "/simple/price"
    }
    
    # 币种ID映射缓存
    coin_id_mapping = {}
    
    def __init__(self, proxy: str = None, api_key: str = None):
        """
        初始化CoinGecko API适配器
        
        Args:
            proxy: 代理服务器URL (如 "http://10.10.1.10:3128")
            api_key: CoinGecko API密钥（可选，用于提高请求限制）
        """
        # 设置代理
        self.proxies = None
        if proxy:
            self.proxies = {
                "http": proxy,
                "https": proxy
            }
        
        # 设置API密钥
        self.api_key = api_key
        self.headers = {}
        if api_key:
            self.headers["x-cg-pro-api-key"] = api_key
        
        logger.info(f"CoinGecko API适配器初始化，代理: {'已配置' if self.proxies else '未配置'}, API密钥: {'已配置' if self.api_key else '未配置'}")
    
    @property
    def exchange_name(self) -> str:
        """获取交易所名称"""
        return "CoinGecko"
    
    @property
    def exchange_id(self) -> str:
        """获取交易所唯一标识符"""
        return "coingecko"
    
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """
        获取所有交易对的ticker数据
        
        Returns:
            所有交易对的ticker数据列表
        """
        logger.info("获取CoinGecko所有币种的市场数据")
        url = f"{self.BASE_URL}{self.ENDPOINTS['coins_markets']}"
        params = {
            "vs_currency": "usd",
            "order": "market_cap_desc",
            "per_page": 250,
            "page": 1,
            "sparkline": "false",
            "price_change_percentage": "24h"
        }
        
        all_coins = []
        max_pages = 4  # 限制最大页数，避免过多请求
        
        for page in range(1, max_pages + 1):
            params["page"] = page
            response = self._make_request(url, params)
            
            if not response:
                break
                
            all_coins.extend(response)
            logger.info(f"获取CoinGecko市场数据第{page}页，共{len(response)}个币种")
            
            # 如果返回的数据少于每页数量，说明已经是最后一页
            if len(response) < params["per_page"]:
                break
                
            # 添加延迟，避免触发API限制
            time.sleep(1.5)
        
        logger.info(f"成功获取CoinGecko {len(all_coins)}个币种的市场数据")
        return all_coins
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取特定交易对的ticker数据
        
        Args:
            symbol: 交易对符号，如"BTC_USDT"或"BTC"
            
        Returns:
            交易对的ticker数据或None（如果请求失败）
        """
        # 从symbol中提取币种部分
        coin_symbol = symbol.split('_')[0] if '_' in symbol else symbol
        
        # 获取币种ID
        coin_id = self._get_coin_id(coin_symbol)
        if not coin_id:
            logger.warning(f"无法找到币种 {coin_symbol} 的CoinGecko ID")
            return None
        
        logger.info(f"获取CoinGecko币种 {coin_id} 的详细数据")
        url = f"{self.BASE_URL}{self.ENDPOINTS['coin_data'].format(id=coin_id)}"
        params = {
            "localization": "false",
            "tickers": "true",
            "market_data": "true",
            "community_data": "false",
            "developer_data": "false"
        }
        
        return self._make_request(url, params)
    
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """
        获取所有可交易的交易对信息
        
        Returns:
            所有可交易的交易对信息列表
        """
        logger.info("获取CoinGecko所有币种列表")
        url = f"{self.BASE_URL}{self.ENDPOINTS['coins_list']}"
        
        response = self._make_request(url)
        if response:
            # 更新币种ID映射
            for coin in response:
                self.coin_id_mapping[coin.get("symbol", "").upper()] = coin.get("id")
            
            logger.info(f"成功获取CoinGecko {len(response)}个币种信息")
            
            # 转换为标准格式
            currency_pairs = []
            for coin in response:
                currency_pairs.append({
                    "id": coin.get("id"),
                    "symbol": f"{coin.get('symbol', '').upper()}_USDT",
                    "base_asset": coin.get("symbol", "").upper(),
                    "quote_asset": "USDT"
                })
            
            return currency_pairs
        
        return []
    
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """
        将CoinGecko特定的ticker数据格式转换为标准格式
        
        Args:
            ticker: CoinGecko特定的ticker数据
            
        Returns:
            标准化的ticker数据
        """
        try:
            # 构建标准化的交易对符号（添加_USDT后缀）
            symbol = ticker.get("symbol", "").upper()
            normalized_symbol = f"{symbol}_USDT"
            
            # 获取价格和交易量数据
            current_price = ticker.get("current_price", 0)
            market_cap = ticker.get("market_cap", 0)
            total_volume = ticker.get("total_volume", 0)
            price_change_24h = ticker.get("price_change_percentage_24h", 0)
            high_24h = ticker.get("high_24h", 0)
            low_24h = ticker.get("low_24h", 0)
            
            return {
                "exchange": self.exchange_id,
                "exchange_name": self.exchange_name,
                "symbol": normalized_symbol,
                "original_symbol": symbol,
                "price": current_price,
                "volume_24h": total_volume,
                "change_24h": price_change_24h,
                "high_24h": high_24h,
                "low_24h": low_24h,
                "market_cap": market_cap,
                "timestamp": datetime.now().isoformat(),
                "original_data": ticker
            }
        except (ValueError, TypeError) as e:
            logger.warning(f"标准化CoinGecko ticker数据失败: {str(e)}")
            return {
                "exchange": self.exchange_id,
                "exchange_name": self.exchange_name,
                "symbol": f"{ticker.get('symbol', '').upper()}_USDT",
                "original_symbol": ticker.get("symbol", "").upper(),
                "price": 0.0,
                "volume_24h": 0.0,
                "change_24h": 0.0,
                "high_24h": 0.0,
                "low_24h": 0.0,
                "timestamp": datetime.now().isoformat(),
                "original_data": ticker
            }
    
    def get_exchange_url(self, symbol: str) -> str:
        """
        获取币种在CoinGecko的URL链接
        
        Args:
            symbol: 交易对符号，如"BTC_USDT"或"BTC"
            
        Returns:
            币种在CoinGecko的URL链接
        """
        # 从symbol中提取币种部分
        coin_symbol = symbol.split('_')[0] if '_' in symbol else symbol
        
        # 获取币种ID
        coin_id = self._get_coin_id(coin_symbol)
        if not coin_id:
            # 如果找不到ID，使用symbol作为fallback
            return f"https://www.coingecko.com/en/coins/{coin_symbol.lower()}"
        
        return f"https://www.coingecko.com/en/coins/{coin_id}"
    
    def _get_coin_id(self, symbol: str) -> Optional[str]:
        """
        获取币种的CoinGecko ID
        
        Args:
            symbol: 币种符号，如"BTC"
            
        Returns:
            币种的CoinGecko ID或None（如果找不到）
        """
        symbol = symbol.upper()
        
        # 检查缓存
        if symbol in self.coin_id_mapping:
            return self.coin_id_mapping[symbol]
        
        # 如果缓存中没有，获取所有币种列表
        if not self.coin_id_mapping:
            self.fetch_all_currency_pairs()
            
            # 再次检查缓存
            if symbol in self.coin_id_mapping:
                return self.coin_id_mapping[symbol]
        
        # 常见币种的映射
        common_coins = {
            "BTC": "bitcoin",
            "ETH": "ethereum",
            "USDT": "tether",
            "BNB": "binancecoin",
            "XRP": "ripple",
            "ADA": "cardano",
            "SOL": "solana",
            "DOT": "polkadot",
            "DOGE": "dogecoin",
            "AVAX": "avalanche-2"
        }
        
        # 检查常见币种映射
        if symbol in common_coins:
            self.coin_id_mapping[symbol] = common_coins[symbol]
            return common_coins[symbol]
        
        logger.warning(f"无法找到币种 {symbol} 的CoinGecko ID")
        return None
    
    def _make_request(self, url: str, params: Dict = None) -> Optional[Any]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API端点URL
            params: 请求参数
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    url, 
                    params=params, 
                    headers=self.headers,
                    timeout=15,
                    proxies=self.proxies
                )
                
                # 检查是否达到API请求限制
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", retry_delay * 2))
                    logger.warning(f"CoinGecko API请求限制，等待{retry_after}秒后重试")
                    time.sleep(retry_after)
                    continue
                
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"CoinGecko API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"CoinGecko API请求最终失败: {str(e)}")
                    return None
            except json.JSONDecodeError as e:
                logger.error(f"解析CoinGecko API响应JSON失败: {str(e)}")
                return None


# 测试代码
if __name__ == "__main__":
    # 创建CoinGecko API适配器实例
    coingecko = CoinGeckoExchangeAPI()
    
    # 测试获取所有币种列表
    print("获取所有币种列表...")
    currency_pairs = coingecko.fetch_all_currency_pairs()
    print(f"共获取到 {len(currency_pairs)} 个币种")
    if currency_pairs:
        print("前5个币种:")
        for pair in currency_pairs[:5]:
            print(f"  - {pair['symbol']}: ID={pair['id']}")
    
    # 测试获取市场数据
    print("\n获取市场数据...")
    tickers = coingecko.fetch_all_tickers()
    print(f"共获取到 {len(tickers)} 个币种的市场数据")
    if tickers:
        print("前5个币种的市场数据:")
        for ticker in tickers[:5]:
            print(f"  - {ticker['symbol'].upper()}: 价格=${ticker['current_price']}, 24h交易量=${ticker['total_volume']}")
    
    # 测试获取特定币种数据
    print("\n获取特定币种数据...")
    btc_data = coingecko.fetch_ticker("BTC")
    if btc_data:
        print(f"比特币(BTC)数据:")
        print(f"  - 当前价格: ${btc_data['market_data']['current_price']['usd']}")
        print(f"  - 24h交易量: ${btc_data['market_data']['total_volume']['usd']}")
        print(f"  - 市值: ${btc_data['market_data']['market_cap']['usd']}")
    
    # 测试标准化数据
    print("\n测试标准化数据...")
    if tickers:
        normalized = coingecko.normalize_ticker_data(tickers[0])
        print("原始数据:")
        print(f"  - {tickers[0]['name']} ({tickers[0]['symbol'].upper()})")
        print("标准化数据:")
        print(f"  - 交易所: {normalized['exchange_name']}")
        print(f"  - 交易对: {normalized['symbol']}")
        print(f"  - 价格: ${normalized['price']}")
        print(f"  - 24h交易量: ${normalized['volume_24h']}")
        print(f"  - 24h变化百分比: {normalized['change_24h']}%")
    
    # 测试获取币种URL
    print("\n测试获取币种URL...")
    btc_url = coingecko.get_exchange_url("BTC_USDT")
    eth_url = coingecko.get_exchange_url("ETH")
    print(f"BTC_USDT URL: {btc_url}")
    print(f"ETH URL: {eth_url}")
    
    print("\n测试完成!")
