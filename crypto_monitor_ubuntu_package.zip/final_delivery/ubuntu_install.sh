#!/bin/bash
echo "===== 加密货币监控系统 Ubuntu 22.04 专用安装 ====="

# 安装必要的系统包
echo "正在安装必要的系统包..."
sudo apt update
sudo apt install -y python3-full python3-venv python3-pip

# 创建虚拟环境
echo "正在创建Python虚拟环境..."
python3 -m venv venv
source venv/bin/activate

# 安装依赖
echo "正在安装依赖包..."
pip install --upgrade pip
pip install -r requirements.txt

# 创建基础配置
echo "正在创建基础配置..."
mkdir -p src/config
cat > src/config.json << EOF
{
  "enabled_exchanges": ["gateio", "binance"],
  "use_binance_testnet": true,
  "check_interval": 60,
  "price_change_threshold": 5.0,
  "volume_change_threshold": 20.0,
  "detection_sensitivity": "medium",
  "enable_advanced_detection": true
}
EOF

echo "===== 安装完成! ====="
echo "启动系统请运行: ./ubuntu_start.sh"

# 创建启动脚本
cat > ubuntu_start.sh << EOF
#!/bin/bash
source venv/bin/activate
cd src
python main.py
EOF

chmod +x ubuntu_start.sh
