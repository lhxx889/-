"""
高级异常检测算法测试模块 - 验证各种检测算法的效果
"""

import sys
import os
import json
import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import logging
from typing import List, Dict, Any

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# 导入高级异常检测器
from src.advanced_anomaly_detector import AdvancedAnomalyDetector

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("anomaly_detector_test")

def generate_test_data(num_points=1000, anomaly_ratio=0.05):
    """
    生成测试数据，包含正常价格和异常价格
    
    参数:
        num_points: 数据点数量
        anomaly_ratio: 异常数据比例
        
    返回:
        测试数据列表
    """
    # 生成时间序列
    base_time = datetime.now() - timedelta(hours=num_points)
    timestamps = [base_time + timedelta(hours=i) for i in range(num_points)]
    
    # 生成正常价格数据（随机游走）
    np.random.seed(42)
    price = 1000.0  # 起始价格
    prices = [price]
    
    for i in range(1, num_points):
        # 随机游走，每步变化在 -1% 到 1% 之间
        change = np.random.normal(0, 0.01)
        price = price * (1 + change)
        prices.append(price)
    
    # 生成交易量数据
    volumes = []
    for i in range(num_points):
        # 基础交易量
        base_volume = 1000000
        # 添加每日周期性变化
        hour_factor = 1 + 0.5 * np.sin(2 * np.pi * (i % 24) / 24)
        # 添加随机波动
        random_factor = np.random.normal(1, 0.2)
        volume = base_volume * hour_factor * random_factor
        volumes.append(volume)
    
    # 插入异常数据
    num_anomalies = int(num_points * anomaly_ratio)
    anomaly_indices = np.random.choice(range(num_points), num_anomalies, replace=False)
    
    for idx in anomaly_indices:
        if idx > 0:  # 避免修改第一个数据点
            # 价格异常：大幅上涨或下跌
            if np.random.random() > 0.5:
                # 上涨 10% 到 30%
                prices[idx] = prices[idx-1] * (1 + np.random.uniform(0.1, 0.3))
            else:
                # 下跌 10% 到 30%
                prices[idx] = prices[idx-1] * (1 - np.random.uniform(0.1, 0.3))
            
            # 交易量异常：大幅增加
            volumes[idx] = volumes[idx-1] * np.random.uniform(2, 5)
    
    # 构建数据列表
    data = []
    for i in range(num_points):
        item = {
            'coin_id': 1,
            'exchange_id': 'test_exchange',
            'symbol': 'BTC_USDT',
            'price': prices[i],
            'volume_24h': volumes[i],
            'timestamp': timestamps[i].isoformat()
        }
        data.append(item)
    
    return data

def plot_data_with_anomalies(data, anomalies):
    """
    绘制数据和检测到的异常
    
    参数:
        data: 价格数据列表
        anomalies: 检测到的异常列表
    """
    # 转换为DataFrame
    df = pd.DataFrame(data)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    # 创建图表
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10), sharex=True)
    
    # 绘制价格数据
    ax1.plot(df['timestamp'], df['price'], label='价格')
    ax1.set_title('价格数据与异常')
    ax1.set_ylabel('价格')
    ax1.grid(True)
    
    # 标记价格异常
    price_anomalies = [a for a in anomalies if a['type'] == 'price']
    if price_anomalies:
        # 确保detected_at是datetime对象
        anomaly_times = []
        anomaly_prices = []
        
        for a in price_anomalies:
            if isinstance(a['detected_at'], datetime):
                anomaly_time = a['detected_at']
            else:
                # 如果是字符串，尝试转换
                try:
                    anomaly_time = datetime.fromisoformat(str(a['detected_at']).replace('Z', '+00:00'))
                except:
                    # 如果转换失败，使用当前时间
                    anomaly_time = datetime.now()
            
            anomaly_times.append(anomaly_time)
            anomaly_prices.append(a['current_price'])
        
        ax1.scatter(anomaly_times, anomaly_prices, color='red', s=50, label='价格异常')
    
    ax1.legend()
    
    # 绘制交易量数据
    ax2.plot(df['timestamp'], df['volume_24h'], label='交易量')
    ax2.set_title('交易量数据与异常')
    ax2.set_xlabel('时间')
    ax2.set_ylabel('交易量')
    ax2.grid(True)
    
    # 标记交易量异常
    volume_anomalies = [a for a in anomalies if a['type'] == 'volume']
    if volume_anomalies:
        # 确保detected_at是datetime对象
        anomaly_times = []
        anomaly_volumes = []
        
        for a in volume_anomalies:
            if isinstance(a['detected_at'], datetime):
                anomaly_time = a['detected_at']
            else:
                # 如果是字符串，尝试转换
                try:
                    anomaly_time = datetime.fromisoformat(str(a['detected_at']).replace('Z', '+00:00'))
                except:
                    # 如果转换失败，使用当前时间
                    anomaly_time = datetime.now()
            
            anomaly_times.append(anomaly_time)
            anomaly_volumes.append(a['volume_24h'])
        
        ax2.scatter(anomaly_times, anomaly_volumes, color='red', s=50, label='交易量异常')
    
    ax2.legend()
    
    plt.tight_layout()
    plt.savefig('anomaly_detection_results.png')
    logger.info("已保存异常检测结果图表到 anomaly_detection_results.png")

def evaluate_detector(data, anomalies, known_anomaly_indices):
    """
    评估异常检测器的性能
    
    参数:
        data: 价格数据列表
        anomalies: 检测到的异常列表
        known_anomaly_indices: 已知异常的索引列表
        
    返回:
        性能指标字典
    """
    # 获取检测到的异常索引
    detected_indices = []
    for anomaly in anomalies:
        # 确保detected_at是datetime对象
        if isinstance(anomaly['detected_at'], datetime):
            anomaly_time = anomaly['detected_at']
        else:
            # 如果是字符串，尝试转换
            try:
                anomaly_time = datetime.fromisoformat(str(anomaly['detected_at']).replace('Z', '+00:00'))
            except:
                # 如果转换失败，使用当前时间
                anomaly_time = datetime.now()
        
        # 查找最接近的数据点
        closest_idx = None
        min_diff = float('inf')
        
        for i, item in enumerate(data):
            item_time = datetime.fromisoformat(item['timestamp'].replace('Z', '+00:00'))
            diff = abs((anomaly_time - item_time).total_seconds())
            
            if diff < min_diff:
                min_diff = diff
                closest_idx = i
        
        if closest_idx is not None and min_diff < 3600:  # 1小时内的视为同一点
            detected_indices.append(closest_idx)
    
    # 去重
    detected_indices = list(set(detected_indices))
    
    # 计算性能指标
    true_positives = len(set(detected_indices) & set(known_anomaly_indices))
    false_positives = len(set(detected_indices) - set(known_anomaly_indices))
    false_negatives = len(set(known_anomaly_indices) - set(detected_indices))
    
    precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
    recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
    f1_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    metrics = {
        'true_positives': true_positives,
        'false_positives': false_positives,
        'false_negatives': false_negatives,
        'precision': precision,
        'recall': recall,
        'f1_score': f1_score
    }
    
    return metrics

def test_sensitivity_levels():
    """测试不同灵敏度级别的效果"""
    # 生成测试数据
    test_data = generate_test_data(num_points=500, anomaly_ratio=0.05)
    
    # 获取已知异常索引
    known_anomaly_indices = []
    for i in range(1, len(test_data)):
        price_change = abs(test_data[i]['price'] - test_data[i-1]['price']) / test_data[i-1]['price']
        volume_change = abs(test_data[i]['volume_24h'] - test_data[i-1]['volume_24h']) / test_data[i-1]['volume_24h']
        
        if price_change > 0.1 or volume_change > 1.0:  # 价格变化>10%或交易量变化>100%视为异常
            known_anomaly_indices.append(i)
    
    # 测试不同灵敏度
    sensitivity_levels = ['low', 'medium', 'high']
    results = {}
    
    for sensitivity in sensitivity_levels:
        # 配置检测器
        config = {
            'detection_sensitivity': sensitivity,
            'analysis_window': 24,
            'enable_cross_exchange': 'false'
        }
        
        detector = AdvancedAnomalyDetector(config)
        
        # 检测异常
        anomalies = detector.detect_anomalies(test_data)
        
        # 评估性能
        metrics = evaluate_detector(test_data, anomalies, known_anomaly_indices)
        results[sensitivity] = metrics
        
        logger.info(f"灵敏度 {sensitivity} 的检测结果:")
        logger.info(f"  检测到的异常数量: {len(anomalies)}")
        logger.info(f"  准确率: {metrics['precision']:.4f}")
        logger.info(f"  召回率: {metrics['recall']:.4f}")
        logger.info(f"  F1分数: {metrics['f1_score']:.4f}")
    
    # 绘制性能对比图
    plt.figure(figsize=(10, 6))
    
    metrics_to_plot = ['precision', 'recall', 'f1_score']
    x = np.arange(len(sensitivity_levels))
    width = 0.25
    
    for i, metric in enumerate(metrics_to_plot):
        values = [results[sensitivity][metric] for sensitivity in sensitivity_levels]
        plt.bar(x + i*width, values, width, label=metric)
    
    plt.xlabel('灵敏度级别')
    plt.ylabel('分数')
    plt.title('不同灵敏度级别的检测性能')
    plt.xticks(x + width, sensitivity_levels)
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('sensitivity_comparison.png')
    logger.info("已保存灵敏度对比图表到 sensitivity_comparison.png")

def test_algorithm_comparison():
    """比较不同算法的效果"""
    # 生成测试数据
    test_data = generate_test_data(num_points=500, anomaly_ratio=0.05)
    
    # 获取已知异常索引
    known_anomaly_indices = []
    for i in range(1, len(test_data)):
        price_change = abs(test_data[i]['price'] - test_data[i-1]['price']) / test_data[i-1]['price']
        volume_change = abs(test_data[i]['volume_24h'] - test_data[i-1]['volume_24h']) / test_data[i-1]['volume_24h']
        
        if price_change > 0.1 or volume_change > 1.0:
            known_anomaly_indices.append(i)
    
    # 配置检测器
    config = {
        'detection_sensitivity': 'medium',
        'analysis_window': 24,
        'enable_cross_exchange': 'false'
    }
    
    detector = AdvancedAnomalyDetector(config)
    
    # 检测异常并按算法分组
    all_anomalies = detector.detect_anomalies(test_data)
    
    # 按算法分组
    algorithms = {}
    for anomaly in all_anomalies:
        algo = anomaly['algorithm']
        if algo not in algorithms:
            algorithms[algo] = []
        algorithms[algo].append(anomaly)
    
    # 评估每种算法的性能
    results = {}
    for algo, anomalies in algorithms.items():
        metrics = evaluate_detector(test_data, anomalies, known_anomaly_indices)
        results[algo] = metrics
        
        logger.info(f"算法 {algo} 的检测结果:")
        logger.info(f"  检测到的异常数量: {len(anomalies)}")
        logger.info(f"  准确率: {metrics['precision']:.4f}")
        logger.info(f"  召回率: {metrics['recall']:.4f}")
        logger.info(f"  F1分数: {metrics['f1_score']:.4f}")
    
    # 绘制性能对比图
    if algorithms:  # 确保有算法数据
        plt.figure(figsize=(12, 6))
        
        metrics_to_plot = ['precision', 'recall', 'f1_score']
        x = np.arange(len(algorithms))
        width = 0.25
        
        for i, metric in enumerate(metrics_to_plot):
            values = [results[algo][metric] for algo in algorithms]
            plt.bar(x + i*width, values, width, label=metric)
        
        plt.xlabel('算法')
        plt.ylabel('分数')
        plt.title('不同算法的检测性能')
        plt.xticks(x + width, algorithms.keys())
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('algorithm_comparison.png')
        logger.info("已保存算法对比图表到 algorithm_comparison.png")
    else:
        logger.warning("没有检测到任何算法数据，跳过算法对比图表生成")

def main():
    """主函数"""
    logger.info("开始测试高级异常检测算法")
    
    # 生成测试数据
    logger.info("生成测试数据...")
    test_data = generate_test_data()
    
    # 配置检测器
    config = {
        'detection_sensitivity': 'medium',
        'analysis_window': 24,
        'enable_cross_exchange': 'false'
    }
    
    # 初始化检测器
    logger.info("初始化高级异常检测器...")
    detector = AdvancedAnomalyDetector(config)
    
    # 检测异常
    logger.info("执行异常检测...")
    anomalies = detector.detect_anomalies(test_data)
    
    logger.info(f"检测到 {len(anomalies)} 个异常")
    
    # 绘制结果
    logger.info("绘制检测结果...")
    plot_data_with_anomalies(test_data, anomalies)
    
    # 测试不同灵敏度级别
    logger.info("测试不同灵敏度级别...")
    test_sensitivity_levels()
    
    # 比较不同算法
    logger.info("比较不同算法的效果...")
    test_algorithm_comparison()
    
    logger.info("测试完成")

if __name__ == "__main__":
    main()
