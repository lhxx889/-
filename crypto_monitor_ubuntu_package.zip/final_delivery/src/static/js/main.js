// 主JavaScript文件
$(document).ready(function() {
    // 侧边栏切换
    $('#sidebarCollapse').on('click', function() {
        $('#sidebar').toggleClass('active');
        $('#content').toggleClass('active');
    });

    // 更新当前时间
    function updateCurrentTime() {
        const now = new Date();
        $('#current-time').text(now.toLocaleString());
    }
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);

    // 页面导航
    $('a[data-page]').on('click', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        
        // 更新活动菜单项
        $('a[data-page]').parent().removeClass('active');
        $(this).parent().addClass('active');
        
        // 加载页面内容
        loadPage(page);
    });

    // 默认加载仪表盘页面
    loadPage('dashboard');

    // 加载页面内容
    function loadPage(page) {
        $('#page-content').html('<div class="loader"></div>');
        
        switch(page) {
            case 'dashboard':
                loadDashboard();
                break;
            case 'exchanges':
                loadExchanges();
                break;
            case 'coins':
                loadCoins();
                break;
            case 'anomalies':
                loadAnomalies();
                break;
            case 'settings':
                loadSettings();
                break;
            default:
                $('#page-content').html('<div class="alert alert-danger">页面不存在</div>');
        }
    }

    // 加载仪表盘页面
    function loadDashboard() {
        let html = `
            <h2 class="mb-4">仪表盘</h2>
            <div class="row">
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="icon text-primary">
                            <i class="bi bi-building"></i>
                        </div>
                        <div class="stat-value" id="exchange-count">--</div>
                        <div class="stat-label">交易所</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="icon text-success">
                            <i class="bi bi-coin"></i>
                        </div>
                        <div class="stat-value" id="coin-count">--</div>
                        <div class="stat-label">监控币种</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="icon text-warning">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                        <div class="stat-value" id="anomaly-count">--</div>
                        <div class="stat-label">今日异常</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card">
                        <div class="icon text-danger">
                            <i class="bi bi-activity"></i>
                        </div>
                        <div class="stat-value" id="api-status">--</div>
                        <div class="stat-label">API状态</div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-exclamation-triangle"></i> 最近异常
                        </div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-hover" id="recent-anomalies">
                                    <thead>
                                        <tr>
                                            <th>交易所</th>
                                            <th>币种</th>
                                            <th>类型</th>
                                            <th>变化</th>
                                            <th>时间</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" class="text-center">加载中...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-graph-up"></i> 异常趋势
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="anomaly-trend-chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-currency-exchange"></i> 交易所状态
                        </div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-hover" id="exchange-status">
                                    <thead>
                                        <tr>
                                            <th>交易所</th>
                                            <th>状态</th>
                                            <th>连续失败</th>
                                            <th>最后更新</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" class="text-center">加载中...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('#page-content').html(html);
        
        // 加载仪表盘数据
        loadDashboardData();
    }

    // 加载仪表盘数据
    function loadDashboardData() {
        // 获取交易所数量
        $.get('/api/exchanges/', function(response) {
            if (response.success) {
                $('#exchange-count').text(response.data.length);
                
                // 更新交易所状态表
                updateExchangeStatusTable(response.data);
            }
        });
        
        // 获取币种数量
        $.get('/api/coins/', function(response) {
            if (response.success) {
                $('#coin-count').text(response.data.length);
            }
        });
        
        // 获取今日异常数量
        $.get('/api/anomalies/?hours=24', function(response) {
            if (response.success) {
                $('#anomaly-count').text(response.data.length);
                
                // 更新最近异常表
                updateRecentAnomaliesTable(response.data.slice(0, 5));
            }
        });
        
        // 获取API状态
        $.get('/api/status', function(response) {
            $('#api-status').text('正常');
        }).fail(function() {
            $('#api-status').text('异常');
        });
        
        // 获取异常趋势数据
        $.get('/api/anomalies/stats?days=7', function(response) {
            if (response.success) {
                createAnomalyTrendChart(response.data.by_date);
            }
        });
    }

    // 更新交易所状态表
    function updateExchangeStatusTable(exchanges) {
        let html = '';
        
        if (exchanges.length === 0) {
            html = '<tr><td colspan="5" class="text-center">暂无数据</td></tr>';
        } else {
            exchanges.forEach(function(exchange) {
                let statusBadge = '';
                
                if (exchange.api_status === 'ok') {
                    statusBadge = '<span class="badge bg-success">正常</span>';
                } else if (exchange.api_status === 'limited') {
                    statusBadge = '<span class="badge bg-warning">受限</span>';
                } else if (exchange.api_status === 'error') {
                    statusBadge = '<span class="badge bg-danger">错误</span>';
                } else {
                    statusBadge = '<span class="badge bg-secondary">未知</span>';
                }
                
                html += `
                    <tr>
                        <td>${exchange.name}</td>
                        <td>${statusBadge}</td>
                        <td>${exchange.consecutive_failures}</td>
                        <td>${new Date(exchange.last_updated).toLocaleString()}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="refreshExchange('${exchange.id}')">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }
        
        $('#exchange-status tbody').html(html);
    }

    // 更新最近异常表
    function updateRecentAnomaliesTable(anomalies) {
        let html = '';
        
        if (anomalies.length === 0) {
            html = '<tr><td colspan="5" class="text-center">暂无数据</td></tr>';
        } else {
            anomalies.forEach(function(anomaly) {
                let typeLabel = '';
                let changeClass = '';
                
                if (anomaly.type === 'price') {
                    typeLabel = '价格';
                } else if (anomaly.type === 'volume') {
                    typeLabel = '交易量';
                } else {
                    typeLabel = '模式';
                }
                
                if (anomaly.price_change_pct > 0) {
                    changeClass = 'text-success';
                } else {
                    changeClass = 'text-danger';
                }
                
                html += `
                    <tr>
                        <td>${anomaly.exchange_name}</td>
                        <td>${anomaly.symbol}</td>
                        <td>${typeLabel}</td>
                        <td class="${changeClass}">${anomaly.price_change_pct ? (anomaly.price_change_pct + '%') : '-'}</td>
                        <td>${new Date(anomaly.detected_at).toLocaleString()}</td>
                    </tr>
                `;
            });
        }
        
        $('#recent-anomalies tbody').html(html);
    }

    // 创建异常趋势图表
    function createAnomalyTrendChart(data) {
        const ctx = document.getElementById('anomaly-trend-chart').getContext('2d');
        
        // 准备数据
        const dates = Object.keys(data).sort();
        const counts = dates.map(date => data[date]);
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: '异常数量',
                    data: counts,
                    backgroundColor: 'rgba(52, 152, 219, 0.2)',
                    borderColor: 'rgba(52, 152, 219, 1)',
                    borderWidth: 2,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    }

    // 加载交易所管理页面
    function loadExchanges() {
        let html = `
            <h2 class="mb-4">交易所管理</h2>
            <div class="row mb-3">
                <div class="col-md-6">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addExchangeModal">
                        <i class="bi bi-plus"></i> 添加交易所
                    </button>
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-secondary" id="refresh-exchanges">
                        <i class="bi bi-arrow-clockwise"></i> 刷新
                    </button>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-building"></i> 交易所列表
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table table-hover" id="exchanges-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>名称</th>
                                    <th>状态</th>
                                    <th>启用</th>
                                    <th>最后更新</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="6" class="text-center">加载中...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <h3 class="mt-4 mb-3">备用数据源配置</h3>
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-diagram-3"></i> 备用数据源映射
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table table-hover" id="fallback-table">
                            <thead>
                                <tr>
                                    <th>主交易所</th>
                                    <th>备用交易所</th>
                                    <th>优先级</th>
                                    <th>启用</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="5" class="text-center">加载中...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <button class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addFallbackModal">
                        <i class="bi bi-plus"></i> 添加备用映射
                    </button>
                </div>
            </div>
            
            <!-- 添加交易所模态框 -->
            <div class="modal fade" id="addExchangeModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">添加交易所</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="add-exchange-form">
                                <div class="mb-3">
                                    <label for="exchange-id" class="form-label">交易所ID</label>
                                    <input type="text" class="form-control" id="exchange-id" required>
                                    <div class="form-text">唯一标识符，如 binance, gateio</div>
                                </div>
                                <div class="mb-3">
                                    <label for="exchange-name" class="form-label">交易所名称</label>
                                    <input type="text" class="form-control" id="exchange-name" required>
                                    <div class="form-text">显示名称，如 币安, Gate.io</div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="exchange-enabled" checked>
                                    <label class="form-check-label" for="exchange-enabled">启用</label>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                            <button type="button" class="btn btn-primary" id="save-exchange">保存</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 添加备用映射模态框 -->
            <div class="modal fade" id="addFallbackModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">添加备用数据源映射</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="add-fallback-form">
                                <div class="mb-3">
                                    <label for="primary-exchange" class="form-label">主交易所</label>
                                    <select class="form-select" id="primary-exchange" required>
                                        <option value="">选择交易所</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="fallback-exchange" class="form-label">备用交易所</label>
                                    <select class="form-select" id="fallback-exchange" required>
                                        <option value="">选择交易所</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="fallback-priority" class="form-label">优先级</label>
                                    <input type="number" class="form-control" id="fallback-priority" value="1" min="1" required>
                                    <div class="form-text">数字越小优先级越高</div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="fallback-enabled" checked>
                                    <label class="form-check-label" for="fallback-enabled">启用</label>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                            <button type="button" class="btn btn-primary" id="save-fallback">保存</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('#page-content').html(html);
        
        // 加载交易所数据
        loadExchangesData();
        
        // 绑定事件
        $('#refresh-exchanges').on('click', function() {
            loadExchangesData();
        });
        
        $('#save-exchange').on('click', function() {
            saveExchange();
        });
        
        $('#save-fallback').on('click', function() {
            saveFallback();
        });
    }

    // 加载交易所数据
    function loadExchangesData() {
        // 获取交易所列表
        $.get('/api/exchanges/', function(response) {
            if (response.success) {
                updateExchangesTable(response.data);
                
                // 更新备用交易所下拉列表
                const exchangeOptions = response.data.map(exchange => 
                    `<option value="${exchange.id}">${exchange.name}</option>`
                ).join('');
                
                $('#primary-exchange').html('<option value="">选择交易所</option>' + exchangeOptions);
                $('#fallback-exchange').html('<option value="">选择交易所</option>' + exchangeOptions);
            }
        });
        
        // 获取备用数据源配置
        $.get('/api/exchanges/fallback', function(response) {
            if (response.success) {
                updateFallbackTable(response.data);
            }
        });
    }

    // 更新交易所表
    function updateExchangesTable(exchanges) {
        let html = '';
        
        if (exchanges.length === 0) {
            html = '<tr><td colspan="6" class="text-center">暂无数据</td></tr>';
        } else {
            exchanges.forEach(function(exchange) {
                let statusBadge = '';
                
                if (exchange.api_status === 'ok') {
                    statusBadge = '<span class="badge bg-success">正常</span>';
                } else if (exchange.api_status === 'limited') {
                    statusBadge = '<span class="badge bg-warning">受限</span>';
                } else if (exchange.api_status === 'error') {
                    statusBadge = '<span class="badge bg-danger">错误</span>';
                } else {
                    statusBadge = '<span class="badge bg-secondary">未知</span>';
                }
                
                const enabledSwitch = `
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" 
                            id="exchange-enabled-${exchange.id}" 
                            ${exchange.is_enabled ? 'checked' : ''}
                            onchange="toggleExchange('${exchange.id}', this.checked)">
                    </div>
                `;
                
                html += `
                    <tr>
                        <td>${exchange.id}</td>
                        <td>${exchange.name}</td>
                        <td>${statusBadge}</td>
                        <td>${enabledSwitch}</td>
                        <td>${new Date(exchange.last_updated).toLocaleString()}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="editExchange('${exchange.id}')">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteExchange('${exchange.id}')">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }
        
        $('#exchanges-table tbody').html(html);
    }

    // 更新备用数据源表
    function updateFallbackTable(fallbacks) {
        let html = '';
        
        if (fallbacks.length === 0) {
            html = '<tr><td colspan="5" class="text-center">暂无数据</td></tr>';
        } else {
            fallbacks.forEach(function(fallback) {
                const enabledSwitch = `
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" 
                            id="fallback-enabled-${fallback.id}" 
                            ${fallback.is_enabled ? 'checked' : ''}
                            onchange="toggleFallback(${fallback.id}, this.checked)">
                    </div>
                `;
                
                html += `
                    <tr>
                        <td>${fallback.primary_exchange_name}</td>
                        <td>${fallback.fallback_exchange_name}</td>
                        <td>${fallback.priority}</td>
                        <td>${enabledSwitch}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="editFallback(${fallback.id})">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteFallback(${fallback.id})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }
        
        $('#fallback-table tbody').html(html);
    }

    // 保存交易所
    function saveExchange() {
        const exchangeId = $('#exchange-id').val();
        const exchangeName = $('#exchange-name').val();
        const exchangeEnabled = $('#exchange-enabled').prop('checked');
        
        if (!exchangeId || !exchangeName) {
            alert('请填写所有必填字段');
            return;
        }
        
        const data = {
            id: exchangeId,
            name: exchangeName,
            is_enabled: exchangeEnabled
        };
        
        $.ajax({
            url: '/api/exchanges/',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                if (response.success) {
                    $('#addExchangeModal').modal('hide');
                    loadExchangesData();
                    alert('交易所添加成功');
                } else {
                    alert('添加失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('添加失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }

    // 保存备用数据源映射
    function saveFallback() {
        const primaryExchange = $('#primary-exchange').val();
        const fallbackExchange = $('#fallback-exchange').val();
        const priority = $('#fallback-priority').val();
        const enabled = $('#fallback-enabled').prop('checked');
        
        if (!primaryExchange || !fallbackExchange || !priority) {
            alert('请填写所有必填字段');
            return;
        }
        
        if (primaryExchange === fallbackExchange) {
            alert('主交易所和备用交易所不能相同');
            return;
        }
        
        const data = {
            primary_exchange_id: primaryExchange,
            fallback_exchange_id: fallbackExchange,
            priority: parseInt(priority),
            is_enabled: enabled
        };
        
        $.ajax({
            url: '/api/exchanges/fallback',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                if (response.success) {
                    $('#addFallbackModal').modal('hide');
                    loadExchangesData();
                    alert('备用数据源映射添加成功');
                } else {
                    alert('添加失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('添加失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }

    // 加载币种监控页面
    function loadCoins() {
        let html = `
            <h2 class="mb-4">币种监控</h2>
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <select class="form-select" id="exchange-filter">
                            <option value="">所有交易所</option>
                        </select>
                        <input type="text" class="form-control" id="symbol-search" placeholder="搜索币种...">
                        <button class="btn btn-primary" id="search-coins">
                            <i class="bi bi-search"></i> 搜索
                        </button>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-secondary" id="refresh-coins">
                        <i class="bi bi-arrow-clockwise"></i> 刷新
                    </button>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-coin"></i> 币种价格数据
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table table-hover" id="coins-table">
                            <thead>
                                <tr>
                                    <th>交易所</th>
                                    <th>币种</th>
                                    <th>当前价格</th>
                                    <th>24h变化</th>
                                    <th>24h交易量</th>
                                    <th>最后更新</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="7" class="text-center">加载中...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- 币种详情模态框 -->
            <div class="modal fade" id="coinDetailModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="coin-detail-title">币种详情</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>基本信息</h6>
                                    <table class="table">
                                        <tr>
                                            <th>交易所</th>
                                            <td id="detail-exchange"></td>
                                        </tr>
                                        <tr>
                                            <th>币种</th>
                                            <td id="detail-symbol"></td>
                                        </tr>
                                        <tr>
                                            <th>当前价格</th>
                                            <td id="detail-price"></td>
                                        </tr>
                                        <tr>
                                            <th>24h变化</th>
                                            <td id="detail-change"></td>
                                        </tr>
                                        <tr>
                                            <th>24h交易量</th>
                                            <td id="detail-volume"></td>
                                        </tr>
                                        <tr>
                                            <th>24h最高价</th>
                                            <td id="detail-high"></td>
                                        </tr>
                                        <tr>
                                            <th>24h最低价</th>
                                            <td id="detail-low"></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <h6>价格历史</h6>
                                    <div class="chart-container">
                                        <canvas id="price-history-chart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <h6>最近异常</h6>
                                    <div class="table-container">
                                        <table class="table table-hover" id="coin-anomalies">
                                            <thead>
                                                <tr>
                                                    <th>类型</th>
                                                    <th>价格</th>
                                                    <th>变化</th>
                                                    <th>时间</th>
                                                    <th>算法</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colspan="5" class="text-center">加载中...</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('#page-content').html(html);
        
        // 加载交易所下拉列表
        $.get('/api/exchanges/', function(response) {
            if (response.success) {
                const exchangeOptions = response.data.map(exchange => 
                    `<option value="${exchange.id}">${exchange.name}</option>`
                ).join('');
                
                $('#exchange-filter').append(exchangeOptions);
            }
        });
        
        // 加载币种数据
        loadCoinsData();
        
        // 绑定事件
        $('#refresh-coins').on('click', function() {
            loadCoinsData();
        });
        
        $('#search-coins').on('click', function() {
            loadCoinsData();
        });
    }

    // 加载币种数据
    function loadCoinsData() {
        const exchangeId = $('#exchange-filter').val();
        const symbol = $('#symbol-search').val();
        
        let url = '/api/coins/price';
        let params = [];
        
        if (exchangeId) {
            params.push(`exchange_id=${exchangeId}`);
        }
        
        if (symbol) {
            params.push(`symbol=${symbol}`);
        }
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        $.get(url, function(response) {
            if (response.success) {
                updateCoinsTable(response.data);
            }
        });
    }

    // 更新币种表
    function updateCoinsTable(coins) {
        let html = '';
        
        if (coins.length === 0) {
            html = '<tr><td colspan="7" class="text-center">暂无数据</td></tr>';
        } else {
            coins.forEach(function(coin) {
                let changeClass = '';
                let changeIcon = '';
                
                if (coin.change_percentage_24h > 0) {
                    changeClass = 'text-success';
                    changeIcon = '<i class="bi bi-arrow-up"></i>';
                } else if (coin.change_percentage_24h < 0) {
                    changeClass = 'text-danger';
                    changeIcon = '<i class="bi bi-arrow-down"></i>';
                }
                
                html += `
                    <tr>
                        <td>${coin.exchange_name}</td>
                        <td>${coin.symbol}</td>
                        <td>${coin.price}</td>
                        <td class="${changeClass}">
                            ${changeIcon} ${coin.change_percentage_24h ? (coin.change_percentage_24h + '%') : '-'}
                        </td>
                        <td>${coin.volume_24h ? coin.volume_24h : '-'}</td>
                        <td>${new Date(coin.timestamp).toLocaleString()}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="viewCoinDetail(${coin.coin_id})">
                                <i class="bi bi-graph-up"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }
        
        $('#coins-table tbody').html(html);
    }

    // 加载异常检测页面
    function loadAnomalies() {
        let html = `
            <h2 class="mb-4">异常检测</h2>
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <select class="form-select" id="anomaly-exchange-filter">
                            <option value="">所有交易所</option>
                        </select>
                        <select class="form-select" id="anomaly-type-filter">
                            <option value="">所有类型</option>
                            <option value="price">价格异常</option>
                            <option value="volume">交易量异常</option>
                            <option value="pattern">模式异常</option>
                        </select>
                        <select class="form-select" id="anomaly-time-filter">
                            <option value="24">24小时内</option>
                            <option value="48">48小时内</option>
                            <option value="168">7天内</option>
                            <option value="720">30天内</option>
                        </select>
                        <button class="btn btn-primary" id="filter-anomalies">
                            <i class="bi bi-filter"></i> 筛选
                        </button>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-secondary" id="refresh-anomalies">
                        <i class="bi bi-arrow-clockwise"></i> 刷新
                    </button>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-exclamation-triangle"></i> 异常记录
                        </div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-hover" id="anomalies-table">
                                    <thead>
                                        <tr>
                                            <th>交易所</th>
                                            <th>币种</th>
                                            <th>类型</th>
                                            <th>当前价格</th>
                                            <th>变化</th>
                                            <th>置信度</th>
                                            <th>时间</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="8" class="text-center">加载中...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="bi bi-pie-chart"></i> 异常类型分布
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="anomaly-type-chart"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-bar-chart"></i> 交易所异常分布
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="anomaly-exchange-chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 异常详情模态框 -->
            <div class="modal fade" id="anomalyDetailModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="anomaly-detail-title">异常详情</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <table class="table">
                                <tr>
                                    <th>交易所</th>
                                    <td id="anomaly-detail-exchange"></td>
                                </tr>
                                <tr>
                                    <th>币种</th>
                                    <td id="anomaly-detail-symbol"></td>
                                </tr>
                                <tr>
                                    <th>类型</th>
                                    <td id="anomaly-detail-type"></td>
                                </tr>
                                <tr>
                                    <th>当前价格</th>
                                    <td id="anomaly-detail-price"></td>
                                </tr>
                                <tr>
                                    <th>参考价格</th>
                                    <td id="anomaly-detail-reference"></td>
                                </tr>
                                <tr>
                                    <th>价格变化</th>
                                    <td id="anomaly-detail-price-change"></td>
                                </tr>
                                <tr>
                                    <th>交易量</th>
                                    <td id="anomaly-detail-volume"></td>
                                </tr>
                                <tr>
                                    <th>交易量变化</th>
                                    <td id="anomaly-detail-volume-change"></td>
                                </tr>
                                <tr>
                                    <th>置信度</th>
                                    <td id="anomaly-detail-confidence"></td>
                                </tr>
                                <tr>
                                    <th>检测算法</th>
                                    <td id="anomaly-detail-algorithm"></td>
                                </tr>
                                <tr>
                                    <th>检测时间</th>
                                    <td id="anomaly-detail-time"></td>
                                </tr>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                            <button type="button" class="btn btn-primary" id="view-coin-from-anomaly">查看币种</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('#page-content').html(html);
        
        // 加载交易所下拉列表
        $.get('/api/exchanges/', function(response) {
            if (response.success) {
                const exchangeOptions = response.data.map(exchange => 
                    `<option value="${exchange.id}">${exchange.name}</option>`
                ).join('');
                
                $('#anomaly-exchange-filter').append(exchangeOptions);
            }
        });
        
        // 加载异常数据
        loadAnomaliesData();
        
        // 绑定事件
        $('#refresh-anomalies').on('click', function() {
            loadAnomaliesData();
        });
        
        $('#filter-anomalies').on('click', function() {
            loadAnomaliesData();
        });
        
        $('#view-coin-from-anomaly').on('click', function() {
            const coinId = $(this).data('coin-id');
            $('#anomalyDetailModal').modal('hide');
            viewCoinDetail(coinId);
        });
    }

    // 加载异常数据
    function loadAnomaliesData() {
        const exchangeId = $('#anomaly-exchange-filter').val();
        const type = $('#anomaly-type-filter').val();
        const hours = $('#anomaly-time-filter').val();
        
        let url = '/api/anomalies/';
        let params = [];
        
        if (exchangeId) {
            params.push(`exchange_id=${exchangeId}`);
        }
        
        if (type) {
            params.push(`type=${type}`);
        }
        
        if (hours) {
            params.push(`hours=${hours}`);
        }
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        $.get(url, function(response) {
            if (response.success) {
                updateAnomaliesTable(response.data);
            }
        });
        
        // 获取异常统计数据
        $.get('/api/anomalies/stats', function(response) {
            if (response.success) {
                createAnomalyTypeChart(response.data.by_type);
                createAnomalyExchangeChart(response.data.by_exchange);
            }
        });
    }

    // 更新异常表
    function updateAnomaliesTable(anomalies) {
        let html = '';
        
        if (anomalies.length === 0) {
            html = '<tr><td colspan="8" class="text-center">暂无数据</td></tr>';
        } else {
            anomalies.forEach(function(anomaly) {
                let typeLabel = '';
                let changeClass = '';
                let confidenceBadge = '';
                
                if (anomaly.type === 'price') {
                    typeLabel = '价格';
                } else if (anomaly.type === 'volume') {
                    typeLabel = '交易量';
                } else {
                    typeLabel = '模式';
                }
                
                if (anomaly.price_change_pct > 0) {
                    changeClass = 'text-success';
                } else {
                    changeClass = 'text-danger';
                }
                
                if (anomaly.confidence_score >= 0.8) {
                    confidenceBadge = '<span class="badge bg-danger">高</span>';
                } else if (anomaly.confidence_score >= 0.5) {
                    confidenceBadge = '<span class="badge bg-warning">中</span>';
                } else {
                    confidenceBadge = '<span class="badge bg-success">低</span>';
                }
                
                html += `
                    <tr>
                        <td>${anomaly.exchange_name}</td>
                        <td>${anomaly.symbol}</td>
                        <td>${typeLabel}</td>
                        <td>${anomaly.current_price}</td>
                        <td class="${changeClass}">${anomaly.price_change_pct ? (anomaly.price_change_pct + '%') : '-'}</td>
                        <td>${confidenceBadge}</td>
                        <td>${new Date(anomaly.detected_at).toLocaleString()}</td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="viewAnomalyDetail(${anomaly.id})">
                                <i class="bi bi-info-circle"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }
        
        $('#anomalies-table tbody').html(html);
    }

    // 创建异常类型图表
    function createAnomalyTypeChart(data) {
        const ctx = document.getElementById('anomaly-type-chart').getContext('2d');
        
        const labels = [];
        const values = [];
        const colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12'];
        
        let i = 0;
        for (const type in data) {
            let label = type;
            
            if (type === 'price') {
                label = '价格异常';
            } else if (type === 'volume') {
                label = '交易量异常';
            } else if (type === 'pattern') {
                label = '模式异常';
            }
            
            labels.push(label);
            values.push(data[type]);
            i++;
        }
        
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colors.slice(0, i),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    // 创建交易所异常图表
    function createAnomalyExchangeChart(data) {
        const ctx = document.getElementById('anomaly-exchange-chart').getContext('2d');
        
        const labels = Object.keys(data);
        const values = Object.values(data);
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: '异常数量',
                    data: values,
                    backgroundColor: 'rgba(52, 152, 219, 0.5)',
                    borderColor: 'rgba(52, 152, 219, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    // 加载系统设置页面
    function loadSettings() {
        let html = `
            <h2 class="mb-4">系统设置</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="bi bi-sliders"></i> 监控参数
                        </div>
                        <div class="card-body">
                            <form id="monitoring-settings-form">
                                <div class="mb-3">
                                    <label for="check-interval" class="form-label">检查间隔（秒）</label>
                                    <input type="number" class="form-control" id="check-interval" min="10">
                                    <div class="form-text">系统检查价格和交易量的时间间隔</div>
                                </div>
                                <div class="mb-3">
                                    <label for="price-threshold" class="form-label">价格异动阈值（%）</label>
                                    <input type="number" class="form-control" id="price-threshold" min="0" step="0.1">
                                    <div class="form-text">触发价格异常警报的最小百分比变化</div>
                                </div>
                                <div class="mb-3">
                                    <label for="volume-threshold" class="form-label">交易量异动阈值（%）</label>
                                    <input type="number" class="form-control" id="volume-threshold" min="0" step="0.1">
                                    <div class="form-text">触发交易量异常警报的最小百分比变化</div>
                                </div>
                                <div class="mb-3">
                                    <label for="data-retention" class="form-label">数据保留天数</label>
                                    <input type="number" class="form-control" id="data-retention" min="1">
                                    <div class="form-text">历史价格和异常数据的保留时间</div>
                                </div>
                                <button type="button" class="btn btn-primary" id="save-monitoring-settings">保存设置</button>
                            </form>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-bell"></i> 通知设置
                        </div>
                        <div class="card-body">
                            <form id="notification-settings-form">
                                <div class="mb-3">
                                    <label for="max-alerts" class="form-label">每批最大警报数</label>
                                    <input type="number" class="form-control" id="max-alerts" min="1">
                                    <div class="form-text">每次发送的最大警报数量</div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="enable-telegram">
                                    <label class="form-check-label" for="enable-telegram">启用Telegram通知</label>
                                </div>
                                <div class="mb-3">
                                    <label for="telegram-token" class="form-label">Telegram Bot Token</label>
                                    <input type="text" class="form-control" id="telegram-token">
                                </div>
                                <div class="mb-3">
                                    <label for="telegram-chat-id" class="form-label">Telegram Chat ID</label>
                                    <input type="text" class="form-control" id="telegram-chat-id">
                                </div>
                                <button type="button" class="btn btn-primary" id="save-notification-settings">保存设置</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="bi bi-gear-wide-connected"></i> 高级设置
                        </div>
                        <div class="card-body">
                            <form id="advanced-settings-form">
                                <div class="mb-3">
                                    <label for="excluded-symbols" class="form-label">排除的币种</label>
                                    <textarea class="form-control" id="excluded-symbols" rows="3"></textarea>
                                    <div class="form-text">不监控的币种，每行一个，例如 BTC_USDT</div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="use-binance-testnet">
                                    <label class="form-check-label" for="use-binance-testnet">使用币安测试网</label>
                                </div>
                                <div class="mb-3">
                                    <label for="proxy-url" class="form-label">代理服务器URL</label>
                                    <input type="text" class="form-control" id="proxy-url">
                                    <div class="form-text">格式: http://host:port</div>
                                </div>
                                <div class="mb-3">
                                    <label for="coingecko-api-key" class="form-label">CoinGecko API密钥</label>
                                    <input type="text" class="form-control" id="coingecko-api-key">
                                    <div class="form-text">可选，用于提高API请求限制</div>
                                </div>
                                <button type="button" class="btn btn-primary" id="save-advanced-settings">保存设置</button>
                            </form>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-braces"></i> 异常检测算法设置
                        </div>
                        <div class="card-body">
                            <form id="algorithm-settings-form">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="enable-advanced-detection">
                                    <label class="form-check-label" for="enable-advanced-detection">启用高级异常检测</label>
                                </div>
                                <div class="mb-3">
                                    <label for="detection-sensitivity" class="form-label">检测灵敏度</label>
                                    <select class="form-select" id="detection-sensitivity">
                                        <option value="low">低（减少误报）</option>
                                        <option value="medium">中（平衡）</option>
                                        <option value="high">高（减少漏报）</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="analysis-window" class="form-label">分析窗口（小时）</label>
                                    <input type="number" class="form-control" id="analysis-window" min="1">
                                    <div class="form-text">用于模式分析的历史数据时间窗口</div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="enable-cross-exchange">
                                    <label class="form-check-label" for="enable-cross-exchange">启用交叉交易所验证</label>
                                </div>
                                <button type="button" class="btn btn-primary" id="save-algorithm-settings">保存设置</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('#page-content').html(html);
        
        // 加载设置数据
        loadSettingsData();
        
        // 绑定事件
        $('#save-monitoring-settings').on('click', function() {
            saveMonitoringSettings();
        });
        
        $('#save-notification-settings').on('click', function() {
            saveNotificationSettings();
        });
        
        $('#save-advanced-settings').on('click', function() {
            saveAdvancedSettings();
        });
        
        $('#save-algorithm-settings').on('click', function() {
            saveAlgorithmSettings();
        });
    }

    // 加载设置数据
    function loadSettingsData() {
        $.get('/api/config/', function(response) {
            if (response.success) {
                const configs = response.data;
                
                // 填充表单
                configs.forEach(function(config) {
                    switch(config.key) {
                        case 'check_interval':
                            $('#check-interval').val(config.value);
                            break;
                        case 'price_threshold':
                            $('#price-threshold').val(config.value);
                            break;
                        case 'volume_threshold':
                            $('#volume-threshold').val(config.value);
                            break;
                        case 'data_retention_days':
                            $('#data-retention').val(config.value);
                            break;
                        case 'max_alerts_per_batch':
                            $('#max-alerts').val(config.value);
                            break;
                        case 'enable_telegram':
                            $('#enable-telegram').prop('checked', config.value === 'true');
                            break;
                        case 'telegram_token':
                            $('#telegram-token').val(config.value);
                            break;
                        case 'telegram_chat_id':
                            $('#telegram-chat-id').val(config.value);
                            break;
                        case 'excluded_symbols':
                            $('#excluded-symbols').val(config.value);
                            break;
                        case 'use_binance_testnet':
                            $('#use-binance-testnet').prop('checked', config.value === 'true');
                            break;
                        case 'proxy':
                            $('#proxy-url').val(config.value);
                            break;
                        case 'coingecko_api_key':
                            $('#coingecko-api-key').val(config.value);
                            break;
                        case 'enable_advanced_detection':
                            $('#enable-advanced-detection').prop('checked', config.value === 'true');
                            break;
                        case 'detection_sensitivity':
                            $('#detection-sensitivity').val(config.value);
                            break;
                        case 'analysis_window':
                            $('#analysis-window').val(config.value);
                            break;
                        case 'enable_cross_exchange':
                            $('#enable-cross-exchange').prop('checked', config.value === 'true');
                            break;
                    }
                });
            }
        });
    }

    // 保存监控设置
    function saveMonitoringSettings() {
        const data = {
            check_interval: $('#check-interval').val(),
            price_threshold: $('#price-threshold').val(),
            volume_threshold: $('#volume-threshold').val(),
            data_retention_days: $('#data-retention').val()
        };
        
        $.ajax({
            url: '/api/config/batch',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                if (response.success) {
                    alert('监控设置保存成功');
                } else {
                    alert('保存失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('保存失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }

    // 保存通知设置
    function saveNotificationSettings() {
        const data = {
            max_alerts_per_batch: $('#max-alerts').val(),
            enable_telegram: $('#enable-telegram').prop('checked').toString(),
            telegram_token: $('#telegram-token').val(),
            telegram_chat_id: $('#telegram-chat-id').val()
        };
        
        $.ajax({
            url: '/api/config/batch',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                if (response.success) {
                    alert('通知设置保存成功');
                } else {
                    alert('保存失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('保存失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }

    // 保存高级设置
    function saveAdvancedSettings() {
        const data = {
            excluded_symbols: $('#excluded-symbols').val(),
            use_binance_testnet: $('#use-binance-testnet').prop('checked').toString(),
            proxy: $('#proxy-url').val(),
            coingecko_api_key: $('#coingecko-api-key').val()
        };
        
        $.ajax({
            url: '/api/config/batch',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                if (response.success) {
                    alert('高级设置保存成功');
                } else {
                    alert('保存失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('保存失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }

    // 保存算法设置
    function saveAlgorithmSettings() {
        const data = {
            enable_advanced_detection: $('#enable-advanced-detection').prop('checked').toString(),
            detection_sensitivity: $('#detection-sensitivity').val(),
            analysis_window: $('#analysis-window').val(),
            enable_cross_exchange: $('#enable-cross-exchange').prop('checked').toString()
        };
        
        $.ajax({
            url: '/api/config/batch',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(response) {
                if (response.success) {
                    alert('算法设置保存成功');
                } else {
                    alert('保存失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('保存失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }
});

// 全局函数

// 查看币种详情
function viewCoinDetail(coinId) {
    // 获取币种基本信息
    $.get(`/api/coins/${coinId}`, function(response) {
        if (response.success) {
            const coin = response.data;
            
            // 获取最新价格数据
            $.get(`/api/coins/price?coin_id=${coinId}`, function(priceResponse) {
                if (priceResponse.success && priceResponse.data.length > 0) {
                    const priceData = priceResponse.data[0];
                    
                    // 更新模态框标题和基本信息
                    $('#coin-detail-title').text(`${coin.symbol} (${coin.exchange_name})`);
                    $('#detail-exchange').text(coin.exchange_name);
                    $('#detail-symbol').text(coin.symbol);
                    $('#detail-price').text(priceData.price);
                    
                    let changeClass = '';
                    if (priceData.change_percentage_24h > 0) {
                        changeClass = 'text-success';
                    } else if (priceData.change_percentage_24h < 0) {
                        changeClass = 'text-danger';
                    }
                    
                    $('#detail-change').text(priceData.change_percentage_24h + '%').addClass(changeClass);
                    $('#detail-volume').text(priceData.volume_24h);
                    $('#detail-high').text(priceData.high_24h);
                    $('#detail-low').text(priceData.low_24h);
                    
                    // 获取价格历史数据
                    $.get(`/api/coins/price/history?coin_id=${coinId}&hours=24`, function(historyResponse) {
                        if (historyResponse.success) {
                            createPriceHistoryChart(historyResponse.data);
                        }
                    });
                    
                    // 获取币种异常记录
                    $.get(`/api/anomalies/?coin_id=${coinId}&hours=168`, function(anomalyResponse) {
                        if (anomalyResponse.success) {
                            updateCoinAnomaliesTable(anomalyResponse.data);
                        }
                    });
                    
                    // 显示模态框
                    $('#coinDetailModal').modal('show');
                }
            });
        }
    });
}

// 创建价格历史图表
function createPriceHistoryChart(data) {
    const ctx = document.getElementById('price-history-chart').getContext('2d');
    
    // 准备数据
    const timestamps = data.map(item => new Date(item.timestamp));
    const prices = data.map(item => item.price);
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: timestamps,
            datasets: [{
                label: '价格',
                data: prices,
                backgroundColor: 'rgba(52, 152, 219, 0.2)',
                borderColor: 'rgba(52, 152, 219, 1)',
                borderWidth: 2,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'hour'
                    }
                }
            }
        }
    });
}

// 更新币种异常表
function updateCoinAnomaliesTable(anomalies) {
    let html = '';
    
    if (anomalies.length === 0) {
        html = '<tr><td colspan="5" class="text-center">暂无数据</td></tr>';
    } else {
        anomalies.forEach(function(anomaly) {
            let typeLabel = '';
            let changeClass = '';
            
            if (anomaly.type === 'price') {
                typeLabel = '价格';
            } else if (anomaly.type === 'volume') {
                typeLabel = '交易量';
            } else {
                typeLabel = '模式';
            }
            
            if (anomaly.price_change_pct > 0) {
                changeClass = 'text-success';
            } else {
                changeClass = 'text-danger';
            }
            
            html += `
                <tr>
                    <td>${typeLabel}</td>
                    <td>${anomaly.current_price}</td>
                    <td class="${changeClass}">${anomaly.price_change_pct ? (anomaly.price_change_pct + '%') : '-'}</td>
                    <td>${new Date(anomaly.detected_at).toLocaleString()}</td>
                    <td>${anomaly.algorithm || '-'}</td>
                </tr>
            `;
        });
    }
    
    $('#coin-anomalies tbody').html(html);
}

// 查看异常详情
function viewAnomalyDetail(anomalyId) {
    $.get(`/api/anomalies/${anomalyId}`, function(response) {
        if (response.success) {
            const anomaly = response.data;
            
            // 更新模态框内容
            $('#anomaly-detail-title').text(`异常详情 #${anomaly.id}`);
            $('#anomaly-detail-exchange').text(anomaly.exchange_name);
            $('#anomaly-detail-symbol').text(anomaly.symbol);
            
            let typeLabel = '';
            if (anomaly.type === 'price') {
                typeLabel = '价格异常';
            } else if (anomaly.type === 'volume') {
                typeLabel = '交易量异常';
            } else {
                typeLabel = '模式异常';
            }
            $('#anomaly-detail-type').text(typeLabel);
            
            $('#anomaly-detail-price').text(anomaly.current_price);
            $('#anomaly-detail-reference').text(anomaly.reference_price || '-');
            
            let changeClass = '';
            if (anomaly.price_change_pct > 0) {
                changeClass = 'text-success';
            } else {
                changeClass = 'text-danger';
            }
            $('#anomaly-detail-price-change').text(anomaly.price_change_pct ? (anomaly.price_change_pct + '%') : '-').addClass(changeClass);
            
            $('#anomaly-detail-volume').text(anomaly.volume_24h || '-');
            $('#anomaly-detail-volume-change').text(anomaly.volume_change_pct ? (anomaly.volume_change_pct + '%') : '-');
            $('#anomaly-detail-confidence').text((anomaly.confidence_score * 100).toFixed(1) + '%');
            $('#anomaly-detail-algorithm').text(anomaly.algorithm || '基础阈值检测');
            $('#anomaly-detail-time').text(new Date(anomaly.detected_at).toLocaleString());
            
            // 设置查看币种按钮的数据
            $('#view-coin-from-anomaly').data('coin-id', anomaly.coin_id);
            
            // 显示模态框
            $('#anomalyDetailModal').modal('show');
        }
    });
}

// 刷新交易所
function refreshExchange(exchangeId) {
    // 这里应该调用后端API来刷新交易所数据
    alert(`刷新交易所 ${exchangeId} 的数据`);
}

// 编辑交易所
function editExchange(exchangeId) {
    // 这里应该打开编辑交易所的模态框
    alert(`编辑交易所 ${exchangeId}`);
}

// 删除交易所
function deleteExchange(exchangeId) {
    if (confirm(`确定要删除交易所 ${exchangeId} 吗？`)) {
        $.ajax({
            url: `/api/exchanges/${exchangeId}`,
            type: 'DELETE',
            success: function(response) {
                if (response.success) {
                    alert('交易所删除成功');
                    // 重新加载交易所数据
                    loadExchangesData();
                } else {
                    alert('删除失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('删除失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }
}

// 切换交易所启用状态
function toggleExchange(exchangeId, enabled) {
    $.ajax({
        url: `/api/exchanges/${exchangeId}`,
        type: 'PUT',
        contentType: 'application/json',
        data: JSON.stringify({
            is_enabled: enabled
        }),
        success: function(response) {
            if (!response.success) {
                alert('更新失败: ' + response.message);
                // 恢复原始状态
                $(`#exchange-enabled-${exchangeId}`).prop('checked', !enabled);
            }
        },
        error: function(xhr) {
            alert('更新失败: ' + xhr.responseJSON?.message || '未知错误');
            // 恢复原始状态
            $(`#exchange-enabled-${exchangeId}`).prop('checked', !enabled);
        }
    });
}

// 编辑备用数据源映射
function editFallback(fallbackId) {
    // 这里应该打开编辑备用数据源映射的模态框
    alert(`编辑备用数据源映射 ${fallbackId}`);
}

// 删除备用数据源映射
function deleteFallback(fallbackId) {
    if (confirm(`确定要删除备用数据源映射 ${fallbackId} 吗？`)) {
        $.ajax({
            url: `/api/exchanges/fallback/${fallbackId}`,
            type: 'DELETE',
            success: function(response) {
                if (response.success) {
                    alert('备用数据源映射删除成功');
                    // 重新加载备用数据源映射数据
                    loadExchangesData();
                } else {
                    alert('删除失败: ' + response.message);
                }
            },
            error: function(xhr) {
                alert('删除失败: ' + xhr.responseJSON?.message || '未知错误');
            }
        });
    }
}

// 切换备用数据源映射启用状态
function toggleFallback(fallbackId, enabled) {
    $.ajax({
        url: `/api/exchanges/fallback/${fallbackId}`,
        type: 'PUT',
        contentType: 'application/json',
        data: JSON.stringify({
            is_enabled: enabled
        }),
        success: function(response) {
            if (!response.success) {
                alert('更新失败: ' + response.message);
                // 恢复原始状态
                $(`#fallback-enabled-${fallbackId}`).prop('checked', !enabled);
            }
        },
        error: function(xhr) {
            alert('更新失败: ' + xhr.responseJSON?.message || '未知错误');
            // 恢复原始状态
            $(`#fallback-enabled-${fallbackId}`).prop('checked', !enabled);
        }
    });
}
