"""
加密货币监控系统API路由 - 币种和价格数据
"""

from flask import Blueprint, jsonify, request
from src.models.crypto import db, Coin, PriceData, Exchange
from datetime import datetime, timedelta
import json

coin_bp = Blueprint('coin', __name__)

@coin_bp.route('/', methods=['GET'])
def get_all_coins():
    """获取所有币种信息"""
    # 支持按交易所过滤
    exchange_id = request.args.get('exchange_id')
    
    query = Coin.query
    if exchange_id:
        query = query.filter_by(exchange_id=exchange_id)
    
    coins = query.all()
    return jsonify({
        "success": True,
        "data": [coin.to_dict() for coin in coins]
    }), 200

@coin_bp.route('/<int:coin_id>', methods=['GET'])
def get_coin(coin_id):
    """获取特定币种信息"""
    coin = Coin.query.get(coin_id)
    if not coin:
        return jsonify({
            "success": False,
            "message": f"币种ID {coin_id} 不存在"
        }), 404
    
    return jsonify({
        "success": True,
        "data": coin.to_dict()
    }), 200

@coin_bp.route('/symbol/<symbol>', methods=['GET'])
def get_coin_by_symbol(symbol):
    """根据符号获取币种信息"""
    # 支持按交易所过滤
    exchange_id = request.args.get('exchange_id')
    
    query = Coin.query.filter_by(symbol=symbol)
    if exchange_id:
        query = query.filter_by(exchange_id=exchange_id)
    
    coins = query.all()
    if not coins:
        return jsonify({
            "success": False,
            "message": f"币种 {symbol} 不存在"
        }), 404
    
    return jsonify({
        "success": True,
        "data": [coin.to_dict() for coin in coins]
    }), 200

@coin_bp.route('/', methods=['POST'])
def create_coin():
    """创建新币种"""
    data = request.json
    
    # 验证必要字段
    if not data or not data.get('exchange_id') or not data.get('symbol'):
        return jsonify({
            "success": False,
            "message": "缺少必要字段: exchange_id, symbol"
        }), 400
    
    # 检查交易所是否存在
    exchange = Exchange.query.get(data['exchange_id'])
    if not exchange:
        return jsonify({
            "success": False,
            "message": f"交易所 {data['exchange_id']} 不存在"
        }), 404
    
    # 检查币种是否已存在
    existing_coin = Coin.query.filter_by(
        exchange_id=data['exchange_id'],
        symbol=data['symbol']
    ).first()
    
    if existing_coin:
        return jsonify({
            "success": False,
            "message": f"币种 {data['symbol']} 在交易所 {data['exchange_id']} 中已存在"
        }), 409
    
    # 创建新币种
    new_coin = Coin(
        exchange_id=data['exchange_id'],
        symbol=data['symbol'],
        name=data.get('name'),
        last_updated=datetime.now()
    )
    
    try:
        db.session.add(new_coin)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "币种创建成功",
            "data": new_coin.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"创建币种失败: {str(e)}"
        }), 500

@coin_bp.route('/<int:coin_id>', methods=['PUT'])
def update_coin(coin_id):
    """更新币种信息"""
    coin = Coin.query.get(coin_id)
    if not coin:
        return jsonify({
            "success": False,
            "message": f"币种ID {coin_id} 不存在"
        }), 404
    
    data = request.json
    if not data:
        return jsonify({
            "success": False,
            "message": "未提供更新数据"
        }), 400
    
    # 更新字段
    if 'name' in data:
        coin.name = data['name']
    
    coin.last_updated = datetime.now()
    
    try:
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "币种更新成功",
            "data": coin.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"更新币种失败: {str(e)}"
        }), 500

@coin_bp.route('/<int:coin_id>', methods=['DELETE'])
def delete_coin(coin_id):
    """删除币种"""
    coin = Coin.query.get(coin_id)
    if not coin:
        return jsonify({
            "success": False,
            "message": f"币种ID {coin_id} 不存在"
        }), 404
    
    try:
        # 删除相关的价格数据
        PriceData.query.filter_by(coin_id=coin_id).delete()
        
        # 删除币种
        db.session.delete(coin)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"币种ID {coin_id} 已删除"
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"删除币种失败: {str(e)}"
        }), 500

@coin_bp.route('/price', methods=['GET'])
def get_latest_prices():
    """获取最新价格数据"""
    # 支持按交易所和币种过滤
    exchange_id = request.args.get('exchange_id')
    symbol = request.args.get('symbol')
    
    # 构建子查询，获取每个币种的最新价格数据ID
    subquery = db.session.query(
        PriceData.coin_id,
        db.func.max(PriceData.timestamp).label('max_timestamp')
    ).group_by(PriceData.coin_id).subquery()
    
    # 构建主查询，关联币种和价格数据
    query = db.session.query(PriceData, Coin).join(
        subquery,
        db.and_(
            PriceData.coin_id == subquery.c.coin_id,
            PriceData.timestamp == subquery.c.max_timestamp
        )
    ).join(Coin, PriceData.coin_id == Coin.id)
    
    # 应用过滤条件
    if exchange_id:
        query = query.filter(Coin.exchange_id == exchange_id)
    if symbol:
        query = query.filter(Coin.symbol == symbol)
    
    results = query.all()
    
    # 格式化结果
    data = []
    for price_data, coin in results:
        item = price_data.to_dict()
        item.update({
            "exchange_id": coin.exchange_id,
            "exchange_name": coin.exchange.name if coin.exchange else None,
            "symbol": coin.symbol
        })
        data.append(item)
    
    return jsonify({
        "success": True,
        "data": data
    }), 200

@coin_bp.route('/price/history', methods=['GET'])
def get_price_history():
    """获取价格历史数据"""
    # 必要参数：币种ID
    coin_id = request.args.get('coin_id')
    if not coin_id:
        return jsonify({
            "success": False,
            "message": "缺少必要参数: coin_id"
        }), 400
    
    # 可选参数：时间范围
    hours = request.args.get('hours', type=int)
    days = request.args.get('days', type=int)
    
    # 构建查询
    query = PriceData.query.filter_by(coin_id=coin_id)
    
    # 应用时间过滤
    if hours:
        start_time = datetime.now() - timedelta(hours=hours)
        query = query.filter(PriceData.timestamp >= start_time)
    elif days:
        start_time = datetime.now() - timedelta(days=days)
        query = query.filter(PriceData.timestamp >= start_time)
    
    # 按时间排序
    query = query.order_by(PriceData.timestamp.asc())
    
    # 执行查询
    price_data = query.all()
    
    return jsonify({
        "success": True,
        "data": [item.to_dict() for item in price_data]
    }), 200

@coin_bp.route('/price', methods=['POST'])
def add_price_data():
    """添加价格数据"""
    data = request.json
    
    # 验证必要字段
    if not data or not data.get('coin_id') or 'price' not in data:
        return jsonify({
            "success": False,
            "message": "缺少必要字段: coin_id, price"
        }), 400
    
    # 检查币种是否存在
    coin = Coin.query.get(data['coin_id'])
    if not coin:
        return jsonify({
            "success": False,
            "message": f"币种ID {data['coin_id']} 不存在"
        }), 404
    
    # 创建价格数据
    new_price_data = PriceData(
        coin_id=data['coin_id'],
        price=data['price'],
        volume_24h=data.get('volume_24h'),
        change_percentage_24h=data.get('change_percentage_24h'),
        high_24h=data.get('high_24h'),
        low_24h=data.get('low_24h'),
        timestamp=datetime.now()
    )
    
    try:
        db.session.add(new_price_data)
        db.session.commit()
        
        # 更新币种的最后更新时间
        coin.last_updated = datetime.now()
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "价格数据添加成功",
            "data": new_price_data.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"添加价格数据失败: {str(e)}"
        }), 500

@coin_bp.route('/price/batch', methods=['POST'])
def add_batch_price_data():
    """批量添加价格数据"""
    data = request.json
    
    if not data or not isinstance(data, list) or len(data) == 0:
        return jsonify({
            "success": False,
            "message": "请提供有效的价格数据列表"
        }), 400
    
    success_count = 0
    failed_items = []
    
    for item in data:
        # 验证必要字段
        if not item.get('coin_id') or 'price' not in item:
            failed_items.append({
                "item": item,
                "reason": "缺少必要字段: coin_id, price"
            })
            continue
        
        # 检查币种是否存在
        coin = Coin.query.get(item['coin_id'])
        if not coin:
            failed_items.append({
                "item": item,
                "reason": f"币种ID {item['coin_id']} 不存在"
            })
            continue
        
        # 创建价格数据
        new_price_data = PriceData(
            coin_id=item['coin_id'],
            price=item['price'],
            volume_24h=item.get('volume_24h'),
            change_percentage_24h=item.get('change_percentage_24h'),
            high_24h=item.get('high_24h'),
            low_24h=item.get('low_24h'),
            timestamp=datetime.now()
        )
        
        try:
            db.session.add(new_price_data)
            
            # 更新币种的最后更新时间
            coin.last_updated = datetime.now()
            
            success_count += 1
        except Exception as e:
            failed_items.append({
                "item": item,
                "reason": str(e)
            })
    
    # 提交事务
    try:
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"成功添加 {success_count} 条价格数据，失败 {len(failed_items)} 条",
            "failed_items": failed_items
        }), 201 if success_count > 0 else 400
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"批量添加价格数据失败: {str(e)}"
        }), 500
