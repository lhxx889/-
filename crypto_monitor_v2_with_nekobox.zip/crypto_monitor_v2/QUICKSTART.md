# 加密货币监控系统 v2.0 - 快速开始指南

## 🚀 快速启动

### 1. 安装依赖
```bash
cd crypto_monitor_v2
pip install -r requirements.txt
```

### 2. 启动Web界面
```bash
python main.py
```
然后访问 http://localhost:5000

### 3. 命令行使用
```bash
# 查看系统状态
python cli.py status

# 手动价格检查
python cli.py price-check

# 手动公告扫描
python cli.py announcement-scan

# 启动监控（命令行模式）
python cli.py start
```

## 📋 主要功能

### ✨ 核心特性
- **多交易所监控**: 支持 Binance.US 和 Gate.io
- **实时价格监控**: 可自定义阈值的价格变动监控
- **公告扫描**: 自动扫描新上币和重要公告
- **智能通知**: Telegram 和邮件通知支持
- **Web管理界面**: 现代化的实时监控界面
- **数据存储**: SQLite数据库，支持历史数据查询

### 🔧 技术改进
- **模块化架构**: 清晰的代码结构，易于维护
- **RESTful API**: 完整的API接口
- **配置管理**: 灵活的配置系统
- **错误处理**: 完善的错误处理和恢复机制
- **代理支持**: SOCKS5代理支持

## 🎛️ Web界面功能

### 主页
- 系统状态概览
- 监控组件状态
- 快速操作按钮

### 仪表板
- 实时数据展示
- 价格变动历史
- 公告列表
- 新上币信息

### 设置页面
- 监控参数配置
- 交易所开关
- Telegram通知设置

## 📊 API接口

### 监控控制
- `POST /api/monitor/start` - 启动监控
- `POST /api/monitor/stop` - 停止监控
- `POST /api/monitor/price-check` - 手动价格检查
- `POST /api/monitor/announcement-scan` - 手动公告扫描

### 数据查询
- `GET /api/status` - 获取系统状态
- `GET /api/statistics` - 获取统计信息
- `GET /api/price-changes` - 获取价格变动记录
- `GET /api/announcements` - 获取公告记录

## ⚙️ 配置说明

配置文件位于 `config/config.json`：

```json
{
  "price_change_threshold": 5.0,
  "price_check_interval": 300,
  "announcement_scan_interval": 3600,
  "exchanges": {
    "binance": {"enabled": true},
    "gate": {"enabled": true}
  },
  "notifications": {
    "telegram": {
      "enabled": false,
      "bot_token": "YOUR_BOT_TOKEN",
      "chat_id": "YOUR_CHAT_ID"
    }
  }
}
```

## 🔄 与原版本对比

### 架构改进
- ✅ 模块化设计，代码结构清晰
- ✅ SQLite数据库替代JSON文件
- ✅ Web界面管理，无需命令行操作
- ✅ RESTful API，支持第三方集成

### 功能增强
- ✅ 实时监控界面
- ✅ 在线配置管理
- ✅ 更完善的错误处理
- ✅ 结构化日志记录

### 性能优化
- ✅ 异步处理
- ✅ 数据库索引优化
- ✅ 缓存机制

## 🛠️ 故障排除

### 常见问题
1. **Web界面无法访问**: 检查端口5000是否被占用
2. **API请求失败**: 确认网络连接和代理设置
3. **Telegram通知失败**: 验证Bot Token和Chat ID

### 日志查看
```bash
# 查看系统日志
tail -f logs/crypto_monitor.log
```

## 📞 技术支持

如遇问题，请：
1. 查看日志文件
2. 检查配置文件
3. 运行系统测试：`python test_system.py`

---

**版本**: v2.0  
**基于**: crypto_monitor_enhanced_v1.2_final  
**开发时间**: 2024-06-09

