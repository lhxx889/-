#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
简单测试脚本
验证系统基本功能
"""

import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

def test_config():
    """测试配置模块"""
    print("测试配置模块...")
    try:
        from app.core.config import Config
        config = Config()
        print(f"✅ 配置加载成功")
        print(f"   价格阈值: {config.price_change_threshold}%")
        print(f"   Web端口: {config.web_port}")
        return True
    except Exception as e:
        print(f"❌ 配置模块测试失败: {e}")
        return False

def test_database():
    """测试数据库模块"""
    print("\\n测试数据库模块...")
    try:
        from app.core.config import Config
        from app.core.database import Database
        
        config = Config()
        db = Database(config.database_path)
        db.init_database()
        
        # 测试统计功能
        stats = db.get_statistics()
        print(f"✅ 数据库连接成功")
        print(f"   总价格变动: {stats['total_price_changes']}")
        print(f"   总公告数: {stats['total_announcements']}")
        return True
    except Exception as e:
        print(f"❌ 数据库模块测试失败: {e}")
        return False

def test_api_client():
    """测试API客户端模块"""
    print("\\n测试API客户端模块...")
    try:
        from app.core.config import Config
        from app.core.api_client import ExchangeAPIManager
        
        config = Config()
        api_manager = ExchangeAPIManager(config)
        
        print("✅ API客户端初始化成功")
        print(f"   支持的交易所: {list(api_manager.clients.keys())}")
        return True
    except Exception as e:
        print(f"❌ API客户端模块测试失败: {e}")
        return False

def test_monitor():
    """测试监控模块"""
    print("\\n测试监控模块...")
    try:
        from app.core.config import Config
        from app.core.database import Database
        from app.core.monitor import CryptoMonitor
        
        config = Config()
        db = Database(config.database_path)
        monitor = CryptoMonitor(config, db)
        
        status = monitor.get_status()
        print("✅ 监控模块初始化成功")
        print(f"   运行状态: {status['is_running']}")
        return True
    except Exception as e:
        print(f"❌ 监控模块测试失败: {e}")
        return False

def test_web_app():
    """测试Web应用模块"""
    print("\\n测试Web应用模块...")
    try:
        from app.core.config import Config
        from app.core.database import Database
        from app.core.monitor import CryptoMonitor
        from app.web.app import create_app
        
        config = Config()
        db = Database(config.database_path)
        monitor = CryptoMonitor(config, db)
        app = create_app(config, monitor)
        
        print("✅ Web应用创建成功")
        print(f"   应用名称: {app.name}")
        return True
    except Exception as e:
        print(f"❌ Web应用模块测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("🚀 开始系统测试...")
    print("=" * 50)
    
    tests = [
        test_config,
        test_database,
        test_api_client,
        test_monitor,
        test_web_app
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print("\\n" + "=" * 50)
    print(f"📊 测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有测试通过！系统运行正常。")
        return 0
    else:
        print("⚠️  部分测试失败，请检查错误信息。")
        return 1

if __name__ == "__main__":
    sys.exit(main())

