#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Nekobox代理管理模块
提供Nekobox代理检测和配置功能
"""

import socket
import requests
import logging
from typing import Dict, Optional, List, Tuple

logger = logging.getLogger(__name__)

class NekoboxProxyManager:
    """Nekobox代理管理器"""
    
    # 常见的Nekobox端口
    COMMON_PORTS = [7890, 7891, 7892, 1080, 8080, 10808, 10809]
    
    def __init__(self):
        self.detected_proxies = []
        self.current_proxy = None
        
    def is_port_open(self, host: str, port: int, timeout: float = 3.0) -> bool:
        """检测端口是否开放"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                result = sock.connect_ex((host, port))
                return result == 0
        except Exception as e:
            logger.debug(f"端口检测失败 {host}:{port} - {e}")
            return False
    
    def detect_proxy_type(self, host: str, port: int) -> Optional[str]:
        """检测代理类型"""
        # 测试SOCKS5代理
        try:
            proxies = {
                'http': f'socks5://{host}:{port}',
                'https': f'socks5://{host}:{port}'
            }
            response = requests.get(
                'http://httpbin.org/ip', 
                proxies=proxies, 
                timeout=5
            )
            if response.status_code == 200:
                return 'socks5'
        except:
            pass
        
        # 测试HTTP代理
        try:
            proxies = {
                'http': f'http://{host}:{port}',
                'https': f'http://{host}:{port}'
            }
            response = requests.get(
                'http://httpbin.org/ip', 
                proxies=proxies, 
                timeout=5
            )
            if response.status_code == 200:
                return 'http'
        except:
            pass
        
        return None
    
    def detect_nekobox_proxies(self) -> List[Dict]:
        """检测Nekobox代理端口"""
        detected = []
        
        for port in self.COMMON_PORTS:
            if self.is_port_open('127.0.0.1', port):
                proxy_type = self.detect_proxy_type('127.0.0.1', port)
                if proxy_type:
                    proxy_info = {
                        'host': '127.0.0.1',
                        'port': port,
                        'type': proxy_type,
                        'url': f'{proxy_type}://127.0.0.1:{port}',
                        'status': 'active'
                    }
                    detected.append(proxy_info)
                    logger.info(f"检测到Nekobox代理: {proxy_type}://127.0.0.1:{port}")
        
        self.detected_proxies = detected
        return detected
    
    def test_proxy_connection(self, proxy_url: str) -> Dict:
        """测试代理连接"""
        try:
            proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
            
            # 测试连接
            response = requests.get(
                'http://httpbin.org/ip', 
                proxies=proxies, 
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'ip': data.get('origin', 'Unknown'),
                    'message': '代理连接成功'
                }
            else:
                return {
                    'success': False,
                    'message': f'HTTP错误: {response.status_code}'
                }
                
        except requests.exceptions.ProxyError as e:
            return {
                'success': False,
                'message': f'代理连接失败: {str(e)}'
            }
        except requests.exceptions.Timeout:
            return {
                'success': False,
                'message': '连接超时'
            }
        except Exception as e:
            return {
                'success': False,
                'message': f'未知错误: {str(e)}'
            }
    
    def get_proxy_config(self, auto_detect: bool = True, manual_config: Optional[Dict] = None) -> Optional[Dict]:
        """获取代理配置"""
        if auto_detect:
            # 自动检测模式
            proxies = self.detect_nekobox_proxies()
            if proxies:
                # 优先使用SOCKS5代理
                socks5_proxies = [p for p in proxies if p['type'] == 'socks5']
                if socks5_proxies:
                    best_proxy = socks5_proxies[0]
                else:
                    best_proxy = proxies[0]
                
                self.current_proxy = best_proxy
                return {
                    'http': best_proxy['url'],
                    'https': best_proxy['url']
                }
        
        elif manual_config:
            # 手动配置模式
            host = manual_config.get('host', '127.0.0.1')
            port = manual_config.get('port', 7890)
            protocol = manual_config.get('protocol', 'socks5')
            
            proxy_url = f"{protocol}://{host}:{port}"
            
            # 测试手动配置的代理
            test_result = self.test_proxy_connection(proxy_url)
            if test_result['success']:
                self.current_proxy = {
                    'host': host,
                    'port': port,
                    'type': protocol,
                    'url': proxy_url,
                    'status': 'active'
                }
                return {
                    'http': proxy_url,
                    'https': proxy_url
                }
            else:
                logger.warning(f"手动配置的代理测试失败: {test_result['message']}")
        
        return None
    
    def get_status(self) -> Dict:
        """获取Nekobox代理状态"""
        return {
            'detected_proxies': self.detected_proxies,
            'current_proxy': self.current_proxy,
            'total_detected': len(self.detected_proxies)
        }
    
    def refresh_detection(self) -> Dict:
        """刷新代理检测"""
        logger.info("刷新Nekobox代理检测...")
        proxies = self.detect_nekobox_proxies()
        return {
            'success': True,
            'detected_count': len(proxies),
            'proxies': proxies
        }

