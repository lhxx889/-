#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
API客户端模块
负责与各交易所API交互
"""

import requests
import logging
import hashlib
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup

class APIClient:
    """API客户端基类"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.session = requests.Session()
        
        # 设置通用请求头
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json',
            'Accept-Language': 'en-US,en;q=0.9',
        })
        
        # 设置代理
        self._setup_proxy()
    
    def _setup_proxy(self):
        """设置代理配置"""
        if self.config.proxy_enabled:
            if self.config.proxy_type == 'nekobox' and self.config.nekobox_enabled:
                # 使用Nekobox代理
                from .nekobox_proxy import NekoboxProxyManager
                nekobox_manager = NekoboxProxyManager()
                nekobox_config = self.config.nekobox_config
                
                proxy_config = nekobox_manager.get_proxy_config(
                    auto_detect=nekobox_config.get('auto_detect', True),
                    manual_config=nekobox_config.get('manual_config') if not nekobox_config.get('auto_detect', True) else None
                )
                
                if proxy_config:
                    self.session.proxies.update(proxy_config)
                    self.logger.info(f"使用Nekobox代理: {proxy_config}")
                else:
                    self.logger.warning("Nekobox代理配置失败，使用直连")
            else:
                # 使用手动配置的代理
                self.session.proxies.update(self.config.proxy_config)
    
    def make_request(self, url: str, method: str = 'GET', **kwargs) -> Optional[requests.Response]:
        """发起HTTP请求"""
        try:
            response = self.session.request(method, url, timeout=15, **kwargs)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            self.logger.error(f"请求失败 {url}: {e}")
            return None

class BinanceClient(APIClient):
    """Binance.US API客户端"""
    
    def __init__(self, config):
        super().__init__(config)
        self.exchange_config = config.exchanges.get('binance', {})
        self.api_base = self.exchange_config.get('api_base')
        self.ticker_endpoint = self.exchange_config.get('ticker_endpoint')
        self.announcement_url = self.exchange_config.get('announcement_url')
    
    def get_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的24小时价格变动数据"""
        if not self.exchange_config.get('enabled', False):
            return []
        
        url = f"{self.api_base}{self.ticker_endpoint}"
        response = self.make_request(url)
        
        if response:
            try:
                tickers = response.json()
                self.logger.info(f"成功获取Binance.US {len(tickers)} 个交易对数据")
                return tickers
            except ValueError as e:
                self.logger.error(f"解析Binance.US响应失败: {e}")
        
        return []
    
    def get_announcements(self) -> List[Dict[str, Any]]:
        """获取公告信息"""
        if not self.exchange_config.get('enabled', False):
            return []
        
        response = self.make_request(self.announcement_url)
        if not response:
            return []
        
        return self._parse_announcements(response.text)
    
    def _parse_announcements(self, html_content: str) -> List[Dict[str, Any]]:
        """解析公告页面"""
        announcements = []
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            articles = soup.select('article.article-list-item')
            
            for article in articles:
                try:
                    title_element = article.select_one('h3.article-list-item-title')
                    link_element = article.select_one('a')
                    date_element = article.select_one('time')
                    
                    if title_element and link_element:
                        title = title_element.text.strip()
                        link = link_element.get('href')
                        if not link.startswith('http'):
                            link = f"https://support.binance.us{link}"
                        
                        date = date_element.text.strip() if date_element else "未知日期"
                        content_hash = hashlib.md5(f"{title}_{link}".encode()).hexdigest()
                        
                        # 检查是否为新上币公告
                        is_new_listing = any(
                            keyword.lower() in title.lower() 
                            for keyword in self.config.new_listing_keywords
                        )
                        
                        announcements.append({
                            "exchange": "Binance.US",
                            "title": title,
                            "url": link,
                            "date": date,
                            "content_hash": content_hash,
                            "is_new_listing": is_new_listing
                        })
                except Exception as e:
                    self.logger.error(f"解析Binance.US公告项目时出错: {e}")
            
            self.logger.info(f"成功解析 {len(announcements)} 条Binance.US公告")
        except Exception as e:
            self.logger.error(f"解析Binance.US公告页面失败: {e}")
        
        return announcements

class GateClient(APIClient):
    """Gate.io API客户端"""
    
    def __init__(self, config):
        super().__init__(config)
        self.exchange_config = config.exchanges.get('gate', {})
        self.api_base = self.exchange_config.get('api_base')
        self.ticker_endpoint = self.exchange_config.get('ticker_endpoint')
        self.announcement_url = self.exchange_config.get('announcement_url')
    
    def get_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的价格和涨跌幅数据"""
        if not self.exchange_config.get('enabled', False):
            return []
        
        url = f"{self.api_base}{self.ticker_endpoint}"
        response = self.make_request(url)
        
        if response:
            try:
                tickers = response.json()
                self.logger.info(f"成功获取Gate.io {len(tickers)} 个交易对数据")
                return tickers
            except ValueError as e:
                self.logger.error(f"解析Gate.io响应失败: {e}")
        
        return []
    
    def get_announcements(self) -> List[Dict[str, Any]]:
        """获取公告信息"""
        if not self.exchange_config.get('enabled', False):
            return []
        
        response = self.make_request(self.announcement_url)
        if not response:
            return []
        
        return self._parse_announcements(response.text)
    
    def _parse_announcements(self, html_content: str) -> List[Dict[str, Any]]:
        """解析公告页面"""
        announcements = []
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            articles = soup.select('div.article-item') or soup.select('div.announcement-item')
            
            for article in articles:
                try:
                    title_element = article.select_one('h3') or article.select_one('div.title')
                    link_element = article.select_one('a')
                    date_element = article.select_one('time') or article.select_one('div.date')
                    
                    if title_element and link_element:
                        title = title_element.text.strip()
                        link = link_element.get('href')
                        if not link.startswith('http'):
                            link = f"https://www.gate.io{link}"
                        
                        date = date_element.text.strip() if date_element else "未知日期"
                        content_hash = hashlib.md5(f"{title}_{link}".encode()).hexdigest()
                        
                        # 检查是否为新上币公告
                        is_new_listing = any(
                            keyword.lower() in title.lower() 
                            for keyword in self.config.new_listing_keywords
                        )
                        
                        announcements.append({
                            "exchange": "Gate.io",
                            "title": title,
                            "url": link,
                            "date": date,
                            "content_hash": content_hash,
                            "is_new_listing": is_new_listing
                        })
                except Exception as e:
                    self.logger.error(f"解析Gate.io公告项目时出错: {e}")
            
            self.logger.info(f"成功解析 {len(announcements)} 条Gate.io公告")
        except Exception as e:
            self.logger.error(f"解析Gate.io公告页面失败: {e}")
        
        return announcements

class ExchangeAPIManager:
    """交易所API管理器"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # 初始化各交易所客户端
        self.clients = {
            'binance': BinanceClient(config),
            'gate': GateClient(config)
        }
    
    def get_all_tickers(self) -> Dict[str, List[Dict[str, Any]]]:
        """获取所有启用交易所的ticker数据"""
        all_tickers = {}
        
        for exchange, client in self.clients.items():
            if self.config.exchanges.get(exchange, {}).get('enabled', False):
                tickers = client.get_tickers()
                all_tickers[exchange] = tickers
        
        return all_tickers
    
    def get_all_announcements(self) -> Dict[str, List[Dict[str, Any]]]:
        """获取所有启用交易所的公告数据"""
        all_announcements = {}
        
        for exchange, client in self.clients.items():
            if self.config.exchanges.get(exchange, {}).get('enabled', False):
                announcements = client.get_announcements()
                all_announcements[exchange] = announcements
        
        return all_announcements

