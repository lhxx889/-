#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
通知管理模块
负责发送各种类型的通知
"""

import logging
import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Dict, Any

class NotificationManager:
    """通知管理器"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def send_price_notifications(self, price_changes: List[Dict[str, Any]]):
        """发送价格变动通知"""
        if not price_changes:
            return
        
        # 过滤符合通知条件的变动
        telegram_config = self.config.telegram_config
        min_change = telegram_config.get('min_price_change', 10.0)
        
        significant_changes = [
            change for change in price_changes
            if abs(change['change_percent']) >= min_change
        ]
        
        if not significant_changes:
            return
        
        # 发送Telegram通知
        if telegram_config.get('enabled') and telegram_config.get('price_notify'):
            self._send_telegram_price_notification(significant_changes)
        
        # 发送邮件通知
        email_config = self.config.get('notifications.email', {})
        if email_config.get('enabled'):
            self._send_email_price_notification(significant_changes)
    
    def send_announcement_notifications(self, announcements: List[Dict[str, Any]]):
        """发送公告通知"""
        if not announcements:
            return
        
        telegram_config = self.config.telegram_config
        
        # 发送Telegram通知
        if telegram_config.get('enabled') and telegram_config.get('announcement_notify'):
            self._send_telegram_announcement_notification(announcements)
        
        # 发送邮件通知
        email_config = self.config.get('notifications.email', {})
        if email_config.get('enabled'):
            self._send_email_announcement_notification(announcements)
    
    def _send_telegram_price_notification(self, price_changes: List[Dict[str, Any]]):
        """发送Telegram价格通知"""
        try:
            telegram_config = self.config.telegram_config
            bot_token = telegram_config.get('bot_token')
            chat_id = telegram_config.get('chat_id')
            
            if not bot_token or not chat_id:
                self.logger.warning("Telegram配置不完整，跳过通知")
                return
            
            # 构建消息
            message_lines = ["🚨 价格异动提醒 🚨\\n"]
            
            for change in price_changes:
                direction_emoji = "📈" if change['direction'] == "上涨" else "📉"
                message_lines.append(
                    f"{direction_emoji} {change['exchange']} - {change['symbol']}\\n"
                    f"价格: ${change['price']:.6f}\\n"
                    f"变动: {change['change_percent']:+.2f}%\\n"
                )
            
            message = "\\n".join(message_lines)
            
            # 发送消息
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': chat_id,
                'text': message,
                'parse_mode': 'MarkdownV2'
            }
            
            # 使用代理（如果配置了）
            proxies = self.config.proxy_config if self.config.proxy_enabled else None
            
            response = requests.post(url, data=data, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            self.logger.info(f"Telegram价格通知发送成功，{len(price_changes)}条变动")
            
        except Exception as e:
            self.logger.error(f"发送Telegram价格通知失败: {e}")
    
    def _send_telegram_announcement_notification(self, announcements: List[Dict[str, Any]]):
        """发送Telegram公告通知"""
        try:
            telegram_config = self.config.telegram_config
            bot_token = telegram_config.get('bot_token')
            chat_id = telegram_config.get('chat_id')
            
            if not bot_token or not chat_id:
                self.logger.warning("Telegram配置不完整，跳过通知")
                return
            
            # 分离新上币和普通公告
            new_listings = [a for a in announcements if a['is_new_listing']]
            regular_announcements = [a for a in announcements if not a['is_new_listing']]
            
            message_lines = []
            
            # 新上币公告
            if new_listings:
                message_lines.append("🚀 新上币公告 🚀\\n")
                for announcement in new_listings:
                    message_lines.append(
                        f"💰 {announcement['exchange']}\\n"
                        f"标题: {announcement['title']}\\n"
                        f"链接: {announcement['url']}\\n"
                    )
            
            # 普通公告
            if regular_announcements:
                if new_listings:
                    message_lines.append("\\n" + "="*30 + "\\n")
                message_lines.append("📢 交易所公告 📢\\n")
                for announcement in regular_announcements:
                    message_lines.append(
                        f"📋 {announcement['exchange']}\\n"
                        f"标题: {announcement['title']}\\n"
                        f"链接: {announcement['url']}\\n"
                    )
            
            if not message_lines:
                return
            
            message = "\\n".join(message_lines)
            
            # 发送消息
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': chat_id,
                'text': message,
                'parse_mode': 'MarkdownV2',
                'disable_web_page_preview': True
            }
            
            # 使用代理（如果配置了）
            proxies = self.config.proxy_config if self.config.proxy_enabled else None
            
            response = requests.post(url, data=data, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            self.logger.info(f"Telegram公告通知发送成功，{len(announcements)}条公告")
            
        except Exception as e:
            self.logger.error(f"发送Telegram公告通知失败: {e}")
    
    def _send_email_price_notification(self, price_changes: List[Dict[str, Any]]):
        """发送邮件价格通知"""
        try:
            email_config = self.config.get('notifications.email', {})
            
            # 构建邮件内容
            subject = f"加密货币价格异动提醒 - {len(price_changes)}个变动"
            
            html_content = """
            <html>
            <body>
            <h2>🚨 价格异动提醒</h2>
            <table border="1" style="border-collapse: collapse;">
            <tr>
                <th>交易所</th>
                <th>交易对</th>
                <th>当前价格</th>
                <th>变动幅度</th>
                <th>方向</th>
            </tr>
            """
            
            for change in price_changes:
                color = "green" if change['direction'] == "上涨" else "red"
                html_content += f"""
                <tr>
                    <td>{change['exchange']}</td>
                    <td>{change['symbol']}</td>
                    <td>${change['price']:.6f}</td>
                    <td style="color: {color};">{change['change_percent']:+.2f}%</td>
                    <td style="color: {color};">{change['direction']}</td>
                </tr>
                """
            
            html_content += """
            </table>
            </body>
            </html>
            """
            
            self._send_email(subject, html_content, email_config)
            self.logger.info(f"邮件价格通知发送成功，{len(price_changes)}条变动")
            
        except Exception as e:
            self.logger.error(f"发送邮件价格通知失败: {e}")
    
    def _send_email_announcement_notification(self, announcements: List[Dict[str, Any]]):
        """发送邮件公告通知"""
        try:
            email_config = self.config.get('notifications.email', {})
            
            # 构建邮件内容
            subject = f"交易所公告更新 - {len(announcements)}条新公告"
            
            html_content = """
            <html>
            <body>
            <h2>📢 交易所公告更新</h2>
            """
            
            # 分离新上币和普通公告
            new_listings = [a for a in announcements if a['is_new_listing']]
            regular_announcements = [a for a in announcements if not a['is_new_listing']]
            
            if new_listings:
                html_content += "<h3>🚀 新上币公告</h3><ul>"
                for announcement in new_listings:
                    html_content += f"""
                    <li>
                        <strong>{announcement['exchange']}</strong>: 
                        <a href="{announcement['url']}">{announcement['title']}</a>
                        <br><small>日期: {announcement['date']}</small>
                    </li>
                    """
                html_content += "</ul>"
            
            if regular_announcements:
                html_content += "<h3>📋 普通公告</h3><ul>"
                for announcement in regular_announcements:
                    html_content += f"""
                    <li>
                        <strong>{announcement['exchange']}</strong>: 
                        <a href="{announcement['url']}">{announcement['title']}</a>
                        <br><small>日期: {announcement['date']}</small>
                    </li>
                    """
                html_content += "</ul>"
            
            html_content += "</body></html>"
            
            self._send_email(subject, html_content, email_config)
            self.logger.info(f"邮件公告通知发送成功，{len(announcements)}条公告")
            
        except Exception as e:
            self.logger.error(f"发送邮件公告通知失败: {e}")
    
    def _send_email(self, subject: str, html_content: str, email_config: Dict[str, Any]):
        """发送邮件"""
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = email_config['username']
        msg['To'] = email_config['to_email']
        
        html_part = MIMEText(html_content, 'html')
        msg.attach(html_part)
        
        # 发送邮件
        with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            server.send_message(msg)
    
    def test_telegram_connection(self) -> Dict[str, Any]:
        """测试Telegram连接"""
        try:
            telegram_config = self.config.telegram_config
            bot_token = telegram_config.get('bot_token')
            chat_id = telegram_config.get('chat_id')
            
            if not bot_token or not chat_id:
                return {
                    'success': False,
                    'message': 'Telegram配置不完整'
                }
            
            # 发送测试消息
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': chat_id,
                'text': '🤖 加密货币监控系统连接测试成功！'
            }
            
            # 使用代理（如果配置了）
            proxies = self.config.proxy_config if self.config.proxy_enabled else None
            
            response = requests.post(url, data=data, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            return {
                'success': True,
                'message': 'Telegram连接测试成功'
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': f'Telegram连接测试失败: {str(e)}'
            }

