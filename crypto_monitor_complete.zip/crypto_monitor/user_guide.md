# 币安美国和Gate交易所监控系统使用说明

## 系统概述

本系统用于监控币安美国(Binance.US)和Gate.io交易所的币种涨跌幅，并定期扫描两家交易所的公告和新上币信息，实现自动化监控和通知功能。系统由三个核心脚本组成，分别负责不同交易所的价格监控和公告扫描。

## 功能特点

1. **币种涨跌幅监控**
   - 实时获取Binance.US和Gate.io所有币种的价格和涨跌幅数据
   - 支持设置涨跌幅阈值，超过阈值时触发通知
   - 自动记录显著价格变动，便于后续分析

2. **公告和新上币扫描**
   - 定期扫描交易所的公告页面
   - 识别新上币公告并优先提醒
   - 记录历史公告，避免重复通知

3. **数据存储与日志**
   - 所有监控数据以JSON格式保存
   - 完整的日志系统，记录所有监控活动和异常情况

## 系统组件

系统由以下三个核心脚本组成：

1. **binance_price_monitor.py**: 监控Binance.US交易所的币种价格和涨跌幅
2. **gate_price_monitor.py**: 监控Gate.io交易所的币种价格和涨跌幅
3. **announcement_scanner.py**: 扫描两家交易所的公告页面

## 安装与配置

### 系统要求

- Python 3.6+
- 必要的Python库：requests, beautifulsoup4, json, time, logging

### 安装步骤

1. 确保系统已安装Python 3.6或更高版本
2. 安装必要的Python库：
   ```
   pip install requests beautifulsoup4
   ```
3. 将所有脚本文件放置在同一目录下

### 配置参数

每个脚本中都有一些可配置的参数，可以根据需要进行调整：

- **价格监控脚本**:
  - `PRICE_CHANGE_THRESHOLD`: 涨跌幅阈值，默认为5.0%
  - `CHECK_INTERVAL`: 检查间隔，默认为300秒(5分钟)

- **公告扫描脚本**:
  - `SCAN_INTERVAL`: 扫描间隔，默认为3600秒(1小时)
  - `NEW_LISTINGS_KEYWORDS`: 用于识别新上币公告的关键词列表

## 使用方法

### 运行价格监控

1. 运行Binance.US价格监控：
   ```
   python binance_price_monitor.py
   ```

2. 运行Gate.io价格监控：
   ```
   python gate_price_monitor.py
   ```

### 运行公告扫描

```
python announcement_scanner.py
```

### 设置定时任务

为了实现自动化监控，建议使用系统的定时任务功能：

#### Linux/Mac (使用cron)

```
# 编辑crontab
crontab -e

# 添加以下内容（每5分钟运行价格监控，每小时运行公告扫描）
*/5 * * * * cd /path/to/scripts && python binance_price_monitor.py
*/5 * * * * cd /path/to/scripts && python gate_price_monitor.py
0 * * * * cd /path/to/scripts && python announcement_scanner.py
```

#### Windows (使用任务计划程序)

1. 打开任务计划程序
2. 创建基本任务
3. 设置触发器为每5分钟一次（价格监控）或每小时一次（公告扫描）
4. 操作选择"启动程序"，然后选择Python解释器和相应的脚本

## 输出文件

系统运行后会生成以下文件：

1. **significant_price_changes.json**: 记录所有显著的价格变动
2. **new_announcements.json**: 记录所有新发现的公告
3. **announcement_history.json**: 记录已处理过的公告历史
4. **binance_monitor.log**: Binance.US价格监控的日志文件
5. **gate_monitor.log**: Gate.io价格监控的日志文件
6. **announcement_scanner.log**: 公告扫描的日志文件

## 已知限制

1. **Gate.io公告页面访问限制**:
   - Gate.io网站对爬虫有严格限制，可能会返回403 Forbidden错误
   - 解决方案：使用代理服务器、调整请求头或考虑使用官方API（如果有）

2. **网络依赖**:
   - 系统依赖网络连接，网络不稳定可能导致数据获取失败
   - 脚本已包含基本的错误处理和重试机制

3. **API限制**:
   - 交易所API可能有请求频率限制，过于频繁的请求可能被限制
   - 建议根据实际需求调整检查间隔

## 扩展与优化

1. **添加更多交易所**:
   - 系统设计为模块化，可以参考现有脚本添加其他交易所的监控

2. **增强通知功能**:
   - 可以集成邮件、短信或消息推送服务，实现实时通知

3. **数据分析与可视化**:
   - 可以添加数据分析功能，生成价格趋势图表
   - 可以开发Web界面，实现可视化监控

4. **改进公告抓取**:
   - 对于受限的公告页面，可以考虑使用更高级的爬虫技术或API
   - 可以增加自然语言处理功能，更准确地识别重要公告

## 故障排除

1. **脚本无法启动**:
   - 检查Python版本和必要库是否正确安装
   - 检查脚本文件权限

2. **无法获取数据**:
   - 检查网络连接
   - 检查API端点是否变更
   - 查看日志文件了解详细错误信息

3. **公告扫描403错误**:
   - 尝试调整请求头，模拟正常浏览器行为
   - 考虑使用代理服务器
   - 减少请求频率

## 联系与支持

如有任何问题或需要进一步的支持，请联系系统开发者。
