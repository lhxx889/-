"""
加密货币监控系统API路由 - 交易所管理
"""

from flask import Blueprint, jsonify, request
from src.models.crypto import db, Exchange, FallbackConfig
from datetime import datetime
import json

exchange_bp = Blueprint('exchange', __name__)

@exchange_bp.route('/', methods=['GET'])
def get_all_exchanges():
    """获取所有交易所信息"""
    exchanges = Exchange.query.all()
    return jsonify({
        "success": True,
        "data": [exchange.to_dict() for exchange in exchanges]
    }), 200

@exchange_bp.route('/<exchange_id>', methods=['GET'])
def get_exchange(exchange_id):
    """获取特定交易所信息"""
    exchange = Exchange.query.get(exchange_id)
    if not exchange:
        return jsonify({
            "success": False,
            "message": f"交易所 {exchange_id} 不存在"
        }), 404
    
    return jsonify({
        "success": True,
        "data": exchange.to_dict()
    }), 200

@exchange_bp.route('/', methods=['POST'])
def create_exchange():
    """创建新交易所"""
    data = request.json
    
    # 验证必要字段
    if not data or not data.get('id') or not data.get('name'):
        return jsonify({
            "success": False,
            "message": "缺少必要字段: id, name"
        }), 400
    
    # 检查交易所ID是否已存在
    existing_exchange = Exchange.query.get(data['id'])
    if existing_exchange:
        return jsonify({
            "success": False,
            "message": f"交易所ID {data['id']} 已存在"
        }), 409
    
    # 创建新交易所
    new_exchange = Exchange(
        id=data['id'],
        name=data['name'],
        is_enabled=data.get('is_enabled', True),
        api_status=data.get('api_status', 'unknown'),
        consecutive_failures=data.get('consecutive_failures', 0),
        last_updated=datetime.now()
    )
    
    try:
        db.session.add(new_exchange)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "交易所创建成功",
            "data": new_exchange.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"创建交易所失败: {str(e)}"
        }), 500

@exchange_bp.route('/<exchange_id>', methods=['PUT'])
def update_exchange(exchange_id):
    """更新交易所信息"""
    exchange = Exchange.query.get(exchange_id)
    if not exchange:
        return jsonify({
            "success": False,
            "message": f"交易所 {exchange_id} 不存在"
        }), 404
    
    data = request.json
    if not data:
        return jsonify({
            "success": False,
            "message": "未提供更新数据"
        }), 400
    
    # 更新字段
    if 'name' in data:
        exchange.name = data['name']
    if 'is_enabled' in data:
        exchange.is_enabled = data['is_enabled']
    if 'api_status' in data:
        exchange.api_status = data['api_status']
    if 'consecutive_failures' in data:
        exchange.consecutive_failures = data['consecutive_failures']
    
    exchange.last_updated = datetime.now()
    
    try:
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "交易所更新成功",
            "data": exchange.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"更新交易所失败: {str(e)}"
        }), 500

@exchange_bp.route('/<exchange_id>', methods=['DELETE'])
def delete_exchange(exchange_id):
    """删除交易所"""
    exchange = Exchange.query.get(exchange_id)
    if not exchange:
        return jsonify({
            "success": False,
            "message": f"交易所 {exchange_id} 不存在"
        }), 404
    
    try:
        # 删除相关的备用配置
        FallbackConfig.query.filter_by(primary_exchange_id=exchange_id).delete()
        FallbackConfig.query.filter_by(fallback_exchange_id=exchange_id).delete()
        
        # 删除交易所
        db.session.delete(exchange)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"交易所 {exchange_id} 已删除"
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"删除交易所失败: {str(e)}"
        }), 500

@exchange_bp.route('/status', methods=['GET'])
def get_exchanges_status():
    """获取所有交易所状态"""
    exchanges = Exchange.query.all()
    status_data = {}
    
    for exchange in exchanges:
        status_data[exchange.id] = {
            "name": exchange.name,
            "status": exchange.api_status,
            "consecutive_failures": exchange.consecutive_failures,
            "last_updated": exchange.last_updated.isoformat() if exchange.last_updated else None,
            "is_enabled": exchange.is_enabled
        }
    
    return jsonify({
        "success": True,
        "data": status_data
    }), 200

@exchange_bp.route('/fallback', methods=['GET'])
def get_all_fallbacks():
    """获取所有备用数据源配置"""
    fallbacks = FallbackConfig.query.all()
    return jsonify({
        "success": True,
        "data": [fallback.to_dict() for fallback in fallbacks]
    }), 200

@exchange_bp.route('/fallback', methods=['POST'])
def create_fallback():
    """创建新的备用数据源配置"""
    data = request.json
    
    # 验证必要字段
    if not data or not data.get('primary_exchange_id') or not data.get('fallback_exchange_id'):
        return jsonify({
            "success": False,
            "message": "缺少必要字段: primary_exchange_id, fallback_exchange_id"
        }), 400
    
    # 检查交易所是否存在
    primary = Exchange.query.get(data['primary_exchange_id'])
    fallback = Exchange.query.get(data['fallback_exchange_id'])
    
    if not primary:
        return jsonify({
            "success": False,
            "message": f"主交易所 {data['primary_exchange_id']} 不存在"
        }), 404
    
    if not fallback:
        return jsonify({
            "success": False,
            "message": f"备用交易所 {data['fallback_exchange_id']} 不存在"
        }), 404
    
    # 检查是否已存在相同配置
    existing = FallbackConfig.query.filter_by(
        primary_exchange_id=data['primary_exchange_id'],
        fallback_exchange_id=data['fallback_exchange_id']
    ).first()
    
    if existing:
        return jsonify({
            "success": False,
            "message": "该备用数据源配置已存在"
        }), 409
    
    # 创建新配置
    new_fallback = FallbackConfig(
        primary_exchange_id=data['primary_exchange_id'],
        fallback_exchange_id=data['fallback_exchange_id'],
        is_enabled=data.get('is_enabled', True),
        priority=data.get('priority', 1)
    )
    
    try:
        db.session.add(new_fallback)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "备用数据源配置创建成功",
            "data": new_fallback.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"创建备用数据源配置失败: {str(e)}"
        }), 500

@exchange_bp.route('/fallback/<int:fallback_id>', methods=['PUT'])
def update_fallback(fallback_id):
    """更新备用数据源配置"""
    fallback = FallbackConfig.query.get(fallback_id)
    if not fallback:
        return jsonify({
            "success": False,
            "message": f"备用数据源配置 ID {fallback_id} 不存在"
        }), 404
    
    data = request.json
    if not data:
        return jsonify({
            "success": False,
            "message": "未提供更新数据"
        }), 400
    
    # 更新字段
    if 'is_enabled' in data:
        fallback.is_enabled = data['is_enabled']
    if 'priority' in data:
        fallback.priority = data['priority']
    
    try:
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "备用数据源配置更新成功",
            "data": fallback.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"更新备用数据源配置失败: {str(e)}"
        }), 500

@exchange_bp.route('/fallback/<int:fallback_id>', methods=['DELETE'])
def delete_fallback(fallback_id):
    """删除备用数据源配置"""
    fallback = FallbackConfig.query.get(fallback_id)
    if not fallback:
        return jsonify({
            "success": False,
            "message": f"备用数据源配置 ID {fallback_id} 不存在"
        }), 404
    
    try:
        db.session.delete(fallback)
        db.session.commit()
        return jsonify({
            "success": True,
            "message": f"备用数据源配置 ID {fallback_id} 已删除"
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False,
            "message": f"删除备用数据源配置失败: {str(e)}"
        }), 500
