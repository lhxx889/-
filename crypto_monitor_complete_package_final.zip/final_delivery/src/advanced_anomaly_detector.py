"""
高级异常检测算法模块 - 实现多种异常检测算法和策略
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Any, Tuple, Optional
from scipy import stats
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("advanced_anomaly_detector")

class AdvancedAnomalyDetector:
    """高级异常检测器，集成多种检测算法"""
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化高级异常检测器
        
        参数:
            config: 配置字典，包含检测参数
        """
        self.config = config or {}
        self.sensitivity = self.config.get('detection_sensitivity', 'medium')
        self.analysis_window = int(self.config.get('analysis_window', 24))
        self.enable_cross_exchange = self.config.get('enable_cross_exchange', 'false') == 'true'
        
        # 根据灵敏度设置阈值
        self._set_thresholds()
        
        logger.info(f"高级异常检测器初始化完成，灵敏度: {self.sensitivity}, 分析窗口: {self.analysis_window}小时")
    
    def _set_thresholds(self):
        """根据灵敏度设置检测阈值"""
        # Z分数阈值
        if self.sensitivity == 'high':
            self.z_score_threshold = 2.0  # 更敏感，约95%的数据在此范围内
        elif self.sensitivity == 'low':
            self.z_score_threshold = 3.0  # 不太敏感，约99.7%的数据在此范围内
        else:  # medium
            self.z_score_threshold = 2.5  # 中等灵敏度，约99%的数据在此范围内
        
        # 移动平均偏差阈值
        if self.sensitivity == 'high':
            self.ma_deviation_threshold = 0.05  # 5%偏差
        elif self.sensitivity == 'low':
            self.ma_deviation_threshold = 0.15  # 15%偏差
        else:  # medium
            self.ma_deviation_threshold = 0.10  # 10%偏差
        
        # 孤立森林异常分数阈值
        if self.sensitivity == 'high':
            self.isolation_forest_threshold = -0.3  # 更敏感
        elif self.sensitivity == 'low':
            self.isolation_forest_threshold = -0.5  # 不太敏感
        else:  # medium
            self.isolation_forest_threshold = -0.4  # 中等灵敏度
        
        # 交叉交易所验证阈值
        if self.sensitivity == 'high':
            self.cross_exchange_threshold = 0.05  # 5%差异
        elif self.sensitivity == 'low':
            self.cross_exchange_threshold = 0.15  # 15%差异
        else:  # medium
            self.cross_exchange_threshold = 0.10  # 10%差异
    
    def detect_anomalies(self, price_data: List[Dict[str, Any]], 
                         exchange_data: Optional[Dict[str, List[Dict[str, Any]]]] = None) -> List[Dict[str, Any]]:
        """
        检测价格数据中的异常
        
        参数:
            price_data: 价格数据列表，每个元素是一个包含价格信息的字典
            exchange_data: 可选，其他交易所的价格数据，用于交叉验证
            
        返回:
            异常列表，每个元素是一个包含异常信息的字典
        """
        if not price_data:
            logger.warning("没有提供价格数据，无法进行异常检测")
            return []
        
        # 转换为DataFrame便于分析
        df = pd.DataFrame(price_data)
        
        # 确保时间戳是datetime类型
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # 按时间排序
        df = df.sort_values('timestamp')
        
        # 检查数据量是否足够
        if len(df) < 10:
            logger.warning(f"数据点数量不足（{len(df)}），无法进行可靠的异常检测")
            return []
        
        # 执行多种检测算法
        anomalies = []
        
        # 1. 基于Z分数的异常检测
        z_score_anomalies = self._detect_z_score_anomalies(df)
        anomalies.extend(z_score_anomalies)
        
        # 2. 基于移动平均的异常检测
        ma_anomalies = self._detect_moving_average_anomalies(df)
        anomalies.extend(ma_anomalies)
        
        # 3. 基于孤立森林的异常检测
        if len(df) >= 50:  # 需要足够的数据点
            isolation_forest_anomalies = self._detect_isolation_forest_anomalies(df)
            anomalies.extend(isolation_forest_anomalies)
        
        # 4. 交叉交易所验证（如果启用且提供了其他交易所数据）
        if self.enable_cross_exchange and exchange_data:
            cross_exchange_anomalies = self._detect_cross_exchange_anomalies(df, exchange_data)
            anomalies.extend(cross_exchange_anomalies)
        
        # 去重并返回
        unique_anomalies = self._deduplicate_anomalies(anomalies)
        
        logger.info(f"高级异常检测完成，发现 {len(unique_anomalies)} 个异常")
        return unique_anomalies
    
    def _detect_z_score_anomalies(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """基于Z分数的异常检测"""
        anomalies = []
        
        # 计算价格的Z分数
        df['price_z_score'] = stats.zscore(df['price'])
        
        # 检测异常
        price_anomalies = df[abs(df['price_z_score']) > self.z_score_threshold]
        
        for _, row in price_anomalies.iterrows():
            # 计算参考价格（平均值）
            reference_price = df['price'].mean()
            
            # 计算价格变化百分比
            price_change_pct = ((row['price'] - reference_price) / reference_price) * 100
            
            anomaly = {
                'coin_id': row['coin_id'],
                'type': 'price',
                'current_price': row['price'],
                'reference_price': reference_price,
                'price_change_pct': price_change_pct,
                'volume_24h': row.get('volume_24h'),
                'confidence_score': min(abs(row['price_z_score']) / 5.0, 1.0),  # 归一化置信度
                'algorithm': 'z_score',
                'detected_at': datetime.now(),
                'is_notified': False
            }
            anomalies.append(anomaly)
        
        logger.info(f"Z分数检测发现 {len(anomalies)} 个异常")
        return anomalies
    
    def _detect_moving_average_anomalies(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """基于移动平均的异常检测"""
        anomalies = []
        
        # 计算移动平均
        window_size = min(len(df) // 3, 24)  # 使用数据长度的1/3或24作为窗口大小
        if window_size < 2:
            window_size = 2
        
        df['price_ma'] = df['price'].rolling(window=window_size).mean()
        
        # 跳过NaN值
        df_valid = df.dropna()
        
        # 计算当前价格与移动平均的偏差
        df_valid['ma_deviation'] = abs(df_valid['price'] - df_valid['price_ma']) / df_valid['price_ma']
        
        # 检测异常
        ma_anomalies = df_valid[df_valid['ma_deviation'] > self.ma_deviation_threshold]
        
        for _, row in ma_anomalies.iterrows():
            # 计算价格变化百分比
            price_change_pct = ((row['price'] - row['price_ma']) / row['price_ma']) * 100
            
            anomaly = {
                'coin_id': row['coin_id'],
                'type': 'price',
                'current_price': row['price'],
                'reference_price': row['price_ma'],
                'price_change_pct': price_change_pct,
                'volume_24h': row.get('volume_24h'),
                'confidence_score': min(row['ma_deviation'] / 0.3, 1.0),  # 归一化置信度
                'algorithm': 'moving_average',
                'detected_at': datetime.now(),
                'is_notified': False
            }
            anomalies.append(anomaly)
        
        logger.info(f"移动平均检测发现 {len(anomalies)} 个异常")
        return anomalies
    
    def _detect_isolation_forest_anomalies(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """基于孤立森林的异常检测"""
        anomalies = []
        
        # 准备特征
        features = ['price']
        if 'volume_24h' in df.columns and df['volume_24h'].notna().all():
            features.append('volume_24h')
        
        # 标准化特征
        scaler = StandardScaler()
        X = scaler.fit_transform(df[features])
        
        # 训练孤立森林模型
        model = IsolationForest(contamination=0.05, random_state=42)
        df['anomaly_score'] = model.fit_predict(X)
        df['anomaly_score'] = model.decision_function(X)  # 获取异常分数
        
        # 检测异常
        isolation_anomalies = df[df['anomaly_score'] < self.isolation_forest_threshold]
        
        for _, row in isolation_anomalies.iterrows():
            # 计算参考价格（过去24小时的平均值）
            cutoff_time = row['timestamp'] - timedelta(hours=24)
            past_data = df[df['timestamp'] >= cutoff_time]
            reference_price = past_data['price'].mean()
            
            # 计算价格变化百分比
            price_change_pct = ((row['price'] - reference_price) / reference_price) * 100
            
            # 确定异常类型
            anomaly_type = 'pattern'  # 默认为模式异常
            if abs(price_change_pct) > 10:  # 如果价格变化显著，则为价格异常
                anomaly_type = 'price'
            elif 'volume_24h' in features and row.get('volume_24h') is not None:
                # 计算交易量变化
                past_volume = past_data['volume_24h'].mean()
                if past_volume > 0:
                    volume_change_pct = ((row['volume_24h'] - past_volume) / past_volume) * 100
                    if abs(volume_change_pct) > 50:  # 如果交易量变化显著，则为交易量异常
                        anomaly_type = 'volume'
            
            anomaly = {
                'coin_id': row['coin_id'],
                'type': anomaly_type,
                'current_price': row['price'],
                'reference_price': reference_price,
                'price_change_pct': price_change_pct,
                'volume_24h': row.get('volume_24h'),
                'confidence_score': min(abs(row['anomaly_score'] - 1) / 2, 1.0),  # 归一化置信度
                'algorithm': 'isolation_forest',
                'detected_at': datetime.now(),
                'is_notified': False
            }
            anomalies.append(anomaly)
        
        logger.info(f"孤立森林检测发现 {len(anomalies)} 个异常")
        return anomalies
    
    def _detect_cross_exchange_anomalies(self, df: pd.DataFrame, 
                                         exchange_data: Dict[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        """基于交叉交易所验证的异常检测"""
        anomalies = []
        
        # 获取当前交易所和币种
        if len(df) == 0 or 'exchange_id' not in df.iloc[0] or 'symbol' not in df.iloc[0]:
            logger.warning("数据缺少交易所或币种信息，无法进行交叉交易所验证")
            return []
        
        current_exchange = df.iloc[-1]['exchange_id']
        current_symbol = df.iloc[-1]['symbol']
        current_price = df.iloc[-1]['price']
        
        # 收集其他交易所的最新价格
        other_prices = []
        for exchange_id, exchange_price_data in exchange_data.items():
            if exchange_id == current_exchange:
                continue  # 跳过当前交易所
            
            # 查找相同币种
            for price_item in exchange_price_data:
                if price_item.get('symbol') == current_symbol:
                    other_prices.append(price_item.get('price'))
                    break
        
        if not other_prices:
            logger.info(f"没有找到其他交易所的 {current_symbol} 价格数据，无法进行交叉验证")
            return []
        
        # 计算其他交易所的平均价格
        avg_other_price = sum(other_prices) / len(other_prices)
        
        # 计算价格偏差
        price_deviation = abs(current_price - avg_other_price) / avg_other_price
        
        # 检测异常
        if price_deviation > self.cross_exchange_threshold:
            # 计算价格变化百分比
            price_change_pct = ((current_price - avg_other_price) / avg_other_price) * 100
            
            anomaly = {
                'coin_id': df.iloc[-1]['coin_id'],
                'type': 'price',
                'current_price': current_price,
                'reference_price': avg_other_price,
                'price_change_pct': price_change_pct,
                'volume_24h': df.iloc[-1].get('volume_24h'),
                'confidence_score': min(price_deviation / 0.3, 1.0),  # 归一化置信度
                'algorithm': 'cross_exchange',
                'detected_at': datetime.now(),
                'is_notified': False
            }
            anomalies.append(anomaly)
            
            logger.info(f"交叉交易所验证发现异常: {current_symbol} 在 {current_exchange} 的价格与其他交易所平均价格相差 {price_deviation:.2%}")
        
        return anomalies
    
    def _deduplicate_anomalies(self, anomalies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """去除重复的异常"""
        if not anomalies:
            return []
        
        # 按币种ID和异常类型分组
        grouped_anomalies = {}
        for anomaly in anomalies:
            key = (anomaly['coin_id'], anomaly['type'])
            if key not in grouped_anomalies or anomaly['confidence_score'] > grouped_anomalies[key]['confidence_score']:
                grouped_anomalies[key] = anomaly
        
        return list(grouped_anomalies.values())


class AnomalyDetectionService:
    """异常检测服务，集成基础和高级异常检测"""
    
    def __init__(self, db_connection, config: Dict[str, Any] = None):
        """
        初始化异常检测服务
        
        参数:
            db_connection: 数据库连接
            config: 配置字典
        """
        self.db = db_connection
        self.config = config or {}
        
        # 基础阈值
        self.price_threshold = float(self.config.get('price_threshold', 10.0))
        self.volume_threshold = float(self.config.get('volume_threshold', 50.0))
        
        # 是否启用高级检测
        self.enable_advanced_detection = self.config.get('enable_advanced_detection', 'false') == 'true'
        
        # 初始化高级检测器
        if self.enable_advanced_detection:
            self.advanced_detector = AdvancedAnomalyDetector(config)
        
        logger.info(f"异常检测服务初始化完成，价格阈值: {self.price_threshold}%, 交易量阈值: {self.volume_threshold}%")
        logger.info(f"高级异常检测: {'启用' if self.enable_advanced_detection else '禁用'}")
    
    def detect_anomalies(self, price_data: List[Dict[str, Any]], 
                         historical_data: Dict[int, List[Dict[str, Any]]],
                         exchange_data: Optional[Dict[str, List[Dict[str, Any]]]] = None) -> List[Dict[str, Any]]:
        """
        检测价格数据中的异常
        
        参数:
            price_data: 当前价格数据列表
            historical_data: 历史价格数据，按币种ID分组
            exchange_data: 其他交易所的价格数据，按交易所ID分组
            
        返回:
            异常列表
        """
        anomalies = []
        
        # 1. 基础阈值检测
        threshold_anomalies = self._detect_threshold_anomalies(price_data, historical_data)
        anomalies.extend(threshold_anomalies)
        
        # 2. 高级异常检测（如果启用）
        if self.enable_advanced_detection:
            for coin_id, coin_history in historical_data.items():
                if len(coin_history) < 10:
                    continue  # 数据不足，跳过
                
                advanced_anomalies = self.advanced_detector.detect_anomalies(coin_history, exchange_data)
                anomalies.extend(advanced_anomalies)
        
        # 去重并返回
        unique_anomalies = self._deduplicate_anomalies(anomalies)
        
        logger.info(f"异常检测完成，共发现 {len(unique_anomalies)} 个异常")
        return unique_anomalies
    
    def _detect_threshold_anomalies(self, price_data: List[Dict[str, Any]], 
                                   historical_data: Dict[int, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        """基础阈值异常检测"""
        anomalies = []
        
        for item in price_data:
            coin_id = item.get('coin_id')
            if not coin_id or coin_id not in historical_data:
                continue
            
            # 获取历史数据
            history = historical_data[coin_id]
            if not history:
                continue
            
            # 计算参考价格（24小时前的价格或最早的价格）
            reference_price = None
            current_time = datetime.now()
            
            for h_item in history:
                h_time = datetime.fromisoformat(h_item['timestamp'].replace('Z', '+00:00'))
                time_diff = (current_time - h_time).total_seconds() / 3600  # 小时差
                
                if 23 <= time_diff <= 25:  # 约24小时前
                    reference_price = h_item['price']
                    break
            
            # 如果没有找到24小时前的价格，使用最早的价格
            if reference_price is None and history:
                reference_price = history[0]['price']
            
            if reference_price is None:
                continue
            
            current_price = item['price']
            
            # 计算价格变化百分比
            price_change_pct = ((current_price - reference_price) / reference_price) * 100
            
            # 检测价格异常
            if abs(price_change_pct) >= self.price_threshold:
                anomaly = {
                    'coin_id': coin_id,
                    'type': 'price',
                    'current_price': current_price,
                    'reference_price': reference_price,
                    'price_change_pct': price_change_pct,
                    'volume_24h': item.get('volume_24h'),
                    'confidence_score': min(abs(price_change_pct) / (self.price_threshold * 2), 1.0),  # 归一化置信度
                    'algorithm': 'threshold',
                    'detected_at': datetime.now(),
                    'is_notified': False
                }
                anomalies.append(anomaly)
            
            # 检测交易量异常
            if 'volume_24h' in item and item['volume_24h'] is not None:
                # 查找历史交易量
                reference_volume = None
                for h_item in history:
                    if 'volume_24h' in h_item and h_item['volume_24h'] is not None:
                        h_time = datetime.fromisoformat(h_item['timestamp'].replace('Z', '+00:00'))
                        time_diff = (current_time - h_time).total_seconds() / 3600  # 小时差
                        
                        if 23 <= time_diff <= 25:  # 约24小时前
                            reference_volume = h_item['volume_24h']
                            break
                
                # 如果没有找到24小时前的交易量，使用最早的交易量
                if reference_volume is None and history:
                    for h_item in history:
                        if 'volume_24h' in h_item and h_item['volume_24h'] is not None:
                            reference_volume = h_item['volume_24h']
                            break
                
                if reference_volume is not None and reference_volume > 0:
                    current_volume = item['volume_24h']
                    volume_change_pct = ((current_volume - reference_volume) / reference_volume) * 100
                    
                    if abs(volume_change_pct) >= self.volume_threshold:
                        anomaly = {
                            'coin_id': coin_id,
                            'type': 'volume',
                            'current_price': current_price,
                            'reference_price': reference_price,
                            'price_change_pct': price_change_pct,
                            'volume_24h': current_volume,
                            'volume_change_pct': volume_change_pct,
                            'confidence_score': min(abs(volume_change_pct) / (self.volume_threshold * 2), 1.0),  # 归一化置信度
                            'algorithm': 'threshold',
                            'detected_at': datetime.now(),
                            'is_notified': False
                        }
                        anomalies.append(anomaly)
        
        logger.info(f"基础阈值检测发现 {len(anomalies)} 个异常")
        return anomalies
    
    def _deduplicate_anomalies(self, anomalies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """去除重复的异常"""
        if not anomalies:
            return []
        
        # 按币种ID和异常类型分组
        grouped_anomalies = {}
        for anomaly in anomalies:
            key = (anomaly['coin_id'], anomaly['type'])
            if key not in grouped_anomalies or anomaly['confidence_score'] > grouped_anomalies[key]['confidence_score']:
                grouped_anomalies[key] = anomaly
        
        return list(grouped_anomalies.values())
    
    def save_anomalies(self, anomalies: List[Dict[str, Any]]) -> int:
        """
        保存异常到数据库
        
        参数:
            anomalies: 异常列表
            
        返回:
            保存的异常数量
        """
        if not anomalies:
            return 0
        
        saved_count = 0
        
        # 构建SQL插入语句
        for anomaly in anomalies:
            try:
                # 检查是否已存在相同的异常（同一币种、同一类型、同一天）
                cursor = self.db.cursor()
                today = datetime.now().date()
                
                query = """
                SELECT id FROM anomaly 
                WHERE coin_id = ? AND type = ? AND DATE(detected_at) = ?
                """
                cursor.execute(query, (anomaly['coin_id'], anomaly['type'], today))
                existing = cursor.fetchone()
                
                if existing:
                    # 更新现有异常
                    update_query = """
                    UPDATE anomaly SET 
                        current_price = ?,
                        reference_price = ?,
                        price_change_pct = ?,
                        volume_24h = ?,
                        volume_change_pct = ?,
                        confidence_score = ?,
                        algorithm = ?,
                        detected_at = ?,
                        is_notified = ?
                    WHERE id = ?
                    """
                    cursor.execute(update_query, (
                        anomaly['current_price'],
                        anomaly.get('reference_price'),
                        anomaly.get('price_change_pct'),
                        anomaly.get('volume_24h'),
                        anomaly.get('volume_change_pct'),
                        anomaly['confidence_score'],
                        anomaly['algorithm'],
                        anomaly['detected_at'],
                        anomaly['is_notified'],
                        existing[0]
                    ))
                else:
                    # 插入新异常
                    insert_query = """
                    INSERT INTO anomaly (
                        coin_id, type, current_price, reference_price, 
                        price_change_pct, volume_24h, volume_change_pct,
                        confidence_score, algorithm, detected_at, is_notified
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """
                    cursor.execute(insert_query, (
                        anomaly['coin_id'],
                        anomaly['type'],
                        anomaly['current_price'],
                        anomaly.get('reference_price'),
                        anomaly.get('price_change_pct'),
                        anomaly.get('volume_24h'),
                        anomaly.get('volume_change_pct'),
                        anomaly['confidence_score'],
                        anomaly['algorithm'],
                        anomaly['detected_at'],
                        anomaly['is_notified']
                    ))
                
                self.db.commit()
                saved_count += 1
            except Exception as e:
                logger.error(f"保存异常失败: {str(e)}")
                self.db.rollback()
        
        logger.info(f"成功保存 {saved_count} 个异常到数据库")
        return saved_count
