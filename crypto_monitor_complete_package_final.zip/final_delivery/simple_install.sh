#!/bin/bash
echo "===== 加密货币监控系统简化安装 ====="

# 检查Python和pip
echo "检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到Python3，请先安装Python3"
    exit 1
fi

if ! command -v pip3 &> /dev/null; then
    echo "正在安装pip..."
    sudo apt update
    sudo apt install -y python3-pip
fi

# 安装依赖
echo "正在安装依赖包..."
pip3 install -r requirements.txt

# 创建基础配置
echo "正在创建基础配置..."
mkdir -p src/config
cat > src/config.json << EOF
{
  "enabled_exchanges": ["gateio", "binance"],
  "use_binance_testnet": true,
  "check_interval": 60,
  "price_change_threshold": 5.0,
  "volume_change_threshold": 20.0,
  "detection_sensitivity": "medium",
  "enable_advanced_detection": true
}
EOF

echo "===== 安装完成! ====="
echo "启动系统请运行: ./simple_start.sh"

# 创建启动脚本
cat > simple_start.sh << EOF
#!/bin/bash
cd src
python3 main.py
EOF

chmod +x simple_start.sh
