# 多交易所监控系统设计方案

## 1. 概述

本设计方案旨在扩展现有的Gate.io加密货币监控系统，使其支持多个交易所（包括币安Binance）的实时监控。设计将遵循以下原则：

- 使用公开API，无需API密钥即可工作
- 在告警通知中清晰区分不同交易所的信息
- 保持现有功能的完整性
- 提供可扩展的架构，便于未来添加更多交易所

## 2. 交易所API抽象层设计

### 2.1 基础交易所接口

```python
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional

class ExchangeAPI(ABC):
    """交易所API抽象基类，定义所有交易所必须实现的接口"""
    
    @property
    @abstractmethod
    def exchange_name(self) -> str:
        """获取交易所名称"""
        pass
    
    @property
    @abstractmethod
    def exchange_id(self) -> str:
        """获取交易所唯一标识符"""
        pass
    
    @abstractmethod
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的ticker数据"""
        pass
    
    @abstractmethod
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取特定交易对的ticker数据"""
        pass
    
    @abstractmethod
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """获取所有可交易的交易对信息"""
        pass
    
    @abstractmethod
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """将交易所特定的ticker数据格式转换为标准格式"""
        pass
    
    @abstractmethod
    def get_exchange_url(self, symbol: str) -> str:
        """获取交易对在交易所的URL链接"""
        pass
```

### 2.2 标准化数据结构

为确保不同交易所的数据可以统一处理，定义标准化的数据结构：

```python
# 标准化的ticker数据结构
STANDARD_TICKER_SCHEMA = {
    "exchange": "",        # 交易所ID
    "symbol": "",          # 交易对符号
    "price": 0.0,          # 当前价格
    "volume_24h": 0.0,     # 24小时交易量
    "change_24h": 0.0,     # 24小时价格变化百分比
    "high_24h": 0.0,       # 24小时最高价
    "low_24h": 0.0,        # 24小时最低价
    "timestamp": "",       # 数据时间戳
    "original_data": {}    # 原始交易所数据（用于调试）
}
```

### 2.3 Gate.io交易所适配器实现

将现有的Gate.io实现重构为适配器模式：

```python
class GateioExchangeAPI(ExchangeAPI):
    """Gate.io交易所API适配器"""
    
    # Gate.io API基础URL
    BASE_URL = "https://api.gateio.ws/api/v4"
    
    # API端点
    ENDPOINTS = {
        "tickers": "/spot/tickers",
        "currency_pairs": "/spot/currency_pairs",
        "ticker": "/spot/tickers/{currency_pair}"
    }
    
    @property
    def exchange_name(self) -> str:
        return "Gate.io"
    
    @property
    def exchange_id(self) -> str:
        return "gateio"
    
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的ticker数据"""
        url = f"{self.BASE_URL}{self.ENDPOINTS['tickers']}"
        response = self._make_request(url)
        if response:
            return response
        return []
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取特定交易对的ticker数据"""
        endpoint = self.ENDPOINTS["ticker"].format(currency_pair=symbol)
        url = f"{self.BASE_URL}{endpoint}"
        return self._make_request(url)
    
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """获取所有可交易的交易对信息"""
        url = f"{self.BASE_URL}{self.ENDPOINTS['currency_pairs']}"
        response = self._make_request(url)
        if response:
            return response
        return []
    
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """将Gate.io特定的ticker数据格式转换为标准格式"""
        try:
            return {
                "exchange": self.exchange_id,
                "symbol": ticker.get("currency_pair", ""),
                "price": float(ticker.get("last", 0)),
                "volume_24h": float(ticker.get("base_volume", 0)),
                "change_24h": float(ticker.get("change_percentage", 0)),
                "high_24h": float(ticker.get("high_24h", 0)),
                "low_24h": float(ticker.get("low_24h", 0)),
                "timestamp": ticker.get("timestamp", ""),
                "original_data": ticker
            }
        except (ValueError, TypeError) as e:
            logger.warning(f"标准化Gate.io ticker数据失败: {str(e)}")
            return {
                "exchange": self.exchange_id,
                "symbol": ticker.get("currency_pair", ""),
                "price": 0.0,
                "volume_24h": 0.0,
                "change_24h": 0.0,
                "high_24h": 0.0,
                "low_24h": 0.0,
                "timestamp": "",
                "original_data": ticker
            }
    
    def get_exchange_url(self, symbol: str) -> str:
        """获取交易对在Gate.io的URL链接"""
        return f"https://www.gate.io/trade/{symbol}"
    
    def _make_request(self, url: str, params: Dict = None) -> Optional[Dict]:
        """发送API请求并处理可能的异常"""
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
```

### 2.4 币安交易所适配器设计

```python
class BinanceExchangeAPI(ExchangeAPI):
    """币安交易所API适配器"""
    
    # 币安API基础URL
    BASE_URL = "https://api.binance.com/api/v3"
    
    # API端点
    ENDPOINTS = {
        "tickers": "/ticker/24hr",
        "exchange_info": "/exchangeInfo",
        "ticker": "/ticker/24hr"
    }
    
    @property
    def exchange_name(self) -> str:
        return "Binance"
    
    @property
    def exchange_id(self) -> str:
        return "binance"
    
    def fetch_all_tickers(self) -> List[Dict[str, Any]]:
        """获取所有交易对的ticker数据"""
        url = f"{self.BASE_URL}{self.ENDPOINTS['tickers']}"
        response = self._make_request(url)
        if response:
            return response
        return []
    
    def fetch_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """获取特定交易对的ticker数据"""
        url = f"{self.BASE_URL}{self.ENDPOINTS['ticker']}"
        params = {"symbol": symbol}
        return self._make_request(url, params)
    
    def fetch_all_currency_pairs(self) -> List[Dict[str, Any]]:
        """获取所有可交易的交易对信息"""
        url = f"{self.BASE_URL}{self.ENDPOINTS['exchange_info']}"
        response = self._make_request(url)
        if response and "symbols" in response:
            return response["symbols"]
        return []
    
    def normalize_ticker_data(self, ticker: Dict[str, Any]) -> Dict[str, Any]:
        """将币安特定的ticker数据格式转换为标准格式"""
        try:
            # 计算24小时变化百分比
            last_price = float(ticker.get("lastPrice", 0))
            open_price = float(ticker.get("openPrice", 0))
            change_pct = 0
            if open_price > 0:
                change_pct = ((last_price - open_price) / open_price) * 100
            
            return {
                "exchange": self.exchange_id,
                "symbol": ticker.get("symbol", ""),
                "price": last_price,
                "volume_24h": float(ticker.get("volume", 0)),
                "change_24h": change_pct,
                "high_24h": float(ticker.get("highPrice", 0)),
                "low_24h": float(ticker.get("lowPrice", 0)),
                "timestamp": "",  # 币安不直接提供时间戳，使用系统时间
                "original_data": ticker
            }
        except (ValueError, TypeError) as e:
            logger.warning(f"标准化币安ticker数据失败: {str(e)}")
            return {
                "exchange": self.exchange_id,
                "symbol": ticker.get("symbol", ""),
                "price": 0.0,
                "volume_24h": 0.0,
                "change_24h": 0.0,
                "high_24h": 0.0,
                "low_24h": 0.0,
                "timestamp": "",
                "original_data": ticker
            }
    
    def get_exchange_url(self, symbol: str) -> str:
        """获取交易对在币安的URL链接"""
        return f"https://www.binance.com/en/trade/{symbol}"
    
    def _make_request(self, url: str, params: Dict = None) -> Optional[Dict]:
        """发送API请求并处理可能的异常"""
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"币安API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"币安API请求最终失败: {str(e)}")
                    return None
```

### 2.5 交易所工厂类

```python
class ExchangeFactory:
    """交易所工厂类，负责创建和管理交易所实例"""
    
    def __init__(self):
        self.exchanges = {}
        self.register_default_exchanges()
    
    def register_default_exchanges(self):
        """注册默认支持的交易所"""
        self.register_exchange("gateio", GateioExchangeAPI)
        self.register_exchange("binance", BinanceExchangeAPI)
    
    def register_exchange(self, exchange_id: str, exchange_class):
        """注册新的交易所"""
        self.exchanges[exchange_id] = exchange_class
    
    def create_exchange(self, exchange_id: str) -> Optional[ExchangeAPI]:
        """创建交易所实例"""
        if exchange_id in self.exchanges:
            return self.exchanges[exchange_id]()
        return None
    
    def get_all_exchanges(self) -> List[ExchangeAPI]:
        """获取所有注册的交易所实例"""
        return [exchange_class() for exchange_class in self.exchanges.values()]
    
    def get_exchange_ids(self) -> List[str]:
        """获取所有注册的交易所ID"""
        return list(self.exchanges.keys())
```

## 3. 数据采集器重构设计

### 3.1 多交易所数据采集器

```python
class MultiExchangeDataCollector:
    """多交易所数据采集器，负责从多个交易所获取数据并进行标准化处理"""
    
    def __init__(self, db_path: str = "crypto_data.db", cache_duration: int = 3600):
        """
        初始化多交易所数据采集器
        
        Args:
            db_path: SQLite数据库路径
            cache_duration: 缓存有效期（秒）
        """
        self.db_path = db_path
        self.cache_duration = cache_duration
        self.memory_cache = {}
        self.last_update_time = {}
        
        # 初始化交易所工厂
        self.exchange_factory = ExchangeFactory()
        
        # 初始化数据库
        self._init_database()
        
        logger.info("多交易所数据采集模块初始化完成")
    
    def _init_database(self) -> None:
        """初始化SQLite数据库，创建必要的表"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 创建币种信息表（添加exchange字段）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS coins (
                id TEXT,
                exchange TEXT,
                symbol TEXT NOT NULL,
                name TEXT,
                last_updated TIMESTAMP,
                PRIMARY KEY (exchange, symbol)
            )
            ''')
            
            # 创建价格历史表（添加exchange字段）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                volume_24h REAL,
                change_percentage_24h REAL,
                timestamp TIMESTAMP NOT NULL,
                FOREIGN KEY (exchange, symbol) REFERENCES coins(exchange, symbol)
            )
            ''')
            
            # 创建异常检测记录表（添加exchange字段）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS anomaly_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                old_price REAL NOT NULL,
                change_percentage REAL NOT NULL,
                volume_24h REAL,
                volume_change_percentage REAL,
                detected_at TIMESTAMP NOT NULL,
                is_notified BOOLEAN DEFAULT 0,
                FOREIGN KEY (exchange, symbol) REFERENCES coins(exchange, symbol)
            )
            ''')
            
            # 创建交易所信息表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS exchanges (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                last_updated TIMESTAMP
            )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("数据库初始化成功")
        except Exception as e:
            logger.error(f"数据库初始化失败: {str(e)}")
            raise
    
    def get_exchange(self, exchange_id: str) -> Optional[ExchangeAPI]:
        """获取指定交易所的API实例"""
        return self.exchange_factory.create_exchange(exchange_id)
    
    def get_all_exchanges(self) -> List[ExchangeAPI]:
        """获取所有交易所的API实例"""
        return self.exchange_factory.get_all_exchanges()
    
    def fetch_all_tickers_from_exchange(self, exchange_id: str) -> List[Dict]:
        """从指定交易所获取所有ticker数据"""
        exchange = self.get_exchange(exchange_id)
        if not exchange:
            logger.error(f"未找到交易所: {exchange_id}")
            return []
        
        logger.info(f"从{exchange.exchange_name}获取所有ticker数据")
        tickers = exchange.fetch_all_tickers()
        
        # 标准化数据
        normalized_tickers = []
        for ticker in tickers:
            normalized_ticker = exchange.normalize_ticker_data(ticker)
            normalized_tickers.append(normalized_ticker)
        
        return normalized_tickers
    
    def fetch_all_tickers_from_all_exchanges(self) -> Dict[str, List[Dict]]:
        """从所有交易所获取ticker数据"""
        result = {}
        
        for exchange in self.get_all_exchanges():
            exchange_id = exchange.exchange_id
            tickers = self.fetch_all_tickers_from_exchange(exchange_id)
            result[exchange_id] = tickers
            
            # 更新缓存
            cache_key = f"{exchange_id}_tickers"
            self.memory_cache[cache_key] = tickers
            self.last_update_time[cache_key] = time.time()
        
        return result
    
    def save_ticker_data(self, exchange_id: str, tickers: List[Dict]) -> None:
        """将ticker数据保存到数据库"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            current_time = datetime.now().isoformat()
            
            # 更新交易所信息
            exchange = self.get_exchange(exchange_id)
            if exchange:
                cursor.execute(
                    "INSERT OR REPLACE INTO exchanges (id, name, last_updated) VALUES (?, ?, ?)",
                    (exchange_id, exchange.exchange_name, current_time)
                )
            
            for ticker in tickers:
                symbol = ticker.get("symbol")
                if not symbol:
                    continue
                
                # 更新或插入币种信息
                cursor.execute(
                    "INSERT OR REPLACE INTO coins (id, exchange, symbol, last_updated) VALUES (?, ?, ?, ?)",
                    (f"{exchange_id}_{symbol}", exchange_id, symbol, current_time)
                )
                
                # 插入价格历史
                try:
                    price = ticker.get("price", 0)
                    volume_24h = ticker.get("volume_24h", 0)
                    change_percentage_24h = ticker.get("change_24h", 0)
                    
                    cursor.execute(
                        """
                        INSERT INTO price_history 
                        (exchange, symbol, price, volume_24h, change_percentage_24h, timestamp) 
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (exchange_id, symbol, price, volume_24h, change_percentage_24h, current_time)
                    )
                except (ValueError, TypeError) as e:
                    logger.warning(f"处理{exchange_id}交易所币种{symbol}数据时出错: {str(e)}")
                    continue
            
            conn.commit()
            conn.close()
            logger.info(f"成功保存{exchange_id}交易所{len(tickers)}个币种的ticker数据到数据库")
        except Exception as e:
            logger.error(f"保存{exchange_id}交易所ticker数据到数据库失败: {str(e)}")
    
    def get_latest_price_data(self, exchange_id: str = None, symbol: str = None) -> Dict:
        """
        获取最新价格数据
        
        Args:
            exchange_id: 交易所ID，如果为None则返回所有交易所数据
            symbol: 币种符号，如果为None则返回所有币种数据
            
        Returns:
            最新价格数据字典
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query_conditions = []
            query_params = []
            
            if exchange_id:
                query_conditions.append("ph.exchange = ?")
                query_params.append(exchange_id)
            
            if symbol:
                query_conditions.append("ph.symbol = ?")
                query_params.append(symbol)
            
            where_clause = ""
            if query_conditions:
                where_clause = f"WHERE {' AND '.join(query_conditions)}"
            
            cursor.execute(
                f"""
                SELECT ph.exchange, ph.symbol, ph.price, ph.volume_24h, ph.change_percentage_24h, ph.timestamp
                FROM price_history ph
                JOIN (
                    SELECT exchange, symbol, MAX(timestamp) as max_time
                    FROM price_history
                    {where_clause}
                    GROUP BY exchange, symbol
                ) latest
                ON ph.exchange = latest.exchange AND ph.symbol = latest.symbol AND ph.timestamp = latest.max_time
                """,
                query_params
            )
            
            results = cursor.fetchall()
            conn.close()
            
            data = {}
            for row in results:
                exchange = row[0]
                symbol = row[1]
                
                if exchange not in data:
                    data[exchange] = {}
                
                data[exchange][symbol] = {
                    "price": row[2],
                    "volume_24h": row[3],
                    "change_percentage_24h": row[4],
                    "timestamp": row[5]
                }
            
            return data
        except Exception as e:
            logger.error(f"获取最新价格数据失败: {str(e)}")
            return {}
    
    def update_data(self) -> Dict[str, bool]:
        """
        更新所有交易所的数据
        
        Returns:
            更新结果字典，键为交易所ID，值为更新是否成功
        """
        results = {}
        
        for exchange in self.get_all_exchanges():
            exchange_id = exchange.exchange_id
            try:
                tickers = self.fetch_all_tickers_from_exchange(exchange_id)
                if tickers:
                    self.save_ticker_data(exchange_id, tickers)
                    cache_key = f"{exchange_id}_tickers"
                    self.memory_cache[cache_key] = tickers
                    self.last_update_time[cache_key] = time.time()
                    results[exchange_id] = True
                else:
                    results[exchange_id] = False
            except Exception as e:
                logger.error(f"更新{exchange_id}交易所数据失败: {str(e)}")
                results[exchange_id] = False
        
        return results
    
    def get_cached_tickers(self, exchange_id: str) -> List[Dict]:
        """
        获取缓存的ticker数据，如果缓存过期则重新获取
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            ticker数据列表
        """
        cache_key = f"{exchange_id}_tickers"
        current_time = time.time()
        
        if (
            cache_key not in self.memory_cache or
            cache_key not in self.last_update_time or
            current_time - self.last_update_time[cache_key] > self.cache_duration
        ):
            logger.info(f"{exchange_id}交易所缓存过期，重新获取ticker数据")
            tickers = self.fetch_all_tickers_from_exchange(exchange_id)
            if tickers:
                self.memory_cache[cache_key] = tickers
                self.last_update_time[cache_key] = current_time
        
        return self.memory_cache.get(cache_key, [])
    
    def clean_old_data(self, days: int = 7) -> None:
        """
        清理旧数据以节省空间
        
        Args:
            days: 保留最近多少天的数据
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(
                "DELETE FROM price_history WHERE timestamp < datetime('now', '-' || ? || ' days')",
                (days,)
            )
            
            deleted_rows = cursor.rowcount
            conn.commit()
            conn.close()
            
            logger.info(f"已清理{deleted_rows}条{days}天前的旧数据")
        except Exception as e:
            logger.error(f"清理旧数据失败: {str(e)}")
```

## 4. 异常检测与告警系统更新

### 4.1 多交易所异常检测器

```python
class MultiExchangeAnomalyDetector:
    """多交易所异常检测类，负责检测多个交易所的价格和交易量异常"""
    
    def __init__(
        self, 
        collector: MultiExchangeDataCollector,
        price_change_threshold: float = 30.0,  # 价格变化阈值（百分比）
        volume_change_threshold: float = 200.0,  # 交易量变化阈值（百分比）
        min_price: float = 0.00001,  # 最小价格阈值，过滤低价值币种
        min_volume: float = 1000.0,  # 最小交易量阈值，过滤低流动性币种
        reference_period: int = 24  # 参考周期（小时）
    ):
        """
        初始化多交易所异常检测器
        
        Args:
            collector: 多交易所数据采集器实例
            price_change_threshold: 价格变化阈值（百分比）
            volume_change_threshold: 交易量变化阈值（百分比）
            min_price: 最小价格阈值
            min_volume: 最小交易量阈值
            reference_period: 参考周期（小时）
        """
        self.collector = collector
        self.price_change_threshold = price_change_threshold
        self.volume_change_threshold = volume_change_threshold
        self.min_price = min_price
        self.min_volume = min_volume
        self.reference_period = reference_period
        self.detected_anomalies = defaultdict(list)  # 用于存储已检测到的异常
        
        logger.info(f"多交易所异常检测模块初始化完成，价格变化阈值: {price_change_threshold}%，交易量变化阈值: {volume_change_threshold}%")
    
    def detect_price_anomalies(self, exchange_id: str) -> List[Dict]:
        """
        检测指定交易所的价格异常
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            异常列表，每个异常包含交易所、币种、价格变化等信息
        """
        logger.info(f"开始检测{exchange_id}交易所价格异常")
        anomalies = []
        
        try:
            # 获取交易所实例
            exchange = self.collector.get_exchange(exchange_id)
            if not exchange:
                logger.error(f"未找到交易所: {exchange_id}")
                return anomalies
            
            # 获取最新价格数据
            latest_data = self.collector.get_latest_price_data(exchange_id)
            if not latest_data or exchange_id not in latest_data:
                logger.warning(f"无法获取{exchange_id}交易所最新价格数据")
                return anomalies
            
            # 获取所有币种的ticker数据
            tickers = self.collector.get_cached_tickers(exchange_id)
            if not tickers:
                logger.warning(f"无法获取{exchange_id}交易所缓存的ticker数据")
                return anomalies
            
            # 处理每个币种
            for ticker in tickers:
                symbol = ticker.get("symbol")
                if not symbol:
                    continue
                
                try:
                    # 获取当前价格
                    current_price = ticker.get("price", 0)
                    if current_price < self.min_price:
                        continue  # 忽略低价值币种
                    
                    # 获取历史价格数据
                    conn = sqlite3.connect(self.collector.db_path)
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    
                    cursor.execute(
                        """
                        SELECT price, timestamp
                        FROM price_history
                        WHERE exchange = ? AND symbol = ? AND timestamp >= datetime('now', '-' || ? || ' hours')
                        ORDER BY timestamp ASC
                        """,
                        (exchange_id, symbol, self.reference_period)
                    )
                    
                    historical_data = cursor.fetchall()
                    conn.close()
                    
                    if not historical_data:
                        continue  # 没有历史数据，跳过
                    
                    # 找到最早的价格记录作为参考
                    reference_price = None
                    for data in historical_data:
                        if data["price"] > 0:
                            reference_price = data["price"]
                            break
                    
                    if not reference_price:
                        continue  # 没有有效的参考价格，跳过
                    
                    # 计算价格变化百分比
                    price_change_pct = ((current_price - reference_price) / reference_price) * 100
                    
                    # 检查是否超过阈值
                    if abs(price_change_pct) >= self.price_change_threshold:
                        # 检查是否已经报告过这个异常
                        anomaly_key = f"{exchange_id}_{symbol}_price"
                        if self._is_already_reported(anomaly_key, price_change_pct):
                            continue
                        
                        # 记录异常
                        anomaly = {
                            "exchange": exchange_id,
                            "exchange_name": exchange.exchange_name,
                            "symbol": symbol,
                            "current_price": current_price,
                            "reference_price": reference_price,
                            "price_change_pct": price_change_pct,
                            "volume_24h": ticker.get("volume_24h", 0),
                            "detected_at": datetime.now().isoformat(),
                            "type": "price",
                            "exchange_url": exchange.get_exchange_url(symbol)
                        }
                        
                        anomalies.append(anomaly)
                        self._record_anomaly(anomaly_key, price_change_pct)
                        logger.info(f"检测到{exchange.exchange_name}交易所价格异常: {symbol}, 变化: {price_change_pct:.2f}%")
                
                except (ValueError, TypeError, KeyError) as e:
                    logger.warning(f"处理{exchange.exchange_name}交易所币种{symbol}时出错: {str(e)}")
                    continue
            
            logger.info(f"{exchange.exchange_name}交易所价格异常检测完成，发现{len(anomalies)}个异常")
            return anomalies
        
        except Exception as e:
            logger.error(f"{exchange_id}交易所价格异常检测过程中发生错误: {str(e)}")
            return anomalies
    
    def detect_volume_anomalies(self, exchange_id: str) -> List[Dict]:
        """
        检测指定交易所的交易量异常
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            异常列表，每个异常包含交易所、币种、交易量变化等信息
        """
        logger.info(f"开始检测{exchange_id}交易所交易量异常")
        anomalies = []
        
        try:
            # 获取交易所实例
            exchange = self.collector.get_exchange(exchange_id)
            if not exchange:
                logger.error(f"未找到交易所: {exchange_id}")
                return anomalies
            
            # 获取最新价格数据
            latest_data = self.collector.get_latest_price_data(exchange_id)
            if not latest_data or exchange_id not in latest_data:
                logger.warning(f"无法获取{exchange_id}交易所最新价格数据")
                return anomalies
            
            # 获取所有币种的ticker数据
            tickers = self.collector.get_cached_tickers(exchange_id)
            if not tickers:
                logger.warning(f"无法获取{exchange_id}交易所缓存的ticker数据")
                return anomalies
            
            # 处理每个币种
            for ticker in tickers:
                symbol = ticker.get("symbol")
                if not symbol:
                    continue
                
                try:
                    # 获取当前交易量
                    current_volume = ticker.get("volume_24h", 0)
                    if current_volume < self.min_volume:
                        continue  # 忽略低流动性币种
                    
                    # 获取历史交易量数据
                    conn = sqlite3.connect(self.collector.db_path)
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    
                    cursor.execute(
                        """
                        SELECT volume_24h, timestamp
                        FROM price_history
                        WHERE exchange = ? AND symbol = ? AND timestamp >= datetime('now', '-' || ? || ' hours')
                        ORDER BY timestamp ASC
                        """,
                        (exchange_id, symbol, self.reference_period)
                    )
                    
                    historical_data = cursor.fetchall()
                    conn.close()
                    
                    if not historical_data or len(historical_data) < 2:
                        continue  # 没有足够的历史数据，跳过
                    
                    # 计算平均交易量作为参考
                    volumes = [data["volume_24h"] for data in historical_data if data["volume_24h"] > 0]
                    if not volumes:
                        continue
                    
                    # 使用移动平均线作为参考
                    reference_volume = np.mean(volumes)
                    if reference_volume <= 0:
                        continue
                    
                    # 计算交易量变化百分比
                    volume_change_pct = ((current_volume - reference_volume) / reference_volume) * 100
                    
                    # 检查是否超过阈值
                    if volume_change_pct >= self.volume_change_threshold:
                        # 检查是否已经报告过这个异常
                        anomaly_key = f"{exchange_id}_{symbol}_volume"
                        if self._is_already_reported(anomaly_key, volume_change_pct):
                            continue
                        
                        # 记录异常
                        anomaly = {
                            "exchange": exchange_id,
                            "exchange_name": exchange.exchange_name,
                            "symbol": symbol,
                            "current_volume": current_volume,
                            "reference_volume": reference_volume,
                            "volume_change_pct": volume_change_pct,
                            "current_price": ticker.get("price", 0),
                            "detected_at": datetime.now().isoformat(),
                            "type": "volume",
                            "exchange_url": exchange.get_exchange_url(symbol)
                        }
                        
                        anomalies.append(anomaly)
                        self._record_anomaly(anomaly_key, volume_change_pct)
                        logger.info(f"检测到{exchange.exchange_name}交易所交易量异常: {symbol}, 变化: {volume_change_pct:.2f}%")
                
                except (ValueError, TypeError, KeyError) as e:
                    logger.warning(f"处理{exchange.exchange_name}交易所币种{symbol}时出错: {str(e)}")
                    continue
            
            logger.info(f"{exchange.exchange_name}交易所交易量异常检测完成，发现{len(anomalies)}个异常")
            return anomalies
        
        except Exception as e:
            logger.error(f"{exchange_id}交易所交易量异常检测过程中发生错误: {str(e)}")
            return anomalies
    
    def detect_all_anomalies_for_exchange(self, exchange_id: str) -> List[Dict]:
        """
        检测指定交易所的所有类型异常
        
        Args:
            exchange_id: 交易所ID
            
        Returns:
            异常列表
        """
        price_anomalies = self.detect_price_anomalies(exchange_id)
        volume_anomalies = self.detect_volume_anomalies(exchange_id)
        
        all_anomalies = price_anomalies + volume_anomalies
        
        # 按检测时间排序
        all_anomalies.sort(key=lambda x: x["detected_at"], reverse=True)
        
        return all_anomalies
    
    def detect_all_anomalies(self) -> List[Dict]:
        """
        检测所有交易所的所有类型异常
        
        Returns:
            所有异常的列表
        """
        all_anomalies = []
        
        for exchange_id in self.collector.exchange_factory.get_exchange_ids():
            exchange_anomalies = self.detect_all_anomalies_for_exchange(exchange_id)
            all_anomalies.extend(exchange_anomalies)
        
        # 按检测时间排序
        all_anomalies.sort(key=lambda x: x["detected_at"], reverse=True)
        
        return all_anomalies
    
    def _is_already_reported(self, anomaly_key: str, change_pct: float) -> bool:
        """
        检查异常是否已经报告过
        
        Args:
            anomaly_key: 异常键（格式：exchange_symbol_type）
            change_pct: 变化百分比
            
        Returns:
            是否已经报告过
        """
        # 检查是否已经报告过类似的异常
        for reported_change in self.detected_anomalies[anomaly_key]:
            # 如果变化方向相同且差异不大，认为是同一个异常
            if (change_pct > 0 and reported_change > 0) or (change_pct < 0 and reported_change < 0):
                if abs(abs(change_pct) - abs(reported_change)) < self.price_change_threshold / 2:
                    return True
        
        return False
    
    def _record_anomaly(self, anomaly_key: str, change_pct: float) -> None:
        """
        记录已检测到的异常
        
        Args:
            anomaly_key: 异常键（格式：exchange_symbol_type）
            change_pct: 变化百分比
        """
        self.detected_anomalies[anomaly_key].append(change_pct)
        
        # 限制记录数量，避免内存泄漏
        if len(self.detected_anomalies[anomaly_key]) > 10:
            self.detected_anomalies[anomaly_key] = self.detected_anomalies[anomaly_key][-10:]
```

### 4.2 多交易所告警格式化

```python
class MultiExchangeAlerter:
    """多交易所告警类，负责格式化和发送多交易所异常告警"""
    
    def __init__(self, telegram_alerter):
        """
        初始化多交易所告警器
        
        Args:
            telegram_alerter: Telegram告警器实例
        """
        self.telegram_alerter = telegram_alerter
        logger.info("多交易所告警模块初始化完成")
    
    def format_alert_message(self, anomaly: Dict) -> str:
        """
        格式化告警消息，区分不同交易所
        
        Args:
            anomaly: 异常数据
            
        Returns:
            格式化后的消息
        """
        try:
            # 获取异常类型、交易所和币种
            anomaly_type = anomaly.get("type", "unknown")
            exchange = anomaly.get("exchange", "unknown")
            exchange_name = anomaly.get("exchange_name", exchange)
            symbol = anomaly.get("symbol", "未知币种")
            
            # 构建消息标题（添加交易所标识）
            if anomaly_type == "price":
                change_pct = anomaly.get("price_change_pct", 0)
                direction = "上涨" if change_pct > 0 else "下跌"
                title = f"🚨 [{exchange_name}] 价格异动警报: {symbol} {direction} {abs(change_pct):.2f}%"
            elif anomaly_type == "volume":
                change_pct = anomaly.get("volume_change_pct", 0)
                title = f"📊 [{exchange_name}] 交易量异动警报: {symbol} 增加 {change_pct:.2f}%"
            else:
                title = f"⚠️ [{exchange_name}] 异常警报: {symbol}"
            
            # 构建消息内容
            message_parts = [title, ""]
            
            # 添加交易所信息
            message_parts.append(f"交易所: {exchange_name}")
            
            # 添加价格信息
            if anomaly_type == "price":
                current_price = anomaly.get("current_price", 0)
                reference_price = anomaly.get("reference_price", 0)
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"参考价格: {reference_price}")
                message_parts.append(f"变化幅度: {change_pct:.2f}%")
                
                # 添加交易量信息
                volume_24h = anomaly.get("volume_24h", 0)
                message_parts.append(f"24小时交易量: {volume_24h}")
            
            # 添加交易量信息
            elif anomaly_type == "volume":
                current_volume = anomaly.get("current_volume", 0)
                reference_volume = anomaly.get("reference_volume", 0)
                current_price = anomaly.get("current_price", 0)
                
                message_parts.append(f"当前价格: {current_price}")
                message_parts.append(f"当前交易量: {current_volume}")
                message_parts.append(f"参考交易量: {reference_volume}")
                message_parts.append(f"交易量增加: {change_pct:.2f}%")
            
            # 添加检测时间
            detected_at = anomaly.get("detected_at", datetime.now().isoformat())
            try:
                # 尝试将ISO格式转换为更易读的格式
                dt = datetime.fromisoformat(detected_at)
                formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                formatted_time = detected_at
            
            message_parts.append("")
            message_parts.append(f"检测时间: {formatted_time}")
            
            # 添加交易所链接
            exchange_url = anomaly.get("exchange_url", "")
            if exchange_url:
                message_parts.append("")
                message_parts.append(f"🔗 [在{exchange_name}上查看]({exchange_url})")
            
            # 合并消息
            return "\n".join(message_parts)
        
        except Exception as e:
            logger.error(f"格式化告警消息失败: {str(e)}")
            return f"[{anomaly.get('exchange_name', '未知交易所')}] 异常警报: {anomaly.get('symbol', '未知币种')}"
    
    def send_anomaly_alert(self, anomaly: Dict) -> bool:
        """
        发送异常告警
        
        Args:
            anomaly: 异常数据
            
        Returns:
            发送是否成功
        """
        message = self.format_alert_message(anomaly)
        return self.telegram_alerter.send_message(message)
    
    def send_batch_alerts(self, anomalies: List[Dict], max_batch: int = 5) -> int:
        """
        批量发送异常告警
        
        Args:
            anomalies: 异常列表
            max_batch: 最大批量发送数量
            
        Returns:
            成功发送的数量
        """
        if not anomalies:
            return 0
        
        # 限制批量发送数量
        anomalies_to_send = anomalies[:max_batch]
        
        success_count = 0
        for anomaly in anomalies_to_send:
            if self.send_anomaly_alert(anomaly):
                success_count += 1
                # 添加短暂延迟，避免触发Telegram限流
                time.sleep(1)
        
        logger.info(f"批量发送异常告警完成，成功: {success_count}/{len(anomalies_to_send)}")
        return success_count
```

## 5. 主程序更新设计

```python
class MultiExchangeCryptoMonitor:
    """多交易所加密货币异动监控系统主类"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化多交易所加密货币异动监控系统
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # 初始化模块
        self.data_collector = MultiExchangeDataCollector()
        self.anomaly_detector = MultiExchangeAnomalyDetector(self.data_collector)
        
        # 初始化告警模块
        if enhanced_telegram_available:
            self.telegram_alerter = EnhancedMultiTelegramAlerter()
            logger.info("使用增强版多账号Telegram警报器")
        else:
            self.telegram_alerter = TelegramAlerter()
            logger.info("使用标准Telegram警报器")
        
        self.multi_exchange_alerter = MultiExchangeAlerter(self.telegram_alerter)
        
        # 运行标志
        self.running = False
        
        logger.info("多交易所加密货币异动监控系统初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        default_config = {
            "check_interval": 50,  # 检查间隔（秒）
            "price_threshold": 30.0,  # 价格异动阈值（百分比）
            "volume_threshold": 200.0,  # 交易量异动阈值（百分比）
            "enabled_exchanges": ["gateio", "binance"],  # 启用的交易所
            "excluded_symbols": []  # 排除的币种符号
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # 合并默认配置和加载的配置
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    
                    logger.info(f"从配置文件加载配置成功")
                    return config
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，使用默认配置")
                return default_config
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
            return default_config
    
    def start(self) -> None:
        """启动监控系统"""
        if self.running:
            logger.warning("监控系统已经在运行中")
            return
        
        self.running = True
        logger.info("启动多交易所监控系统")
        
        try:
            # 发送启动通知
            if self.telegram_alerter.is_configured():
                start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if timezone_utils_available:
                    start_time = format_time()
                
                message = f"🚀 多交易所加密货币异动监控系统已启动\n\n"
                message += f"🕒 启动时间: {start_time}\n"
                message += f"⚙️ 价格异动阈值: {self.config['price_threshold']}%\n"
                message += f"⚙️ 交易量异动阈值: {self.config['volume_threshold']}%\n"
                message += f"⚙️ 检查间隔: {self.config['check_interval']}秒\n"
                
                # 添加启用的交易所信息
                enabled_exchanges = self.config.get("enabled_exchanges", [])
                if enabled_exchanges:
                    message += f"\n📈 已启用交易所:\n"
                    for exchange_id in enabled_exchanges:
                        exchange = self.data_collector.get_exchange(exchange_id)
                        if exchange:
                            message += f"  • {exchange.exchange_name}\n"
                
                self.telegram_alerter.send_message(message)
            
            # 主监控循环
            while self.running:
                try:
                    # 获取所有交易所的ticker数据
                    logger.info("获取所有交易所ticker数据")
                    self.data_collector.update_data()
                    
                    # 检测异常
                    logger.info("检测异常")
                    anomalies = self.anomaly_detector.detect_all_anomalies()
                    
                    # 处理异常
                    for anomaly in anomalies:
                        self._process_anomaly(anomaly)
                    
                    # 等待下一次检查
                    check_interval = self.config["check_interval"]
                    logger.info(f"等待 {check_interval}秒 后进行下一次检查")
                    
                    # 分段等待，以便能够及时响应停止信号
                    for _ in range(check_interval):
                        if not self.running:
                            break
                        time.sleep(1)
                except Exception as e:
                    logger.error(f"监控循环异常: {str(e)}")
                    time.sleep(10)  # 出错后等待一段时间再继续
        except KeyboardInterrupt:
            logger.info("接收到键盘中断信号，停止监控系统")
        finally:
            self.running = False
            logger.info("监控系统已停止")
    
    def _process_anomaly(self, anomaly: Dict[str, Any]) -> None:
        """
        处理异常
        
        Args:
            anomaly: 异常数据
        """
        exchange = anomaly.get("exchange", "")
        exchange_name = anomaly.get("exchange_name", exchange)
        symbol = anomaly.get("symbol", "")
        logger.info(f"处理异常: [{exchange_name}] {symbol}")
        
        try:
            # 发送警报
            if self.telegram_alerter.is_configured():
                self.multi_exchange_alerter.send_anomaly_alert(anomaly)
        except Exception as e:
            logger.error(f"处理异常失败: {str(e)}")
```

## 6. 实施计划

### 6.1 实施步骤

1. **创建交易所API抽象层**
   - 实现`ExchangeAPI`抽象基类
   - 实现`ExchangeFactory`工厂类

2. **重构现有Gate.io实现**
   - 将现有的`GateioDataCollector`重构为`GateioExchangeAPI`
   - 确保与抽象接口兼容

3. **实现币安适配器**
   - 实现`BinanceExchangeAPI`类
   - 测试币安API连接和数据获取

4. **实现多交易所数据采集器**
   - 实现`MultiExchangeDataCollector`类
   - 更新数据库结构，支持多交易所数据

5. **更新异常检测和告警系统**
   - 实现`MultiExchangeAnomalyDetector`类
   - 实现`MultiExchangeAlerter`类，支持区分交易所的告警格式

6. **更新主程序**
   - 实现`MultiExchangeCryptoMonitor`类
   - 更新配置管理，支持交易所启用/禁用

7. **测试和验证**
   - 测试多交易所数据采集
   - 测试异常检测
   - 测试告警通知

### 6.2 优先级和时间估计

1. **高优先级**（1-2天）
   - 交易所API抽象层
   - 币安适配器实现
   - 基本多交易所数据采集

2. **中优先级**（2-3天）
   - 异常检测系统更新
   - 告警系统更新
   - 主程序更新

3. **低优先级**（3-5天）
   - 完善错误处理
   - 添加更多交易所支持
   - 优化性能和内存使用

## 7. 总结

本设计方案提供了一个可扩展的多交易所监控架构，通过抽象接口和适配器模式，实现了对不同交易所API的统一访问。主要特点包括：

1. **可扩展性**：通过抽象接口和工厂模式，可以轻松添加新的交易所支持
2. **数据标准化**：统一不同交易所的数据格式，简化后续处理
3. **清晰的告警区分**：在告警通知中明确标识不同交易所的信息
4. **兼容性**：与现有系统保持兼容，最小化代码修改

实施该方案后，系统将能够同时监控Gate.io和币安等多个交易所的加密货币价格和交易量异动，并通过Telegram发送清晰区分交易所来源的告警通知。
