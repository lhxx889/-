#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Hysteria2 代理管理模块
提供 Hysteria2 代理服务器的配置和连接管理功能
"""

import json
import uuid
import requests
import logging
import time
import re
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)

class Hysteria2ProxyManager:
    """Hysteria2 代理管理器"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        self.servers = []
        self.current_server = None
        self.load_servers()
    
    def load_servers(self):
        """从配置和数据库加载服务器列表"""
        try:
            # 从配置文件加载
            hy2_config = self.config.get('proxy.hysteria2', {})
            config_servers = hy2_config.get('servers', [])
            
            # 从数据库加载
            db_servers = self.db.get_proxy_servers('hysteria2')
            
            # 合并服务器列表
            self.servers = []
            
            # 添加配置文件中的服务器
            for server in config_servers:
                if self.validate_hysteria2_config(server):
                    self.servers.append(server)
            
            # 添加数据库中的服务器
            for db_server in db_servers:
                try:
                    server_config = json.loads(db_server['config'])
                    server_config['id'] = db_server['server_id']
                    server_config['name'] = db_server['name']
                    server_config['priority'] = db_server['priority']
                    server_config['active'] = bool(db_server['active'])
                    
                    if self.validate_hysteria2_config(server_config):
                        self.servers.append(server_config)
                except Exception as e:
                    logger.error(f"加载数据库服务器配置失败: {e}")
            
            # 按优先级排序
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已加载 {len(self.servers)} 个 Hysteria2 服务器")
            
        except Exception as e:
            logger.error(f"加载 Hysteria2 服务器失败: {e}")
            self.servers = []
    
    def validate_hysteria2_config(self, config: Dict) -> bool:
        """验证 Hysteria2 配置"""
        try:
            # 必填字段检查
            required_fields = ['server', 'auth']
            for field in required_fields:
                if field not in config:
                    logger.error(f"Hysteria2 配置缺少必填字段: {field}")
                    return False
            
            # 服务器地址验证
            server = config['server']
            if not self._is_valid_server_address(server):
                logger.error(f"无效的服务器地址: {server}")
                return False
            
            # 认证信息验证
            auth = config['auth']
            if not auth or not isinstance(auth, str):
                logger.error("认证信息不能为空")
                return False
            
            # 带宽设置验证
            if 'bandwidth' in config:
                bandwidth = config['bandwidth']
                if isinstance(bandwidth, dict):
                    for direction in ['up', 'down']:
                        if direction in bandwidth:
                            if not self._is_valid_bandwidth(bandwidth[direction]):
                                logger.error(f"无效的带宽设置: {bandwidth[direction]}")
                                return False
            
            # TLS 设置验证
            if 'tls' in config:
                tls_config = config['tls']
                if isinstance(tls_config, dict):
                    if 'sni' in tls_config and not tls_config['sni']:
                        logger.error("SNI 不能为空")
                        return False
            
            return True
            
        except Exception as e:
            logger.error(f"Hysteria2 配置验证失败: {e}")
            return False
    
    def _is_valid_server_address(self, server: str) -> bool:
        """验证服务器地址格式 (host:port)"""
        pattern = r'^[a-zA-Z0-9.-]+:\d+$'
        if not re.match(pattern, server):
            return False
        
        try:
            host, port = server.rsplit(':', 1)
            port_num = int(port)
            return 1 <= port_num <= 65535 and len(host) > 0
        except ValueError:
            return False
    
    def _is_valid_bandwidth(self, bandwidth: str) -> bool:
        """验证带宽格式"""
        pattern = r'^\d+\s*(bps|kbps|mbps|gbps)$'
        return bool(re.match(pattern, bandwidth.lower().replace(' ', '')))
    
    def add_server(self, config: Dict) -> Dict:
        """添加 Hysteria2 服务器"""
        try:
            # 生成服务器 ID
            if 'id' not in config:
                config['id'] = f"hy2-{uuid.uuid4().hex[:8]}"
            
            # 设置默认值
            config.setdefault('name', f"Hysteria2 服务器 {len(self.servers) + 1}")
            config.setdefault('priority', 1)
            config.setdefault('active', True)
            config.setdefault('fastOpen', True)
            config.setdefault('lazy', False)
            
            # 设置默认 TLS 配置
            if 'tls' not in config:
                config['tls'] = {
                    'insecure': False
                }
            
            # 设置默认 QUIC 配置
            if 'quic' not in config:
                config['quic'] = {
                    'initStreamReceiveWindow': 8388608,
                    'maxStreamReceiveWindow': 8388608,
                    'initConnReceiveWindow': 20971520,
                    'maxConnReceiveWindow': 20971520,
                    'maxIdleTimeout': '30s',
                    'maxIncomingStreams': 1024,
                    'disablePathMTUDiscovery': False
                }
            
            # 设置默认带宽
            if 'bandwidth' not in config:
                config['bandwidth'] = {
                    'up': '100 mbps',
                    'down': '100 mbps'
                }
            
            # 验证配置
            if not self.validate_hysteria2_config(config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 保存到数据库
            self.db.add_proxy_server(
                protocol='hysteria2',
                server_id=config['id'],
                name=config['name'],
                config=json.dumps(config),
                priority=config['priority'],
                active=config['active']
            )
            
            # 添加到内存列表
            self.servers.append(config)
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已添加 Hysteria2 服务器: {config['name']}")
            
            return {
                'success': True,
                'server_id': config['id'],
                'message': f"Hysteria2 服务器 '{config['name']}' 添加成功"
            }
            
        except Exception as e:
            logger.error(f"添加 Hysteria2 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def update_server(self, server_id: str, config: Dict) -> Dict:
        """更新 Hysteria2 服务器配置"""
        try:
            # 查找服务器
            server_index = None
            for i, server in enumerate(self.servers):
                if server.get('id') == server_id:
                    server_index = i
                    break
            
            if server_index is None:
                return {'success': False, 'message': '服务器不存在'}
            
            # 更新配置
            updated_config = self.servers[server_index].copy()
            updated_config.update(config)
            updated_config['id'] = server_id  # 确保 ID 不变
            
            # 验证配置
            if not self.validate_hysteria2_config(updated_config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 更新数据库
            self.db.update_proxy_server(
                server_id=server_id,
                name=updated_config['name'],
                config=json.dumps(updated_config),
                priority=updated_config['priority'],
                active=updated_config['active']
            )
            
            # 更新内存列表
            self.servers[server_index] = updated_config
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已更新 Hysteria2 服务器: {updated_config['name']}")
            
            return {
                'success': True,
                'message': f"Hysteria2 服务器 '{updated_config['name']}' 更新成功"
            }
            
        except Exception as e:
            logger.error(f"更新 Hysteria2 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def delete_server(self, server_id: str) -> Dict:
        """删除 Hysteria2 服务器"""
        try:
            # 查找服务器
            server_index = None
            server_name = None
            for i, server in enumerate(self.servers):
                if server.get('id') == server_id:
                    server_index = i
                    server_name = server.get('name', server_id)
                    break
            
            if server_index is None:
                return {'success': False, 'message': '服务器不存在'}
            
            # 从数据库删除
            self.db.delete_proxy_server(server_id)
            
            # 从内存列表删除
            del self.servers[server_index]
            
            # 如果删除的是当前服务器，清除当前服务器
            if self.current_server and self.current_server.get('id') == server_id:
                self.current_server = None
            
            logger.info(f"已删除 Hysteria2 服务器: {server_name}")
            
            return {
                'success': True,
                'message': f"Hysteria2 服务器 '{server_name}' 删除成功"
            }
            
        except Exception as e:
            logger.error(f"删除 Hysteria2 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_servers(self) -> List[Dict]:
        """获取所有 Hysteria2 服务器"""
        return self.servers.copy()
    
    def get_server(self, server_id: str) -> Optional[Dict]:
        """获取指定的 Hysteria2 服务器"""
        for server in self.servers:
            if server.get('id') == server_id:
                return server.copy()
        return None
    
    def test_connection(self, server_id: str) -> Dict:
        """测试 Hysteria2 服务器连接"""
        try:
            server = self.get_server(server_id)
            if not server:
                return {'success': False, 'message': '服务器不存在'}
            
            # 构建代理 URL
            proxy_url = self._build_proxy_url(server)
            if not proxy_url:
                return {'success': False, 'message': '无法构建代理 URL'}
            
            # 测试连接
            start_time = time.time()
            
            proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
            
            response = requests.get(
                'http://httpbin.org/ip',
                proxies=proxies,
                timeout=10
            )
            
            end_time = time.time()
            response_time = int((end_time - start_time) * 1000)
            
            if response.status_code == 200:
                data = response.json()
                external_ip = data.get('origin', 'Unknown')
                
                # 记录连接日志
                self.db.log_proxy_connection(
                    server_id=server_id,
                    protocol='hysteria2',
                    response_time=response_time,
                    success=True,
                    external_ip=external_ip
                )
                
                return {
                    'success': True,
                    'response_time': response_time,
                    'external_ip': external_ip,
                    'message': 'Hysteria2 连接测试成功'
                }
            else:
                error_msg = f'HTTP 错误: {response.status_code}'
                
                # 记录连接日志
                self.db.log_proxy_connection(
                    server_id=server_id,
                    protocol='hysteria2',
                    response_time=response_time,
                    success=False,
                    error_message=error_msg
                )
                
                return {'success': False, 'message': error_msg}
                
        except requests.exceptions.ProxyError as e:
            error_msg = f'代理连接失败: {str(e)}'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='hysteria2',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
            
        except requests.exceptions.Timeout:
            error_msg = '连接超时'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='hysteria2',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
            
        except Exception as e:
            error_msg = f'未知错误: {str(e)}'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='hysteria2',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
    
    def _build_proxy_url(self, server: Dict) -> Optional[str]:
        """构建代理 URL"""
        try:
            # 注意：这里只是示例，实际的 Hysteria2 代理需要专门的客户端
            # 在实际应用中，需要集成 hysteria2 客户端
            
            # 这里返回一个占位符 URL，实际实现需要根据具体的代理客户端来构建
            # 简化的 URL 构建（实际需要更复杂的处理）
            return f"socks5://127.0.0.1:1080"  # 假设本地有 Hysteria2 客户端监听此端口
            
        except Exception as e:
            logger.error(f"构建 Hysteria2 代理 URL 失败: {e}")
            return None
    
    def get_proxy_config(self, server_id: str) -> Optional[Dict]:
        """获取代理配置"""
        server = self.get_server(server_id)
        if not server:
            return None
        
        proxy_url = self._build_proxy_url(server)
        if not proxy_url:
            return None
        
        return {
            'http': proxy_url,
            'https': proxy_url
        }
    
    def health_check(self) -> Dict:
        """健康检查所有服务器"""
        results = []
        
        for server in self.servers:
            if not server.get('active', True):
                continue
            
            server_id = server.get('id')
            result = self.test_connection(server_id)
            
            results.append({
                'server_id': server_id,
                'name': server.get('name', server_id),
                'healthy': result['success'],
                'response_time': result.get('response_time'),
                'error_message': result.get('message') if not result['success'] else None
            })
        
        return {
            'success': True,
            'protocol': 'hysteria2',
            'results': results,
            'total_servers': len(self.servers),
            'healthy_servers': len([r for r in results if r['healthy']])
        }
    
    def get_best_server(self) -> Optional[Dict]:
        """获取最佳服务器"""
        active_servers = [s for s in self.servers if s.get('active', True)]
        if not active_servers:
            return None
        
        # 按优先级返回第一个活跃服务器
        return active_servers[0]
    
    def set_current_server(self, server_id: str) -> Dict:
        """设置当前使用的服务器"""
        server = self.get_server(server_id)
        if not server:
            return {'success': False, 'message': '服务器不存在'}
        
        self.current_server = server
        
        return {
            'success': True,
            'message': f"已切换到 Hysteria2 服务器: {server['name']}"
        }
    
    def get_current_server(self) -> Optional[Dict]:
        """获取当前使用的服务器"""
        return self.current_server.copy() if self.current_server else None
    
    def generate_config_file(self, server_id: str) -> Optional[str]:
        """生成 Hysteria2 配置文件"""
        server = self.get_server(server_id)
        if not server:
            return None
        
        try:
            config = {
                'server': server['server'],
                'auth': server['auth']
            }
            
            # 添加 TLS 配置
            if 'tls' in server:
                config['tls'] = server['tls']
            
            # 添加 QUIC 配置
            if 'quic' in server:
                config['quic'] = server['quic']
            
            # 添加带宽配置
            if 'bandwidth' in server:
                config['bandwidth'] = server['bandwidth']
            
            # 添加其他配置
            for key in ['fastOpen', 'lazy', 'hopInterval']:
                if key in server:
                    config[key] = server[key]
            
            # 添加 SOCKS5 监听配置
            config['socks5'] = {
                'listen': '127.0.0.1:1080'
            }
            
            return json.dumps(config, indent=2, ensure_ascii=False)
            
        except Exception as e:
            logger.error(f"生成 Hysteria2 配置文件失败: {e}")
            return None

