#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VLESS 代理管理模块
提供 VLESS 代理服务器的配置和连接管理功能
"""

import json
import uuid
import requests
import logging
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse
import re

logger = logging.getLogger(__name__)

class VLESSProxyManager:
    """VLESS 代理管理器"""
    
    def __init__(self, config_manager, db_manager):
        self.config = config_manager
        self.db = db_manager
        self.servers = []
        self.current_server = None
        self.load_servers()
    
    def load_servers(self):
        """从配置和数据库加载服务器列表"""
        try:
            # 从配置文件加载
            vless_config = self.config.get('proxy.vless', {})
            config_servers = vless_config.get('servers', [])
            
            # 从数据库加载
            db_servers = self.db.get_proxy_servers('vless')
            
            # 合并服务器列表
            self.servers = []
            
            # 添加配置文件中的服务器
            for server in config_servers:
                if self.validate_vless_config(server):
                    self.servers.append(server)
            
            # 添加数据库中的服务器
            for db_server in db_servers:
                try:
                    server_config = json.loads(db_server['config'])
                    server_config['id'] = db_server['server_id']
                    server_config['name'] = db_server['name']
                    server_config['priority'] = db_server['priority']
                    server_config['active'] = bool(db_server['active'])
                    
                    if self.validate_vless_config(server_config):
                        self.servers.append(server_config)
                except Exception as e:
                    logger.error(f"加载数据库服务器配置失败: {e}")
            
            # 按优先级排序
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已加载 {len(self.servers)} 个 VLESS 服务器")
            
        except Exception as e:
            logger.error(f"加载 VLESS 服务器失败: {e}")
            self.servers = []
    
    def validate_vless_config(self, config: Dict) -> bool:
        """验证 VLESS 配置"""
        try:
            # 必填字段检查
            required_fields = ['address', 'port', 'uuid']
            for field in required_fields:
                if field not in config:
                    logger.error(f"VLESS 配置缺少必填字段: {field}")
                    return False
            
            # 地址验证
            address = config['address']
            if not self._is_valid_address(address):
                logger.error(f"无效的服务器地址: {address}")
                return False
            
            # 端口验证
            port = config['port']
            if not isinstance(port, int) or port < 1 or port > 65535:
                logger.error(f"无效的端口号: {port}")
                return False
            
            # UUID 验证
            uuid_str = config['uuid']
            if not self._is_valid_uuid(uuid_str):
                logger.error(f"无效的 UUID: {uuid_str}")
                return False
            
            # 网络类型验证
            network = config.get('network', 'tcp')
            if network not in ['tcp', 'ws', 'grpc']:
                logger.error(f"不支持的网络类型: {network}")
                return False
            
            # 安全类型验证
            security = config.get('security', 'none')
            if security not in ['none', 'tls']:
                logger.error(f"不支持的安全类型: {security}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"VLESS 配置验证失败: {e}")
            return False
    
    def _is_valid_address(self, address: str) -> bool:
        """验证地址格式"""
        # 域名格式验证
        domain_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        # IP 地址格式验证
        ip_pattern = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        
        return bool(re.match(domain_pattern, address) or re.match(ip_pattern, address))
    
    def _is_valid_uuid(self, uuid_str: str) -> bool:
        """验证 UUID 格式"""
        try:
            uuid.UUID(uuid_str)
            return True
        except ValueError:
            return False
    
    def add_server(self, config: Dict) -> Dict:
        """添加 VLESS 服务器"""
        try:
            # 生成服务器 ID
            if 'id' not in config:
                config['id'] = f"vless-{uuid.uuid4().hex[:8]}"
            
            # 设置默认值
            config.setdefault('name', f"VLESS 服务器 {len(self.servers) + 1}")
            config.setdefault('encryption', 'none')
            config.setdefault('network', 'tcp')
            config.setdefault('security', 'none')
            config.setdefault('priority', 1)
            config.setdefault('active', True)
            
            # 验证配置
            if not self.validate_vless_config(config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 保存到数据库
            self.db.add_proxy_server(
                protocol='vless',
                server_id=config['id'],
                name=config['name'],
                config=json.dumps(config),
                priority=config['priority'],
                active=config['active']
            )
            
            # 添加到内存列表
            self.servers.append(config)
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已添加 VLESS 服务器: {config['name']}")
            
            return {
                'success': True,
                'server_id': config['id'],
                'message': f"VLESS 服务器 '{config['name']}' 添加成功"
            }
            
        except Exception as e:
            logger.error(f"添加 VLESS 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def update_server(self, server_id: str, config: Dict) -> Dict:
        """更新 VLESS 服务器配置"""
        try:
            # 查找服务器
            server_index = None
            for i, server in enumerate(self.servers):
                if server.get('id') == server_id:
                    server_index = i
                    break
            
            if server_index is None:
                return {'success': False, 'message': '服务器不存在'}
            
            # 更新配置
            updated_config = self.servers[server_index].copy()
            updated_config.update(config)
            updated_config['id'] = server_id  # 确保 ID 不变
            
            # 验证配置
            if not self.validate_vless_config(updated_config):
                return {'success': False, 'message': '配置验证失败'}
            
            # 更新数据库
            self.db.update_proxy_server(
                server_id=server_id,
                name=updated_config['name'],
                config=json.dumps(updated_config),
                priority=updated_config['priority'],
                active=updated_config['active']
            )
            
            # 更新内存列表
            self.servers[server_index] = updated_config
            self.servers.sort(key=lambda x: x.get('priority', 999))
            
            logger.info(f"已更新 VLESS 服务器: {updated_config['name']}")
            
            return {
                'success': True,
                'message': f"VLESS 服务器 '{updated_config['name']}' 更新成功"
            }
            
        except Exception as e:
            logger.error(f"更新 VLESS 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def delete_server(self, server_id: str) -> Dict:
        """删除 VLESS 服务器"""
        try:
            # 查找服务器
            server_index = None
            server_name = None
            for i, server in enumerate(self.servers):
                if server.get('id') == server_id:
                    server_index = i
                    server_name = server.get('name', server_id)
                    break
            
            if server_index is None:
                return {'success': False, 'message': '服务器不存在'}
            
            # 从数据库删除
            self.db.delete_proxy_server(server_id)
            
            # 从内存列表删除
            del self.servers[server_index]
            
            # 如果删除的是当前服务器，清除当前服务器
            if self.current_server and self.current_server.get('id') == server_id:
                self.current_server = None
            
            logger.info(f"已删除 VLESS 服务器: {server_name}")
            
            return {
                'success': True,
                'message': f"VLESS 服务器 '{server_name}' 删除成功"
            }
            
        except Exception as e:
            logger.error(f"删除 VLESS 服务器失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_servers(self) -> List[Dict]:
        """获取所有 VLESS 服务器"""
        return self.servers.copy()
    
    def get_server(self, server_id: str) -> Optional[Dict]:
        """获取指定的 VLESS 服务器"""
        for server in self.servers:
            if server.get('id') == server_id:
                return server.copy()
        return None
    
    def test_connection(self, server_id: str) -> Dict:
        """测试 VLESS 服务器连接"""
        try:
            server = self.get_server(server_id)
            if not server:
                return {'success': False, 'message': '服务器不存在'}
            
            # 构建代理 URL
            proxy_url = self._build_proxy_url(server)
            if not proxy_url:
                return {'success': False, 'message': '无法构建代理 URL'}
            
            # 测试连接
            start_time = time.time()
            
            proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
            
            response = requests.get(
                'http://httpbin.org/ip',
                proxies=proxies,
                timeout=10
            )
            
            end_time = time.time()
            response_time = int((end_time - start_time) * 1000)
            
            if response.status_code == 200:
                data = response.json()
                external_ip = data.get('origin', 'Unknown')
                
                # 记录连接日志
                self.db.log_proxy_connection(
                    server_id=server_id,
                    protocol='vless',
                    response_time=response_time,
                    success=True,
                    external_ip=external_ip
                )
                
                return {
                    'success': True,
                    'response_time': response_time,
                    'external_ip': external_ip,
                    'message': 'VLESS 连接测试成功'
                }
            else:
                error_msg = f'HTTP 错误: {response.status_code}'
                
                # 记录连接日志
                self.db.log_proxy_connection(
                    server_id=server_id,
                    protocol='vless',
                    response_time=response_time,
                    success=False,
                    error_message=error_msg
                )
                
                return {'success': False, 'message': error_msg}
                
        except requests.exceptions.ProxyError as e:
            error_msg = f'代理连接失败: {str(e)}'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='vless',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
            
        except requests.exceptions.Timeout:
            error_msg = '连接超时'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='vless',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
            
        except Exception as e:
            error_msg = f'未知错误: {str(e)}'
            self.db.log_proxy_connection(
                server_id=server_id,
                protocol='vless',
                success=False,
                error_message=error_msg
            )
            return {'success': False, 'message': error_msg}
    
    def _build_proxy_url(self, server: Dict) -> Optional[str]:
        """构建代理 URL"""
        try:
            # 注意：这里只是示例，实际的 VLESS 代理需要专门的客户端
            # 在实际应用中，需要集成 v2ray-core 或其他 VLESS 客户端
            
            # 这里返回一个占位符 URL，实际实现需要根据具体的代理客户端来构建
            address = server['address']
            port = server['port']
            
            # 简化的 URL 构建（实际需要更复杂的处理）
            return f"socks5://127.0.0.1:1080"  # 假设本地有 VLESS 客户端监听此端口
            
        except Exception as e:
            logger.error(f"构建 VLESS 代理 URL 失败: {e}")
            return None
    
    def get_proxy_config(self, server_id: str) -> Optional[Dict]:
        """获取代理配置"""
        server = self.get_server(server_id)
        if not server:
            return None
        
        proxy_url = self._build_proxy_url(server)
        if not proxy_url:
            return None
        
        return {
            'http': proxy_url,
            'https': proxy_url
        }
    
    def health_check(self) -> Dict:
        """健康检查所有服务器"""
        results = []
        
        for server in self.servers:
            if not server.get('active', True):
                continue
            
            server_id = server.get('id')
            result = self.test_connection(server_id)
            
            results.append({
                'server_id': server_id,
                'name': server.get('name', server_id),
                'healthy': result['success'],
                'response_time': result.get('response_time'),
                'error_message': result.get('message') if not result['success'] else None
            })
        
        return {
            'success': True,
            'protocol': 'vless',
            'results': results,
            'total_servers': len(self.servers),
            'healthy_servers': len([r for r in results if r['healthy']])
        }
    
    def get_best_server(self) -> Optional[Dict]:
        """获取最佳服务器"""
        active_servers = [s for s in self.servers if s.get('active', True)]
        if not active_servers:
            return None
        
        # 按优先级返回第一个活跃服务器
        return active_servers[0]
    
    def set_current_server(self, server_id: str) -> Dict:
        """设置当前使用的服务器"""
        server = self.get_server(server_id)
        if not server:
            return {'success': False, 'message': '服务器不存在'}
        
        self.current_server = server
        
        return {
            'success': True,
            'message': f"已切换到 VLESS 服务器: {server['name']}"
        }
    
    def get_current_server(self) -> Optional[Dict]:
        """获取当前使用的服务器"""
        return self.current_server.copy() if self.current_server else None

