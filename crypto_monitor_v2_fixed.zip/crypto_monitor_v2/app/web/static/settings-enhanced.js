// 设置页面增强版 JavaScript
// 支持 VLESS 和 Hysteria2 代理配置

// 全局变量
let currentEditingVLESS = null;
let currentEditingHysteria2 = null;
let vlessServers = [];
let hysteria2Servers = [];

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    initializePage();
    loadConfig();
    setupEventListeners();
});

function initializePage() {
    // 初始化协议标签切换
    setupProtocolTabs();
    
    // 初始化 Nekobox 自动检测切换
    toggleNekoboxManualConfig();
    
    // 初始化 VLESS 网络类型切换
    setupVLESSNetworkChange();
    
    // 加载服务器列表
    loadVLESSServers();
    loadHysteria2Servers();
}

function setupEventListeners() {
    // 监控参数表单提交
    document.getElementById('monitoringForm').addEventListener('submit', handleMonitoringFormSubmit);
    
    // 交易所设置表单提交
    document.getElementById('exchangeForm').addEventListener('submit', handleExchangeFormSubmit);
    
    // Telegram 设置表单提交
    document.getElementById('telegramForm').addEventListener('submit', handleTelegramFormSubmit);
    
    // Nekobox 自动检测切换
    document.getElementById('nekoboxAutoDetect').addEventListener('change', toggleNekoboxManualConfig);
    
    // VLESS 网络类型切换
    document.getElementById('vlessNetwork').addEventListener('change', handleVLESSNetworkChange);
    document.getElementById('vlessSecurity').addEventListener('change', handleVLESSSecurityChange);
}

function setupProtocolTabs() {
    const tabs = document.querySelectorAll('.protocol-tab');
    const contents = document.querySelectorAll('.protocol-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const protocol = this.dataset.protocol;
            
            // 移除所有活跃状态
            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));
            
            // 设置当前活跃状态
            this.classList.add('active');
            document.getElementById(protocol + '-content').classList.add('active');
        });
    });
}

function loadConfig() {
    fetch('/api/config')
        .then(response => response.json())
        .then(data => {
            // 监控参数
            document.getElementById('priceThreshold').value = data.price_change_threshold || 5;
            document.getElementById('priceInterval').value = data.price_check_interval || 300;
            document.getElementById('announcementInterval').value = data.announcement_scan_interval || 3600;
            
            // 交易所设置
            document.getElementById('binanceEnabled').checked = data.exchanges?.binance?.enabled || false;
            document.getElementById('gateEnabled').checked = data.exchanges?.gate?.enabled || false;
            
            // Nekobox 设置
            document.getElementById('nekoboxEnabled').checked = data.nekobox_enabled || false;
            document.getElementById('nekoboxAutoDetect').checked = data.nekobox_auto_detect !== false;
            
            // Telegram 设置
            document.getElementById('telegramEnabled').checked = data.telegram_enabled || false;
            
            toggleNekoboxManualConfig();
        })
        .catch(error => {
            console.error('加载配置失败:', error);
            showAlert('加载配置失败: ' + error.message, 'danger');
        });
}

function toggleNekoboxManualConfig() {
    const autoDetect = document.getElementById('nekoboxAutoDetect').checked;
    const manualConfig = document.getElementById('nekoboxManualConfig');
    
    if (autoDetect) {
        manualConfig.style.display = 'none';
    } else {
        manualConfig.style.display = 'block';
    }
}

// 监控参数表单处理
function handleMonitoringFormSubmit(e) {
    e.preventDefault();
    
    const data = {
        price_change_threshold: parseFloat(document.getElementById('priceThreshold').value),
        price_check_interval: parseInt(document.getElementById('priceInterval').value),
        announcement_scan_interval: parseInt(document.getElementById('announcementInterval').value)
    };
    
    fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert('监控参数已保存', 'success');
        } else {
            showAlert('保存失败: ' + result.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('请求失败: ' + error.message, 'danger');
    });
}

// 交易所设置表单处理
function handleExchangeFormSubmit(e) {
    e.preventDefault();
    
    const data = {
        exchanges: {
            binance: { enabled: document.getElementById('binanceEnabled').checked },
            gate: { enabled: document.getElementById('gateEnabled').checked }
        }
    };
    
    fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert('交易所设置已保存', 'success');
        } else {
            showAlert('保存失败: ' + result.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('请求失败: ' + error.message, 'danger');
    });
}

// Telegram 设置表单处理
function handleTelegramFormSubmit(e) {
    e.preventDefault();
    
    const data = {
        bot_token: document.getElementById('botToken').value,
        chat_id: document.getElementById('chatId').value,
        enabled: document.getElementById('telegramEnabled').checked,
        price_notify: document.getElementById('priceNotify').checked,
        announcement_notify: document.getElementById('announcementNotify').checked,
        min_price_change: parseFloat(document.getElementById('minPriceChange').value) || 10
    };
    
    fetch('/api/telegram/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert('Telegram 设置已保存', 'success');
        } else {
            showAlert('保存失败: ' + result.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('请求失败: ' + error.message, 'danger');
    });
}

// Nekobox 相关函数
function detectNekobox() {
    fetch('/api/nekobox/detect', { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            const statusDiv = document.getElementById('nekoboxStatus');
            const contentDiv = document.getElementById('nekoboxStatusContent');
            
            if (result.success) {
                contentDiv.innerHTML = `
                    <p><strong>检测到 ${result.detected_count} 个代理端口:</strong></p>
                    <ul class="mb-0">
                        ${result.proxies.map(proxy => 
                            `<li>${proxy.type}://${proxy.host}:${proxy.port} (${proxy.status})</li>`
                        ).join('')}
                    </ul>
                `;
                statusDiv.className = 'alert alert-success';
            } else {
                contentDiv.innerHTML = `<p class="mb-0">检测失败: ${result.message}</p>`;
                statusDiv.className = 'alert alert-warning';
            }
            
            statusDiv.style.display = 'block';
        })
        .catch(error => {
            const statusDiv = document.getElementById('nekoboxStatus');
            const contentDiv = document.getElementById('nekoboxStatusContent');
            contentDiv.innerHTML = `<p class="mb-0">检测失败: ${error.message}</p>`;
            statusDiv.className = 'alert alert-danger';
            statusDiv.style.display = 'block';
        });
}

function testNekobox() {
    fetch('/api/nekobox/status')
        .then(response => response.json())
        .then(data => {
            if (data.current_proxy) {
                return fetch('/api/nekobox/test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ proxy_url: data.current_proxy.url })
                });
            } else {
                throw new Error('未检测到活动的 Nekobox 代理');
            }
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(`✅ Nekobox 代理测试成功\\n外部IP: ${result.ip}`, 'success');
            } else {
                showAlert(`❌ Nekobox 代理测试失败: ${result.message}`, 'danger');
            }
        })
        .catch(error => {
            showAlert(`❌ 测试失败: ${error.message}`, 'danger');
        });
}

function testTelegram() {
    fetch('/api/telegram/test', { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert('✅ Telegram 连接测试成功', 'success');
            } else {
                showAlert('❌ Telegram 连接测试失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            showAlert('❌ 测试失败: ' + error.message, 'danger');
        });
}

function saveNekoboxConfig() {
    const data = {
        nekobox_enabled: document.getElementById('nekoboxEnabled').checked,
        nekobox_auto_detect: document.getElementById('nekoboxAutoDetect').checked
    };
    
    // 如果不是自动检测，添加手动配置
    if (!data.nekobox_auto_detect) {
        data.nekobox_host = document.getElementById('nekoboxHost').value || '127.0.0.1';
        data.nekobox_port = parseInt(document.getElementById('nekoboxPort').value) || 7890;
        data.nekobox_protocol = document.getElementById('nekoboxProtocol').value || 'socks5';
    }
    
    fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert('Nekobox 配置已保存', 'success');
        } else {
            showAlert('保存失败: ' + result.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('请求失败: ' + error.message, 'danger');
    });
}

// VLESS 相关函数
function loadVLESSServers() {
    fetch('/api/vless/servers')
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                vlessServers = result.servers;
                renderVLESSServerList();
            } else {
                showAlert('加载 VLESS 服务器失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            console.error('加载 VLESS 服务器失败:', error);
            showAlert('加载 VLESS 服务器失败: ' + error.message, 'danger');
        });
}

function renderVLESSServerList() {
    const container = document.getElementById('vlessServerList');
    
    if (vlessServers.length === 0) {
        container.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fas fa-inbox fa-2x mb-2"></i>
                <p>暂无 VLESS 服务器配置</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = vlessServers.map(server => `
        <div class="proxy-server-card p-3 ${server.active ? 'active' : ''}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <span class="server-status ${getServerHealthStatus(server)}"></span>
                        ${server.name}
                        ${server.active ? '<span class="badge bg-success ms-2">活跃</span>' : '<span class="badge bg-secondary ms-2">禁用</span>'}
                    </h6>
                    <p class="text-muted mb-1">
                        <i class="fas fa-server me-1"></i>
                        ${server.address}:${server.port}
                    </p>
                    <p class="text-muted mb-0">
                        <i class="fas fa-network-wired me-1"></i>
                        ${server.network || 'tcp'} / ${server.security || 'none'}
                        <span class="ms-3">
                            <i class="fas fa-sort-numeric-up me-1"></i>
                            优先级: ${server.priority || 1}
                        </span>
                    </p>
                </div>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-success" onclick="testVLESSServer('${server.id}')">
                        <i class="fas fa-vial"></i>
                    </button>
                    <button type="button" class="btn btn-outline-primary" onclick="editVLESSServer('${server.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteVLESSServer('${server.id}', '${server.name}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function showAddVLESSModal() {
    currentEditingVLESS = null;
    document.getElementById('vlessModalTitle').textContent = '添加 VLESS 服务器';
    document.getElementById('vlessForm').reset();
    document.getElementById('vlessServerId').value = '';
    document.getElementById('vlessPriority').value = '1';
    document.getElementById('vlessNetwork').value = 'tcp';
    document.getElementById('vlessSecurity').value = 'none';
    document.getElementById('vlessEncryption').value = 'none';
    document.getElementById('vlessActive').checked = true;
    
    handleVLESSNetworkChange();
    handleVLESSSecurityChange();
    
    new bootstrap.Modal(document.getElementById('vlessModal')).show();
}

function editVLESSServer(serverId) {
    const server = vlessServers.find(s => s.id === serverId);
    if (!server) return;
    
    currentEditingVLESS = serverId;
    document.getElementById('vlessModalTitle').textContent = '编辑 VLESS 服务器';
    
    // 填充表单
    document.getElementById('vlessServerId').value = server.id;
    document.getElementById('vlessName').value = server.name;
    document.getElementById('vlessAddress').value = server.address;
    document.getElementById('vlessPort').value = server.port;
    document.getElementById('vlessUuid').value = server.uuid;
    document.getElementById('vlessNetwork').value = server.network || 'tcp';
    document.getElementById('vlessSecurity').value = server.security || 'none';
    document.getElementById('vlessEncryption').value = server.encryption || 'none';
    document.getElementById('vlessPriority').value = server.priority || 1;
    document.getElementById('vlessActive').checked = server.active !== false;
    
    // TLS 设置
    if (server.tls_settings) {
        document.getElementById('vlessSni').value = server.tls_settings.server_name || '';
        document.getElementById('vlessAllowInsecure').checked = server.tls_settings.allow_insecure || false;
    }
    
    // WebSocket 设置
    if (server.ws_settings) {
        document.getElementById('vlessWsPath').value = server.ws_settings.path || '/';
        document.getElementById('vlessWsHost').value = server.ws_settings.headers?.Host || '';
    }
    
    // gRPC 设置
    if (server.grpc_settings) {
        document.getElementById('vlessGrpcService').value = server.grpc_settings.service_name || '';
    }
    
    handleVLESSNetworkChange();
    handleVLESSSecurityChange();
    
    new bootstrap.Modal(document.getElementById('vlessModal')).show();
}

function setupVLESSNetworkChange() {
    document.getElementById('vlessNetwork').addEventListener('change', handleVLESSNetworkChange);
    document.getElementById('vlessSecurity').addEventListener('change', handleVLESSSecurityChange);
}

function handleVLESSNetworkChange() {
    const network = document.getElementById('vlessNetwork').value;
    const wsSettings = document.getElementById('vlessWsSettings');
    const grpcSettings = document.getElementById('vlessGrpcSettings');
    
    // 隐藏所有网络特定设置
    wsSettings.style.display = 'none';
    grpcSettings.style.display = 'none';
    
    // 显示对应的设置
    if (network === 'ws') {
        wsSettings.style.display = 'block';
    } else if (network === 'grpc') {
        grpcSettings.style.display = 'block';
    }
}

function handleVLESSSecurityChange() {
    const security = document.getElementById('vlessSecurity').value;
    const tlsSettings = document.getElementById('vlessTlsSettings');
    
    if (security === 'tls') {
        tlsSettings.style.display = 'block';
    } else {
        tlsSettings.style.display = 'none';
    }
}

function generateUUID(inputId) {
    const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
    document.getElementById(inputId).value = uuid;
}

function saveVLESSServer() {
    const form = document.getElementById('vlessForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const data = {
        name: document.getElementById('vlessName').value,
        address: document.getElementById('vlessAddress').value,
        port: parseInt(document.getElementById('vlessPort').value),
        uuid: document.getElementById('vlessUuid').value,
        network: document.getElementById('vlessNetwork').value,
        security: document.getElementById('vlessSecurity').value,
        encryption: document.getElementById('vlessEncryption').value,
        priority: parseInt(document.getElementById('vlessPriority').value),
        active: document.getElementById('vlessActive').checked
    };
    
    // TLS 设置
    if (data.security === 'tls') {
        data.tls_settings = {
            server_name: document.getElementById('vlessSni').value,
            allow_insecure: document.getElementById('vlessAllowInsecure').checked
        };
        data.sni = document.getElementById('vlessSni').value;
    }
    
    // WebSocket 设置
    if (data.network === 'ws') {
        data.ws_settings = {
            path: document.getElementById('vlessWsPath').value || '/',
            headers: {
                Host: document.getElementById('vlessWsHost').value || data.address
            }
        };
    }
    
    // gRPC 设置
    if (data.network === 'grpc') {
        data.grpc_settings = {
            service_name: document.getElementById('vlessGrpcService').value || 'grpc_service'
        };
    }
    
    const url = currentEditingVLESS ? 
        `/api/vless/servers/${currentEditingVLESS}` : 
        '/api/vless/servers';
    const method = currentEditingVLESS ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert(result.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('vlessModal')).hide();
            loadVLESSServers();
        } else {
            showAlert('保存失败: ' + result.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('请求失败: ' + error.message, 'danger');
    });
}

function testVLESSServer(serverId) {
    fetch(`/api/vless/servers/${serverId}/test`, { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(`✅ VLESS 连接测试成功\\n响应时间: ${result.response_time}ms\\n外部IP: ${result.external_ip}`, 'success');
            } else {
                showAlert(`❌ VLESS 连接测试失败: ${result.message}`, 'danger');
            }
        })
        .catch(error => {
            showAlert(`❌ 测试失败: ${error.message}`, 'danger');
        });
}

function testVLESSConnection() {
    // 临时保存当前表单数据进行测试
    const form = document.getElementById('vlessForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showAlert('正在测试连接...', 'info');
    
    // 这里可以实现临时测试逻辑
    // 由于需要先保存服务器才能测试，这里暂时提示用户先保存
    showAlert('请先保存服务器配置，然后使用服务器列表中的测试按钮', 'warning');
}

function deleteVLESSServer(serverId, serverName) {
    if (!confirm(`确定要删除 VLESS 服务器 "${serverName}" 吗？`)) {
        return;
    }
    
    fetch(`/api/vless/servers/${serverId}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(result.message, 'success');
                loadVLESSServers();
            } else {
                showAlert('删除失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            showAlert('请求失败: ' + error.message, 'danger');
        });
}

function healthCheckVLESS() {
    fetch('/api/proxy/health-check', { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                const vlessResult = result.results.find(r => r.protocol === 'vless');
                if (vlessResult) {
                    const healthyCount = vlessResult.healthy_servers;
                    const totalCount = vlessResult.total_servers;
                    showAlert(`VLESS 健康检查完成: ${healthyCount}/${totalCount} 服务器健康`, 'info');
                    loadVLESSServers(); // 重新加载以更新状态
                } else {
                    showAlert('未找到 VLESS 健康检查结果', 'warning');
                }
            } else {
                showAlert('健康检查失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            showAlert('健康检查失败: ' + error.message, 'danger');
        });
}

// Hysteria2 相关函数
function loadHysteria2Servers() {
    fetch('/api/hysteria2/servers')
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                hysteria2Servers = result.servers;
                renderHysteria2ServerList();
            } else {
                showAlert('加载 Hysteria2 服务器失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            console.error('加载 Hysteria2 服务器失败:', error);
            showAlert('加载 Hysteria2 服务器失败: ' + error.message, 'danger');
        });
}

function renderHysteria2ServerList() {
    const container = document.getElementById('hysteria2ServerList');
    
    if (hysteria2Servers.length === 0) {
        container.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fas fa-inbox fa-2x mb-2"></i>
                <p>暂无 Hysteria2 服务器配置</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = hysteria2Servers.map(server => `
        <div class="proxy-server-card p-3 ${server.active ? 'active' : ''}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h6 class="mb-1">
                        <span class="server-status ${getServerHealthStatus(server)}"></span>
                        ${server.name}
                        ${server.active ? '<span class="badge bg-success ms-2">活跃</span>' : '<span class="badge bg-secondary ms-2">禁用</span>'}
                    </h6>
                    <p class="text-muted mb-1">
                        <i class="fas fa-server me-1"></i>
                        ${server.server}
                    </p>
                    <p class="text-muted mb-0">
                        <i class="fas fa-tachometer-alt me-1"></i>
                        ${server.bandwidth?.up || '100 mbps'} ↑ / ${server.bandwidth?.down || '100 mbps'} ↓
                        <span class="ms-3">
                            <i class="fas fa-sort-numeric-up me-1"></i>
                            优先级: ${server.priority || 1}
                        </span>
                    </p>
                </div>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-info" onclick="showHysteria2Config('${server.id}')">
                        <i class="fas fa-file-code"></i>
                    </button>
                    <button type="button" class="btn btn-outline-success" onclick="testHysteria2Server('${server.id}')">
                        <i class="fas fa-vial"></i>
                    </button>
                    <button type="button" class="btn btn-outline-primary" onclick="editHysteria2Server('${server.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteHysteria2Server('${server.id}', '${server.name}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function showAddHysteria2Modal() {
    currentEditingHysteria2 = null;
    document.getElementById('hysteria2ModalTitle').textContent = '添加 Hysteria2 服务器';
    document.getElementById('hysteria2Form').reset();
    document.getElementById('hysteria2ServerId').value = '';
    document.getElementById('hysteria2Priority').value = '1';
    document.getElementById('hysteria2UpBandwidth').value = '100 mbps';
    document.getElementById('hysteria2DownBandwidth').value = '100 mbps';
    document.getElementById('hysteria2FastOpen').checked = true;
    document.getElementById('hysteria2Active').checked = true;
    
    new bootstrap.Modal(document.getElementById('hysteria2Modal')).show();
}

function editHysteria2Server(serverId) {
    const server = hysteria2Servers.find(s => s.id === serverId);
    if (!server) return;
    
    currentEditingHysteria2 = serverId;
    document.getElementById('hysteria2ModalTitle').textContent = '编辑 Hysteria2 服务器';
    
    // 填充表单
    document.getElementById('hysteria2ServerId').value = server.id;
    document.getElementById('hysteria2Name').value = server.name;
    document.getElementById('hysteria2Server').value = server.server;
    document.getElementById('hysteria2Auth').value = server.auth;
    document.getElementById('hysteria2Priority').value = server.priority || 1;
    document.getElementById('hysteria2Active').checked = server.active !== false;
    
    // 带宽设置
    if (server.bandwidth) {
        document.getElementById('hysteria2UpBandwidth').value = server.bandwidth.up || '100 mbps';
        document.getElementById('hysteria2DownBandwidth').value = server.bandwidth.down || '100 mbps';
    }
    
    // TLS 设置
    if (server.tls) {
        document.getElementById('hysteria2Sni').value = server.tls.sni || '';
        document.getElementById('hysteria2Insecure').checked = server.tls.insecure || false;
    }
    
    // 其他设置
    document.getElementById('hysteria2FastOpen').checked = server.fastOpen !== false;
    
    new bootstrap.Modal(document.getElementById('hysteria2Modal')).show();
}

function saveHysteria2Server() {
    const form = document.getElementById('hysteria2Form');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const data = {
        name: document.getElementById('hysteria2Name').value,
        server: document.getElementById('hysteria2Server').value,
        auth: document.getElementById('hysteria2Auth').value,
        priority: parseInt(document.getElementById('hysteria2Priority').value),
        active: document.getElementById('hysteria2Active').checked,
        fastOpen: document.getElementById('hysteria2FastOpen').checked,
        bandwidth: {
            up: document.getElementById('hysteria2UpBandwidth').value,
            down: document.getElementById('hysteria2DownBandwidth').value
        },
        tls: {
            sni: document.getElementById('hysteria2Sni').value,
            insecure: document.getElementById('hysteria2Insecure').checked
        }
    };
    
    const url = currentEditingHysteria2 ? 
        `/api/hysteria2/servers/${currentEditingHysteria2}` : 
        '/api/hysteria2/servers';
    const method = currentEditingHysteria2 ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert(result.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('hysteria2Modal')).hide();
            loadHysteria2Servers();
        } else {
            showAlert('保存失败: ' + result.message, 'danger');
        }
    })
    .catch(error => {
        showAlert('请求失败: ' + error.message, 'danger');
    });
}

function testHysteria2Server(serverId) {
    fetch(`/api/hysteria2/servers/${serverId}/test`, { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(`✅ Hysteria2 连接测试成功\\n响应时间: ${result.response_time}ms\\n外部IP: ${result.external_ip}`, 'success');
            } else {
                showAlert(`❌ Hysteria2 连接测试失败: ${result.message}`, 'danger');
            }
        })
        .catch(error => {
            showAlert(`❌ 测试失败: ${error.message}`, 'danger');
        });
}

function testHysteria2Connection() {
    // 临时保存当前表单数据进行测试
    const form = document.getElementById('hysteria2Form');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    showAlert('正在测试连接...', 'info');
    
    // 这里可以实现临时测试逻辑
    // 由于需要先保存服务器才能测试，这里暂时提示用户先保存
    showAlert('请先保存服务器配置，然后使用服务器列表中的测试按钮', 'warning');
}

function deleteHysteria2Server(serverId, serverName) {
    if (!confirm(`确定要删除 Hysteria2 服务器 "${serverName}" 吗？`)) {
        return;
    }
    
    fetch(`/api/hysteria2/servers/${serverId}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showAlert(result.message, 'success');
                loadHysteria2Servers();
            } else {
                showAlert('删除失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            showAlert('请求失败: ' + error.message, 'danger');
        });
}

function showHysteria2Config(serverId) {
    fetch(`/api/hysteria2/servers/${serverId}/config`)
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                document.getElementById('configContent').textContent = result.config;
                new bootstrap.Modal(document.getElementById('configModal')).show();
            } else {
                showAlert('获取配置失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            showAlert('获取配置失败: ' + error.message, 'danger');
        });
}

function generateHysteria2Config() {
    const form = document.getElementById('hysteria2Form');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const config = {
        server: document.getElementById('hysteria2Server').value,
        auth: document.getElementById('hysteria2Auth').value,
        bandwidth: {
            up: document.getElementById('hysteria2UpBandwidth').value,
            down: document.getElementById('hysteria2DownBandwidth').value
        },
        tls: {
            sni: document.getElementById('hysteria2Sni').value,
            insecure: document.getElementById('hysteria2Insecure').checked
        },
        fastOpen: document.getElementById('hysteria2FastOpen').checked,
        socks5: {
            listen: '127.0.0.1:1080'
        }
    };
    
    document.getElementById('configContent').textContent = JSON.stringify(config, null, 2);
    new bootstrap.Modal(document.getElementById('configModal')).show();
}

function healthCheckHysteria2() {
    fetch('/api/proxy/health-check', { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                const hy2Result = result.results.find(r => r.protocol === 'hysteria2');
                if (hy2Result) {
                    const healthyCount = hy2Result.healthy_servers;
                    const totalCount = hy2Result.total_servers;
                    showAlert(`Hysteria2 健康检查完成: ${healthyCount}/${totalCount} 服务器健康`, 'info');
                    loadHysteria2Servers(); // 重新加载以更新状态
                } else {
                    showAlert('未找到 Hysteria2 健康检查结果', 'warning');
                }
            } else {
                showAlert('健康检查失败: ' + result.message, 'danger');
            }
        })
        .catch(error => {
            showAlert('健康检查失败: ' + error.message, 'danger');
        });
}

// 工具函数
function getServerHealthStatus(server) {
    // 根据服务器的健康状态返回对应的 CSS 类
    if (server.health_status === 'healthy') {
        return 'healthy';
    } else if (server.health_status === 'unhealthy') {
        return 'unhealthy';
    } else {
        return 'unknown';
    }
}

function copyConfig() {
    const content = document.getElementById('configContent').textContent;
    navigator.clipboard.writeText(content).then(() => {
        showAlert('配置已复制到剪贴板', 'success');
    }).catch(err => {
        console.error('复制失败:', err);
        showAlert('复制失败', 'danger');
    });
}

function showAlert(message, type) {
    // 创建并显示 Bootstrap 警告框
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // 自动移除警告框
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 5000);
}

