#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
命令行界面模块
提供命令行操作接口
"""

import argparse
import sys
import logging
from pathlib import Path

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.core.config import Config
from app.core.database import Database
from app.core.monitor import CryptoMonitor

def setup_logging():
    """设置日志配置"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def cmd_start_monitor(args):
    """启动监控命令"""
    config = Config()
    db = Database(config.database_path)
    db.init_database()
    
    monitor = CryptoMonitor(config, db)
    
    try:
        monitor.start_monitoring()
        print("监控已启动，按 Ctrl+C 停止...")
        
        # 保持程序运行
        import time
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n正在停止监控...")
        monitor.stop_monitoring()
        print("监控已停止")

def cmd_price_check(args):
    """手动价格检查命令"""
    config = Config()
    db = Database(config.database_path)
    db.init_database()
    
    monitor = CryptoMonitor(config, db)
    result = monitor.manual_price_check()
    
    print(f"价格检查完成，发现 {result['changes_count']} 个显著变动")

def cmd_announcement_scan(args):
    """手动公告扫描命令"""
    config = Config()
    db = Database(config.database_path)
    db.init_database()
    
    monitor = CryptoMonitor(config, db)
    result = monitor.manual_announcement_scan()
    
    print(f"公告扫描完成，发现 {result['new_count']} 条新公告")

def cmd_show_status(args):
    """显示状态命令"""
    config = Config()
    db = Database(config.database_path)
    
    try:
        stats = db.get_statistics()
        monitor_status = db.get_monitor_status()
        
        print("=== 系统统计 ===")
        print(f"总价格变动记录: {stats['total_price_changes']}")
        print(f"总公告记录: {stats['total_announcements']}")
        print(f"新上币公告: {stats['total_new_listings']}")
        print(f"今日价格变动: {stats['today_price_changes']}")
        print(f"今日新公告: {stats['today_announcements']}")
        
        print("\n=== 监控组件状态 ===")
        for component in monitor_status:
            print(f"{component['component']}: {component['status']}")
            if component['message']:
                print(f"  消息: {component['message']}")
            if component['last_run']:
                print(f"  上次运行: {component['last_run']}")
        
    except Exception as e:
        print(f"获取状态失败: {e}")

def cmd_test_telegram(args):
    """测试Telegram连接命令"""
    config = Config()
    db = Database(config.database_path)
    
    monitor = CryptoMonitor(config, db)
    result = monitor.notification_manager.test_telegram_connection()
    
    if result['success']:
        print("✅ Telegram连接测试成功")
    else:
        print(f"❌ Telegram连接测试失败: {result['message']}")

def cmd_config(args):
    """配置管理命令"""
    config = Config()
    
    if args.action == 'show':
        print("=== 当前配置 ===")
        print(f"价格变动阈值: {config.price_change_threshold}%")
        print(f"价格检查间隔: {config.price_check_interval}秒")
        print(f"公告扫描间隔: {config.announcement_scan_interval}秒")
        print(f"代理启用: {config.proxy_enabled}")
        print(f"Web端口: {config.web_port}")
        
        print("\n=== 交易所配置 ===")
        for name, ex_config in config.exchanges.items():
            print(f"{name}: {'启用' if ex_config.get('enabled') else '禁用'}")
        
        print("\n=== Telegram配置 ===")
        telegram_config = config.telegram_config
        print(f"启用: {telegram_config.get('enabled', False)}")
        print(f"Bot Token: {'已配置' if telegram_config.get('bot_token') else '未配置'}")
        print(f"Chat ID: {'已配置' if telegram_config.get('chat_id') else '未配置'}")
    
    elif args.action == 'set':
        if args.key and args.value:
            try:
                # 尝试转换数值类型
                if args.value.lower() in ['true', 'false']:
                    value = args.value.lower() == 'true'
                elif args.value.isdigit():
                    value = int(args.value)
                elif '.' in args.value and args.value.replace('.', '').isdigit():
                    value = float(args.value)
                else:
                    value = args.value
                
                config.set(args.key, value)
                config.save()
                print(f"✅ 配置已更新: {args.key} = {value}")
            except Exception as e:
                print(f"❌ 配置更新失败: {e}")
        else:
            print("❌ 请提供配置键和值")

def main():
    """主函数"""
    setup_logging()
    
    parser = argparse.ArgumentParser(description='加密货币监控系统 v2.0 命令行工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 启动监控命令
    parser_start = subparsers.add_parser('start', help='启动监控')
    parser_start.set_defaults(func=cmd_start_monitor)
    
    # 价格检查命令
    parser_price = subparsers.add_parser('price-check', help='手动价格检查')
    parser_price.set_defaults(func=cmd_price_check)
    
    # 公告扫描命令
    parser_announcement = subparsers.add_parser('announcement-scan', help='手动公告扫描')
    parser_announcement.set_defaults(func=cmd_announcement_scan)
    
    # 状态查看命令
    parser_status = subparsers.add_parser('status', help='显示系统状态')
    parser_status.set_defaults(func=cmd_show_status)
    
    # Telegram测试命令
    parser_telegram = subparsers.add_parser('test-telegram', help='测试Telegram连接')
    parser_telegram.set_defaults(func=cmd_test_telegram)
    
    # 配置管理命令
    parser_config = subparsers.add_parser('config', help='配置管理')
    parser_config.add_argument('action', choices=['show', 'set'], help='配置操作')
    parser_config.add_argument('--key', help='配置键')
    parser_config.add_argument('--value', help='配置值')
    parser_config.set_defaults(func=cmd_config)
    
    args = parser.parse_args()
    
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()

