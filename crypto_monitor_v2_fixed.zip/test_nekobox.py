#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Nekobox代理功能测试脚本
"""

import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

def test_nekobox_detection():
    """测试Nekobox代理检测功能"""
    print("测试Nekobox代理检测功能...")
    try:
        from app.core.nekobox_proxy import NekoboxProxyManager
        
        nekobox_manager = NekoboxProxyManager()
        
        # 测试端口检测
        print("  检测常见代理端口...")
        for port in nekobox_manager.COMMON_PORTS:
            is_open = nekobox_manager.is_port_open('127.0.0.1', port)
            print(f"    端口 {port}: {'开放' if is_open else '关闭'}")
        
        # 检测Nekobox代理
        print("  检测Nekobox代理...")
        proxies = nekobox_manager.detect_nekobox_proxies()
        
        if proxies:
            print(f"  ✅ 检测到 {len(proxies)} 个代理:")
            for proxy in proxies:
                print(f"    - {proxy['type']}://{proxy['host']}:{proxy['port']} ({proxy['status']})")
        else:
            print("  ⚠️  未检测到Nekobox代理")
        
        return True
    except Exception as e:
        print(f"  ❌ 检测失败: {e}")
        return False

def test_nekobox_config():
    """测试Nekobox配置功能"""
    print("\\n测试Nekobox配置功能...")
    try:
        from app.core.nekobox_proxy import NekoboxProxyManager
        
        nekobox_manager = NekoboxProxyManager()
        
        # 测试自动检测配置
        print("  测试自动检测配置...")
        auto_config = nekobox_manager.get_proxy_config(auto_detect=True)
        if auto_config:
            print(f"  ✅ 自动配置成功: {auto_config}")
        else:
            print("  ⚠️  自动配置失败（可能没有运行Nekobox）")
        
        # 测试手动配置
        print("  测试手动配置...")
        manual_config = {
            'host': '127.0.0.1',
            'port': 7890,
            'protocol': 'socks5'
        }
        
        manual_proxy_config = nekobox_manager.get_proxy_config(
            auto_detect=False, 
            manual_config=manual_config
        )
        
        if manual_proxy_config:
            print(f"  ✅ 手动配置成功: {manual_proxy_config}")
        else:
            print("  ⚠️  手动配置失败（端口可能未开放）")
        
        return True
    except Exception as e:
        print(f"  ❌ 配置测试失败: {e}")
        return False

def test_nekobox_integration():
    """测试Nekobox与系统集成"""
    print("\\n测试Nekobox与系统集成...")
    try:
        from app.core.config import Config
        from app.core.api_client import ExchangeAPIManager
        
        # 创建配置并启用Nekobox
        config = Config()
        config.set('proxy.enabled', True)
        config.set('proxy.type', 'nekobox')
        config.set('proxy.nekobox.enabled', True)
        config.set('proxy.nekobox.auto_detect', True)
        
        print("  测试API客户端Nekobox集成...")
        api_manager = ExchangeAPIManager(config)
        
        print("  ✅ API客户端创建成功")
        print(f"    支持的交易所: {list(api_manager.clients.keys())}")
        
        return True
    except Exception as e:
        print(f"  ❌ 集成测试失败: {e}")
        return False

def test_nekobox_api():
    """测试Nekobox Web API"""
    print("\\n测试Nekobox Web API...")
    try:
        from app.core.config import Config
        from app.core.database import Database
        from app.core.monitor import CryptoMonitor
        from app.web.app import create_app
        
        config = Config()
        db = Database(config.database_path)
        monitor = CryptoMonitor(config, db)
        app = create_app(config, monitor)
        
        with app.test_client() as client:
            # 测试Nekobox状态API
            print("  测试Nekobox状态API...")
            response = client.get('/api/nekobox/status')
            if response.status_code == 200:
                print("  ✅ 状态API正常")
            else:
                print(f"  ⚠️  状态API异常: {response.status_code}")
            
            # 测试Nekobox检测API
            print("  测试Nekobox检测API...")
            response = client.post('/api/nekobox/detect')
            if response.status_code == 200:
                print("  ✅ 检测API正常")
            else:
                print(f"  ⚠️  检测API异常: {response.status_code}")
        
        return True
    except Exception as e:
        print(f"  ❌ API测试失败: {e}")
        return False

def test_config_persistence():
    """测试配置持久化"""
    print("\\n测试Nekobox配置持久化...")
    try:
        from app.core.config import Config
        
        # 创建配置实例
        config = Config()
        
        # 设置Nekobox配置
        config.set('proxy.nekobox.enabled', True)
        config.set('proxy.nekobox.auto_detect', False)
        config.set('proxy.nekobox.manual_config.host', '127.0.0.1')
        config.set('proxy.nekobox.manual_config.port', 7890)
        config.set('proxy.nekobox.manual_config.protocol', 'socks5')
        
        # 保存配置
        config.save()
        print("  ✅ 配置保存成功")
        
        # 重新加载配置验证
        new_config = Config()
        nekobox_enabled = new_config.nekobox_enabled
        nekobox_config = new_config.nekobox_config
        
        print(f"  验证配置: enabled={nekobox_enabled}")
        print(f"  验证配置: auto_detect={nekobox_config.get('auto_detect')}")
        print(f"  验证配置: manual_config={nekobox_config.get('manual_config')}")
        
        return True
    except Exception as e:
        print(f"  ❌ 配置持久化测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("🚀 开始Nekobox代理功能测试...")
    print("=" * 60)
    
    tests = [
        test_nekobox_detection,
        test_nekobox_config,
        test_nekobox_integration,
        test_nekobox_api,
        test_config_persistence
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print("\\n" + "=" * 60)
    print(f"📊 Nekobox测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有Nekobox功能测试通过！")
        return 0
    else:
        print("⚠️  部分Nekobox功能测试失败")
        print("\\n💡 提示:")
        print("- 如果检测失败，请确保Nekobox正在运行")
        print("- 检查Nekobox是否在常见端口(7890, 7891, 7892等)上监听")
        print("- 确认Nekobox配置了混合端口或SOCKS代理")
        return 1

if __name__ == "__main__":
    sys.exit(main())

