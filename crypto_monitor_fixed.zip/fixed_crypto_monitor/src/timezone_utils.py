"""
Gate.io加密货币异动监控系统 - 时区工具模块
提供统一的时区处理功能，确保系统中所有时间显示为中国标准时间
"""

import logging
import datetime
import pytz
import os
import json
import time
from typing import Optional, Dict, Any

# 配置日志
logger = logging.getLogger("timezone_utils")

# 默认时区设置
DEFAULT_TIMEZONE = "Asia/Shanghai"  # 中国标准时间 (UTC+8)
CONFIG_FILE = "timezone_config.json"

class TimezoneManager:
    """时区管理器，提供统一的时区处理功能"""
    
    def __init__(self, config_file: str = CONFIG_FILE):
        """
        初始化时区管理器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.timezone_str = DEFAULT_TIMEZONE
        self.timezone = pytz.timezone(DEFAULT_TIMEZONE)
        
        # 检测系统时区是否已经是中国标准时间
        self.is_system_already_china_tz = self._check_if_system_already_china_tz()
        if self.is_system_already_china_tz:
            logger.info("检测到系统时区已经是中国标准时间，无需额外转换")
        else:
            logger.info("系统时区不是中国标准时间，将进行时区转换")
        
        # 加载配置
        self._load_config()
        
        logger.info(f"时区管理器初始化完成，当前时区: {self.timezone_str}")
    
    def _check_if_system_already_china_tz(self) -> bool:
        """
        检查系统时区是否已经是中国标准时间
        
        Returns:
            是否已经是中国标准时间
        """
        try:
            # 获取UTC时间和系统时间
            utc_now = datetime.datetime.utcnow()
            system_now = datetime.datetime.now()
            
            # 计算时差（小时）
            time_diff_hours = (system_now - utc_now).total_seconds() / 3600
            
            # 如果时差接近8小时，说明系统已经是中国标准时间
            return abs(time_diff_hours - 8) < 0.5
        except:
            return False
    
    def _load_config(self) -> None:
        """从配置文件加载时区配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    timezone_str = config.get("timezone")
                    if timezone_str:
                        try:
                            # 验证时区有效性
                            pytz.timezone(timezone_str)
                            self.timezone_str = timezone_str
                            self.timezone = pytz.timezone(timezone_str)
                            logger.info(f"从配置文件加载时区配置成功: {timezone_str}")
                        except Exception as e:
                            logger.warning(f"无效的时区: {timezone_str}，使用默认时区: {DEFAULT_TIMEZONE}")
            else:
                # 如果配置文件不存在，创建默认配置
                self.save_config(DEFAULT_TIMEZONE)
        except Exception as e:
            logger.error(f"加载时区配置文件失败: {str(e)}")
    
    def save_config(self, timezone_str: str) -> bool:
        """
        保存时区配置到配置文件
        
        Args:
            timezone_str: 时区字符串
            
        Returns:
            保存是否成功
        """
        try:
            # 验证时区有效性
            pytz.timezone(timezone_str)
            
            self.timezone_str = timezone_str
            self.timezone = pytz.timezone(timezone_str)
            
            with open(self.config_file, 'w') as f:
                json.dump({"timezone": timezone_str}, f, indent=4)
            
            logger.info(f"保存时区配置到配置文件成功: {timezone_str}")
            return True
        except Exception as e:
            logger.error(f"保存时区配置文件失败: {str(e)}")
            return False
    
    def get_current_time(self) -> datetime.datetime:
        """
        获取当前本地时间
        
        Returns:
            当前本地时间
        """
        if self.is_system_already_china_tz:
            # 如果系统已经是中国标准时间，直接使用系统时间并添加时区信息
            now = datetime.datetime.now()
            return self.timezone.localize(now)
        else:
            # 如果系统不是中国标准时间，从UTC转换
            utc_now = datetime.datetime.utcnow()
            utc_now = pytz.utc.localize(utc_now)
            return utc_now.astimezone(self.timezone)
    
    def format_time(self, dt: Optional[datetime.datetime] = None, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        格式化时间为字符串
        
        Args:
            dt: 要格式化的时间，如果为None则使用当前时间
            format_str: 时间格式字符串
            
        Returns:
            格式化后的时间字符串
        """
        if dt is None:
            dt = self.get_current_time()
        elif dt.tzinfo is None:
            # 如果输入时间没有时区信息，假设为UTC时间，转换为本地时区
            dt = pytz.utc.localize(dt).astimezone(self.timezone)
        else:
            # 如果输入时间有时区信息，转换为本地时区
            dt = dt.astimezone(self.timezone)
        
        return dt.strftime(format_str)
    
    def localize_time(self, dt: datetime.datetime) -> datetime.datetime:
        """
        将时间转换为本地时区
        
        Args:
            dt: 要转换的时间
            
        Returns:
            转换后的本地时间
        """
        if dt.tzinfo is None:
            # 如果输入时间没有时区信息，假设为UTC时间
            return pytz.utc.localize(dt).astimezone(self.timezone)
        else:
            # 如果输入时间有时区信息，直接转换
            return dt.astimezone(self.timezone)
    
    def parse_time(self, time_str: str, format_str: str = "%Y-%m-%d %H:%M:%S") -> datetime.datetime:
        """
        解析时间字符串为本地时间
        
        Args:
            time_str: 时间字符串
            format_str: 时间格式字符串
            
        Returns:
            解析后的本地时间
        """
        try:
            # 解析为naive datetime
            dt = datetime.datetime.strptime(time_str, format_str)
            # 添加本地时区信息
            return self.timezone.localize(dt)
        except Exception as e:
            logger.error(f"解析时间字符串失败: {str(e)}")
            # 返回当前时间作为后备
            return self.get_current_time()
    
    def utc_to_local(self, utc_dt: datetime.datetime) -> datetime.datetime:
        """
        将UTC时间转换为本地时间
        
        Args:
            utc_dt: UTC时间
            
        Returns:
            本地时间
        """
        if utc_dt.tzinfo is None:
            # 如果输入时间没有时区信息，假设为UTC时间
            utc_dt = pytz.utc.localize(utc_dt)
        
        return utc_dt.astimezone(self.timezone)
    
    def local_to_utc(self, local_dt: datetime.datetime) -> datetime.datetime:
        """
        将本地时间转换为UTC时间
        
        Args:
            local_dt: 本地时间
            
        Returns:
            UTC时间
        """
        if local_dt.tzinfo is None:
            # 如果输入时间没有时区信息，假设为本地时间
            local_dt = self.timezone.localize(local_dt)
        
        return local_dt.astimezone(pytz.utc)
    
    def get_timezone_offset(self) -> str:
        """
        获取当前时区偏移量字符串
        
        Returns:
            时区偏移量字符串，如 "+08:00"
        """
        # 直接返回中国标准时间的偏移量
        return "+08:00"

# 创建全局时区管理器实例
timezone_manager = TimezoneManager()

# 便捷函数
def get_current_time() -> datetime.datetime:
    """获取当前本地时间"""
    return timezone_manager.get_current_time()

def format_time(dt: Optional[datetime.datetime] = None, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """格式化时间为字符串"""
    return timezone_manager.format_time(dt, format_str)

def localize_time(dt: datetime.datetime) -> datetime.datetime:
    """将时间转换为本地时区"""
    return timezone_manager.localize_time(dt)

def parse_time(time_str: str, format_str: str = "%Y-%m-%d %H:%M:%S") -> datetime.datetime:
    """解析时间字符串为本地时间"""
    return timezone_manager.parse_time(time_str, format_str)

def utc_to_local(utc_dt: datetime.datetime) -> datetime.datetime:
    """将UTC时间转换为本地时间"""
    return timezone_manager.utc_to_local(utc_dt)

def local_to_utc(local_dt: datetime.datetime) -> datetime.datetime:
    """将本地时间转换为UTC时间"""
    return timezone_manager.local_to_utc(local_dt)

def get_timezone_offset() -> str:
    """获取当前时区偏移量字符串"""
    return timezone_manager.get_timezone_offset()

def get_timezone_name() -> str:
    """获取当前时区名称"""
    return timezone_manager.timezone_str

if __name__ == "__main__":
    # 测试代码
    logging.basicConfig(level=logging.INFO)
    
    print(f"当前时区: {get_timezone_name()}")
    print(f"时区偏移: {get_timezone_offset()}")
    print(f"当前时间: {format_time()}")
    
    # 测试时区转换
    utc_now = datetime.datetime.now(pytz.UTC)
    print(f"UTC时间: {utc_now}")
    print(f"本地时间: {format_time(utc_to_local(utc_now))}")
    
    # 测试解析时间字符串
    time_str = "2025-05-30 12:00:00"
    local_dt = parse_time(time_str)
    print(f"解析时间字符串: {time_str} -> {local_dt}")
    print(f"转换为UTC: {local_to_utc(local_dt)}")
