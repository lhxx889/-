#!/bin/bash
# Gate.io加密货币异动监控系统 - 快捷启动脚本

# 设置颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 无颜色

# 设置日志文件
LOG_FILE="crypto_monitor.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 检查Python环境
check_python() {
  if ! command -v python3 &> /dev/null; then
    echo -e "${RED}错误: 未找到Python3${NC}"
    echo "请安装Python3后再试"
    exit 1
  fi
}

# 检查依赖
check_dependencies() {
  echo "检查依赖..."
  
  # 检查是否是外部管理环境
  if python3 -m pip install --dry-run requests 2>&1 | grep -q "externally-managed-environment"; then
    echo "检测到外部管理环境，跳过依赖安装"
    return 0
  fi
  
  # 尝试安装依赖
  if ! python3 -m pip install --no-cache-dir -r requirements.txt; then
    echo -e "${RED}错误: 安装依赖失败${NC}"
    
    # 尝试使用系统包管理器
    if command -v apt &> /dev/null; then
      echo "尝试使用系统包管理器安装依赖..."
      sudo apt update
      sudo apt install -y python3-requests python3-matplotlib python3-numpy python3-pandas python3-pytz
    elif command -v yum &> /dev/null; then
      echo "尝试使用系统包管理器安装依赖..."
      sudo yum install -y python3-requests python3-matplotlib python3-numpy python3-pandas python3-pytz
    else
      echo "无法安装依赖，请手动安装以下包:"
      cat requirements.txt
      return 1
    fi
  fi
  
  return 0
}

# 创建必要的目录
create_directories() {
  echo "创建必要的目录..."
  mkdir -p charts logs config
}

# 启动监控
start_monitor() {
  echo -e "${GREEN}启动加密货币异动监控系统...${NC}"
  
  # 检查是否已经在运行
  if [ -f "crypto_monitor.pid" ]; then
    PID=$(cat crypto_monitor.pid)
    if ps -p $PID > /dev/null; then
      echo -e "${YELLOW}监控系统已经在运行 (PID: $PID)${NC}"
      echo "如需重启，请先停止当前进程: ./crypto_monitor.sh stop"
      return 1
    else
      echo "发现过期的PID文件，将删除"
      rm -f crypto_monitor.pid
    fi
  fi
  
  # 启动监控
  nohup python3 main.py > crypto_monitor.log 2>&1 &
  PID=$!
  echo $PID > crypto_monitor.pid
  echo -e "${GREEN}监控系统已启动 (PID: $PID)${NC}"
  echo "日志文件: crypto_monitor.log"
  
  # 等待几秒检查是否成功启动
  sleep 3
  if ! ps -p $PID > /dev/null; then
    echo -e "${RED}启动失败，请查看日志文件${NC}"
    echo "最后10行日志:"
    tail -n 10 crypto_monitor.log
    return 1
  fi
  
  return 0
}

# 停止监控
stop_monitor() {
  echo -e "${YELLOW}停止加密货币异动监控系统...${NC}"
  
  if [ -f "crypto_monitor.pid" ]; then
    PID=$(cat crypto_monitor.pid)
    if ps -p $PID > /dev/null; then
      kill $PID
      echo -e "${GREEN}已发送停止信号到进程 (PID: $PID)${NC}"
      
      # 等待进程结束
      for i in {1..10}; do
        if ! ps -p $PID > /dev/null; then
          echo -e "${GREEN}监控系统已停止${NC}"
          rm -f crypto_monitor.pid
          return 0
        fi
        sleep 1
      done
      
      # 如果进程仍在运行，强制终止
      echo -e "${YELLOW}进程未响应，强制终止...${NC}"
      kill -9 $PID
      if ! ps -p $PID > /dev/null; then
        echo -e "${GREEN}监控系统已强制停止${NC}"
        rm -f crypto_monitor.pid
        return 0
      else
        echo -e "${RED}无法停止进程 (PID: $PID)${NC}"
        return 1
      fi
    else
      echo "监控系统未运行"
      rm -f crypto_monitor.pid
    fi
  else
    echo "监控系统未运行"
  fi
  
  return 0
}

# 重启监控
restart_monitor() {
  echo -e "${BLUE}重启加密货币异动监控系统...${NC}"
  
  stop_monitor
  sleep 2
  start_monitor
  
  return $?
}

# 查看状态
status_monitor() {
  echo -e "${BLUE}加密货币异动监控系统状态:${NC}"
  
  if [ -f "crypto_monitor.pid" ]; then
    PID=$(cat crypto_monitor.pid)
    if ps -p $PID > /dev/null; then
      echo -e "${GREEN}监控系统正在运行 (PID: $PID)${NC}"
      
      # 显示运行时间
      PROC_START=$(ps -p $PID -o lstart=)
      echo "启动时间: $PROC_START"
      
      # 显示最近日志
      echo -e "\n最近10行日志:"
      tail -n 10 crypto_monitor.log
      
      return 0
    else
      echo -e "${RED}监控系统未运行，但存在过期的PID文件${NC}"
      rm -f crypto_monitor.pid
    fi
  else
    echo -e "${RED}监控系统未运行${NC}"
  fi
  
  return 1
}

# 查看日志
view_log() {
  echo -e "${BLUE}查看日志:${NC}"
  
  if [ -f "crypto_monitor.log" ]; then
    if [ "$1" == "all" ]; then
      cat crypto_monitor.log
    elif [ "$1" == "follow" ]; then
      tail -f crypto_monitor.log
    else
      # 默认显示最后50行
      tail -n 50 crypto_monitor.log
    fi
  else
    echo -e "${RED}日志文件不存在${NC}"
    return 1
  fi
  
  return 0
}

# Telegram账号管理
telegram_manager() {
  echo -e "${BLUE}Telegram账号管理${NC}"
  
  # 检查依赖
  check_dependencies
  
  # 创建Telegram配置
  create_telegram_config() {
    echo "创建Telegram配置..."
    
    # 确保目录存在
    mkdir -p config
    
    # 创建配置文件
    cat > telegram_accounts.json << EOF
{
  "accounts": {
    "$1": {
      "token": "$2",
      "chat_id": "$3",
      "is_active": true,
      "consecutive_errors": 0
    }
  },
  "current": "$1"
}
EOF
    
    echo "Telegram账号 '$1' 已添加"
  }
  
  # 子命令处理
  case "$1" in
    "add")
      if [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ]; then
        echo "用法: $0 telegram add <账号名称> <Bot Token> <Chat ID>"
        return 1
      fi
      
      create_telegram_config "$2" "$3" "$4"
      ;;
    
    "test")
      if [ -z "$2" ]; then
        echo "用法: $0 telegram test <账号名称>"
        return 1
      fi
      
      python3 -c "from src.multi_telegram_manager import telegram_manager; print(telegram_manager.test_account('$2'))"
      ;;
    
    "send")
      if [ -z "$2" ] || [ -z "$3" ]; then
        echo "用法: $0 telegram send <账号名称> <消息>"
        return 1
      fi
      
      python3 -c "from src.multi_telegram_manager import telegram_manager; print(telegram_manager.send_message('$3', specific_account='$2'))"
      ;;
    
    "list")
      python3 -c "from src.multi_telegram_manager import telegram_manager; accounts = telegram_manager.get_accounts(); print(f'共有 {len(accounts)} 个Telegram账号:'); [print(f'- {name}: {account.token[:10]}... (活跃: {account.is_active})') for name, account in accounts.items()]"
      ;;
    
    "remove")
      if [ -z "$2" ]; then
        echo "用法: $0 telegram remove <账号名称>"
        return 1
      fi
      
      python3 -c "from src.multi_telegram_manager import telegram_manager; print(telegram_manager.remove_account('$2'))"
      ;;
    
    "menu")
      while true; do
        echo -e "\n${BLUE}Telegram账号管理${NC}"
        echo "1. 添加新的Telegram账号"
        echo "2. 测试账号连接"
        echo "3. 发送测试消息"
        echo "4. 查看账号列表"
        echo "5. 删除账号"
        echo "0. 返回"
        echo -n "请选择: "
        read choice
        
        case $choice in
          1)
            echo -n "账号名称: "
            read name
            echo -n "Telegram Bot Token: "
            read token
            echo -n "Telegram Chat ID: "
            read chat_id
            
            create_telegram_config "$name" "$token" "$chat_id"
            ;;
          
          2)
            echo -n "账号名称 (留空测试所有账号): "
            read name
            
            if [ -z "$name" ]; then
              python3 -c "from src.multi_telegram_manager import telegram_manager; results = telegram_manager.test_all_accounts(); print(f'测试结果: {results}')"
            else
              python3 -c "from src.multi_telegram_manager import telegram_manager; print(f'测试结果: {telegram_manager.test_account(\"$name\")}')"
            fi
            ;;
          
          3)
            echo -n "账号名称: "
            read name
            echo -n "测试消息: "
            read message
            
            python3 -c "from src.multi_telegram_manager import telegram_manager; result, account = telegram_manager.send_message(\"$message\", specific_account=\"$name\"); print(f'发送结果: {result}, 使用账号: {account}')"
            ;;
          
          4)
            python3 -c "from src.multi_telegram_manager import telegram_manager; accounts = telegram_manager.get_accounts(); print(f'共有 {len(accounts)} 个Telegram账号:'); [print(f'- {name}: {account.token[:10]}... (活跃: {account.is_active})') for name, account in accounts.items()]"
            ;;
          
          5)
            echo -n "账号名称: "
            read name
            
            python3 -c "from src.multi_telegram_manager import telegram_manager; print(f'删除结果: {telegram_manager.remove_account(\"$name\")}')"
            ;;
          
          0)
            return 0
            ;;
          
          *)
            echo -e "${RED}无效选择${NC}"
            ;;
        esac
      done
      ;;
    
    *)
      echo "用法: $0 telegram <命令>"
      echo "命令:"
      echo "  add <账号名称> <Bot Token> <Chat ID>  添加Telegram账号"
      echo "  test <账号名称>                      测试账号连接"
      echo "  send <账号名称> <消息>                发送测试消息"
      echo "  list                               查看账号列表"
      echo "  remove <账号名称>                    删除账号"
      echo "  menu                               交互式菜单"
      return 1
      ;;
  esac
  
  return 0
}

# 设置向导
setup_wizard() {
  echo -e "${BLUE}设置向导${NC}"
  
  # 检查依赖
  check_dependencies
  
  # 创建必要的目录
  create_directories
  
  # 配置Telegram
  echo -e "\n${BLUE}--- Telegram配置 ---${NC}"
  echo "1. 添加新的Telegram账号"
  echo "2. 跳过Telegram配置"
  echo -n "请选择: "
  read choice
  
  if [ "$choice" == "1" ]; then
    echo -n "账号名称: "
    read name
    echo -n "Telegram Bot Token: "
    read token
    echo -n "Telegram Chat ID: "
    read chat_id
    
    # 创建Telegram配置
    mkdir -p config
    cat > telegram_accounts.json << EOF
{
  "accounts": {
    "$name": {
      "token": "$token",
      "chat_id": "$chat_id",
      "is_active": true,
      "consecutive_errors": 0
    }
  },
  "current": "$name"
}
EOF
    
    echo "Telegram账号已添加"
  fi
  
  # 配置排除币种
  echo -e "\n${BLUE}--- 排除币种配置 ---${NC}"
  echo -n "排除的币种符号 (用逗号分隔，当前: "
  
  if [ -f "config/excluded_symbols.txt" ]; then
    cat config/excluded_symbols.txt
  fi
  
  echo -n "): "
  read excluded
  
  if [ ! -z "$excluded" ]; then
    echo "$excluded" > config/excluded_symbols.txt
    echo "已更新排除币种列表"
  fi
  
  # 配置异动阈值
  echo -e "\n${BLUE}--- 异动阈值配置 ---${NC}"
  echo -n "价格异动阈值 (百分比，当前: "
  
  if [ -f "config/price_threshold.txt" ]; then
    cat config/price_threshold.txt
  else
    echo -n "30"
  fi
  
  echo -n "): "
  read price_threshold
  
  if [ ! -z "$price_threshold" ]; then
    echo "$price_threshold" > config/price_threshold.txt
    echo "已更新价格异动阈值"
  fi
  
  echo -n "交易量异动阈值 (百分比，当前: "
  
  if [ -f "config/volume_threshold.txt" ]; then
    cat config/volume_threshold.txt
  else
    echo -n "100"
  fi
  
  echo -n "): "
  read volume_threshold
  
  if [ ! -z "$volume_threshold" ]; then
    echo "$volume_threshold" > config/volume_threshold.txt
    echo "已更新交易量异动阈值"
  fi
  
  echo -e "\n${GREEN}设置完成！${NC}"
  echo "您现在可以使用 ./crypto_monitor.sh start 启动监控系统"
  
  return 0
}

# 创建启动脚本
create_startup_script() {
  echo "创建启动脚本..."
  
  # 检测操作系统类型
  if [ -d "/etc/systemd/system" ]; then
    # 创建systemd服务文件
    cat > crypto_monitor.service << EOF
[Unit]
Description=Gate.io Crypto Monitor Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
ExecStart=$(which python3) $(pwd)/main.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    echo "服务文件已创建: $(pwd)/crypto_monitor.service"
    echo "要安装为系统服务，请运行:"
    echo "sudo cp $(pwd)/crypto_monitor.service /etc/systemd/system/"
    echo "sudo systemctl daemon-reload"
    echo "sudo systemctl enable crypto_monitor.service"
    echo "sudo systemctl start crypto_monitor.service"
  else
    # 创建crontab条目
    echo "要设置开机自启，请运行:"
    echo "crontab -e"
    echo "然后添加以下行:"
    echo "@reboot cd $(pwd) && ./crypto_monitor.sh start"
  fi
}

# 主函数
main() {
  # 检查Python
  check_python
  
  # 处理命令行参数
  case "$1" in
    "start")
      check_dependencies
      create_directories
      start_monitor
      ;;
    
    "stop")
      stop_monitor
      ;;
    
    "restart")
      restart_monitor
      ;;
    
    "status")
      status_monitor
      ;;
    
    "log")
      view_log "$2"
      ;;
    
    "setup")
      setup_wizard
      ;;
    
    "telegram")
      shift
      telegram_manager "$@"
      ;;
    
    "install")
      check_dependencies
      create_directories
      create_startup_script
      setup_wizard
      ;;
    
    *)
      echo "用法: $0 <命令>"
      echo "命令:"
      echo "  start                启动监控"
      echo "  stop                 停止监控"
      echo "  restart              重启监控"
      echo "  status               查看状态"
      echo "  log [all|follow]     查看日志"
      echo "  setup                设置向导"
      echo "  telegram <子命令>     Telegram账号管理"
      echo "  install              安装为系统服务"
      ;;
  esac
}

# 执行主函数
main "$@"
