# 交易所监控系统使用说明 - Telegram推送版

## 系统概述

本系统用于监控币安美国(Binance.US)和Gate.io交易所的币种涨跌幅，并定期扫描两家交易所的公告和新上币信息，实现自动化监控和通知功能。系统通过一个统一的主控脚本提供所有功能，支持灵活的命令行参数配置，并集成了Telegram推送功能，可以实时将重要信息推送到您的Telegram账号。

## 主要功能

1. **币种价格监控**
   - 实时获取Binance.US和Gate.io所有币种的价格和涨跌幅数据
   - 支持设置涨跌幅阈值，超过阈值时触发通知
   - 自动记录显著价格变动，便于后续分析

2. **公告和新上币扫描**
   - 定期扫描交易所的公告页面
   - 智能识别新上币公告并优先提醒
   - 记录历史公告，避免重复通知

3. **Telegram实时推送**
   - 价格变动实时推送到Telegram
   - 新公告即时通知
   - 支持批量推送模式，减少消息打扰
   - 可单独设置价格推送阈值，过滤低波动率信息

4. **统一控制**
   - 单一入口脚本，简化操作
   - 多线程并行处理，提高效率
   - 灵活的命令行参数，支持自定义配置

## 系统要求

- Python 3.6+
- 必要的Python库：requests, beautifulsoup4
- Telegram账号和机器人Token

## 安装步骤

1. 确保系统已安装Python 3.6或更高版本
2. 安装必要的Python库：
   ```
   pip install requests beautifulsoup4
   ```
3. 如需使用代理功能，还需安装socks支持：
   ```
   pip install requests[socks]
   ```
4. 将所有脚本文件放置在同一目录下
5. 确保主脚本有执行权限：
   ```
   chmod +x crypto_monitor_telegram.py
   ```

## Telegram机器人配置

要使用Telegram推送功能，您需要先创建一个Telegram机器人并获取必要的Token和聊天ID：

### 1. 创建Telegram机器人

1. 在Telegram中搜索 `@BotFather` 并开始对话
2. 发送 `/newbot` 命令创建新机器人
3. 按照提示设置机器人名称和用户名
4. 创建成功后，BotFather会发送一个API Token给您，格式类似：`123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ`
5. 保存这个Token，后续配置需要使用

### 2. 获取聊天ID

方法一：通过 @userinfobot 获取
1. 在Telegram中搜索 `@userinfobot` 并开始对话
2. 机器人会自动回复您的用户ID，这就是您的聊天ID

方法二：通过API获取
1. 首先向您创建的机器人发送一条消息
2. 在浏览器中访问：`https://api.telegram.org/bot<您的TOKEN>/getUpdates`
   (将`<您的TOKEN>`替换为实际的机器人Token)
3. 在返回的JSON数据中找到 `message.chat.id` 字段，这就是您的聊天ID

### 3. 创建群组（可选）

如果您希望在群组中接收通知：
1. 创建一个新的Telegram群组
2. 将您的机器人添加为群组成员
3. 在群组中发送一条消息
4. 使用上述方法二获取群组的聊天ID（注意群组ID通常是负数）

## 使用方法

### 基本用法

使用Telegram推送功能运行：

```
./crypto_monitor_telegram.py --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID"
```

### 命令行参数

脚本支持多种命令行参数，可以灵活配置：

```
usage: crypto_monitor_telegram.py [-h] [--threshold THRESHOLD]
                                 [--price-interval PRICE_INTERVAL]
                                 [--announcement-interval ANNOUNCEMENT_INTERVAL]
                                 [--proxy] [--no-binance] [--no-gate]
                                 [--no-announcement] [--price-only]
                                 [--announcement-only] [--data-dir DATA_DIR]
                                 [--telegram] [--telegram-token TELEGRAM_TOKEN]
                                 [--telegram-chat TELEGRAM_CHAT]
                                 [--telegram-min-change TELEGRAM_MIN_CHANGE]
                                 [--no-batch] [--batch-interval BATCH_INTERVAL]
                                 [--no-price-notify]
                                 [--no-announcement-notify]

交易所监控系统 - 带Telegram推送功能

optional arguments:
  -h, --help            显示帮助信息并退出
  --threshold THRESHOLD
                        价格涨跌幅阈值，百分比 (默认: 5.0)
  --price-interval PRICE_INTERVAL
                        价格检查间隔，秒 (默认: 300)
  --announcement-interval ANNOUNCEMENT_INTERVAL
                        公告扫描间隔，秒 (默认: 3600)
  --proxy               使用代理 (默认: 不使用)
  --no-binance          禁用Binance.US监控 (默认: 启用)
  --no-gate             禁用Gate.io监控 (默认: 启用)
  --no-announcement     禁用公告扫描 (默认: 启用)
  --price-only          仅运行价格监控 (默认: 全部运行)
  --announcement-only   仅运行公告扫描 (默认: 全部运行)
  --data-dir DATA_DIR   数据存储目录 (默认: ./data)
  --telegram            启用Telegram推送 (默认: 不启用)
  --telegram-token TELEGRAM_TOKEN
                        Telegram机器人Token
  --telegram-chat TELEGRAM_CHAT
                        Telegram聊天ID
  --telegram-min-change TELEGRAM_MIN_CHANGE
                        价格变动推送的最小阈值，百分比 (默认: 10.0)
  --no-batch            禁用批量推送模式 (默认: 启用)
  --batch-interval BATCH_INTERVAL
                        批量推送间隔，秒 (默认: 60)
  --no-price-notify     禁用价格变动推送 (默认: 启用)
  --no-announcement-notify
                        禁用公告推送 (默认: 启用)
```

### Telegram推送相关参数详解

- `--telegram`: 启用Telegram推送功能
- `--telegram-token`: 您的Telegram机器人Token
- `--telegram-chat`: 您的Telegram聊天ID（个人ID或群组ID）
- `--telegram-min-change`: 价格变动推送的最小阈值（百分比），默认为10%
  - 注意：此阈值独立于系统监控阈值，可以设置更高以减少推送频率
- `--no-batch`: 禁用批量推送模式，每发现一个变动就立即推送
- `--batch-interval`: 批量推送的时间间隔（秒），默认为60秒
- `--no-price-notify`: 禁用价格变动推送，只推送公告
- `--no-announcement-notify`: 禁用公告推送，只推送价格变动

### 使用示例

1. 启用Telegram推送，设置更高的价格推送阈值（15%）：
   ```
   ./crypto_monitor_telegram.py --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID" --telegram-min-change 15.0
   ```

2. 禁用批量推送，实时接收每一条通知：
   ```
   ./crypto_monitor_telegram.py --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID" --no-batch
   ```

3. 只接收公告推送，不接收价格变动推送：
   ```
   ./crypto_monitor_telegram.py --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID" --no-price-notify
   ```

4. 使用代理并启用Telegram推送：
   ```
   ./crypto_monitor_telegram.py --proxy --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID"
   ```

## 推送消息格式

### 价格变动推送

价格变动消息格式如下：

```
🟢 Binance.US - BTCUSDT 上涨 12.34%，当前价格: 65000.0
```

或

```
🔴 Gate.io - BTC_USDT 下跌 8.75%，当前价格: 64000.0
```

### 公告推送

普通公告消息格式如下：

```
📢 Binance.US - 系统维护通知
📅 日期: 2025-06-04
🔗 链接: https://support.binance.us/...
```

新上币公告会特别标记：

```
🔔 Gate.io - [新上币] Gate.io将上线XXX代币
📅 日期: 2025-06-04
🔗 链接: https://www.gate.io/...
```

### 批量推送

在批量推送模式下，系统会将一段时间内的多条消息合并为一条发送：

```
🔔 价格监控通知

🟢 Binance.US - BTCUSDT 上涨 12.34%，当前价格: 65000.0
🔴 Gate.io - ETH_USDT 下跌 7.89%，当前价格: 3500.0
🟢 Binance.US - DOGEUSDT 上涨 25.67%，当前价格: 0.15

...还有 5 条价格变动未显示
```

## 设置为系统服务

### Linux (systemd)

创建服务文件：

```
sudo nano /etc/systemd/system/crypto-monitor.service
```

添加以下内容（替换相应的路径和参数）：

```
[Unit]
Description=Cryptocurrency Exchange Monitor with Telegram Notifications
After=network.target

[Service]
ExecStart=/path/to/crypto_monitor_telegram.py --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID"
WorkingDirectory=/path/to/script/directory
User=yourusername
Restart=on-failure
RestartSec=30s

[Install]
WantedBy=multi-user.target
```

启用并启动服务：

```
sudo systemctl enable crypto-monitor.service
sudo systemctl start crypto-monitor.service
```

查看服务状态：

```
sudo systemctl status crypto-monitor.service
```

### Windows (任务计划程序)

1. 打开任务计划程序
2. 创建基本任务
3. 触发器选择"计算机启动时"
4. 操作选择"启动程序"
5. 程序/脚本选择Python解释器路径
6. 添加参数：完整路径到`crypto_monitor_telegram.py --telegram --telegram-token "YOUR_BOT_TOKEN" --telegram-chat "YOUR_CHAT_ID"`
7. 完成配置并保存

## 故障排除

### Telegram相关问题

1. **无法发送消息**:
   - 检查Token和聊天ID是否正确
   - 确保您已经向机器人发送过至少一条消息
   - 检查网络连接和代理设置

2. **消息格式错误**:
   - Telegram的Markdown解析有时会失败，尤其是当消息中包含特殊字符时
   - 如果发现格式问题，可以查看日志中的错误信息

3. **批量推送不工作**:
   - 确保没有使用`--no-batch`参数
   - 检查是否有足够的消息积累（价格变动超过阈值）
   - 增加日志级别查看详细信息

### 其他常见问题

1. **脚本无法启动**:
   - 检查Python版本和必要库是否正确安装
   - 确保脚本有执行权限

2. **无法获取数据**:
   - 检查网络连接
   - 检查API端点是否变更
   - 查看日志文件了解详细错误信息

3. **公告扫描403错误**:
   - 尝试使用`--proxy`参数启用代理
   - 确保代理服务正常运行
   - 减少请求频率（增加`--announcement-interval`值）

## 安全注意事项

1. **Token安全**:
   - 请妥善保管您的Telegram机器人Token，不要泄露给他人
   - 如果怀疑Token泄露，请通过@BotFather重新生成

2. **命令行参数**:
   - 避免在共享环境中直接在命令行中输入Token
   - 考虑使用环境变量或配置文件存储敏感信息

3. **代理安全**:
   - 使用可信的代理服务
   - 定期更新代理配置

## 进阶使用

### 自定义消息格式

如果您希望自定义推送消息的格式，可以修改脚本中的以下函数：
- `notify_price_change`: 价格变动消息格式
- `notify_new_announcement`: 公告消息格式

### 添加更多推送渠道

系统设计为模块化，可以轻松添加其他推送渠道（如邮件、钉钉等）。只需参考Telegram推送的实现方式，添加相应的发送函数和配置参数。
