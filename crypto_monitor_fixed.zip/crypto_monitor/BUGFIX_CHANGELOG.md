# 修复日志

## 2025-06-06 修复

### 1. 修复sing-box路径问题

- 修改了`install_proxy.sh`脚本，自动检测sing-box的实际安装路径
- 更新了systemd服务文件，使用正确的sing-box路径
- 添加了符号链接创建功能，确保在`/usr/bin`和`/usr/local/bin`都能找到sing-box

### 2. 增强代理管理器功能

- 修改了`proxy_manager.py`，增加了更强大的sing-box路径检测
- 添加了服务文件自动更新功能，确保使用正确的sing-box路径
- 改进了错误处理和日志记录

### 3. 添加VLESS节点管理功能

- 新增`vless_manager.sh`脚本，提供完整的VLESS节点管理功能
- 支持添加、删除、修改、查看、测试和应用VLESS节点
- 添加了`VLESS_MANAGER_GUIDE.md`使用指南文档

## 使用方法

### 修复sing-box路径问题

如果您遇到"sing-box.service: Failed with result 'exec'"错误，请运行以下命令：

```bash
./scripts/install_proxy.sh
```

这将自动检测sing-box的正确路径并更新服务配置。

### 使用VLESS节点管理器

```bash
# 确保脚本有执行权限
chmod +x ./scripts/vless_manager.sh

# 运行VLESS节点管理器
./scripts/vless_manager.sh
```

详细使用说明请参考`VLESS_MANAGER_GUIDE.md`文档。

