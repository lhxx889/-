#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
快捷配置代理脚本
此脚本提供了简单的交互式界面，用于快速配置和管理代理。
"""

import os
import sys
import json
import time
import subprocess
import platform
import logging
from pathlib import Path

# 添加父目录到路径，以便导入proxy_manager
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from proxy_manager import ProxyManager
except ImportError:
    print("错误：无法导入ProxyManager模块。请确保您在正确的目录中运行此脚本。")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('quick_proxy_config.log')
    ]
)

logger = logging.getLogger('quick_proxy_config')

# 预设代理配置
PRESET_PROXIES = [
    {
        "name": "默认代理",
        "server": "ty.fk69.top",
        "server_port": 2026,
        "uuid": "aa05ee3d-ea0f-49e5-8692-4c4f69797110",
        "flow": "xtls-rprx-vision",
        "sni": "www.cloudflare.com",
        "public_key": "8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY",
        "short_id": ""
    },
    {
        "name": "备用代理1",
        "server": "sg.fk69.top",
        "server_port": 2087,
        "uuid": "aa05ee3d-ea0f-49e5-8692-4c4f69797110",
        "flow": "xtls-rprx-vision",
        "sni": "www.cloudflare.com",
        "public_key": "8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY",
        "short_id": ""
    },
    {
        "name": "备用代理2",
        "server": "jp.fk69.top",
        "server_port": 2053,
        "uuid": "aa05ee3d-ea0f-49e5-8692-4c4f69797110",
        "flow": "xtls-rprx-vision",
        "sni": "www.cloudflare.com",
        "public_key": "8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY",
        "short_id": ""
    }
]

def clear_screen():
    """清除屏幕"""
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def print_header():
    """打印标题"""
    clear_screen()
    print("=" * 60)
    print(" " * 20 + "快捷配置代理" + " " * 20)
    print("=" * 60)

def print_status(proxy_manager):
    """打印代理状态"""
    status = proxy_manager.get_proxy_status()
    print(f"代理安装状态: {'已安装' if status['installed'] else '未安装'}")
    print(f"代理运行状态: {'运行中' if status['running'] else '未运行'}")
    print("-" * 60)

def print_menu():
    """打印菜单"""
    print("1. 安装/更新代理")
    print("2. 启动代理服务")
    print("3. 停止代理服务")
    print("4. 测试代理连接")
    print("5. 应用代理设置到监控系统")
    print("6. 选择预设代理配置")
    print("7. 自定义代理配置")
    print("8. 查看当前代理配置")
    print("0. 退出")
    print("-" * 60)

def select_preset_proxy(proxy_manager):
    """选择预设代理配置"""
    print_header()
    print("选择预设代理配置:")
    print("-" * 60)
    
    for i, proxy in enumerate(PRESET_PROXIES):
        print(f"{i+1}. {proxy['name']} ({proxy['server']}:{proxy['server_port']})")
    
    print("0. 返回")
    print("-" * 60)
    
    choice = input("请选择 [0-{}]: ".format(len(PRESET_PROXIES)))
    
    try:
        choice = int(choice)
        if choice == 0:
            return False
        
        if 1 <= choice <= len(PRESET_PROXIES):
            proxy_settings = PRESET_PROXIES[choice-1].copy()
            # 删除name字段，因为ProxyManager不需要它
            if "name" in proxy_settings:
                del proxy_settings["name"]
            
            # 设置自定义代理
            if proxy_manager.set_custom_proxy(proxy_settings):
                print(f"已选择 {PRESET_PROXIES[choice-1]['name']} 作为代理配置")
                input("按Enter键继续...")
                return True
            else:
                print("应用代理配置失败")
                input("按Enter键继续...")
                return False
        else:
            print("无效的选择")
            input("按Enter键继续...")
            return False
    except ValueError:
        print("请输入有效的数字")
        input("按Enter键继续...")
        return False

def custom_proxy_config(proxy_manager):
    """自定义代理配置"""
    print_header()
    print("自定义代理配置:")
    print("-" * 60)
    print("请输入以下信息（直接按Enter使用默认值）:")
    
    # 获取当前配置作为默认值
    current_config = {}
    if os.path.exists("/etc/sing-box/config.json"):
        try:
            with open("/etc/sing-box/config.json", "r") as f:
                config = json.load(f)
                if "outbounds" in config and len(config["outbounds"]) > 0:
                    outbound = config["outbounds"][0]
                    current_config = {
                        "server": outbound.get("server", ""),
                        "server_port": outbound.get("server_port", 0),
                        "uuid": outbound.get("uuid", ""),
                        "flow": outbound.get("flow", ""),
                        "sni": outbound.get("tls", {}).get("server_name", ""),
                        "public_key": outbound.get("tls", {}).get("reality", {}).get("public_key", ""),
                        "short_id": outbound.get("tls", {}).get("reality", {}).get("short_id", "")
                    }
        except Exception as e:
            logger.error(f"读取当前配置失败: {e}")
    
    # 如果没有当前配置，使用默认配置
    if not current_config:
        current_config = proxy_manager.default_proxy
    
    # 收集用户输入
    server = input(f"服务器地址 [{current_config.get('server', '')}]: ").strip() or current_config.get('server', '')
    
    server_port_str = input(f"服务器端口 [{current_config.get('server_port', '')}]: ").strip() or str(current_config.get('server_port', ''))
    try:
        server_port = int(server_port_str)
    except ValueError:
        print("端口必须是数字，使用默认值")
        server_port = current_config.get('server_port', 0)
    
    uuid = input(f"UUID [{current_config.get('uuid', '')}]: ").strip() or current_config.get('uuid', '')
    flow = input(f"流控 [{current_config.get('flow', '')}]: ").strip() or current_config.get('flow', '')
    sni = input(f"SNI [{current_config.get('sni', '')}]: ").strip() or current_config.get('sni', '')
    public_key = input(f"公钥 [{current_config.get('public_key', '')}]: ").strip() or current_config.get('public_key', '')
    short_id = input(f"Short ID [{current_config.get('short_id', '')}]: ").strip() or current_config.get('short_id', '')
    
    # 创建代理配置
    proxy_settings = {
        "server": server,
        "server_port": server_port,
        "uuid": uuid,
        "flow": flow,
        "sni": sni,
        "public_key": public_key,
        "short_id": short_id
    }
    
    # 确认配置
    print("\n您的配置:")
    for key, value in proxy_settings.items():
        print(f"{key}: {value}")
    
    confirm = input("\n确认应用此配置? (y/n): ").strip().lower()
    if confirm == 'y':
        if proxy_manager.set_custom_proxy(proxy_settings):
            print("自定义代理配置已应用")
            input("按Enter键继续...")
            return True
        else:
            print("应用代理配置失败")
            input("按Enter键继续...")
            return False
    else:
        print("已取消")
        input("按Enter键继续...")
        return False

def view_current_config():
    """查看当前代理配置"""
    print_header()
    print("当前代理配置:")
    print("-" * 60)
    
    if os.path.exists("/etc/sing-box/config.json"):
        try:
            with open("/etc/sing-box/config.json", "r") as f:
                config = json.load(f)
                print(json.dumps(config, indent=2, ensure_ascii=False))
        except Exception as e:
            print(f"读取配置失败: {e}")
    else:
        print("配置文件不存在")
    
    input("\n按Enter键继续...")

def main():
    """主函数"""
    # 创建代理管理器
    proxy_manager = ProxyManager()
    
    while True:
        print_header()
        print_status(proxy_manager)
        print_menu()
        
        choice = input("请选择 [0-8]: ")
        
        if choice == '0':
            break
        elif choice == '1':
            print("正在安装/更新代理...")
            if proxy_manager.install_proxy():
                print("代理安装/更新成功")
            else:
                print("代理安装/更新失败")
            input("按Enter键继续...")
        elif choice == '2':
            print("正在启动代理服务...")
            if proxy_manager.start_proxy():
                print("代理服务启动成功")
            else:
                print("代理服务启动失败")
            input("按Enter键继续...")
        elif choice == '3':
            print("正在停止代理服务...")
            if proxy_manager.stop_proxy():
                print("代理服务停止成功")
            else:
                print("代理服务停止失败")
            input("按Enter键继续...")
        elif choice == '4':
            print("正在测试代理连接...")
            if proxy_manager.test_proxy_connection():
                print("代理连接测试成功")
            else:
                print("代理连接测试失败")
            input("按Enter键继续...")
        elif choice == '5':
            print("正在应用代理设置到监控系统...")
            if proxy_manager.apply_proxy_settings():
                print("代理设置已应用到监控系统")
            else:
                print("应用代理设置失败")
            input("按Enter键继续...")
        elif choice == '6':
            select_preset_proxy(proxy_manager)
        elif choice == '7':
            custom_proxy_config(proxy_manager)
        elif choice == '8':
            view_current_config()
        else:
            print("无效的选择")
            input("按Enter键继续...")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n程序已退出")
    except Exception as e:
        logger.error(f"程序异常: {e}")
        print(f"程序异常: {e}")

