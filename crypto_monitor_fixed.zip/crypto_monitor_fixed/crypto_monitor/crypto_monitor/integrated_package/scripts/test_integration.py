#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试整合后的功能
"""

import os
import sys
import json
import time
import subprocess
import logging
from pathlib import Path

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('test_integration.log')
    ]
)

logger = logging.getLogger('test_integration')

def check_file_exists(file_path):
    """检查文件是否存在"""
    exists = os.path.exists(file_path)
    logger.info(f"检查文件 {file_path}: {'存在' if exists else '不存在'}")
    return exists

def check_file_executable(file_path):
    """检查文件是否可执行"""
    executable = os.access(file_path, os.X_OK)
    logger.info(f"检查文件 {file_path} 是否可执行: {'是' if executable else '否'}")
    return executable

def test_file_structure():
    """测试文件结构"""
    logger.info("测试文件结构...")
    
    # 定义需要检查的文件列表
    files_to_check = [
        "crypto_monitor_menu.py",
        "scripts/quick_proxy.sh",
        "scripts/quick_proxy_config.py",
        "QUICK_PROXY_GUIDE.md"
    ]
    
    # 检查文件是否存在
    all_exist = True
    for file in files_to_check:
        file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), file)
        if not check_file_exists(file_path):
            all_exist = False
    
    # 检查脚本是否可执行
    scripts_to_check = [
        "crypto_monitor_menu.py",
        "scripts/quick_proxy.sh",
        "scripts/quick_proxy_config.py"
    ]
    
    all_executable = True
    for script in scripts_to_check:
        script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), script)
        if not check_file_executable(script_path):
            all_executable = False
    
    return all_exist and all_executable

def test_menu_integration():
    """测试主菜单整合"""
    logger.info("测试主菜单整合...")
    
    # 检查主菜单脚本中是否包含快捷配置代理选项
    menu_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "crypto_monitor_menu.py")
    
    try:
        with open(menu_path, 'r') as f:
            content = f.read()
            
            # 检查是否包含快捷配置代理选项
            has_menu_option = "6. 快捷配置代理" in content
            logger.info(f"主菜单中是否包含快捷配置代理选项: {'是' if has_menu_option else '否'}")
            
            # 检查是否包含quick_proxy_config函数
            has_function = "def quick_proxy_config():" in content
            logger.info(f"主菜单中是否包含quick_proxy_config函数: {'是' if has_function else '否'}")
            
            # 检查是否在主函数中调用了quick_proxy_config函数
            has_function_call = 'elif choice == "6":\n            quick_proxy_config()' in content
            logger.info(f"主菜单中是否调用了quick_proxy_config函数: {'是' if has_function_call else '否'}")
            
            return has_menu_option and has_function and has_function_call
    except Exception as e:
        logger.error(f"测试主菜单整合失败: {e}")
        return False

def test_quick_proxy_script():
    """测试快捷配置代理脚本"""
    logger.info("测试快捷配置代理脚本...")
    
    # 检查快捷配置代理脚本是否包含必要的功能
    script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "quick_proxy_config.py")
    
    try:
        with open(script_path, 'r') as f:
            content = f.read()
            
            # 检查是否包含预设代理配置
            has_preset_proxies = "PRESET_PROXIES = [" in content
            logger.info(f"快捷配置代理脚本中是否包含预设代理配置: {'是' if has_preset_proxies else '否'}")
            
            # 检查是否包含主要功能函数
            has_functions = all(func in content for func in [
                "def select_preset_proxy(",
                "def custom_proxy_config(",
                "def view_current_config("
            ])
            logger.info(f"快捷配置代理脚本中是否包含主要功能函数: {'是' if has_functions else '否'}")
            
            return has_preset_proxies and has_functions
    except Exception as e:
        logger.error(f"测试快捷配置代理脚本失败: {e}")
        return False

def test_launcher_script():
    """测试启动器脚本"""
    logger.info("测试启动器脚本...")
    
    # 检查启动器脚本是否包含必要的功能
    script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "quick_proxy.sh")
    
    try:
        with open(script_path, 'r') as f:
            content = f.read()
            
            # 检查是否包含必要的命令
            has_commands = all(cmd in content for cmd in [
                "python3 \"$SCRIPT_DIR/quick_proxy_config.py\"",
                "SCRIPT_DIR=\"$( cd \"$( dirname \"${BASH_SOURCE[0]}\" )\" &> /dev/null && pwd )\"",
                "PROJECT_DIR=\"$(dirname \"$SCRIPT_DIR\")\""
            ])
            logger.info(f"启动器脚本中是否包含必要的命令: {'是' if has_commands else '否'}")
            
            return has_commands
    except Exception as e:
        logger.error(f"测试启动器脚本失败: {e}")
        return False

def test_guide_document():
    """测试使用指南文档"""
    logger.info("测试使用指南文档...")
    
    # 检查使用指南文档是否包含必要的内容
    doc_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "QUICK_PROXY_GUIDE.md")
    
    try:
        with open(doc_path, 'r') as f:
            content = f.read()
            
            # 检查是否包含必要的内容
            has_content = all(section in content for section in [
                "# 快捷配置代理使用指南",
                "## 功能特点",
                "## 使用方法",
                "## 常见问题"
            ])
            logger.info(f"使用指南文档中是否包含必要的内容: {'是' if has_content else '否'}")
            
            return has_content
    except Exception as e:
        logger.error(f"测试使用指南文档失败: {e}")
        return False

def main():
    """主函数"""
    print("=" * 60)
    print("            测试整合后的功能")
    print("=" * 60)
    
    # 测试文件结构
    file_structure_result = test_file_structure()
    print("-" * 60)
    
    # 测试主菜单整合
    menu_integration_result = test_menu_integration()
    print("-" * 60)
    
    # 测试快捷配置代理脚本
    quick_proxy_script_result = test_quick_proxy_script()
    print("-" * 60)
    
    # 测试启动器脚本
    launcher_script_result = test_launcher_script()
    print("-" * 60)
    
    # 测试使用指南文档
    guide_document_result = test_guide_document()
    
    print("-" * 60)
    print("测试结果汇总:")
    print(f"文件结构测试: {'通过' if file_structure_result else '失败'}")
    print(f"主菜单整合测试: {'通过' if menu_integration_result else '失败'}")
    print(f"快捷配置代理脚本测试: {'通过' if quick_proxy_script_result else '失败'}")
    print(f"启动器脚本测试: {'通过' if launcher_script_result else '失败'}")
    print(f"使用指南文档测试: {'通过' if guide_document_result else '失败'}")
    
    # 总体测试结果
    all_passed = all([
        file_structure_result,
        menu_integration_result,
        quick_proxy_script_result,
        launcher_script_result,
        guide_document_result
    ])
    
    print("\n总体测试结果: " + ("通过" if all_passed else "失败"))
    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())

