#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
加密货币监控系统 - 优化版
集成API智能管理器，解决API请求限制问题
"""

import os
import sys
import json
import time
import logging
import threading
import argparse
import signal
import datetime
import pytz
from typing import Dict, Any, List, Optional, Tuple, Union

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 导入API管理器
try:
    from crypto_monitor_api_manager import get_api_manager
except ImportError:
    print("错误: 找不到crypto_monitor_api_manager.py模块")
    print("请确保该文件与本脚本位于同一目录")
    sys.exit(1)

# 尝试导入模块，如果失败则提示安装
try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("缺少必要的Python库。请运行以下命令安装：")
    print("pip install requests beautifulsoup4 pytz")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "crypto_monitor_optimized.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("crypto_monitor_optimized")

# 默认配置
DEFAULT_CONFIG = {
    "data_dir": os.path.join(script_dir, "data"),
    "price_threshold": 5.0,  # 价格变动阈值（百分比）
    "notification_threshold": 10.0,  # 通知阈值（百分比）
    "price_check_interval": 300,  # 价格检查间隔（秒）
    "announcement_check_interval": 1800,  # 公告检查间隔（秒）
    "telegram": {
        "enabled": False,
        "token": "",
        "chat_id": "",
        "batch_mode": True,
        "batch_interval": 300  # 批量发送间隔（秒）
    },
    "exchanges": {
        "binance_us": {
            "enabled": True,
            "api_base_url": "https://api.binance.us",
            "announcement_url": "https://www.binance.us/en/support/announcement"
        },
        "gate_io": {
            "enabled": True,
            "api_base_url": "https://api.gateio.ws/api/v4",
            "announcement_url": "https://www.gate.io/article/16"
        }
    },
    "use_proxy": False,
    "proxy": {
        "http": "socks5://127.0.0.1:1080",
        "https": "socks5://127.0.0.1:1080"
    },
    "display": {
        "use_shanghai_time": True,
        "show_coin_details": True,
        "show_holders_count": True,
        "show_social_links": True,
        "show_price_change_reason": True
    },
    "api_manager": {
        "cache_expiry": {
            "coin_list": 86400,  # 24小时
            "coin_detail": 3600,  # 1小时
            "market_data": 300    # 5分钟
        },
        "data_sources": {
            "coingecko": {
                "enabled": True,
                "priority": 1,
                "api_key": ""
            },
            "coinmarketcap": {
                "enabled": True,
                "priority": 2,
                "api_key": ""
            }
        }
    }
}

class CryptoMonitor:
    """加密货币监控系统"""
    
    def __init__(self, config_file=None):
        """初始化监控系统"""
        self.config = DEFAULT_CONFIG.copy()
        if config_file and os.path.exists(config_file):
            self._load_config(config_file)
        
        # 确保数据目录存在
        if not os.path.exists(self.config["data_dir"]):
            os.makedirs(self.config["data_dir"])
        
        # 初始化API管理器
        self.api_manager = get_api_manager()
        
        # 更新API管理器配置
        self._update_api_manager_config()
        
        # 初始化Telegram通知队列
        self.telegram_queue = []
        self.telegram_lock = threading.Lock()
        
        # 初始化停止标志
        self.stop_flag = threading.Event()
        
        # 加载历史数据
        self.price_history = self._load_json_data("price_history.json", {})
        self.significant_changes = self._load_json_data("significant_price_changes.json", [])
        self.announcement_history = self._load_json_data("announcement_history.json", {})
        
        logger.info("加密货币监控系统初始化完成")
    
    def _load_config(self, config_file):
        """从文件加载配置"""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
                # 递归更新配置
                self._update_config(self.config, user_config)
            logger.info(f"已从{config_file}加载配置")
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
    
    def _update_config(self, target, source):
        """递归更新配置"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._update_config(target[key], value)
            else:
                target[key] = value
    
    def _update_api_manager_config(self):
        """更新API管理器配置"""
        # 更新缓存过期时间
        self.api_manager.config["cache_expiry"] = self.config["api_manager"]["cache_expiry"]
        
        # 更新数据源配置
        for source, source_config in self.config["api_manager"]["data_sources"].items():
            if source in self.api_manager.config["data_sources"]:
                self.api_manager.config["data_sources"][source]["enabled"] = source_config["enabled"]
                self.api_manager.config["data_sources"][source]["priority"] = source_config["priority"]
                if source_config["api_key"]:
                    self.api_manager.config["data_sources"][source]["api_key"] = source_config["api_key"]
        
        # 更新代理配置
        self.api_manager.config["use_proxy"] = self.config["use_proxy"]
        self.api_manager.config["proxy"] = self.config["proxy"]
    
    def _save_config(self, config_file="config.json"):
        """保存配置到文件"""
        try:
            with open(os.path.join(script_dir, config_file), 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            logger.info(f"已保存配置到{config_file}")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {e}")
            return False
    
    def _load_json_data(self, filename, default=None):
        """加载JSON数据"""
        file_path = os.path.join(self.config["data_dir"], filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"加载{filename}失败: {e}")
        return default if default is not None else {}
    
    def _save_json_data(self, data, filename):
        """保存JSON数据"""
        file_path = os.path.join(self.config["data_dir"], filename)
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"保存{filename}失败: {e}")
            return False
    
    def _get_shanghai_time(self):
        """获取上海时间"""
        if self.config["display"]["use_shanghai_time"]:
            shanghai_tz = pytz.timezone('Asia/Shanghai')
            return datetime.datetime.now(shanghai_tz).strftime('%Y-%m-%d %H:%M:%S CST%z')
        else:
            return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')
    
    def _send_telegram_message(self, message):
        """发送Telegram消息"""
        if not self.config["telegram"]["enabled"] or not self.config["telegram"]["token"] or not self.config["telegram"]["chat_id"]:
            logger.warning("Telegram未配置，跳过发送消息")
            return False
        
        try:
            url = f"https://api.telegram.org/bot{self.config['telegram']['token']}/sendMessage"
            data = {
                "chat_id": self.config["telegram"]["chat_id"],
                "text": message,
                "parse_mode": "Markdown"
            }
            
            # 是否使用代理
            proxies = self.config["proxy"] if self.config["use_proxy"] else None
            
            response = requests.post(url, data=data, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            logger.info("Telegram消息发送成功")
            return True
        except Exception as e:
            logger.error(f"发送Telegram消息失败: {e}")
            return False
    
    def _queue_telegram_message(self, message):
        """将消息加入Telegram队列"""
        if not self.config["telegram"]["enabled"]:
            return
        
        with self.telegram_lock:
            self.telegram_queue.append(message)
        
        # 如果不使用批量模式，立即发送
        if not self.config["telegram"]["batch_mode"]:
            self._send_queued_messages()
    
    def _send_queued_messages(self):
        """发送队列中的消息"""
        if not self.config["telegram"]["enabled"] or not self.telegram_queue:
            return
        
        with self.telegram_lock:
            # 如果队列中有消息，合并发送
            if self.telegram_queue:
                combined_message = "\n\n".join(self.telegram_queue)
                success = self._send_telegram_message(combined_message)
                if success:
                    self.telegram_queue.clear()
    
    def _get_coin_details(self, symbol, exchange, price, change_percent):
        """获取币种详细信息"""
        if not self.config["display"]["show_coin_details"]:
            return f"{'🟢' if change_percent > 0 else '🔴'} {exchange} - {symbol} {'上涨' if change_percent > 0 else '下跌'} {abs(change_percent):.2f}%\n💰 当前价格: {price}\n🕒 时间: {self._get_shanghai_time()}"
        
        # 尝试获取币种详情
        try:
            # 从符号中提取基础币种（去掉交易对后缀）
            base_symbol = symbol.split('_')[0] if '_' in symbol else symbol.split('/')[0] if '/' in symbol else symbol
            if base_symbol.endswith('USDT') or base_symbol.endswith('USD'):
                base_symbol = base_symbol[:-4]
            elif base_symbol.endswith('BTC'):
                base_symbol = base_symbol[:-3]
            
            # 获取币种所有信息
            coin_info = self.api_manager.get_coin_all_info(base_symbol)
            
            if not coin_info:
                # 如果获取失败，返回基本信息
                return f"{'🟢' if change_percent > 0 else '🔴'} {exchange} - {symbol} {'上涨' if change_percent > 0 else '下跌'} {abs(change_percent):.2f}%\n💰 当前价格: {price}\n🕒 时间: {self._get_shanghai_time()}"
            
            # 构建详细消息
            message = f"{'🟢' if change_percent > 0 else '🔴'} {exchange} - {symbol} {'上涨' if change_percent > 0 else '下跌'} {abs(change_percent):.2f}%\n"
            message += f"💰 当前价格: {price}\n"
            
            # 市场数据
            market_data = coin_info.get("market_data", {})
            if market_data:
                if market_data.get("market_cap"):
                    message += f"🏦 市值: ${self._format_number(market_data.get('market_cap'))}\n"
                if market_data.get("total_volume"):
                    message += f"📊 24h交易量: ${self._format_number(market_data.get('total_volume'))}\n"
                if market_data.get("price_change_7d"):
                    message += f"📈 7天变化: {'+' if market_data.get('price_change_7d', 0) > 0 else ''}{market_data.get('price_change_7d', 0):.2f}%\n"
                if market_data.get("price_change_30d"):
                    message += f"📉 30天变化: {'+' if market_data.get('price_change_30d', 0) > 0 else ''}{market_data.get('price_change_30d', 0):.2f}%\n"
            
            # 持币人数
            if self.config["display"]["show_holders_count"] and coin_info.get("holders_count"):
                message += f"👥 持币人数: {self._format_number(coin_info.get('holders_count'))}\n"
            
            # 流通量
            if market_data and market_data.get("circulating_supply"):
                message += f"🔄 流通量: {self._format_number(market_data.get('circulating_supply'))} {base_symbol}\n"
            
            # 社交媒体链接
            if self.config["display"]["show_social_links"]:
                social_data = coin_info.get("social_data", {})
                links = social_data.get("links", {})
                
                if links:
                    message += "\n🔗 链接:\n"
                    
                    # 官网
                    if links.get("homepage") and links["homepage"]:
                        message += f"🌐 官网: {links['homepage'][0]}\n"
                    
                    # Telegram
                    if links.get("telegram_channel_identifier") or links.get("chat_url"):
                        telegram_link = links.get("chat_url", [])
                        if telegram_link and isinstance(telegram_link, list) and telegram_link[0]:
                            message += f"📱 Telegram: {telegram_link[0]}\n"
                    
                    # Twitter/X
                    if links.get("twitter_screen_name"):
                        message += f"🐦 X/Twitter: https://twitter.com/{links['twitter_screen_name']}\n"
            
            # 价格变动原因分析
            if self.config["display"]["show_price_change_reason"]:
                reasons = self._analyze_price_change_reason(coin_info, change_percent)
                if reasons:
                    message += f"\n📝 可能原因: {', '.join(reasons)}\n"
            
            # 时间
            message += f"\n🕒 时间: {self._get_shanghai_time()}"
            
            return message
        
        except Exception as e:
            logger.error(f"获取币种详情失败: {e}")
            # 如果出错，返回基本信息
            return f"{'🟢' if change_percent > 0 else '🔴'} {exchange} - {symbol} {'上涨' if change_percent > 0 else '下跌'} {abs(change_percent):.2f}%\n💰 当前价格: {price}\n🕒 时间: {self._get_shanghai_time()}"
    
    def _format_number(self, number):
        """格式化数字，添加千位分隔符"""
        if number is None:
            return "N/A"
        
        if isinstance(number, str):
            try:
                number = float(number)
            except:
                return number
        
        if number >= 1_000_000_000:
            return f"{number / 1_000_000_000:.2f}B"
        elif number >= 1_000_000:
            return f"{number / 1_000_000:.2f}M"
        elif number >= 1_000:
            return f"{number / 1_000:.2f}K"
        else:
            return f"{number:.2f}"
    
    def _analyze_price_change_reason(self, coin_info, change_percent):
        """分析价格变动可能的原因"""
        reasons = []
        
        try:
            market_data = coin_info.get("market_data", {})
            
            # 交易量变化
            if market_data.get("total_volume") and market_data.get("market_cap"):
                volume_to_mcap_ratio = market_data["total_volume"] / market_data["market_cap"]
                if volume_to_mcap_ratio > 0.2:  # 交易量超过市值的20%
                    reasons.append("交易量大幅增加")
            
            # 市值排名变化
            if market_data.get("market_cap_rank_change"):
                rank_change = market_data.get("market_cap_rank_change")
                if abs(rank_change) >= 5:
                    direction = "上升" if rank_change < 0 else "下降"  # 排名数字减小表示上升
                    reasons.append(f"市值排名{direction}")
            
            # 趋势分析
            if market_data.get("trend") and market_data.get("trend_strength", 0) > 5:
                if change_percent > 0 and market_data["trend"] == "上升":
                    reasons.append("延续上涨趋势")
                elif change_percent < 0 and market_data["trend"] == "下降":
                    reasons.append("延续下跌趋势")
                elif change_percent > 0 and market_data["trend"] == "下降":
                    reasons.append("反转下跌趋势")
                elif change_percent < 0 and market_data["trend"] == "上升":
                    reasons.append("反转上涨趋势")
            
            # 波动性分析
            if market_data.get("volatility", 0) > 10:
                reasons.append("市场波动性高")
            
            # 相关新闻
            news = self.api_manager.get_coin_news(coin_info.get("basic_info", {}).get("id"))
            if news:
                reasons.append(f"有{len(news)}条相关新闻")
        
        except Exception as e:
            logger.error(f"分析价格变动原因失败: {e}")
        
        # 如果没有找到原因，添加一个通用原因
        if not reasons:
            if abs(change_percent) > 20:
                reasons.append("市场情绪剧烈波动")
            elif abs(change_percent) > 10:
                reasons.append("市场短期波动")
            else:
                reasons.append("正常市场波动")
        
        return reasons
    
    def check_binance_us_prices(self):
        """检查Binance.US价格"""
        if not self.config["exchanges"]["binance_us"]["enabled"]:
            logger.info("Binance.US已禁用，跳过价格检查")
            return
        
        try:
            # 获取所有交易对的24小时统计
            url = f"{self.config['exchanges']['binance_us']['api_base_url']}/api/v3/ticker/24hr"
            
            # 是否使用代理
            proxies = self.config["proxy"] if self.config["use_proxy"] else None
            
            response = requests.get(url, proxies=proxies, timeout=10)
            response.raise_for_status()
            tickers = response.json()
            
            for ticker in tickers:
                symbol = ticker.get("symbol")
                price = float(ticker.get("lastPrice", 0))
                price_change_percent = float(ticker.get("priceChangePercent", 0))
                
                # 记录价格历史
                if "binance_us" not in self.price_history:
                    self.price_history["binance_us"] = {}
                self.price_history["binance_us"][symbol] = {
                    "price": price,
                    "timestamp": time.time()
                }
                
                # 检查是否超过阈值
                if abs(price_change_percent) >= self.config["price_threshold"]:
                    logger.info(f"Binance.US - {symbol} {'上涨' if price_change_percent > 0 else '下跌'} {abs(price_change_percent):.2f}%, 当前价格: {price} ({self._get_shanghai_time()})")
                    
                    # 记录显著变化
                    self.significant_changes.append({
                        "exchange": "Binance.US",
                        "symbol": symbol,
                        "price": price,
                        "change_percent": price_change_percent,
                        "timestamp": time.time()
                    })
                    
                    # 如果超过通知阈值，发送通知
                    if abs(price_change_percent) >= self.config["notification_threshold"]:
                        message = self._get_coin_details(symbol, "Binance.US", price, price_change_percent)
                        self._queue_telegram_message(message)
            
            # 保存数据
            self._save_json_data(self.price_history, "price_history.json")
            self._save_json_data(self.significant_changes, "significant_price_changes.json")
            
            logger.info(f"Binance.US价格检查完成，共{len(tickers)}个交易对")
        
        except Exception as e:
            logger.error(f"检查Binance.US价格失败: {e}")
    
    def check_gate_io_prices(self):
        """检查Gate.io价格"""
        if not self.config["exchanges"]["gate_io"]["enabled"]:
            logger.info("Gate.io已禁用，跳过价格检查")
            return
        
        try:
            # 获取所有交易对的24小时统计
            url = f"{self.config['exchanges']['gate_io']['api_base_url']}/spot/tickers"
            
            # 是否使用代理
            proxies = self.config["proxy"] if self.config["use_proxy"] else None
            
            response = requests.get(url, proxies=proxies, timeout=10)
            response.raise_for_status()
            tickers = response.json()
            
            for ticker in tickers:
                symbol = ticker.get("currency_pair")
                price = float(ticker.get("last", 0))
                
                # 计算价格变化百分比
                change_str = ticker.get("change_percentage", "0")
                try:
                    # Gate.io返回的是带百分号的字符串，如"5.2%"
                    price_change_percent = float(change_str.rstrip("%"))
                except:
                    price_change_percent = 0
                
                # 记录价格历史
                if "gate_io" not in self.price_history:
                    self.price_history["gate_io"] = {}
                self.price_history["gate_io"][symbol] = {
                    "price": price,
                    "timestamp": time.time()
                }
                
                # 检查是否超过阈值
                if abs(price_change_percent) >= self.config["price_threshold"]:
                    logger.info(f"Gate.io - {symbol} {'上涨' if price_change_percent > 0 else '下跌'} {abs(price_change_percent):.2f}%, 当前价格: {price} ({self._get_shanghai_time()})")
                    
                    # 记录显著变化
                    self.significant_changes.append({
                        "exchange": "Gate.io",
                        "symbol": symbol,
                        "price": price,
                        "change_percent": price_change_percent,
                        "timestamp": time.time()
                    })
                    
                    # 如果超过通知阈值，发送通知
                    if abs(price_change_percent) >= self.config["notification_threshold"]:
                        message = self._get_coin_details(symbol, "Gate.io", price, price_change_percent)
                        self._queue_telegram_message(message)
            
            # 保存数据
            self._save_json_data(self.price_history, "price_history.json")
            self._save_json_data(self.significant_changes, "significant_price_changes.json")
            
            logger.info(f"Gate.io价格检查完成，共{len(tickers)}个交易对")
        
        except Exception as e:
            logger.error(f"检查Gate.io价格失败: {e}")
    
    def check_binance_us_announcements(self):
        """检查Binance.US公告"""
        if not self.config["exchanges"]["binance_us"]["enabled"]:
            logger.info("Binance.US已禁用，跳过公告检查")
            return
        
        try:
            # 获取公告页面
            url = self.config["exchanges"]["binance_us"]["announcement_url"]
            
            # 是否使用代理
            proxies = self.config["proxy"] if self.config["use_proxy"] else None
            
            response = requests.get(url, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 查找公告列表
            announcements = []
            
            # 这里的选择器需要根据实际网页结构调整
            for article in soup.select('article') or soup.select('.article-item'):
                try:
                    title_elem = article.select_one('h3') or article.select_one('.title')
                    link_elem = article.select_one('a')
                    date_elem = article.select_one('.date') or article.select_one('time')
                    
                    if title_elem and link_elem:
                        title = title_elem.text.strip()
                        link = link_elem.get('href')
                        if not link.startswith('http'):
                            link = f"https://www.binance.us{link}"
                        
                        date = date_elem.text.strip() if date_elem else ""
                        
                        announcements.append({
                            "title": title,
                            "link": link,
                            "date": date,
                            "timestamp": time.time()
                        })
                except Exception as e:
                    logger.error(f"解析Binance.US公告项失败: {e}")
            
            # 检查新公告
            if "binance_us" not in self.announcement_history:
                self.announcement_history["binance_us"] = []
            
            existing_titles = [a["title"] for a in self.announcement_history["binance_us"]]
            new_announcements = [a for a in announcements if a["title"] not in existing_titles]
            
            # 更新历史记录
            self.announcement_history["binance_us"] = announcements
            self._save_json_data(self.announcement_history, "announcement_history.json")
            
            # 发送新公告通知
            for announcement in new_announcements:
                logger.info(f"Binance.US新公告: {announcement['title']}")
                
                # 检查是否是新上币公告
                is_new_listing = any(keyword in announcement["title"].lower() for keyword in ["list", "listing", "新增", "上线", "new"])
                
                # 构建消息
                message = f"{'🔔🔔🔔 新上币公告 🔔🔔🔔' if is_new_listing else '📢 Binance.US新公告'}\n\n"
                message += f"**{announcement['title']}**\n\n"
                if announcement["date"]:
                    message += f"日期: {announcement['date']}\n"
                message += f"链接: {announcement['link']}\n"
                message += f"\n🕒 时间: {self._get_shanghai_time()}"
                
                # 发送通知
                self._queue_telegram_message(message)
            
            logger.info(f"Binance.US公告检查完成，共{len(announcements)}条公告，{len(new_announcements)}条新公告")
        
        except Exception as e:
            logger.error(f"检查Binance.US公告失败: {e}")
    
    def check_gate_io_announcements(self):
        """检查Gate.io公告"""
        if not self.config["exchanges"]["gate_io"]["enabled"]:
            logger.info("Gate.io已禁用，跳过公告检查")
            return
        
        try:
            # 获取公告页面
            url = self.config["exchanges"]["gate_io"]["announcement_url"]
            
            # 是否使用代理
            proxies = self.config["proxy"] if self.config["use_proxy"] else None
            
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
            
            response = requests.get(url, headers=headers, proxies=proxies, timeout=10)
            response.raise_for_status()
            
            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 查找公告列表
            announcements = []
            
            # 这里的选择器需要根据实际网页结构调整
            for article in soup.select('.article-list li') or soup.select('.article-item'):
                try:
                    title_elem = article.select_one('a') or article.select_one('.title')
                    link_elem = article.select_one('a')
                    date_elem = article.select_one('.date') or article.select_one('time')
                    
                    if title_elem and link_elem:
                        title = title_elem.text.strip()
                        link = link_elem.get('href')
                        if not link.startswith('http'):
                            link = f"https://www.gate.io{link}"
                        
                        date = date_elem.text.strip() if date_elem else ""
                        
                        announcements.append({
                            "title": title,
                            "link": link,
                            "date": date,
                            "timestamp": time.time()
                        })
                except Exception as e:
                    logger.error(f"解析Gate.io公告项失败: {e}")
            
            # 检查新公告
            if "gate_io" not in self.announcement_history:
                self.announcement_history["gate_io"] = []
            
            existing_titles = [a["title"] for a in self.announcement_history["gate_io"]]
            new_announcements = [a for a in announcements if a["title"] not in existing_titles]
            
            # 更新历史记录
            self.announcement_history["gate_io"] = announcements
            self._save_json_data(self.announcement_history, "announcement_history.json")
            
            # 发送新公告通知
            for announcement in new_announcements:
                logger.info(f"Gate.io新公告: {announcement['title']}")
                
                # 检查是否是新上币公告
                is_new_listing = any(keyword in announcement["title"].lower() for keyword in ["list", "listing", "新增", "上线", "new"])
                
                # 构建消息
                message = f"{'🔔🔔🔔 新上币公告 🔔🔔🔔' if is_new_listing else '📢 Gate.io新公告'}\n\n"
                message += f"**{announcement['title']}**\n\n"
                if announcement["date"]:
                    message += f"日期: {announcement['date']}\n"
                message += f"链接: {announcement['link']}\n"
                message += f"\n🕒 时间: {self._get_shanghai_time()}"
                
                # 发送通知
                self._queue_telegram_message(message)
            
            logger.info(f"Gate.io公告检查完成，共{len(announcements)}条公告，{len(new_announcements)}条新公告")
        
        except Exception as e:
            logger.error(f"检查Gate.io公告失败: {e}")
    
    def price_monitor_thread(self):
        """价格监控线程"""
        logger.info("价格监控线程已启动")
        
        while not self.stop_flag.is_set():
            try:
                # 检查Binance.US价格
                self.check_binance_us_prices()
                
                # 检查Gate.io价格
                self.check_gate_io_prices()
                
                # 等待下一次检查
                for _ in range(self.config["price_check_interval"]):
                    if self.stop_flag.is_set():
                        break
                    time.sleep(1)
            
            except Exception as e:
                logger.error(f"价格监控线程异常: {e}")
                time.sleep(60)  # 出错后等待一分钟再重试
    
    def announcement_monitor_thread(self):
        """公告监控线程"""
        logger.info("公告监控线程已启动")
        
        while not self.stop_flag.is_set():
            try:
                # 检查Binance.US公告
                self.check_binance_us_announcements()
                
                # 检查Gate.io公告
                self.check_gate_io_announcements()
                
                # 等待下一次检查
                for _ in range(self.config["announcement_check_interval"]):
                    if self.stop_flag.is_set():
                        break
                    time.sleep(1)
            
            except Exception as e:
                logger.error(f"公告监控线程异常: {e}")
                time.sleep(60)  # 出错后等待一分钟再重试
    
    def telegram_sender_thread(self):
        """Telegram发送线程"""
        logger.info("Telegram发送线程已启动")
        
        while not self.stop_flag.is_set():
            try:
                # 如果使用批量模式，定期发送队列中的消息
                if self.config["telegram"]["enabled"] and self.config["telegram"]["batch_mode"]:
                    self._send_queued_messages()
                
                # 等待下一次发送
                for _ in range(self.config["telegram"]["batch_interval"]):
                    if self.stop_flag.is_set():
                        break
                    time.sleep(1)
            
            except Exception as e:
                logger.error(f"Telegram发送线程异常: {e}")
                time.sleep(60)  # 出错后等待一分钟再重试
    
    def start(self):
        """启动监控系统"""
        logger.info("启动加密货币监控系统")
        
        # 重置停止标志
        self.stop_flag.clear()
        
        # 启动价格监控线程
        price_thread = threading.Thread(target=self.price_monitor_thread)
        price_thread.daemon = True
        price_thread.start()
        
        # 启动公告监控线程
        announcement_thread = threading.Thread(target=self.announcement_monitor_thread)
        announcement_thread.daemon = True
        announcement_thread.start()
        
        # 启动Telegram发送线程
        telegram_thread = threading.Thread(target=self.telegram_sender_thread)
        telegram_thread.daemon = True
        telegram_thread.start()
        
        # 注册信号处理器
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info("所有监控线程已启动")
        
        # 主线程等待
        try:
            while not self.stop_flag.is_set():
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop()
    
    def stop(self):
        """停止监控系统"""
        logger.info("停止加密货币监控系统")
        self.stop_flag.set()
        
        # 发送剩余的消息
        self._send_queued_messages()
        
        # 保存数据
        self._save_json_data(self.price_history, "price_history.json")
        self._save_json_data(self.significant_changes, "significant_price_changes.json")
        self._save_json_data(self.announcement_history, "announcement_history.json")
        
        logger.info("加密货币监控系统已停止")
    
    def _signal_handler(self, sig, frame):
        """信号处理器"""
        logger.info(f"接收到信号 {sig}，准备停止")
        self.stop()

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="加密货币监控系统 - 优化版")
    parser.add_argument("--config", help="配置文件路径", default="config.json")
    parser.add_argument("--price-only", help="仅监控价格", action="store_true")
    parser.add_argument("--announcement-only", help="仅监控公告", action="store_true")
    parser.add_argument("--telegram", help="启用Telegram通知", action="store_true")
    parser.add_argument("--telegram-token", help="Telegram机器人Token")
    parser.add_argument("--telegram-chat", help="Telegram聊天ID")
    parser.add_argument("--proxy", help="启用代理", action="store_true")
    parser.add_argument("--threshold", help="价格变动阈值（百分比）", type=float)
    parser.add_argument("--notification-threshold", help="通知阈值（百分比）", type=float)
    parser.add_argument("--price-interval", help="价格检查间隔（秒）", type=int)
    parser.add_argument("--announcement-interval", help="公告检查间隔（秒）", type=int)
    
    args = parser.parse_args()
    
    # 创建监控系统
    monitor = CryptoMonitor(args.config)
    
    # 应用命令行参数
    if args.telegram:
        monitor.config["telegram"]["enabled"] = True
    if args.telegram_token:
        monitor.config["telegram"]["token"] = args.telegram_token
    if args.telegram_chat:
        monitor.config["telegram"]["chat_id"] = args.telegram_chat
    if args.proxy:
        monitor.config["use_proxy"] = True
    if args.threshold:
        monitor.config["price_threshold"] = args.threshold
    if args.notification_threshold:
        monitor.config["notification_threshold"] = args.notification_threshold
    if args.price_interval:
        monitor.config["price_check_interval"] = args.price_interval
    if args.announcement_interval:
        monitor.config["announcement_check_interval"] = args.announcement_interval
    
    # 如果指定了仅监控价格或仅监控公告
    if args.price_only:
        monitor.config["exchanges"]["binance_us"]["enabled"] = True
        monitor.config["exchanges"]["gate_io"]["enabled"] = True
        monitor.check_binance_us_prices()
        monitor.check_gate_io_prices()
        return
    
    if args.announcement_only:
        monitor.config["exchanges"]["binance_us"]["enabled"] = True
        monitor.config["exchanges"]["gate_io"]["enabled"] = True
        monitor.check_binance_us_announcements()
        monitor.check_gate_io_announcements()
        return
    
    # 启动监控系统
    monitor.start()

if __name__ == "__main__":
    main()
