"""
Gate.io加密货币异动监控系统 - 合约信息获取模块
获取币种的合约交易相关信息，包括资金费率、未平仓合约和多空比
支持无API配置模式，自动降级为模拟数据
"""

import logging
import requests
import time
import random
from typing import Dict, Any, Optional, List

# 配置日志
logger = logging.getLogger("contract_info_fetcher")

class ContractInfoFetcher:
    """合约信息获取器，用于获取币种的合约交易相关信息"""
    
    def __init__(self, base_url: str = "https://api.gateio.ws/api/v4", api_key: str = "", api_secret: str = ""):
        """
        初始化合约信息获取器
        
        Args:
            base_url: Gate.io API基础URL
            api_key: Gate.io API密钥
            api_secret: Gate.io API密钥
        """
        self.base_url = base_url
        self.api_key = api_key
        self.api_secret = api_secret
        self.use_mock_data = not (api_key and api_secret)
        
        if self.use_mock_data:
            logger.warning("未配置Gate.io API，合约信息获取模块将使用模拟数据")
        else:
            logger.info("合约信息获取模块初始化完成")
    
    def get_contract_info(self, symbol: str) -> Dict[str, Any]:
        """
        获取币种的合约信息
        
        Args:
            symbol: 币种符号，如 BTC_USDT
            
        Returns:
            合约信息字典，包含资金费率、未平仓合约和多空比等
        """
        logger.info(f"获取 {symbol} 的合约信息")
        
        # 初始化结果
        result = {
            "symbol": symbol,
            "funding_rate": None,
            "open_interest": None,
            "long_short_ratio": None,
            "mark_price": None,
            "index_price": None,
            "last_price": None
        }
        
        try:
            if self.use_mock_data:
                return self._generate_mock_contract_info(symbol)
                
            # 转换符号格式（如 BTC_USDT -> BTC_USDT）
            contract_symbol = symbol
            
            # 获取合约基本信息
            contract_info = self._get_contract_detail(contract_symbol)
            if contract_info:
                result["mark_price"] = float(contract_info.get("mark_price", 0))
                result["index_price"] = float(contract_info.get("index_price", 0))
                result["last_price"] = float(contract_info.get("last_price", 0))
                result["funding_rate"] = float(contract_info.get("funding_rate", 0)) * 100  # 转换为百分比
            
            # 获取未平仓合约
            open_interest = self._get_open_interest(contract_symbol)
            if open_interest:
                result["open_interest"] = float(open_interest.get("total", 0))
                result["long_short_ratio"] = float(open_interest.get("long_short_ratio", 1))
            
            logger.info(f"成功获取 {symbol} 的合约信息")
            return result
        except Exception as e:
            logger.error(f"获取 {symbol} 的合约信息失败: {str(e)}")
            return result
    
    def _generate_mock_contract_info(self, symbol: str) -> Dict[str, Any]:
        """
        生成模拟的合约信息
        
        Args:
            symbol: 币种符号
            
        Returns:
            模拟的合约信息字典
        """
        # 根据币种生成不同范围的模拟数据
        if symbol.startswith("BTC"):
            last_price = random.uniform(25000, 35000)
        elif symbol.startswith("ETH"):
            last_price = random.uniform(1500, 2500)
        elif symbol.startswith("SHIB") or symbol.startswith("DOGE"):
            last_price = random.uniform(0.00001, 0.1)
        else:
            last_price = random.uniform(0.1, 100)
        
        # 生成略微不同的标记价格和指数价格
        mark_price = last_price * random.uniform(0.995, 1.005)
        index_price = last_price * random.uniform(0.995, 1.005)
        
        # 生成资金费率（通常在-0.1%到0.1%之间）
        funding_rate = random.uniform(-0.1, 0.1)
        
        # 生成未平仓合约数量
        if symbol.startswith("BTC"):
            open_interest = random.uniform(10000, 50000)
        elif symbol.startswith("ETH"):
            open_interest = random.uniform(50000, 200000)
        else:
            open_interest = random.uniform(100000, 1000000)
        
        # 生成多空比（通常在0.5到2之间）
        long_short_ratio = random.uniform(0.5, 2.0)
        
        result = {
            "symbol": symbol,
            "funding_rate": funding_rate,
            "open_interest": open_interest,
            "long_short_ratio": long_short_ratio,
            "mark_price": mark_price,
            "index_price": index_price,
            "last_price": last_price
        }
        
        logger.info(f"生成 {symbol} 的模拟合约信息")
        return result
    
    def _get_contract_detail(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取合约详情
        
        Args:
            symbol: 合约符号
            
        Returns:
            合约详情字典
        """
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取合约详情失败: {str(e)}")
            return None
    
    def _get_open_interest(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        获取未平仓合约信息
        
        Args:
            symbol: 合约符号
            
        Returns:
            未平仓合约信息字典
        """
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}/open_interest"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取未平仓合约信息失败: {str(e)}")
            return None
    
    def get_funding_history(self, symbol: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        获取资金费率历史
        
        Args:
            symbol: 合约符号
            limit: 返回记录数量限制
            
        Returns:
            资金费率历史列表
        """
        if self.use_mock_data:
            return self._generate_mock_funding_history(symbol, limit)
            
        try:
            url = f"{self.base_url}/futures/usdt/funding_rate"
            params = {
                "contract": symbol,
                "limit": limit
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取资金费率历史失败: {str(e)}")
            return []
    
    def _generate_mock_funding_history(self, symbol: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        生成模拟的资金费率历史
        
        Args:
            symbol: 合约符号
            limit: 返回记录数量限制
            
        Returns:
            模拟的资金费率历史列表
        """
        history = []
        current_time = int(time.time())
        
        # 每8小时一次资金费率
        interval = 8 * 3600
        
        for i in range(limit):
            # 生成-0.1%到0.1%之间的随机资金费率
            rate = random.uniform(-0.001, 0.001)
            
            # 时间戳递减
            timestamp = current_time - (i * interval)
            
            history.append({
                "t": timestamp,
                "r": str(rate),
                "contract": symbol
            })
        
        logger.info(f"生成 {symbol} 的模拟资金费率历史，共 {limit} 条记录")
        return history
    
    def get_contract_stats(self, symbol: str) -> Dict[str, Any]:
        """
        获取合约统计信息
        
        Args:
            symbol: 合约符号
            
        Returns:
            合约统计信息字典
        """
        if self.use_mock_data:
            return self._generate_mock_contract_stats(symbol)
            
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}/stats"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取合约统计信息失败: {str(e)}")
            return {}
    
    def _generate_mock_contract_stats(self, symbol: str) -> Dict[str, Any]:
        """
        生成模拟的合约统计信息
        
        Args:
            symbol: 合约符号
            
        Returns:
            模拟的合约统计信息字典
        """
        # 24小时交易量
        if symbol.startswith("BTC"):
            volume_24h = random.uniform(500000000, 2000000000)
        elif symbol.startswith("ETH"):
            volume_24h = random.uniform(200000000, 1000000000)
        else:
            volume_24h = random.uniform(10000000, 500000000)
        
        # 24小时交易笔数
        trades_24h = int(volume_24h / 10000)
        
        stats = {
            "volume_24h": str(volume_24h),
            "volume_24h_usd": str(volume_24h),
            "volume_24h_btc": str(volume_24h / 30000),
            "trades_24h": trades_24h,
            "long_short_ratio": random.uniform(0.5, 2.0)
        }
        
        logger.info(f"生成 {symbol} 的模拟合约统计信息")
        return stats
    
    def get_top_long_short_accounts(self, symbol: str) -> Dict[str, Any]:
        """
        获取大户多空比例
        
        Args:
            symbol: 合约符号
            
        Returns:
            大户多空比例信息字典
        """
        if self.use_mock_data:
            return self._generate_mock_top_long_short_accounts(symbol)
            
        try:
            url = f"{self.base_url}/futures/usdt/contracts/{symbol}/top_long_short_account_ratio"
            params = {
                "period": 5  # 5分钟
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"获取大户多空比例失败: {str(e)}")
            return {}
    
    def _generate_mock_top_long_short_accounts(self, symbol: str) -> Dict[str, Any]:
        """
        生成模拟的大户多空比例
        
        Args:
            symbol: 合约符号
            
        Returns:
            模拟的大户多空比例信息字典
        """
        # 生成随机的多空比例
        long_ratio = random.uniform(0.3, 0.7)
        short_ratio = 1 - long_ratio
        
        result = {
            "long_account_ratio": str(long_ratio),
            "short_account_ratio": str(short_ratio),
            "long_short_account_ratio": str(long_ratio / short_ratio),
            "timestamp": int(time.time())
        }
        
        logger.info(f"生成 {symbol} 的模拟大户多空比例")
        return result

# 创建全局实例
contract_info_fetcher = ContractInfoFetcher()

if __name__ == "__main__":
    # 测试代码
    logging.basicConfig(level=logging.INFO)
    
    # 测试获取合约信息
    symbol = "BTC_USDT"
    contract_info = contract_info_fetcher.get_contract_info(symbol)
    print(f"{symbol} 合约信息:")
    print(f"资金费率: {contract_info.get('funding_rate')}%")
    print(f"未平仓合约: {contract_info.get('open_interest')}")
    print(f"多空比: {contract_info.get('long_short_ratio')}")
    
    # 测试获取资金费率历史
    funding_history = contract_info_fetcher.get_funding_history(symbol, 5)
    print(f"\n{symbol} 资金费率历史:")
    for item in funding_history:
        print(f"时间: {item.get('t')}, 费率: {float(item.get('r', 0)) * 100:.6f}%")
