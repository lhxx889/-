"""
Gate.io加密货币异动监控系统 - 数据采集模块
负责从Gate.io API获取实时价格和交易量数据，并进行缓存和管理
支持无API配置模式，自动降级为模拟数据
"""

import requests
import time
import json
import sqlite3
import logging
import random
from datetime import datetime, timedelta
import os
from typing import Dict, List, Any, Optional, Tuple

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("data_collector")

class GateioDataCollector:
    """Gate.io数据采集类，负责从API获取数据并管理本地缓存"""
    
    # Gate.io API基础URL
    BASE_URL = "https://api.gateio.ws/api/v4"
    
    # API端点
    ENDPOINTS = {
        "tickers": "/spot/tickers",
        "currency_pairs": "/spot/currency_pairs",
        "ticker": "/spot/tickers/{currency_pair}"
    }
    
    # 模拟数据模式下的默认币种列表
    DEFAULT_SYMBOLS = [
        "BTC_USDT", "ETH_USDT", "XRP_USDT", "LTC_USDT", "BCH_USDT", 
        "EOS_USDT", "TRX_USDT", "BSV_USDT", "ADA_USDT", "DOT_USDT",
        "LINK_USDT", "BNB_USDT", "DOGE_USDT", "UNI_USDT", "SOL_USDT",
        "MATIC_USDT", "AVAX_USDT", "SHIB_USDT", "ATOM_USDT", "XLM_USDT"
    ]
    
    def __init__(self, db_path: str = "crypto_data.db", cache_duration: int = 3600, api_key: str = "", api_secret: str = ""):
        """
        初始化数据采集器
        
        Args:
            db_path: SQLite数据库路径
            cache_duration: 缓存有效期（秒）
            api_key: Gate.io API密钥
            api_secret: Gate.io API密钥
        """
        self.db_path = db_path
        self.cache_duration = cache_duration
        self.memory_cache = {}
        self.last_update_time = {}
        self.api_key = api_key
        self.api_secret = api_secret
        self.use_mock_data = not (api_key and api_secret)
        
        # 初始化数据库
        self._init_database()
        
        if self.use_mock_data:
            logger.warning("未配置Gate.io API，将使用模拟数据模式")
        else:
            logger.info("数据采集模块初始化完成，使用真实API数据")
    
    def _init_database(self) -> None:
        """初始化SQLite数据库，创建必要的表"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 创建币种信息表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS coins (
                id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                name TEXT,
                last_updated TIMESTAMP
            )
            ''')
            
            # 创建价格历史表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                volume_24h REAL,
                change_percentage_24h REAL,
                timestamp TIMESTAMP NOT NULL,
                FOREIGN KEY (symbol) REFERENCES coins(symbol)
            )
            ''')
            
            # 创建异常检测记录表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS anomaly_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                old_price REAL NOT NULL,
                change_percentage REAL NOT NULL,
                volume_24h REAL,
                volume_change_percentage REAL,
                detected_at TIMESTAMP NOT NULL,
                is_notified BOOLEAN DEFAULT 0,
                FOREIGN KEY (symbol) REFERENCES coins(symbol)
            )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("数据库初始化成功")
        except Exception as e:
            logger.error(f"数据库初始化失败: {str(e)}")
            raise
    
    def _make_request(self, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """
        发送API请求并处理可能的异常
        
        Args:
            endpoint: API端点
            params: 请求参数
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        # 如果使用模拟数据模式，则不发送实际请求
        if self.use_mock_data:
            logger.debug("使用模拟数据模式，跳过API请求")
            return None
            
        url = f"{self.BASE_URL}{endpoint}"
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
    
    def _generate_mock_currency_pairs(self) -> List[Dict]:
        """
        生成模拟的币种对数据
        
        Returns:
            模拟的币种对列表
        """
        pairs = []
        for symbol in self.DEFAULT_SYMBOLS:
            base, quote = symbol.split('_')
            pairs.append({
                "id": symbol,
                "base": base,
                "quote": quote,
                "fee": "0.2",
                "min_base_amount": "0.0001",
                "min_quote_amount": "1",
                "amount_precision": 4,
                "precision": 8,
                "trade_status": "tradable"
            })
        return pairs
    
    def _generate_mock_tickers(self) -> List[Dict]:
        """
        生成模拟的ticker数据
        
        Returns:
            模拟的ticker数据列表
        """
        tickers = []
        
        # 获取上次的价格数据作为基准
        last_prices = {}
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT ph.symbol, ph.price
                FROM price_history ph
                JOIN (
                    SELECT symbol, MAX(timestamp) as max_time
                    FROM price_history
                    GROUP BY symbol
                ) latest
                ON ph.symbol = latest.symbol AND ph.timestamp = latest.max_time
                """
            )
            for row in cursor.fetchall():
                last_prices[row[0]] = row[1]
            conn.close()
        except Exception as e:
            logger.warning(f"获取上次价格数据失败: {str(e)}")
        
        # 为每个默认币种生成模拟数据
        for symbol in self.DEFAULT_SYMBOLS:
            # 如果有历史价格，则基于历史价格生成波动；否则使用默认价格范围
            if symbol in last_prices:
                base_price = last_prices[symbol]
                # 生成-5%到+5%的随机波动
                change = random.uniform(-0.05, 0.05)
                price = base_price * (1 + change)
                change_percentage = change * 100
            else:
                # 为不同币种设置不同的价格范围
                if symbol.startswith("BTC"):
                    price = random.uniform(25000, 35000)
                elif symbol.startswith("ETH"):
                    price = random.uniform(1500, 2500)
                elif symbol.startswith("SHIB") or symbol.startswith("DOGE"):
                    price = random.uniform(0.00001, 0.1)
                else:
                    price = random.uniform(0.1, 100)
                
                change_percentage = random.uniform(-10, 10)
            
            # 生成交易量数据
            volume = random.uniform(1000000, 100000000)
            
            # 随机生成一些异常数据（约5%的概率）
            if random.random() < 0.05:
                # 生成大幅波动
                if random.random() < 0.5:
                    # 价格大幅上涨
                    price = price * random.uniform(1.3, 1.5)
                    change_percentage = random.uniform(30, 50)
                else:
                    # 价格大幅下跌
                    price = price * random.uniform(0.5, 0.7)
                    change_percentage = random.uniform(-50, -30)
                
                # 交易量大幅增加
                volume = volume * random.uniform(3, 10)
            
            tickers.append({
                "currency_pair": symbol,
                "last": str(price),
                "lowest_ask": str(price * 1.001),
                "highest_bid": str(price * 0.999),
                "change_percentage": str(change_percentage),
                "base_volume": str(volume),
                "quote_volume": str(volume * price),
                "high_24h": str(price * 1.1),
                "low_24h": str(price * 0.9)
            })
        
        return tickers
    
    def fetch_all_currency_pairs(self) -> List[Dict]:
        """
        获取所有可交易的币种对
        
        Returns:
            币种对列表
        """
        logger.info("获取所有可交易币种对")
        
        if self.use_mock_data:
            mock_data = self._generate_mock_currency_pairs()
            logger.info(f"使用模拟数据，生成了{len(mock_data)}个币种对信息")
            return mock_data
        
        data = self._make_request(self.ENDPOINTS["currency_pairs"])
        if data:
            logger.info(f"成功获取{len(data)}个币种对信息")
            return data
        return []
    
    def fetch_all_tickers(self) -> List[Dict]:
        """
        获取所有币种的ticker数据
        
        Returns:
            所有币种的ticker数据列表
        """
        logger.info("获取所有币种ticker数据")
        
        if self.use_mock_data:
            mock_data = self._generate_mock_tickers()
            logger.info(f"使用模拟数据，生成了{len(mock_data)}个币种的ticker数据")
            return mock_data
        
        data = self._make_request(self.ENDPOINTS["tickers"])
        if data:
            logger.info(f"成功获取{len(data)}个币种的ticker数据")
            return data
        return []
    
    def fetch_ticker(self, currency_pair: str) -> Optional[Dict]:
        """
        获取特定币种对的ticker数据
        
        Args:
            currency_pair: 币种对名称，如"BTC_USDT"
            
        Returns:
            币种的ticker数据或None（如果请求失败）
        """
        if self.use_mock_data:
            # 从模拟的所有ticker数据中筛选出特定币种
            all_tickers = self._generate_mock_tickers()
            for ticker in all_tickers:
                if ticker.get("currency_pair") == currency_pair:
                    return ticker
            return None
        
        endpoint = self.ENDPOINTS["ticker"].format(currency_pair=currency_pair)
        return self._make_request(endpoint)
    
    def save_ticker_data(self, tickers: List[Dict]) -> None:
        """
        将ticker数据保存到数据库
        
        Args:
            tickers: ticker数据列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            current_time = datetime.now().isoformat()
            
            for ticker in tickers:
                symbol = ticker.get("currency_pair")
                if not symbol:
                    continue
                
                # 更新或插入币种信息
                cursor.execute(
                    "INSERT OR REPLACE INTO coins (id, symbol, last_updated) VALUES (?, ?, ?)",
                    (symbol, symbol, current_time)
                )
                
                # 插入价格历史
                try:
                    price = float(ticker.get("last", 0))
                    volume_24h = float(ticker.get("base_volume", 0))
                    change_percentage_24h = float(ticker.get("change_percentage", 0))
                    
                    cursor.execute(
                        """
                        INSERT INTO price_history 
                        (symbol, price, volume_24h, change_percentage_24h, timestamp) 
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (symbol, price, volume_24h, change_percentage_24h, current_time)
                    )
                except (ValueError, TypeError) as e:
                    logger.warning(f"处理币种{symbol}数据时出错: {str(e)}")
                    continue
            
            conn.commit()
            conn.close()
            logger.info(f"成功保存{len(tickers)}个币种的ticker数据到数据库")
        except Exception as e:
            logger.error(f"保存ticker数据到数据库失败: {str(e)}")
    
    def get_latest_price_data(self, symbol: str = None) -> Dict:
        """
        获取最新价格数据
        
        Args:
            symbol: 币种符号，如果为None则返回所有币种数据
            
        Returns:
            最新价格数据字典
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if symbol:
                cursor.execute(
                    """
                    SELECT ph.symbol, ph.price, ph.volume_24h, ph.change_percentage_24h, ph.timestamp
                    FROM price_history ph
                    JOIN (
                        SELECT symbol, MAX(timestamp) as max_time
                        FROM price_history
                        WHERE symbol = ?
                        GROUP BY symbol
                    ) latest
                    ON ph.symbol = latest.symbol AND ph.timestamp = latest.max_time
                    """,
                    (symbol,)
                )
            else:
                cursor.execute(
                    """
                    SELECT ph.symbol, ph.price, ph.volume_24h, ph.change_percentage_24h, ph.timestamp
                    FROM price_history ph
                    JOIN (
                        SELECT symbol, MAX(timestamp) as max_time
                        FROM price_history
                        GROUP BY symbol
                    ) latest
                    ON ph.symbol = latest.symbol AND ph.timestamp = latest.max_time
                    """
                )
            
            results = cursor.fetchall()
            conn.close()
            
            data = {}
            for row in results:
                data[row[0]] = {
                    "price": row[1],
                    "volume_24h": row[2],
                    "change_percentage_24h": row[3],
                    "timestamp": row[4]
                }
            
            return data
        except Exception as e:
            logger.error(f"获取最新价格数据失败: {str(e)}")
            return {}
    
    def get_historical_price_data(self, symbol: str, hours: int = 24) -> List[Dict]:
        """
        获取历史价格数据
        
        Args:
            symbol: 币种符号
            hours: 获取过去多少小时的数据
            
        Returns:
            历史价格数据列表
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute(
                """
                SELECT symbol, price, volume_24h, change_percentage_24h, timestamp
                FROM price_history
                WHERE symbol = ? AND timestamp >= datetime('now', '-' || ? || ' hours')
                ORDER BY timestamp ASC
                """,
                (symbol, hours)
            )
            
            results = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in results]
        except Exception as e:
            logger.error(f"获取历史价格数据失败: {str(e)}")
            return []
    
    def update_data(self) -> bool:
        """
        更新所有币种的数据
        
        Returns:
            更新是否成功
        """
        try:
            tickers = self.fetch_all_tickers()
            if tickers:
                self.save_ticker_data(tickers)
                self.memory_cache["tickers"] = tickers
                self.last_update_time["tickers"] = time.time()
                return True
            return False
        except Exception as e:
            logger.error(f"更新数据失败: {str(e)}")
            return False
    
    def get_cached_tickers(self) -> List[Dict]:
        """
        获取缓存的ticker数据，如果缓存过期则重新获取
        
        Returns:
            ticker数据列表
        """
        current_time = time.time()
        if (
            "tickers" not in self.memory_cache or
            "tickers" not in self.last_update_time or
            current_time - self.last_update_time["tickers"] > self.cache_duration
        ):
            logger.info("缓存过期，重新获取ticker数据")
            tickers = self.fetch_all_tickers()
            if tickers:
                self.memory_cache["tickers"] = tickers
                self.last_update_time["tickers"] = current_time
        
        return self.memory_cache.get("tickers", [])
    
    def clean_old_data(self, days: int = 7) -> None:
        """
        清理旧数据以节省空间
        
        Args:
            days: 保留最近多少天的数据
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(
                "DELETE FROM price_history WHERE timestamp < datetime('now', '-' || ? || ' days')",
                (days,)
            )
            
            deleted_rows = cursor.rowcount
            conn.commit()
            conn.close()
            
            logger.info(f"已清理{deleted_rows}条{days}天前的旧数据")
        except Exception as e:
            logger.error(f"清理旧数据失败: {str(e)}")


class DataCollector:
    """数据收集器，兼容旧版接口，内部使用GateioDataCollector"""
    
    def __init__(self, api_key: str = "", api_secret: str = "", base_url: str = "https://api.gateio.ws/api/v4"):
        """
        初始化数据收集器
        
        Args:
            api_key: Gate.io API密钥
            api_secret: Gate.io API密钥
            base_url: Gate.io API基础URL
        """
        self.collector = GateioDataCollector(api_key=api_key, api_secret=api_secret)
        self.use_mock_data = self.collector.use_mock_data
        
        if self.use_mock_data:
            logger.warning("未配置Gate.io API，数据收集器将使用模拟数据")
        else:
            logger.info("数据收集器初始化完成")
    
    def get_all_tickers(self) -> List[Dict]:
        """
        获取所有币种的ticker数据
        
        Returns:
            所有币种的ticker数据列表
        """
        return self.collector.fetch_all_tickers()
    
    def get_ticker(self, symbol: str) -> Optional[Dict]:
        """
        获取特定币种的ticker数据
        
        Args:
            symbol: 币种符号
            
        Returns:
            币种的ticker数据或None（如果请求失败）
        """
        return self.collector.fetch_ticker(symbol)
    
    def get_historical_data(self, symbol: str, hours: int = 24) -> List[Dict]:
        """
        获取历史价格数据
        
        Args:
            symbol: 币种符号
            hours: 获取过去多少小时的数据
            
        Returns:
            历史价格数据列表
        """
        return self.collector.get_historical_price_data(symbol, hours)


class DataMonitor:
    """数据监控类，负责定期获取数据并触发检测"""
    
    def __init__(self, collector: GateioDataCollector, interval: int = 50):
        """
        初始化监控器
        
        Args:
            collector: 数据采集器实例
            interval: 检查间隔（秒）
        """
        self.collector = collector
        self.interval = interval
        self.running = False
        self.last_clean_time = time.time()
        self.clean_interval = 86400  # 24小时清理一次旧数据
        
        logger.info(f"数据监控器初始化完成，检查间隔: {interval}秒")
    
    def start(self) -> None:
        """启动监控"""
        self.running = True
        logger.info("数据监控启动")
        
        try:
            while self.running:
                logger.info(f"执行数据更新，当前时间: {datetime.now().isoformat()}")
                
                # 更新数据
                success = self.collector.update_data()
                if success:
                    logger.info("数据更新成功")
                else:
                    logger.warning("数据更新失败")
                
                # 定期清理旧数据
                current_time = time.time()
                if current_time - self.last_clean_time > self.clean_interval:
                    logger.info("执行旧数据清理")
                    self.collector.clean_old_data()
                    self.last_clean_time = current_time
                
                # 等待下一次检查
                logger.info(f"等待{self.interval}秒后进行下一次检查")
                time.sleep(self.interval)
        except KeyboardInterrupt:
            logger.info("收到中断信号，停止监控")
            self.stop()
        except Exception as e:
            logger.error(f"监控过程中发生错误: {str(e)}")
            self.stop()
    
    def stop(self) -> None:
        """停止监控"""
        self.running = False
        logger.info("数据监控已停止")


if __name__ == "__main__":
    # 测试代码
    collector = GateioDataCollector()
    monitor = DataMonitor(collector)
    
    # 获取并打印一些数据
    print("获取所有币种对...")
    pairs = collector.fetch_all_currency_pairs()
    print(f"共获取到 {len(pairs)} 个币种对")
    if pairs:
        print("前5个币种对:")
        for pair in pairs[:5]:
            print(f"  - {pair.get('id')}: {pair.get('base')}/{pair.get('quote')}")
    
    print("\n获取所有ticker数据...")
    tickers = collector.fetch_all_tickers()
    print(f"共获取到 {len(tickers)} 个ticker数据")
    if tickers:
        print("前5个ticker数据:")
        for ticker in tickers[:5]:
            print(f"  - {ticker.get('currency_pair')}: 最新价格 {ticker.get('last')}, 24h成交量 {ticker.get('base_volume')}")
    
    print("\n保存数据到数据库...")
    collector.save_ticker_data(tickers)
    
    print("\n获取最新价格数据...")
    latest_data = collector.get_latest_price_data()
    print(f"共获取到 {len(latest_data)} 个币种的最新价格数据")
    
    print("\n测试完成，可以通过以下命令启动监控:")
    print("  monitor = DataMonitor(collector)")
    print("  monitor.start()")
