"""
Gate.io加密货币异动监控系统 - 增强版币种信息查询模块
负责查询和整合币种的详细信息，包括简介、社交媒体等
"""

import logging
import time
import json
import requests
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import os
import re

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("enhanced_coin_info")

class EnhancedCoinInfo:
    """增强版币种信息查询类，负责获取币种的详细信息"""
    
    # CoinGecko API
    COINGECKO_SEARCH_URL = "https://api.coingecko.com/api/v3/search"
    COINGECKO_COIN_URL = "https://api.coingecko.com/api/v3/coins/{id}"
    
    # CoinMarketCap API
    CMC_API_URL = "https://pro-api.coinmarketcap.com/v1"
    
    def __init__(self, config_file: str = "api_config.json", cache_duration: int = 3600):
        """
        初始化增强版币种信息查询器
        
        Args:
            config_file: 配置文件路径
            cache_duration: 缓存有效期（秒）
        """
        self.config_file = config_file
        self.cache_duration = cache_duration
        self.cmc_api_key = None
        self.cache = {}
        self.cache_expiry = {}
        
        # 尝试从配置文件加载API密钥
        self._load_config()
        
        logger.info("增强版币种信息查询模块初始化完成")
    
    def _load_config(self) -> None:
        """从配置文件加载API配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.cmc_api_key = config.get("cmc_api_key")
                    logger.info("从配置文件加载API配置成功")
            else:
                logger.warning(f"配置文件{self.config_file}不存在")
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
    
    def save_config(self, cmc_api_key: str = None) -> bool:
        """
        保存API配置到配置文件
        
        Args:
            cmc_api_key: CoinMarketCap API密钥
            
        Returns:
            保存是否成功
        """
        try:
            # 读取现有配置（如果存在）
            config = {}
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            
            # 更新配置
            if cmc_api_key:
                self.cmc_api_key = cmc_api_key
                config["cmc_api_key"] = cmc_api_key
            
            # 保存配置
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info("保存API配置到配置文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def _make_request(self, url: str, params: Dict = None, headers: Dict = None) -> Optional[Dict]:
        """
        发送API请求并处理可能的异常
        
        Args:
            url: API URL
            params: 请求参数
            headers: 请求头
            
        Returns:
            API响应数据或None（如果请求失败）
        """
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, headers=headers, timeout=10)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API请求失败 (尝试 {attempt+1}/{max_retries}): {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # 指数退避
                else:
                    logger.error(f"API请求最终失败: {str(e)}")
                    return None
    
    def get_coin_id_from_coingecko(self, symbol: str) -> Optional[str]:
        """
        从CoinGecko获取币种ID
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种ID或None（如果未找到）
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"coingecko_id_{coin_name}"
        if cache_key in self.cache:
            logger.info(f"从缓存获取{coin_name}的CoinGecko ID")
            return self.cache[cache_key]
        
        logger.info(f"从CoinGecko获取{coin_name}的ID")
        
        params = {"query": coin_name}
        data = self._make_request(self.COINGECKO_SEARCH_URL, params)
        
        if data and "coins" in data:
            coins = data["coins"]
            if coins:
                # 尝试找到最匹配的币种
                for coin in coins:
                    if (
                        coin["symbol"].lower() == coin_name.lower() or
                        coin["name"].lower() == coin_name.lower()
                    ):
                        coin_id = coin["id"]
                        logger.info(f"成功获取{coin_name}的CoinGecko ID: {coin_id}")
                        
                        # 更新缓存
                        self.cache[cache_key] = coin_id
                        
                        return coin_id
                
                # 如果没有找到完全匹配的，使用第一个结果
                coin_id = coins[0]["id"]
                logger.info(f"未找到完全匹配的{coin_name}，使用第一个结果: {coin_id}")
                
                # 更新缓存
                self.cache[cache_key] = coin_id
                
                return coin_id
        
        logger.warning(f"未找到{coin_name}的CoinGecko ID")
        
        # 更新缓存（避免重复请求）
        self.cache[cache_key] = None
        
        return None
    
    def get_coin_info_from_coingecko(self, symbol: str) -> Optional[Dict]:
        """
        从CoinGecko获取币种信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种信息或None（如果未找到）
        """
        # 检查缓存
        cache_key = f"coingecko_info_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{symbol}的CoinGecko信息")
            return self.cache[cache_key]
        
        logger.info(f"从CoinGecko获取{symbol}的信息")
        
        # 获取币种ID
        coin_id = self.get_coin_id_from_coingecko(symbol)
        if not coin_id:
            return None
        
        # 获取币种信息
        url = self.COINGECKO_COIN_URL.format(id=coin_id)
        data = self._make_request(url)
        
        if data:
            logger.info(f"成功获取{symbol}的CoinGecko信息")
            
            # 更新缓存
            self.cache[cache_key] = data
            self.cache_expiry[cache_key] = time.time()
            
            return data
        
        logger.warning(f"获取{symbol}的CoinGecko信息失败")
        return None
    
    def get_coin_info_from_cmc(self, symbol: str) -> Optional[Dict]:
        """
        从CoinMarketCap获取币种信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            币种信息或None（如果未找到或API密钥未配置）
        """
        if not self.cmc_api_key:
            logger.warning("CoinMarketCap API密钥未配置，无法获取信息")
            return None
        
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"cmc_info_{coin_name}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{coin_name}的CoinMarketCap信息")
            return self.cache[cache_key]
        
        logger.info(f"从CoinMarketCap获取{coin_name}的信息")
        
        # 构建请求
        url = f"{self.CMC_API_URL}/cryptocurrency/info"
        headers = {
            "X-CMC_PRO_API_KEY": self.cmc_api_key,
            "Accept": "application/json"
        }
        params = {"symbol": coin_name}
        
        data = self._make_request(url, params, headers)
        
        if data and data.get("status", {}).get("error_code") == 0:
            coin_data = data.get("data", {}).get(coin_name.upper())
            if coin_data:
                logger.info(f"成功获取{coin_name}的CoinMarketCap信息")
                
                # 更新缓存
                self.cache[cache_key] = coin_data
                self.cache_expiry[cache_key] = time.time()
                
                return coin_data
        
        logger.warning(f"获取{coin_name}的CoinMarketCap信息失败")
        return None
    
    def extract_social_media_links(self, coin_info: Dict) -> Dict:
        """
        从币种信息中提取社交媒体链接
        
        Args:
            coin_info: 币种信息
            
        Returns:
            社交媒体链接字典
        """
        social_links = {}
        
        # 从CoinGecko信息中提取
        if "links" in coin_info:
            links = coin_info["links"]
            
            # 提取Twitter
            if "twitter_screen_name" in links and links["twitter_screen_name"]:
                social_links["twitter"] = f"https://twitter.com/{links['twitter_screen_name']}"
            
            # 提取Telegram
            if "telegram_channel_identifier" in links and links["telegram_channel_identifier"]:
                social_links["telegram"] = f"https://t.me/{links['telegram_channel_identifier']}"
            
            # 提取Reddit
            if "subreddit_url" in links and links["subreddit_url"]:
                social_links["reddit"] = links["subreddit_url"]
            
            # 提取官网
            if "homepage" in links and links["homepage"] and links["homepage"][0]:
                social_links["website"] = links["homepage"][0]
            
            # 提取Github
            if "repos_url" in links and links["repos_url"].get("github") and links["repos_url"]["github"]:
                social_links["github"] = links["repos_url"]["github"][0]
        
        # 从CoinMarketCap信息中提取
        elif "urls" in coin_info:
            urls = coin_info["urls"]
            
            # 提取Twitter
            if "twitter" in urls and urls["twitter"] and urls["twitter"][0]:
                social_links["twitter"] = urls["twitter"][0]
            
            # 提取Telegram
            if "chat" in urls and urls["chat"]:
                for chat in urls["chat"]:
                    if "telegram" in chat.lower():
                        social_links["telegram"] = chat
                        break
            
            # 提取Reddit
            if "reddit" in urls and urls["reddit"] and urls["reddit"][0]:
                social_links["reddit"] = urls["reddit"][0]
            
            # 提取官网
            if "website" in urls and urls["website"] and urls["website"][0]:
                social_links["website"] = urls["website"][0]
            
            # 提取Github
            if "source_code" in urls and urls["source_code"] and urls["source_code"][0]:
                social_links["github"] = urls["source_code"][0]
        
        return social_links
    
    def get_coin_description(self, coin_info: Dict) -> str:
        """
        从币种信息中提取描述
        
        Args:
            coin_info: 币种信息
            
        Returns:
            币种描述
        """
        # 从CoinGecko信息中提取
        if "description" in coin_info and "zh" in coin_info["description"] and coin_info["description"]["zh"]:
            return coin_info["description"]["zh"]
        elif "description" in coin_info and "en" in coin_info["description"] and coin_info["description"]["en"]:
            return coin_info["description"]["en"]
        
        # 从CoinMarketCap信息中提取
        elif "description" in coin_info:
            return coin_info["description"]
        
        return "暂无描述"
    
    def get_coin_market_data(self, coin_info: Dict) -> Dict:
        """
        从币种信息中提取市场数据
        
        Args:
            coin_info: 币种信息
            
        Returns:
            市场数据字典
        """
        market_data = {}
        
        # 从CoinGecko信息中提取
        if "market_data" in coin_info:
            data = coin_info["market_data"]
            
            # 提取市值
            if "market_cap" in data and "usd" in data["market_cap"]:
                market_data["market_cap"] = data["market_cap"]["usd"]
            
            # 提取24小时交易量
            if "total_volume" in data and "usd" in data["total_volume"]:
                market_data["volume_24h"] = data["total_volume"]["usd"]
            
            # 提取流通量
            if "circulating_supply" in data:
                market_data["circulating_supply"] = data["circulating_supply"]
            
            # 提取总供应量
            if "total_supply" in data:
                market_data["total_supply"] = data["total_supply"]
            
            # 提取最大供应量
            if "max_supply" in data:
                market_data["max_supply"] = data["max_supply"]
        
        # 从CoinMarketCap信息中提取
        elif "quote" in coin_info and "USD" in coin_info["quote"]:
            data = coin_info["quote"]["USD"]
            
            # 提取市值
            if "market_cap" in data:
                market_data["market_cap"] = data["market_cap"]
            
            # 提取24小时交易量
            if "volume_24h" in data:
                market_data["volume_24h"] = data["volume_24h"]
            
            # 提取流通量
            if "circulating_supply" in coin_info:
                market_data["circulating_supply"] = coin_info["circulating_supply"]
            
            # 提取总供应量
            if "total_supply" in coin_info:
                market_data["total_supply"] = coin_info["total_supply"]
            
            # 提取最大供应量
            if "max_supply" in coin_info:
                market_data["max_supply"] = coin_info["max_supply"]
        
        return market_data
    
    def get_comprehensive_coin_info(self, symbol: str) -> Dict:
        """
        获取综合币种信息
        
        Args:
            symbol: 币种符号，如"BTC_USDT"
            
        Returns:
            综合币种信息字典
        """
        # 提取币种名称（去除交易对后缀）
        coin_name = symbol.split('_')[0]
        
        # 检查缓存
        cache_key = f"comprehensive_info_{symbol}"
        if cache_key in self.cache and time.time() - self.cache_expiry.get(cache_key, 0) < self.cache_duration:
            logger.info(f"从缓存获取{symbol}的综合信息")
            return self.cache[cache_key]
        
        logger.info(f"获取{symbol}的综合信息")
        
        # 初始化结果
        result = {
            "symbol": coin_name,
            "name": coin_name,
            "description": "暂无描述",
            "social_links": {},
            "market_data": {}
        }
        
        # 尝试从CoinGecko获取信息
        coingecko_info = self.get_coin_info_from_coingecko(symbol)
        if coingecko_info:
            # 更新基本信息
            result["name"] = coingecko_info.get("name", coin_name)
            
            # 更新描述
            result["description"] = self.get_coin_description(coingecko_info)
            
            # 更新社交媒体链接
            result["social_links"] = self.extract_social_media_links(coingecko_info)
            
            # 更新市场数据
            result["market_data"] = self.get_coin_market_data(coingecko_info)
            
            # 更新数据来源
            result["data_source"] = "CoinGecko"
        
        # 如果CoinGecko没有数据，尝试从CoinMarketCap获取
        elif self.cmc_api_key:
            cmc_info = self.get_coin_info_from_cmc(symbol)
            if cmc_info:
                # 更新基本信息
                result["name"] = cmc_info.get("name", coin_name)
                
                # 更新描述
                result["description"] = self.get_coin_description(cmc_info)
                
                # 更新社交媒体链接
                result["social_links"] = self.extract_social_media_links(cmc_info)
                
                # 更新市场数据
                result["market_data"] = self.get_coin_market_data(cmc_info)
                
                # 更新数据来源
                result["data_source"] = "CoinMarketCap"
        
        # 更新缓存
        self.cache[cache_key] = result
        self.cache_expiry[cache_key] = time.time()
        
        return result
    
    def format_coin_info_message(self, coin_info: Dict) -> str:
        """
        格式化币种信息消息
        
        Args:
            coin_info: 币种信息
            
        Returns:
            格式化后的消息
        """
        # 提取信息
        symbol = coin_info.get("symbol", "")
        name = coin_info.get("name", symbol)
        description = coin_info.get("description", "暂无描述")
        social_links = coin_info.get("social_links", {})
        market_data = coin_info.get("market_data", {})
        data_source = coin_info.get("data_source", "未知")
        
        # 截断描述（避免消息过长）
        if len(description) > 300:
            description = description[:297] + "..."
        
        # 构建消息
        message_parts = [
            f"📊 {name} ({symbol}) 币种信息",
            ""
        ]
        
        # 添加市场数据
        message_parts.append("🔸 市场数据:")
        
        if "market_cap" in market_data:
            market_cap = market_data["market_cap"]
            if market_cap >= 1_000_000_000:
                market_cap_str = f"${market_cap / 1_000_000_000:.2f}B"
            elif market_cap >= 1_000_000:
                market_cap_str = f"${market_cap / 1_000_000:.2f}M"
            else:
                market_cap_str = f"${market_cap:.2f}"
            message_parts.append(f"市值: {market_cap_str}")
        
        if "volume_24h" in market_data:
            volume = market_data["volume_24h"]
            if volume >= 1_000_000_000:
                volume_str = f"${volume / 1_000_000_000:.2f}B"
            elif volume >= 1_000_000:
                volume_str = f"${volume / 1_000_000:.2f}M"
            else:
                volume_str = f"${volume:.2f}"
            message_parts.append(f"24小时交易量: {volume_str}")
        
        if "circulating_supply" in market_data:
            supply = market_data["circulating_supply"]
            if supply >= 1_000_000_000:
                supply_str = f"{supply / 1_000_000_000:.2f}B"
            elif supply >= 1_000_000:
                supply_str = f"{supply / 1_000_000:.2f}M"
            else:
                supply_str = f"{supply:.2f}"
            message_parts.append(f"流通量: {supply_str} {symbol}")
        
        # 添加描述
        message_parts.append("")
        message_parts.append("🔸 项目简介:")
        message_parts.append(description)
        
        # 添加社交媒体链接
        if social_links:
            message_parts.append("")
            message_parts.append("🔸 社交媒体:")
            
            if "website" in social_links:
                message_parts.append(f"官网: {social_links['website']}")
            
            if "twitter" in social_links:
                message_parts.append(f"Twitter: {social_links['twitter']}")
            
            if "telegram" in social_links:
                message_parts.append(f"Telegram: {social_links['telegram']}")
            
            if "reddit" in social_links:
                message_parts.append(f"Reddit: {social_links['reddit']}")
            
            if "github" in social_links:
                message_parts.append(f"GitHub: {social_links['github']}")
        
        # 添加数据来源
        message_parts.append("")
        message_parts.append(f"数据来源: {data_source}")
        
        # 合并消息
        return "\n".join(message_parts)


if __name__ == "__main__":
    # 测试代码
    
    # 创建增强版币种信息查询器
    coin_info = EnhancedCoinInfo()
    
    # 测试获取币种信息
    test_symbols = ["BTC_USDT", "ETH_USDT", "DOGE_USDT"]
    
    for symbol in test_symbols:
        print(f"\n获取{symbol}的综合信息...")
        info = coin_info.get_comprehensive_coin_info(symbol)
        
        print(f"币种名称: {info['name']}")
        print(f"社交媒体链接: {info['social_links']}")
        print(f"市场数据: {info['market_data']}")
        
        # 测试格式化消息
        print("\n格式化后的消息:")
        formatted_message = coin_info.format_coin_info_message(info)
        print(formatted_message)
    
    print("\n测试完成!")
