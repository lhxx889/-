"""
空文件，用于标记crypto_monitor目录为Python包
"""
