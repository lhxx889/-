"""
Gate.io加密货币异动监控系统 - 快捷设置模块
提供API、Telegram和涨跌幅阈值的快捷设置功能
"""

import os
import json
import logging
import sys
from typing import Dict, Any, List, Optional, Tuple
import getpass

# 配置日志
logger = logging.getLogger("quick_settings")

class QuickSettings:
    """快捷设置类，提供各种配置的快捷设置功能"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化快捷设置
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # Telegram配置文件
        self.telegram_config_file = "telegram_config.json"
        self.telegram_accounts_file = "telegram_accounts.json"
        
        # API配置文件
        self.api_config_file = "api_config.json"
        
        logger.info("快捷设置模块初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        default_config = {
            "check_interval": 50,  # 检查间隔（秒）
            "price_threshold": 30.0,  # 价格异动阈值（百分比）
            "volume_threshold": 200.0,  # 交易量异动阈值（百分比）
            "api_key": "",  # Gate.io API Key
            "api_secret": "",  # Gate.io API Secret
            "excluded_symbols": [],  # 排除的币种符号
            "use_custom_format": True,  # 使用自定义推送格式
            "api_required": False,  # API是否必需
            "scan_new_listings": True  # 是否扫描新上币公告
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # 合并默认配置和加载的配置
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    
                    logger.info(f"从配置文件加载配置成功")
                    return config
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，使用默认配置")
                return default_config
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
            return default_config
    
    def save_config(self) -> bool:
        """
        保存配置到文件
        
        Returns:
            保存是否成功
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            
            logger.info(f"保存配置到文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置到文件失败: {str(e)}")
            return False
    
    def setup_api(self) -> bool:
        """
        设置Gate.io API
        
        Returns:
            设置是否成功
        """
        print("\n===== Gate.io API设置 =====")
        print("注意: API设置为可选，不设置API也可以使用基本功能")
        
        try:
            # 询问是否设置API
            setup_api = input("是否设置Gate.io API? (y/n): ")
            
            if setup_api.lower() == 'y':
                api_key = input("Gate.io API Key: ")
                api_secret = getpass.getpass("Gate.io API Secret: ")
                
                if api_key and api_secret:
                    # 更新主配置
                    self.config["api_key"] = api_key
                    self.config["api_secret"] = api_secret
                    
                    # 创建API配置文件
                    api_config = {
                        "gate_io": {
                            "api_key": api_key,
                            "api_secret": api_secret
                        }
                    }
                    
                    with open(self.api_config_file, 'w') as f:
                        json.dump(api_config, f, indent=4)
                    
                    print("Gate.io API设置成功！")
                    return True
                else:
                    print("API Key或Secret为空，设置取消")
            else:
                print("跳过API设置")
            
            return False
        except Exception as e:
            logger.error(f"设置API失败: {str(e)}")
            print(f"设置API失败: {str(e)}")
            return False
    
    def setup_telegram(self) -> bool:
        """
        设置Telegram
        
        Returns:
            设置是否成功
        """
        print("\n===== Telegram设置 =====")
        
        try:
            # 询问是否设置Telegram
            setup_telegram = input("是否设置Telegram? (y/n): ")
            
            if setup_telegram.lower() == 'y':
                # 检查是否支持多账号
                multi_account = os.path.exists("src/enhanced_multi_telegram_alerter.py")
                
                if multi_account:
                    print("\n支持多账号Telegram设置")
                    accounts = []
                    
                    while True:
                        print("\n1. 添加Telegram账号")
                        print("2. 完成设置")
                        
                        choice = input("请选择: ")
                        
                        if choice == "1":
                            name = input("账号名称: ")
                            token = input("Telegram Bot Token: ")
                            chat_id = input("Telegram Chat ID: ")
                            
                            if name and token and chat_id:
                                accounts.append({
                                    "name": name,
                                    "token": token,
                                    "chat_id": chat_id
                                })
                                
                                print(f"账号 '{name}' 添加成功")
                            else:
                                print("账号信息不完整，添加失败")
                        elif choice == "2":
                            break
                        else:
                            print("无效选择，请重试")
                    
                    if accounts:
                        # 保存多账号配置
                        with open(self.telegram_accounts_file, 'w') as f:
                            json.dump({"accounts": accounts}, f, indent=4)
                        
                        print(f"已保存 {len(accounts)} 个Telegram账号")
                        return True
                    else:
                        print("未添加任何账号，设置取消")
                else:
                    # 单账号设置
                    token = input("Telegram Bot Token: ")
                    chat_id = input("Telegram Chat ID: ")
                    
                    if token and chat_id:
                        # 保存单账号配置
                        with open(self.telegram_config_file, 'w') as f:
                            json.dump({"token": token, "chat_id": chat_id}, f, indent=4)
                        
                        print("Telegram设置成功！")
                        return True
                    else:
                        print("Token或Chat ID为空，设置取消")
            else:
                print("跳过Telegram设置")
            
            return False
        except Exception as e:
            logger.error(f"设置Telegram失败: {str(e)}")
            print(f"设置Telegram失败: {str(e)}")
            return False
    
    def setup_thresholds(self) -> bool:
        """
        设置异动阈值
        
        Returns:
            设置是否成功
        """
        print("\n===== 异动阈值设置 =====")
        
        try:
            # 显示当前阈值
            print(f"当前价格异动阈值: {self.config['price_threshold']}%")
            print(f"当前交易量异动阈值: {self.config['volume_threshold']}%")
            
            # 设置价格异动阈值
            price_threshold_str = input("价格异动阈值 (百分比，留空保持不变): ")
            if price_threshold_str:
                try:
                    price_threshold = float(price_threshold_str)
                    self.config["price_threshold"] = price_threshold
                    print(f"价格异动阈值已设置为: {price_threshold}%")
                except ValueError:
                    print("无效输入，价格异动阈值保持不变")
            
            # 设置交易量异动阈值
            volume_threshold_str = input("交易量异动阈值 (百分比，留空保持不变): ")
            if volume_threshold_str:
                try:
                    volume_threshold = float(volume_threshold_str)
                    self.config["volume_threshold"] = volume_threshold
                    print(f"交易量异动阈值已设置为: {volume_threshold}%")
                except ValueError:
                    print("无效输入，交易量异动阈值保持不变")
            
            # 保存配置
            success = self.save_config()
            
            if success:
                print("异动阈值设置成功！")
                return True
            else:
                print("保存配置失败，设置未生效")
                return False
        except Exception as e:
            logger.error(f"设置异动阈值失败: {str(e)}")
            print(f"设置异动阈值失败: {str(e)}")
            return False
    
    def setup_new_listings_scan(self) -> bool:
        """
        设置新上币公告扫描
        
        Returns:
            设置是否成功
        """
        print("\n===== 新上币公告扫描设置 =====")
        print("注意: 定时任务功能暂不可用，系统将提供手动触发扫描功能")
        
        try:
            # 询问是否启用新上币公告扫描
            enable_scan = input("是否启用新上币公告扫描? (y/n): ")
            
            if enable_scan.lower() == 'y':
                self.config["scan_new_listings"] = True
                print("新上币公告扫描已启用")
                
                print("\n由于定时任务功能暂不可用，您可以通过以下方式实现定期扫描：")
                print("1. 使用系统的手动扫描功能（运行 python scan_new_listings.py）")
                print("2. 使用外部定时工具（如crontab、Windows任务计划程序等）定期执行扫描脚本")
                print("3. 在监控系统运行期间，可以通过命令行参数触发一次性扫描")
                
                # 保存配置
                success = self.save_config()
                
                if success:
                    print("新上币公告扫描设置成功！")
                    return True
                else:
                    print("保存配置失败，设置未生效")
                    return False
            else:
                self.config["scan_new_listings"] = False
                self.save_config()
                print("新上币公告扫描已禁用")
                return True
        except Exception as e:
            logger.error(f"设置新上币公告扫描失败: {str(e)}")
            print(f"设置新上币公告扫描失败: {str(e)}")
            return False
    
    def run_quick_setup(self) -> bool:
        """
        运行快捷设置向导
        
        Returns:
            设置是否成功
        """
        print("\n===== Gate.io加密货币异动监控系统快捷设置 =====")
        
        try:
            while True:
                print("\n请选择要设置的项目：")
                print("1. Gate.io API设置")
                print("2. Telegram设置")
                print("3. 异动阈值设置")
                print("4. 新上币公告扫描设置")
                print("5. 保存并退出")
                print("0. 取消设置")
                
                choice = input("请选择: ")
                
                if choice == "1":
                    self.setup_api()
                elif choice == "2":
                    self.setup_telegram()
                elif choice == "3":
                    self.setup_thresholds()
                elif choice == "4":
                    self.setup_new_listings_scan()
                elif choice == "5":
                    # 保存配置
                    success = self.save_config()
                    
                    if success:
                        print("\n所有设置已保存！")
                        return True
                    else:
                        print("\n保存配置失败！")
                        return False
                elif choice == "0":
                    print("\n设置已取消")
                    return False
                else:
                    print("\n无效选择，请重试")
            
            return True
        except Exception as e:
            logger.error(f"快捷设置向导运行失败: {str(e)}")
            print(f"\n快捷设置向导运行失败: {str(e)}")
            return False


def main():
    """主函数"""
    # 配置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # 创建快捷设置实例
    settings = QuickSettings()
    
    # 运行快捷设置向导
    settings.run_quick_setup()


if __name__ == "__main__":
    main()
