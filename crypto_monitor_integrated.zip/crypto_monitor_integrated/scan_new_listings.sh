#!/bin/bash

# 新上币公告扫描启动脚本
# 用于手动触发新上币公告扫描

cd "$(dirname "$0")"

# 激活虚拟环境
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows
    source venv/Scripts/activate
else
    # Linux/Mac
    source venv/bin/activate
fi

# 运行扫描脚本
python src/new_listings_scanner.py

echo "扫描完成！"
