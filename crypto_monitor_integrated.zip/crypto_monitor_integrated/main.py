"""
Gate.io加密货币异动监控系统 - 主程序（优化版）
集成所有功能模块，实现异动监控、多账号推送和快捷管理
支持自定义推送格式和市场动态数据实时补全
"""

import logging
import time
import json
import os
import sys
import argparse
import threading
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

# 导入自定义模块
from src.data_collector import GateioDataCollector as DataCollector
from src.anomaly_detector import AnomalyDetector

# 导入增强模块
try:
    from src.enhanced_multi_telegram_alerter import EnhancedMultiTelegramAlerter
    enhanced_telegram_available = True
except ImportError:
    from src.telegram_alerter import TelegramAlerter
    enhanced_telegram_available = False

try:
    from src.enhanced_coin_info import EnhancedCoinInfo
    enhanced_coin_info_available = True
except ImportError:
    # 创建一个基础的CoinInfoFetcher类作为回退
    class CoinInfoFetcher:
        def __init__(self):
            logging.getLogger("main").warning("使用基础币种信息查询类（回退）")
        
        def get_comprehensive_info(self, symbol):
            return {"symbol": symbol, "name": symbol.split('_')[0], "description": "暂无描述"}
    
    enhanced_coin_info_available = False

try:
    from src.enhanced_reason_analyzer import EnhancedReasonAnalyzer
    enhanced_reason_analyzer_available = True
except ImportError:
    from src.deep_analyzer import DeepAnalyzer
    enhanced_reason_analyzer_available = False

try:
    from src.chart_generator import ChartGenerator
    chart_generator_available = True
except ImportError:
    chart_generator_available = False

try:
    from src.price_history_fetcher import PriceHistoryFetcher
    price_history_available = True
except ImportError:
    price_history_available = False

try:
    from src.contract_info_fetcher import ContractInfoFetcher
    contract_info_available = True
except ImportError:
    contract_info_available = False

try:
    from src.timezone_utils import format_time, get_current_time
    timezone_utils_available = True
except ImportError:
    timezone_utils_available = False

# 导入自定义格式化模块
try:
    from src.custom_formatter import CustomFormatter, custom_formatter
    custom_formatter_available = True
except ImportError:
    custom_formatter_available = False
    # 如果导入失败，创建自定义格式化模块
    from src.custom_formatter import CustomFormatter
    custom_formatter = CustomFormatter()
    custom_formatter_available = True

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("main")

class CryptoMonitor:
    """加密货币异动监控系统主类"""
    
    def __init__(self, config_file: str = "config.json"):
        """
        初始化加密货币异动监控系统
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        
        # 初始化模块
        self.data_collector = DataCollector()
        # 修复：传递data_collector实例给AnomalyDetector
        self.anomaly_detector = AnomalyDetector(self.data_collector)
        
        # 初始化增强模块
        if enhanced_telegram_available:
            self.telegram_alerter = EnhancedMultiTelegramAlerter()
            logger.info("使用增强版多账号Telegram警报器")
        else:
            self.telegram_alerter = TelegramAlerter()
            logger.info("使用标准Telegram警报器")
        
        if enhanced_coin_info_available:
            self.coin_info_fetcher = EnhancedCoinInfo()
            logger.info("使用增强版币种信息查询模块")
        else:
            self.coin_info_fetcher = CoinInfoFetcher()
            logger.info("使用标准币种信息查询模块")
        
        if enhanced_reason_analyzer_available:
            self.reason_analyzer = EnhancedReasonAnalyzer()
            logger.info("使用增强版异动原因分析模块")
        else:
            self.reason_analyzer = DeepAnalyzer()
            logger.info("使用标准异动原因分析模块")
        
        # 初始化可选模块
        self.chart_generator = ChartGenerator() if chart_generator_available else None
        if self.chart_generator:
            logger.info("图表生成模块初始化完成")
        
        self.price_history_fetcher = PriceHistoryFetcher() if price_history_available else None
        if self.price_history_fetcher:
            logger.info("历史价格数据获取模块初始化完成")
        
        self.contract_info_fetcher = ContractInfoFetcher() if contract_info_available else None
        if self.contract_info_fetcher:
            logger.info("合约信息获取模块初始化完成")
        
        # 初始化自定义格式化模块
        self.custom_formatter = custom_formatter
        if custom_formatter_available:
            logger.info("自定义格式化模块初始化完成")
        
        # 运行标志
        self.running = False
        
        # 推送格式配置
        self.use_custom_format = True  # 默认使用自定义格式
        
        logger.info("加密货币异动监控系统初始化完成")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置文件
        
        Returns:
            配置字典
        """
        default_config = {
            "check_interval": 50,  # 检查间隔（秒）
            "price_threshold": 30.0,  # 价格异动阈值（百分比）
            "volume_threshold": 200.0,  # 交易量异动阈值（百分比）
            "api_key": "",  # Gate.io API Key
            "api_secret": "",  # Gate.io API Secret
            "excluded_symbols": [],  # 排除的币种符号
            "use_custom_format": True  # 使用自定义推送格式
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    # 合并默认配置和加载的配置
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    
                    logger.info(f"从配置文件加载配置成功")
                    return config
            else:
                logger.warning(f"配置文件 {self.config_file} 不存在，使用默认配置")
                return default_config
        except Exception as e:
            logger.error(f"加载配置文件失败: {str(e)}")
            return default_config
    
    def save_config(self) -> bool:
        """
        保存配置到文件
        
        Returns:
            保存是否成功
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            
            logger.info(f"保存配置到文件成功")
            return True
        except Exception as e:
            logger.error(f"保存配置到文件失败: {str(e)}")
            return False
    
    def update_config(self, new_config: Dict[str, Any]) -> bool:
        """
        更新配置
        
        Args:
            new_config: 新配置字典
            
        Returns:
            更新是否成功
        """
        try:
            # 更新配置
            for key, value in new_config.items():
                self.config[key] = value
            
            # 保存配置
            success = self.save_config()
            
            if success:
                logger.info(f"更新配置成功")
            else:
                logger.error(f"更新配置失败")
            
            return success
        except Exception as e:
            logger.error(f"更新配置失败: {str(e)}")
            return False
    
    def run_setup_wizard(self) -> bool:
        """
        运行设置向导
        
        Returns:
            设置是否成功
        """
        print("\n===== Gate.io加密货币异动监控系统设置向导 =====\n")
        
        try:
            # 设置API配置
            print("\n--- API配置 ---")
            api_key = input("Gate.io API Key (留空保持不变): ")
            api_secret = input("Gate.io API Secret (留空保持不变): ")
            
            if api_key:
                self.config["api_key"] = api_key
            if api_secret:
                self.config["api_secret"] = api_secret
            
            # 设置异动阈值
            print("\n--- 异动阈值配置 ---")
            price_threshold_str = input(f"价格异动阈值 (百分比，当前: {self.config['price_threshold']}): ")
            volume_threshold_str = input(f"交易量异动阈值 (百分比，当前: {self.config['volume_threshold']}): ")
            
            if price_threshold_str:
                self.config["price_threshold"] = float(price_threshold_str)
            if volume_threshold_str:
                self.config["volume_threshold"] = float(volume_threshold_str)
            
            # 设置检查间隔
            print("\n--- 检查间隔配置 ---")
            check_interval_str = input(f"检查间隔 (秒，当前: {self.config['check_interval']}): ")
            
            if check_interval_str:
                self.config["check_interval"] = int(check_interval_str)
            
            # 设置排除币种
            print("\n--- 排除币种配置 ---")
            excluded_symbols_str = input(f"排除的币种符号 (用逗号分隔，当前: {','.join(self.config['excluded_symbols'])}): ")
            
            if excluded_symbols_str:
                self.config["excluded_symbols"] = [s.strip() for s in excluded_symbols_str.split(",")]
            
            # 设置推送格式
            print("\n--- 推送格式配置 ---")
            print("1. 使用自定义推送格式（包含市值、创建者持有量、社交媒体等信息）")
            print("2. 使用标准推送格式")
            
            format_choice = input(f"请选择 (当前: {'1' if self.config.get('use_custom_format', True) else '2'}): ")
            
            if format_choice == "1":
                self.config["use_custom_format"] = True
                self.use_custom_format = True
                print("已选择使用自定义推送格式")
            elif format_choice == "2":
                self.config["use_custom_format"] = False
                self.use_custom_format = False
                print("已选择使用标准推送格式")
            
            # 设置Telegram配置
            print("\n--- Telegram配置 ---")
            print("1. 添加新的Telegram账号")
            print("2. 跳过Telegram配置")
            
            choice = input("请选择: ")
            
            if choice == "1":
                # 检查是否支持多账号
                if enhanced_telegram_available and hasattr(self.telegram_alerter, "telegram_manager"):
                    name = input("账号名称: ")
                    token = input("Telegram Bot Token: ")
                    chat_id = input("Telegram Chat ID: ")
                    
                    if name and token and chat_id:
                        self.telegram_alerter.telegram_manager.add_account(name, token, chat_id)
                        
                        # 测试连接
                        test = input("是否测试连接? (y/n): ")
                        if test.lower() == 'y':
                            success = self.telegram_alerter.telegram_manager.test_account(name)
                            if success:
                                print(f"账号 '{name}' 连接测试成功")
                            else:
                                print(f"账号 '{name}' 连接测试失败")
                else:
                    # 使用旧方法配置单账号
                    token = input("Telegram Bot Token: ")
                    chat_id = input("Telegram Chat ID: ")
                    
                    if token and chat_id:
                        # 保存到telegram_config.json
                        with open("telegram_config.json", 'w') as f:
                            json.dump({"token": token, "chat_id": chat_id}, f, indent=4)
                        
                        # 测试连接
                        test = input("是否测试连接? (y/n): ")
                        if test.lower() == 'y':
                            if self.telegram_alerter.test_connection():
                                print("Telegram连接测试成功")
                            else:
                                print("Telegram连接测试失败")
            
            # 保存配置
            success = self.save_config()
            
            if success:
                print("\n配置已保存成功！")
            else:
                print("\n保存配置失败！")
            
            return success
        except Exception as e:
            logger.error(f"设置向导运行失败: {str(e)}")
            print(f"\n设置向导运行失败: {str(e)}")
            return False
    
    def start(self) -> None:
        """启动监控系统"""
        if self.running:
            logger.warning("监控系统已经在运行中")
            return
        
        self.running = True
        logger.info("启动监控系统")
        
        try:
            # 发送启动通知
            if self.telegram_alerter.is_configured():
                start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if timezone_utils_available:
                    start_time = format_time()
                
                message = f"🚀 Gate.io加密货币异动监控系统已启动\n\n"
                message += f"🕒 启动时间: {start_time}\n"
                message += f"⚙️ 价格异动阈值: {self.config['price_threshold']}%\n"
                message += f"⚙️ 交易量异动阈值: {self.config['volume_threshold']}%\n"
                message += f"⚙️ 检查间隔: {self.config['check_interval']}秒\n"
                message += f"📝 推送格式: {'自定义格式' if self.use_custom_format else '标准格式'}\n"
                
                # 添加增强模块信息
                features = []
                if enhanced_telegram_available:
                    features.append("多账号轮换推送")
                if chart_generator_available:
                    features.append("价格图表生成")
                if price_history_available:
                    features.append("历史价格分析")
                if contract_info_available:
                    features.append("合约信息查询")
                if enhanced_coin_info_available:
                    features.append("增强币种信息")
                if enhanced_reason_analyzer_available:
                    features.append("增强异动分析")
                if custom_formatter_available:
                    features.append("自定义推送格式")
                
                if features:
                    message += f"\n✨ 已启用增强功能:\n"
                    for feature in features:
                        message += f"  • {feature}\n"
                
                self.telegram_alerter.send_message(message)
            
            # 主监控循环
            while self.running:
                try:
                    # 获取所有币种的ticker数据
                    logger.info("获取所有币种ticker数据")
                    tickers = self.data_collector.fetch_all_tickers()  # 修正方法名为fetch_all_tickers
                    
                    # 检测异常 - 修正方法名为detect_all_anomalies
                    logger.info("检测异常")
                    anomalies = self.anomaly_detector.detect_all_anomalies()
                    
                    # 处理异常
                    for anomaly in anomalies:
                        self._process_anomaly(anomaly)
                    
                    # 等待下一次检查
                    check_interval = self.config["check_interval"]
                    logger.info(f"等待 {check_interval}秒 后进行下一次检查")
                    
                    # 分段等待，以便能够及时响应停止信号
                    for _ in range(check_interval):
                        if not self.running:
                            break
                        time.sleep(1)
                except Exception as e:
                    logger.error(f"监控循环异常: {str(e)}")
                    time.sleep(10)  # 出错后等待一段时间再继续
        except KeyboardInterrupt:
            logger.info("接收到键盘中断信号，停止监控系统")
        finally:
            self.running = False
            logger.info("监控系统已停止")
    
    def stop(self) -> None:
        """停止监控系统"""
        if not self.running:
            logger.warning("监控系统未在运行")
            return
        
        logger.info("停止监控系统")
        self.running = False
    
    def _process_anomaly(self, anomaly: Dict[str, Any]) -> None:
        """
        处理异常
        
        Args:
            anomaly: 异常数据
        """
        symbol = anomaly.get("symbol", "")
        logger.info(f"处理异常: {symbol}")
        
        try:
            # 增强异常数据
            enhanced_anomaly = self._enhance_anomaly_data(anomaly)
            
            # 发送警报
            if self.telegram_alerter.is_configured():
                # 根据配置选择推送格式
                if self.use_custom_format and custom_formatter_available:
                    # 使用自定义格式
                    logger.info("使用自定义推送格式")
                    custom_message = self.custom_formatter.format_custom_message(enhanced_anomaly)
                    self.telegram_alerter.send_message(custom_message)
                else:
                    # 使用标准格式
                    logger.info("使用标准推送格式")
                    self.telegram_alerter.send_anomaly_alert(enhanced_anomaly)
        except Exception as e:
            logger.error(f"处理异常失败: {str(e)}")
    
    def _enhance_anomaly_data(self, anomaly: Dict[str, Any]) -> Dict[str, Any]:
        """
        增强异常数据，添加币种信息、历史价格、合约信息等
        
        Args:
            anomaly: 原始异常数据
            
        Returns:
            增强后的异常数据
        """
        symbol = anomaly.get("symbol", "")
        logger.info(f"增强异常数据: {symbol}")
        
        # 复制原始数据
        enhanced_anomaly = anomaly.copy()
        
        try:
            # 获取币种信息
            if enhanced_coin_info_available:
                logger.info(f"获取 {symbol} 的综合信息")
                coin_info = self.coin_info_fetcher.get_comprehensive_coin_info(symbol)  # 修正方法名
                enhanced_anomaly["coin_info"] = coin_info
            
            # 获取历史价格数据
            if price_history_available and self.price_history_fetcher:
                logger.info(f"获取 {symbol} 的历史价格数据")
                # 获取24小时价格变化
                price_change = self.price_history_fetcher.get_price_change(symbol, 24)
                enhanced_anomaly["price_history"] = price_change
                
                # 获取价格波动率
                volatility = self.price_history_fetcher.get_price_volatility(symbol, 7)
                enhanced_anomaly["volatility"] = volatility
                
                # 获取历史价格数据用于图表生成
                if chart_generator_available and self.chart_generator:
                    history = self.price_history_fetcher.get_price_history(symbol, "1h", 24)
                    if history:
                        # 提取数据
                        timestamps = [item.get("timestamp") for item in history]
                        prices = [item.get("price") for item in history]
                        volumes = [item.get("volume") for item in history]
                        
                        # 生成图表
                        chart_path = f"charts/{symbol.replace('/', '_')}_chart.png"
                        os.makedirs("charts", exist_ok=True)
                        self.chart_generator.generate_price_volume_chart(
                            symbol, timestamps, prices, volumes, chart_path
                        )
                        enhanced_anomaly["chart_path"] = chart_path
            
            # 获取合约信息
            if contract_info_available and self.contract_info_fetcher:
                logger.info(f"获取 {symbol} 的合约信息")
                contract_info = self.contract_info_fetcher.get_contract_info(symbol)
                enhanced_anomaly["contract_info"] = contract_info
            
            # 分析异动原因
            if enhanced_reason_analyzer_available:
                logger.info(f"分析 {symbol} 的异动原因")
                reasons = self.reason_analyzer.analyze_anomaly(anomaly)
                enhanced_anomaly["reasons"] = reasons
            
            return enhanced_anomaly
        except Exception as e:
            logger.error(f"增强异常数据失败: {str(e)}")
            return anomaly


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Gate.io加密货币异动监控系统")
    parser.add_argument("--config", type=str, default="config.json", help="配置文件路径")
    parser.add_argument("--setup", action="store_true", help="运行设置向导")
    parser.add_argument("--format", type=str, choices=["custom", "standard"], help="设置推送格式（custom: 自定义格式, standard: 标准格式）")
    args = parser.parse_args()
    
    # 创建监控系统实例
    monitor = CryptoMonitor(config_file=args.config)
    
    # 设置推送格式
    if args.format:
        use_custom_format = args.format == "custom"
        monitor.update_config({"use_custom_format": use_custom_format})
        monitor.use_custom_format = use_custom_format
        print(f"已设置推送格式为: {'自定义格式' if use_custom_format else '标准格式'}")
    
    # 运行设置向导
    if args.setup:
        monitor.run_setup_wizard()
        return
    
    try:
        # 启动监控系统
        print("启动Gate.io加密货币异动监控系统...")
        print(f"推送格式: {'自定义格式' if monitor.use_custom_format else '标准格式'}")
        print("按Ctrl+C停止")
        monitor.start()
    except KeyboardInterrupt:
        print("\n接收到停止信号，正在停止...")
    finally:
        monitor.stop()
        print("监控系统已停止")


if __name__ == "__main__":
    main()
