# 交易所监控系统使用说明 - 整合版

## 系统概述

本系统用于监控币安美国(Binance.US)和Gate.io交易所的币种涨跌幅，并定期扫描两家交易所的公告和新上币信息，实现自动化监控和通知功能。系统通过一个统一的主控脚本提供所有功能，支持灵活的命令行参数配置。

## 主要功能

1. **币种价格监控**
   - 实时获取Binance.US和Gate.io所有币种的价格和涨跌幅数据
   - 支持设置涨跌幅阈值，超过阈值时触发通知
   - 自动记录显著价格变动，便于后续分析

2. **公告和新上币扫描**
   - 定期扫描交易所的公告页面
   - 智能识别新上币公告并优先提醒
   - 记录历史公告，避免重复通知

3. **统一控制**
   - 单一入口脚本，简化操作
   - 多线程并行处理，提高效率
   - 灵活的命令行参数，支持自定义配置

## 系统要求

- Python 3.6+
- 必要的Python库：requests, beautifulsoup4

## 安装步骤

1. 确保系统已安装Python 3.6或更高版本
2. 安装必要的Python库：
   ```
   pip install requests beautifulsoup4
   ```
3. 如需使用代理功能，还需安装socks支持：
   ```
   pip install requests[socks]
   ```
4. 将所有脚本文件放置在同一目录下
5. 确保主脚本有执行权限：
   ```
   chmod +x crypto_monitor.py
   ```

## 使用方法

### 基本用法

直接运行主脚本，使用默认配置：

```
./crypto_monitor.py
```

### 命令行参数

脚本支持多种命令行参数，可以灵活配置：

```
usage: crypto_monitor.py [-h] [--threshold THRESHOLD]
                         [--price-interval PRICE_INTERVAL]
                         [--announcement-interval ANNOUNCEMENT_INTERVAL]
                         [--proxy] [--no-binance] [--no-gate]
                         [--no-announcement] [--price-only]
                         [--announcement-only] [--data-dir DATA_DIR]

交易所监控系统

optional arguments:
  -h, --help            显示帮助信息并退出
  --threshold THRESHOLD
                        价格涨跌幅阈值，百分比 (默认: 5.0)
  --price-interval PRICE_INTERVAL
                        价格检查间隔，秒 (默认: 300)
  --announcement-interval ANNOUNCEMENT_INTERVAL
                        公告扫描间隔，秒 (默认: 3600)
  --proxy               使用代理 (默认: 不使用)
  --no-binance          禁用Binance.US监控 (默认: 启用)
  --no-gate             禁用Gate.io监控 (默认: 启用)
  --no-announcement     禁用公告扫描 (默认: 启用)
  --price-only          仅运行价格监控 (默认: 全部运行)
  --announcement-only   仅运行公告扫描 (默认: 全部运行)
  --data-dir DATA_DIR   数据存储目录 (默认: ./data)
```

### 使用示例

1. 仅监控价格变动，不扫描公告：
   ```
   ./crypto_monitor.py --price-only
   ```

2. 仅扫描公告，不监控价格：
   ```
   ./crypto_monitor.py --announcement-only
   ```

3. 设置更低的价格变动阈值（3%）：
   ```
   ./crypto_monitor.py --threshold 3.0
   ```

4. 更频繁地检查价格（每分钟）：
   ```
   ./crypto_monitor.py --price-interval 60
   ```

5. 使用代理服务（如Nekobox）：
   ```
   ./crypto_monitor.py --proxy
   ```

6. 仅监控Binance.US，不监控Gate.io：
   ```
   ./crypto_monitor.py --no-gate
   ```

7. 自定义数据存储目录：
   ```
   ./crypto_monitor.py --data-dir /path/to/data
   ```

## 配置代理

如果您需要使用代理（如Nekobox）来解决Gate.io的反爬虫限制，请按以下步骤操作：

1. 确保已安装代理软件（如Nekobox）并正确配置
2. 确保代理服务在本地127.0.0.1:1080端口提供SOCKS5服务
3. 运行脚本时添加`--proxy`参数：
   ```
   ./crypto_monitor.py --proxy
   ```

如需修改默认代理配置，请编辑脚本中的`CONFIG["proxy"]`部分。

## 输出文件

系统运行后会在数据目录（默认为`./data`）中生成以下文件：

1. **significant_price_changes.json**: 记录所有显著的价格变动
2. **new_announcements.json**: 记录所有新发现的公告
3. **announcement_history.json**: 记录已处理过的公告历史
4. **crypto_monitor.log**: 系统运行日志

## 设置为系统服务

### Linux (systemd)

创建服务文件：

```
sudo nano /etc/systemd/system/crypto-monitor.service
```

添加以下内容：

```
[Unit]
Description=Cryptocurrency Exchange Monitor
After=network.target

[Service]
ExecStart=/path/to/crypto_monitor.py
WorkingDirectory=/path/to/script/directory
User=yourusername
Restart=on-failure
RestartSec=30s

[Install]
WantedBy=multi-user.target
```

启用并启动服务：

```
sudo systemctl enable crypto-monitor.service
sudo systemctl start crypto-monitor.service
```

查看服务状态：

```
sudo systemctl status crypto-monitor.service
```

### Windows (任务计划程序)

1. 打开任务计划程序
2. 创建基本任务
3. 触发器选择"计算机启动时"
4. 操作选择"启动程序"，然后选择Python解释器和脚本路径
5. 完成配置并保存

## 故障排除

1. **脚本无法启动**:
   - 检查Python版本和必要库是否正确安装
   - 确保脚本有执行权限

2. **无法获取数据**:
   - 检查网络连接
   - 检查API端点是否变更
   - 查看日志文件了解详细错误信息

3. **公告扫描403错误**:
   - 尝试使用`--proxy`参数启用代理
   - 确保代理服务正常运行
   - 减少请求频率（增加`--announcement-interval`值）

4. **日志或数据文件找不到**:
   - 检查数据目录是否存在并有写入权限
   - 可以使用`--data-dir`参数指定新的数据目录

## 进阶使用

### 添加更多交易所

系统设计为模块化，可以扩展支持更多交易所。如需添加新交易所，请参考现有代码结构，添加相应的获取和处理函数。

### 自定义通知方式

目前系统使用日志和文件存储通知信息。如需添加更多通知方式（如邮件、短信等），可以修改`save_significant_changes`和`notify_new_announcements`函数。

### 数据分析与可视化

系统生成的JSON数据文件可以用于进一步的数据分析和可视化。可以使用Python的数据分析库（如pandas、matplotlib等）处理这些数据。
