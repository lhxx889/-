"""
更新后的主程序入口，集成所有API路由
"""

import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from src.models.crypto import db
from src.routes.exchange import exchange_bp
from src.routes.coin import coin_bp
from src.routes.anomaly_config import anomaly_bp, config_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# 注册API蓝图
app.register_blueprint(exchange_bp, url_prefix='/api/exchanges')
app.register_blueprint(coin_bp, url_prefix='/api/coins')
app.register_blueprint(anomaly_bp, url_prefix='/api/anomalies')
app.register_blueprint(config_bp, url_prefix='/api/config')

# 启用数据库
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# 创建数据库表
with app.app_context():
    db.create_all()

# API状态路由
@app.route('/api/status', methods=['GET'])
def api_status():
    return jsonify({
        "status": "ok",
        "version": "1.0.0",
        "name": "加密货币监控系统API"
    })

# 前端路由处理
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
