#!/bin/bash
echo "===== 修复依赖问题 ====="

# 备份原始requirements文件
cp requirements.txt requirements.txt.bak

# 修改requirements文件，移除版本限制
cat requirements.txt | grep -v "blinker==" > requirements_fixed.txt
echo "blinker>=1.6.0" >> requirements_fixed.txt

# 安装核心依赖
echo "正在安装核心依赖..."
pip install flask flask-sqlalchemy pymysql requests matplotlib numpy pandas scikit-learn

# 尝试安装修改后的requirements
echo "正在安装其他依赖..."
pip install -r requirements_fixed.txt --no-dependencies

echo "依赖修复完成，请运行 ./start.sh 启动系统"
