#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
加密货币API智能管理器
实现API请求智能管理、高效缓存系统和多数据源自动切换
解决CoinGecko API请求限制问题
"""

import os
import sys
import json
import time
import logging
import random
import threading
from datetime import datetime, timedelta
import hashlib
from typing import Dict, Any, List, Optional, Tuple, Union

# 确保脚本可以导入其他模块
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# 尝试导入模块，如果失败则提示安装
try:
    import requests
    import pytz  # 用于时区转换
except ImportError:
    print("缺少必要的Python库。请运行以下命令安装：")
    print("pip install requests pytz")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(script_dir, "crypto_api_manager.log")),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("crypto_api_manager")

# 默认配置
DEFAULT_CONFIG = {
    "cache_dir": os.path.join(script_dir, "cache"),
    "cache_expiry": {
        "coin_list": 86400,  # 24小时
        "coin_detail": 3600,  # 1小时
        "market_data": 300,   # 5分钟
    },
    "request_delay": {
        "min_delay": 1.0,     # 最小延迟秒数
        "max_delay": 5.0,     # 最大延迟秒数
        "default_delay": 1.2  # 默认延迟秒数
    },
    "retry_settings": {
        "max_retries": 3,     # 最大重试次数
        "base_delay": 2.0,    # 基础延迟秒数
        "max_delay": 60.0     # 最大延迟秒数
    },
    "data_sources": {
        "coingecko": {
            "enabled": True,
            "priority": 1,
            "base_url": "https://api.coingecko.com/api/v3",
            "api_key": "",
            "endpoints": {
                "coin_list": "/coins/list",
                "coin_detail": "/coins/{id}",
                "market_data": "/coins/markets"
            }
        },
        "coinmarketcap": {
            "enabled": True,
            "priority": 2,
            "base_url": "https://pro-api.coinmarketcap.com/v1",
            "api_key": "",
            "endpoints": {
                "coin_list": "/cryptocurrency/map",
                "coin_detail": "/cryptocurrency/info",
                "market_data": "/cryptocurrency/quotes/latest"
            }
        }
    },
    "use_proxy": False,
    "proxy": {
        "http": "socks5://127.0.0.1:1080",
        "https": "socks5://127.0.0.1:1080"
    }
}

class CryptoAPIManager:
    """加密货币API智能管理器"""
    
    def __init__(self, config_file=None):
        """初始化API管理器"""
        self.config = DEFAULT_CONFIG.copy()
        if config_file and os.path.exists(config_file):
            self._load_config(config_file)
        
        # 确保缓存目录存在
        if not os.path.exists(self.config["cache_dir"]):
            os.makedirs(self.config["cache_dir"])
        
        # 请求锁，用于控制请求频率
        self.request_locks = {
            "coingecko": threading.Lock(),
            "coinmarketcap": threading.Lock()
        }
        
        # 上次请求时间
        self.last_request_time = {
            "coingecko": 0,
            "coinmarketcap": 0
        }
        
        # 当前延迟时间
        self.current_delay = {
            "coingecko": self.config["request_delay"]["default_delay"],
            "coinmarketcap": self.config["request_delay"]["default_delay"]
        }
        
        # 错误计数器
        self.error_counts = {
            "coingecko": 0,
            "coinmarketcap": 0
        }
        
        # 数据源状态
        self.source_status = {
            "coingecko": True,  # True表示可用
            "coinmarketcap": True
        }
        
        # 币种ID映射缓存
        self.id_mappings = {
            "symbol_to_coingecko": {},
            "symbol_to_coinmarketcap": {},
            "coingecko_to_coinmarketcap": {},
            "coinmarketcap_to_coingecko": {}
        }
        
        # 初始化缓存
        self._init_cache()
        
        logger.info("加密货币API智能管理器初始化完成")
    
    def _load_config(self, config_file):
        """从文件加载配置"""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
                # 递归更新配置
                self._update_config(self.config, user_config)
            logger.info(f"已从{config_file}加载配置")
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
    
    def _update_config(self, target, source):
        """递归更新配置"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._update_config(target[key], value)
            else:
                target[key] = value
    
    def _init_cache(self):
        """初始化缓存"""
        # 创建缓存子目录
        for cache_type in ["coin_list", "coin_detail", "market_data"]:
            cache_dir = os.path.join(self.config["cache_dir"], cache_type)
            if not os.path.exists(cache_dir):
                os.makedirs(cache_dir)
        
        # 加载币种ID映射缓存
        self._load_id_mappings()
    
    def _load_id_mappings(self):
        """加载币种ID映射缓存"""
        mapping_file = os.path.join(self.config["cache_dir"], "id_mappings.json")
        if os.path.exists(mapping_file):
            try:
                with open(mapping_file, 'r', encoding='utf-8') as f:
                    self.id_mappings = json.load(f)
                logger.info("已加载币种ID映射缓存")
            except Exception as e:
                logger.error(f"加载币种ID映射缓存失败: {e}")
    
    def _save_id_mappings(self):
        """保存币种ID映射缓存"""
        mapping_file = os.path.join(self.config["cache_dir"], "id_mappings.json")
        try:
            with open(mapping_file, 'w', encoding='utf-8') as f:
                json.dump(self.id_mappings, f, ensure_ascii=False, indent=2)
            logger.info("已保存币种ID映射缓存")
        except Exception as e:
            logger.error(f"保存币种ID映射缓存失败: {e}")
    
    def _get_cache_path(self, cache_type, key):
        """获取缓存文件路径"""
        # 使用MD5哈希作为文件名，避免特殊字符问题
        hashed_key = hashlib.md5(key.encode()).hexdigest()
        return os.path.join(self.config["cache_dir"], cache_type, f"{hashed_key}.json")
    
    def _get_from_cache(self, cache_type, key):
        """从缓存获取数据"""
        cache_path = self._get_cache_path(cache_type, key)
        if not os.path.exists(cache_path):
            return None
        
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                cached_data = json.load(f)
            
            # 检查缓存是否过期
            expiry = self.config["cache_expiry"][cache_type]
            if time.time() - cached_data["timestamp"] > expiry:
                logger.debug(f"缓存已过期: {cache_type}/{key}")
                return None
            
            logger.debug(f"从缓存获取数据: {cache_type}/{key}")
            return cached_data["data"]
        except Exception as e:
            logger.error(f"读取缓存失败: {cache_type}/{key}: {e}")
            return None
    
    def _save_to_cache(self, cache_type, key, data):
        """保存数据到缓存"""
        cache_path = self._get_cache_path(cache_type, key)
        try:
            cached_data = {
                "timestamp": time.time(),
                "data": data
            }
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(cached_data, f, ensure_ascii=False, indent=2)
            logger.debug(f"保存数据到缓存: {cache_type}/{key}")
            return True
        except Exception as e:
            logger.error(f"保存缓存失败: {cache_type}/{key}: {e}")
            return False
    
    def _clear_cache(self, cache_type=None):
        """清除缓存"""
        if cache_type:
            cache_dir = os.path.join(self.config["cache_dir"], cache_type)
            if os.path.exists(cache_dir):
                for file in os.listdir(cache_dir):
                    os.remove(os.path.join(cache_dir, file))
                logger.info(f"已清除{cache_type}缓存")
        else:
            for cache_type in ["coin_list", "coin_detail", "market_data"]:
                self._clear_cache(cache_type)
            logger.info("已清除所有缓存")
    
    def _wait_for_rate_limit(self, source):
        """等待以遵守速率限制"""
        with self.request_locks[source]:
            current_time = time.time()
            elapsed = current_time - self.last_request_time[source]
            
            # 如果距离上次请求时间小于当前延迟，则等待
            if elapsed < self.current_delay[source]:
                wait_time = self.current_delay[source] - elapsed
                logger.debug(f"等待 {wait_time:.2f} 秒以遵守{source}速率限制")
                time.sleep(wait_time)
            
            # 更新上次请求时间
            self.last_request_time[source] = time.time()
    
    def _adjust_delay(self, source, success):
        """根据请求结果调整延迟"""
        with self.request_locks[source]:
            if success:
                # 请求成功，逐渐减少延迟，但不低于最小延迟
                self.error_counts[source] = 0
                self.current_delay[source] = max(
                    self.config["request_delay"]["min_delay"],
                    self.current_delay[source] * 0.9  # 每次成功减少10%
                )
            else:
                # 请求失败，增加延迟
                self.error_counts[source] += 1
                
                # 使用指数退避算法
                backoff_factor = min(2 ** self.error_counts[source], 10)  # 最多增加10倍
                self.current_delay[source] = min(
                    self.config["request_delay"]["max_delay"],
                    self.current_delay[source] * backoff_factor
                )
                
                logger.info(f"{source} 请求失败，调整延迟至 {self.current_delay[source]:.2f} 秒")
    
    def _make_request(self, source, endpoint, params=None, method="GET"):
        """发送API请求"""
        if not self.source_status[source]:
            logger.warning(f"{source} 当前不可用，跳过请求")
            return None
        
        source_config = self.config["data_sources"][source]
        if not source_config["enabled"]:
            logger.warning(f"{source} 已禁用，跳过请求")
            return None
        
        url = f"{source_config['base_url']}{endpoint}"
        headers = {}
        
        # 添加API密钥
        if source_config["api_key"]:
            if source == "coingecko":
                # CoinGecko使用x-cg-pro-api-key头
                headers["x-cg-pro-api-key"] = source_config["api_key"]
            elif source == "coinmarketcap":
                # CoinMarketCap使用X-CMC_PRO_API_KEY头
                headers["X-CMC_PRO_API_KEY"] = source_config["api_key"]
        
        # 准备请求参数
        request_params = params or {}
        
        # 等待以遵守速率限制
        self._wait_for_rate_limit(source)
        
        # 发送请求
        try:
            # 是否使用代理
            proxies = self.config["proxy"] if self.config["use_proxy"] else None
            
            if method.upper() == "GET":
                response = requests.get(
                    url, 
                    headers=headers, 
                    params=request_params, 
                    proxies=proxies, 
                    timeout=15
                )
            elif method.upper() == "POST":
                response = requests.post(
                    url, 
                    headers=headers, 
                    json=request_params, 
                    proxies=proxies, 
                    timeout=15
                )
            else:
                logger.error(f"不支持的请求方法: {method}")
                self._adjust_delay(source, False)
                return None
            
            # 检查响应状态
            if response.status_code == 200:
                self._adjust_delay(source, True)
                return response.json()
            elif response.status_code == 429:  # Too Many Requests
                logger.warning(f"{source} 请求频率过高 (429): {url}")
                self._adjust_delay(source, False)
                
                # 如果连续多次429错误，暂时禁用该数据源
                if self.error_counts[source] >= 3:
                    logger.warning(f"暂时禁用 {source} (连续多次429错误)")
                    self.source_status[source] = False
                    
                    # 启动一个定时器，一段时间后重新启用
                    def enable_source():
                        logger.info(f"重新启用 {source}")
                        self.source_status[source] = True
                        self.error_counts[source] = 0
                    
                    # 5分钟后重新启用
                    threading.Timer(300, enable_source).start()
                
                return None
            else:
                logger.error(f"{source} 请求失败 ({response.status_code}): {url}")
                self._adjust_delay(source, False)
                return None
        
        except Exception as e:
            logger.error(f"{source} 请求异常: {url}: {e}")
            self._adjust_delay(source, False)
            return None
    
    def _get_coin_list_coingecko(self):
        """获取CoinGecko币种列表"""
        endpoint = self.config["data_sources"]["coingecko"]["endpoints"]["coin_list"]
        return self._make_request("coingecko", endpoint)
    
    def _get_coin_list_coinmarketcap(self):
        """获取CoinMarketCap币种列表"""
        endpoint = self.config["data_sources"]["coinmarketcap"]["endpoints"]["coin_list"]
        return self._make_request("coinmarketcap", endpoint)
    
    def _get_coin_detail_coingecko(self, coin_id, params=None):
        """获取CoinGecko币种详情"""
        endpoint = self.config["data_sources"]["coingecko"]["endpoints"]["coin_detail"].format(id=coin_id)
        default_params = {
            "localization": "false",
            "tickers": "false",
            "market_data": "true",
            "community_data": "true",
            "developer_data": "false",
            "sparkline": "false"
        }
        if params:
            default_params.update(params)
        return self._make_request("coingecko", endpoint, default_params)
    
    def _get_coin_detail_coinmarketcap(self, coin_id):
        """获取CoinMarketCap币种详情"""
        endpoint = self.config["data_sources"]["coinmarketcap"]["endpoints"]["coin_detail"]
        params = {"id": coin_id}
        return self._make_request("coinmarketcap", endpoint, params)
    
    def _build_id_mappings(self):
        """构建币种ID映射"""
        # 从缓存获取币种列表
        coingecko_list = self.get_coin_list("coingecko")
        coinmarketcap_list = self.get_coin_list("coinmarketcap")
        
        if not coingecko_list or not coinmarketcap_list:
            logger.error("无法构建币种ID映射：缺少币种列表数据")
            return False
        
        # 构建符号到ID的映射
        symbol_to_coingecko = {}
        for coin in coingecko_list:
            symbol = coin.get("symbol", "").lower()
            if symbol:
                if symbol not in symbol_to_coingecko:
                    symbol_to_coingecko[symbol] = []
                symbol_to_coingecko[symbol].append(coin.get("id"))
        
        symbol_to_coinmarketcap = {}
        if "data" in coinmarketcap_list:
            for coin in coinmarketcap_list["data"]:
                symbol = coin.get("symbol", "").lower()
                if symbol:
                    if symbol not in symbol_to_coinmarketcap:
                        symbol_to_coinmarketcap[symbol] = []
                    symbol_to_coinmarketcap[symbol].append(str(coin.get("id")))
        
        # 更新映射
        self.id_mappings["symbol_to_coingecko"] = symbol_to_coingecko
        self.id_mappings["symbol_to_coinmarketcap"] = symbol_to_coinmarketcap
        
        # 尝试构建跨平台ID映射
        coingecko_to_coinmarketcap = {}
        coinmarketcap_to_coingecko = {}
        
        for symbol in symbol_to_coingecko:
            if symbol in symbol_to_coinmarketcap:
                for cg_id in symbol_to_coingecko[symbol]:
                    for cmc_id in symbol_to_coinmarketcap[symbol]:
                        coingecko_to_coinmarketcap[cg_id] = cmc_id
                        coinmarketcap_to_coingecko[cmc_id] = cg_id
        
        self.id_mappings["coingecko_to_coinmarketcap"] = coingecko_to_coinmarketcap
        self.id_mappings["coinmarketcap_to_coingecko"] = coinmarketcap_to_coingecko
        
        # 保存映射
        self._save_id_mappings()
        
        logger.info(f"已构建币种ID映射: {len(symbol_to_coingecko)}个CoinGecko币种, {len(symbol_to_coinmarketcap)}个CoinMarketCap币种")
        return True
    
    def get_coin_list(self, source="coingecko"):
        """获取币种列表"""
        # 从缓存获取
        cached_data = self._get_from_cache("coin_list", source)
        if cached_data:
            return cached_data
        
        # 从API获取
        if source == "coingecko":
            data = self._get_coin_list_coingecko()
        elif source == "coinmarketcap":
            data = self._get_coin_list_coinmarketcap()
        else:
            logger.error(f"不支持的数据源: {source}")
            return None
        
        # 保存到缓存
        if data:
            self._save_to_cache("coin_list", source, data)
        
        return data
    
    def get_coin_id(self, symbol, source="coingecko"):
        """根据符号获取币种ID"""
        symbol = symbol.lower()
        
        # 如果映射为空，尝试构建
        if not self.id_mappings["symbol_to_coingecko"] or not self.id_mappings["symbol_to_coinmarketcap"]:
            self._build_id_mappings()
        
        # 从映射中获取
        if source == "coingecko":
            if symbol in self.id_mappings["symbol_to_coingecko"]:
                return self.id_mappings["symbol_to_coingecko"][symbol][0]
        elif source == "coinmarketcap":
            if symbol in self.id_mappings["symbol_to_coinmarketcap"]:
                return self.id_mappings["symbol_to_coinmarketcap"][symbol][0]
        
        # 如果映射中没有，尝试刷新映射
        self._build_id_mappings()
        
        # 再次尝试获取
        if source == "coingecko":
            if symbol in self.id_mappings["symbol_to_coingecko"]:
                return self.id_mappings["symbol_to_coingecko"][symbol][0]
        elif source == "coinmarketcap":
            if symbol in self.id_mappings["symbol_to_coinmarketcap"]:
                return self.id_mappings["symbol_to_coinmarketcap"][symbol][0]
        
        logger.warning(f"未找到币种ID: {symbol} ({source})")
        return None
    
    def get_coin_detail(self, coin_id_or_symbol, source="auto"):
        """获取币种详情"""
        # 确定数据源
        if source == "auto":
            # 按优先级尝试数据源
            sources = sorted(
                [s for s, cfg in self.config["data_sources"].items() if cfg["enabled"]],
                key=lambda s: self.config["data_sources"][s]["priority"]
            )
        else:
            sources = [source]
        
        # 尝试每个数据源
        for src in sources:
            # 确定币种ID
            coin_id = coin_id_or_symbol
            
            # 如果输入是符号，转换为ID
            if len(coin_id_or_symbol) < 15 and not coin_id_or_symbol.startswith("0x"):
                coin_id = self.get_coin_id(coin_id_or_symbol, src)
                if not coin_id:
                    continue
            
            # 构建缓存键
            cache_key = f"{src}_{coin_id}"
            
            # 从缓存获取
            cached_data = self._get_from_cache("coin_detail", cache_key)
            if cached_data:
                return cached_data
            
            # 从API获取
            if src == "coingecko":
                data = self._get_coin_detail_coingecko(coin_id)
            elif src == "coinmarketcap":
                data = self._get_coin_detail_coinmarketcap(coin_id)
            else:
                logger.error(f"不支持的数据源: {src}")
                continue
            
            # 保存到缓存
            if data:
                self._save_to_cache("coin_detail", cache_key, data)
                return data
        
        logger.error(f"无法获取币种详情: {coin_id_or_symbol}")
        return None
    
    def get_coin_market_data(self, coin_id_or_symbol, source="auto"):
        """获取币种市场数据"""
        # 这里简化处理，直接调用get_coin_detail并提取市场数据
        coin_detail = self.get_coin_detail(coin_id_or_symbol, source)
        if not coin_detail:
            return None
        
        # 提取市场数据
        if "market_data" in coin_detail:
            return coin_detail["market_data"]
        
        return None
    
    def get_coin_social_data(self, coin_id_or_symbol, source="auto"):
        """获取币种社交数据"""
        # 这里简化处理，直接调用get_coin_detail并提取社交数据
        coin_detail = self.get_coin_detail(coin_id_or_symbol, source)
        if not coin_detail:
            return None
        
        # 提取社交数据
        result = {}
        
        # 从links中提取
        if "links" in coin_detail:
            result["links"] = coin_detail["links"]
        
        # 从community_data中提取
        if "community_data" in coin_detail:
            result["community_data"] = coin_detail["community_data"]
        
        return result if result else None
    
    def get_coin_holders_count(self, coin_id_or_symbol, source="auto"):
        """获取币种持有人数量"""
        # 这里简化处理，直接调用get_coin_detail并提取持有人数量
        coin_detail = self.get_coin_detail(coin_id_or_symbol, source)
        if not coin_detail:
            return None
        
        # 从community_data中提取
        if "community_data" in coin_detail and "holders_count" in coin_detail["community_data"]:
            return coin_detail["community_data"]["holders_count"]
        
        return None
    
    def get_coin_price_history(self, coin_id_or_symbol, days=7, source="auto"):
        """获取币种价格历史"""
        # 确定数据源
        if source == "auto":
            # 按优先级尝试数据源
            sources = sorted(
                [s for s, cfg in self.config["data_sources"].items() if cfg["enabled"]],
                key=lambda s: self.config["data_sources"][s]["priority"]
            )
        else:
            sources = [source]
        
        # 尝试每个数据源
        for src in sources:
            # 确定币种ID
            coin_id = coin_id_or_symbol
            
            # 如果输入是符号，转换为ID
            if len(coin_id_or_symbol) < 15 and not coin_id_or_symbol.startswith("0x"):
                coin_id = self.get_coin_id(coin_id_or_symbol, src)
                if not coin_id:
                    continue
            
            # 构建缓存键
            cache_key = f"{src}_{coin_id}_history_{days}"
            
            # 从缓存获取
            cached_data = self._get_from_cache("market_data", cache_key)
            if cached_data:
                return cached_data
            
            # 从API获取
            if src == "coingecko":
                # CoinGecko的价格历史API
                endpoint = f"/coins/{coin_id}/market_chart"
                params = {
                    "vs_currency": "usd",
                    "days": days,
                    "interval": "daily"
                }
                data = self._make_request("coingecko", endpoint, params)
            elif src == "coinmarketcap":
                # CoinMarketCap没有直接的历史API，这里简化处理
                logger.warning("CoinMarketCap不支持直接获取价格历史")
                continue
            else:
                logger.error(f"不支持的数据源: {src}")
                continue
            
            # 保存到缓存
            if data:
                self._save_to_cache("market_data", cache_key, data)
                return data
        
        logger.error(f"无法获取币种价格历史: {coin_id_or_symbol}")
        return None
    
    def search_coins(self, query, limit=10, source="auto"):
        """搜索币种"""
        # 确定数据源
        if source == "auto":
            # 按优先级尝试数据源
            sources = sorted(
                [s for s, cfg in self.config["data_sources"].items() if cfg["enabled"]],
                key=lambda s: self.config["data_sources"][s]["priority"]
            )
        else:
            sources = [source]
        
        results = []
        query = query.lower()
        
        # 尝试每个数据源
        for src in sources:
            # 获取币种列表
            coin_list = self.get_coin_list(src)
            if not coin_list:
                continue
            
            # 搜索匹配项
            matched_coins = []
            
            if src == "coingecko":
                for coin in coin_list:
                    if (query in coin.get("id", "").lower() or 
                        query in coin.get("symbol", "").lower() or 
                        query in coin.get("name", "").lower()):
                        matched_coins.append({
                            "id": coin.get("id"),
                            "symbol": coin.get("symbol"),
                            "name": coin.get("name"),
                            "source": "coingecko"
                        })
            elif src == "coinmarketcap" and "data" in coin_list:
                for coin in coin_list["data"]:
                    if (query in str(coin.get("id")).lower() or 
                        query in coin.get("symbol", "").lower() or 
                        query in coin.get("name", "").lower()):
                        matched_coins.append({
                            "id": str(coin.get("id")),
                            "symbol": coin.get("symbol"),
                            "name": coin.get("name"),
                            "source": "coinmarketcap"
                        })
            
            # 添加到结果
            results.extend(matched_coins[:limit])
            
            # 如果已经找到足够的结果，停止搜索
            if len(results) >= limit:
                break
        
        return results[:limit]
    
    def get_trending_coins(self, limit=10):
        """获取热门币种"""
        # 尝试从CoinGecko获取热门币种
        endpoint = "/search/trending"
        data = self._make_request("coingecko", endpoint)
        
        if not data or "coins" not in data:
            logger.error("无法获取热门币种")
            return []
        
        trending_coins = []
        for item in data["coins"][:limit]:
            coin = item.get("item", {})
            trending_coins.append({
                "id": coin.get("id"),
                "symbol": coin.get("symbol"),
                "name": coin.get("name"),
                "market_cap_rank": coin.get("market_cap_rank"),
                "thumb": coin.get("thumb"),
                "source": "coingecko"
            })
        
        return trending_coins
    
    def analyze_price_change(self, coin_id_or_symbol, source="auto"):
        """分析价格变化"""
        # 获取币种市场数据
        market_data = self.get_coin_market_data(coin_id_or_symbol, source)
        if not market_data:
            return None
        
        # 获取价格历史
        history = self.get_coin_price_history(coin_id_or_symbol, days=30, source=source)
        
        # 分析结果
        analysis = {
            "current_price": market_data.get("current_price", {}).get("usd"),
            "market_cap": market_data.get("market_cap", {}).get("usd"),
            "total_volume": market_data.get("total_volume", {}).get("usd"),
            "price_change_24h": market_data.get("price_change_percentage_24h"),
            "price_change_7d": market_data.get("price_change_percentage_7d"),
            "price_change_30d": market_data.get("price_change_percentage_30d"),
            "market_cap_rank": market_data.get("market_cap_rank"),
            "circulating_supply": market_data.get("circulating_supply"),
            "total_supply": market_data.get("total_supply"),
            "max_supply": market_data.get("max_supply"),
        }
        
        # 添加价格历史分析
        if history and "prices" in history:
            # 计算波动性
            prices = [price[1] for price in history["prices"]]
            if len(prices) > 1:
                price_changes = [abs(prices[i] - prices[i-1]) / prices[i-1] * 100 for i in range(1, len(prices))]
                analysis["volatility"] = sum(price_changes) / len(price_changes)
            
            # 计算趋势
            if len(prices) > 2:
                # 简单线性回归
                n = len(prices)
                x = list(range(n))
                x_mean = sum(x) / n
                y_mean = sum(prices) / n
                
                numerator = sum((x[i] - x_mean) * (prices[i] - y_mean) for i in range(n))
                denominator = sum((x[i] - x_mean) ** 2 for i in range(n))
                
                if denominator != 0:
                    slope = numerator / denominator
                    analysis["trend"] = "上升" if slope > 0 else "下降" if slope < 0 else "横盘"
                    analysis["trend_strength"] = abs(slope) / y_mean * 100  # 趋势强度
        
        return analysis
    
    def get_coin_news(self, coin_id_or_symbol, limit=5):
        """获取币种相关新闻"""
        # 这个功能需要额外的新闻API，这里简化处理
        logger.warning("获取币种新闻功能需要额外的新闻API")
        return []
    
    def get_coin_all_info(self, coin_id_or_symbol, source="auto"):
        """获取币种所有信息（综合接口）"""
        # 获取币种详情
        coin_detail = self.get_coin_detail(coin_id_or_symbol, source)
        if not coin_detail:
            return None
        
        # 获取价格分析
        price_analysis = self.analyze_price_change(coin_id_or_symbol, source)
        
        # 获取社交数据
        social_data = self.get_coin_social_data(coin_id_or_symbol, source)
        
        # 获取持有人数量
        holders_count = self.get_coin_holders_count(coin_id_or_symbol, source)
        
        # 组合结果
        result = {
            "basic_info": {
                "id": coin_detail.get("id"),
                "symbol": coin_detail.get("symbol"),
                "name": coin_detail.get("name"),
                "description": coin_detail.get("description", {}).get("en")
            },
            "market_data": price_analysis,
            "social_data": social_data,
            "holders_count": holders_count
        }
        
        return result

# 单例模式
_instance = None

def get_api_manager(config_file=None):
    """获取API管理器实例（单例模式）"""
    global _instance
    if _instance is None:
        _instance = CryptoAPIManager(config_file)
    return _instance

if __name__ == "__main__":
    # 简单测试
    api_manager = CryptoAPIManager()
    
    # 测试获取币种列表
    print("获取币种列表...")
    coin_list = api_manager.get_coin_list("coingecko")
    print(f"CoinGecko币种数量: {len(coin_list) if coin_list else 0}")
    
    # 测试获取币种详情
    print("\n获取币种详情...")
    btc_detail = api_manager.get_coin_detail("bitcoin")
    if btc_detail:
        print(f"名称: {btc_detail.get('name')}")
        print(f"符号: {btc_detail.get('symbol')}")
        print(f"当前价格: ${btc_detail.get('market_data', {}).get('current_price', {}).get('usd')}")
    
    # 测试搜索币种
    print("\n搜索币种...")
    search_results = api_manager.search_coins("eth")
    for i, coin in enumerate(search_results):
        print(f"{i+1}. {coin.get('name')} ({coin.get('symbol')}) - {coin.get('source')}")
    
    # 测试获取热门币种
    print("\n获取热门币种...")
    trending = api_manager.get_trending_coins(5)
    for i, coin in enumerate(trending):
        print(f"{i+1}. {coin.get('name')} ({coin.get('symbol')}) - 排名: {coin.get('market_cap_rank')}")
    
    print("\n测试完成")
