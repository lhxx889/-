#!/bin/bash
# VLESS节点管理工具启动器

# 获取脚本所在目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# 设置Python脚本路径
PYTHON_SCRIPT="$SCRIPT_DIR/vless_node_manager.py"

# 检查Python脚本是否存在
if [ ! -f "$PYTHON_SCRIPT" ]; then
    echo "错误：找不到VLESS节点管理脚本"
    exit 1
fi

# 确保脚本有执行权限
chmod +x "$PYTHON_SCRIPT"

# 显示菜单
show_menu() {
    clear
    echo "=================================="
    echo "      VLESS节点管理工具"
    echo "=================================="
    echo "1. 添加节点"
    echo "2. 编辑节点"
    echo "3. 删除节点"
    echo "4. 列出所有节点"
    echo "5. 显示节点详细信息"
    echo "6. 使用节点"
    echo "7. 测试节点连接"
    echo "8. 从文件导入节点"
    echo "9. 导出节点到文件"
    echo "10. 重命名节点"
    echo "0. 退出"
    echo "=================================="
    echo "请选择操作 [0-10]: "
}

# 添加节点
add_node() {
    clear
    echo "=================================="
    echo "          添加节点"
    echo "=================================="
    echo "1. 从VLESS链接添加"
    echo "2. 手动添加"
    echo "0. 返回"
    echo "=================================="
    read -p "请选择添加方式 [0-2]: " choice
    
    case $choice in
        1)
            read -p "请输入VLESS链接: " link
            read -p "请输入节点名称 (可选): " name
            
            if [ -z "$name" ]; then
                python3 "$PYTHON_SCRIPT" add --link "$link"
            else
                python3 "$PYTHON_SCRIPT" add --link "$link" --name "$name"
            fi
            ;;
        2)
            read -p "请输入节点名称: " name
            read -p "请输入服务器地址: " server
            read -p "请输入服务器端口: " port
            read -p "请输入UUID: " uuid
            read -p "请输入流控 (可选): " flow
            read -p "请输入SNI (可选): " sni
            read -p "请输入指纹 (可选): " fp
            read -p "请输入安全类型 (可选): " security
            read -p "请输入公钥 (可选): " pbk
            read -p "请输入短ID (可选): " sid
            read -p "请输入备注 (可选): " remark
            
            cmd="python3 \"$PYTHON_SCRIPT\" add --name \"$name\" --server \"$server\" --port $port --uuid \"$uuid\""
            
            if [ ! -z "$flow" ]; then
                cmd="$cmd --flow \"$flow\""
            fi
            
            if [ ! -z "$sni" ]; then
                cmd="$cmd --sni \"$sni\""
            fi
            
            if [ ! -z "$fp" ]; then
                cmd="$cmd --fp \"$fp\""
            fi
            
            if [ ! -z "$security" ]; then
                cmd="$cmd --security \"$security\""
            fi
            
            if [ ! -z "$pbk" ]; then
                cmd="$cmd --pbk \"$pbk\""
            fi
            
            if [ ! -z "$sid" ]; then
                cmd="$cmd --sid \"$sid\""
            fi
            
            if [ ! -z "$remark" ]; then
                cmd="$cmd --remark \"$remark\""
            fi
            
            eval $cmd
            ;;
        0)
            return
            ;;
        *)
            echo "无效的选择"
            ;;
    esac
    
    read -p "按Enter键继续..."
}

# 编辑节点
edit_node() {
    clear
    echo "=================================="
    echo "          编辑节点"
    echo "=================================="
    
    # 获取节点列表
    python3 "$PYTHON_SCRIPT" list
    
    read -p "请输入要编辑的节点名称: " name
    
    if [ -z "$name" ]; then
        echo "节点名称不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    echo "=================================="
    echo "1. 从VLESS链接更新"
    echo "2. 手动更新"
    echo "0. 返回"
    echo "=================================="
    read -p "请选择更新方式 [0-2]: " choice
    
    case $choice in
        1)
            read -p "请输入VLESS链接: " link
            
            python3 "$PYTHON_SCRIPT" edit "$name" --link "$link"
            ;;
        2)
            read -p "请输入服务器地址 (可选): " server
            read -p "请输入服务器端口 (可选): " port
            read -p "请输入UUID (可选): " uuid
            read -p "请输入流控 (可选): " flow
            read -p "请输入SNI (可选): " sni
            read -p "请输入指纹 (可选): " fp
            read -p "请输入安全类型 (可选): " security
            read -p "请输入公钥 (可选): " pbk
            read -p "请输入短ID (可选): " sid
            read -p "请输入备注 (可选): " remark
            
            cmd="python3 \"$PYTHON_SCRIPT\" edit \"$name\""
            
            if [ ! -z "$server" ]; then
                cmd="$cmd --server \"$server\""
            fi
            
            if [ ! -z "$port" ]; then
                cmd="$cmd --port $port"
            fi
            
            if [ ! -z "$uuid" ]; then
                cmd="$cmd --uuid \"$uuid\""
            fi
            
            if [ ! -z "$flow" ]; then
                cmd="$cmd --flow \"$flow\""
            fi
            
            if [ ! -z "$sni" ]; then
                cmd="$cmd --sni \"$sni\""
            fi
            
            if [ ! -z "$fp" ]; then
                cmd="$cmd --fp \"$fp\""
            fi
            
            if [ ! -z "$security" ]; then
                cmd="$cmd --security \"$security\""
            fi
            
            if [ ! -z "$pbk" ]; then
                cmd="$cmd --pbk \"$pbk\""
            fi
            
            if [ ! -z "$sid" ]; then
                cmd="$cmd --sid \"$sid\""
            fi
            
            if [ ! -z "$remark" ]; then
                cmd="$cmd --remark \"$remark\""
            fi
            
            eval $cmd
            ;;
        0)
            return
            ;;
        *)
            echo "无效的选择"
            ;;
    esac
    
    read -p "按Enter键继续..."
}

# 删除节点
delete_node() {
    clear
    echo "=================================="
    echo "          删除节点"
    echo "=================================="
    
    # 获取节点列表
    python3 "$PYTHON_SCRIPT" list
    
    read -p "请输入要删除的节点名称: " name
    
    if [ -z "$name" ]; then
        echo "节点名称不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    read -p "确定要删除节点 '$name' 吗？(y/n): " confirm
    
    if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
        python3 "$PYTHON_SCRIPT" delete "$name"
    else
        echo "已取消删除操作"
    fi
    
    read -p "按Enter键继续..."
}

# 列出所有节点
list_nodes() {
    clear
    echo "=================================="
    echo "        所有节点列表"
    echo "=================================="
    
    python3 "$PYTHON_SCRIPT" list
    
    read -p "按Enter键继续..."
}

# 显示节点详细信息
show_node() {
    clear
    echo "=================================="
    echo "      节点详细信息"
    echo "=================================="
    
    # 获取节点列表
    python3 "$PYTHON_SCRIPT" list
    
    read -p "请输入要查看的节点名称: " name
    
    if [ -z "$name" ]; then
        echo "节点名称不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    clear
    echo "=================================="
    echo "      节点详细信息"
    echo "=================================="
    
    python3 "$PYTHON_SCRIPT" show "$name"
    
    read -p "按Enter键继续..."
}

# 使用节点
use_node() {
    clear
    echo "=================================="
    echo "          使用节点"
    echo "=================================="
    
    # 获取节点列表
    python3 "$PYTHON_SCRIPT" list
    
    read -p "请输入要使用的节点名称: " name
    
    if [ -z "$name" ]; then
        echo "节点名称不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    python3 "$PYTHON_SCRIPT" use "$name"
    
    read -p "按Enter键继续..."
}

# 测试节点连接
test_node() {
    clear
    echo "=================================="
    echo "        测试节点连接"
    echo "=================================="
    echo "1. 测试指定节点"
    echo "2. 测试所有节点"
    echo "0. 返回"
    echo "=================================="
    read -p "请选择测试方式 [0-2]: " choice
    
    case $choice in
        1)
            # 获取节点列表
            python3 "$PYTHON_SCRIPT" list
            
            read -p "请输入要测试的节点名称: " name
            
            if [ -z "$name" ]; then
                echo "节点名称不能为空"
                read -p "按Enter键继续..."
                return
            fi
            
            python3 "$PYTHON_SCRIPT" test --name "$name"
            ;;
        2)
            python3 "$PYTHON_SCRIPT" test
            ;;
        0)
            return
            ;;
        *)
            echo "无效的选择"
            ;;
    esac
    
    read -p "按Enter键继续..."
}

# 从文件导入节点
import_nodes() {
    clear
    echo "=================================="
    echo "        从文件导入节点"
    echo "=================================="
    
    read -p "请输入文件路径: " file
    
    if [ -z "$file" ]; then
        echo "文件路径不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    python3 "$PYTHON_SCRIPT" import "$file"
    
    read -p "按Enter键继续..."
}

# 导出节点到文件
export_nodes() {
    clear
    echo "=================================="
    echo "        导出节点到文件"
    echo "=================================="
    
    read -p "请输入文件路径: " file
    
    if [ -z "$file" ]; then
        echo "文件路径不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    python3 "$PYTHON_SCRIPT" export "$file"
    
    read -p "按Enter键继续..."
}

# 重命名节点
rename_node() {
    clear
    echo "=================================="
    echo "          重命名节点"
    echo "=================================="
    
    # 获取节点列表
    python3 "$PYTHON_SCRIPT" list
    
    read -p "请输入要重命名的节点名称: " old_name
    
    if [ -z "$old_name" ]; then
        echo "节点名称不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    read -p "请输入新的节点名称: " new_name
    
    if [ -z "$new_name" ]; then
        echo "新节点名称不能为空"
        read -p "按Enter键继续..."
        return
    fi
    
    python3 "$PYTHON_SCRIPT" rename "$old_name" "$new_name"
    
    read -p "按Enter键继续..."
}

# 主循环
while true; do
    show_menu
    read choice
    
    case $choice in
        1)
            add_node
            ;;
        2)
            edit_node
            ;;
        3)
            delete_node
            ;;
        4)
            list_nodes
            ;;
        5)
            show_node
            ;;
        6)
            use_node
            ;;
        7)
            test_node
            ;;
        8)
            import_nodes
            ;;
        9)
            export_nodes
            ;;
        10)
            rename_node
            ;;
        0)
            echo "感谢使用VLESS节点管理工具！"
            exit 0
            ;;
        *)
            echo "无效的选择，请重试"
            read -p "按Enter键继续..."
            ;;
    esac
done

