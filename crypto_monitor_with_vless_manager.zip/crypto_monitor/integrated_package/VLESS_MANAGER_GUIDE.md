# VLESS节点管理工具使用指南

## 概述

VLESS节点管理工具是一个命令行工具，用于管理VLESS代理节点。它提供了简单易用的界面，让您可以方便地添加、编辑、删除、测试和使用VLESS节点。

## 功能特点

- 添加、编辑、删除和查看VLESS节点
- 支持从VLESS链接导入节点
- 支持从文件批量导入节点
- 导出节点到文件
- 测试节点连接速度和稳定性
- 一键应用节点配置并重启服务

## 安装说明

1. 确保您的系统已安装Python 3和sing-box

2. 将以下文件复制到您的系统中：
   - `vless_node_manager.py`：核心管理脚本
   - `vless_manager.sh`：启动器脚本

3. 给脚本添加执行权限：
   ```bash
   chmod +x vless_node_manager.py vless_manager.sh
   ```

## 使用方法

### 通过启动器使用

运行启动器脚本：
```bash
./vless_manager.sh
```

这将显示一个交互式菜单，您可以通过数字选择不同的功能。

### 直接使用命令行

您也可以直接使用命令行参数来调用核心脚本：

```bash
# 查看帮助
python3 vless_node_manager.py --help

# 列出所有节点
python3 vless_node_manager.py list

# 添加节点（从VLESS链接）
python3 vless_node_manager.py add --link "vless://..."

# 添加节点（手动指定参数）
python3 vless_node_manager.py add --name "节点名称" --server "服务器地址" --port 端口 --uuid "UUID" --flow "流控" --sni "SNI" --security "reality" --pbk "公钥" --sid "短ID"

# 使用节点
python3 vless_node_manager.py use "节点名称"

# 测试节点
python3 vless_node_manager.py test --name "节点名称"
```

## 功能详解

### 1. 添加节点

您可以通过两种方式添加节点：

#### 从VLESS链接添加

支持标准VLESS链接格式：
```
vless://UUID@服务器:端口/?参数1=值1&参数2=值2#备注
```

例如：
```
vless://aa05ee3d-ea0f-49e5-8692-4c4f69797110@ty.fk69.top:2026/?type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.cloudflare.com&fp=chrome&security=reality&pbk=8KlmgUWuITzjG-lpUyLHAXRDf7vQ6HU1OV-TGvHR7BY&sid=#台湾省动态
```

#### 手动添加

您需要提供以下信息：
- 节点名称
- 服务器地址
- 服务器端口
- UUID
- 流控（可选）
- SNI（可选）
- 指纹（可选）
- 安全类型（可选）
- 公钥（可选）
- 短ID（可选）
- 备注（可选）

### 2. 编辑节点

您可以编辑现有节点的任何参数，方式与添加节点类似。

### 3. 删除节点

删除不再需要的节点。

### 4. 列出所有节点

显示所有已保存的节点及其基本信息。

### 5. 显示节点详细信息

查看指定节点的所有详细参数。

### 6. 使用节点

应用指定节点的配置到sing-box，并重启服务。

### 7. 测试节点连接

测试节点的连接速度和稳定性。您可以测试单个节点或所有节点。

### 8. 从文件导入节点

从包含VLESS链接的文本文件中批量导入节点。文件中的每行应该是一个完整的VLESS链接。

### 9. 导出节点到文件

将所有节点导出为VLESS链接，保存到文本文件中。

### 10. 重命名节点

修改节点的名称。

## 配置文件

工具使用以下配置文件：

1. `~/.config/vless_manager/nodes.json`：保存所有节点配置
2. `~/.config/vless_manager/config_template.json`：sing-box配置模板
3. `/etc/sing-box/config.json`：sing-box实际使用的配置文件

## 常见问题

### 1. 无法启动sing-box服务

- 确保sing-box已正确安装
- 检查配置文件格式是否正确
- 检查端口是否被占用
- 查看系统日志：`journalctl -u sing-box -n 50`

### 2. 测试节点连接失败

- 确认节点配置正确
- 检查网络连接
- 尝试使用不同的节点
- 检查防火墙设置

### 3. 如何批量导入多个节点？

创建一个文本文件，每行包含一个VLESS链接，然后使用"从文件导入节点"功能。

### 4. 如何备份我的节点配置？

使用"导出节点到文件"功能，将节点导出到安全的位置。

## 高级用法

### 自定义配置模板

您可以编辑`~/.config/vless_manager/config_template.json`文件，自定义sing-box的配置模板。

### 命令行批处理

您可以编写脚本，使用命令行参数批量处理节点：

```bash
#!/bin/bash
# 批量测试所有节点并使用最快的节点
python3 vless_node_manager.py test > test_results.txt
fastest_node=$(grep "连接成功" test_results.txt | sort -k 8 -n | head -n 1 | awk -F "'" '{print $2}')
python3 vless_node_manager.py use "$fastest_node"
```

## 技术支持

如果您在使用过程中遇到任何问题，请参考本指南或联系技术支持。

